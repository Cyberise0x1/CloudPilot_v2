/**
 * Backup Monitoring Configuration
 * Comprehensive monitoring and metrics collection for backup operations
 */

export interface MonitoringConfig {
  environment: string;
  enabled: boolean;
  metrics: MetricsConfig;
  dashboards: DashboardsConfig;
  alerting: AlertingConfig;
  status: StatusTrackingConfig;
  healthChecks: HealthCheckConfig;
  logging: LoggingConfig;
  performance: PerformanceMonitoringConfig;
  compliance: ComplianceMonitoringConfig;
}

export interface MetricsConfig {
  enabled: boolean;
  collection: MetricsCollectionConfig;
  aggregation: MetricsAggregationConfig;
  retention: MetricsRetentionConfig;
  publishing: MetricsPublishingConfig;
}

export interface MetricsCollectionConfig {
  interval: number; // seconds
  granularity: 'raw' | 'minute' | 'hourly' | 'daily';
  metrics: MetricDefinition[];
  custom: CustomMetricConfig;
}

export interface MetricDefinition {
  name: string;
  type: 'counter' | 'gauge' | 'histogram' | 'timer' | 'distribution';
  description: string;
  unit?: string;
  tags?: string[];
  source: 'system' | 'application' | 'backup' | 'storage' | 'network';
  collection: CollectionStrategy;
}

export interface CollectionStrategy {
  method: 'pull' | 'push' | 'event' | 'polling';
  endpoint?: string;
  frequency?: number; // seconds
  threshold?: number;
  conditions?: Record<string, any>;
}

export interface CustomMetricConfig {
  enabled: boolean;
  expressions: MetricExpression[];
  windows: TimeWindow[];
}

export interface MetricExpression {
  name: string;
  expression: string; // DSL or query language
  description: string;
  unit?: string;
  tags?: string[];
}

export interface TimeWindow {
  name: string;
  duration: number; // seconds
  granularity: string;
  retention: number; // days
}

export interface MetricsAggregationConfig {
  enabled: boolean;
  functions: AggregationFunction[];
  periods: AggregationPeriod[];
}

export interface AggregationFunction {
  name: 'sum' | 'avg' | 'min' | 'max' | 'p50' | 'p90' | 'p95' | 'p99';
  metrics: string[];
  window: string;
}

export interface AggregationPeriod {
  name: string;
  interval: number; // seconds
  retention: number; // days
}

export interface MetricsRetentionConfig {
  raw: number; // days
  aggregated: number; // days
  detailed: number; // days
  archived: number; // days
  cleanup: {
    enabled: boolean;
    schedule: string;
    batchSize: number;
  };
}

export interface MetricsPublishingConfig {
  enabled: boolean;
  destinations: PublishingDestination[];
  format: 'prometheus' | 'influxdb' | 'datadog' | 'cloudwatch' | 'json';
  compression: boolean;
  authentication: PublishingAuthConfig;
}

export interface PublishingDestination {
  name: string;
  type: 'prometheus' | 'influxdb' | 'datadog' | 'cloudwatch' | 'elasticsearch';
  endpoint: string;
  enabled: boolean;
  batchSize: number;
  timeout: number; // seconds
  retry: RetryConfig;
}

export interface RetryConfig {
  enabled: boolean;
  maxAttempts: number;
  backoff: 'exponential' | 'linear' | 'fixed';
  initialDelay: number; // ms
  maxDelay: number; // ms
}

export interface PublishingAuthConfig {
  type: 'none' | 'api-key' | 'oauth2' | 'basic';
  credentials?: Record<string, string>;
}

export interface DashboardsConfig {
  enabled: boolean;
  provider: 'grafana' | 'datadog' | 'cloudwatch' | 'prometheus' | 'custom';
  refreshInterval: number; // seconds
  layouts: DashboardLayout[];
  access: DashboardAccessConfig;
}

export interface DashboardLayout {
  name: string;
  description: string;
  panels: DashboardPanel[];
  variables: DashboardVariable[];
  tags: string[];
}

export interface DashboardPanel {
  id: string;
  type: 'graph' | 'stat' | 'table' | 'heatmap' | 'log' | 'alert';
  title: string;
  query: string;
  visualization: PanelVisualizationConfig;
  position: PanelPosition;
  alert?: PanelAlertConfig;
}

export interface PanelVisualizationConfig {
  colorScheme: string;
  legend: LegendConfig;
  axes: AxesConfig;
  thresholds?: ThresholdConfig[];
  options: Record<string, any>;
}

export interface LegendConfig {
  show: boolean;
  position: 'bottom' | 'right' | 'top';
  sortBy?: string;
  sortDesc?: boolean;
}

export interface AxesConfig {
  x: {
    label?: string;
    type: 'time' | 'linear' | 'log';
    format?: string;
  };
  y: {
    label?: string;
    min?: number;
    max?: number;
    format?: string;
  };
}

export interface ThresholdConfig {
  value: number;
  color: string;
  op: 'gt' | 'lt' | 'eq';
  fill: boolean;
  line: boolean;
}

export interface PanelPosition {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface PanelAlertConfig {
  enabled: boolean;
  conditions: AlertCondition[];
  notifications: string[];
  frequency: number; // seconds
}

export interface AlertCondition {
  query: string;
  reducer: 'avg' | 'sum' | 'min' | 'max';
  evaluator: 'gt' | 'lt' | 'eq' | 'ne' | 'contains';
  threshold: number;
  timeRange: number; // minutes
}

export interface DashboardVariable {
  name: string;
  type: 'query' | 'custom' | 'interval';
  query: string;
  options: VariableOption[];
  multi: boolean;
  includeAll: boolean;
}

export interface VariableOption {
  text: string;
  value: string;
  selected: boolean;
}

export interface DashboardAccessConfig {
  users: string[];
  groups: string[];
  permissions: ('view' | 'edit' | 'admin')[];
}

export interface AlertingConfig {
  enabled: boolean;
  channels: AlertChannelConfig[];
  rules: AlertRuleConfig[];
  escalation: EscalationConfig;
  suppression: SuppressionConfig;
}

export interface AlertChannelConfig {
  name: string;
  type: 'email' | 'slack' | 'pagerduty' | 'teams' | 'webhook' | 'sms';
  enabled: boolean;
  config: Record<string, any>;
  filters: AlertFilter[];
}

export interface AlertFilter {
  field: string;
  operator: 'equals' | 'contains' | 'matches' | 'in';
  value: any;
}

export interface AlertRuleConfig {
  name: string;
  description: string;
  severity: 'critical' | 'warning' | 'info';
  condition: AlertCondition;
  labels: Record<string, string>;
  annotations: Record<string, string>;
  for: number; // minutes to wait before firing
  enabled: boolean;
}

export interface EscalationConfig {
  enabled: boolean;
  levels: EscalationLevelConfig[];
  repeat: RepeatConfig;
}

export interface EscalationLevelConfig {
  delay: number; // minutes
  channels: string[];
  recipients: string[];
  conditions: EscalationCondition[];
}

export interface EscalationCondition {
  field: string;
  operator: string;
  value: any;
}

export interface RepeatConfig {
  enabled: boolean;
  interval: number; // minutes
  maxRepeats: number;
}

export interface SuppressionConfig {
  enabled: boolean;
  rules: SuppressionRule[];
}

export interface SuppressionRule {
  name: string;
  condition: AlertCondition;
  duration: number; // minutes
  description: string;
}

export interface StatusTrackingConfig {
  enabled: boolean;
  tracking: StatusTrackingMethod;
  history: HistoryConfig;
  reporting: StatusReportingConfig;
}

export interface StatusTrackingMethod {
  backupJobs: boolean;
  storage: boolean;
  network: boolean;
  application: boolean;
  system: boolean;
}

export interface HistoryConfig {
  retention: number; // days
  detail: 'summary' | 'detailed' | 'verbose';
  archive: {
    enabled: boolean;
    location: string;
  };
}

export interface StatusReportingConfig {
  enabled: boolean;
  schedule: string;
  recipients: string[];
  format: 'json' | 'html' | 'pdf';
  include: ReportIncludeConfig;
}

export interface ReportIncludeConfig {
  summary: boolean;
  details: boolean;
  trends: boolean;
  recommendations: boolean;
  attachments: boolean;
}

export interface HealthCheckConfig {
  enabled: boolean;
  checks: HealthCheckDefinition[];
  schedule: string;
  timeout: number; // seconds
  retries: number;
  notification: HealthNotificationConfig;
}

export interface HealthCheckDefinition {
  name: string;
  type: 'backup' | 'storage' | 'network' | 'system' | 'application';
  endpoint?: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  expectedStatus: number;
  timeout: number; // seconds
  interval: number; // seconds
  conditions: HealthCondition[];
}

export interface HealthCondition {
  field: string;
  operator: 'equals' | 'contains' | 'gt' | 'lt' | 'matches';
  value: any;
}

export interface HealthNotificationConfig {
  enabled: boolean;
  channels: string[];
  failureThreshold: number; // consecutive failures before notification
  recoveryThreshold: number; // consecutive successes before recovery notification
}

export interface LoggingConfig {
  enabled: boolean;
  level: 'debug' | 'info' | 'warn' | 'error';
  format: 'json' | 'text';
  destinations: LogDestination[];
  retention: LogRetentionConfig;
}

export interface LogDestination {
  type: 'console' | 'file' | 'elasticsearch' | 'cloudwatch' | 'splunk';
  enabled: boolean;
  config: Record<string, any>;
  filters: LogFilter[];
}

export interface LogFilter {
  field: string;
  operator: 'equals' | 'contains' | 'matches' | 'in';
  value: any;
  action: 'include' | 'exclude';
}

export interface LogRetentionConfig {
  enabled: boolean;
  period: number; // days
  cleanup: {
    enabled: boolean;
    schedule: string;
  };
}

export interface PerformanceMonitoringConfig {
  enabled: boolean;
  profiling: ProfilingConfig;
  benchmarking: BenchmarkingConfig;
  optimization: OptimizationConfig;
}

export interface ProfilingConfig {
  enabled: boolean;
  interval: number; // seconds
  duration: number; // seconds
  memory: boolean;
  cpu: boolean;
  io: boolean;
}

export interface BenchmarkingConfig {
  enabled: boolean;
  schedule: string;
  tests: BenchmarkTest[];
  baseline: BenchmarkBaselineConfig;
}

export interface BenchmarkTest {
  name: string;
  type: 'backup-speed' | 'restore-speed' | 'compression' | 'encryption' | 'network';
  parameters: Record<string, any>;
}

export interface BenchmarkBaselineConfig {
  enabled: boolean;
  environment: string;
  history: number; // number of baseline runs to keep
}

export interface OptimizationConfig {
  enabled: boolean;
  recommendations: boolean;
  autoTuning: boolean;
  thresholds: OptimizationThreshold[];
}

export interface OptimizationThreshold {
  metric: string;
  warning: number;
  critical: number;
  action: 'optimize' | 'alert' | 'scale';
}

export interface ComplianceMonitoringConfig {
  enabled: boolean;
  standards: ComplianceStandard[];
  audits: ComplianceAudit[];
  reporting: ComplianceReportingConfig;
}

export interface ComplianceStandard {
  name: 'FIPS-140-2' | 'PCI-DSS' | 'GDPR' | 'HIPAA' | 'SOX' | 'ISO-27001';
  enabled: boolean;
  checks: ComplianceCheck[];
}

export interface ComplianceCheck {
  name: string;
  description: string;
  type: 'configuration' | 'access' | 'encryption' | 'audit';
  severity: 'high' | 'medium' | 'low';
  frequency: 'real-time' | 'hourly' | 'daily' | 'weekly';
  conditions: ComplianceCondition[];
}

export interface ComplianceCondition {
  field: string;
  operator: 'equals' | 'gt' | 'lt' | 'contains' | 'matches';
  value: any;
  required: boolean;
}

export interface ComplianceAudit {
  name: string;
  schedule: string;
  standards: string[];
  scope: AuditScope[];
  report: AuditReportConfig;
}

export interface AuditScope {
  component: string;
  data: string[];
  permissions: string[];
}

export interface AuditReportConfig {
  format: 'pdf' | 'html' | 'json';
  recipients: string[];
  include: string[];
}

export interface ComplianceReportingConfig {
  enabled: boolean;
  schedule: string;
  format: 'pdf' | 'json' | 'csv';
  recipients: string[];
  standards: string[];
}

// Environment-specific configurations
export const monitoringConfigs: Record<string, MonitoringConfig> = {
  dev: {
    environment: 'dev',
    enabled: true,
    metrics: {
      enabled: true,
      collection: {
        interval: 60,
        granularity: 'minute',
        metrics: [
          {
            name: 'backup_duration',
            type: 'timer',
            description: 'Backup operation duration',
            unit: 'seconds',
            tags: ['type', 'environment'],
            source: 'backup',
            collection: { method: 'event' }
          },
          {
            name: 'backup_size',
            type: 'gauge',
            description: 'Backup size in bytes',
            unit: 'bytes',
            tags: ['type', 'environment'],
            source: 'backup',
            collection: { method: 'event' }
          },
          {
            name: 'backup_success_rate',
            type: 'gauge',
            description: 'Successful backup rate',
            unit: 'percentage',
            tags: ['type', 'environment'],
            source: 'backup',
            collection: { method: 'polling', frequency: 300 }
          }
        ],
        custom: {
          enabled: false,
          expressions: [],
          windows: [
            { name: '1h', duration: 3600, granularity: '1m', retention: 7 },
            { name: '24h', duration: 86400, granularity: '5m', retention: 30 }
          ]
        }
      },
      aggregation: {
        enabled: true,
        functions: [
          { name: 'avg', metrics: ['backup_duration'], window: '1h' },
          { name: 'sum', metrics: ['backup_size'], window: '1h' }
        ],
        periods: [
          { name: 'hourly', interval: 3600, retention: 7 },
          { name: 'daily', interval: 86400, retention: 30 }
        ]
      },
      retention: {
        raw: 7,
        aggregated: 30,
        detailed: 14,
        archived: 90,
        cleanup: { enabled: true, schedule: '0 2 * * *', batchSize: 1000 }
      },
      publishing: {
        enabled: false,
        destinations: [],
        format: 'json',
        compression: false,
        authentication: { type: 'none' }
      }
    },
    dashboards: {
      enabled: false,
      provider: 'prometheus',
      refreshInterval: 30,
      layouts: [],
      access: { users: [], groups: [], permissions: ['view'] }
    },
    alerting: {
      enabled: false,
      channels: [],
      rules: [],
      escalation: { enabled: false, levels: [], repeat: { enabled: false, interval: 60, maxRepeats: 3 } },
      suppression: { enabled: false, rules: [] }
    },
    status: {
      enabled: true,
      tracking: { backupJobs: true, storage: true, network: false, application: true, system: false },
      history: { retention: 7, detail: 'summary', archive: { enabled: false, location: '' } },
      reporting: { enabled: false, schedule: '0 9 * * 1', recipients: [], format: 'json', include: { summary: true, details: false, trends: false, recommendations: false, attachments: false } }
    },
    healthChecks: {
      enabled: false,
      checks: [],
      schedule: '*/5 * * * *',
      timeout: 30,
      retries: 3,
      notification: { enabled: false, channels: [], failureThreshold: 3, recoveryThreshold: 2 }
    },
    logging: {
      enabled: true,
      level: 'debug',
      format: 'json',
      destinations: [
        { type: 'console', enabled: true, config: {}, filters: [] }
      ],
      retention: { enabled: true, period: 7, cleanup: { enabled: true, schedule: '0 2 * * *' } }
    },
    performance: {
      enabled: false,
      profiling: { enabled: false, interval: 60, duration: 30, memory: false, cpu: false, io: false },
      benchmarking: { enabled: false, schedule: '0 2 * * 0', tests: [], baseline: { enabled: false, environment: 'dev', history: 5 } },
      optimization: { enabled: false, recommendations: false, autoTuning: false, thresholds: [] }
    },
    compliance: {
      enabled: false,
      standards: [],
      audits: [],
      reporting: { enabled: false, schedule: '0 9 * * 1', format: 'json', recipients: [], standards: [] }
    }
  },

  staging: {
    environment: 'staging',
    enabled: true,
    metrics: {
      enabled: true,
      collection: {
        interval: 30,
        granularity: 'minute',
        metrics: [
          {
            name: 'backup_duration',
            type: 'timer',
            description: 'Backup operation duration',
            unit: 'seconds',
            tags: ['type', 'environment', 'status'],
            source: 'backup',
            collection: { method: 'event' }
          },
          {
            name: 'backup_size',
            type: 'gauge',
            description: 'Backup size in bytes',
            unit: 'bytes',
            tags: ['type', 'environment', 'compression'],
            source: 'backup',
            collection: { method: 'event' }
          },
          {
            name: 'backup_success_rate',
            type: 'gauge',
            description: 'Successful backup rate',
            unit: 'percentage',
            tags: ['type', 'environment'],
            source: 'backup',
            collection: { method: 'polling', frequency: 300 }
          },
          {
            name: 'storage_usage',
            type: 'gauge',
            description: 'Storage usage percentage',
            unit: 'percentage',
            tags: ['bucket', 'region'],
            source: 'storage',
            collection: { method: 'polling', frequency: 300 }
          }
        ],
        custom: {
          enabled: true,
          expressions: [
            { name: 'backup_efficiency', expression: 'backup_size / backup_duration', description: 'Backup efficiency metric', unit: 'bytes/second' }
          ],
          windows: [
            { name: '1h', duration: 3600, granularity: '1m', retention: 30 },
            { name: '24h', duration: 86400, granularity: '5m', retention: 90 }
          ]
        }
      },
      aggregation: {
        enabled: true,
        functions: [
          { name: 'avg', metrics: ['backup_duration'], window: '1h' },
          { name: 'sum', metrics: ['backup_size'], window: '1h' },
          { name: 'p95', metrics: ['backup_duration'], window: '1h' }
        ],
        periods: [
          { name: 'hourly', interval: 3600, retention: 30 },
          { name: 'daily', interval: 86400, retention: 90 }
        ]
      },
      retention: {
        raw: 30,
        aggregated: 90,
        detailed: 60,
        archived: 365,
        cleanup: { enabled: true, schedule: '0 2 * * *', batchSize: 2000 }
      },
      publishing: {
        enabled: true,
        destinations: [
          { name: 'prometheus', type: 'prometheus', endpoint: 'http://prometheus:9090', enabled: true, batchSize: 100, timeout: 10, retry: { enabled: true, maxAttempts: 3, backoff: 'exponential', initialDelay: 1000, maxDelay: 30000 } }
        ],
        format: 'prometheus',
        compression: true,
        authentication: { type: 'none' }
      }
    },
    dashboards: {
      enabled: true,
      provider: 'grafana',
      refreshInterval: 30,
      layouts: [
        {
          name: 'Staging Backup Overview',
          description: 'Main backup monitoring dashboard for staging',
          panels: [],
          variables: [],
          tags: ['backup', 'staging']
        }
      ],
      access: { users: ['staging-team@company.com'], groups: ['staging'], permissions: ['view', 'edit'] }
    },
    alerting: {
      enabled: true,
      channels: [
        {
          name: 'staging-alerts',
          type: 'email',
          enabled: true,
          config: { recipients: ['staging-team@company.com'], subject: '[STAGING] Backup Alert' },
          filters: []
        }
      ],
      rules: [
        {
          name: 'backup_failure_rate',
          description: 'High backup failure rate in staging',
          severity: 'warning',
          condition: { query: 'backup_success_rate < 90', reducer: 'avg', evaluator: 'lt', threshold: 90, timeRange: 10 },
          labels: { environment: 'staging', team: 'staging' },
          annotations: { summary: 'High backup failure rate detected' },
          for: 5,
          enabled: true
        }
      ],
      escalation: { enabled: true, levels: [{ delay: 30, channels: ['staging-alerts'], recipients: ['devops@company.com'], conditions: [] }], repeat: { enabled: true, interval: 60, maxRepeats: 3 } },
      suppression: { enabled: true, rules: [] }
    },
    status: {
      enabled: true,
      tracking: { backupJobs: true, storage: true, network: true, application: true, system: true },
      history: { retention: 30, detail: 'detailed', archive: { enabled: true, location: 's3://staging-monitoring-archive' } },
      reporting: { enabled: true, schedule: '0 9 * * 1', recipients: ['staging-team@company.com'], format: 'html', include: { summary: true, details: true, trends: true, recommendations: true, attachments: false } }
    },
    healthChecks: {
      enabled: true,
      checks: [
        {
          name: 'backup_service_health',
          type: 'backup',
          endpoint: 'http://backup-service/health',
          method: 'GET',
          expectedStatus: 200,
          timeout: 10,
          interval: 60,
          conditions: [{ field: 'status', operator: 'equals', value: 'healthy' }]
        }
      ],
      schedule: '*/5 * * * *',
      timeout: 30,
      retries: 3,
      notification: { enabled: true, channels: ['staging-alerts'], failureThreshold: 3, recoveryThreshold: 2 }
    },
    logging: {
      enabled: true,
      level: 'info',
      format: 'json',
      destinations: [
        { type: 'console', enabled: true, config: {}, filters: [] },
        { type: 'file', enabled: true, config: { path: './logs/staging-backup.log' }, filters: [] }
      ],
      retention: { enabled: true, period: 30, cleanup: { enabled: true, schedule: '0 2 * * *' } }
    },
    performance: {
      enabled: true,
      profiling: { enabled: false, interval: 300, duration: 60, memory: true, cpu: true, io: true },
      benchmarking: { enabled: true, schedule: '0 2 * * 0', tests: [{ name: 'backup_speed', type: 'backup-speed', parameters: { dataSize: '1GB' } }], baseline: { enabled: true, environment: 'staging', history: 10 } },
      optimization: { enabled: true, recommendations: true, autoTuning: false, thresholds: [{ metric: 'backup_duration', warning: 1800, critical: 3600, action: 'alert' }] }
    },
    compliance: {
      enabled: true,
      standards: [
        { name: 'FIPS-140-2', enabled: true, checks: [], }
      ],
      audits: [],
      reporting: { enabled: true, schedule: '0 9 * * 1', format: 'json', recipients: ['staging-compliance@company.com'], standards: ['FIPS-140-2'] }
    }
  },

  production: {
    environment: 'production',
    enabled: true,
    metrics: {
      enabled: true,
      collection: {
        interval: 10,
        granularity: 'raw',
        metrics: [
          {
            name: 'backup_duration',
            type: 'timer',
            description: 'Backup operation duration',
            unit: 'milliseconds',
            tags: ['type', 'environment', 'status', 'priority'],
            source: 'backup',
            collection: { method: 'event' }
          },
          {
            name: 'backup_size',
            type: 'gauge',
            description: 'Backup size in bytes',
            unit: 'bytes',
            tags: ['type', 'environment', 'compression', 'encryption'],
            source: 'backup',
            collection: { method: 'event' }
          },
          {
            name: 'backup_success_rate',
            type: 'gauge',
            description: 'Successful backup rate',
            unit: 'percentage',
            tags: ['type', 'environment', 'region'],
            source: 'backup',
            collection: { method: 'polling', frequency: 60 }
          },
          {
            name: 'storage_usage',
            type: 'gauge',
            description: 'Storage usage percentage',
            unit: 'percentage',
            tags: ['bucket', 'region', 'tier'],
            source: 'storage',
            collection: { method: 'polling', frequency: 60 }
          },
          {
            name: 'network_latency',
            type: 'histogram',
            description: 'Network latency for backup operations',
            unit: 'milliseconds',
            tags: ['region', 'destination'],
            source: 'network',
            collection: { method: 'event' }
          },
          {
            name: 'backup_throughput',
            type: 'gauge',
            description: 'Backup throughput',
            unit: 'bytes/second',
            tags: ['type', 'region'],
            source: 'backup',
            collection: { method: 'event' }
          }
        ],
        custom: {
          enabled: true,
          expressions: [
            { name: 'backup_efficiency', expression: 'backup_size / backup_duration', description: 'Backup efficiency metric', unit: 'bytes/second' },
            { name: 'compression_ratio', expression: 'backup_size / original_size', description: 'Compression ratio', unit: 'ratio' },
            { name: 'cost_per_gb', expression: 'storage_cost / backup_size', description: 'Cost per GB backed up', unit: 'currency/gb' }
          ],
          windows: [
            { name: '15m', duration: 900, granularity: '30s', retention: 90 },
            { name: '1h', duration: 3600, granularity: '1m', retention: 180 },
            { name: '24h', duration: 86400, granularity: '5m', retention: 365 }
          ]
        }
      },
      aggregation: {
        enabled: true,
        functions: [
          { name: 'avg', metrics: ['backup_duration'], window: '15m' },
          { name: 'p95', metrics: ['backup_duration'], window: '15m' },
          { name: 'p99', metrics: ['backup_duration'], window: '1h' },
          { name: 'sum', metrics: ['backup_size'], window: '1h' }
        ],
        periods: [
          { name: '15min', interval: 900, retention: 90 },
          { name: 'hourly', interval: 3600, retention: 180 },
          { name: 'daily', interval: 86400, retention: 365 }
        ]
      },
      retention: {
        raw: 90,
        aggregated: 365,
        detailed: 180,
        archived: 2555,
        cleanup: { enabled: true, schedule: '0 2 * * *', batchSize: 5000 }
      },
      publishing: {
        enabled: true,
        destinations: [
          { name: 'datadog', type: 'datadog', endpoint: 'https://api.datadoghq.com', enabled: true, batchSize: 500, timeout: 30, retry: { enabled: true, maxAttempts: 5, backoff: 'exponential', initialDelay: 1000, maxDelay: 60000 } },
          { name: 'cloudwatch', type: 'cloudwatch', endpoint: 'https://cloudwatch.amazonaws.com', enabled: true, batchSize: 1000, timeout: 30, retry: { enabled: true, maxAttempts: 3, backoff: 'exponential', initialDelay: 2000, maxDelay: 30000 } }
        ],
        format: 'datadog',
        compression: true,
        authentication: { type: 'api-key', credentials: { apiKey: process.env.DATADOG_API_KEY } }
      }
    },
    dashboards: {
      enabled: true,
      provider: 'datadog',
      refreshInterval: 10,
      layouts: [
        {
          name: 'Production Backup Operations',
          description: 'Comprehensive backup monitoring dashboard',
          panels: [],
          variables: [],
          tags: ['backup', 'production', 'critical']
        },
        {
          name: 'Storage and Performance',
          description: 'Storage usage and performance metrics',
          panels: [],
          variables: [],
          tags: ['storage', 'performance', 'production']
        },
        {
          name: 'Compliance and Security',
          description: 'Compliance metrics and security monitoring',
          panels: [],
          variables: [],
          tags: ['compliance', 'security', 'production']
        }
      ],
      access: { users: ['ops-team@company.com', 'devops@company.com'], groups: ['operations', 'devops'], permissions: ['view', 'edit', 'admin'] }
    },
    alerting: {
      enabled: true,
      channels: [
        {
          name: 'pagerduty',
          type: 'pagerduty',
          enabled: true,
          config: { serviceId: process.env.PAGERDUTY_SERVICE_ID, integrationKey: process.env.PAGERDUTY_INTEGRATION_KEY },
          filters: []
        },
        {
          name: 'slack-ops',
          type: 'slack',
          enabled: true,
          config: { webhook: process.env.SLACK_WEBHOOK_URL, channel: '#ops-alerts' },
          filters: []
        },
        {
          name: 'email-management',
          type: 'email',
          enabled: true,
          config: { recipients: ['management@company.com'], subject: '[PRODUCTION] Critical Backup Alert' },
          filters: []
        }
      ],
      rules: [
        {
          name: 'backup_failure_critical',
          description: 'Critical backup failure rate in production',
          severity: 'critical',
          condition: { query: 'backup_success_rate < 95', reducer: 'avg', evaluator: 'lt', threshold: 95, timeRange: 5 },
          labels: { environment: 'production', severity: 'critical', team: 'operations' },
          annotations: { summary: 'Critical backup failure rate detected', description: 'Backup success rate below 95% threshold' },
          for: 2,
          enabled: true
        },
        {
          name: 'storage_usage_warning',
          description: 'High storage usage warning',
          severity: 'warning',
          condition: { query: 'storage_usage > 75', reducer: 'avg', evaluator: 'gt', threshold: 75, timeRange: 15 },
          labels: { environment: 'production', severity: 'warning' },
          annotations: { summary: 'Storage usage above 75%' },
          for: 10,
          enabled: true
        },
        {
          name: 'backup_duration_critical',
          description: 'Backup duration exceeds critical threshold',
          severity: 'critical',
          condition: { query: 'backup_duration > 7200', reducer: 'avg', evaluator: 'gt', threshold: 7200, timeRange: 10 },
          labels: { environment: 'production', severity: 'critical' },
          annotations: { summary: 'Backup duration exceeds 2 hours' },
          for: 5,
          enabled: true
        }
      ],
      escalation: {
        enabled: true,
        levels: [
          { delay: 5, channels: ['slack-ops'], recipients: ['oncall@company.com'], conditions: [] },
          { delay: 15, channels: ['pagerduty'], recipients: ['primary-oncall@company.com'], conditions: [] },
          { delay: 30, channels: ['email-management'], recipients: ['management@company.com'], conditions: [] }
        ],
        repeat: { enabled: true, interval: 60, maxRepeats: 10 }
      },
      suppression: {
        enabled: true,
        rules: [
          { name: 'maintenance_window', condition: { query: 'maintenance_mode = true', reducer: 'avg', evaluator: 'eq', threshold: 1, timeRange: 1 }, duration: 1440, description: 'Suppressed during maintenance windows' }
        ]
      }
    },
    status: {
      enabled: true,
      tracking: { backupJobs: true, storage: true, network: true, application: true, system: true },
      history: { retention: 2555, detail: 'verbose', archive: { enabled: true, location: 's3://production-monitoring-archive' } },
      reporting: { enabled: true, schedule: '0 6 * * *', recipients: ['operations@company.com', 'management@company.com'], format: 'pdf', include: { summary: true, details: true, trends: true, recommendations: true, attachments: true } }
    },
    healthChecks: {
      enabled: true,
      checks: [
        {
          name: 'backup_service_health',
          type: 'backup',
          endpoint: 'http://backup-service/health',
          method: 'GET',
          expectedStatus: 200,
          timeout: 5,
          interval: 60,
          conditions: [{ field: 'status', operator: 'equals', value: 'healthy' }]
        },
        {
          name: 'storage_connectivity',
          type: 'storage',
          endpoint: 'http://backup-service/storage/ping',
          method: 'GET',
          expectedStatus: 200,
          timeout: 10,
          interval: 120,
          conditions: [{ field: 'latency', operator: 'lt', value: 1000 }]
        },
        {
          name: 'encryption_service',
          type: 'application',
          endpoint: 'http://backup-service/encryption/health',
          method: 'GET',
          expectedStatus: 200,
          timeout: 5,
          interval: 180,
          conditions: [{ field: 'key_rotation_status', operator: 'equals', value: 'healthy' }]
        }
      ],
      schedule: '*/2 * * * *',
      timeout: 30,
      retries: 5,
      notification: { enabled: true, channels: ['pagerduty', 'slack-ops'], failureThreshold: 2, recoveryThreshold: 2 }
    },
    logging: {
      enabled: true,
      level: 'info',
      format: 'json',
      destinations: [
        { type: 'console', enabled: false, config: {}, filters: [] },
        { type: 'elasticsearch', enabled: true, config: { endpoint: process.env.ELASTICSEARCH_ENDPOINT }, filters: [] },
        { type: 'cloudwatch', enabled: true, config: { logGroup: 'production-backup-logs' }, filters: [] }
      ],
      retention: { enabled: true, period: 2555, cleanup: { enabled: true, schedule: '0 2 * * *' } }
    },
    performance: {
      enabled: true,
      profiling: { enabled: true, interval: 300, duration: 120, memory: true, cpu: true, io: true },
      benchmarking: { enabled: true, schedule: '0 2 * * 0', tests: [{ name: 'backup_speed', type: 'backup-speed', parameters: { dataSize: '10GB' } }, { name: 'encryption_benchmark', type: 'encryption', parameters: { algorithm: 'aes-256-gcm' } }], baseline: { enabled: true, environment: 'production', history: 50 } },
      optimization: { enabled: true, recommendations: true, autoTuning: true, thresholds: [{ metric: 'backup_duration', warning: 1800, critical: 3600, action: 'optimize' }, { metric: 'storage_usage', warning: 70, critical: 85, action: 'alert' }, { metric: 'backup_success_rate', warning: 98, critical: 95, action: 'alert' }] }
    },
    compliance: {
      enabled: true,
      standards: [
        { name: 'FIPS-140-2', enabled: true, checks: [] },
        { name: 'PCI-DSS', enabled: true, checks: [] },
        { name: 'GDPR', enabled: true, checks: [] },
        { name: 'HIPAA', enabled: true, checks: [] },
        { name: 'SOX', enabled: true, checks: [] },
        { name: 'ISO-27001', enabled: true, checks: [] }
      ],
      audits: [
        { name: 'monthly_compliance_audit', schedule: '0 2 1 * *', standards: ['FIPS-140-2', 'PCI-DSS'], scope: [], report: { format: 'pdf', recipients: ['compliance@company.com'], include: ['summary', 'findings', 'recommendations'] } }
      ],
      reporting: { enabled: true, schedule: '0 9 * * 1', format: 'pdf', recipients: ['compliance@company.com', 'security@company.com'], standards: ['FIPS-140-2', 'PCI-DSS', 'GDPR', 'HIPAA', 'SOX', 'ISO-27001'] }
    }
  }
};

// Utility functions
export function getMonitoringConfig(environment: string): MonitoringConfig {
  const config = monitoringConfigs[environment];
  if (!config) {
    throw new Error(`No monitoring configuration found for environment: ${environment}`);
  }
  return config;
}

export function getCurrentMonitoringConfig(): MonitoringConfig {
  const environment = process.env.NODE_ENV || 'development';
  return getMonitoringConfig(environment);
}

export function isMonitoringEnabled(environment: string): boolean {
  const config = getMonitoringConfig(environment);
  return config.enabled;
}

export function getMetricsInterval(environment: string): number {
  const config = getMonitoringConfig(environment);
  return config.metrics.collection.interval;
}

export function validateMonitoringConfig(config: MonitoringConfig): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Validate metrics configuration
  if (config.metrics.enabled) {
    if (config.metrics.collection.interval < 1) {
      errors.push('Metrics collection interval must be at least 1 second');
    }
    if (config.metrics.collection.metrics.length === 0) {
      warnings.push('No metrics defined for collection');
    }
  }

  // Validate alerting configuration
  if (config.alerting.enabled && config.alerting.channels.length === 0) {
    warnings.push('Alerting enabled but no channels configured');
  }

  // Validate health checks
  if (config.healthChecks.enabled) {
    config.healthChecks.checks.forEach((check, index) => {
      if (!check.endpoint) {
        errors.push(`Health check ${index + 1} missing endpoint`);
      }
    });
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings
  };
}

export interface ValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

export default monitoringConfigs;