/**
 * Backup Encryption Configuration
 * Secure backup handling with encryption at rest and in transit
 */

export interface EncryptionConfig {
  enabled: boolean;
  algorithm: EncryptionAlgorithm;
  keyManagement: KeyManagementConfig;
  transport: TransportEncryptionConfig;
  performance: PerformanceConfig;
  compliance: ComplianceConfig;
  environment: string;
}

export type EncryptionAlgorithm = 'aes-256-gcm' | 'aes-256-cbc' | 'chacha20-poly1305' | 'aes-256-xts';

export interface KeyManagementConfig {
  provider: 'aws-kms' | 'hashicorp-vault' | 'azure-keyvault' | 'gcp-kms' | 'local';
  masterKey: string;
  keyRotation: KeyRotationConfig;
  keyDerivation: KeyDerivationConfig;
  keyStorage: KeyStorageConfig;
}

export interface KeyRotationConfig {
  enabled: boolean;
  interval: number; // days
  overlap: number; // days to keep old keys active
  automatic: boolean;
  notification: boolean;
  conditions: RotationCondition[];
}

export interface RotationCondition {
  type: 'time' | 'usage' | 'security' | 'breach';
  threshold: number;
  action: 'rotate' | 'alert' | 'both';
}

export interface KeyDerivationConfig {
  method: 'pbkdf2' | 'scrypt' | 'argon2' | 'hkdf';
  iterations: number;
  memory: number; // MB for memory-hard functions
  parallelism: number;
  saltLength: number;
}

export interface KeyStorageConfig {
  location: string;
  accessControl: AccessControlConfig;
  backup: boolean;
  audit: boolean;
  expiration?: number; // days
}

export interface AccessControlConfig {
  principal: string;
  permissions: string[];
  conditions?: Record<string, any>;
  mfaRequired: boolean;
}

export interface TransportEncryptionConfig {
  enabled: boolean;
  protocol: 'tls-1.2' | 'tls-1.3';
  certificate: CertificateConfig;
  cipherSuites: string[];
  verification: VerificationConfig;
  performance: TransportPerformanceConfig;
}

export interface CertificateConfig {
  source: 'provided' | 'auto-generated' | 'managed';
  path?: string;
  rotation: {
    enabled: boolean;
    interval: number; // days
    automatic: boolean;
  };
  validation: {
    enabled: boolean;
    methods: ('hostname' | 'fingerprint' | 'pkix')[];
  };
}

export interface VerificationConfig {
  enabled: boolean;
  strict: boolean;
  allowSelfSigned: boolean;
  pinCerts: boolean;
  revocation: {
    enabled: boolean;
    method: 'ocsp' | 'crl';
  };
}

export interface TransportPerformanceConfig {
  sessionResumption: boolean;
  compression: boolean;
  buffering: boolean;
  pipeline: boolean;
}

export interface PerformanceConfig {
  hardwareAcceleration: boolean;
  threads: number;
  batchSize: number;
  memoryLimit: number; // MB
  parallel: ParallelEncryptionConfig;
  optimization: EncryptionOptimizationConfig;
}

export interface ParallelEncryptionConfig {
  enabled: boolean;
  workers: number;
  chunkSize: number; // MB
  queueSize: number;
  backpressure: boolean;
}

export interface EncryptionOptimizationConfig {
  streaming: boolean;
  compressBeforeEncrypt: boolean;
  deltaEncryption: boolean;
  deduplication: boolean;
  adaptiveChunking: boolean;
}

export interface ComplianceConfig {
  standards: ComplianceStandard[];
  keyRetention: number; // days
  audit: AuditConfig;
  reporting: ReportingConfig;
}

export interface ComplianceStandard {
  name: 'FIPS-140-2' | 'PCI-DSS' | 'GDPR' | 'HIPAA' | 'SOX' | 'ISO-27001';
  level?: string;
  required: boolean;
  implementation: string[];
}

export interface AuditConfig {
  enabled: boolean;
  events: AuditEvent[];
  retention: number; // days
  integration: AuditIntegrationConfig;
}

export interface AuditEvent {
  type: 'key-generation' | 'key-rotation' | 'encryption' | 'decryption' | 'access' | 'failure';
  fields: string[];
  sensitive: boolean;
}

export interface AuditIntegrationConfig {
  provider: 'cloudwatch' | 'splunk' | 'elastic' | 'datadog';
  endpoint: string;
  authentication: Record<string, any>;
}

export interface ReportingConfig {
  enabled: boolean;
  schedule: string;
  recipients: string[];
  format: 'json' | 'csv' | 'pdf';
  includeMetrics: boolean;
  includeCompliance: boolean;
}

// Environment-specific configurations
export const encryptionConfigs: Record<string, EncryptionConfig> = {
  dev: {
    environment: 'dev',
    enabled: false,
    algorithm: 'aes-256-gcm',
    keyManagement: {
      provider: 'local',
      masterKey: process.env.DEV_ENCRYPTION_KEY || 'dev-master-key-32-chars-minimum!!',
      keyRotation: {
        enabled: false,
        interval: 30,
        overlap: 7,
        automatic: false,
        notification: false,
        conditions: []
      },
      keyDerivation: {
        method: 'pbkdf2',
        iterations: 1000,
        memory: 4,
        parallelism: 1,
        saltLength: 16
      },
      keyStorage: {
        location: './config/keys/dev',
        accessControl: {
          principal: 'dev-user',
          permissions: ['read', 'write']
        },
        backup: false,
        audit: false
      }
    },
    transport: {
      enabled: false,
      protocol: 'tls-1.2',
      certificate: {
        source: 'auto-generated',
        rotation: { enabled: false, interval: 90, automatic: false },
        validation: { enabled: false, methods: ['hostname'] }
      },
      cipherSuites: ['TLS_AES_256_GCM_SHA384', 'TLS_CHACHA20_POLY1305_SHA256'],
      verification: {
        enabled: false,
        strict: false,
        allowSelfSigned: true,
        pinCerts: false,
        revocation: { enabled: false, method: 'ocsp' }
      },
      performance: {
        sessionResumption: false,
        compression: false,
        buffering: false,
        pipeline: false
      }
    },
    performance: {
      hardwareAcceleration: false,
      threads: 1,
      batchSize: 64, // MB
      memoryLimit: 256, // MB
      parallel: {
        enabled: false,
        workers: 1,
        chunkSize: 1, // MB
        queueSize: 10,
        backpressure: false
      },
      optimization: {
        streaming: false,
        compressBeforeEncrypt: false,
        deltaEncryption: false,
        deduplication: false,
        adaptiveChunking: false
      }
    },
    compliance: {
      standards: [],
      keyRetention: 30,
      audit: {
        enabled: false,
        events: [],
        retention: 30,
        integration: {
          provider: 'cloudwatch',
          endpoint: '',
          authentication: {}
        }
      },
      reporting: {
        enabled: false,
        schedule: '0 9 * * 1',
        recipients: [],
        format: 'json',
        includeMetrics: false,
        includeCompliance: false
      }
    }
  },

  staging: {
    environment: 'staging',
    enabled: true,
    algorithm: 'aes-256-gcm',
    keyManagement: {
      provider: 'aws-kms',
      masterKey: process.env.STAGING_KMS_KEY_ID || 'arn:aws:kms:us-east-1:123456789012:key/staging-master-key',
      keyRotation: {
        enabled: true,
        interval: 90,
        overlap: 14,
        automatic: true,
        notification: true,
        conditions: [
          { type: 'usage', threshold: 10000, action: 'rotate' },
          { type: 'security', threshold: 1, action: 'alert' }
        ]
      },
      keyDerivation: {
        method: 'pbkdf2',
        iterations: 100000,
        memory: 16,
        parallelism: 4,
        saltLength: 32
      },
      keyStorage: {
        location: 's3://staging-encryption-keys',
        accessControl: {
          principal: 'arn:aws:iam::123456789012:role/staging-backup-service',
          permissions: ['kms:Encrypt', 'kms:Decrypt', 'kms:GenerateDataKey']
        },
        backup: true,
        audit: true
      }
    },
    transport: {
      enabled: true,
      protocol: 'tls-1.3',
      certificate: {
        source: 'managed',
        rotation: { enabled: true, interval: 90, automatic: true },
        validation: { enabled: true, methods: ['hostname', 'fingerprint'] }
      },
      cipherSuites: ['TLS_AES_256_GCM_SHA384', 'TLS_CHACHA20_POLY1305_SHA256'],
      verification: {
        enabled: true,
        strict: true,
        allowSelfSigned: false,
        pinCerts: true,
        revocation: { enabled: true, method: 'ocsp' }
      },
      performance: {
        sessionResumption: true,
        compression: true,
        buffering: true,
        pipeline: true
      }
    },
    performance: {
      hardwareAcceleration: true,
      threads: 4,
      batchSize: 128, // MB
      memoryLimit: 1024, // MB
      parallel: {
        enabled: true,
        workers: 4,
        chunkSize: 4, // MB
        queueSize: 50,
        backpressure: true
      },
      optimization: {
        streaming: true,
        compressBeforeEncrypt: true,
        deltaEncryption: true,
        deduplication: true,
        adaptiveChunking: true
      }
    },
    compliance: {
      standards: ['FIPS-140-2'],
      keyRetention: 365,
      audit: {
        enabled: true,
        events: [
          { type: 'key-generation', fields: ['keyId', 'timestamp', 'user'], sensitive: false },
          { type: 'key-rotation', fields: ['keyId', 'timestamp', 'reason'], sensitive: false },
          { type: 'encryption', fields: ['keyId', 'timestamp', 'size'], sensitive: false },
          { type: 'decryption', fields: ['keyId', 'timestamp', 'size'], sensitive: false }
        ],
        retention: 365,
        integration: {
          provider: 'cloudwatch',
          endpoint: 'https://logs.us-east-1.amazonaws.com',
          authentication: {
            accessKeyId: process.env.AWS_ACCESS_KEY_ID,
            secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
          }
        }
      },
      reporting: {
        enabled: true,
        schedule: '0 9 * * 1',
        recipients: ['staging-security@company.com'],
        format: 'json',
        includeMetrics: true,
        includeCompliance: true
      }
    }
  },

  production: {
    environment: 'production',
    enabled: true,
    algorithm: 'aes-256-gcm',
    keyManagement: {
      provider: 'aws-kms',
      masterKey: process.env.PRODUCTION_KMS_KEY_ID || 'arn:aws:kms:us-east-1:123456789012:key/production-master-key',
      keyRotation: {
        enabled: true,
        interval: 30,
        overlap: 7,
        automatic: true,
        notification: true,
        conditions: [
          { type: 'usage', threshold: 5000, action: 'rotate' },
          { type: 'security', threshold: 1, action: 'both' },
          { type: 'time', threshold: 30, action: 'rotate' }
        ]
      },
      keyDerivation: {
        method: 'argon2',
        iterations: 3,
        memory: 64, // MB
        parallelism: 8,
        saltLength: 32
      },
      keyStorage: {
        location: 's3://production-encryption-keys',
        accessControl: {
          principal: 'arn:aws:iam::123456789012:role/production-backup-service',
          permissions: ['kms:Encrypt', 'kms:Decrypt', 'kms:GenerateDataKey', 'kms:GenerateRandom']
        },
        backup: true,
        audit: true,
        expiration: 2555 // 7 years
      }
    },
    transport: {
      enabled: true,
      protocol: 'tls-1.3',
      certificate: {
        source: 'managed',
        rotation: { enabled: true, interval: 30, automatic: true },
        validation: { enabled: true, methods: ['hostname', 'fingerprint', 'pkix'] }
      },
      cipherSuites: ['TLS_AES_256_GCM_SHA384'],
      verification: {
        enabled: true,
        strict: true,
        allowSelfSigned: false,
        pinCerts: true,
        revocation: { enabled: true, method: 'ocsp' }
      },
      performance: {
        sessionResumption: true,
        compression: true,
        buffering: true,
        pipeline: true
      }
    },
    performance: {
      hardwareAcceleration: true,
      threads: 16,
      batchSize: 256, // MB
      memoryLimit: 4096, // MB
      parallel: {
        enabled: true,
        workers: 16,
        chunkSize: 8, // MB
        queueSize: 100,
        backpressure: true
      },
      optimization: {
        streaming: true,
        compressBeforeEncrypt: true,
        deltaEncryption: true,
        deduplication: true,
        adaptiveChunking: true
      }
    },
    compliance: {
      standards: ['FIPS-140-2', 'PCI-DSS', 'GDPR', 'HIPAA'],
      keyRetention: 2555, // 7 years
      audit: {
        enabled: true,
        events: [
          { type: 'key-generation', fields: ['keyId', 'timestamp', 'user', 'sourceIp'], sensitive: false },
          { type: 'key-rotation', fields: ['keyId', 'timestamp', 'reason', 'initiator'], sensitive: false },
          { type: 'encryption', fields: ['keyId', 'timestamp', 'size', 'destination'], sensitive: false },
          { type: 'decryption', fields: ['keyId', 'timestamp', 'size', 'requester'], sensitive: false },
          { type: 'access', fields: ['keyId', 'timestamp', 'principal', 'operation'], sensitive: true },
          { type: 'failure', fields: ['keyId', 'timestamp', 'error', 'sourceIp'], sensitive: false }
        ],
        retention: 2555,
        integration: {
          provider: 'splunk',
          endpoint: process.env.SPLUNK_ENDPOINT || 'https://splunk.company.com:8088',
          authentication: {
            token: process.env.SPLUNK_TOKEN
          }
        }
      },
      reporting: {
        enabled: true,
        schedule: '0 6 * * *',
        recipients: ['security-team@company.com', 'compliance@company.com'],
        format: 'pdf',
        includeMetrics: true,
        includeCompliance: true
      }
    }
  }
};

// Utility functions
export function getEncryptionConfig(environment: string): EncryptionConfig {
  const config = encryptionConfigs[environment];
  if (!config) {
    throw new Error(`No encryption configuration found for environment: ${environment}`);
  }
  return config;
}

export function getCurrentEncryptionConfig(): EncryptionConfig {
  const environment = process.env.NODE_ENV || 'development';
  return getEncryptionConfig(environment);
}

export function isEncryptionRequired(environment: string): boolean {
  const config = getEncryptionConfig(environment);
  return config.enabled;
}

export function getEncryptionAlgorithm(environment: string): EncryptionAlgorithm {
  const config = getEncryptionConfig(environment);
  return config.algorithm;
}

export function validateEncryptionConfig(config: EncryptionConfig): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Validate algorithm
  if (!config.algorithm) {
    errors.push('Encryption algorithm is required');
  }

  // Validate key management
  if (config.enabled && config.keyManagement.provider === 'local') {
    if (!config.keyManagement.masterKey || config.keyManagement.masterKey.length < 32) {
      errors.push('Master key must be at least 32 characters for local key management');
    }
  }

  // Validate performance settings
  if (config.enabled) {
    if (config.performance.threads < 1) {
      errors.push('Thread count must be at least 1');
    }
    if (config.performance.batchSize < 1) {
      errors.push('Batch size must be at least 1 MB');
    }
    if (config.performance.memoryLimit < 64) {
      warnings.push('Memory limit less than 64MB may impact performance');
    }
  }

  // Validate transport encryption for production
  if (config.environment === 'production' && !config.transport.enabled) {
    errors.push('Transport encryption must be enabled in production');
  }

  // Validate compliance for production
  if (config.environment === 'production') {
    if (!config.compliance.standards.includes('FIPS-140-2')) {
      warnings.push('FIPS-140-2 compliance recommended for production');
    }
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings
  };
}

export interface ValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

export function generateKeyDerivationSalt(): Buffer {
  return crypto.getRandomValues(new Uint8Array(32));
}

export function deriveKey(
  password: string,
  salt: Buffer,
  iterations: number = 100000
): Promise<Buffer> {
  return crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(password),
    'PBKDF2',
    false,
    ['deriveBits', 'deriveKey']
  ).then(baseKey =>
    crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: salt,
        iterations: iterations,
        hash: 'SHA-256'
      },
      baseKey,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    }
  );
}

// Backwards compatibility exports
export const defaultConfig = encryptionConfigs.dev;

export default encryptionConfigs;