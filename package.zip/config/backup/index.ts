/**
 * Backup Configuration Index
 * Central export point for all backup-related configurations
 */

export { 
  BackupConfig, 
  BackupSchedule, 
  StorageConfig, 
  RetentionConfig, 
  EncryptionConfig, 
  MonitoringConfig, 
  AlertConfig,
  getBackupConfig, 
  getCurrentBackupConfig, 
  validateBackupConfig,
  backupConfigs as defaultBackupConfigs
} from './backup.config';

export {
  RetentionRule,
  RetentionMatch,
  RetentionPeriod,
  RetentionCondition,
  RetentionSchedule,
  ArchiveConfig,
  CleanupConfig,
  getRetentionPolicies,
  getRetentionSchedule,
  getAllRetentionSchedules,
  getArchiveConfig,
  getCleanupConfig,
  evaluateRetentionRule,
  calculateRetentionPeriod,
  shouldArchive,
  shouldDelete,
  retentionPolicies as defaultRetentionPolicies,
  retentionSchedules as defaultRetentionSchedules,
  archiveConfigs as defaultArchiveConfigs,
  cleanupConfigs as defaultCleanupConfigs
} from './retention-policies';

export {
  EncryptionConfig as EncryptionSettings,
  KeyManagementConfig,
  KeyRotationConfig,
  KeyDerivationConfig,
  KeyStorageConfig,
  TransportEncryptionConfig,
  CertificateConfig,
  VerificationConfig,
  PerformanceConfig,
  ParallelEncryptionConfig,
  EncryptionOptimizationConfig,
  ComplianceConfig,
  ComplianceStandard,
  AuditConfig,
  AuditEvent,
  AuditIntegrationConfig,
  ReportingConfig,
  ValidationResult as EncryptionValidationResult,
  getEncryptionConfig,
  getCurrentEncryptionConfig,
  isEncryptionRequired,
  getEncryptionAlgorithm,
  validateEncryptionConfig,
  generateKeyDerivationSalt,
  deriveKey,
  encryptionConfigs as defaultEncryptionConfigs
} from './backup-encryption';

export {
  MonitoringConfig as MonitoringSettings,
  MetricsConfig,
  MetricsCollectionConfig,
  MetricDefinition,
  CollectionStrategy,
  CustomMetricConfig,
  MetricExpression,
  TimeWindow,
  MetricsAggregationConfig,
  AggregationFunction,
  AggregationPeriod,
  MetricsRetentionConfig,
  MetricsPublishingConfig,
  PublishingDestination,
  RetryConfig,
  PublishingAuthConfig,
  DashboardsConfig,
  DashboardLayout,
  DashboardPanel,
  PanelVisualizationConfig,
  LegendConfig,
  AxesConfig,
  ThresholdConfig,
  PanelPosition,
  PanelAlertConfig,
  AlertCondition,
  DashboardVariable,
  VariableOption,
  DashboardAccessConfig,
  AlertingConfig as MonitoringAlertingConfig,
  AlertChannelConfig as MonitoringAlertChannelConfig,
  AlertFilter as MonitoringAlertFilter,
  AlertRuleConfig as MonitoringAlertRuleConfig,
  EscalationConfig as MonitoringEscalationConfig,
  EscalationLevelConfig,
  EscalationCondition,
  RepeatConfig,
  SuppressionConfig as MonitoringSuppressionConfig,
  SuppressionRule as MonitoringSuppressionRule,
  StatusTrackingConfig,
  StatusTrackingMethod,
  HistoryConfig,
  StatusReportingConfig,
  ReportIncludeConfig,
  HealthCheckConfig,
  HealthCheckDefinition,
  HealthCondition,
  HealthNotificationConfig,
  LoggingConfig,
  LogDestination,
  LogFilter,
  LogRetentionConfig,
  PerformanceMonitoringConfig,
  ProfilingConfig,
  BenchmarkingConfig,
  BenchmarkTest,
  BenchmarkBaselineConfig,
  OptimizationConfig,
  OptimizationThreshold,
  ComplianceMonitoringConfig,
  ComplianceStandard as MonitoringComplianceStandard,
  ComplianceCheck,
  ComplianceCondition,
  ComplianceAudit,
  AuditScope,
  AuditReportConfig,
  ComplianceReportingConfig,
  ValidationResult as MonitoringValidationResult,
  getMonitoringConfig,
  getCurrentMonitoringConfig,
  isMonitoringEnabled,
  getMetricsInterval,
  validateMonitoringConfig,
  monitoringConfigs as defaultMonitoringConfigs
} from './backup-monitoring';

export {
  AlertConfig as AlertSettings,
  GlobalAlertConfig,
  RateLimitingConfig,
  BatchingConfig,
  QuietHoursConfig,
  AlertChannelConfig,
  ChannelConfig,
  AlertFilter,
  ChannelScheduling,
  ScheduleOverride,
  ChannelAuthentication,
  AlertRuleConfig,
  AlertCondition,
  AlertTemplateConfig,
  TemplateField,
  TemplateFormatting,
  AlertEscalationConfig,
  EscalationLevel,
  EscalationRecipient,
  EscalationCondition,
  ResolutionCondition,
  AlertSuppressionConfig,
  SuppressionRule,
  SuppressionMatch,
  AlertNotificationConfig,
  NotificationTemplate,
  TemplateVariable,
  LocalizationConfig,
  NotificationFormatting,
  NotificationDelivery,
  DeliveryRetryConfig,
  NotificationTracking,
  NotificationEvent,
  TrackingStorageConfig,
  ComplianceAlertConfig,
  ComplianceStandardAlert,
  ComplianceAlertRule,
  ComplianceAuditAlert,
  AuditScopeConfig,
  ComplianceReportingAlert,
  ValidationResult as AlertValidationResult,
  getAlertConfig,
  getCurrentAlertConfig,
  isAlertingEnabled,
  getAlertChannels,
  getAlertRules,
  evaluateAlertCondition,
  shouldSuppressAlert,
  validateAlertConfig,
  alertConfigs as defaultAlertConfigs
} from './backup-alerts';

// Combined configuration factory
export interface BackupSystemConfig {
  environment: string;
  backup: import('./backup.config').BackupConfig;
  retention: {
    policies: import('./retention-policies').RetentionRule[];
    schedules: import('./retention-policies').RetentionSchedule[];
    archive: import('./retention-policies').ArchiveConfig;
    cleanup: import('./retention-policies').CleanupConfig;
  };
  encryption: import('./backup-encryption').EncryptionConfig;
  monitoring: import('./backup-monitoring').MonitoringConfig;
  alerting: import('./backup-alerts').AlertConfig;
}

export function createBackupSystemConfig(environment: string): BackupSystemConfig {
  const backup = getBackupConfig(environment);
  const retentionPolicies = getRetentionPolicies(environment);
  const retentionSchedules = getAllRetentionSchedules(environment);
  const archive = getArchiveConfig(environment);
  const cleanup = getCleanupConfig(environment);
  const encryption = getEncryptionConfig(environment);
  const monitoring = getMonitoringConfig(environment);
  const alerting = getAlertConfig(environment);

  return {
    environment,
    backup,
    retention: {
      policies: retentionPolicies,
      schedules: retentionSchedules,
      archive,
      cleanup
    },
    encryption,
    monitoring,
    alerting
  };
}

export function getCurrentBackupSystemConfig(): BackupSystemConfig {
  const environment = process.env.NODE_ENV || 'development';
  return createBackupSystemConfig(environment);
}

// Validation utility for the entire system
export interface BackupSystemValidation {
  backup: {
    valid: boolean;
    errors: string[];
    warnings: string[];
  };
  retention: {
    valid: boolean;
    errors: string[];
    warnings: string[];
  };
  encryption: {
    valid: boolean;
    errors: string[];
    warnings: string[];
  };
  monitoring: {
    valid: boolean;
    errors: string[];
    warnings: string[];
  };
  alerting: {
    valid: boolean;
    errors: string[];
    warnings: string[];
  };
  overall: boolean;
}

export function validateBackupSystemConfig(config: BackupSystemConfig): BackupSystemValidation {
  const backupValidation = validateBackupConfig(config.backup);
  const encryptionValidation = validateEncryptionConfig(config.encryption);
  const monitoringValidation = validateMonitoringConfig(config.monitoring);
  const alertingValidation = validateAlertConfig(config.alerting);
  
  // Additional retention validation
  const retentionValidation = {
    valid: config.retention.policies.length > 0,
    errors: [] as string[],
    warnings: [] as string[]
  };
  
  if (config.retention.policies.length === 0) {
    retentionValidation.errors.push('No retention policies defined');
  }

  const validations = {
    backup: backupValidation,
    retention: retentionValidation,
    encryption: encryptionValidation,
    monitoring: monitoringValidation,
    alerting: alertingValidation
  };

  const overall = Object.values(validations).every(v => v.valid);

  return {
    ...validations,
    overall
  };
}

// Export all configs as default
export const backupConfigs = defaultBackupConfigs;
export const retentionPolicies = defaultRetentionPolicies;
export const retentionSchedules = defaultRetentionSchedules;
export const archiveConfigs = defaultArchiveConfigs;
export const cleanupConfigs = defaultCleanupConfigs;
export const encryptionConfigs = defaultEncryptionConfigs;
export const monitoringConfigs = defaultMonitoringConfigs;
export const alertConfigs = defaultAlertConfigs;

// Default export for backward compatibility
export default {
  backup: backupConfigs,
  retention: {
    policies: retentionPolicies,
    schedules: retentionSchedules,
    archive: archiveConfigs,
    cleanup: cleanupConfigs
  },
  encryption: encryptionConfigs,
  monitoring: monitoringConfigs,
  alerting: alertConfigs
};