/**
 * Backup Alerting Configuration
 * Comprehensive alerting system for backup failures and monitoring
 */

export interface AlertConfig {
  environment: string;
  enabled: boolean;
  global: GlobalAlertConfig;
  channels: AlertChannelConfig[];
  rules: AlertRuleConfig[];
  escalation: AlertEscalationConfig;
  suppression: AlertSuppressionConfig;
  notification: AlertNotificationConfig;
  compliance: ComplianceAlertConfig;
}

export interface GlobalAlertConfig {
  enabled: boolean;
  defaultSeverity: 'critical' | 'high' | 'medium' | 'low' | 'info';
  defaultChannels: string[];
  rateLimiting: RateLimitingConfig;
  batching: BatchingConfig;
  quietHours: QuietHoursConfig;
  testMode: boolean;
}

export interface RateLimitingConfig {
  enabled: boolean;
  maxAlerts: {
    perMinute: number;
    perHour: number;
    perDay: number;
  };
  burst: {
    enabled: boolean;
    window: number; // seconds
    max: number;
  };
}

export interface BatchingConfig {
  enabled: boolean;
  batchSize: number;
  batchTimeout: number; // seconds
  aggregation: 'time' | 'severity' | 'source' | 'custom';
  fields: string[];
}

export interface QuietHoursConfig {
  enabled: boolean;
  start: string; // HH:mm format
  end: string; // HH:mm format
  timezone: string;
  channels: string[];
  severity: ('critical' | 'high' | 'medium' | 'low' | 'info')[];
  override: {
    enabled: boolean;
    reason: string;
    duration: number; // minutes
  };
}

export interface AlertChannelConfig {
  name: string;
  type: 'email' | 'slack' | 'pagerduty' | 'teams' | 'webhook' | 'sms' | 'voice' | 'sns';
  enabled: boolean;
  priority: number;
  config: ChannelConfig;
  filters: AlertFilter[];
  scheduling: ChannelScheduling;
  authentication: ChannelAuthentication;
}

export interface ChannelConfig {
  // Email
  recipients?: string[];
  subject?: string;
  template?: string;
  replyTo?: string;
  cc?: string[];
  bcc?: string[];
  
  // Slack
  webhook?: string;
  channel?: string;
  username?: string;
  iconEmoji?: string;
  
  // PagerDuty
  serviceId?: string;
  integrationKey?: string;
  escalationPolicyId?: string;
  
  // Teams
  teamsWebhook?: string;
  teamsChannel?: string;
  
  // Webhook
  url?: string;
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH';
  headers?: Record<string, string>;
  payload?: Record<string, any>;
  
  // SMS
  phoneNumbers?: string[];
  provider?: 'twilio' | 'aws-sns';
  
  // Voice
  phoneNumbers?: string[];
  message?: string;
  
  // SNS
  topicArn?: string;
  subject?: string;
}

export interface AlertFilter {
  field: string;
  operator: 'equals' | 'contains' | 'matches' | 'in' | 'gt' | 'lt' | 'gte' | 'lte';
  value: any;
  caseSensitive: boolean;
}

export interface ChannelScheduling {
  enabled: boolean;
  schedule: string; // cron expression
  timezone: string;
  overrides: ScheduleOverride[];
}

export interface ScheduleOverride {
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  channels: string[];
  reason: string;
}

export interface ChannelAuthentication {
  type: 'none' | 'api-key' | 'basic' | 'oauth2' | 'bearer-token' | 'signature';
  credentials?: Record<string, string>;
  headers?: Record<string, string>;
  token?: string;
  expiry?: string; // ISO 8601
}

export interface AlertRuleConfig {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info';
  category: 'backup' | 'storage' | 'network' | 'system' | 'application' | 'security' | 'compliance';
  condition: AlertCondition;
  labels: Record<string, string>;
  annotations: Record<string, string>;
  for: number; // minutes to wait before firing
  retain: number; // minutes to retain after resolution
  channels: string[];
  templates: AlertTemplateConfig;
  dependencies?: string[]; // other rule IDs
  testing: {
    enabled: boolean;
    schedule: string;
    dryRun: boolean;
  };
}

export interface AlertCondition {
  type: 'threshold' | 'anomaly' | 'missing' | 'change' | 'composite';
  query: string; // metric query or expression
  operator: 'gt' | 'lt' | 'eq' | 'ne' | 'gte' | 'lte' | 'contains' | 'matches';
  threshold: number | string;
  timeRange: number; // minutes
  evaluation: 'any' | 'all'; // how to evaluate multiple data points
  grouping?: {
    field: string;
    minGroups: number;
  };
  additional?: Record<string, any>;
}

export interface AlertTemplateConfig {
  subject: string;
  message: string;
  details: string[];
  fields: TemplateField[];
  formatting: TemplateFormatting;
}

export interface TemplateField {
  name: string;
  source: 'metric' | 'label' | 'annotation' | 'static' | 'computed';
  format?: string;
  required: boolean;
}

export interface TemplateFormatting {
  markdown: boolean;
  html: boolean;
  colorize: boolean;
  includeCharts: boolean;
  maxLength: number;
}

export interface AlertEscalationConfig {
  enabled: boolean;
  levels: EscalationLevel[];
  globalTimeout: number; // minutes
  autoResolve: boolean;
  resolution: {
    enabled: boolean;
    conditions: ResolutionCondition[];
    channels: string[];
  };
}

export interface EscalationLevel {
  id: string;
  name: string;
  delay: number; // minutes from previous level or alert creation
  channels: string[];
  recipients: EscalationRecipient[];
  conditions: EscalationCondition[];
  timeout?: number; // minutes
  repeat?: {
    enabled: boolean;
    interval: number; // minutes
    maxRepeats: number;
  };
}

export interface EscalationRecipient {
  type: 'user' | 'group' | 'role' | 'oncall';
  identifier: string;
  contact?: {
    email?: string;
    phone?: string;
    slack?: string;
  };
}

export interface EscalationCondition {
  type: 'time' | 'severity' | 'count' | 'manual';
  value: any;
  action: 'escalate' | 'resolve' | 'notify';
}

export interface ResolutionCondition {
  type: 'time' | 'metric' | 'manual' | 'dependent';
  query?: string;
  threshold?: number;
  timeRange?: number;
  dependentRule?: string;
}

export interface AlertSuppressionConfig {
  enabled: boolean;
  rules: SuppressionRule[];
  logic: 'any' | 'all';
  expiry: {
    enabled: boolean;
    maxDuration: number; // minutes
  };
}

export interface SuppressionRule {
  id: string;
  name: string;
  description: string;
  enabled: boolean;
  priority: number;
  condition: AlertCondition;
  match: SuppressionMatch;
  duration: number; // minutes
  reason: string;
  createdBy: string;
  expiry?: string; // ISO 8601
}

export interface SuppressionMatch {
  rules?: string[];
  labels?: Record<string, string>;
  severity?: ('critical' | 'high' | 'medium' | 'low' | 'info')[];
  source?: string[];
  custom?: AlertFilter[];
}

export interface AlertNotificationConfig {
  enabled: boolean;
  templates: NotificationTemplate[];
  formatting: NotificationFormatting;
  delivery: NotificationDelivery;
  tracking: NotificationTracking;
}

export interface NotificationTemplate {
  name: string;
  type: 'initial' | 'update' | 'escalation' | 'resolution' | 'test';
  subject: string;
  body: string;
  variables: TemplateVariable[];
  localization: LocalizationConfig;
}

export interface TemplateVariable {
  name: string;
  type: 'string' | 'number' | 'boolean' | 'object';
  default?: any;
  description: string;
  format?: string;
}

export interface LocalizationConfig {
  enabled: boolean;
  default: string;
  translations: Record<string, Record<string, string>>;
}

export interface NotificationFormatting {
  style: 'markdown' | 'html' | 'plain' | 'json';
  colors: boolean;
  emoji: boolean;
  charts: boolean;
  tables: boolean;
  maxLength: number;
}

export interface NotificationDelivery {
  retry: DeliveryRetryConfig;
  timeout: number; // seconds
  parallel: boolean;
  ordered: boolean;
}

export interface DeliveryRetryConfig {
  enabled: boolean;
  attempts: number;
  backoff: 'exponential' | 'linear' | 'fixed';
  initialDelay: number; // ms
  maxDelay: number; // ms
  maxRetries: number;
}

export interface NotificationTracking {
  enabled: boolean;
  events: NotificationEvent[];
  storage: TrackingStorageConfig;
}

export interface NotificationEvent {
  type: 'sent' | 'delivered' | 'failed' | 'bounced' | 'clicked' | 'opened';
  fields: string[];
  retention: number; // days
}

export interface TrackingStorageConfig {
  provider: 'database' | 'elasticsearch' | 'cloudwatch' | 'splunk';
  endpoint?: string;
  retention: number; // days
  batchSize: number;
}

export interface ComplianceAlertConfig {
  enabled: boolean;
  standards: ComplianceStandardAlert[];
  audits: ComplianceAuditAlert[];
  reporting: ComplianceReportingAlert;
}

export interface ComplianceStandardAlert {
  name: 'FIPS-140-2' | 'PCI-DSS' | 'GDPR' | 'HIPAA' | 'SOX' | 'ISO-27001';
  enabled: boolean;
  severity: 'critical' | 'high' | 'medium' | 'low';
  rules: ComplianceAlertRule[];
  channels: string[];
}

export interface ComplianceAlertRule {
  name: string;
  description: string;
  condition: string; // compliance check query
  threshold: number;
  timeRange: number; // minutes
  documentation: string;
  remediation: string;
}

export interface ComplianceAuditAlert {
  name: string;
  schedule: string; // cron
  enabled: boolean;
  standards: string[];
  scope: AuditScopeConfig;
  recipients: string[];
}

export interface AuditScopeConfig {
  components: string[];
  dataTypes: string[];
  permissions: string[];
}

export interface ComplianceReportingAlert {
  enabled: boolean;
  schedule: string; // cron
  format: 'pdf' | 'html' | 'json' | 'csv';
  recipients: string[];
  include: string[];
}

// Environment-specific configurations
export const alertConfigs: Record<string, AlertConfig> = {
  dev: {
    environment: 'dev',
    enabled: false,
    global: {
      enabled: false,
      defaultSeverity: 'medium',
      defaultChannels: [],
      rateLimiting: { enabled: false, maxAlerts: { perMinute: 10, perHour: 100, perDay: 1000 }, burst: { enabled: false, window: 60, max: 5 } },
      batching: { enabled: false, batchSize: 10, batchTimeout: 60, aggregation: 'time', fields: [] },
      quietHours: { enabled: false, start: '22:00', end: '08:00', timezone: 'UTC', channels: [], severity: [], override: { enabled: false, reason: '', duration: 60 } },
      testMode: true
    },
    channels: [],
    rules: [],
    escalation: { enabled: false, levels: [], globalTimeout: 60, autoResolve: false, resolution: { enabled: false, conditions: [], channels: [] } },
    suppression: { enabled: false, rules: [], logic: 'any', expiry: { enabled: false, maxDuration: 1440 } },
    notification: { enabled: false, templates: [], formatting: { style: 'plain', colors: false, emoji: false, charts: false, tables: false, maxLength: 1000 }, delivery: { retry: { enabled: false, attempts: 3, backoff: 'exponential', initialDelay: 1000, maxDelay: 30000, maxRetries: 5 }, timeout: 30, parallel: false, ordered: true }, tracking: { enabled: false, events: [], storage: { provider: 'database', retention: 7, batchSize: 100 } } },
    compliance: { enabled: false, standards: [], audits: [], reporting: { enabled: false, schedule: '0 9 * * 1', format: 'json', recipients: [], include: [] } }
  },

  staging: {
    environment: 'staging',
    enabled: true,
    global: {
      enabled: true,
      defaultSeverity: 'medium',
      defaultChannels: ['staging-email'],
      rateLimiting: { enabled: true, maxAlerts: { perMinute: 30, perHour: 300, perDay: 2000 }, burst: { enabled: true, window: 60, max: 10 } },
      batching: { enabled: true, batchSize: 5, batchTimeout: 30, aggregation: 'severity', fields: ['severity', 'category'] },
      quietHours: { enabled: false, start: '22:00', end: '08:00', timezone: 'America/New_York', channels: ['staging-email'], severity: ['low', 'info'], override: { enabled: true, reason: 'Scheduled maintenance', duration: 120 } },
      testMode: false
    },
    channels: [
      {
        name: 'staging-email',
        type: 'email',
        enabled: true,
        priority: 5,
        config: {
          recipients: ['staging-team@company.com'],
          subject: '[STAGING] Backup Alert: {{severity | upper}}',
          template: 'staging-alert-template'
        },
        filters: [],
        scheduling: { enabled: false, schedule: '', timezone: 'UTC', overrides: [] },
        authentication: { type: 'none' }
      },
      {
        name: 'staging-slack',
        type: 'slack',
        enabled: true,
        priority: 3,
        config: {
          webhook: process.env.STAGING_SLACK_WEBHOOK,
          channel: '#staging-alerts',
          username: 'backup-bot'
        },
        filters: [{ field: 'severity', operator: 'in', value: ['critical', 'high'], caseSensitive: false }],
        scheduling: { enabled: false, schedule: '', timezone: 'UTC', overrides: [] },
        authentication: { type: 'none' }
      }
    ],
    rules: [
      {
        id: 'staging-backup-failure',
        name: 'Staging Backup Failure',
        description: 'Backup operation failed in staging environment',
        enabled: true,
        severity: 'high',
        category: 'backup',
        condition: { type: 'threshold', query: 'backup_success_rate', operator: 'lt', threshold: 90, timeRange: 15, evaluation: 'all' },
        labels: { environment: 'staging', team: 'staging' },
        annotations: { summary: 'Backup failure rate above threshold', description: 'Backup success rate is below 90%' },
        for: 5,
        retain: 120,
        channels: ['staging-email', 'staging-slack'],
        templates: {
          subject: 'Staging Backup Alert: {{severity}}',
          message: 'Backup operation failed in staging. Success rate: {{value}}%',
          details: ['environment', 'backup_type', 'duration', 'error_count'],
          fields: [
            { name: 'environment', source: 'label', format: 'string', required: true },
            { name: 'backup_type', source: 'label', format: 'string', required: true },
            { name: 'duration', source: 'metric', format: 'duration', required: true }
          ],
          formatting: { markdown: true, html: false, colorize: true, includeCharts: false, maxLength: 2000 }
        },
        testing: { enabled: true, schedule: '0 2 * * *', dryRun: true }
      },
      {
        id: 'staging-storage-high',
        name: 'Staging Storage Usage High',
        description: 'Storage usage exceeds 80% in staging',
        enabled: true,
        severity: 'medium',
        category: 'storage',
        condition: { type: 'threshold', query: 'storage_usage_percent', operator: 'gt', threshold: 80, timeRange: 30, evaluation: 'any' },
        labels: { environment: 'staging', team: 'staging' },
        annotations: { summary: 'High storage usage detected', description: 'Storage usage is above 80% threshold' },
        for: 10,
        retain: 60,
        channels: ['staging-email'],
        templates: {
          subject: 'Staging Storage Alert',
          message: 'Storage usage is at {{value}}%',
          details: ['storage_tier', 'available_space'],
          fields: [],
          formatting: { markdown: false, html: false, colorize: true, includeCharts: false, maxLength: 1000 }
        },
        testing: { enabled: false, schedule: '', dryRun: true }
      }
    ],
    escalation: {
      enabled: true,
      levels: [
        {
          id: 'level1',
          name: 'Team Notification',
          delay: 15,
          channels: ['staging-email'],
          recipients: [{ type: 'group', identifier: 'staging-team' }],
          conditions: [{ type: 'severity', value: 'high', action: 'escalate' }],
          timeout: 30
        },
        {
          id: 'level2',
          name: 'Management Notification',
          delay: 60,
          channels: ['staging-email'],
          recipients: [{ type: 'group', identifier: 'devops-team' }],
          conditions: [{ type: 'time', value: 60, action: 'escalate' }],
          timeout: 60
        }
      ],
      globalTimeout: 240,
      autoResolve: true,
      resolution: {
        enabled: true,
        conditions: [{ type: 'time', timeRange: 60 }],
        channels: ['staging-email']
      }
    },
    suppression: {
      enabled: true,
      rules: [
        {
          id: 'staging-maintenance',
          name: 'Staging Maintenance Window',
          description: 'Suppress alerts during maintenance',
          enabled: true,
          priority: 10,
          condition: { type: 'threshold', query: 'maintenance_mode', operator: 'eq', threshold: 1, timeRange: 1, evaluation: 'any' },
          match: { labels: { environment: 'staging' } },
          duration: 120,
          reason: 'Scheduled maintenance',
          createdBy: 'system'
        }
      ],
      logic: 'any',
      expiry: { enabled: true, maxDuration: 1440 }
    },
    notification: {
      enabled: true,
      templates: [
        {
          name: 'staging-alert-template',
          type: 'initial',
          subject: 'Staging Backup Alert: {{severity}}',
          body: 'Alert: {{alert.name}}\nSeverity: {{severity}}\nDescription: {{alert.description}}\nTime: {{timestamp}}',
          variables: [
            { name: 'severity', type: 'string', description: 'Alert severity level', default: 'medium' },
            { name: 'timestamp', type: 'string', description: 'Alert timestamp', format: 'iso8601' }
          ],
          localization: { enabled: false, default: 'en', translations: {} }
        }
      ],
      formatting: { style: 'markdown', colors: true, emoji: true, charts: false, tables: true, maxLength: 5000 },
      delivery: { retry: { enabled: true, attempts: 3, backoff: 'exponential', initialDelay: 2000, maxDelay: 60000, maxRetries: 5 }, timeout: 30, parallel: true, ordered: false },
      tracking: { enabled: true, events: [{ type: 'sent', fields: ['alert_id', 'channel', 'timestamp'], retention: 30 }], storage: { provider: 'database', retention: 30, batchSize: 100 } }
    },
    compliance: {
      enabled: true,
      standards: [
        { name: 'FIPS-140-2', enabled: true, severity: 'high', rules: [], channels: ['staging-email'] }
      ],
      audits: [],
      reporting: { enabled: false, schedule: '0 9 * * 1', format: 'json', recipients: [], include: [] }
    }
  },

  production: {
    environment: 'production',
    enabled: true,
    global: {
      enabled: true,
      defaultSeverity: 'critical',
      defaultChannels: ['prod-pagerduty', 'prod-slack', 'prod-email'],
      rateLimiting: { enabled: true, maxAlerts: { perMinute: 100, perHour: 1000, perDay: 10000 }, burst: { enabled: true, window: 60, max: 20 } },
      batching: { enabled: true, batchSize: 3, batchTimeout: 60, aggregation: 'severity', fields: ['severity', 'category', 'service'] },
      quietHours: { enabled: false, start: '22:00', end: '08:00', timezone: 'America/New_York', channels: ['prod-email'], severity: ['low', 'info'], override: { enabled: true, reason: 'Scheduled maintenance', duration: 60 } },
      testMode: false
    },
    channels: [
      {
        name: 'prod-pagerduty',
        type: 'pagerduty',
        enabled: true,
        priority: 10,
        config: {
          serviceId: process.env.PAGERDUTY_SERVICE_ID,
          integrationKey: process.env.PAGERDUTY_INTEGRATION_KEY,
          escalationPolicyId: process.env.PAGERDUTY_ESCALATION_POLICY
        },
        filters: [{ field: 'severity', operator: 'in', value: ['critical'], caseSensitive: false }],
        scheduling: { enabled: false, schedule: '', timezone: 'UTC', overrides: [] },
        authentication: { type: 'api-key', credentials: { apiKey: process.env.PAGERDUTY_API_KEY } }
      },
      {
        name: 'prod-slack',
        type: 'slack',
        enabled: true,
        priority: 8,
        config: {
          webhook: process.env.PROD_SLACK_WEBHOOK,
          channel: '#ops-alerts',
          username: 'backup-alerts',
          iconEmoji: ':warning:'
        },
        filters: [{ field: 'severity', operator: 'in', value: ['critical', 'high'], caseSensitive: false }],
        scheduling: { enabled: false, schedule: '', timezone: 'UTC', overrides: [] },
        authentication: { type: 'none' }
      },
      {
        name: 'prod-email',
        type: 'email',
        enabled: true,
        priority: 6,
        config: {
          recipients: ['operations@company.com', 'management@company.com'],
          subject: '[PRODUCTION] Critical Backup Alert: {{alert.name}}',
          template: 'prod-critical-alert-template',
          replyTo: 'noreply@company.com'
        },
        filters: [],
        scheduling: { enabled: false, schedule: '', timezone: 'UTC', overrides: [] },
        authentication: { type: 'none' }
      },
      {
        name: 'prod-sns',
        type: 'sns',
        enabled: true,
        priority: 7,
        config: {
          topicArn: process.env.AWS_SNS_TOPIC_ARN,
          subject: 'PRODUCTION Backup Alert'
        },
        filters: [{ field: 'severity', operator: 'in', value: ['critical', 'high'], caseSensitive: false }],
        scheduling: { enabled: false, schedule: '', timezone: 'UTC', overrides: [] },
        authentication: { type: 'none' }
      }
    ],
    rules: [
      {
        id: 'prod-backup-failure-critical',
        name: 'Production Backup Critical Failure',
        description: 'Critical backup failure in production',
        enabled: true,
        severity: 'critical',
        category: 'backup',
        condition: { type: 'threshold', query: 'backup_success_rate', operator: 'lt', threshold: 95, timeRange: 10, evaluation: 'all' },
        labels: { environment: 'production', service: 'backup', team: 'operations', severity: 'critical' },
        annotations: { summary: 'CRITICAL: Backup failure rate in production', description: 'Backup success rate below 95% threshold - immediate attention required' },
        for: 2,
        retain: 1440,
        channels: ['prod-pagerduty', 'prod-slack', 'prod-email', 'prod-sns'],
        templates: {
          subject: '🚨 CRITICAL: Production Backup Failure',
          message: 'CRITICAL BACKUP ALERT\n\nEnvironment: Production\nSuccess Rate: {{value}}%\nTime Range: {{timeRange}} minutes\nImpact: {{impact}}\n\nImmediate action required.',
          details: ['backup_type', 'affected_systems', 'last_success', 'error_patterns', 'estimated_mttr'],
          fields: [
            { name: 'impact', source: 'computed', format: 'string', required: true },
            { name: 'affected_systems', source: 'label', format: 'string', required: true },
            { name: 'estimated_mttr', source: 'computed', format: 'duration', required: false }
          ],
          formatting: { markdown: true, html: true, colorize: true, includeCharts: true, maxLength: 10000 }
        },
        testing: { enabled: true, schedule: '0 3 * * 0', dryRun: false }
      },
      {
        id: 'prod-storage-critical',
        name: 'Production Storage Critical',
        description: 'Storage usage exceeds 85% in production',
        enabled: true,
        severity: 'critical',
        category: 'storage',
        condition: { type: 'threshold', query: 'storage_usage_percent', operator: 'gt', threshold: 85, timeRange: 15, evaluation: 'any' },
        labels: { environment: 'production', service: 'storage', team: 'operations' },
        annotations: { summary: 'CRITICAL: Storage usage critical', description: 'Storage usage above 85% - immediate action required' },
        for: 5,
        retain: 720,
        channels: ['prod-pagerduty', 'prod-slack'],
        templates: {
          subject: '🚨 CRITICAL: Production Storage Critical',
          message: 'STORAGE CRITICAL ALERT\n\nStorage Usage: {{value}}%\nAvailable Space: {{available_space}}\nEstimated Full: {{estimated_full_time}}\n\nImmediate cleanup required.',
          details: ['storage_tier', 'growth_rate', 'oldest_files'],
          fields: [],
          formatting: { markdown: true, html: true, colorize: true, includeCharts: true, maxLength: 5000 }
        },
        testing: { enabled: false, schedule: '', dryRun: false }
      },
      {
        id: 'prod-backup-duration',
        name: 'Production Backup Duration',
        description: 'Backup duration exceeds 2 hours',
        enabled: true,
        severity: 'high',
        category: 'backup',
        condition: { type: 'threshold', query: 'backup_duration_seconds', operator: 'gt', threshold: 7200, timeRange: 30, evaluation: 'any' },
        labels: { environment: 'production', service: 'backup' },
        annotations: { summary: 'High backup duration detected', description: 'Backup operation taking longer than expected' },
        for: 10,
        retain: 120,
        channels: ['prod-slack', 'prod-email'],
        templates: {
          subject: '⚠️ Production Backup Duration Alert',
          message: 'BACKUP DURATION ALERT\n\nDuration: {{value}}\nExpected: 2 hours\nBackup Type: {{backup_type}}\n\nPlease investigate performance issues.',
          details: ['backup_size', 'network_latency', 'system_load'],
          fields: [],
          formatting: { markdown: true, html: false, colorize: true, includeCharts: false, maxLength: 3000 }
        },
        testing: { enabled: true, schedule: '0 4 * * 0', dryRun: true }
      },
      {
        id: 'prod-encryption-failure',
        name: 'Production Encryption Failure',
        description: 'Encryption process failure in production',
        enabled: true,
        severity: 'critical',
        category: 'security',
        condition: { type: 'threshold', query: 'encryption_success_rate', operator: 'lt', threshold: 100, timeRange: 5, evaluation: 'all' },
        labels: { environment: 'production', service: 'encryption', team: 'security' },
        annotations: { summary: 'CRITICAL: Encryption failure detected', description: 'Any encryption failure in production requires immediate attention' },
        for: 1,
        retain: 2555,
        channels: ['prod-pagerduty', 'prod-sns'],
        templates: {
          subject: '🚨 CRITICAL: Production Encryption Failure',
          message: 'ENCRYPTION FAILURE ALERT\n\nSuccess Rate: {{value}}%\nFailed Items: {{failed_count}}\nTime: {{timestamp}}\n\nSECURITY INCIDENT - Immediate action required.',
          details: ['key_id', 'failure_reason', 'affected_data'],
          fields: [],
          formatting: { markdown: true, html: true, colorize: true, includeCharts: false, maxLength: 2000 }
        },
        testing: { enabled: false, schedule: '', dryRun: false }
      },
      {
        id: 'prod-compliance-violation',
        name: 'Production Compliance Violation',
        description: 'Compliance check violation in production',
        enabled: true,
        severity: 'critical',
        category: 'compliance',
        condition: { type: 'threshold', query: 'compliance_score', operator: 'lt', threshold: 100, timeRange: 1, evaluation: 'any' },
        labels: { environment: 'production', service: 'compliance', team: 'security' },
        annotations: { summary: 'CRITICAL: Compliance violation detected', description: 'Compliance check failed in production environment' },
        for: 1,
        retain: 2555,
        channels: ['prod-pagerduty', 'prod-email'],
        templates: {
          subject: '🚨 CRITICAL: Production Compliance Violation',
          message: 'COMPLIANCE VIOLATION ALERT\n\nScore: {{value}}%\nStandard: {{compliance_standard}}\nCheck: {{check_name}}\n\nREGULATORY INCIDENT - Immediate action required.',
          details: ['violation_details', 'remediation_steps', 'regulatory_impact'],
          fields: [],
          formatting: { markdown: true, html: true, colorize: true, includeCharts: false, maxLength: 3000 }
        },
        testing: { enabled: false, schedule: '', dryRun: false }
      }
    ],
    escalation: {
      enabled: true,
      levels: [
        {
          id: 'immediate',
          name: 'Immediate Response',
          delay: 0,
          channels: ['prod-pagerduty', 'prod-slack'],
          recipients: [{ type: 'oncall', identifier: 'primary-oncall' }, { type: 'role', identifier: 'backup-team-lead' }],
          conditions: [{ type: 'severity', value: 'critical', action: 'escalate' }],
          timeout: 5
        },
        {
          id: '15min',
          name: '15 Minute Escalation',
          delay: 15,
          channels: ['prod-pagerduty', 'prod-email'],
          recipients: [{ type: 'oncall', identifier: 'escalation-oncall' }, { type: 'group', identifier: 'operations-management' }],
          conditions: [{ type: 'time', value: 15, action: 'escalate' }],
          timeout: 30
        },
        {
          id: '30min',
          name: '30 Minute Escalation',
          delay: 30,
          channels: ['prod-email', 'prod-sns'],
          recipients: [{ type: 'group', identifier: 'senior-management' }, { type: 'user', identifier: 'cto@company.com' }],
          conditions: [{ type: 'time', value: 30, action: 'escalate' }],
          timeout: 60
        },
        {
          id: '60min',
          name: 'Executive Escalation',
          delay: 60,
          channels: ['prod-email'],
          recipients: [{ type: 'user', identifier: 'ceo@company.com' }, { type: 'user', identifier: 'ciso@company.com' }],
          conditions: [{ type: 'time', value: 60, action: 'escalate' }],
          timeout: 120
        }
      ],
      globalTimeout: 240,
      autoResolve: false,
      resolution: {
        enabled: true,
        conditions: [{ type: 'time', timeRange: 30 }],
        channels: ['prod-slack', 'prod-email']
      }
    },
    suppression: {
      enabled: true,
      rules: [
        {
          id: 'prod-planned-maintenance',
          name: 'Production Planned Maintenance',
          description: 'Suppress alerts during planned maintenance windows',
          enabled: true,
          priority: 100,
          condition: { type: 'threshold', query: 'maintenance_mode', operator: 'eq', threshold: 1, timeRange: 1, evaluation: 'any' },
          match: { labels: { environment: 'production' }, severity: ['low', 'medium', 'high'] },
          duration: 240,
          reason: 'Scheduled maintenance window',
          createdBy: 'system',
          expiry: '2025-12-31T23:59:59Z'
        },
        {
          id: 'prod-weekend-quiet',
          name: 'Weekend Quiet Hours',
          description: 'Reduce noise during weekends for non-critical alerts',
          enabled: true,
          priority: 50,
          condition: { type: 'composite', query: 'day_of_week in [0,6] and hour >= 22 or hour <= 8', operator: 'matches', threshold: 1, timeRange: 1, evaluation: 'any' },
          match: { severity: ['low', 'info'] },
          duration: 720,
          reason: 'Weekend quiet hours',
          createdBy: 'system'
        }
      ],
      logic: 'any',
      expiry: { enabled: true, maxDuration: 10080 } // 1 week
    },
    notification: {
      enabled: true,
      templates: [
        {
          name: 'prod-critical-alert-template',
          type: 'initial',
          subject: '🚨 CRITICAL: {{alert.name}}',
          body: '# CRITICAL ALERT\n\n## Alert Details\n- **Name**: {{alert.name}}\n- **Severity**: {{severity | upper}}\n- **Environment**: {{environment}}\n- **Time**: {{timestamp | date}}\n\n## Description\n{{alert.description}}\n\n## Current Status\n- **Metric**: {{metric}}\n- **Value**: {{value}}\n- **Threshold**: {{threshold}}\n- **Duration**: {{duration}}\n\n## Impact\n{{impact}}\n\n## Next Steps\n1. Acknowledge this alert\n2. Investigate root cause\n3. Implement remediation\n4. Document resolution\n\n---\n*Generated by Backup Monitoring System*',
          variables: [
            { name: 'severity', type: 'string', default: 'critical', description: 'Alert severity level' },
            { name: 'environment', type: 'string', default: 'production', description: 'Environment name' },
            { name: 'timestamp', type: 'string', format: 'iso8601', description: 'Alert timestamp' },
            { name: 'metric', type: 'string', description: 'Metric being monitored' },
            { name: 'value', type: 'number', description: 'Current metric value' },
            { name: 'threshold', type: 'number', description: 'Alert threshold' },
            { name: 'duration', type: 'number', description: 'Duration above threshold' },
            { name: 'impact', type: 'string', description: 'Business impact assessment' }
          ],
          localization: { enabled: true, default: 'en', translations: { es: { severity: 'severidad' } } }
        }
      ],
      formatting: { style: 'markdown', colors: true, emoji: true, charts: true, tables: true, maxLength: 20000 },
      delivery: { retry: { enabled: true, attempts: 5, backoff: 'exponential', initialDelay: 1000, maxDelay: 120000, maxRetries: 10 }, timeout: 60, parallel: true, ordered: true },
      tracking: { enabled: true, events: [{ type: 'sent', fields: ['alert_id', 'channel', 'timestamp', 'recipient'], retention: 2555 }, { type: 'delivered', fields: ['alert_id', 'channel', 'timestamp'], retention: 2555 }, { type: 'failed', fields: ['alert_id', 'channel', 'error'], retention: 2555 }], storage: { provider: 'elasticsearch', endpoint: process.env.ELASTICSEARCH_ENDPOINT, retention: 2555, batchSize: 1000 } }
    },
    compliance: {
      enabled: true,
      standards: [
        { name: 'FIPS-140-2', enabled: true, severity: 'critical', rules: [], channels: ['prod-pagerduty', 'prod-email'] },
        { name: 'PCI-DSS', enabled: true, severity: 'critical', rules: [], channels: ['prod-pagerduty', 'prod-email'] },
        { name: 'GDPR', enabled: true, severity: 'high', rules: [], channels: ['prod-pagerduty'] },
        { name: 'HIPAA', enabled: true, severity: 'critical', rules: [], channels: ['prod-pagerduty', 'prod-email'] },
        { name: 'SOX', enabled: true, severity: 'high', rules: [], channels: ['prod-email'] },
        { name: 'ISO-27001', enabled: true, severity: 'high', rules: [], channels: ['prod-slack'] }
      ],
      audits: [
        {
          name: 'monthly-compliance-audit',
          schedule: '0 2 1 * *',
          enabled: true,
          standards: ['FIPS-140-2', 'PCI-DSS', 'GDPR', 'HIPAA', 'SOX', 'ISO-27001'],
          scope: { components: ['backup-service', 'storage', 'encryption'], dataTypes: ['all'], permissions: ['admin', 'read', 'write'] },
          recipients: ['compliance@company.com', 'security@company.com', 'legal@company.com']
        }
      ],
      reporting: { enabled: true, schedule: '0 6 * * 1', format: 'pdf', recipients: ['compliance@company.com', 'security@company.com', 'management@company.com'], include: ['summary', 'detailed_findings', 'remediation_plan', 'risk_assessment', 'compliance_trends'] }
    }
  }
};

// Utility functions
export function getAlertConfig(environment: string): AlertConfig {
  const config = alertConfigs[environment];
  if (!config) {
    throw new Error(`No alert configuration found for environment: ${environment}`);
  }
  return config;
}

export function getCurrentAlertConfig(): AlertConfig {
  const environment = process.env.NODE_ENV || 'development';
  return getAlertConfig(environment);
}

export function isAlertingEnabled(environment: string): boolean {
  const config = getAlertConfig(environment);
  return config.enabled;
}

export function getAlertChannels(environment: string): AlertChannelConfig[] {
  const config = getAlertConfig(environment);
  return config.channels.filter(channel => channel.enabled);
}

export function getAlertRules(environment: string): AlertRuleConfig[] {
  const config = getAlertConfig(environment);
  return config.rules.filter(rule => rule.enabled);
}

export function evaluateAlertCondition(condition: AlertCondition, data: Record<string, any>): boolean {
  // This is a simplified evaluation - in practice, you'd use a proper expression evaluator
  const value = data[condition.query];
  
  switch (condition.operator) {
    case 'gt': return value > condition.threshold;
    case 'lt': return value < condition.threshold;
    case 'eq': return value === condition.threshold;
    case 'ne': return value !== condition.threshold;
    case 'gte': return value >= condition.threshold;
    case 'lte': return value <= condition.threshold;
    case 'contains': return String(value).includes(String(condition.threshold));
    case 'matches': return new RegExp(String(condition.threshold)).test(String(value));
    default: return false;
  }
}

export function shouldSuppressAlert(alert: any, suppressionRules: SuppressionRule[]): boolean {
  return suppressionRules.some(rule => {
    if (!rule.enabled) return false;
    
    // Check if alert matches suppression criteria
    if (rule.match.rules && !rule.match.rules.includes(alert.ruleId)) return false;
    if (rule.match.severity && !rule.match.severity.includes(alert.severity)) return false;
    
    // Additional matching logic would go here
    
    return true;
  });
}

export function validateAlertConfig(config: AlertConfig): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Validate channels
  config.channels.forEach((channel, index) => {
    if (!channel.name) {
      errors.push(`Channel ${index + 1} missing name`);
    }
    if (!channel.type) {
      errors.push(`Channel ${channel.name || index + 1} missing type`);
    }
  });

  // Validate rules
  config.rules.forEach((rule, index) => {
    if (!rule.name) {
      errors.push(`Rule ${index + 1} missing name`);
    }
    if (!rule.condition.query) {
      errors.push(`Rule ${rule.name || index + 1} missing condition query`);
    }
    if (rule.channels.length === 0) {
      warnings.push(`Rule ${rule.name || index + 1} has no notification channels`);
    }
  });

  // Validate escalation
  if (config.escalation.enabled) {
    config.escalation.levels.forEach((level, index) => {
      if (level.channels.length === 0) {
        warnings.push(`Escalation level ${level.name || index + 1} has no channels`);
      }
    });
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings
  };
}

export interface ValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

export default alertConfigs;