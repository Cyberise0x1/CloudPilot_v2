/**
 * Backup Configuration
 * Central configuration for backup settings and policies across different environments
 */

export interface BackupConfig {
  environment: 'dev' | 'staging' | 'production';
  schedule: BackupSchedule;
  storage: StorageConfig;
  retention: RetentionConfig;
  encryption: EncryptionConfig;
  monitoring: MonitoringConfig;
  alerting: AlertConfig;
  verification: VerificationConfig;
  recovery: RecoveryConfig;
}

export interface BackupSchedule {
  full: {
    enabled: boolean;
    cron: string;
    retention: number; // days
  };
  incremental: {
    enabled: boolean;
    cron: string;
    retention: number; // days
  };
  continuous: {
    enabled: boolean;
    interval: number; // minutes
    retention: number; // days
  };
}

export interface StorageConfig {
  provider: 'aws-s3' | 'aws-dynamodb' | 'local' | 'multiple';
  primary: {
    region: string;
    bucket: string;
    path: string;
  };
  secondary?: {
    region: string;
    bucket: string;
    path: string;
  };
  archive?: {
    region: string;
    bucket: string;
    path: string;
  };
  compression: {
    enabled: boolean;
    algorithm: 'gzip' | 'lz4' | 'zstd';
    level: number; // 1-9
  };
  parallel: {
    uploads: number;
    downloads: number;
  };
}

export interface RetentionConfig {
  policies: RetentionPolicy[];
  archive: {
    after: number; // days
    destination: string;
  };
  deletion: {
    enabled: boolean;
    schedule: string;
    confirmation: boolean;
  };
}

export interface RetentionPolicy {
  name: string;
  dataType: 'database' | 'files' | 'logs' | 'configuration' | 'all';
  retentionDays: number;
  archiveAfter?: number;
  conditions?: {
    environment?: string[];
    size?: {
      min?: number; // MB
      max?: number; // MB
    };
    dateRange?: {
      start?: string;
      end?: string;
    };
  };
}

export interface EncryptionConfig {
  enabled: boolean;
  algorithm: 'aes-256-gcm' | 'aes-256-cbc' | 'chacha20-poly1305';
  keyRotation: {
    enabled: boolean;
    interval: number; // days
    keys: number; // number of keys to keep
  };
  transport: {
    enabled: boolean;
    protocol: 'tls-1.2' | 'tls-1.3';
  };
}

export interface MonitoringConfig {
  enabled: boolean;
  metrics: {
    collection: boolean;
    retention: number; // days
    aggregation: 'raw' | 'hourly' | 'daily';
  };
  status: {
    tracking: boolean;
    history: number; // days
  };
  dashboards: {
    enabled: boolean;
    provider: 'datadog' | 'prometheus' | 'cloudwatch';
  };
}

export interface AlertConfig {
  enabled: boolean;
  channels: AlertChannel[];
  thresholds: AlertThresholds;
  escalation: EscalationConfig;
}

export interface AlertChannel {
  type: 'email' | 'slack' | 'pagerduty' | 'teams' | 'webhook';
  name: string;
  config: Record<string, any>;
  enabled: boolean;
}

export interface AlertThresholds {
  failureRate: number; // percentage
  duration: number; // hours
  size: {
    warning: number; // GB
    critical: number; // GB
  };
  storage: {
    warning: number; // percentage
    critical: number; // percentage
  };
}

export interface EscalationConfig {
  enabled: boolean;
  levels: EscalationLevel[];
}

export interface EscalationLevel {
  delay: number; // minutes
  recipients: string[];
  channel: string;
}

export interface VerificationConfig {
  enabled: boolean;
  methods: ('checksum' | 'size' | 'content' | 'functional')[];
  schedule: string;
  sampleSize: number; // percentage
  integrity: {
    hash: 'sha256' | 'sha512' | 'md5';
    verify: boolean;
  };
}

export interface RecoveryConfig {
  pointInTime: {
    enabled: boolean;
    granularity: 'hourly' | 'daily' | 'weekly';
  };
  crossRegion: {
    enabled: boolean;
    regions: string[];
  };
  testing: {
    enabled: boolean;
    schedule: string;
    retention: number; // days
  };
}

// Environment-specific configurations
export const backupConfigs: Record<string, BackupConfig> = {
  dev: {
    environment: 'dev',
    schedule: {
      full: { enabled: true, cron: '0 2 * * 0', retention: 7 },
      incremental: { enabled: true, cron: '0 2 * * 1-6', retention: 3 },
      continuous: { enabled: false, interval: 60, retention: 1 }
    },
    storage: {
      provider: 'local',
      primary: { region: 'us-east-1', bucket: 'dev-backups', path: './backups/dev' },
      compression: { enabled: false, algorithm: 'gzip', level: 6 },
      parallel: { uploads: 1, downloads: 1 }
    },
    retention: {
      policies: [
        { name: 'dev-daily', dataType: 'all', retentionDays: 7 },
        { name: 'dev-weekly', dataType: 'all', retentionDays: 30, archiveAfter: 7 }
      ],
      archive: { after: 7, destination: 'archive-dev' },
      deletion: { enabled: true, schedule: '0 3 * * 1', confirmation: false }
    },
    encryption: {
      enabled: false,
      algorithm: 'aes-256-gcm',
      keyRotation: { enabled: false, interval: 90, keys: 2 },
      transport: { enabled: false, protocol: 'tls-1.2' }
    },
    monitoring: {
      enabled: true,
      metrics: { collection: true, retention: 7, aggregation: 'daily' },
      status: { tracking: true, history: 7 },
      dashboards: { enabled: false, provider: 'prometheus' }
    },
    alerting: {
      enabled: false,
      channels: [],
      thresholds: { failureRate: 50, duration: 2, size: { warning: 1, critical: 5 }, storage: { warning: 80, critical: 95 } },
      escalation: { enabled: false, levels: [] }
    },
    verification: {
      enabled: false,
      methods: ['size'],
      schedule: '0 4 * * *',
      sampleSize: 10,
      integrity: { hash: 'sha256', verify: false }
    },
    recovery: {
      pointInTime: { enabled: false, granularity: 'daily' },
      crossRegion: { enabled: false, regions: [] },
      testing: { enabled: false, schedule: '0 5 * * 0', retention: 30 }
    }
  },

  staging: {
    environment: 'staging',
    schedule: {
      full: { enabled: true, cron: '0 2 * * 0', retention: 14 },
      incremental: { enabled: true, cron: '0 2 * * 1-6', retention: 7 },
      continuous: { enabled: true, interval: 30, retention: 3 }
    },
    storage: {
      provider: 'aws-s3',
      primary: { region: 'us-east-1', bucket: 'staging-backups', path: '/staging' },
      secondary: { region: 'us-west-2', bucket: 'staging-backups-dr', path: '/staging' },
      compression: { enabled: true, algorithm: 'gzip', level: 6 },
      parallel: { uploads: 2, downloads: 2 }
    },
    retention: {
      policies: [
        { name: 'staging-daily', dataType: 'all', retentionDays: 14 },
        { name: 'staging-weekly', dataType: 'all', retentionDays: 60, archiveAfter: 14 }
      ],
      archive: { after: 14, destination: 'archive-staging' },
      deletion: { enabled: true, schedule: '0 3 * * 1', confirmation: true }
    },
    encryption: {
      enabled: true,
      algorithm: 'aes-256-gcm',
      keyRotation: { enabled: true, interval: 90, keys: 3 },
      transport: { enabled: true, protocol: 'tls-1.3' }
    },
    monitoring: {
      enabled: true,
      metrics: { collection: true, retention: 30, aggregation: 'daily' },
      status: { tracking: true, history: 30 },
      dashboards: { enabled: true, provider: 'prometheus' }
    },
    alerting: {
      enabled: true,
      channels: [
        { type: 'email', name: 'staging-team', config: { recipients: ['staging-team@company.com'] }, enabled: true }
      ],
      thresholds: { failureRate: 25, duration: 1, size: { warning: 2, critical: 10 }, storage: { warning: 75, critical: 90 } },
      escalation: { enabled: true, levels: [{ delay: 30, recipients: ['devops@company.com'], channel: 'email' }] }
    },
    verification: {
      enabled: true,
      methods: ['checksum', 'size'],
      schedule: '0 4 * * *',
      sampleSize: 25,
      integrity: { hash: 'sha256', verify: true }
    },
    recovery: {
      pointInTime: { enabled: true, granularity: 'hourly' },
      crossRegion: { enabled: true, regions: ['us-west-2'] },
      testing: { enabled: true, schedule: '0 5 * * 0', retention: 60 }
    }
  },

  production: {
    environment: 'production',
    schedule: {
      full: { enabled: true, cron: '0 1 * * 0', retention: 90 },
      incremental: { enabled: true, cron: '0 1 * * 1-6', retention: 30 },
      continuous: { enabled: true, interval: 15, retention: 7 }
    },
    storage: {
      provider: 'aws-dynamodb',
      primary: { region: 'us-east-1', bucket: 'prod-backups-primary', path: '/production' },
      secondary: { region: 'us-west-2', bucket: 'prod-backups-secondary', path: '/production' },
      archive: { region: 'us-east-2', bucket: 'prod-backups-archive', path: '/production' },
      compression: { enabled: true, algorithm: 'zstd', level: 9 },
      parallel: { uploads: 8, downloads: 8 }
    },
    retention: {
      policies: [
        { name: 'prod-daily', dataType: 'all', retentionDays: 30 },
        { name: 'prod-weekly', dataType: 'all', retentionDays: 180, archiveAfter: 30 },
        { name: 'prod-monthly', dataType: 'all', retentionDays: 365, archiveAfter: 180 },
        { name: 'prod-yearly', dataType: 'all', retentionDays: 2555, archiveAfter: 365 }
      ],
      archive: { after: 90, destination: 'archive-production' },
      deletion: { enabled: true, schedule: '0 2 * * 1', confirmation: true }
    },
    encryption: {
      enabled: true,
      algorithm: 'aes-256-gcm',
      keyRotation: { enabled: true, interval: 30, keys: 5 },
      transport: { enabled: true, protocol: 'tls-1.3' }
    },
    monitoring: {
      enabled: true,
      metrics: { collection: true, retention: 365, aggregation: 'daily' },
      status: { tracking: true, history: 365 },
      dashboards: { enabled: true, provider: 'datadog' }
    },
    alerting: {
      enabled: true,
      channels: [
        { type: 'pagerduty', name: 'primary', config: { serviceId: 'prod-backup-primary' }, enabled: true },
        { type: 'slack', name: 'operations', config: { webhook: process.env.SLACK_WEBHOOK_URL }, enabled: true },
        { type: 'email', name: 'management', config: { recipients: ['ops-management@company.com'] }, enabled: true }
      ],
      thresholds: { failureRate: 10, duration: 0.5, size: { warning: 5, critical: 20 }, storage: { warning: 70, critical: 85 } },
      escalation: { 
        enabled: true, 
        levels: [
          { delay: 15, recipients: ['devops@company.com'], channel: 'slack' },
          { delay: 30, recipients: ['oncall@company.com'], channel: 'pagerduty' },
          { delay: 60, recipients: ['management@company.com'], channel: 'email' }
        ]
      }
    },
    verification: {
      enabled: true,
      methods: ['checksum', 'size', 'content', 'functional'],
      schedule: '0 3 * * *',
      sampleSize: 100,
      integrity: { hash: 'sha512', verify: true }
    },
    recovery: {
      pointInTime: { enabled: true, granularity: 'hourly' },
      crossRegion: { enabled: true, regions: ['us-west-2', 'eu-west-1'] },
      testing: { enabled: true, schedule: '0 4 * * 0', retention: 90 }
    }
  }
};

// Utility functions
export function getBackupConfig(environment: string): BackupConfig {
  const config = backupConfigs[environment];
  if (!config) {
    throw new Error(`No backup configuration found for environment: ${environment}`);
  }
  return config;
}

export function getCurrentBackupConfig(): BackupConfig {
  const environment = process.env.NODE_ENV || 'development';
  return getBackupConfig(environment);
}

export function validateBackupConfig(config: BackupConfig): boolean {
  const errors: string[] = [];

  // Validate schedule
  if (!config.schedule.full.enabled && !config.schedule.incremental.enabled && !config.schedule.continuous.enabled) {
    errors.push('At least one backup type must be enabled');
  }

  // Validate storage
  if (!config.storage.primary.bucket || !config.storage.primary.path) {
    errors.push('Primary storage configuration is incomplete');
  }

  // Validate retention
  if (!config.retention.policies || config.retention.policies.length === 0) {
    errors.push('At least one retention policy must be defined');
  }

  // Validate encryption for production
  if (config.environment === 'production' && !config.encryption.enabled) {
    errors.push('Encryption must be enabled in production');
  }

  if (errors.length > 0) {
    console.error('Backup configuration validation errors:', errors);
    return false;
  }

  return true;
}

export default backupConfigs;