# Backup Configuration

This directory contains comprehensive backup and recovery configuration for different environments (development, staging, production). The configuration is split into focused modules that can be imported and used independently or together.

## Files Overview

### 1. `backup.config.ts` - Main Backup Configuration
Central configuration file that defines backup settings, policies, and environment-specific configurations.

**Key Features:**
- Environment-specific configurations (dev, staging, production)
- Backup scheduling (full, incremental, continuous)
- Storage configuration (AWS S3, DynamoDB, local storage)
- Retention policies
- Encryption settings
- Monitoring and alerting integration
- Recovery configuration

**Usage:**
```typescript
import { getBackupConfig, getCurrentBackupConfig } from './backup.config';

// Get config for specific environment
const prodConfig = getBackupConfig('production');

// Get config for current environment
const currentConfig = getCurrentBackupConfig();

// Validate configuration
import { validateBackupConfig } from './backup.config';
const isValid = validateBackupConfig(config);
```

### 2. `retention-policies.ts` - Data Retention Management
Manages data retention schedules, archive policies, and cleanup procedures.

**Key Features:**
- Environment-specific retention rules
- Archive configuration
- Automated cleanup schedules
- Compliance-based retention
- Exception handling for critical data

**Usage:**
```typescript
import { 
  getRetentionPolicies, 
  getRetentionSchedule, 
  getArchiveConfig,
  evaluateRetentionRule 
} from './retention-policies';

// Get retention policies for environment
const policies = getRetentionPolicies('production');

// Check if backup matches retention rule
const shouldRetain = evaluateRetentionRule(rule, backupMetadata);
```

### 3. `backup-encryption.ts` - Secure Backup Handling
Configuration for encryption at rest and in transit, key management, and compliance.

**Key Features:**
- Multiple encryption algorithms (AES-256-GCM, ChaCha20-Poly1305)
- AWS KMS, HashiCorp Vault, Azure Key Vault integration
- Key rotation policies
- Transport encryption (TLS 1.2/1.3)
- FIPS-140-2 compliance
- Performance optimization

**Usage:**
```typescript
import { getEncryptionConfig, isEncryptionRequired } from './backup-encryption';

const encryptionConfig = getEncryptionConfig('production');
const requiresEncryption = isEncryptionRequired('production');
```

### 4. `backup-monitoring.ts` - Backup Operation Monitoring
Comprehensive monitoring and metrics collection for backup operations.

**Key Features:**
- Real-time metrics collection
- Multiple monitoring backends (Datadog, Prometheus, CloudWatch)
- Custom dashboards
- Performance profiling
- Compliance monitoring
- Health checks

**Usage:**
```typescript
import { getMonitoringConfig, isMonitoringEnabled } from './backup-monitoring';

const monitoringConfig = getMonitoringConfig('staging');
const monitoringActive = isMonitoringEnabled('production');
```

### 5. `backup-alerts.ts` - Backup Failure Alerting
Comprehensive alerting system for backup failures and system monitoring.

**Key Features:**
- Multi-channel alerting (Email, Slack, PagerDuty, Teams)
- Severity-based escalation
- Alert suppression during maintenance
- Compliance-specific alerts
- Quiet hours configuration
- Alert templates and customization

**Usage:**
```typescript
import { 
  getAlertConfig, 
  getAlertRules, 
  evaluateAlertCondition 
} from './backup-alerts';

const alertConfig = getAlertConfig('production');
const activeRules = getAlertRules('production');
```

## Environment Configurations

### Development Environment
- **Encryption**: Disabled for development convenience
- **Monitoring**: Basic metrics, console logging
- **Alerting**: Disabled or minimal notifications
- **Retention**: Short-term retention (7-14 days)
- **Storage**: Local storage or development S3 bucket

### Staging Environment
- **Encryption**: AES-256-GCM with AWS KMS
- **Monitoring**: Full metrics, Prometheus/Grafana dashboards
- **Alerting**: Team notifications via email and Slack
- **Retention**: Medium-term retention (30-90 days)
- **Storage**: Staging S3 with cross-region replication

### Production Environment
- **Encryption**: AES-256-GCM with AWS KMS, mandatory key rotation
- **Monitoring**: Enterprise monitoring (Datadog, CloudWatch)
- **Alerting**: 24/7 monitoring with PagerDuty escalation
- **Retention**: Long-term retention (1-7 years) with compliance
- **Storage**: Multi-region S3 with archival to Glacier

## Quick Start

### 1. Import Configuration
```typescript
import { getCurrentBackupConfig } from './backup/backup.config';
import { getAlertConfig } from './backup/backup-alerts';
import { getMonitoringConfig } from './backup/backup-monitoring';

// Initialize backup configuration
const backupConfig = getCurrentBackupConfig();
const alertConfig = getAlertConfig(backupConfig.environment);
const monitoringConfig = getMonitoringConfig(backupConfig.environment);
```

### 2. Validate Configuration
```typescript
import { validateBackupConfig } from './backup/backup.config';
import { validateAlertConfig } from './backup/backup-alerts';
import { validateMonitoringConfig } from './backup/backup-monitoring';

const backupValidation = validateBackupConfig(backupConfig);
const alertValidation = validateAlertConfig(alertConfig);
const monitoringValidation = validateMonitoringConfig(monitoringConfig);

if (!backupValidation.valid) {
  console.error('Backup configuration errors:', backupValidation.errors);
}
```

### 3. Apply Configuration
```typescript
// Example: Initialize backup service with configuration
import { BackupService } from './backup-service';

const backupService = new BackupService({
  config: backupConfig,
  alerts: alertConfig,
  monitoring: monitoringConfig
});

await backupService.initialize();
```

## Configuration Structure

```
config/backup/
├── backup.config.ts           # Main configuration
├── retention-policies.ts      # Data retention rules
├── backup-encryption.ts       # Encryption settings
├── backup-monitoring.ts       # Monitoring configuration
├── backup-alerts.ts          # Alerting configuration
└── README.md                 # This file
```

## Environment Variables

Set these environment variables for production configurations:

```bash
# AWS Configuration
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key
AWS_REGION=us-east-1

# Key Management
PRODUCTION_KMS_KEY_ID=arn:aws:kms:...
STAGING_KMS_KEY_ID=arn:aws:kms:...

# Alerting Channels
PAGERDUTY_SERVICE_ID=your_service_id
PAGERDUTY_INTEGRATION_KEY=your_integration_key
SLACK_WEBHOOK_URL=https://hooks.slack.com/...
PROD_SLACK_WEBHOOK_URL=https://hooks.slack.com/...
STAGING_SLACK_WEBHOOK_URL=https://hooks.slack.com/...

# Monitoring
DATADOG_API_KEY=your_datadog_api_key
SPLUNK_ENDPOINT=https://splunk.company.com:8088
SPLUNK_TOKEN=your_splunk_token
ELASTICSEARCH_ENDPOINT=https://elasticsearch.company.com

# Storage
S3_BUCKET_PRODUCTION=prod-backups-primary
S3_BUCKET_STAGING=staging-backups
S3_BUCKET_DEV=dev-backups
```

## Best Practices

### 1. Environment Isolation
- Use separate configurations for each environment
- Never use production keys in development
- Validate configurations before deployment

### 2. Security
- Always enable encryption in production
- Use key rotation policies
- Implement proper access controls
- Enable audit logging

### 3. Monitoring
- Set up comprehensive monitoring
- Configure appropriate alerting thresholds
- Regular review of monitoring data
- Test alerting channels regularly

### 4. Backup Verification
- Implement automated backup verification
- Regular restore testing
- Monitor backup success rates
- Track storage usage

### 5. Compliance
- Ensure configurations meet regulatory requirements
- Regular compliance audits
- Document retention policies
- Implement data classification

## Integration Examples

### With Express.js Application
```typescript
import express from 'express';
import { getCurrentBackupConfig } from './config/backup/backup.config';

const app = express();
const backupConfig = getCurrentBackupConfig();

// Use configuration in your application
app.get('/backup/status', (req, res) => {
  res.json({
    environment: backupConfig.environment,
    backupEnabled: backupConfig.schedule.full.enabled,
    encryptionEnabled: backupConfig.encryption.enabled
  });
});
```

### With AWS Lambda
```typescript
import { getBackupConfig } from './config/backup/backup.config';

export const handler = async (event: any) => {
  const environment = process.env.AWS_LAMBDA_FUNCTION_NAME?.includes('prod') ? 'production' : 'staging';
  const config = getBackupConfig(environment);
  
  // Use configuration in Lambda function
  return {
    statusCode: 200,
    body: JSON.stringify(config)
  };
};
```

### With Docker/Kubernetes
```typescript
import { getCurrentBackupConfig } from './config/backup/backup.config';

const config = getCurrentBackupConfig();

// Use environment-specific configuration
if (config.environment === 'production') {
  // Production-specific setup
  enableProductionFeatures(config);
} else {
  // Development/staging setup
  enableDevelopmentFeatures(config);
}
```

## Testing

Test configurations in your CI/CD pipeline:

```typescript
import { validateBackupConfig } from './config/backup/backup.config';
import { validateAlertConfig } from './config/backup/backup-alerts';

describe('Backup Configuration', () => {
  test('production config is valid', () => {
    const config = getBackupConfig('production');
    expect(validateBackupConfig(config)).toBe(true);
  });
  
  test('alert config is valid', () => {
    const config = getAlertConfig('production');
    expect(validateAlertConfig(config).valid).toBe(true);
  });
});
```

## Troubleshooting

### Common Issues

1. **Configuration Validation Failures**
   - Check environment variables
   - Verify all required fields are present
   - Ensure encryption is enabled in production

2. **Alert Delivery Issues**
   - Verify webhook URLs and API keys
   - Check channel configurations
   - Test alert rules in development first

3. **Monitoring Integration Problems**
   - Confirm monitoring service credentials
   - Check network connectivity
   - Verify endpoint configurations

### Debug Configuration
```typescript
import { getCurrentBackupConfig } from './config/backup/backup.config';

const config = getCurrentBackupConfig();
console.log('Backup Configuration:', JSON.stringify(config, null, 2));
```

## Support

For issues or questions about backup configurations:
- Review the configuration files for detailed comments
- Check the environment-specific documentation
- Validate configurations using the provided validation functions
- Test in non-production environments first

## License

This configuration is part of the CloudPilot project and follows the same licensing terms.