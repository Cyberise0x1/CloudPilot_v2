/**
 * Retention Policies Configuration
 * Manages data retention schedules and policies for backups
 */

import { RetentionPolicy } from './backup.config';

export interface RetentionRule {
  id: string;
  name: string;
  description: string;
  priority: number; // Higher number = higher priority
  match: RetentionMatch;
  retention: RetentionPeriod;
  action: 'keep' | 'archive' | 'delete';
  conditions?: RetentionCondition[];
}

export interface RetentionMatch {
  dataType?: ('database' | 'files' | 'logs' | 'configuration' | 'artifacts' | 'all')[];
  environment?: ('dev' | 'staging' | 'production' | 'all')[];
  pathPatterns?: string[];
  sizeRange?: {
    min: number; // MB
    max: number; // MB
  };
  ageRange?: {
    min: number; // days
    max: number; // days
  };
  tags?: Record<string, string>;
  metadata?: Record<string, any>;
}

export interface RetentionPeriod {
  immediate: number; // days to keep in primary storage
  archive?: number; // days to keep in archive after immediate
  total: number; // total retention period in days
}

export interface RetentionCondition {
  type: 'time' | 'size' | 'count' | 'threshold';
  operator: 'equals' | 'greaterThan' | 'lessThan' | 'between';
  value: any;
  action?: 'keep' | 'delete' | 'archive';
}

export interface RetentionSchedule {
  id: string;
  name: string;
  cron: string;
  rules: string[]; // Rule IDs to apply
  dryRun: boolean;
  batchSize: number;
  enabled: boolean;
}

export interface ArchiveConfig {
  enabled: boolean;
  destination: {
    type: 's3' | 'glacier' | 'cold-storage' | 'local';
    location: string;
    region?: string;
    tier?: 'standard' | 'infrequent' | 'archive';
  };
  compression: {
    enabled: boolean;
    algorithm: 'gzip' | 'lz4' | 'zstd';
  };
  encryption: {
    enabled: boolean;
    algorithm: string;
  };
  verification: {
    enabled: boolean;
    checksum: boolean;
  };
}

export interface CleanupConfig {
  enabled: boolean;
  schedule: string;
  batchSize: number;
  delay: number; // minutes to wait before deletion
  confirmationRequired: boolean;
  notifyBefore: {
    enabled: boolean;
    schedule: string; // when to send notifications
  };
  exceptions: {
    critical: string[]; // patterns for critical data that should never be deleted
    flagged: string[]; // patterns for flagged items
  };
}

// Environment-specific retention policies
export const retentionPolicies: Record<string, RetentionRule[]> = {
  dev: [
    {
      id: 'dev-short-term',
      name: 'Development Short-term Retention',
      description: 'Keep development backups for short periods due to frequent changes',
      priority: 1,
      match: {
        dataType: ['all'],
        environment: ['dev']
      },
      retention: {
        immediate: 7,
        total: 7
      },
      action: 'delete',
      conditions: []
    },
    {
      id: 'dev-test-results',
      name: 'Development Test Results',
      description: 'Test results and logs for debugging',
      priority: 2,
      match: {
        dataType: ['logs'],
        environment: ['dev'],
        pathPatterns: ['*/test-results/*', '*/logs/test/*']
      },
      retention: {
        immediate: 14,
        total: 14
      },
      action: 'delete'
    },
    {
      id: 'dev-artifacts',
      name: 'Development Artifacts',
      description: 'Build artifacts and temporary files',
      priority: 3,
      match: {
        dataType: ['artifacts'],
        environment: ['dev'],
        pathPatterns: ['*/build/*', '*/dist/*', '*/temp/*']
      },
      retention: {
        immediate: 3,
        total: 3
      },
      action: 'delete'
    }
  ],

  staging: [
    {
      id: 'staging-operational',
      name: 'Staging Operational Retention',
      description: 'Standard operational backup retention for staging',
      priority: 1,
      match: {
        dataType: ['database', 'files'],
        environment: ['staging']
      },
      retention: {
        immediate: 14,
        archive: 30,
        total: 44
      },
      action: 'archive'
    },
    {
      id: 'staging-logs',
      name: 'Staging Logs Retention',
      description: 'Application and system logs for staging',
      priority: 2,
      match: {
        dataType: ['logs'],
        environment: ['staging']
      },
      retention: {
        immediate: 7,
        archive: 14,
        total: 21
      },
      action: 'archive'
    },
    {
      id: 'staging-config',
      name: 'Staging Configuration',
      description: 'Configuration files and settings',
      priority: 3,
      match: {
        dataType: ['configuration'],
        environment: ['staging']
      },
      retention: {
        immediate: 30,
        archive: 60,
        total: 90
      },
      action: 'archive'
    },
    {
      id: 'staging-release',
      name: 'Staging Release Backups',
      description: 'Pre-production release backups',
      priority: 4,
      match: {
        dataType: ['all'],
        environment: ['staging'],
        tags: { backupType: 'release' }
      },
      retention: {
        immediate: 60,
        archive: 90,
        total: 150
      },
      action: 'archive'
    }
  ],

  production: [
    {
      id: 'prod-critical-daily',
      name: 'Production Critical Daily',
      description: 'Critical production data - daily retention',
      priority: 1,
      match: {
        dataType: ['database'],
        environment: ['production'],
        tags: { critical: 'true', tier: 'primary' }
      },
      retention: {
        immediate: 30,
        archive: 90,
        total: 365
      },
      action: 'archive',
      conditions: [
        {
          type: 'size',
          operator: 'greaterThan',
          value: 1024, // 1GB
          action: 'keep'
        }
      ]
    },
    {
      id: 'prod-operational',
      name: 'Production Operational',
      description: 'Standard production operational data',
      priority: 2,
      match: {
        dataType: ['database', 'files'],
        environment: ['production']
      },
      retention: {
        immediate: 30,
        archive: 180,
        total: 365
      },
      action: 'archive'
    },
    {
      id: 'prod-logs-recent',
      name: 'Production Recent Logs',
      description: 'Recent production logs for troubleshooting',
      priority: 3,
      match: {
        dataType: ['logs'],
        environment: ['production'],
        ageRange: { min: 0, max: 90 }
      },
      retention: {
        immediate: 30,
        archive: 90,
        total: 120
      },
      action: 'archive'
    },
    {
      id: 'prod-logs-archive',
      name: 'Production Archive Logs',
      description: 'Archived production logs for compliance',
      priority: 4,
      match: {
        dataType: ['logs'],
        environment: ['production'],
        ageRange: { min: 90, max: 2555 } // 7 years
      },
      retention: {
        immediate: 0,
        archive: 2555,
        total: 2555
      },
      action: 'archive'
    },
    {
      id: 'prod-config-versions',
      name: 'Production Configuration Versions',
      description: 'Configuration version history for audit',
      priority: 5,
      match: {
        dataType: ['configuration'],
        environment: ['production']
      },
      retention: {
        immediate: 90,
        archive: 2555,
        total: 2555
      },
      action: 'archive',
      conditions: [
        {
          type: 'threshold',
          operator: 'greaterThan',
          value: 2555,
          action: 'keep'
        }
      ]
    },
    {
      id: 'prod-compliance',
      name: 'Production Compliance Data',
      description: 'Regulatory and compliance required backups',
      priority: 6,
      match: {
        dataType: ['all'],
        environment: ['production'],
        tags: { compliance: 'required' }
      },
      retention: {
        immediate: 365,
        archive: 2555,
        total: 2555 // 7 years
      },
      action: 'archive',
      conditions: [
        {
          type: 'count',
          operator: 'greaterThan',
          value: 1,
          action: 'keep'
        }
      ],
      exceptions: {
        critical: ['compliance'],
        flagged: ['audit', 'regulatory']
      }
    },
    {
      id: 'prod-disaster-recovery',
      name: 'Production Disaster Recovery',
      description: 'Long-term disaster recovery backups',
      priority: 7,
      match: {
        dataType: ['all'],
        environment: ['production'],
        tags: { backupType: 'disaster-recovery' }
      },
      retention: {
        immediate: 90,
        archive: 3650,
        total: 3650 // 10 years
      },
      action: 'archive',
      conditions: [
        {
          type: 'time',
          operator: 'equals',
          value: 0,
          action: 'keep'
        }
      ]
    }
  ]
};

// Retention schedules
export const retentionSchedules: Record<string, RetentionSchedule[]> = {
  dev: [
    {
      id: 'dev-daily-cleanup',
      name: 'Daily Development Cleanup',
      cron: '0 3 * * *',
      rules: ['dev-short-term', 'dev-test-results', 'dev-artifacts'],
      dryRun: false,
      batchSize: 100,
      enabled: true
    }
  ],

  staging: [
    {
      id: 'staging-daily-retention',
      name: 'Daily Staging Retention',
      cron: '0 4 * * *',
      rules: ['staging-operational', 'staging-logs'],
      dryRun: false,
      batchSize: 500,
      enabled: true
    },
    {
      id: 'staging-weekly-archive',
      name: 'Weekly Staging Archive',
      cron: '0 2 * * 0',
      rules: ['staging-config', 'staging-release'],
      dryRun: false,
      batchSize: 200,
      enabled: true
    }
  ],

  production: [
    {
      id: 'prod-hourly-retention',
      name: 'Hourly Production Retention',
      cron: '0 * * * *',
      rules: ['prod-critical-daily'],
      dryRun: false,
      batchSize: 1000,
      enabled: true
    },
    {
      id: 'prod-daily-retention',
      name: 'Daily Production Retention',
      cron: '0 1 * * *',
      rules: ['prod-operational', 'prod-logs-recent'],
      dryRun: false,
      batchSize: 2000,
      enabled: true
    },
    {
      id: 'prod-weekly-archive',
      name: 'Weekly Production Archive',
      cron: '0 2 * * 0',
      rules: ['prod-logs-archive', 'prod-config-versions'],
      dryRun: false,
      batchSize: 500,
      enabled: true
    },
    {
      id: 'prod-monthly-compliance',
      name: 'Monthly Compliance Review',
      cron: '0 3 1 * *',
      rules: ['prod-compliance', 'prod-disaster-recovery'],
      dryRun: true, // Always dry run for compliance data
      batchSize: 100,
      enabled: true
    }
  ]
};

// Archive configurations by environment
export const archiveConfigs: Record<string, ArchiveConfig> = {
  dev: {
    enabled: false,
    destination: {
      type: 'local',
      location: './backups/archive/dev'
    },
    compression: { enabled: false, algorithm: 'gzip' },
    encryption: { enabled: false, algorithm: 'none' },
    verification: { enabled: false, checksum: false }
  },

  staging: {
    enabled: true,
    destination: {
      type: 's3',
      location: 's3://staging-archive-bucket',
      region: 'us-east-1',
      tier: 'infrequent'
    },
    compression: { enabled: true, algorithm: 'gzip' },
    encryption: { enabled: true, algorithm: 'AES-256' },
    verification: { enabled: true, checksum: true }
  },

  production: {
    enabled: true,
    destination: {
      type: 'glacier',
      location: 's3://prod-archive-glacier',
      region: 'us-east-1',
      tier: 'archive'
    },
    compression: { enabled: true, algorithm: 'zstd' },
    encryption: { enabled: true, algorithm: 'AES-256-GCM' },
    verification: { enabled: true, checksum: true }
  }
};

// Cleanup configurations
export const cleanupConfigs: Record<string, CleanupConfig> = {
  dev: {
    enabled: true,
    schedule: '0 5 * * *',
    batchSize: 500,
    delay: 0,
    confirmationRequired: false,
    notifyBefore: {
      enabled: false,
      schedule: ''
    },
    exceptions: {
      critical: ['*.db', '*.sql'],
      flagged: []
    }
  },

  staging: {
    enabled: true,
    schedule: '0 6 * * *',
    batchSize: 1000,
    delay: 60,
    confirmationRequired: true,
    notifyBefore: {
      enabled: true,
      schedule: '0 5 * * *'
    },
    exceptions: {
      critical: ['production-data/*', 'customer-data/*'],
      flagged: ['flagged-*', 'quarantine-*']
    }
  },

  production: {
    enabled: true,
    schedule: '0 4 * * *',
    batchSize: 2000,
    delay: 1440, // 24 hours
    confirmationRequired: true,
    notifyBefore: {
      enabled: true,
      schedule: '0 2 * * *'
    },
    exceptions: {
      critical: [
        'compliance/*',
        'audit/*',
        'regulatory/*',
        'disaster-recovery/*',
        'customer-data/*'
      ],
      flagged: [
        'flagged-*',
        'legal-hold-*',
        'investigation-*'
      ]
    }
  }
};

// Utility functions
export function getRetentionPolicies(environment: string): RetentionRule[] {
  const policies = retentionPolicies[environment];
  if (!policies) {
    throw new Error(`No retention policies found for environment: ${environment}`);
  }
  return policies.sort((a, b) => b.priority - a.priority);
}

export function getRetentionSchedule(environment: string, scheduleId: string): RetentionSchedule | null {
  const schedules = retentionSchedules[environment] || [];
  return schedules.find(s => s.id === scheduleId) || null;
}

export function getAllRetentionSchedules(environment: string): RetentionSchedule[] {
  return retentionSchedules[environment] || [];
}

export function getArchiveConfig(environment: string): ArchiveConfig {
  const config = archiveConfigs[environment];
  if (!config) {
    throw new Error(`No archive configuration found for environment: ${environment}`);
  }
  return config;
}

export function getCleanupConfig(environment: string): CleanupConfig {
  const config = cleanupConfigs[environment];
  if (!config) {
    throw new Error(`No cleanup configuration found for environment: ${environment}`);
  }
  return config;
}

export function evaluateRetentionRule(
  rule: RetentionRule,
  backupMetadata: Record<string, any>
): boolean {
  const match = rule.match;
  
  // Check data type
  if (match.dataType && !match.dataType.includes('all')) {
    if (!match.dataType.includes(backupMetadata.dataType)) {
      return false;
    }
  }
  
  // Check environment
  if (match.environment && !match.environment.includes('all')) {
    if (!match.environment.includes(backupMetadata.environment)) {
      return false;
    }
  }
  
  // Check path patterns
  if (match.pathPatterns && match.pathPatterns.length > 0) {
    const matchesPattern = match.pathPatterns.some(pattern => {
      const regex = new RegExp(pattern.replace(/\*/g, '.*'));
      return regex.test(backupMetadata.path || '');
    });
    if (!matchesPattern) {
      return false;
    }
  }
  
  // Check size range
  if (match.sizeRange) {
    const sizeMB = (backupMetadata.size || 0) / (1024 * 1024);
    if (match.sizeRange.min && sizeMB < match.sizeRange.min) return false;
    if (match.sizeRange.max && sizeMB > match.sizeRange.max) return false;
  }
  
  // Check age range
  if (match.ageRange) {
    const ageDays = (Date.now() - new Date(backupMetadata.createdAt).getTime()) / (1000 * 60 * 60 * 24);
    if (match.ageRange.min && ageDays < match.ageRange.min) return false;
    if (match.ageRange.max && ageDays > match.ageRange.max) return false;
  }
  
  // Check tags
  if (match.tags) {
    for (const [key, value] of Object.entries(match.tags)) {
      if (backupMetadata.tags?.[key] !== value) {
        return false;
      }
    }
  }
  
  return true;
}

export function calculateRetentionPeriod(
  rule: RetentionRule,
  currentDate: Date = new Date()
): Date {
  const retention = rule.retention;
  return new Date(currentDate.getTime() + retention.total * 24 * 60 * 60 * 1000);
}

export function shouldArchive(rule: RetentionRule, backupAgeDays: number): boolean {
  return rule.action === 'archive' && 
         rule.retention.archive !== undefined && 
         backupAgeDays >= rule.retention.immediate;
}

export function shouldDelete(rule: RetentionRule, backupAgeDays: number): boolean {
  return rule.action === 'delete' || backupAgeDays >= rule.retention.total;
}

export default {
  retentionPolicies,
  retentionSchedules,
  archiveConfigs,
  cleanupConfigs
};