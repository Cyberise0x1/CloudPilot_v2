#!/bin/bash
###############################################################################
# Database Backup Scripts - Installation and Setup Script
###############################################################################

set -euo pipefail

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
INSTALL_DIR="/opt/backup-scripts"
USER_NAME="backup"
USER_GROUP="backup"
LOG_DIR="/var/log/backup-scripts"
SERVICE_NAME="backup-scheduler"

# Helper functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_error "This script must be run as root"
        exit 1
    fi
}

detect_os() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        OS=$NAME
        VER=$VERSION_ID
    else
        log_error "Cannot detect operating system"
        exit 1
    fi
}

install_dependencies() {
    log_step "Installing system dependencies..."
    
    if [[ "$OS" == *"Ubuntu"* ]] || [[ "$OS" == *"Debian"* ]]; then
        apt-get update
        apt-get install -y \
            curl \
            wget \
            gnupg \
            ca-certificates \
            lsb-release \
            postgresql-client \
            awscli \
            nodejs \
            npm \
            cron
    elif [[ "$OS" == *"CentOS"* ]] || [[ "$OS" == *"Red Hat"* ]]; then
        yum update -y
        yum install -y \
            curl \
            wget \
            gnupg2 \
            ca-certificates \
            postgresql \
            awscli \
            nodejs \
            npm \
            cronie
    else
        log_error "Unsupported operating system: $OS"
        exit 1
    fi
}

install_nodejs() {
    log_step "Installing Node.js LTS..."
    
    if ! command -v node &> /dev/null; then
        curl -fsSL https://deb.nodesource.com/setup_lts.x | bash -
        
        if [[ "$OS" == *"Ubuntu"* ]] || [[ "$OS" == *"Debian"* ]]; then
            apt-get install -y nodejs
        elif [[ "$OS" == *"CentOS"* ]] || [[ "$OS" == *"Red Hat"* ]]; then
            yum install -y nodejs
        fi
    else
        log_info "Node.js already installed: $(node --version)"
    fi
}

create_backup_user() {
    log_step "Creating backup user and group..."
    
    if ! getent group $USER_GROUP > /dev/null 2>&1; then
        groupadd --system $USER_GROUP
        log_info "Created group: $USER_GROUP"
    fi
    
    if ! getent passwd $USER_NAME > /dev/null 2>&1; then
        useradd --system --gid $USER_GROUP --shell /bin/bash \
                --home $INSTALL_DIR --create-home $USER_NAME
        log_info "Created user: $USER_NAME"
    fi
}

setup_directories() {
    log_step "Setting up directories..."
    
    mkdir -p $INSTALL_DIR
    mkdir -p $LOG_DIR
    mkdir -p /etc/backup-scripts
    
    # Set ownership
    chown -R $USER_NAME:$USER_GROUP $INSTALL_DIR
    chown -R $USER_NAME:$USER_GROUP $LOG_DIR
    
    # Set permissions
    chmod 750 $INSTALL_DIR
    chmod 750 $LOG_DIR
    
    log_info "Created directories: $INSTALL_DIR, $LOG_DIR"
}

install_backup_scripts() {
    log_step "Installing backup scripts..."
    
    # Copy scripts to installation directory
    cp -r . $INSTALL_DIR/
    chown -R $USER_NAME:$USER_GROUP $INSTALL_DIR
    
    # Install Node.js dependencies
    cd $INSTALL_DIR
    sudo -u $USER_NAME npm install --production
    
    # Make shell scripts executable
    chmod +x $INSTALL_DIR/backup.sh
    chmod +x $INSTALL_DIR/*.ts
    
    log_info "Backup scripts installed to: $INSTALL_DIR"
}

create_environment_file() {
    log_step "Creating environment configuration file..."
    
    if [[ ! -f /etc/backup-scripts/.env ]]; then
        cp $INSTALL_DIR/.env.example /etc/backup-scripts/.env
        chown $USER_NAME:$USER_GROUP /etc/backup-scripts/.env
        chmod 600 /etc/backup-scripts/.env
        
        log_warn "Please edit /etc/backup-scripts/.env with your database and AWS configuration"
    else
        log_info "Environment file already exists: /etc/backup-scripts/.env"
    fi
}

create_systemd_service() {
    log_step "Creating systemd service..."
    
    cat > /etc/systemd/system/$SERVICE_NAME.service << EOF
[Unit]
Description=Database Backup Scheduler
After=network.target postgresql.service

[Service]
Type=simple
User=$USER_NAME
Group=$USER_GROUP
WorkingDirectory=$INSTALL_DIR
EnvironmentFile=/etc/backup-scripts/.env
ExecStart=/usr/bin/npm run scheduler:start
ExecStop=/usr/bin/npm run scheduler:stop
Restart=always
RestartSec=10
StandardOutput=append:$LOG_DIR/service.log
StandardError=append:$LOG_DIR/service-error.log

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable $SERVICE_NAME
    
    log_info "Created systemd service: $SERVICE_NAME"
}

setup_logrotate() {
    log_step "Setting up log rotation..."
    
    cat > /etc/logrotate.d/backup-scripts << EOF
$LOG_DIR/*.log {
    daily
    missingok
    rotate 30
    compress
    notifempty
    create 644 $USER_NAME $USER_GROUP
    postrotate
        systemctl reload $SERVICE_NAME > /dev/null 2>&1 || true
    endscript
}
EOF

    log_info "Configured log rotation for: $LOG_DIR"
}

setup_cron_jobs() {
    log_step "Setting up cron jobs..."
    
    # Add cron jobs for backup execution
    cat > /etc/cron.d/backup-scripts << EOF
# Database backup cron jobs
# Daily full backup at 2 AM
0 2 * * * $USER_NAME cd $INSTALL_DIR && /usr/bin/npm run backup:full >> $LOG_DIR/daily-backup.log 2>&1

# Hourly incremental backups (during business hours)
0 8-18 * * 1-5 $USER_NAME cd $INSTALL_DIR && /usr/bin/npm run backup:incremental >> $LOG_DIR/hourly-backup.log 2>&1

# Weekly validation on Sundays at 3 AM
0 3 * * 0 $USER_NAME cd $INSTALL_DIR && /usr/bin/npm run validate:report >> $LOG_DIR/weekly-validation.log 2>&1
EOF

    chmod 644 /etc/cron.d/backup-scripts
    
    log_info "Configured cron jobs for automated backups"
}

create_test_script() {
    log_step "Creating test script..."
    
    cat > $INSTALL_DIR/test-backup.sh << 'EOF'
#!/bin/bash

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

log "Starting backup test..."

# Test database connection
if command -v psql &> /dev/null; then
    log "Testing PostgreSQL connection..."
    psql -l > /dev/null 2>&1 && log "✓ PostgreSQL connection successful" || log "✗ PostgreSQL connection failed"
else
    log "⚠ PostgreSQL client not found"
fi

# Test AWS CLI
if command -v aws &> /dev/null; then
    log "Testing AWS CLI..."
    aws sts get-caller-identity > /dev/null 2>&1 && log "✓ AWS CLI configured" || log "✗ AWS CLI not configured"
else
    log "⚠ AWS CLI not found"
fi

# Test Node.js scripts
cd "$(dirname "$0")"

log "Testing backup script..."
npm run backup:full -- --help > /dev/null 2>&1 && log "✓ Backup script working" || log "✗ Backup script failed"

log "Testing validation script..."
npm run validate -- --help > /dev/null 2>&1 && log "✓ Validation script working" || log "✗ Validation script failed"

log "Test completed!"
EOF

    chmod +x $INSTALL_DIR/test-backup.sh
    chown $USER_NAME:$USER_GROUP $INSTALL_DIR/test-backup.sh
    
    log_info "Created test script: $INSTALL_DIR/test-backup.sh"
}

setup_monitoring() {
    log_step "Setting up monitoring script..."
    
    cat > $INSTALL_DIR/monitor.sh << 'EOF'
#!/bin/bash

# Simple monitoring script for backup system

LOG_FILE="/var/log/backup-scripts/monitor.log"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a $LOG_FILE
}

check_service() {
    if systemctl is-active --quiet backup-scheduler; then
        log "✓ Backup scheduler is running"
    else
        log "✗ Backup scheduler is not running"
    fi
}

check_disk_space() {
    BACKUP_DIR="/opt/backup-scripts/backups"
    USAGE=$(df $BACKUP_DIR | tail -1 | awk '{print $5}' | sed 's/%//')
    
    if [[ $USAGE -gt 90 ]]; then
        log "⚠ Warning: Backup disk usage is ${USAGE}%"
    else
        log "✓ Backup disk usage is ${USAGE}%"
    fi
}

check_recent_backups() {
    BACKUP_DIR="/opt/backup-scripts/backups"
    LATEST_BACKUP=$(find $BACKUP_DIR -name "*.sql*" -o -name "*.tar*" | head -1)
    
    if [[ -n "$LATEST_BACKUP" ]]; then
        AGE=$(find $LATEST_BACKUP -mtime -1 | wc -l)
        if [[ $AGE -gt 0 ]]; then
            log "✓ Recent backup found"
        else
            log "⚠ No recent backups found"
        fi
    else
        log "⚠ No backups found"
    fi
}

check_service
check_disk_space
check_recent_backups
EOF

    chmod +x $INSTALL_DIR/monitor.sh
    chown $USER_NAME:$USER_GROUP $INSTALL_DIR/monitor.sh
    
    # Add to crontab for monitoring
    echo "*/15 * * * * $USER_NAME $INSTALL_DIR/monitor.sh" >> /etc/cron.d/backup-scripts
    
    log_info "Created monitoring script: $INSTALL_DIR/monitor.sh"
}

print_final_instructions() {
    log_info "========================================="
    log_info "Installation completed successfully!"
    log_info "========================================="
    echo
    log_info "Next steps:"
    echo "1. Edit configuration file:"
    echo "   sudo nano /etc/backup-scripts/.env"
    echo
    echo "2. Test the installation:"
    echo "   sudo -u $USER_NAME $INSTALL_DIR/test-backup.sh"
    echo
    echo "3. Start the backup scheduler:"
    echo "   sudo systemctl start $SERVICE_NAME"
    echo
    echo "4. Enable automatic startup:"
    echo "   sudo systemctl enable $SERVICE_NAME"
    echo
    echo "5. Check status:"
    echo "   sudo systemctl status $SERVICE_NAME"
    echo
    echo "6. View logs:"
    echo "   sudo tail -f $LOG_DIR/scheduler.log"
    echo
    log_info "Important files:"
    echo "   Config: /etc/backup-scripts/.env"
    echo "   Logs:   $LOG_DIR/"
    echo "   Scripts: $INSTALL_DIR/"
    echo
    log_warn "Please review and update the configuration before starting!"
    echo
}

main() {
    echo "========================================="
    echo "Database Backup Scripts - Installation"
    echo "========================================="
    echo
    
    check_root
    detect_os
    
    log_info "Detected OS: $OS $VER"
    
    install_dependencies
    install_nodejs
    create_backup_user
    setup_directories
    install_backup_scripts
    create_environment_file
    create_systemd_service
    setup_logrotate
    setup_cron_jobs
    create_test_script
    setup_monitoring
    print_final_instructions
}

main "$@"
