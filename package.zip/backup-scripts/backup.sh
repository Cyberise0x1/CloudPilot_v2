#!/bin/bash
###############################################################################
# PostgreSQL/Neon Database Backup Script (Shell Version)
# Supports full and incremental backups with compression and encryption
###############################################################################

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="${SCRIPT_DIR}/backup.log"
BACKUP_DIR="${BACKUP_DIR:-./backups}"
DATE=$(date +"%Y%m%d_%H%M%S")
RETENTION_DAYS="${RETENTION_DAYS:-30}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging function
log() {
    local level=$1
    shift
    local message="$@"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    case $level in
        INFO)
            echo -e "${GREEN}[INFO]${NC} ${timestamp} - $message" | tee -a "$LOG_FILE"
            ;;
        WARN)
            echo -e "${YELLOW}[WARN]${NC} ${timestamp} - $message" | tee -a "$LOG_FILE"
            ;;
        ERROR)
            echo -e "${RED}[ERROR]${NC} ${timestamp} - $message" | tee -a "$LOG_FILE"
            ;;
        DEBUG)
            echo -e "${BLUE}[DEBUG]${NC} ${timestamp} - $message" | tee -a "$LOG_FILE"
            ;;
    esac
}

# Check dependencies
check_dependencies() {
    log INFO "Checking dependencies..."
    
    # Check for required commands
    local required_commands=("pg_dump" "pg_restore" "tar" "gzip" "sha256sum" "aws")
    local missing_commands=()
    
    for cmd in "${required_commands[@]}"; do
        if ! command -v "$cmd" &> /dev/null; then
            missing_commands+=("$cmd")
        fi
    done
    
    if [ ${#missing_commands[@]} -gt 0 ]; then
        log ERROR "Missing required commands: ${missing_commands[*]}"
        log ERROR "Please install: apt-get install postgresql-client aws-cli"
        exit 1
    fi
    
    log INFO "All dependencies satisfied"
}

# Create backup directory
create_backup_dir() {
    log INFO "Creating backup directory: $BACKUP_DIR"
    mkdir -p "$BACKUP_DIR"
    chmod 700 "$BACKUP_DIR"
}

# Perform full backup
perform_full_backup() {
    local db_name=$1
    local db_host=$2
    local db_port=$3
    local db_user=$4
    local output_file="$BACKUP_DIR/full-backup-${db_name}-${DATE}.sql"
    
    log INFO "Starting full backup for database: $db_name"
    
    # Set password for pg_dump
    export PGPASSWORD="$DB_PASSWORD"
    
    # Perform pg_dump
    if pg_dump -h "$db_host" -p "$db_port" -U "$db_user" -d "$db_name" \
        --verbose --no-password --format=custom --compress=9 --file "$output_file"; then
        log INFO "Full backup completed successfully: $output_file"
        echo "$output_file"
    else
        log ERROR "Full backup failed"
        exit 1
    fi
    
    unset PGPASSWORD
}

# Perform incremental backup (WAL archiving)
perform_incremental_backup() {
    local db_name=$1
    local output_file="$BACKUP_DIR/incremental-backup-${db_name}-${DATE}.tar"
    
    log INFO "Starting incremental backup (WAL) for database: $db_name"
    
    # Archive WAL files
    if tar -czf "$output_file" -C /var/lib/postgresql/data/pg_wal \
        --transform "s/^/${db_name}-${DATE}-wal-/" .; then
        log INFO "Incremental backup completed successfully: $output_file"
        echo "$output_file"
    else
        log ERROR "Incremental backup failed"
        exit 1
    fi
}

# Compress backup file
compress_backup() {
    local input_file=$1
    
    if [[ "$COMPRESS" != "false" ]]; then
        log INFO "Compressing backup file: $input_file"
        
        if gzip -9 "$input_file"; then
            local compressed_file="${input_file}.gz"
            log INFO "Compression completed: $compressed_file"
            echo "$compressed_file"
        else
            log ERROR "Compression failed"
            exit 1
        fi
    else
        echo "$input_file"
    fi
}

# Encrypt backup file
encrypt_backup() {
    local input_file=$1
    local key=$2
    
    if [[ -n "$key" ]]; then
        log INFO "Encrypting backup file: $input_file"
        
        local encrypted_file="${input_file}.enc"
        
        if openssl enc -aes-256-cbc -salt -in "$input_file" -out "$encrypted_file" -k "$key"; then
            log INFO "Encryption completed: $encrypted_file"
            echo "$encrypted_file"
        else
            log ERROR "Encryption failed"
            exit 1
        fi
    else
        echo "$input_file"
    fi
}

# Calculate checksum
calculate_checksum() {
    local file=$1
    
    log INFO "Calculating checksum for: $file"
    
    local checksum=$(sha256sum "$file" | awk '{print $1}')
    local checksum_file="${file}.sha256"
    
    echo "$checksum" > "$checksum_file"
    log INFO "Checksum calculated: $checksum"
    echo "$checksum"
}

# Upload to S3
upload_to_s3() {
    local file=$1
    local bucket=$2
    local db_name=$3
    
    if [[ -n "$bucket" ]]; then
        log INFO "Uploading to S3: s3://$bucket/backups/$db_name/$(basename "$file")"
        
        if aws s3 cp "$file" "s3://$bucket/backups/$db_name/" \
            --server-side-encryption AES256; then
            log INFO "Upload to S3 completed successfully"
        else
            log ERROR "Upload to S3 failed"
            exit 1
        fi
    fi
}

# Save metadata
save_metadata() {
    local backup_file=$1
    local backup_type=$2
    local db_name=$3
    local checksum=$4
    
    local size=$(stat -f%z "$backup_file" 2>/dev/null || stat -c%s "$backup_file" 2>/dev/null)
    local metadata_file="${backup_file}.metadata.json"
    
    local metadata=$(cat <<EOF
{
  "timestamp": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "type": "$backup_type",
  "database": "$db_name",
  "size": $size,
  "compressed": $([[ "$COMPRESS" != "false" ]] && echo "true" || echo "false"),
  "encrypted": $([[ -n "$ENCRYPTION_KEY" ]] && echo "true" || echo "false"),
  "checksum": "$checksum",
  "version": "1.0.0"
}
EOF
)
    
    echo "$metadata" > "$metadata_file"
    log INFO "Metadata saved: $metadata_file"
}

# Clean up old backups
cleanup_old_backups() {
    log INFO "Cleaning up backups older than $RETENTION_DAYS days"
    
    find "$BACKUP_DIR" -name "*.sql*" -o -name "*.tar*" -o -name "*.enc*" -o -name "*.sha256" -o -name "*.metadata.json" \
        -mtime +$RETENTION_DAYS -delete
    
    log INFO "Old backups cleaned up"
}

# Restore backup (bonus functionality)
restore_backup() {
    local backup_file=$1
    local db_name=$2
    local db_host=$3
    local db_port=$4
    local db_user=$5
    
    log INFO "Starting restore process for: $backup_file"
    
    # Decrypt if necessary
    local working_file="$backup_file"
    if [[ "$backup_file" == *.enc ]]; then
        log INFO "Decrypting backup file"
        working_file="${backup_file%.enc}"
        openssl enc -aes-256-cbc -d -in "$backup_file" -out "$working_file" -k "$ENCRYPTION_KEY"
    fi
    
    # Decompress if necessary
    if [[ "$working_file" == *.gz ]]; then
        log INFO "Decompressing backup file"
        working_file="${working_file%.gz}"
        gunzip -c "${backup_file%.enc}" > "$working_file"
    fi
    
    # Restore using pg_restore
    export PGPASSWORD="$DB_PASSWORD"
    
    if pg_restore -h "$db_host" -p "$db_port" -U "$db_user" -d "$db_name" \
        --verbose --no-password "$working_file"; then
        log INFO "Restore completed successfully"
    else
        log ERROR "Restore failed"
        exit 1
    fi
    
    unset PGPASSWORD
}

# Help function
show_help() {
    cat <<EOF
Usage: $0 [COMMAND] [OPTIONS]

Commands:
    backup     Create a database backup (default)
    restore    Restore from a backup file

Options:
    --type TYPE         Backup type: full or incremental (default: full)
    --database DB       Database name
    --host HOST         Database host (default: localhost)
    --port PORT         Database port (default: 5432)
    --user USER         Database user
    --password PASS     Database password
    --s3-bucket BUCKET  AWS S3 bucket for storage
    --compress          Enable compression (default: true)
    --encrypt KEY       Encrypt with key (hex or string)
    --retention DAYS    Retention period in days (default: 30)
    --backup-file FILE  Specific backup file for restore
    --help              Show this help message

Environment Variables:
    DB_NAME, DB_HOST, DB_PORT, DB_USER, DB_PASSWORD
    BACKUP_DIR, S3_BUCKET, COMPRESS, ENCRYPTION_KEY, RETENTION_DAYS

Examples:
    # Full backup
    $0 backup --type full --database mydb --user postgres --password secret
    
    # Incremental backup with S3 upload
    $0 backup --type incremental --database mydb --user postgres --password secret --s3-bucket my-backups
    
    # Encrypted backup
    $0 backup --database mydb --user postgres --password secret --encrypt mykey123
    
    # Restore from backup
    $0 restore --backup-file ./backups/full-backup-mydb-20240101_120000.sql.enc --database mydb --user postgres --password secret

EOF
}

# Main backup function
main_backup() {
    log INFO "=== Starting Backup Process ==="
    log INFO "Backup type: $BACKUP_TYPE"
    log INFO "Database: $DB_NAME"
    log INFO "Timestamp: $DATE"
    echo "---"
    
    # Create backup directory
    create_backup_dir
    
    # Perform backup
    local backup_file=""
    if [[ "$BACKUP_TYPE" == "full" ]]; then
        backup_file=$(perform_full_backup "$DB_NAME" "$DB_HOST" "$DB_PORT" "$DB_USER")
    elif [[ "$BACKUP_TYPE" == "incremental" ]]; then
        backup_file=$(perform_incremental_backup "$DB_NAME")
    else
        log ERROR "Invalid backup type: $BACKUP_TYPE"
        exit 1
    fi
    
    # Compress if enabled
    if [[ "$COMPRESS" != "false" ]]; then
        backup_file=$(compress_backup "$backup_file")
    fi
    
    # Encrypt if key provided
    if [[ -n "$ENCRYPTION_KEY" ]]; then
        backup_file=$(encrypt_backup "$backup_file" "$ENCRYPTION_KEY")
    fi
    
    # Calculate checksum
    local checksum=$(calculate_checksum "$backup_file")
    
    # Upload to S3 if bucket specified
    if [[ -n "$S3_BUCKET" ]]; then
        upload_to_s3 "$backup_file" "$S3_BUCKET" "$DB_NAME"
    fi
    
    # Save metadata
    save_metadata "$backup_file" "$BACKUP_TYPE" "$DB_NAME" "$checksum"
    
    # Cleanup old backups
    cleanup_old_backups
    
    echo "---"
    log INFO "=== Backup Process Completed Successfully ==="
    log INFO "Backup file: $backup_file"
    log INFO "Checksum: $checksum"
}

# Parse command line arguments
BACKUP_TYPE="${1:-backup}"
shift || true

while [[ $# -gt 0 ]]; do
    case $1 in
        --type)
            BACKUP_TYPE="$2"
            shift 2
            ;;
        --database)
            DB_NAME="$2"
            shift 2
            ;;
        --host)
            DB_HOST="$2"
            shift 2
            ;;
        --port)
            DB_PORT="$2"
            shift 2
            ;;
        --user)
            DB_USER="$2"
            shift 2
            ;;
        --password)
            DB_PASSWORD="$2"
            shift 2
            ;;
        --s3-bucket)
            S3_BUCKET="$2"
            shift 2
            ;;
        --compress)
            COMPRESS="true"
            shift
            ;;
        --encrypt)
            ENCRYPTION_KEY="$2"
            shift 2
            ;;
        --retention)
            RETENTION_DAYS="$2"
            shift 2
            ;;
        --backup-file)
            BACKUP_FILE="$2"
            shift 2
            ;;
        --help|-h)
            show_help
            exit 0
            ;;
        *)
            log ERROR "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
done

# Set defaults
DB_HOST="${DB_HOST:-localhost}"
DB_PORT="${DB_PORT:-5432}"
BACKUP_TYPE="${BACKUP_TYPE:-full}"
COMPRESS="${COMPRESS:-true}"

# Check required variables
if [[ "$BACKUP_TYPE" == "backup" && ( -z "$DB_NAME" || -z "$DB_USER" || -z "$DB_PASSWORD" ) ]]; then
    log ERROR "Missing required parameters for backup"
    log ERROR "Please set: --database, --user, --password or environment variables"
    exit 1
fi

# Execute main logic
main() {
    check_dependencies
    
    case "$BACKUP_TYPE" in
        backup)
            main_backup
            ;;
        restore)
            if [[ -z "$BACKUP_FILE" ]]; then
                log ERROR "Backup file required for restore"
                exit 1
            fi
            restore_backup "$BACKUP_FILE" "$DB_NAME" "$DB_HOST" "$DB_PORT" "$DB_USER"
            ;;
        *)
            log ERROR "Invalid command: $BACKUP_TYPE"
            show_help
            exit 1
            ;;
    esac
}

# Run main function
main "$@"
