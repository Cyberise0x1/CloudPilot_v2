#!/bin/bash
###############################################################################
# Database Migration Script
# Manages database schema migrations with validation, rollback, and history tracking
###############################################################################

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MIGRATIONS_DIR="${MIGRATIONS_DIR:-./migrations}"
DB_HOST="${DB_HOST:-localhost}"
DB_PORT="${DB_PORT:-5432}"
DB_NAME="${DB_NAME:-}"
DB_USER="${DB_USER:-postgres}"
DB_PASSWORD="${DB_PASSWORD:-}"
MIGRATION_TABLE="${MIGRATION_TABLE:-schema_migrations}"
LOG_FILE="${SCRIPT_DIR}/migration.log"
DRY_RUN="${DRY_RUN:-false}"
VALIDATE="${VALIDATE:-true}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Logging function
log() {
    local level=$1
    shift
    local message="$@"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    case $level in
        INFO)
            echo -e "${GREEN}[INFO]${NC} ${timestamp} - $message" | tee -a "$LOG_FILE"
            ;;
        WARN)
            echo -e "${YELLOW}[WARN]${NC} ${timestamp} - $message" | tee -a "$LOG_FILE"
            ;;
        ERROR)
            echo -e "${RED}[ERROR]${NC} ${timestamp} - $message" | tee -a "$LOG_FILE"
            ;;
        DEBUG)
            echo -e "${BLUE}[DEBUG]${NC} ${timestamp} - $message" | tee -a "$LOG_FILE"
            ;;
        STEP)
            echo -e "${PURPLE}[STEP]${NC} ${timestamp} - $message" | tee -a "$LOG_FILE"
            ;;
    esac
}

# Check dependencies
check_dependencies() {
    log INFO "Checking dependencies..."
    
    local required_commands=("psql" "grep" "sort" "mkdir")
    local missing_commands=()
    
    for cmd in "${required_commands[@]}"; do
        if ! command -v "$cmd" &> /dev/null; then
            missing_commands+=("$cmd")
        fi
    done
    
    if [ ${#missing_commands[@]} -gt 0 ]; then
        log ERROR "Missing required commands: ${missing_commands[*]}"
        exit 1
    fi
    
    log INFO "All dependencies satisfied"
}

# Create migrations directory
create_migrations_dir() {
    if [ ! -d "$MIGRATIONS_DIR" ]; then
        log INFO "Creating migrations directory: $MIGRATIONS_DIR"
        mkdir -p "$MIGRATIONS_DIR"
    fi
}

# Initialize migration table
init_migration_table() {
    log INFO "Initializing migration table: $MIGRATION_TABLE"
    
    export PGPASSWORD="$DB_PASSWORD"
    
    local create_table_sql="
    CREATE TABLE IF NOT EXISTS $MIGRATION_TABLE (
        version VARCHAR(255) PRIMARY KEY,
        description TEXT,
        applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        execution_time INTEGER,
        checksum VARCHAR(64)
    );
    "
    
    if psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -c "$create_table_sql" &> /dev/null; then
        log INFO "Migration table initialized successfully"
    else
        log ERROR "Failed to initialize migration table"
        exit 1
    fi
    
    unset PGPASSWORD
}

# Get list of migration files
get_migration_files() {
    local pattern="^[0-9]{3}_.*\.sql$"
    local migration_files=()
    
    if [ ! -d "$MIGRATIONS_DIR" ]; then
        log ERROR "Migrations directory not found: $MIGRATIONS_DIR"
        exit 1
    fi
    
    while IFS= read -r file; do
        local filename=$(basename "$file")
        if [[ "$filename" =~ $pattern ]]; then
            migration_files+=("$file")
        fi
    done < <(find "$MIGRATIONS_DIR" -type f -name "*.sql" | sort)
    
    printf '%s\n' "${migration_files[@]}"
}

# Get applied migrations from database
get_applied_migrations() {
    export PGPASSWORD="$DB_PASSWORD"
    
    local applied_migrations=()
    
    while IFS= read -r version; do
        if [ -n "$version" ]; then
            applied_migrations+=("$version")
        fi
    done < <(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t \
        -c "SELECT version FROM $MIGRATION_TABLE ORDER BY version;" 2>/dev/null || echo "")
    
    printf '%s\n' "${applied_migrations[@]}"
    
    unset PGPASSWORD
}

# Get pending migrations
get_pending_migrations() {
    local all_migrations=("$@")
    local applied_migrations=($(get_applied_migrations))
    
    # Convert to associative arrays for efficient lookup
    declare -A applied_map
    for migration in "${applied_migrations[@]}"; do
        applied_map[$migration]=1
    done
    
    # Filter out applied migrations
    local pending_migrations=()
    for migration in "${all_migrations[@]}"; do
        local version=$(get_migration_version "$migration")
        if [ -z "${applied_map[$version]:-}" ]; then
            pending_migrations+=("$migration")
        fi
    done
    
    printf '%s\n' "${pending_migrations[@]}"
}

# Extract version from migration filename
get_migration_version() {
    local migration_file=$1
    local basename=$(basename "$migration_file")
    echo "${basename%%_*}"
}

# Extract description from migration filename
get_migration_description() {
    local migration_file=$1
    local basename=$(basename "$migration_file")
    local desc="${basename#*_}"
    desc="${desc%.sql}"
    echo "${desc//_/ }"
}

# Calculate migration checksum
calculate_migration_checksum() {
    local migration_file=$1
    sha256sum "$migration_file" | awk '{print $1}'
}

# Validate migration file
validate_migration_file() {
    local migration_file=$1
    
    log DEBUG "Validating migration file: $(basename "$migration_file")"
    
    local errors=()
    
    # Check if file exists and is readable
    if [ ! -r "$migration_file" ]; then
        errors+=("File is not readable")
    fi
    
    # Check filename format
    local filename=$(basename "$migration_file")
    if [[ ! "$filename" =~ ^[0-9]{3}_.*\.sql$ ]]; then
        errors+=("Invalid filename format. Expected: 001_description.sql")
    fi
    
    # Check for required sections (UP and DOWN migrations)
    if ! grep -q "^-- UP:" "$migration_file" 2>/dev/null; then
        errors+=("Missing -- UP: section")
    fi
    
    if ! grep -q "^-- DOWN:" "$migration_file" 2>/dev/null; then
        errors+=("Missing -- DOWN: section")
    fi
    
    # Check for SQL syntax errors (basic check)
    if grep -q "^[[:space:]]*\;" "$migration_file" 2>/dev/null; then
        errors+=("Potential SQL syntax error: empty statement")
    fi
    
    if [ ${#errors[@]} -gt 0 ]; then
        log ERROR "Validation failed for $(basename "$migration_file"):"
        for error in "${errors[@]}"; do
            log ERROR "  - $error"
        done
        return 1
    fi
    
    log DEBUG "Migration file validation passed"
    return 0
}

# Record migration in database
record_migration() {
    local version=$1
    local description=$2
    local execution_time=$3
    local checksum=$4
    local status=$5  # "applied" or "failed"
    
    export PGPASSWORD="$DB_PASSWORD"
    
    if [ "$status" = "applied" ]; then
        psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
            -c "INSERT INTO $MIGRATION_TABLE (version, description, execution_time, checksum) 
                VALUES ('$version', '$description', $execution_time, '$checksum')" &> /dev/null
    else
        psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
            -c "INSERT INTO $MIGRATION_TABLE (version, description, execution_time, checksum) 
                VALUES ('$version', '$description (FAILED)', $execution_time, '$checksum')" &> /dev/null
    fi
    
    unset PGPASSWORD
}

# Execute migration
execute_migration() {
    local migration_file=$1
    local direction=$2  # "up" or "down"
    
    local version=$(get_migration_version "$migration_file")
    local description=$(get_migration_description "$migration_file")
    
    log STEP "Executing migration $version: $description ($direction)"
    
    local start_time=$(date +%s)
    local migration_sql=""
    
    # Extract the appropriate SQL section
    if [ "$direction" = "up" ]; then
        migration_sql=$(sed -n '/^-- UP:/,/^-- DOWN:/p' "$migration_file" | sed '1d;$d')
    else
        migration_sql=$(sed -n '/^-- DOWN:/,/^-- /*/p' "$migration_file" | sed '1d' | head -n -1)
    fi
    
    if [ "$DRY_RUN" = "true" ]; then
        log INFO "[DRY RUN] Would execute migration $version ($direction)"
        log DEBUG "SQL to execute:"
        echo "$migration_sql" | sed 's/^/  /' >> "$LOG_FILE"
        return 0
    fi
    
    export PGPASSWORD="$DB_PASSWORD"
    
    # Execute migration in transaction
    if psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" \
        -c "BEGIN; $migration_sql; COMMIT;" &> /dev/null; then
        local end_time=$(date +%s)
        local execution_time=$((end_time - start_time))
        local checksum=$(calculate_migration_checksum "$migration_file")
        
        record_migration "$version" "$description" "$execution_time" "$checksum" "applied"
        
        log INFO "Migration $version completed successfully (${execution_time}s)"
        return 0
    else
        local end_time=$(date +%s)
        local execution_time=$((end_time - start_time))
        
        record_migration "$version" "$description" "$execution_time" "" "failed"
        
        log ERROR "Migration $version failed"
        return 1
    fi
    
    unset PGPASSWORD
}

# Rollback migration
rollback_migration() {
    local migration_file=$1
    
    log INFO "Rolling back migration: $(basename "$migration_file")"
    execute_migration "$migration_file" "down"
}

# Show migration status
show_status() {
    log INFO "=== Migration Status ==="
    
    local all_migrations=($(get_migration_files))
    local applied_migrations=($(get_applied_migrations))
    
    # Convert to associative array for efficient lookup
    declare -A applied_map
    for migration in "${applied_migrations[@]}"; do
        applied_map[$migration]=1
    done
    
    echo ""
    printf "%-10s %-40s %-15s\n" "VERSION" "DESCRIPTION" "STATUS"
    printf "%-10s %-40s %-15s\n" "------" "-----------" "------"
    
    for migration_file in "${all_migrations[@]}"; do
        local version=$(get_migration_version "$migration_file")
        local description=$(get_migration_description "$migration_file")
        local status="${GREEN}PENDING${NC}"
        
        if [ -n "${applied_map[$version]:-}" ]; then
            status="${GREEN}APPLIED${NC}"
        fi
        
        printf "%-10s %-40s %-15b\n" "$version" "$description" "$status"
    done
    
    echo ""
    log INFO "Total migrations: ${#all_migrations[@]}"
    log INFO "Applied: ${#applied_migrations[@]}"
    log INFO "Pending: $((${#all_migrations[@]} - ${#applied_migrations[@]}))"
}

# Show pending migrations
show_pending() {
    log INFO "=== Pending Migrations ==="
    
    local all_migrations=($(get_migration_files))
    local pending_migrations=($(get_pending_migrations "${all_migrations[@]}"))
    
    if [ ${#pending_migrations[@]} -eq 0 ]; then
        log INFO "No pending migrations"
        return 0
    fi
    
    echo ""
    printf "%-10s %-40s\n" "VERSION" "DESCRIPTION"
    printf "%-10s %-40s\n" "------" "-----------"
    
    for migration_file in "${pending_migrations[@]}"; do
        local version=$(get_migration_version "$migration_file")
        local description=$(get_migration_description "$migration_file")
        printf "%-10s %-40s\n" "$version" "$description"
    done
    
    echo ""
    log INFO "Total pending: ${#pending_migrations[@]}"
}

# Show applied migrations
show_applied() {
    log INFO "=== Applied Migrations ==="
    
    local applied_migrations=($(get_applied_migrations))
    
    if [ ${#applied_migrations[@]} -eq 0 ]; then
        log INFO "No applied migrations"
        return 0
    fi
    
    echo ""
    printf "%-10s %-40s %-20s\n" "VERSION" "DESCRIPTION" "APPLIED AT"
    printf "%-10s %-40s %-20s\n" "------" "-----------" "---------"
    
    export PGPASSWORD="$DB_PASSWORD"
    
    for version in "${applied_migrations[@]}"; do
        local result=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$DB_NAME" -t \
            -c "SELECT description, applied_at FROM $MIGRATION_TABLE WHERE version = '$version';" 2>/dev/null)
        
        if [ -n "$result" ]; then
            local description=$(echo "$result" | cut -d'|' -f1 | xargs)
            local applied_at=$(echo "$result" | cut -d'|' -f2 | xargs)
            printf "%-10s %-40s %-20s\n" "$version" "$description" "$applied_at"
        fi
    done
    
    unset PGPASSWORD
    
    echo ""
    log INFO "Total applied: ${#applied_migrations[@]}"
}

# Create new migration file
create_migration() {
    local description=$1
    
    if [ -z "$description" ]; then
        log ERROR "Migration description required"
        log INFO "Usage: $0 create <description>"
        exit 1
    fi
    
    # Get next migration number
    local all_migrations=($(get_migration_files))
    local next_number=1
    
    if [ ${#all_migrations[@]} -gt 0 ]; then
        local last_migration="${all_migrations[-1]}"
        local last_number=$(get_migration_version "$last_migration")
        next_number=$((10#$last_number + 1))
    fi
    
    # Format number with leading zeros
    local formatted_number=$(printf "%03d" $next_number)
    
    # Clean description for filename
    local clean_desc=$(echo "$description" | tr ' ' '_' | tr -cd '[:alnum:]_-')
    
    local filename="${formatted_number}_${clean_desc}.sql"
    local filepath="$MIGRATIONS_DIR/$filename"
    
    cat > "$filepath" <<EOF
-- Migration: $description
-- Created: $(date '+%Y-%m-%d %H:%M:%S')

-- UP: Migration to apply
BEGIN;

-- Add your UP migration SQL here
-- Example:
-- CREATE TABLE example_table (
--     id SERIAL PRIMARY KEY,
--     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
-- );

COMMIT;

-- DOWN: Migration to rollback
BEGIN;

-- Add your DOWN migration SQL here
-- Example:
-- DROP TABLE IF EXISTS example_table;

COMMIT;
EOF
    
    log INFO "Created migration file: $filepath"
    log INFO "Edit this file to add your migration SQL"
}

# Run migrations
run_migrations() {
    log INFO "=== Starting Migration Process ==="
    
    local all_migrations=($(get_migration_files))
    local pending_migrations=($(get_pending_migrations "${all_migrations[@]}"))
    
    if [ ${#pending_migrations[@]} -eq 0 ]; then
        log INFO "No pending migrations"
        return 0
    fi
    
    log INFO "Found ${#pending_migrations[@]} pending migrations"
    
    local failed=0
    local success_count=0
    
    for migration_file in "${pending_migrations[@]}"; do
        # Validate if enabled
        if [ "$VALIDATE" = "true" ]; then
            if ! validate_migration_file "$migration_file"; then
                log ERROR "Validation failed for $(basename "$migration_file")"
                failed=$((failed + 1))
                continue
            fi
        fi
        
        # Execute migration
        if execute_migration "$migration_file" "up"; then
            success_count=$((success_count + 1))
        else
            failed=$((failed + 1))
            log ERROR "Migration failed. Stopping execution."
            break
        fi
    done
    
    log INFO "=== Migration Process Completed ==="
    log INFO "Successful: $success_count"
    log INFO "Failed: $failed"
    
    if [ $failed -gt 0 ]; then
        exit 1
    fi
}

# Rollback to version
rollback_to() {
    local target_version=$1
    
    log INFO "=== Starting Rollback Process ==="
    log INFO "Target version: $target_version"
    
    local applied_migrations=($(get_applied_migrations))
    
    # Get migrations to rollback (all applied migrations after target version)
    local migrations_to_rollback=()
    local should_rollback=0
    
    for version in "${applied_migrations[@]}"; do
        if [ "$should_rollback" -eq 1 ]; then
            migrations_to_rollback+=("$version")
        fi
        if [ "$version" = "$target_version" ]; then
            should_rollback=1
        fi
    done
    
    if [ ${#migrations_to_rollback[@]} -eq 0 ]; then
        log INFO "No migrations to rollback"
        return 0
    fi
    
    log INFO "Found ${#migrations_to_rollback[@]} migrations to rollback"
    
    # Rollback in reverse order
    local failed=0
    local success_count=0
    
    for ((i=${#migrations_to_rollback[@]}-1; i>=0; i--)); do
        local version="${migrations_to_rollback[$i]}"
        
        # Find migration file
        local migration_file=""
        for file in "${all_migrations[@]}"; do
            if [ "$(get_migration_version "$file")" = "$version" ]; then
                migration_file="$file"
                break
            fi
        done
        
        if [ -n "$migration_file" ]; then
            if rollback_migration "$migration_file"; then
                success_count=$((success_count + 1))
            else
                failed=$((failed + 1))
                log ERROR "Rollback failed for version $version"
                break
            fi
        else
            log ERROR "Migration file not found for version $version"
            failed=$((failed + 1))
        fi
    done
    
    log INFO "=== Rollback Process Completed ==="
    log INFO "Successful: $success_count"
    log INFO "Failed: $failed"
    
    if [ $failed -gt 0 ]; then
        exit 1
    fi
}

# Show help
show_help() {
    cat <<EOF
Usage: $0 COMMAND [OPTIONS]

Commands:
    migrate      Run pending migrations (default)
    status       Show migration status
    pending      Show pending migrations
    applied      Show applied migrations
    rollback     Rollback to specific version
    create       Create new migration file
    init         Initialize migration table

Options:
    --database DB     Database name
    --host HOST       Database host (default: localhost)
    --port PORT       Database port (default: 5432)
    --user USER       Database user (default: postgres)
    --password PASS   Database password
    --dir DIR         Migrations directory (default: ./migrations)
    --target VERSION  Target version for rollback
    --description DESC Description for new migration
    --dry-run         Show what would be done without executing
    --no-validate     Skip migration validation
    --help            Show this help message

Environment Variables:
    DB_NAME, DB_HOST, DB_PORT, DB_USER, DB_PASSWORD
    MIGRATIONS_DIR, MIGRATION_TABLE, DRY_RUN, VALIDATE

Examples:
    # Run all pending migrations
    $0 migrate --database mydb --user postgres --password secret

    # Show migration status
    $0 status --database mydb --user postgres --password secret

    # Create new migration
    $0 create --database mydb --user postgres --password secret --description "Add user table"

    # Rollback to specific version
    $0 rollback --database mydb --user postgres --password secret --target 005

    # Dry run (show what would be done)
    $0 migrate --database mydb --user postgres --password secret --dry-run

EOF
}

# Parse command line arguments
COMMAND="${1:-migrate}"
shift || true

while [[ $# -gt 0 ]]; do
    case $1 in
        --database)
            DB_NAME="$2"
            shift 2
            ;;
        --host)
            DB_HOST="$2"
            shift 2
            ;;
        --port)
            DB_PORT="$2"
            shift 2
            ;;
        --user)
            DB_USER="$2"
            shift 2
            ;;
        --password)
            DB_PASSWORD="$2"
            shift 2
            ;;
        --dir)
            MIGRATIONS_DIR="$2"
            shift 2
            ;;
        --target)
            TARGET_VERSION="$2"
            shift 2
            ;;
        --description)
            MIGRATION_DESCRIPTION="$2"
            shift 2
            ;;
        --dry-run)
            DRY_RUN="true"
            shift
            ;;
        --no-validate)
            VALIDATE="false"
            shift
            ;;
        --help|-h)
            show_help
            exit 0
            ;;
        *)
            log ERROR "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
done

# Set defaults
DB_HOST="${DB_HOST:-localhost}"
DB_PORT="${DB_PORT:-5432}"

# Check required variables
if [ -z "$DB_NAME" ] && [ "$COMMAND" != "create" ] && [ "$COMMAND" != "help" ]; then
    log ERROR "Database name required"
    log ERROR "Please set: --database or DB_NAME environment variable"
    exit 1
fi

if [ -z "$DB_PASSWORD" ] && [ "$COMMAND" != "create" ] && [ "$COMMAND" != "help" ]; then
    log ERROR "Database password required"
    log ERROR "Please set: --password or DB_PASSWORD environment variable"
    exit 1
fi

# Execute main logic
main() {
    check_dependencies
    create_migrations_dir
    
    case "$COMMAND" in
        migrate)
            if [ -z "$DB_PASSWORD" ]; then
                log ERROR "Database password required for migrate command"
                exit 1
            fi
            init_migration_table
            run_migrations
            ;;
        status)
            show_status
            ;;
        pending)
            show_pending
            ;;
        applied)
            show_applied
            ;;
        rollback)
            if [ -z "$TARGET_VERSION" ]; then
                log ERROR "Target version required for rollback"
                log INFO "Usage: $0 rollback --target <version>"
                exit 1
            fi
            rollback_to "$TARGET_VERSION"
            ;;
        create)
            create_migration "$MIGRATION_DESCRIPTION"
            ;;
        init)
            init_migration_table
            ;;
        *)
            log ERROR "Unknown command: $COMMAND"
            show_help
            exit 1
            ;;
    esac
}

# Run main function
main "$@"
