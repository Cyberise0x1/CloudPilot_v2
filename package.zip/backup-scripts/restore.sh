#!/bin/bash
###############################################################################
# PostgreSQL/Neon Database Restore Script
# Supports restoration from encrypted, compressed backups with validation
###############################################################################

set -euo pipefail

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="${SCRIPT_DIR}/restore.log"
BACKUP_FILE="${BACKUP_FILE:-}"
TARGET_DB="${TARGET_DB:-}"
SOURCE_DB="${SOURCE_DB:-}"
DB_HOST="${DB_HOST:-localhost}"
DB_PORT="${DB_PORT:-5432}"
DB_USER="${DB_USER:-postgres}"
DB_PASSWORD="${DB_PASSWORD:-}"
RESTORE_DIR="${RESTORE_DIR:-./restores}"
TEMP_DIR="${TEMP_DIR:-./temp}"
ENCRYPTION_KEY="${ENCRYPTION_KEY:-}"
DRY_RUN="${DRY_RUN:-false}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging function
log() {
    local level=$1
    shift
    local message="$@"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    case $level in
        INFO)
            echo -e "${GREEN}[INFO]${NC} ${timestamp} - $message" | tee -a "$LOG_FILE"
            ;;
        WARN)
            echo -e "${YELLOW}[WARN]${NC} ${timestamp} - $message" | tee -a "$LOG_FILE"
            ;;
        ERROR)
            echo -e "${RED}[ERROR]${NC} ${timestamp} - $message" | tee -a "$LOG_FILE"
            ;;
        DEBUG)
            echo -e "${BLUE}[DEBUG]${NC} ${timestamp} - $message" | tee -a "$LOG_FILE"
            ;;
    esac
}

# Check dependencies
check_dependencies() {
    log INFO "Checking dependencies..."
    
    local required_commands=("pg_restore" "psql" "tar" "gunzip" "openssl" "sha256sum")
    local missing_commands=()
    
    for cmd in "${required_commands[@]}"; do
        if ! command -v "$cmd" &> /dev/null; then
            missing_commands+=("$cmd")
        fi
    done
    
    if [ ${#missing_commands[@]} -gt 0 ]; then
        log ERROR "Missing required commands: ${missing_commands[*]}"
        log ERROR "Please install: apt-get install postgresql-client openssl"
        exit 1
    fi
    
    log INFO "All dependencies satisfied"
}

# Create necessary directories
create_directories() {
    log INFO "Creating restore directories..."
    mkdir -p "$RESTORE_DIR" "$TEMP_DIR"
    chmod 700 "$TEMP_DIR"
}

# Load backup metadata
load_backup_metadata() {
    local backup_file=$1
    
    local metadata_file="${backup_file}.metadata.json"
    if [ ! -f "$metadata_file" ]; then
        log WARN "Metadata file not found: $metadata_file"
        return 1
    fi
    
    log INFO "Loading backup metadata from: $metadata_file"
    
    # Extract metadata using jq if available, otherwise use grep/sed
    if command -v jq &> /dev/null; then
        BACKUP_TYPE=$(jq -r '.type' "$metadata_file")
        BACKUP_DATABASE=$(jq -r '.database' "$metadata_file")
        BACKUP_TIMESTAMP=$(jq -r '.timestamp' "$metadata_file")
        BACKUP_COMPRESSED=$(jq -r '.compressed' "$metadata_file")
        BACKUP_ENCRYPTED=$(jq -r '.encrypted' "$metadata_file")
        BACKUP_CHECKSUM=$(jq -r '.checksum' "$metadata_file")
    else
        # Fallback parsing
        BACKUP_TYPE=$(grep '"type"' "$metadata_file" | cut -d'"' -f4)
        BACKUP_DATABASE=$(grep '"database"' "$metadata_file" | cut -d'"' -f4)
        BACKUP_TIMESTAMP=$(grep '"timestamp"' "$metadata_file" | cut -d'"' -f4)
        BACKUP_COMPRESSED=$(grep '"compressed"' "$metadata_file" | cut -d':' -f2 | tr -d ' ,')
        BACKUP_ENCRYPTED=$(grep '"encrypted"' "$metadata_file" | cut -d':' -f2 | tr -d ' ,')
        BACKUP_CHECKSUM=$(grep '"checksum"' "$metadata_file" | cut -d'"' -f4)
    fi
    
    log INFO "Backup metadata loaded:"
    log INFO "  Type: $BACKUP_TYPE"
    log INFO "  Database: $BACKUP_DATABASE"
    log INFO "  Timestamp: $BACKUP_TIMESTAMP"
    log INFO "  Compressed: $BACKUP_COMPRESSED"
    log INFO "  Encrypted: $BACKUP_ENCRYPTED"
    log INFO "  Checksum: $BACKUP_CHECKSUM"
}

# Verify backup integrity
verify_backup_integrity() {
    local backup_file=$1
    
    log INFO "Verifying backup integrity..."
    
    # Check if backup file exists
    if [ ! -f "$backup_file" ]; then
        log ERROR "Backup file not found: $backup_file"
        exit 1
    fi
    
    # Verify checksum if available
    local checksum_file="${backup_file}.sha256"
    if [ -f "$checksum_file" ]; then
        log INFO "Verifying checksum..."
        local stored_checksum=$(cat "$checksum_file")
        local calculated_checksum=$(sha256sum "$backup_file" | awk '{print $1}')
        
        if [ "$stored_checksum" = "$calculated_checksum" ]; then
            log INFO "Checksum verification passed"
        else
            log ERROR "Checksum verification failed!"
            log ERROR "  Expected: $stored_checksum"
            log ERROR "  Got: $calculated_checksum"
            exit 1
        fi
    else
        log WARN "Checksum file not found, skipping verification"
    fi
}

# Decrypt backup file
decrypt_backup() {
    local encrypted_file=$1
    
    log INFO "Decrypting backup file..."
    
    local decrypted_file="${TEMP_DIR}/$(basename "${encrypted_file%.enc}")"
    
    if [ -n "$ENCRYPTION_KEY" ]; then
        if openssl enc -aes-256-cbc -d -in "$encrypted_file" -out "$decrypted_file" -k "$ENCRYPTION_KEY"; then
            log INFO "Decryption completed: $decrypted_file"
            echo "$decrypted_file"
        else
            log ERROR "Decryption failed"
            exit 1
        fi
    else
        log ERROR "Encryption key required for encrypted backup"
        exit 1
    fi
}

# Decompress backup file
decompress_backup() {
    local compressed_file=$1
    
    log INFO "Decompressing backup file..."
    
    local decompressed_file="${TEMP_DIR}/$(basename "${compressed_file%.gz}")"
    
    if [ -f "$compressed_file" ]; then
        if gunzip -c "$compressed_file" > "$decompressed_file"; then
            log INFO "Decompression completed: $decompressed_file"
            echo "$decompressed_file"
        else
            log ERROR "Decompression failed"
            exit 1
        fi
    else
        echo "$compressed_file"
    fi
}

# List available backups
list_available_backups() {
    log INFO "Scanning for available backups..."
    
    # Local backups
    local local_backups_dir="${BACKUP_DIR:-./backups}"
    if [ -d "$local_backups_dir" ]; then
        echo ""
        echo "=== Local Backups ==="
        find "$local_backups_dir" -name "*.sql*" -o -name "*.tar*" | sort -r | head -20
    fi
    
    # List S3 backups if configured
    if [ -n "${S3_BUCKET:-}" ] && command -v aws &> /dev/null; then
        echo ""
        echo "=== S3 Backups ==="
        aws s3 ls "s3://$S3_BUCKET/backups/" --recursive | sort -k1,2 -r | head -20
    fi
}

# Get latest backup
get_latest_backup() {
    local database=$1
    
    log INFO "Finding latest backup for database: $database"
    
    local backup_dir="${BACKUP_DIR:-./backups}"
    local latest_backup=""
    
    # Look for latest backup matching the database
    for backup_pattern in "$backup_dir"/full-backup-"$database"-*.sql{,.gz,.enc} \
                         "$backup_dir"/full-backup-"$database"-*.tar{,.gz,.enc}; do
        if [ -e "$backup_pattern" ]; then
            latest_backup=$(ls -t "$backup_pattern" | head -1)
            break
        fi
    done
    
    if [ -z "$latest_backup" ]; then
        log ERROR "No backup found for database: $database"
        log INFO "Try: $0 list"
        exit 1
    fi
    
    echo "$latest_backup"
}

# Create target database
create_target_database() {
    local db_name=$1
    
    log INFO "Creating target database: $db_name"
    
    export PGPASSWORD="$DB_PASSWORD"
    
    # Check if database exists
    if psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -lqt | cut -d '|' -f 1 | grep -qw "$db_name"; then
        log WARN "Database $db_name already exists"
        read -p "Continue anyway? (y/N) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            log INFO "Restore cancelled"
            exit 0
        fi
    else
        # Create database
        if createdb -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" "$db_name"; then
            log INFO "Database $db_name created successfully"
        else
            log ERROR "Failed to create database $db_name"
            exit 1
        fi
    fi
    
    unset PGPASSWORD
}

# Restore database from backup
restore_database() {
    local backup_file=$1
    local db_name=$2
    
    log INFO "Starting restore process..."
    log INFO "Backup file: $backup_file"
    log INFO "Target database: $db_name"
    
    # Set password
    export PGPASSWORD="$DB_PASSWORD"
    
    # Determine restore command based on file format
    if [[ "$backup_file" == *.custom ]]; then
        # PostgreSQL custom format
        if pg_restore -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$db_name" \
            --verbose --clean --no-owner "$backup_file"; then
            log INFO "Restore from custom format completed successfully"
        else
            log ERROR "Restore from custom format failed"
            exit 1
        fi
    else
        # SQL format
        if psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$db_name" \
            --quiet --file="$backup_file"; then
            log INFO "Restore from SQL format completed successfully"
        else
            log ERROR "Restore from SQL format failed"
            exit 1
        fi
    fi
    
    unset PGPASSWORD
}

# Verify restored database
verify_restored_database() {
    local db_name=$1
    
    log INFO "Verifying restored database: $db_name"
    
    export PGPASSWORD="$DB_PASSWORD"
    
    # Check if database is accessible
    if psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$db_name" -c "SELECT 1;" &> /dev/null; then
        log INFO "Database connection verified"
    else
        log ERROR "Cannot connect to restored database"
        exit 1
    fi
    
    # Get database statistics
    local table_count=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$db_name" -t -c \
        "SELECT count(*) FROM information_schema.tables WHERE table_schema = 'public';" | tr -d ' ')
    log INFO "Tables in database: $table_count"
    
    # Get database size
    local db_size=$(psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" -d "$db_name" -t -c \
        "SELECT pg_size_pretty(pg_database_size('$db_name'));" | tr -d ' ')
    log INFO "Database size: $db_size"
    
    unset PGPASSWORD
}

# Download backup from S3
download_from_s3() {
    local s3_path=$1
    local local_file=$2
    
    log INFO "Downloading from S3: $s3_path"
    
    if aws s3 cp "$s3_path" "$local_file" --quiet; then
        log INFO "Download completed: $local_file"
        echo "$local_file"
    else
        log ERROR "Download from S3 failed"
        exit 1
    fi
}

# Cleanup temporary files
cleanup_temp_files() {
    log INFO "Cleaning up temporary files..."
    
    if [ -d "$TEMP_DIR" ]; then
        rm -rf "$TEMP_DIR"/*
        log INFO "Temporary directory cleaned"
    fi
}

# Show help
show_help() {
    cat <<EOF
Usage: $0 COMMAND [OPTIONS]

Commands:
    restore      Restore from backup (default)
    list         List available backups
    latest       Get latest backup for database

Options:
    --backup-file FILE    Specific backup file to restore
    --database DB         Target database name
    --source-db DB        Source database name (from backup metadata)
    --host HOST           Database host (default: localhost)
    --port PORT           Database port (default: 5432)
    --user USER           Database user (default: postgres)
    --password PASS       Database password
    --restore-dir DIR     Restore directory (default: ./restores)
    --temp-dir DIR        Temporary directory (default: ./temp)
    --encrypt-key KEY     Encryption key for encrypted backups
    --dry-run            Show what would be done without executing
    --from-s3 PATH        Download backup from S3 first
    --help               Show this help message

Environment Variables:
    BACKUP_FILE, TARGET_DB, SOURCE_DB, DB_HOST, DB_PORT, DB_USER, DB_PASSWORD
    BACKUP_DIR, RESTORE_DIR, TEMP_DIR, ENCRYPTION_KEY, DRY_RUN

Examples:
    # Restore from specific backup file
    $0 restore --backup-file ./backups/full-backup-mydb-20240101_120000.sql.enc \\
        --database mydb_restored --user postgres --password secret

    # Restore latest backup for database
    $0 latest --database mydb --user postgres --password secret

    # List all available backups
    $0 list

    # Restore from S3
    $0 restore --from-s3 s3://my-bucket/backups/mydb/full-backup-mydb-20240101_120000.sql \\
        --database mydb_restored --user postgres --password secret

    # Dry run (show what would be done)
    $0 restore --backup-file ./backups/latest.sql --database test_restore --dry-run

EOF
}

# Main restore function
main_restore() {
    log INFO "=== Starting Restore Process ==="
    log INFO "Backup file: ${BACKUP_FILE:-latest}"
    log INFO "Target database: $TARGET_DB"
    log INFO "Source database: ${SOURCE_DB:-}"
    
    # Determine backup file
    local backup_to_restore=""
    if [ -n "$BACKUP_FILE" ]; then
        backup_to_restore="$BACKUP_FILE"
    else
        backup_to_restore=$(get_latest_backup "$SOURCE_DB")
    fi
    
    # Download from S3 if specified
    if [ -n "${FROM_S3:-}" ]; then
        backup_to_restore="${TEMP_DIR}/$(basename "$FROM_S3")"
        download_from_s3 "$FROM_S3" "$backup_to_restore"
    fi
    
    # Load metadata if available
    load_backup_metadata "$backup_to_restore"
    
    # Verify backup integrity
    verify_backup_integrity "$backup_to_restore"
    
    # Prepare backup file for restore
    local working_file="$backup_to_restore"
    
    # Decrypt if necessary
    if [[ "$backup_to_restore" == *.enc ]]; then
        working_file=$(decrypt_backup "$backup_to_restore")
    fi
    
    # Decompress if necessary
    if [[ "$working_file" == *.gz ]]; then
        working_file=$(decompress_backup "$working_file")
    fi
    
    # Create target database if it doesn't exist
    create_target_database "$TARGET_DB"
    
    # Perform restore
    if [ "$DRY_RUN" = "true" ]; then
        log INFO "[DRY RUN] Would restore $working_file to database $TARGET_DB"
    else
        restore_database "$working_file" "$TARGET_DB"
        verify_restored_database "$TARGET_DB"
    fi
    
    # Cleanup
    if [ "$FROM_S3" ]; then
        rm -f "$backup_to_restore"
    fi
    cleanup_temp_files
    
    log INFO "=== Restore Process Completed Successfully ==="
    log INFO "Database restored: $TARGET_DB"
}

# Parse command line arguments
COMMAND="${1:-restore}"
shift || true

while [[ $# -gt 0 ]]; do
    case $1 in
        --backup-file)
            BACKUP_FILE="$2"
            shift 2
            ;;
        --database)
            TARGET_DB="$2"
            shift 2
            ;;
        --source-db)
            SOURCE_DB="$2"
            shift 2
            ;;
        --host)
            DB_HOST="$2"
            shift 2
            ;;
        --port)
            DB_PORT="$2"
            shift 2
            ;;
        --user)
            DB_USER="$2"
            shift 2
            ;;
        --password)
            DB_PASSWORD="$2"
            shift 2
            ;;
        --restore-dir)
            RESTORE_DIR="$2"
            shift 2
            ;;
        --temp-dir)
            TEMP_DIR="$2"
            shift 2
            ;;
        --encrypt-key)
            ENCRYPTION_KEY="$2"
            shift 2
            ;;
        --from-s3)
            FROM_S3="$2"
            shift 2
            ;;
        --dry-run)
            DRY_RUN="true"
            shift
            ;;
        --help|-h)
            show_help
            exit 0
            ;;
        *)
            log ERROR "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
done

# Set defaults
DB_HOST="${DB_HOST:-localhost}"
DB_PORT="${DB_PORT:-5432}"

# Check required variables
case "$COMMAND" in
    restore)
        if [ -z "$TARGET_DB" ]; then
            if [ -z "$BACKUP_FILE" ]; then
                log ERROR "Missing required parameters"
                log ERROR "Please set: --database (and optionally --source-db or --backup-file)"
                exit 1
            fi
            TARGET_DB="$BACKUP_FILE"
        fi
        ;;
esac

if [[ "$COMMAND" == "restore" && -z "$DB_PASSWORD" ]]; then
    log ERROR "Database password required"
    log ERROR "Please set: --password or DB_PASSWORD environment variable"
    exit 1
fi

# Execute main logic
main() {
    check_dependencies
    create_directories
    
    case "$COMMAND" in
        restore)
            main_restore
            ;;
        list)
            list_available_backups
            ;;
        latest)
            if [ -z "$SOURCE_DB" ]; then
                log ERROR "Database name required for latest command"
                log ERROR "Usage: $0 latest --database <db_name>"
                exit 1
            fi
            get_latest_backup "$SOURCE_DB"
            ;;
        *)
            log ERROR "Unknown command: $COMMAND"
            show_help
            exit 1
            ;;
    esac
}

# Run main function
main "$@"
