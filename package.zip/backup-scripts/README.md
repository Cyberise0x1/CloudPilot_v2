# Database Backup Scripts

A comprehensive, production-ready backup solution for PostgreSQL/Neon databases with support for compression, encryption, cloud storage (AWS S3), automated scheduling, and integrity validation.

## Features

### 🔐 Security & Encryption
- **AES-256 encryption** for sensitive backup data
- **Compression** using gzip with configurable levels
- **Checksum verification** (SHA256) for integrity validation
- **Secure transmission** to AWS S3 with server-side encryption

### ☁️ Cloud Storage
- **AWS S3 integration** with multi-part uploads
- **Cross-region replication** support
- **Lifecycle policies** for automatic archival and cleanup
- **Versioning** support for backup history
- **Concurrent uploads** with progress tracking

### ⏰ Automated Scheduling
- **Cron-like scheduling** with flexible expressions
- **Multiple backup strategies** (full/incremental)
- **Dependency management** between backup jobs
- **Retry logic** with configurable delays
- **Concurrency control** to prevent resource conflicts

### ✅ Integrity Validation
- **Comprehensive validation** including:
  - File integrity checks
  - Checksum verification
  - Encryption validation
  - Compression verification
  - Metadata validation
  - Restoration testing
  - Database integrity checks
- **Parallel validation** for multiple backups
- **Quarantine system** for failed backups
- **Detailed reporting** (HTML/JSON/Text)

### 📊 Monitoring & Alerts
- **System metrics** collection (CPU, memory, disk)
- **Health checks** with automatic issue detection
- **Email notifications** for success/failure alerts
- **Slack integration** for team notifications
- **Comprehensive logging** with rotation

## Installation

### Prerequisites

```bash
# System dependencies
sudo apt-get update
sudo apt-get install -y postgresql-client aws-cli

# Node.js dependencies
npm install
```

### Configuration

1. Copy the example environment file:
```bash
cp .env.example .env
```

2. Edit `.env` with your database and cloud configuration:
```bash
# Database settings
DB_NAME=your_database
DB_HOST=localhost
DB_USER=postgres
DB_PASSWORD=your_password

# AWS S3 settings
AWS_ACCESS_KEY_ID=your_key
AWS_SECRET_ACCESS_KEY=your_secret
S3_BUCKET=your-backup-bucket

# Security
ENCRYPTION_KEY=your_32_character_encryption_key
```

3. Make shell scripts executable:
```bash
chmod +x backup.sh
```

## Usage

### 1. Basic Backup (`backup.ts`)

#### Full Backup
```bash
npm run backup:full

# Or with specific parameters
DB_NAME=mydb DB_USER=postgres DB_PASSWORD=secret npm run backup
```

#### Incremental Backup
```bash
npm run backup:incremental
```

#### Encrypted and Compressed Backup
```bash
DB_NAME=mydb \
DB_USER=postgres \
DB_PASSWORD=secret \
ENCRYPTION_KEY=your_key_here \
COMPRESS=true \
npm run backup:full
```

### 2. Shell Backup (`backup.sh`)

The shell script provides a more lightweight alternative with similar functionality:

#### Full Backup
```bash
./backup.sh backup \
  --type full \
  --database mydb \
  --user postgres \
  --password secret

# With S3 upload
./backup.sh backup \
  --database mydb \
  --user postgres \
  --password secret \
  --s3-bucket my-backups \
  --encrypt mykey123 \
  --compress
```

#### Incremental Backup
```bash
./backup.sh backup \
  --type incremental \
  --database mydb \
  --user postgres \
  --password secret
```

#### Restore Backup
```bash
./backup.sh restore \
  --backup-file ./backups/full-backup-mydb-20240101_120000.sql.enc \
  --database mydb_restored \
  --user postgres \
  --password secret
```

### 3. Cloud Backup (`cloud-backup.ts`)

Initialize S3 bucket with all configurations:
```bash
npm run cloud:init
```

Upload single file to S3:
```bash
npm run cloud:upload -- ./backups/full-backup-mydb.sql
```

Batch upload directory:
```bash
npm run cloud:batch -- ./backups
```

List S3 backups:
```bash
npm run cloud:list
```

Cleanup old S3 backups (30 days):
```bash
npm run cloud:cleanup -- 30
```

Get S3 backup statistics:
```bash
npm run cloud:stats
```

### 4. Backup Validation (`backup-validator.ts`)

Basic validation:
```bash
npm run validate
```

Strict validation with restoration testing:
```bash
TEST_RESTORATION=true npm run validate
```

Generate detailed HTML report:
```bash
npm run validate:report
```

### 5. Automated Scheduler (`backup-scheduler.ts`)

Start the scheduler:
```bash
npm run scheduler:start
```

Check scheduler status:
```bash
npm run scheduler:status
```

Run a specific schedule once:
```bash
npm run scheduler:run-once daily-full-backup
```

Stop the scheduler:
```bash
npm run scheduler:stop
```

## Advanced Configuration

### Complex Scheduling Example

Edit your `.env` file with a complex schedule configuration:

```bash
SCHEDULE_TYPE=complex

SCHEDULES_JSON=[
  {
    "name": "daily-full-backup",
    "type": "full",
    "enabled": true,
    "schedule": "0 2 * * *",
    "retention": 30,
    "config": {
      "database": "production_db",
      "host": "prod-db.example.com",
      "port": 5432,
      "username": "backup_user",
      "password": "secure_password",
      "outputDirectory": "/backups/production",
      "encrypt": true,
      "encryptionKey": "your_encryption_key_here",
      "compress": true,
      "s3Bucket": "company-backups",
      "priority": "high"
    },
    "notifications": {
      "onSuccess": true,
      "onFailure": true,
      "onTimeout": true
    },
    "dependencies": [],
    "timeoutMinutes": 720,
    "retryAttempts": 3,
    "retryDelayMinutes": 5
  },
  {
    "name": "hourly-incremental-backup",
    "type": "incremental",
    "enabled": true,
    "schedule": "0 * * * *",
    "retention": 7,
    "config": {
      "database": "production_db",
      "host": "prod-db.example.com",
      "port": 5432,
      "username": "backup_user",
      "password": "secure_password",
      "compress": true
    },
    "notifications": {
      "onSuccess": false,
      "onFailure": true,
      "onTimeout": false
    },
    "timeoutMinutes": 120,
    "retryAttempts": 2,
    "retryDelayMinutes": 10
  }
]
```

### S3 Lifecycle Policies

The system automatically configures S3 lifecycle policies:

- **0-30 days**: Standard storage
- **30-90 days**: Standard-IA storage
- **90-365 days**: Glacier storage
- **365+ days**: Deep Archive
- **Auto cleanup**: After 2 years

### Email Notifications

Configure email alerts in your `.env`:

```bash
ENABLE_EMAIL_ALERTS=true
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=noreply@yourcompany.com
SMTP_PASSWORD=your_app_password
FROM_EMAIL=backup-system@yourcompany.com
TO_EMAILS=admin@yourcompany.com,devops@yourcompany.com
SMTP_USE_TLS=true
```

### Slack Integration

Configure Slack alerts:

```bash
ENABLE_SLACK_ALERTS=true
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK
SLACK_CHANNEL=#database-alerts
SLACK_USERNAME=BackupBot
```

## Cron Setup

For automated execution, add to your system crontab:

```bash
# Daily full backup at 2 AM
0 2 * * * cd /path/to/backup-scripts && npm run backup:full >> /var/log/backup.log 2>&1

# Hourly incremental backups
0 * * * * cd /path/to/backup-scripts && npm run backup:incremental >> /var/log/backup.log 2>&1

# Weekly validation on Sundays at 3 AM
0 3 * * 0 cd /path/to/backup-scripts && npm run validate:report >> /var/log/backup-validation.log 2>&1
```

## Systemd Service

Create `/etc/systemd/system/backup-scheduler.service`:

```ini
[Unit]
Description=Database Backup Scheduler
After=network.target

[Service]
Type=forking
User=backup
Group=backup
WorkingDirectory=/opt/backup-scripts
EnvironmentFile=/opt/backup-scripts/.env
ExecStart=/usr/bin/npm run scheduler:start
ExecStop=/usr/bin/npm run scheduler:stop
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

Enable and start the service:

```bash
sudo systemctl enable backup-scheduler
sudo systemctl start backup-scheduler
sudo systemctl status backup-scheduler
```

## File Structure

```
backup-scripts/
├── backup.ts              # Main TypeScript backup script
├── backup.sh              # Shell backup script
├── cloud-backup.ts        # AWS S3 cloud backup management
├── backup-validator.ts    # Backup integrity validation
├── backup-scheduler.ts    # Automated scheduling system
├── package.json           # Node.js dependencies
├── tsconfig.json          # TypeScript configuration
├── .env.example           # Environment configuration template
├── README.md              # This file
├── backups/               # Local backup storage
├── logs/                  # Log files
└── quarantine/            # Failed backup quarantine
```

## Security Best Practices

### 1. Encryption Key Management
```bash
# Generate a secure 32-character encryption key
openssl rand -hex 16

# Use environment variables (never commit to git)
ENCRYPTION_KEY=your_generated_key_here
```

### 2. Database User Permissions
Create a dedicated backup user with minimal permissions:

```sql
-- Create backup user
CREATE USER backup_user WITH ENCRYPTED PASSWORD 'secure_password';

-- Grant necessary permissions
GRANT CONNECT ON DATABASE your_database TO backup_user;
GRANT USAGE ON SCHEMA public TO backup_user;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO backup_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO backup_user;
```

### 3. S3 Bucket Security
```bash
# S3 bucket policy (JSON)
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "DenyInsecureConnections",
      "Effect": "Deny",
      "Principal": "*",
      "Action": "s3:*",
      "Resource": [
        "arn:aws:s3:::your-backup-bucket",
        "arn:aws:s3:::your-backup-bucket/*"
      ],
      "Condition": {
        "Bool": {
          "aws:SecureTransport": "false"
        }
      }
    }
  ]
}
```

### 4. File Permissions
```bash
# Set restrictive permissions
chmod 700 backup-scripts/
chmod 600 backup-scripts/.env
chmod 755 backup-scripts/backup.sh
```

## Monitoring & Maintenance

### Log Rotation
The system automatically rotates logs. Configure in `/etc/logrotate.d/backup-scripts`:

```bash
/path/to/backup-scripts/logs/*.log {
    daily
    missingok
    rotate 30
    compress
    notifempty
    create 644 backup backup
    postrotate
        systemctl reload backup-scheduler
    endscript
}
```

### Disk Space Monitoring
```bash
# Check backup disk usage
du -sh backups/

# Clean up old local backups
find backups/ -name "*.sql*" -mtime +30 -delete
```

### Performance Tuning
```bash
# Adjust concurrent uploads based on system resources
MAX_CONCURRENT_UPLOADS=3

# Optimize for large databases
MULTIPART_THRESHOLD=104857600  # 100MB
CHUNK_SIZE=10485760           # 10MB
```

## Troubleshooting

### Common Issues

#### 1. Permission Denied
```bash
# Fix file permissions
sudo chown -R backup:backup /opt/backup-scripts
chmod +x backup-scripts/backup.sh
```

#### 2. Database Connection Failed
```bash
# Test connection
psql -h localhost -U postgres -d your_database

# Check connection settings
DB_HOST=localhost DB_USER=postgres DB_PASSWORD=secret npm run backup:full
```

#### 3. S3 Upload Failed
```bash
# Test AWS credentials
aws s3 ls

# Check bucket permissions
aws s3api get-bucket-policy --bucket your-backup-bucket
```

#### 4. Encryption Key Invalid
```bash
# Verify encryption key format (32 characters)
echo $ENCRYPTION_KEY | wc -c  # Should be 33 (includes newline)

# Generate new key if needed
openssl rand -hex 16
```

### Debug Mode
```bash
# Enable verbose logging
DEBUG=true npm run backup:full

# Check scheduler logs
tail -f logs/backup-scheduler/scheduler.log

# Validate configuration
npm run scheduler:status
```

## Testing

### Unit Tests
```bash
npm test
npm run test:watch
```

### Integration Tests
```bash
# Test backup and restore cycle
npm run backup:full
npm run validate
./backup.sh restore --backup-file ./backups/latest-backup.sql
```

### Performance Tests
```bash
# Test with large database
time npm run backup:full
```

## License

MIT License - see LICENSE file for details.

## Support

For issues and questions:
- GitHub Issues: https://github.com/yourorg/database-backup-scripts/issues
- Documentation: https://github.com/yourorg/database-backup-scripts/wiki
- Email: support@yourcompany.com

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## Changelog

### v1.0.0
- Initial release
- Full PostgreSQL/Neon backup support
- AWS S3 integration with lifecycle policies
- Automated scheduling with cron-like expressions
- Comprehensive validation and integrity checking
- Email and Slack notifications
- Cross-region replication support
- Quarantine system for failed backups
- Detailed reporting and monitoring
