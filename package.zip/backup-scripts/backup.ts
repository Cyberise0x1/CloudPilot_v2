#!/usr/bin/env node
/**
 * PostgreSQL/Neon Database Backup Script
 * Supports full and incremental backups with compression and encryption
 */

import { execSync, spawn } from 'child_process';
import { createWriteStream, createReadStream, existsSync, mkdirSync, statSync } from 'fs';
import { join, basename, dirname } from 'path';
import { createGzip, createGunzip } from 'zlib';
import { randomBytes, createCipheriv, createDecipheriv } from 'crypto';
import * as S3 from 'aws-sdk/clients/s3';

interface BackupConfig {
  database: string;
  host: string;
  port: number;
  username: string;
  password: string;
  backupType: 'full' | 'incremental';
  outputDirectory: string;
  encryptionKey?: string;
  compress: boolean;
  awsS3Bucket?: string;
  retentionDays: number;
}

interface BackupMetadata {
  timestamp: string;
  type: 'full' | 'incremental';
  database: string;
  size: number;
  compressed: boolean;
  encrypted: boolean;
  checksum: string;
  version: string;
}

class DatabaseBackup {
  private config: BackupConfig;
  private backupPath: string;
  private metadata: BackupMetadata;

  constructor(config: BackupConfig) {
    this.config = config;
    this.backupPath = '';
    this.metadata = {
      timestamp: new Date().toISOString(),
      type: config.backupType,
      database: config.database,
      size: 0,
      compressed: config.compress,
      encrypted: !!config.encryptionKey,
      checksum: '',
      version: '1.0.0'
    };
  }

  /**
   * Execute full database backup using pg_dump
   */
  async performFullBackup(): Promise<void> {
    console.log('🔄 Starting full database backup...');
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `full-backup-${this.config.database}-${timestamp}.sql`;
    this.backupPath = join(this.config.outputDirectory, filename);

    // Ensure output directory exists
    if (!existsSync(this.config.outputDirectory)) {
      mkdirSync(this.config.outputDirectory, { recursive: true });
    }

    // Build pg_dump command
    const pgDumpArgs = [
      '-h', this.config.host,
      '-p', this.config.port.toString(),
      '-U', this.config.username,
      '-d', this.config.database,
      '--verbose',
      '--no-password',
      '--format=custom',
      '--compress=9',
      '--file', this.backupPath
    ];

    // Set password environment variable
    process.env.PGPASSWORD = this.config.password;

    try {
      // Execute pg_dump
      const result = execSync(`pg_dump ${pgDumpArgs.join(' ')}`, {
        stdio: 'pipe',
        encoding: 'utf-8'
      });

      // Get file stats
      const stats = statSync(this.backupPath);
      this.metadata.size = stats.size;

      console.log(`✅ Full backup completed: ${filename}`);
      console.log(`📊 Backup size: ${this.formatBytes(stats.size)}`);
      
    } catch (error) {
      console.error('❌ Full backup failed:', error);
      throw error;
    } finally {
      delete process.env.PGPASSWORD;
    }
  }

  /**
   * Execute incremental backup using WAL archiving
   */
  async performIncrementalBackup(): Promise<void> {
    console.log('🔄 Starting incremental backup (WAL)...');
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const walFilename = `incremental-backup-${this.config.database}-${timestamp}.tar`;
    this.backupPath = join(this.config.outputDirectory, walFilename);

    // Ensure output directory exists
    if (!existsSync(this.config.outputDirectory)) {
      mkdirSync(this.config.outputDirectory, { recursive: true });
    }

    try {
      // Archive WAL files
      const walCmd = `
        tar -czf ${this.backupPath} \\
        -C /var/lib/postgresql/data/pg_wal \\
        --transform 's/^/${this.config.database}-${timestamp}-wal-/' \\
        .
      `;

      execSync(walCmd, { stdio: 'pipe' });

      // Get file stats
      const stats = statSync(this.backupPath);
      this.metadata.size = stats.size;

      console.log(`✅ Incremental backup completed: ${walFilename}`);
      console.log(`📊 Backup size: ${this.formatBytes(stats.size)}`);
      
    } catch (error) {
      console.error('❌ Incremental backup failed:', error);
      throw error;
    }
  }

  /**
   * Compress backup file using gzip
   */
  async compressBackup(): Promise<void> {
    if (!this.config.compress) return;

    console.log('🗜️  Compressing backup file...');
    
    const compressedPath = `${this.backupPath}.gz`;
    
    return new Promise((resolve, reject) => {
      const input = createReadStream(this.backupPath);
      const output = createWriteStream(compressedPath);
      const gzip = createGzip({ level: 9 });

      input.pipe(gzip).pipe(output);

      output.on('finish', () => {
        const stats = statSync(compressedPath);
        this.metadata.size = stats.size;
        console.log(`✅ Compression completed: ${basename(compressedPath)}`);
        resolve();
      });

      output.on('error', reject);
      input.on('error', reject);
    });
  }

  /**
   * Encrypt backup file using AES-256
   */
  async encryptBackup(): Promise<void> {
    if (!this.config.encryptionKey) return;

    console.log('🔐 Encrypting backup file...');
    
    const encryptedPath = `${this.backupPath}.enc`;
    const key = Buffer.from(this.config.encryptionKey, 'hex');
    const iv = randomBytes(16);
    const cipher = createCipheriv('aes-256-cbc', key, iv);

    return new Promise((resolve, reject) => {
      const input = createReadStream(this.backupPath);
      const output = createWriteStream(encryptedPath);

      // Write IV to file for decryption
      output.write(iv);

      input.pipe(cipher).pipe(output);

      output.on('finish', () => {
        console.log(`✅ Encryption completed: ${basename(encryptedPath)}`);
        resolve();
      });

      output.on('error', reject);
      input.on('error', reject);
    });
  }

  /**
   * Calculate checksum for backup integrity
   */
  async calculateChecksum(): Promise<void> {
    console.log('🔍 Calculating checksum...');
    
    try {
      const checksum = execSync(`sha256sum ${this.backupPath}`, {
        encoding: 'utf-8'
      }).split(' ')[0];

      this.metadata.checksum = checksum;
      console.log(`✅ Checksum calculated: ${checksum}`);
    } catch (error) {
      console.error('❌ Checksum calculation failed:', error);
      throw error;
    }
  }

  /**
   * Upload backup to AWS S3
   */
  async uploadToS3(): Promise<void> {
    if (!this.config.awsS3Bucket) return;

    console.log('☁️  Uploading to AWS S3...');
    
    try {
      const s3 = new S3();
      const fileContent = createReadStream(this.backupPath);
      const key = `backups/${this.config.database}/${basename(this.backupPath)}`;

      await s3.upload({
        Bucket: this.config.awsS3Bucket,
        Key: key,
        Body: fileContent,
        ServerSideEncryption: 'AES256'
      }).promise();

      console.log(`✅ Uploaded to S3: s3://${this.config.awsS3Bucket}/${key}`);
    } catch (error) {
      console.error('❌ S3 upload failed:', error);
      throw error;
    }
  }

  /**
   * Save backup metadata
   */
  async saveMetadata(): Promise<void> {
    const metadataPath = `${this.backupPath}.metadata.json`;
    
    try {
      const metadataContent = JSON.stringify(this.metadata, null, 2);
      execSync(`echo '${metadataContent}' > ${metadataPath}`, {
        stdio: 'pipe'
      });

      console.log(`✅ Metadata saved: ${basename(metadataPath)}`);
    } catch (error) {
      console.error('❌ Metadata save failed:', error);
      throw error;
    }
  }

  /**
   * Clean up old backups based on retention policy
   */
  async cleanupOldBackups(): Promise<void> {
    console.log(`🧹 Cleaning up backups older than ${this.config.retentionDays} days...`);
    
    try {
      const cleanupCmd = `
        find ${this.config.outputDirectory} \\
        -name "*.sql*" -o -name "*.tar*" \\
        -mtime +${this.config.retentionDays} \\
        -delete
      `;

      execSync(cleanupCmd, { stdio: 'pipe' });
      console.log('✅ Old backups cleaned up');
    } catch (error) {
      console.error('⚠️  Cleanup warning:', error);
    }
  }

  /**
   * Execute complete backup workflow
   */
  async execute(): Promise<void> {
    try {
      console.log(`🚀 Starting ${this.config.backupType} backup process...`);
      console.log(`📋 Database: ${this.config.database}`);
      console.log(`📅 Timestamp: ${this.metadata.timestamp}`);
      console.log('---');

      // Perform backup based on type
      if (this.config.backupType === 'full') {
        await this.performFullBackup();
      } else {
        await this.performIncrementalBackup();
      }

      // Apply compression
      if (this.config.compress) {
        await this.compressBackup();
      }

      // Apply encryption
      if (this.config.encryptionKey) {
        await this.encryptBackup();
      }

      // Calculate checksum
      await this.calculateChecksum();

      // Upload to S3
      if (this.config.awsS3Bucket) {
        await this.uploadToS3();
      }

      // Save metadata
      await this.saveMetadata();

      // Cleanup old backups
      await this.cleanupOldBackups();

      console.log('---');
      console.log('✅ Backup process completed successfully!');
      console.log(`📁 Backup location: ${this.backupPath}`);
      console.log(`📊 Final size: ${this.formatBytes(this.metadata.size)}`);

    } catch (error) {
      console.error('❌ Backup process failed:', error);
      process.exit(1);
    }
  }

  /**
   * Format bytes to human readable
   */
  private formatBytes(bytes: number): string {
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    if (bytes === 0) return '0 Bytes';
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
  }
}

// CLI interface
async function main() {
  const args = process.argv.slice(2);
  const config: BackupConfig = {
    database: process.env.DB_NAME || '',
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432'),
    username: process.env.DB_USER || '',
    password: process.env.DB_PASSWORD || '',
    backupType: (args[0] as 'full' | 'incremental') || 'full',
    outputDirectory: process.env.BACKUP_DIR || './backups',
    encryptionKey: process.env.ENCRYPTION_KEY,
    compress: process.env.COMPRESS !== 'false',
    awsS3Bucket: process.env.S3_BUCKET,
    retentionDays: parseInt(process.env.RETENTION_DAYS || '30')
  };

  if (!config.database || !config.username || !config.password) {
    console.error('❌ Missing required configuration. Please set:');
    console.error('   DB_NAME, DB_USER, DB_PASSWORD');
    process.exit(1);
  }

  const backup = new DatabaseBackup(config);
  await backup.execute();
}

if (require.main === module) {
  main().catch(console.error);
}

export default DatabaseBackup;
