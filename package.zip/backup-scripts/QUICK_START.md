# Quick Start Guide

## Get up and running in 5 minutes

### Step 1: Prerequisites Check

Make sure you have the required software installed:

```bash
# Check Node.js (v16+ required)
node --version

# Check PostgreSQL client
pg_dump --version

# Check AWS CLI
aws --version
```

If any are missing, install them:
```bash
# Ubuntu/Debian
sudo apt-get install -y postgresql-client awscli nodejs npm

# Or use the automated installer
sudo ./install.sh
```

### Step 2: Configure Environment

```bash
# Copy example configuration
cp .env.example .env

# Edit with your database details
nano .env
```

Minimum required settings:
```bash
DB_NAME=your_database_name
DB_HOST=localhost
DB_USER=postgres
DB_PASSWORD=your_password
```

### Step 3: Test Database Connection

```bash
# Test connection
PGPASSWORD=your_password psql -h localhost -U postgres -d your_database -c "SELECT 1;"

# Expected output: 1 row with value 1
```

### Step 4: Run Your First Backup

```bash
# Full backup
DB_NAME=your_db DB_USER=postgres DB_PASSWORD=your_pass npm run backup:full

# Check the backup file
ls -lh backups/
```

### Step 5: Enable AWS S3 (Optional)

```bash
# In your .env file, add:
AWS_ACCESS_KEY_ID=your_key
AWS_SECRET_ACCESS_KEY=your_secret
S3_BUCKET=your-bucket-name
```

```bash
# Initialize S3 bucket
npm run cloud:init

# Upload backup to cloud
npm run cloud:upload -- backups/latest-backup.sql
```

## Common Operations

### Daily Operations

```bash
# Create a backup
npm run backup:full

# Validate your backups
npm run validate

# Check cloud storage
npm run cloud:list
npm run cloud:stats
```

### Automated Scheduling

```bash
# Start the scheduler (runs in background)
npm run scheduler:start

# Check status
npm run scheduler:status

# Stop the scheduler
npm run scheduler:stop
```

### Troubleshooting

```bash
# Run in verbose mode
DEBUG=true npm run backup:full

# Check logs
tail -f logs/backup-scheduler/scheduler.log

# Test configuration
./test-backup.sh
```

## Example Cron Setup

Add to your crontab (`crontab -e`):

```bash
# Daily full backup at 2 AM
0 2 * * * cd /opt/backup-scripts && npm run backup:full >> /var/log/backup.log 2>&1

# Weekly validation on Sunday at 3 AM
0 3 * * 0 cd /opt/backup-scripts && npm run validate:report >> /var/log/backup-validate.log 2>&1
```

## Example systemd Service

```bash
# Start service
sudo systemctl start backup-scheduler

# Enable auto-start
sudo systemctl enable backup-scheduler

# Check status
sudo systemctl status backup-scheduler

# View logs
sudo journalctl -u backup-scheduler -f
```

## Security Checklist

- [ ] Change default database password
- [ ] Generate strong encryption key (32 characters)
- [ ] Restrict file permissions: `chmod 600 .env`
- [ ] Use dedicated backup user (not postgres)
- [ ] Enable S3 server-side encryption
- [ ] Review S3 bucket permissions
- [ ] Configure backup user with minimal permissions
- [ ] Test backup restoration regularly

## Backup User Setup

```sql
-- Connect as superuser (postgres)
psql -U postgres

-- Create dedicated backup user
CREATE USER backup_user WITH ENCRYPTED PASSWORD 'secure_password_here';

-- Grant minimal permissions
GRANT CONNECT ON DATABASE your_database TO backup_user;
GRANT USAGE ON SCHEMA public TO backup_user;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO backup_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO backup_user;
```

## Encryption Key Generation

```bash
# Generate secure 32-character key
openssl rand -hex 16

# Add to .env
ENCRYPTION_KEY=your_64_character_hex_key_here
```

## File Locations

- Configuration: `/etc/backup-scripts/.env` (after installation) or `./.env`
- Backups: `./backups/` or configured directory
- Logs: `./logs/backup-scheduler/`
- Scripts: `/opt/backup-scripts/` (after installation)

## Getting Help

- Full documentation: `README.md`
- Configuration reference: `.env.example`
- CI/CD examples: `JENKINS_PIPELINE_EXAMPLE.md`
- Installation: `install.sh`

## Quick Validation

```bash
# Validate all backups
npm run validate

# Generate HTML report
GENERATE_REPORT=true REPORT_FORMAT=html npm run validate

# Open report in browser
# file://$(pwd)/backup-validation-report.html
```

## Success! ✅

Your backup system is now configured and ready to use. For production deployment:

1. Review security settings
2. Configure monitoring and alerts
3. Set up automated scheduling
4. Test backup restoration
5. Document your configuration

Need more help? Check the full README.md for detailed documentation.
