#!/usr/bin/env node
/**
 * Backup Scheduler
 * Automated backup scheduling with cron-like functionality, monitoring, and alerting
 */

import { spawn, execSync } from 'child_process';
import { existsSync, mkdirSync, readFileSync, writeFileSync, unlinkSync } from 'fs';
import { join, dirname } from 'path';
import * as cron from 'node-cron';

interface ScheduleConfig {
  scheduleType: 'simple' | 'cron' | 'complex';
  cronExpression?: string;
  schedules: Schedule[];
  timezone: string;
  enableMonitoring: boolean;
  monitoringInterval: number;
  maxConcurrentBackups: number;
  backupTimeout: number;
  enableEmailAlerts: boolean;
  emailConfig: {
    smtpHost: string;
    smtpPort: number;
    smtpUser: string;
    smtpPassword: string;
    fromEmail: string;
    toEmails: string[];
    useTLS: boolean;
  };
  enableSlackAlerts: boolean;
  slackConfig: {
    webhookUrl: string;
    channel: string;
    username: string;
  };
  logDirectory: string;
  pidFile: string;
  stateFile: string;
  enableHealthChecks: boolean;
  healthCheckInterval: number;
  autoCleanup: boolean;
  maxLogFiles: number;
}

interface Schedule {
  name: string;
  type: 'full' | 'incremental';
  enabled: boolean;
  schedule: string; // cron expression
  retention: number; // days
  config: {
    database: string;
    host: string;
    port: number;
    username: string;
    password: string;
    outputDirectory?: string;
    encrypt?: boolean;
    encryptionKey?: string;
    compress?: boolean;
    s3Bucket?: string;
    priority?: 'low' | 'normal' | 'high';
  };
  notifications: {
    onSuccess: boolean;
    onFailure: boolean;
    onTimeout: boolean;
  };
  dependencies?: string[]; // Other schedules that must complete first
  timeoutMinutes?: number;
  retryAttempts?: number;
  retryDelayMinutes?: number;
}

interface BackupJob {
  id: string;
  scheduleName: string;
  type: 'full' | 'incremental';
  status: 'pending' | 'running' | 'completed' | 'failed' | 'timeout';
  startTime: Date;
  endTime?: Date;
  duration?: number;
  pid?: number;
  error?: string;
  exitCode?: number;
  logs: string;
  retries: number;
  metadata: any;
}

interface SystemMetrics {
  timestamp: Date;
  cpuUsage: number;
  memoryUsage: number;
  diskUsage: number;
  activeBackups: number;
  totalBackupsToday: number;
  averageBackupTime: number;
  lastBackupTime?: Date;
}

class BackupScheduler {
  private config: ScheduleConfig;
  private jobs: Map<string, BackupJob> = new Map();
  private schedules: Map<string, any> = new Map();
  private systemMetrics: SystemMetrics;
  private healthCheckTask?: any;
  private monitoringTask?: any;
  private isRunning = false;

  constructor(config: ScheduleConfig) {
    this.config = config;
    this.systemMetrics = {
      timestamp: new Date(),
      cpuUsage: 0,
      memoryUsage: 0,
      diskUsage: 0,
      activeBackups: 0,
      totalBackupsToday: 0,
      averageBackupTime: 0
    };

    // Ensure directories exist
    if (!existsSync(this.config.logDirectory)) {
      mkdirSync(this.config.logDirectory, { recursive: true });
    }
  }

  /**
   * Initialize scheduler
   */
  async initialize(): Promise<void> {
    console.log('🚀 Initializing Backup Scheduler...');

    // Setup signal handlers
    this.setupSignalHandlers();

    // Load existing state
    await this.loadState();

    // Setup logging
    this.setupLogging();

    // Validate configuration
    this.validateConfig();

    // Setup schedules
    this.setupSchedules();

    console.log('✅ Scheduler initialized successfully');
  }

  /**
   * Setup signal handlers for graceful shutdown
   */
  private setupSignalHandlers(): void {
    process.on('SIGTERM', () => this.gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => this.gracefulShutdown('SIGINT'));
    
    process.on('unhandledRejection', (reason, promise) => {
      console.error('Unhandled Rejection at:', promise, 'reason:', reason);
      this.logError('Unhandled Rejection', reason as any);
    });
    
    process.on('uncaughtException', (error) => {
      console.error('Uncaught Exception:', error);
      this.logError('Uncaught Exception', error);
    });
  }

  /**
   * Validate configuration
   */
  private validateConfig(): void {
    if (this.config.scheduleType === 'cron' && !this.config.cronExpression) {
      throw new Error('Cron expression required for cron schedule type');
    }

    if (this.config.scheduleType === 'complex' && this.config.schedules.length === 0) {
      throw new Error('At least one schedule required for complex schedule type');
    }

    if (this.config.enableEmailAlerts) {
      const emailConfig = this.config.emailConfig;
      if (!emailConfig.smtpHost || !emailConfig.smtpUser || !emailConfig.toEmails.length) {
        throw new Error('Invalid email configuration');
      }
    }
  }

  /**
   * Setup schedules based on configuration
   */
  private setupSchedules(): void {
    console.log('📅 Setting up backup schedules...');

    if (this.config.scheduleType === 'simple') {
      // Single schedule - run daily at 2 AM
      const task = cron.schedule('0 2 * * *', () => {
        this.executeSchedule('daily-full-backup');
      }, {
        scheduled: false,
        timezone: this.config.timezone
      });

      this.schedules.set('daily-full-backup', task);
      
    } else if (this.config.scheduleType === 'cron') {
      // Single cron-based schedule
      const task = cron.schedule(this.config.cronExpression!, () => {
        this.executeSchedule('scheduled-backup');
      }, {
        scheduled: false,
        timezone: this.config.timezone
      });

      this.schedules.set('scheduled-backup', task);
      
    } else if (this.config.scheduleType === 'complex') {
      // Multiple schedules
      for (const schedule of this.config.schedules) {
        if (!schedule.enabled) continue;

        const task = cron.schedule(schedule.schedule, () => {
          this.executeSchedule(schedule.name);
        }, {
          scheduled: false,
          timezone: this.config.timezone
        });

        this.schedules.set(schedule.name, task);
        console.log(`✅ Scheduled: ${schedule.name} (${schedule.schedule})`);
      }
    }

    console.log(`✅ ${this.schedules.size} schedules configured`);
  }

  /**
   * Execute a backup schedule
   */
  private async executeSchedule(scheduleName: string): Promise<void> {
    console.log(`🔄 Executing schedule: ${scheduleName}`);

    // Check if already running
    const existingJob = Array.from(this.jobs.values()).find(
      job => job.scheduleName === scheduleName && job.status === 'running'
    );

    if (existingJob) {
      console.warn(`⚠️  Schedule ${scheduleName} is already running`);
      return;
    }

    // Check concurrency limits
    if (this.jobs.size >= this.config.maxConcurrentBackups) {
      console.warn(`⚠️  Maximum concurrent backups reached (${this.config.maxConcurrentBackups})`);
      return;
    }

    const schedule = this.config.schedules.find(s => s.name === scheduleName);
    if (!schedule) {
      console.error(`❌ Schedule not found: ${scheduleName}`);
      return;
    }

    // Check dependencies
    const dependencyJobs = this.getDependencyJobs(schedule.dependencies || []);
    const failedDependencies = dependencyJobs.filter(job => job.status === 'failed');
    
    if (failedDependencies.length > 0) {
      console.error(`❌ Dependencies failed for ${scheduleName}:`, failedDependencies.map(j => j.id));
      await this.handleFailure(scheduleName, 'Dependencies failed');
      return;
    }

    // Create job
    const jobId = this.generateJobId();
    const job: BackupJob = {
      id: jobId,
      scheduleName,
      type: schedule.type,
      status: 'pending',
      startTime: new Date(),
      logs: '',
      retries: 0,
      metadata: {
        database: schedule.config.database,
        schedule: schedule.schedule,
        retention: schedule.retention
      }
    };

    this.jobs.set(jobId, job);

    try {
      // Run backup
      await this.runBackup(job, schedule);
      
    } catch (error) {
      console.error(`❌ Backup failed for ${scheduleName}:`, error);
      await this.handleFailure(scheduleName, error as any);
    }
  }

  /**
   * Run backup for a job
   */
  private async runBackup(job: BackupJob, schedule: Schedule): Promise<void> {
    job.status = 'running';
    this.systemMetrics.activeBackups++;

    console.log(`💾 Starting backup: ${job.id} (${schedule.config.database})`);

    const logFile = this.getJobLogFile(job.id);
    
    try {
      // Prepare command
      const cmdArgs = [
        'backup.ts',
        schedule.type,
        '--database', schedule.config.database,
        '--host', schedule.config.host,
        '--port', schedule.config.port.toString(),
        '--user', schedule.config.username,
        '--password', schedule.config.password
      ];

      if (schedule.config.outputDirectory) {
        cmdArgs.push('--output-dir', schedule.config.outputDirectory);
      }

      if (schedule.config.encrypt && schedule.config.encryptionKey) {
        cmdArgs.push('--encrypt', schedule.config.encryptionKey);
      }

      if (schedule.config.compress !== false) {
        cmdArgs.push('--compress');
      }

      if (schedule.config.s3Bucket) {
        cmdArgs.push('--s3-bucket', schedule.config.s3Bucket);
      }

      // Execute backup
      const childProcess = spawn('node', cmdArgs, {
        cwd: __dirname,
        stdio: ['pipe', 'pipe', 'pipe']
      });

      job.pid = childProcess.pid;

      // Handle output
      childProcess.stdout.on('data', (data) => {
        const log = data.toString();
        job.logs += log;
        process.stdout.write(log);
      });

      childProcess.stderr.on('data', (data) => {
        const log = data.toString();
        job.logs += log;
        process.stderr.write(log);
      });

      // Handle completion
      const timeout = (schedule.timeoutMinutes || this.config.backupTimeout) * 60 * 1000;
      
      const completionPromise = new Promise<void>((resolve, reject) => {
        childProcess.on('close', (code) => {
          job.endTime = new Date();
          job.duration = job.endTime.getTime() - job.startTime.getTime();
          job.exitCode = code || 0;

          if (code === 0) {
            job.status = 'completed';
            resolve();
          } else {
            reject(new Error(`Backup failed with exit code ${code}`));
          }
        });

        childProcess.on('error', (error) => {
          reject(error);
        });
      });

      // Set timeout
      const timeoutPromise = new Promise<void>((_, reject) => {
        setTimeout(() => {
          childProcess.kill('SIGTERM');
          reject(new Error('Backup timeout'));
        }, timeout);
      });

      await Promise.race([completionPromise, timeoutPromise]);

      // Update metrics
      this.systemMetrics.totalBackupsToday++;
      this.systemMetrics.lastBackupTime = new Date();
      
      // Handle success
      if (job.status === 'completed') {
        console.log(`✅ Backup completed: ${job.id} (${job.duration}ms)`);
        
        if (schedule.notifications.onSuccess) {
          await this.sendSuccessNotification(job, schedule);
        }

        // Cleanup old backups
        if (this.config.autoCleanup) {
          await this.cleanupOldBackups(schedule);
        }
      }

    } catch (error) {
      job.status = 'failed';
      job.error = error.message;
      console.error(`❌ Backup failed: ${job.id} - ${error.message}`);
      
      if (schedule.notifications.onFailure) {
        await this.sendFailureNotification(job, schedule, error as any);
      }

      // Retry if configured
      if (schedule.retryAttempts && job.retries < schedule.retryAttempts) {
        job.retries++;
        const delay = (schedule.retryDelayMinutes || 5) * 60 * 1000;
        
        console.log(`⏳ Retrying backup in ${schedule.retryDelayMinutes} minutes...`);
        setTimeout(() => {
          this.runBackup(job, schedule);
        }, delay);
      }

    } finally {
      this.systemMetrics.activeBackups--;
      this.saveState();
    }
  }

  /**
   * Handle backup failure
   */
  private async handleFailure(scheduleName: string, error: any): Promise<void> {
    console.error(`❌ Schedule ${scheduleName} failed:`, error);
    
    // Send failure notification
    if (this.config.enableEmailAlerts || this.config.enableSlackAlerts) {
      await this.sendFailureAlert(scheduleName, error);
    }

    // Log to file
    this.logError(`Schedule ${scheduleName} failed`, error);
  }

  /**
   * Get dependency jobs
   */
  private getDependencyJobs(dependencies: string[]): BackupJob[] {
    const jobs: BackupJob[] = [];
    
    for (const dep of dependencies) {
      const depJobs = Array.from(this.jobs.values())
        .filter(job => job.scheduleName === dep)
        .sort((a, b) => b.startTime.getTime() - a.startTime.getTime());
      
      if (depJobs.length > 0) {
        jobs.push(depJobs[0]);
      }
    }
    
    return jobs;
  }

  /**
   * Start scheduler
   */
  async start(): Promise<void> {
    console.log('▶️  Starting Backup Scheduler...');
    
    if (this.isRunning) {
      console.warn('⚠️  Scheduler is already running');
      return;
    }

    this.isRunning = true;

    // Start all schedules
    for (const [name, task] of this.schedules) {
      task.start();
      console.log(`▶️  Started schedule: ${name}`);
    }

    // Start monitoring if enabled
    if (this.config.enableMonitoring) {
      this.startMonitoring();
    }

    // Start health checks if enabled
    if (this.config.enableHealthChecks) {
      this.startHealthChecks();
    }

    console.log('✅ Scheduler started successfully');
    console.log(`📊 Active schedules: ${this.schedules.size}`);
  }

  /**
   * Stop scheduler
   */
  async stop(): Promise<void> {
    console.log('⏹️  Stopping Backup Scheduler...');

    this.isRunning = false;

    // Stop all schedules
    for (const [name, task] of this.schedules) {
      task.stop();
      console.log(`⏹️  Stopped schedule: ${name}`);
    }

    // Stop monitoring
    if (this.monitoringTask) {
      this.monitoringTask.stop();
    }

    // Stop health checks
    if (this.healthCheckTask) {
      this.healthCheckTask.stop();
    }

    console.log('✅ Scheduler stopped');
  }

  /**
   * Graceful shutdown
   */
  private async gracefulShutdown(signal: string): Promise<void> {
    console.log(`🛑 Received ${signal}, initiating graceful shutdown...`);
    
    await this.stop();
    
    // Save state before exit
    await this.saveState();
    
    process.exit(0);
  }

  /**
   * Start monitoring
   */
  private startMonitoring(): void {
    console.log('📊 Starting monitoring...');

    this.monitoringTask = cron.schedule(`*/${this.config.monitoringInterval} * * * *`, () => {
      this.collectMetrics();
      this.checkAlerts();
    }, {
      scheduled: true,
      timezone: this.config.timezone
    });
  }

  /**
   * Start health checks
   */
  private startHealthChecks(): void {
    console.log('❤️  Starting health checks...');

    this.healthCheckTask = cron.schedule(`*/${this.config.healthCheckInterval} * * * *`, () => {
      this.performHealthCheck();
    }, {
      scheduled: true,
      timezone: this.config.timezone
    });
  }

  /**
   * Collect system metrics
   */
  private collectMetrics(): void {
    try {
      // CPU usage (simplified)
      this.systemMetrics.cpuUsage = process.cpuUsage().user / 1000000;
      
      // Memory usage
      const memUsage = process.memoryUsage();
      this.systemMetrics.memoryUsage = memUsage.heapUsed / memUsage.heapTotal;
      
      // Disk usage (simplified - would need actual implementation)
      this.systemMetrics.diskUsage = 0.5; // Placeholder
      
      // Active backups
      this.systemMetrics.activeBackups = Array.from(this.jobs.values())
        .filter(job => job.status === 'running').length;
      
      this.systemMetrics.timestamp = new Date();
      
      // Save metrics
      this.saveMetrics();
      
    } catch (error) {
      console.error('❌ Failed to collect metrics:', error);
    }
  }

  /**
   * Perform health check
   */
  private performHealthCheck(): void {
    console.log('❤️  Performing health check...');

    const issues: string[] = [];
    
    // Check for failed jobs
    const failedJobs = Array.from(this.jobs.values()).filter(
      job => job.status === 'failed'
    );
    
    if (failedJobs.length > 0) {
      issues.push(`${failedJobs.length} failed backup(s)`);
    }
    
    // Check for jobs running too long
    const longRunningJobs = Array.from(this.jobs.values()).filter(
      job => job.status === 'running' && 
      (Date.now() - job.startTime.getTime()) > (this.config.backupTimeout * 60 * 1000)
    );
    
    if (longRunningJobs.length > 0) {
      issues.push(`${longRunningJobs.length} backup(s) running too long`);
    }
    
    // Check disk space
    if (this.systemMetrics.diskUsage > 0.9) {
      issues.push('Disk usage above 90%');
    }
    
    if (issues.length > 0) {
      console.warn('⚠️  Health check issues:', issues.join(', '));
      this.sendHealthAlert(issues);
    } else {
      console.log('✅ Health check passed');
    }
  }

  /**
   * Send success notification
   */
  private async sendSuccessNotification(job: BackupJob, schedule: Schedule): Promise<void> {
    const message = `✅ Backup completed successfully: ${schedule.name}\n` +
                   `Database: ${schedule.config.database}\n` +
                   `Duration: ${job.duration}ms\n` +
                   `Job ID: ${job.id}`;

    if (this.config.enableEmailAlerts) {
      await this.sendEmailAlert(message, 'Backup Success');
    }

    if (this.config.enableSlackAlerts) {
      await this.sendSlackAlert(message);
    }
  }

  /**
   * Send failure notification
   */
  private async sendFailureNotification(job: BackupJob, schedule: Schedule, error: any): Promise<void> {
    const message = `❌ Backup failed: ${schedule.name}\n` +
                   `Database: ${schedule.config.database}\n` +
                   `Error: ${error.message}\n` +
                   `Job ID: ${job.id}`;

    if (this.config.enableEmailAlerts) {
      await this.sendEmailAlert(message, 'Backup Failed');
    }

    if (this.config.enableSlackAlerts) {
      await this.sendSlackAlert(message);
    }
  }

  /**
   * Send failure alert
   */
  private async sendFailureAlert(scheduleName: string, error: any): Promise<void> {
    const message = `❌ Backup schedule failed: ${scheduleName}\n` +
                   `Error: ${error.message}\n` +
                   `Time: ${new Date().toISOString()}`;

    if (this.config.enableEmailAlerts) {
      await this.sendEmailAlert(message, 'Backup Schedule Failed');
    }

    if (this.config.enableSlackAlerts) {
      await this.sendSlackAlert(message);
    }
  }

  /**
   * Send health alert
   */
  private async sendHealthAlert(issues: string[]): Promise<void> {
    const message = `⚠️  Backup scheduler health issues:\n` +
                   issues.map(issue => `- ${issue}`).join('\n') +
                   `\nTime: ${new Date().toISOString()}`;

    if (this.config.enableEmailAlerts) {
      await this.sendEmailAlert(message, 'Backup Health Alert');
    }

    if (this.config.enableSlackAlerts) {
      await this.sendSlackAlert(message);
    }
  }

  /**
   * Send email alert
   */
  private async sendEmailAlert(message: string, subject: string): Promise<void> {
    // Implementation would use nodemailer or similar
    console.log(`📧 Email Alert [${subject}]:\n${message}`);
  }

  /**
   * Send Slack alert
   */
  private async sendSlackAlert(message: string): Promise<void> {
    // Implementation would use Slack webhook or API
    console.log(`📱 Slack Alert:\n${message}`);
  }

  /**
   * Check for alerts
   */
  private checkAlerts(): void {
    // Check for overdue backups
    // Check for high resource usage
    // Check for failed jobs
  }

  /**
   * Cleanup old backups
   */
  private async cleanupOldBackups(schedule: Schedule): Promise<void> {
    try {
      const outputDir = schedule.config.outputDirectory || './backups';
      
      execSync(`find ${outputDir} -name "*.sql*" -o -name "*.tar*" -o -name "*.enc*" -mtime +${schedule.retention} -delete`, {
        stdio: 'pipe'
      });
      
      console.log(`🧹 Cleaned up backups older than ${schedule.retention} days`);
      
    } catch (error) {
      console.error('❌ Cleanup failed:', error);
    }
  }

  /**
   * Get job log file path
   */
  private getJobLogFile(jobId: string): string {
    return join(this.config.logDirectory, `job-${jobId}.log`);
  }

  /**
   * Generate unique job ID
   */
  private generateJobId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Save state
   */
  private async saveState(): Promise<void> {
    try {
      const state = {
        jobs: Array.from(this.jobs.entries()),
        metrics: this.systemMetrics,
        timestamp: new Date().toISOString()
      };

      writeFileSync(this.config.stateFile, JSON.stringify(state, null, 2));
      
    } catch (error) {
      console.error('❌ Failed to save state:', error);
    }
  }

  /**
   * Load state
   */
  private async loadState(): Promise<void> {
    try {
      if (existsSync(this.config.stateFile)) {
        const stateData = readFileSync(this.config.stateFile, 'utf-8');
        const state = JSON.parse(stateData);
        
        this.jobs = new Map(state.jobs);
        this.systemMetrics = state.metrics;
        
        console.log(`📂 Loaded ${this.jobs.size} jobs from state`);
      }
      
    } catch (error) {
      console.error('❌ Failed to load state:', error);
    }
  }

  /**
   * Save metrics
   */
  private saveMetrics(): void {
    const metricsFile = join(this.config.logDirectory, 'metrics.json');
    
    try {
      let metrics = [];
      
      if (existsSync(metricsFile)) {
        metrics = JSON.parse(readFileSync(metricsFile, 'utf-8'));
      }
      
      metrics.push(this.systemMetrics);
      
      // Keep only last 1000 metrics
      if (metrics.length > 1000) {
        metrics = metrics.slice(-1000);
      }
      
      writeFileSync(metricsFile, JSON.stringify(metrics, null, 2));
      
    } catch (error) {
      console.error('❌ Failed to save metrics:', error);
    }
  }

  /**
   * Setup logging
   */
  private setupLogging(): void {
    const logFile = join(this.config.logDirectory, 'scheduler.log');
    
    // Rotate logs if too many
    this.rotateLogs();
  }

  /**
   * Rotate log files
   */
  private rotateLogs(): void {
    try {
      const logDir = this.config.logDirectory;
      const logFiles = require('fs').readdirSync(logDir)
        .filter((f: string) => f.startsWith('scheduler.log.'))
        .sort();
      
      // Remove old log files
      const filesToDelete = logFiles.slice(0, Math.max(0, logFiles.length - this.config.maxLogFiles + 1));
      
      for (const file of filesToDelete) {
        unlinkSync(join(logDir, file));
      }
      
    } catch (error) {
      console.error('❌ Log rotation failed:', error);
    }
  }

  /**
   * Log error
   */
  private logError(message: string, error: any): void {
    const timestamp = new Date().toISOString();
    const logEntry = `[${timestamp}] ERROR: ${message}\n${error.stack || error}\n`;
    
    const logFile = join(this.config.logDirectory, 'errors.log');
    
    try {
      require('fs').appendFileSync(logFile, logEntry);
    } catch (e) {
      console.error('Failed to write error log:', e);
    }
  }

  /**
   * Get status
   */
  getStatus(): any {
    return {
      isRunning: this.isRunning,
      activeBackups: this.systemMetrics.activeBackups,
      totalJobs: this.jobs.size,
      completedJobs: Array.from(this.jobs.values()).filter(j => j.status === 'completed').length,
      failedJobs: Array.from(this.jobs.values()).filter(j => j.status === 'failed').length,
      schedules: Array.from(this.schedules.keys()),
      metrics: this.systemMetrics
    };
  }
}

// CLI interface
async function main() {
  const command = process.argv[2];
  
  const config: ScheduleConfig = {
    scheduleType: (process.env.SCHEDULE_TYPE as 'simple' | 'cron' | 'complex') || 'complex',
    cronExpression: process.env.CRON_EXPRESSION,
    schedules: JSON.parse(process.env.SCHEDULES_JSON || '[]'),
    timezone: process.env.TIMEZONE || 'UTC',
    enableMonitoring: process.env.ENABLE_MONITORING !== 'false',
    monitoringInterval: parseInt(process.env.MONITORING_INTERVAL || '5'),
    maxConcurrentBackups: parseInt(process.env.MAX_CONCURRENT_BACKUPS || '3'),
    backupTimeout: parseInt(process.env.BACKUP_TIMEOUT || '720'),
    enableEmailAlerts: process.env.ENABLE_EMAIL_ALERTS === 'true',
    emailConfig: {
      smtpHost: process.env.SMTP_HOST || '',
      smtpPort: parseInt(process.env.SMTP_PORT || '587'),
      smtpUser: process.env.SMTP_USER || '',
      smtpPassword: process.env.SMTP_PASSWORD || '',
      fromEmail: process.env.FROM_EMAIL || '',
      toEmails: (process.env.TO_EMAILS || '').split(',').filter(e => e.trim()),
      useTLS: process.env.SMTP_USE_TLS !== 'false'
    },
    enableSlackAlerts: process.env.ENABLE_SLACK_ALERTS === 'true',
    slackConfig: {
      webhookUrl: process.env.SLACK_WEBHOOK_URL || '',
      channel: process.env.SLACK_CHANNEL || '#alerts',
      username: process.env.SLACK_USERNAME || 'BackupBot'
    },
    logDirectory: process.env.LOG_DIR || './logs/backup-scheduler',
    pidFile: process.env.PID_FILE || './backup-scheduler.pid',
    stateFile: process.env.STATE_FILE || './backup-scheduler-state.json',
    enableHealthChecks: process.env.ENABLE_HEALTH_CHECKS !== 'false',
    healthCheckInterval: parseInt(process.env.HEALTH_CHECK_INTERVAL || '15'),
    autoCleanup: process.env.AUTO_CLEANUP !== 'false',
    maxLogFiles: parseInt(process.env.MAX_LOG_FILES || '10')
  };

  const scheduler = new BackupScheduler(config);
  
  // Write PID file
  writeFileSync(config.pidFile, process.pid.toString());
  
  try {
    await scheduler.initialize();
    
    switch (command) {
      case 'start':
        await scheduler.start();
        break;
        
      case 'stop':
        await scheduler.stop();
        break;
        
      case 'status':
        const status = scheduler.getStatus();
        console.log(JSON.stringify(status, null, 2));
        break;
        
      case 'run-once':
        if (process.argv[3]) {
          await scheduler['executeSchedule'](process.argv[3]);
        } else {
          console.error('❌ Schedule name required for run-once');
          process.exit(1);
        }
        break;
        
      default:
        console.log('Usage: backup-scheduler.ts [start|stop|status|run-once <schedule-name>]');
        process.exit(1);
    }
    
  } catch (error) {
    console.error('❌ Scheduler error:', error);
    process.exit(1);
  } finally {
    // Cleanup PID file
    if (existsSync(config.pidFile)) {
      unlinkSync(config.pidFile);
    }
  }
}

if (require.main === module) {
  main().catch(console.error);
}

export default BackupScheduler;
