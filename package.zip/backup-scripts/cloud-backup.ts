#!/usr/bin/env node
/**
 * Cloud Backup Script for AWS S3
 * Advanced S3 backup management with lifecycle policies, versioning, and cross-region replication
 */

import { S3, CreateBucketCommand, PutBucketVersioningCommand, PutBucketLifecycleConfigurationCommand, 
         PutBucketReplicationCommand, GetObjectCommand, PutObjectCommand, ListObjectsV2Command,
         DeleteObjectCommand, HeadObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { createReadStream, createWriteStream, existsSync, mkdirSync } from 'fs';
import { join, basename, dirname } from 'path';
import { pipeline } from 'stream/promises';
import { createGzip } from 'zlib';
import { randomBytes, createCipheriv, createHash } from 'crypto';
import * as path from 'path';

interface CloudBackupConfig {
  awsAccessKeyId: string;
  awsSecretAccessKey: string;
  awsRegion: string;
  s3Bucket: string;
  localBackupDirectory: string;
  bucketPrefix?: string;
  enableVersioning: boolean;
  enableEncryption: boolean;
  encryptionKey?: string;
  lifecyclePolicy: {
    standardDays: number;
    glacierDays: number;
    deleteAfterDays: number;
  };
  crossRegionReplication?: {
    targetRegion: string;
    targetBucket: string;
    roleArn: string;
  };
  compressionEnabled: boolean;
  maxConcurrentUploads: number;
  chunkSize: number;
  enableMultipartUpload: boolean;
  multipartThreshold: number;
}

interface BackupFile {
  key: string;
  size: number;
  lastModified: Date;
  etag: string;
  storageClass: string;
  isLatest: boolean;
  versionId?: string;
}

interface UploadProgress {
  loaded: number;
  total: number;
  percentage: number;
  speed: string;
  eta: string;
}

class CloudBackup {
  private config: CloudBackupConfig;
  private s3: S3;
  private uploadQueue: Array<{ file: string; key: string; priority: number }> = [];
  private activeUploads = 0;

  constructor(config: CloudBackupConfig) {
    this.config = config;
    this.s3 = new S3({
      region: config.awsRegion,
      credentials: {
        accessKeyId: config.awsAccessKeyId,
        secretAccessKey: config.awsSecretAccessKey
      }
    });
  }

  /**
   * Initialize S3 bucket with all configurations
   */
  async initializeBucket(): Promise<void> {
    console.log('🔧 Initializing S3 bucket configuration...');

    try {
      // Create bucket if it doesn't exist
      try {
        await this.s3.send(new CreateBucketCommand({
          Bucket: this.config.s3Bucket
        }));
        console.log(`✅ Created S3 bucket: ${this.config.s3Bucket}`);
      } catch (error: any) {
        if (error.name !== 'BucketAlreadyOwnedByYou') {
          throw error;
        }
        console.log(`ℹ️  Bucket already exists: ${this.config.s3Bucket}`);
      }

      // Enable versioning if required
      if (this.config.enableVersioning) {
        await this.s3.send(new PutBucketVersioningCommand({
          Bucket: this.config.s3Bucket,
          VersioningConfiguration: {
            Status: 'Enabled'
          }
        }));
        console.log('✅ Versioning enabled');
      }

      // Configure lifecycle policy
      await this.configureLifecyclePolicy();
      console.log('✅ Lifecycle policy configured');

      // Enable encryption if required
      if (this.config.enableEncryption) {
        await this.configureEncryption();
        console.log('✅ Encryption configured');
      }

      // Configure cross-region replication if specified
      if (this.config.crossRegionReplication) {
        await this.configureCrossRegionReplication();
        console.log('✅ Cross-region replication configured');
      }

      console.log('✅ Bucket initialization completed');

    } catch (error) {
      console.error('❌ Bucket initialization failed:', error);
      throw error;
    }
  }

  /**
   * Configure S3 lifecycle policy for cost optimization
   */
  private async configureLifecyclePolicy(): Promise<void> {
    const { standardDays, glacierDays, deleteAfterDays } = this.config.lifecyclePolicy;

    const lifecycleRules = [
      {
        ID: 'StandardToGlacier',
        Status: 'Enabled',
        Filter: { Prefix: '' },
        Transitions: [
          {
            Days: standardDays,
            StorageClass: 'STANDARD_IA'
          },
          {
            Days: glacierDays,
            StorageClass: 'GLACIER'
          },
          {
            Days: deleteAfterDays,
            StorageClass: 'DEEP_ARCHIVE'
          }
        ],
        Expiration: {
          Days: deleteAfterDays + 365 // Keep for an additional year in Deep Archive
        },
        AbortIncompleteMultipartUpload: {
          DaysAfterInitiation: 7
        }
      }
    ];

    await this.s3.send(new PutBucketLifecycleConfigurationCommand({
      Bucket: this.config.s3Bucket,
      LifecycleConfiguration: {
        Rules: lifecycleRules
      }
    }));
  }

  /**
   * Enable default encryption for the bucket
   */
  private async configureEncryption(): Promise<void> {
    // This would typically be done via bucket policy
    // For now, we'll configure server-side encryption for all uploads
    console.log('ℹ️  Encryption will be applied to all uploads via server-side encryption');
  }

  /**
   * Configure cross-region replication
   */
  private async configureCrossRegionReplication(): Promise<void> {
    if (!this.config.crossRegionReplication) return;

    const { targetBucket, roleArn } = this.config.crossRegionReplication;

    const replicationConfig = {
      Role: roleArn,
      Rules: [
        {
          ID: 'ReplicationRule',
          Status: 'Enabled',
          Prefix: '',
          Destination: {
            Bucket: `arn:aws:s3:::${targetBucket}`,
            StorageClass: 'STANDARD'
          }
        }
      ]
    };

    await this.s3.send(new PutBucketReplicationCommand({
      Bucket: this.config.s3Bucket,
      ReplicationConfiguration: replicationConfig
    }));
  }

  /**
   * Upload single file to S3 with progress tracking
   */
  async uploadFile(filePath: string, customKey?: string): Promise<string> {
    const key = customKey || this.generateS3Key(filePath);
    const fileName = basename(filePath);
    const bucketKey = this.config.bucketPrefix 
      ? `${this.config.bucketPrefix}/${key}` 
      : key;

    console.log(`📤 Uploading: ${fileName} -> s3://${this.config.s3Bucket}/${bucketKey}`);

    const fileSize = existsSync(filePath) ? 
      require('fs').statSync(filePath).size : 0;

    try {
      const fileStream = createReadStream(filePath);
      
      const uploadParams: any = {
        Bucket: this.config.s3Bucket,
        Key: bucketKey,
        Body: fileStream,
        ServerSideEncryption: 'AES256'
      };

      // Add metadata
      uploadParams.Metadata = {
        'original-filename': fileName,
        'upload-timestamp': new Date().toISOString(),
        'file-size': fileSize.toString()
      };

      // Start upload with progress tracking
      await this.uploadWithProgress(uploadParams, filePath, fileSize);

      console.log(`✅ Upload completed: ${fileName}`);
      return bucketKey;

    } catch (error) {
      console.error(`❌ Upload failed for ${fileName}:`, error);
      throw error;
    }
  }

  /**
   * Upload file with progress tracking and retry logic
   */
  private async uploadWithProgress(params: any, filePath: string, fileSize: number): Promise<void> {
    const maxRetries = 3;
    let retryCount = 0;

    while (retryCount <= maxRetries) {
      try {
        const progressCallback = (progress: any) => {
          const percentage = ((progress.loaded / fileSize) * 100).toFixed(2);
          const speed = this.calculateSpeed(progress.loaded);
          const eta = this.calculateETA(progress.loaded, fileSize, speed);
          
          process.stdout.write(`\rProgress: ${percentage}% | Speed: ${speed} | ETA: ${eta}`);
        };

        if (this.config.enableMultipartUpload && fileSize > this.config.multipartThreshold) {
          await this.multipartUpload(params, progressCallback);
        } else {
          await this.s3.send(new PutObjectCommand({
            ...params,
            Body: createReadStream(filePath)
          }));
        }

        process.stdout.write('\n');
        return; // Success, exit retry loop

      } catch (error) {
        retryCount++;
        if (retryCount > maxRetries) {
          throw error;
        }
        console.log(`\n⚠️  Upload failed, retry ${retryCount}/${maxRetries}...`);
        await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
      }
    }
  }

  /**
   * Multipart upload for large files
   */
  private async multipartUpload(params: any, progressCallback: any): Promise<void> {
    const upload = await this.s3.upload(params).promise();
    // For multipart uploads, we would implement more sophisticated progress tracking
    // This is a simplified version
    progressCallback({ loaded: params.Body.length });
  }

  /**
   * Batch upload multiple files concurrently
   */
  async batchUpload(filePaths: string[], concurrency?: number): Promise<string[]> {
    const maxConcurrency = concurrency || this.config.maxConcurrentUploads;
    const uploadPromises: Promise<string>[] = [];
    const results: string[] = [];

    console.log(`📦 Batch uploading ${filePaths.length} files with concurrency: ${maxConcurrency}`);

    for (const filePath of filePaths) {
      if (this.activeUploads >= maxConcurrency) {
        // Wait for at least one upload to complete
        const completed = await Promise.race(uploadPromises);
        results.push(completed);
        const index = uploadPromises.indexOf(completed);
        uploadPromises.splice(index, 1);
      }

      const uploadPromise = this.uploadFile(filePath).then(key => {
        this.activeUploads--;
        return key;
      });

      uploadPromises.push(uploadPromise);
      this.activeUploads++;
    }

    // Wait for all remaining uploads to complete
    const remainingResults = await Promise.all(uploadPromises);
    results.push(...remainingResults);

    console.log(`✅ Batch upload completed: ${results.length} files uploaded`);
    return results;
  }

  /**
   * Download file from S3 with verification
   */
  async downloadFile(s3Key: string, localPath: string, verifyChecksum = true): Promise<void> {
    console.log(`📥 Downloading: s3://${this.config.s3Bucket}/${s3Key} -> ${localPath}`);

    try {
      // Ensure local directory exists
      const dir = dirname(localPath);
      if (!existsSync(dir)) {
        mkdirSync(dir, { recursive: true });
      }

      const command = new GetObjectCommand({
        Bucket: this.config.s3Bucket,
        Key: s3Key
      });

      const response = await this.s3.send(command);
      const body = response.Body as any;
      
      const writeStream = createWriteStream(localPath);
      await pipeline(body, writeStream);

      // Verify checksum if ETag is available
      if (verifyChecksum && response.ETag) {
        await this.verifyChecksum(localPath, response.ETag);
      }

      console.log(`✅ Download completed: ${localPath}`);

    } catch (error) {
      console.error(`❌ Download failed for ${s3Key}:`, error);
      throw error;
    }
  }

  /**
   * List all backup files in S3 bucket
   */
  async listBackups(prefix?: string): Promise<BackupFile[]> {
    console.log('🔍 Listing backup files in S3...');

    const params: any = {
      Bucket: this.config.s3Bucket,
      Prefix: prefix || this.config.bucketPrefix || ''
    };

    const backups: BackupFile[] = [];
    let continuationToken: string | undefined;

    do {
      const response = await this.s3.send(new ListObjectsV2Command({
        ...params,
        ContinuationToken: continuationToken
      }));

      if (response.Contents) {
        for (const item of response.Contents) {
          const headCommand = new HeadObjectCommand({
            Bucket: this.config.s3Bucket,
            Key: item.Key!
          });

          try {
            const headResponse = await this.s3.send(headCommand);
            backups.push({
              key: item.Key!,
              size: item.Size || 0,
              lastModified: item.LastModified || new Date(),
              etag: headResponse.ETag || '',
              storageClass: headResponse.StorageClass || 'STANDARD',
              isLatest: true // Simplified - would need to check version ID
            });
          } catch (error) {
            console.warn(`Could not get metadata for ${item.Key}:`, error);
          }
        }
      }

      continuationToken = response.IsTruncated ? response.NextContinuationToken : undefined;

    } while (continuationToken);

    console.log(`📊 Found ${backups.length} backup files`);
    return backups;
  }

  /**
   * Delete old backup files based on retention policy
   */
  async cleanupOldBackups(retentionDays: number, prefix?: string): Promise<number> {
    console.log(`🧹 Cleaning up backups older than ${retentionDays} days`);

    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - retentionDays);

    const backups = await this.listBackups(prefix);
    const filesToDelete = backups.filter(backup => 
      backup.lastModified < cutoffDate
    );

    if (filesToDelete.length === 0) {
      console.log('ℹ️  No files to delete');
      return 0;
    }

    console.log(`📋 Found ${filesToDelete.length} files to delete`);

    let deletedCount = 0;
    for (const file of filesToDelete) {
      try {
        await this.s3.send(new DeleteObjectCommand({
          Bucket: this.config.s3Bucket,
          Key: file.key
        }));

        console.log(`🗑️  Deleted: ${basename(file.key)}`);
        deletedCount++;

      } catch (error) {
        console.error(`❌ Failed to delete ${file.key}:`, error);
      }
    }

    console.log(`✅ Cleanup completed: ${deletedCount} files deleted`);
    return deletedCount;
  }

  /**
   * Generate pre-signed URL for secure access
   */
  async generateSignedUrl(s3Key: string, expirationHours = 24): Promise<string> {
    const command = new GetObjectCommand({
      Bucket: this.config.s3Bucket,
      Key: s3Key
    });

    const signedUrl = await getSignedUrl(this.s3, command, {
      expiresIn: expirationHours * 60 * 60 // Convert hours to seconds
    });

    return signedUrl;
  }

  /**
   * Sync local directory to S3
   */
  async syncDirectory(localDir: string, prefix?: string): Promise<void> {
    console.log(`🔄 Syncing directory: ${localDir} -> s3://${this.config.s3Bucket}`);

    const files: string[] = [];
    
    // Recursively find all files
    const walkDir = (dir: string) => {
      const entries = require('fs').readdirSync(dir, { withFileTypes: true });
      
      for (const entry of entries) {
        const fullPath = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          walkDir(fullPath);
        } else {
          files.push(fullPath);
        }
      }
    };

    walkDir(localDir);

    if (files.length === 0) {
      console.log('ℹ️  No files found in directory');
      return;
    }

    const uploadResults = await this.batchUpload(files);
    console.log(`✅ Directory sync completed: ${uploadResults.length} files uploaded`);

  }

  /**
   * Generate S3 key from file path
   */
  private generateS3Key(filePath: string): string {
    const fileName = basename(filePath);
    const date = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    const timestamp = Date.now();
    
    return `backups/${date}/${fileName}.${timestamp}`;
  }

  /**
   * Verify file checksum against ETag
   */
  private async verifyChecksum(filePath: string, expectedETag: string): Promise<void> {
    const fs = require('fs');
    const hash = createHash('md5');
    
    const stream = createReadStream(filePath);
    
    return new Promise((resolve, reject) => {
      stream.on('data', (data: Buffer) => hash.update(data));
      stream.on('end', () => {
        const calculatedETag = hash.digest('hex');
        
        // Remove quotes from ETag if present
        const cleanExpectedETag = expectedETag.replace(/^"|"$/g, '');
        
        if (calculatedETag === cleanExpectedETag) {
          console.log('✅ Checksum verified');
          resolve();
        } else {
          console.warn(`⚠️  Checksum mismatch. Expected: ${cleanExpectedETag}, Calculated: ${calculatedETag}`);
          resolve(); // Don't fail on checksum mismatch for now
        }
      });
      stream.on('error', reject);
    });
  }

  /**
   * Calculate upload speed
   */
  private calculateSpeed(bytes: number): string {
    const speeds = ['B/s', 'KB/s', 'MB/s', 'GB/s'];
    let speed = bytes;
    let index = 0;

    while (speed >= 1024 && index < speeds.length - 1) {
      speed /= 1024;
      index++;
    }

    return `${speed.toFixed(2)} ${speeds[index]}`;
  }

  /**
   * Calculate estimated time remaining
   */
  private calculateETA(loaded: number, total: number, speed: string): string {
    const speedValue = parseFloat(speed.split(' ')[0]);
    const remaining = total - loaded;
    const seconds = remaining / (speedValue * 1024 * 1024); // Assume MB/s
    
    if (seconds < 60) {
      return `${Math.round(seconds)}s`;
    } else if (seconds < 3600) {
      return `${Math.round(seconds / 60)}m`;
    } else {
      return `${Math.round(seconds / 3600)}h`;
    }
  }

  /**
   * Get backup statistics
   */
  async getBackupStats(): Promise<{
    totalFiles: number;
    totalSize: number;
    oldestBackup: Date | null;
    newestBackup: Date | null;
    storageByClass: Record<string, number>;
  }> {
    const backups = await this.listBackups();
    
    const stats = {
      totalFiles: backups.length,
      totalSize: 0,
      oldestBackup: null as Date | null,
      newestBackup: null as Date | null,
      storageByClass: {} as Record<string, number>
    };

    for (const backup of backups) {
      stats.totalSize += backup.size;
      
      if (!stats.oldestBackup || backup.lastModified < stats.oldestBackup) {
        stats.oldestBackup = backup.lastModified;
      }
      
      if (!stats.newestBackup || backup.lastModified > stats.newestBackup) {
        stats.newestBackup = backup.lastModified;
      }
      
      if (!stats.storageByClass[backup.storageClass]) {
        stats.storageByClass[backup.storageClass] = 0;
      }
      stats.storageByClass[backup.storageClass] += backup.size;
    }

    return stats;
  }
}

// CLI interface
async function main() {
  const command = process.argv[2];
  const config: CloudBackupConfig = {
    awsAccessKeyId: process.env.AWS_ACCESS_KEY_ID || '',
    awsSecretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || '',
    awsRegion: process.env.AWS_REGION || 'us-east-1',
    s3Bucket: process.env.S3_BUCKET || '',
    localBackupDirectory: process.env.LOCAL_BACKUP_DIR || './backups',
    bucketPrefix: process.env.S3_PREFIX || 'backups',
    enableVersioning: process.env.S3_VERSIONING === 'true',
    enableEncryption: process.env.S3_ENCRYPTION !== 'false',
    encryptionKey: process.env.ENCRYPTION_KEY,
    lifecyclePolicy: {
      standardDays: parseInt(process.env.LIFECYCLE_STANDARD_DAYS || '30'),
      glacierDays: parseInt(process.env.LIFECYCLE_GLACIER_DAYS || '90'),
      deleteAfterDays: parseInt(process.env.LIFECYCLE_DELETE_DAYS || '365')
    },
    crossRegionReplication: process.env.REPLICATION_ROLE_ARN ? {
      targetRegion: process.env.TARGET_REGION || 'us-west-2',
      targetBucket: process.env.TARGET_BUCKET || '',
      roleArn: process.env.REPLICATION_ROLE_ARN || ''
    } : undefined,
    compressionEnabled: process.env.S3_COMPRESSION === 'true',
    maxConcurrentUploads: parseInt(process.env.MAX_CONCURRENT_UPLOADS || '5'),
    chunkSize: parseInt(process.env.CHUNK_SIZE || '10485760'), // 10MB
    enableMultipartUpload: process.env.MULTIPART_UPLOAD !== 'false',
    multipartThreshold: parseInt(process.env.MULTIPART_THRESHOLD || '104857600') // 100MB
  };

  if (!config.awsAccessKeyId || !config.awsSecretAccessKey || !config.s3Bucket) {
    console.error('❌ Missing required configuration:');
    console.error('   AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, S3_BUCKET');
    process.exit(1);
  }

  const backup = new CloudBackup(config);

  try {
    switch (command) {
      case 'init':
        await backup.initializeBucket();
        break;
        
      case 'upload':
        const filePath = process.argv[3];
        if (!filePath) {
          console.error('❌ File path required for upload');
          process.exit(1);
        }
        await backup.uploadFile(filePath);
        break;
        
      case 'batch-upload':
        const directory = process.argv[3];
        if (!directory || !existsSync(directory)) {
          console.error('❌ Valid directory required for batch upload');
          process.exit(1);
        }
        await backup.syncDirectory(directory);
        break;
        
      case 'list':
        const backups = await backup.listBackups();
        console.log(JSON.stringify(backups, null, 2));
        break;
        
      case 'cleanup':
        const retentionDays = parseInt(process.argv[3] || '30');
        await backup.cleanupOldBackups(retentionDays);
        break;
        
      case 'stats':
        const stats = await backup.getBackupStats();
        console.log('📊 Backup Statistics:');
        console.log(`   Total Files: ${stats.totalFiles}`);
        console.log(`   Total Size: ${(stats.totalSize / 1024 / 1024 / 1024).toFixed(2)} GB`);
        console.log(`   Oldest Backup: ${stats.oldestBackup}`);
        console.log(`   Newest Backup: ${stats.newestBackup}`);
        console.log('   Storage by Class:', stats.storageByClass);
        break;
        
      default:
        console.error('❌ Unknown command. Available commands: init, upload, batch-upload, list, cleanup, stats');
        process.exit(1);
    }
  } catch (error) {
    console.error('❌ Command failed:', error);
    process.exit(1);
  }
}

if (require.main === module) {
  main().catch(console.error);
}

export default CloudBackup;
