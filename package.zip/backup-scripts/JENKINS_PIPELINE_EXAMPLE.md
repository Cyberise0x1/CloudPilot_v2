# Jenkins Pipeline Example for Database Backup
# This file demonstrates how to integrate the backup scripts into a CI/CD pipeline

pipeline {
    agent any
    
    environment {
        // Database configuration
        DB_NAME = 'production_db'
        DB_HOST = 'prod-db.internal'
        DB_USER = 'backup_user'
        DB_PASSWORD = credentials('db-backup-password')
        
        // AWS configuration
        AWS_ACCESS_KEY_ID = credentials('aws-access-key-id')
        AWS_SECRET_ACCESS_KEY = credentials('aws-secret-access-key')
        AWS_REGION = 'us-east-1'
        S3_BUCKET = 'company-backups'
        
        // Security
        ENCRYPTION_KEY = credentials('backup-encryption-key')
        
        // Paths
        BACKUP_DIR = '/tmp/ci-backups'
        WORKSPACE_BACKUP = "${WORKSPACE}/backups"
    }
    
    stages {
        stage('Setup') {
            steps {
                script {
                    echo 'Setting up backup environment...'
                    sh '''
                        # Install dependencies
                        npm install
                        
                        # Create backup directory
                        mkdir -p ${BACKUP_DIR}
                        mkdir -p ${WORKSPACE_BACKUP}
                        
                        # Test database connectivity
                        PGPASSWORD=${DB_PASSWORD} psql -h ${DB_HOST} -U ${DB_USER} -d ${DB_NAME} -c "SELECT 1;"
                    '''
                }
            }
        }
        
        stage('Full Backup') {
            when {
                anyOf {
                    branch 'main'
                    buildingTag()
                    cron '0 2 * * *'  // Daily at 2 AM
                }
            }
            steps {
                script {
                    echo 'Creating full database backup...'
                    sh '''
                        # Run full backup
                        BACKUP_DIR=${WORKSPACE_BACKUP} \\
                        DB_NAME=${DB_NAME} \\
                        DB_HOST=${DB_HOST} \\
                        DB_USER=${DB_USER} \\
                        DB_PASSWORD=${DB_PASSWORD} \\
                        S3_BUCKET=${S3_BUCKET} \\
                        ENCRYPTION_KEY=${ENCRYPTION_KEY} \\
                        npm run backup:full
                        
                        # Check if backup was created
                        if [ -f "${WORKSPACE_BACKUP}"/*.sql ]; then
                            echo "✅ Full backup created successfully"
                            ls -lh ${WORKSPACE_BACKUP}/*.sql
                        else
                            echo "❌ Full backup failed"
                            exit 1
                        fi
                    '''
                }
            }
        }
        
        stage('Incremental Backup') {
            when {
                anyOf {
                    branch 'develop'
                    cron 'H/30 * * * *'  // Every 30 minutes
                }
            }
            steps {
                script {
                    echo 'Creating incremental backup...'
                    sh '''
                        # Run incremental backup
                        BACKUP_DIR=${WORKSPACE_BACKUP} \\
                        DB_NAME=${DB_NAME} \\
                        DB_HOST=${DB_HOST} \\
                        DB_USER=${DB_USER} \\
                        DB_PASSWORD=${DB_PASSWORD} \\
                        npm run backup:incremental
                        
                        echo "✅ Incremental backup created"
                    '''
                }
            }
        }
        
        stage('Cloud Upload') {
            when {
                anyOf {
                    branch 'main'
                    buildingTag()
                }
            }
            steps {
                script {
                    echo 'Uploading backup to AWS S3...'
                    sh '''
                        # Initialize S3 bucket
                        npm run cloud:init
                        
                        # Upload latest backup
                        LATEST_BACKUP=$(ls -t ${WORKSPACE_BACKUP}/*.sql 2>/dev/null | head -1)
                        if [ -n "$LATEST_BACKUP" ]; then
                            npm run cloud:upload -- $LATEST_BACKUP
                            echo "✅ Uploaded to S3: $LATEST_BACKUP"
                        fi
                    '''
                }
            }
        }
        
        stage('Validation') {
            steps {
                script {
                    echo 'Validating backup integrity...'
                    sh '''
                        # Run validation
                        BACKUP_DIR=${WORKSPACE_BACKUP} \\
                        VALIDATION_LEVEL=standard \\
                        GENERATE_REPORT=true \\
                        REPORT_FORMAT=json \\
                        npm run validate
                        
                        echo "✅ Backup validation completed"
                    '''
                }
                
                // Archive validation report
                archiveArtifacts artifacts: 'backup-validation-report.json', allowEmptyArchive: true
            }
        }
        
        stage('Notification') {
            when {
                anyOf {
                    branch 'main'
                    buildingTag()
                }
            }
            steps {
                script {
                    echo 'Sending notifications...'
                    
                    // Send Slack notification
                    slackSend(
                        channel: '#database-alerts',
                        color: 'good',
                        message: "✅ Database backup completed successfully for ${env.JOB_NAME} (${env.BUILD_NUMBER})",
                        username: 'BackupBot'
                    )
                    
                    // Send email notification
                    emailext(
                        subject: "Database Backup - ${env.JOB_NAME} #${env.BUILD_NUMBER}",
                        body: """
                        Database backup completed successfully.
                        
                        Build: ${env.BUILD_NUMBER}
                        Branch: ${env.BRANCH_NAME}
                        Time: ${env.BUILD_TIMESTAMP}
                        
                        Files:
                        ${sh(returnStdout: true, script: 'find ${WORKSPACE_BACKUP} -name "*.sql" -exec ls -lh {} \\;')}
                        """,
                        to: "${env.CHANGE_AUTHOR_EMAIL}",
                        attachmentsPattern: 'backup-validation-report.json'
                    )
                }
            }
        }
        
        stage('Cleanup') {
            steps {
                script {
                    echo 'Cleaning up temporary files...'
                    sh '''
                        # Keep only latest 7 days of local backups
                        find ${WORKSPACE_BACKUP} -name "*.sql" -mtime +7 -delete
                        
                        # Clean up old S3 backups (30 days)
                        npm run cloud:cleanup -- 30
                        
                        echo "✅ Cleanup completed"
                    '''
                }
            }
        }
    }
    
    post {
        success {
            script {
                echo 'Backup pipeline completed successfully!'
                
                // Archive backup files
                archiveArtifacts artifacts: 'backups/*.sql*', allowEmptyArchive: true
                
                // Publish backup metrics
                publishBackupMetrics()
            }
        }
        
        failure {
            script {
                echo 'Backup pipeline failed!'
                
                // Send failure notification
                slackSend(
                    channel: '#database-alerts',
                    color: 'danger',
                    message: "❌ Database backup failed for ${env.JOB_NAME} (${env.BUILD_NUMBER})",
                    username: 'BackupBot'
                )
                
                // Email notification to admins
               emailext(
                    subject: "❌ Database Backup Failed - ${env.JOB_NAME} #${env.BUILD_NUMBER}",
                    body: """
                    Database backup pipeline failed.
                    
                    Build: ${env.BUILD_NUMBER}
                    Branch: ${env.BRANCH_NAME}
                    Time: ${env.BUILD_TIMESTAMP}
                    URL: ${env.BUILD_URL}
                    
                    Please check the build logs for more details.
                    """,
                    to: 'devops@company.com'
                )
            }
        }
        
        always {
            script {
                echo 'Cleaning up workspace...'
                sh 'rm -rf ${WORKSPACE_BACKUP}'
            }
        }
    }
}

// Helper function to publish backup metrics
def publishBackupMetrics() {
    sh '''
        # Collect backup metrics
        BACKUP_COUNT=$(find ${WORKSPACE}/backups -name "*.sql" 2>/dev/null | wc -l)
        TOTAL_SIZE=$(du -sb ${WORKSPACE}/backups 2>/dev/null | cut -f1)
        
        echo "Backup metrics:"
        echo "  Total backups: ${BACKUP_COUNT}"
        echo "  Total size: ${TOTAL_SIZE} bytes"
        
        # Publish to monitoring system (Prometheus format example)
        cat << EOF > metrics.prom
        # HELP backup_files_total Total number of backup files
        # TYPE backup_files_total gauge
        backup_files_total ${BACKUP_COUNT}
        
        # HELP backup_total_bytes Total size of backup files in bytes
        # TYPE backup_total_bytes gauge
        backup_total_bytes ${TOTAL_SIZE}
        
        # HELP backup_last_success_timestamp Unix timestamp of last successful backup
        # TYPE backup_last_success_timestamp gauge
        backup_last_success_timestamp $(date +%s)
        EOF
        
        # Upload metrics to monitoring system
        # curl -X POST http://prometheus-pushgateway:9091/metrics/job/backup-pipeline < metrics.prom
    '''
}

// Alternative: GitLab CI Configuration
// Create .gitlab-ci.yml in your repository root
"""

# .gitlab-ci.yml example for GitLab CI/CD

stages:
  - backup
  - validate
  - notify

variables:
  BACKUP_DIR: "/tmp/ci-backups"
  WORKSPACE_BACKUP: "$CI_PROJECT_DIR/backups"

before_script:
  - npm ci
  - mkdir -p $WORKSPACE_BACKUP

full_backup:
  stage: backup
  script:
    - BACKUP_DIR=$WORKSPACE_BACKUP $BACKUP_SCRIPTS/backup.ts full
    - ls -lh $WORKSPACE_BACKUP/*.sql
  artifacts:
    paths:
      - backups/*.sql*
    expire_in: 7 days
  only:
    - main
    - tags
    - schedules

incremental_backup:
  stage: backup
  script:
    - BACKUP_DIR=$WORKSPACE_BACKUP $BACKUP_SCRIPTS/backup.ts incremental
  only:
    - develop
    - schedules

validate_backup:
  stage: validate
  script:
    - BACKUP_DIR=$WORKSPACE_BACKUP $BACKUP_SCRIPTS/backup-validator.ts
  artifacts:
    reports:
      junit: backup-validation-report.xml
    paths:
      - backup-validation-report.*
  needs: ["full_backup"]

notify:
  stage: notify
  script:
    - echo "Sending notifications..."
    # Add your notification logic here
  needs: ["validate_backup"]
  when: always
"""
