/**
 * Jest Configuration for CloudPilot Production
 * Comprehensive setup with TypeScript support, coverage reporting, and mock configurations
 */

const { pathsToModuleNameMapper } = require('ts-jest');
const { compilerOptions } = require('./tsconfig.json');

module.exports = {
  // Test environment
  testEnvironment: 'node',
  
  // Transform configuration for TypeScript
  transform: {
    '^.+\\.tsx?$': ['ts-jest', {
      tsconfig: {
        target: 'ES2020',
        lib: ['ES2020'],
        module: 'ESNext',
        moduleResolution: 'bundler',
        allowJs: true,
        esModuleInterop: true,
        allowSyntheticDefaultImports: true,
        strict: true,
        skipLibCheck: true,
        forceConsistentCasingInFileNames: true,
        resolveJsonModule: true,
        isolatedModules: true,
        noEmit: false,
      }
    }]
  },
  
  // Module file extensions
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json', 'node'],
  
  // Test patterns
  testMatch: [
    '<rootDir>/tests/**/*.test.{ts,tsx}',
    '<rootDir>/tests/**/*.spec.{ts,tsx}',
    '<rootDir>/tests/**/*.integration.test.{ts,tsx}',
    '<rootDir>/__tests__/**/*.test.{ts,tsx}',
    '<rootDir>/__tests__/**/*.spec.{ts,tsx}',
    '<rootDir>/__tests__/**/*.integration.test.{ts,tsx}',
    '<rootDir>/src/**/*.test.{ts,tsx}',
    '<rootDir>/src/**/*.spec.{ts,tsx}',
    '<rootDir>/server/**/*.test.{ts,tsx}',
    '<rootDir>/server/**/*.spec.{ts,tsx}',
    '<rootDir>/shared/**/*.test.{ts,tsx}',
    '<rootDir>/shared/**/*.spec.{ts,tsx}'
  ],
  
  // Module name mapping (based on tsconfig.json paths)
  moduleNameMapper: pathsToModuleNameMapper(compilerOptions.paths, {
    prefix: '<rootDir>/'
  }),
  
  // Test timeout
  testTimeout: 30000,
  
  // Coverage configuration
  collectCoverage: true,
  collectCoverageFrom: [
    'src/**/*.{ts,tsx}',
    'server/**/*.{ts,tsx}',
    'shared/**/*.{ts,tsx}',
    '!src/**/*.d.ts',
    '!server/**/*.d.ts',
    '!shared/**/*.d.ts',
    '!src/**/index.ts',
    '!server/**/index.ts',
    '!shared/**/index.ts',
    '!src/**/*.types.ts',
    '!server/**/*.types.ts',
    '!shared/**/*.types.ts',
    '!**/node_modules/**',
    '!**/dist/**',
    '!**/coverage/**',
    '!**/*.config.{js,ts}',
    '!**/vite.config.ts',
    '!**/drizzle.config.ts'
  ],
  
  // Coverage thresholds
  coverageThreshold: {
    global: {
      branches: 80,
      functions: 80,
      lines: 80,
      statements: 80
    }
  },
  
  // Coverage report formats
  coverageReporters: [
    'text',
    'text-summary',
    'html',
    'lcov',
    'json'
  ],
  
  // Coverage output directory
  coverageDirectory: 'coverage',
  
  // Setup files
  setupFilesAfterEnv: [
    '<rootDir>/tests/setup/setup.ts'
  ],
  
  // Global test configuration
  globals: {
    'ts-jest': {
      useESM: true,
      tsconfig: {
        experimentalDecorators: true,
        emitDecoratorMetadata: true,
        strictPropertyInitialization: false
      }
    }
  },
  
  // Module paths
  roots: [
    '<rootDir>'
  ],
  
  // Ignore patterns
  testPathIgnorePatterns: [
    '/node_modules/',
    '/dist/',
    '/coverage/',
    '/build/'
  ],
  
  // Force exit after tests
  forceExit: true,
  
  // Clear mocks between tests
  clearMocks: true,
  
  // Reset mocks between tests
  resetMocks: true,
  
  // Restore mocks after each test
  restoreMocks: true,
  
  // Verbose output
  verbose: true,
  
  // Run tests in parallel
  maxWorkers: '50%',
  
  // Global variables
  globalTeardown: '<rootDir>/tests/setup/global-teardown.ts',
  
  // Test environment options
  testEnvironmentOptions: {
    url: 'http://localhost'
  }
};
