import { Pool, PoolClient } from 'pg';
import winston from 'winston';
import { Migration } from './migration-manager.js';

/**
 * MigrationHistory - Tracking migration history and status
 * 
 * Features:
 * - Complete migration execution history
 * - State management and recovery
 * - Performance tracking and analytics
 * - Audit trail with detailed metadata
 * - Rollback history and recovery points
 */
export class MigrationHistory {
  private readonly HISTORY_TABLE = 'migration_history';
  private readonly STATUS_TABLE = 'migration_status';
  private readonly BACKUP_TABLE = 'migration_backups';

  constructor(
    private pool: Pool,
    private logger: winston.Logger
  ) {
    this.initializeTables();
  }

  /**
   * Initialize migration history tables
   */
  private async initializeTables(): Promise<void> {
    try {
      await this.pool.query(`
        CREATE TABLE IF NOT EXISTS ${this.HISTORY_TABLE} (
          id SERIAL PRIMARY KEY,
          current_version VARCHAR(255) NOT NULL,
          applied_migrations JSONB NOT NULL DEFAULT '[]',
          last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          execution_duration INTEGER,
          rows_affected INTEGER DEFAULT 0,
          success BOOLEAN NOT NULL DEFAULT false,
          error_message TEXT,
          rollback_migrations JSONB DEFAULT '[]',
          metadata JSONB DEFAULT '{}',
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          UNIQUE(current_version)
        )
      `);

      await this.pool.query(`
        CREATE TABLE IF NOT EXISTS ${this.STATUS_TABLE} (
          version VARCHAR(255) PRIMARY KEY,
          status VARCHAR(50) NOT NULL CHECK (status IN ('pending', 'applying', 'applied', 'failed', 'rolling_back', 'rolled_back')),
          applied_at TIMESTAMP WITH TIME ZONE,
          execution_duration INTEGER,
          rows_affected INTEGER DEFAULT 0,
          error_message TEXT,
          checksum VARCHAR(255),
          dependencies JSONB DEFAULT '[]',
          rollback_script TEXT,
          metadata JSONB DEFAULT '{}',
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )
      `);

      await this.pool.query(`
        CREATE TABLE IF NOT EXISTS ${this.BACKUP_TABLE} (
          id VARCHAR(255) PRIMARY KEY,
          migration_version VARCHAR(255) NOT NULL,
          backup_type VARCHAR(50) NOT NULL CHECK (backup_type IN ('pre_migration', 'pre_rollback', 'manual')),
          created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          size INTEGER,
          checksum VARCHAR(255),
          storage_location TEXT,
          metadata JSONB DEFAULT '{}'
        )
      `);

      await this.pool.query(`
        CREATE INDEX IF NOT EXISTS idx_migration_history_applied_at 
        ON ${this.HISTORY_TABLE} (applied_at DESC)
      `);

      await this.pool.query(`
        CREATE INDEX IF NOT EXISTS idx_migration_status_status 
        ON ${this.STATUS_TABLE} (status)
      `);

      await this.pool.query(`
        CREATE INDEX IF NOT EXISTS idx_migration_status_version 
        ON ${this.STATUS_TABLE} (version)
      `);

      this.logger.info('Migration history tables initialized successfully');

    } catch (error) {
      this.logger.error('Failed to initialize migration history tables', { error });
      throw error;
    }
  }

  /**
   * Record migration batch execution
   */
  async recordMigrationBatch(
    migrationVersions: string[],
    options?: {
      executionDuration?: number;
      rowsAffected?: number;
      success?: boolean;
      errorMessage?: string;
      rollbackMigrations?: string[];
      metadata?: any;
    }
  ): Promise<void> {
    const {
      executionDuration = 0,
      rowsAffected = 0,
      success = true,
      errorMessage,
      rollbackMigrations = [],
      metadata = {}
    } = options || {};

    const client = await this.pool.connect();
    
    try {
      await client.query('BEGIN');

      // Update individual migration statuses
      for (const version of migrationVersions) {
        await this.updateMigrationStatus(client, version, {
          status: success ? 'applied' : 'failed',
          appliedAt: new Date(),
          executionDuration,
          rowsAffected,
          errorMessage: success ? null : errorMessage
        });
      }

      // Record batch history
      const currentState = await this.getCurrentState();
      const newCurrentVersion = migrationVersions[migrationVersions.length - 1];
      const appliedMigrations = [
        ...currentState.appliedMigrations,
        ...migrationVersions
      ];

      await client.query(`
        INSERT INTO ${this.HISTORY_TABLE} (
          current_version,
          applied_migrations,
          last_updated,
          execution_duration,
          rows_affected,
          success,
          error_message,
          rollback_migrations,
          metadata
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        ON CONFLICT (current_version) 
        DO UPDATE SET
          applied_migrations = EXCLUDED.applied_migrations,
          last_updated = EXCLUDED.last_updated,
          execution_duration = EXCLUDED.execution_duration,
          rows_affected = EXCLUDED.rows_affected,
          success = EXCLUDED.success,
          error_message = EXCLUDED.error_message,
          rollback_migrations = EXCLUDED.rollback_migrations,
          metadata = EXCLUDED.metadata
      `, [
        newCurrentVersion,
        JSON.stringify(appliedMigrations),
        new Date(),
        executionDuration,
        rowsAffected,
        success,
        errorMessage,
        JSON.stringify(rollbackMigrations),
        JSON.stringify(metadata)
      ]);

      await client.query('COMMIT');
      
      this.logger.info('Migration batch recorded successfully', {
        versions: migrationVersions,
        success,
        executionDuration
      });

    } catch (error) {
      await client.query('ROLLBACK');
      this.logger.error('Failed to record migration batch', { error });
      throw error;
    } finally {
      client.release();
    }
  }

  /**
   * Record individual migration start
   */
  async recordMigrationStart(
    version: string,
    description: string,
    metadata?: any
  ): Promise<void> {
    await this.updateMigrationStatus(null, version, {
      status: 'applying',
      metadata: {
        ...metadata,
        description,
        startedAt: new Date()
      }
    });
  }

  /**
   * Get current migration state
   */
  async getCurrentState(): Promise<{
    currentVersion: string;
    appliedMigrations: string[];
    lastUpdated: Date;
    executionDuration?: number;
    rowsAffected?: number;
    success?: boolean;
    errorMessage?: string;
    rollbackMigrations?: string[];
    metadata?: any;
  }> {
    try {
      const result = await this.pool.query(`
        SELECT * FROM ${this.HISTORY_TABLE}
        ORDER BY created_at DESC
        LIMIT 1
      `);

      if (result.rows.length === 0) {
        return {
          currentVersion: '0',
          appliedMigrations: [],
          lastUpdated: new Date()
        };
      }

      const row = result.rows[0];
      return {
        currentVersion: row.current_version,
        appliedMigrations: row.applied_migrations || [],
        lastUpdated: row.last_updated,
        executionDuration: row.execution_duration,
        rowsAffected: row.rows_affected,
        success: row.success,
        errorMessage: row.error_message,
        rollbackMigrations: row.rollback_migrations || [],
        metadata: row.metadata || {}
      };

    } catch (error) {
      this.logger.error('Failed to get current migration state', { error });
      return {
        currentVersion: '0',
        appliedMigrations: [],
        lastUpdated: new Date()
      };
    }
  }

  /**
   * Get migration history with pagination
   */
  async getMigrationHistory(
    limit: number = 50,
    offset: number = 0,
    filters?: {
      status?: string;
      version?: string;
      dateFrom?: Date;
      dateTo?: Date;
      success?: boolean;
    }
  ): Promise<{
    migrations: Array<{
      version: string;
      status: string;
      appliedAt?: Date;
      executionDuration?: number;
      rowsAffected?: number;
      errorMessage?: string;
      metadata?: any;
      description?: string;
    }>;
    total: number;
    hasMore: boolean;
  }> {
    try {
      let query = `
        SELECT * FROM ${this.STATUS_TABLE}
        WHERE 1=1
      `;
      const params: any[] = [];
      let paramCount = 0;

      if (filters?.status) {
        paramCount++;
        query += ` AND status = $${paramCount}`;
        params.push(filters.status);
      }

      if (filters?.version) {
        paramCount++;
        query += ` AND version = $${paramCount}`;
        params.push(filters.version);
      }

      if (filters?.success !== undefined) {
        paramCount++;
        query += ` AND status = $${paramCount}`;
        params.push(filters.success ? 'applied' : 'failed');
      }

      if (filters?.dateFrom) {
        paramCount++;
        query += ` AND applied_at >= $${paramCount}`;
        params.push(filters.dateFrom);
      }

      if (filters?.dateTo) {
        paramCount++;
        query += ` AND applied_at <= $${paramCount}`;
        params.push(filters.dateTo);
      }

      query += ` ORDER BY applied_at DESC NULLS LAST, version ASC LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
      params.push(limit + 1, offset); // Fetch one extra to check hasMore

      const result = await this.pool.query(query, params);
      const migrations = result.rows.slice(0, limit).map(row => ({
        version: row.version,
        status: row.status,
        appliedAt: row.applied_at,
        executionDuration: row.execution_duration,
        rowsAffected: row.rows_affected,
        errorMessage: row.error_message,
        metadata: row.metadata || {},
        description: row.metadata?.description
      }));

      // Get total count
      const countQuery = `
        SELECT COUNT(*) as total FROM ${this.STATUS_TABLE}
        WHERE ${filters?.status ? 'status = $1' : '1=1'}
      `;
      const countParams = filters?.status ? [filters.status] : [];
      const countResult = await this.pool.query(countQuery, countParams);
      const total = parseInt(countResult.rows[0]?.total || '0');

      return {
        migrations,
        total,
        hasMore: result.rows.length > limit
      };

    } catch (error) {
      this.logger.error('Failed to get migration history', { error });
      return {
        migrations: [],
        total: 0,
        hasMore: false
      };
    }
  }

  /**
   * Get migrations to rollback for a target version
   */
  async getMigrationsToRollback(targetVersion: string): Promise<Migration[]> {
    try {
      const currentState = await this.getCurrentState();
      const appliedMigrations = currentState.appliedMigrations;
      
      // Find migrations that need to be rolled back
      const migrationsToRollback = appliedMigrations.filter(version => 
        this.compareVersions(version, targetVersion) > 0
      );

      // Load migration details
      const migrations: Migration[] = [];
      for (const version of migrationsToRollback) {
        const migration = await this.getMigrationDetails(version);
        if (migration) {
          migrations.push(migration);
        }
      }

      return migrations.sort((a, b) => this.compareVersions(b.version, a.version));

    } catch (error) {
      this.logger.error('Failed to get migrations to rollback', { error });
      return [];
    }
  }

  /**
   * Get detailed migration information
   */
  async getMigrationDetails(version: string): Promise<Migration | null> {
    try {
      const result = await this.pool.query(
        `SELECT * FROM ${this.STATUS_TABLE} WHERE version = $1`,
        [version]
      );

      if (result.rows.length === 0) {
        return null;
      }

      const row = result.rows[0];
      return {
        version: row.version,
        description: row.metadata?.description || '',
        dependencies: row.dependencies || [],
        estimatedDuration: 1000, // Default estimated duration
        upScript: '', // Would be loaded from migration files
        downScript: row.rollback_script || '',
        checksum: row.checksum || ''
      };

    } catch (error) {
      this.logger.error('Failed to get migration details', { error });
      return null;
    }
  }

  /**
   * Force update migration state (emergency recovery)
   */
  async forceUpdateState(client: PoolClient, state: MigrationState): Promise<void> {
    try {
      await client.query(`
        INSERT INTO ${this.HISTORY_TABLE} (
          current_version,
          applied_migrations,
          last_updated,
          success
        ) VALUES ($1, $2, $3, true)
        ON CONFLICT (current_version)
        DO UPDATE SET
          applied_migrations = EXCLUDED.applied_migrations,
          last_updated = EXCLUDED.last_updated,
          success = EXCLUDED.success
      `, [
        state.currentVersion,
        JSON.stringify(state.appliedMigrations),
        state.lastUpdated
      ]);

      // Update individual status records
      for (const version of state.appliedMigrations) {
        await this.updateMigrationStatus(client, version, {
          status: 'applied',
          appliedAt: state.lastUpdated
        });
      }

      this.logger.warn('Migration state force updated', state);

    } catch (error) {
      this.logger.error('Failed to force update migration state', { error });
      throw error;
    }
  }

  /**
   * Get migration statistics and analytics
   */
  async getMigrationStatistics(
    dateFrom?: Date,
    dateTo?: Date
  ): Promise<{
    totalMigrations: number;
    successfulMigrations: number;
    failedMigrations: number;
    totalExecutionTime: number;
    averageExecutionTime: number;
    mostFrequentErrors: Array<{ error: string; count: number }>;
    migrationsByDate: Array<{ date: string; count: number; successRate: number }>;
    performanceMetrics: {
      slowestMigration?: { version: string; duration: number };
      fastestMigration?: { version: string; duration: number };
      totalRowsAffected: number;
    };
  }> {
    try {
      let query = `
        SELECT 
          COUNT(*) as total_migrations,
          COUNT(CASE WHEN status = 'applied' THEN 1 END) as successful_migrations,
          COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed_migrations,
          AVG(execution_duration) as avg_execution_time,
          SUM(execution_duration) as total_execution_time,
          SUM(rows_affected) as total_rows_affected,
          MAX(execution_duration) as max_execution_time,
          MIN(execution_duration) as min_execution_time
        FROM ${this.STATUS_TABLE}
        WHERE 1=1
      `;
      const params: any[] = [];
      let paramCount = 0;

      if (dateFrom) {
        paramCount++;
        query += ` AND applied_at >= $${paramCount}`;
        params.push(dateFrom);
      }

      if (dateTo) {
        paramCount++;
        query += ` AND applied_at <= $${paramCount}`;
        params.push(dateTo);
      }

      const statsResult = await this.pool.query(query, params);
      const stats = statsResult.rows[0];

      // Get most frequent errors
      const errorsResult = await this.pool.query(`
        SELECT error_message, COUNT(*) as count
        FROM ${this.STATUS_TABLE}
        WHERE error_message IS NOT NULL
        ${dateFrom ? 'AND applied_at >= $1' : ''}
        ${dateTo ? `${dateFrom ? 'AND' : 'AND'} applied_at <= $${dateFrom ? '2' : '1'}` : ''}
        GROUP BY error_message
        ORDER BY count DESC
        LIMIT 5
      `, params);

      const mostFrequentErrors = errorsResult.rows.map(row => ({
        error: row.error_message,
        count: parseInt(row.count)
      }));

      // Get migrations by date
      const dateQuery = `
        SELECT 
          DATE(applied_at) as date,
          COUNT(*) as count,
          COUNT(CASE WHEN status = 'applied' THEN 1 END) * 100.0 / COUNT(*) as success_rate
        FROM ${this.STATUS_TABLE}
        WHERE applied_at IS NOT NULL
        ${dateFrom ? 'AND applied_at >= $1' : ''}
        ${dateTo ? `${dateFrom ? 'AND' : 'AND'} applied_at <= $${dateFrom ? '2' : '1'}` : ''}
        GROUP BY DATE(applied_at)
        ORDER BY date DESC
      `;
      const dateResult = await this.pool.query(dateQuery, params);

      const migrationsByDate = dateResult.rows.map(row => ({
        date: row.date,
        count: parseInt(row.count),
        successRate: parseFloat(row.success_rate)
      }));

      // Performance metrics
      const perfResult = await this.pool.query(`
        SELECT version, execution_duration
        FROM ${this.STATUS_TABLE}
        WHERE execution_duration IS NOT NULL
        ORDER BY execution_duration DESC
        LIMIT 1
      `);
      const slowestMigration = perfResult.rows[0] ? {
        version: perfResult.rows[0].version,
        duration: perfResult.rows[0].execution_duration
      } : undefined;

      const fastestResult = await this.pool.query(`
        SELECT version, execution_duration
        FROM ${this.STATUS_TABLE}
        WHERE execution_duration IS NOT NULL
        ORDER BY execution_duration ASC
        LIMIT 1
      `);
      const fastestMigration = fastestResult.rows[0] ? {
        version: fastestResult.rows[0].version,
        duration: fastestResult.rows[0].execution_duration
      } : undefined;

      return {
        totalMigrations: parseInt(stats.total_migrations || '0'),
        successfulMigrations: parseInt(stats.successful_migrations || '0'),
        failedMigrations: parseInt(stats.failed_migrations || '0'),
        totalExecutionTime: parseInt(stats.total_execution_time || '0'),
        averageExecutionTime: Math.round(parseFloat(stats.avg_execution_time || '0')),
        mostFrequentErrors,
        migrationsByDate,
        performanceMetrics: {
          slowestMigration,
          fastestMigration,
          totalRowsAffected: parseInt(stats.total_rows_affected || '0')
        }
      };

    } catch (error) {
      this.logger.error('Failed to get migration statistics', { error });
      return {
        totalMigrations: 0,
        successfulMigrations: 0,
        failedMigrations: 0,
        totalExecutionTime: 0,
        averageExecutionTime: 0,
        mostFrequentErrors: [],
        migrationsByDate: [],
        performanceMetrics: {
          totalRowsAffected: 0
        }
      };
    }
  }

  /**
   * Clean up old migration history
   */
  async cleanupOldHistory(olderThanDays: number = 90): Promise<number> {
    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - olderThanDays);

      const result = await this.pool.query(`
        DELETE FROM ${this.HISTORY_TABLE}
        WHERE created_at < $1
      `, [cutoffDate]);

      this.logger.info('Cleaned up old migration history', {
        deletedRows: result.rowCount,
        cutoffDate
      });

      return result.rowCount || 0;

    } catch (error) {
      this.logger.error('Failed to cleanup old migration history', { error });
      return 0;
    }
  }

  private async updateMigrationStatus(
    client: PoolClient | null,
    version: string,
    updates: {
      status?: string;
      appliedAt?: Date;
      executionDuration?: number;
      rowsAffected?: number;
      errorMessage?: string | null;
      checksum?: string;
      dependencies?: string[];
      rollbackScript?: string;
      metadata?: any;
    }
  ): Promise<void> {
    const usedClient = client || await this.pool.connect();
    
    try {
      const setClause: string[] = [];
      const params: any[] = [];
      let paramCount = 0;

      if (updates.status !== undefined) {
        paramCount++;
        setClause.push(`status = $${paramCount}`);
        params.push(updates.status);
      }

      if (updates.appliedAt !== undefined) {
        paramCount++;
        setClause.push(`applied_at = $${paramCount}`);
        params.push(updates.appliedAt);
      }

      if (updates.executionDuration !== undefined) {
        paramCount++;
        setClause.push(`execution_duration = $${paramCount}`);
        params.push(updates.executionDuration);
      }

      if (updates.rowsAffected !== undefined) {
        paramCount++;
        setClause.push(`rows_affected = $${paramCount}`);
        params.push(updates.rowsAffected);
      }

      if (updates.errorMessage !== undefined) {
        paramCount++;
        setClause.push(`error_message = $${paramCount}`);
        params.push(updates.errorMessage);
      }

      if (updates.metadata !== undefined) {
        paramCount++;
        setClause.push(`metadata = $${paramCount}`);
        params.push(JSON.stringify(updates.metadata));
      }

      if (updates.checksum !== undefined) {
        paramCount++;
        setClause.push(`checksum = $${paramCount}`);
        params.push(updates.checksum);
      }

      if (updates.dependencies !== undefined) {
        paramCount++;
        setClause.push(`dependencies = $${paramCount}`);
        params.push(JSON.stringify(updates.dependencies));
      }

      if (updates.rollbackScript !== undefined) {
        paramCount++;
        setClause.push(`rollback_script = $${paramCount}`);
        params.push(updates.rollbackScript);
      }

      // Always update updated_at
      paramCount++;
      setClause.push(`updated_at = $${paramCount}`);
      params.push(new Date());

      // Add version as the last parameter
      paramCount++;
      setClause.push(`version = $${paramCount}`);
      params.push(version);

      const query = `
        INSERT INTO ${this.STATUS_TABLE} (
          version, ${setClause.slice(0, -1).join(', ')}
        ) VALUES (
          $${paramCount}, ${setClause.slice(0, -1).map((_, i) => `$${i + 1}`).join(', ')}
        )
        ON CONFLICT (version)
        DO UPDATE SET
          ${setClause.map((clause, i) => {
            const paramIndex = clause.includes('version') ? paramCount : i + 1;
            return clause.includes('=') ? clause.split('=')[0] + ` = $${paramIndex}` : clause;
          }).join(', ')}
      `;

      await usedClient.query(query, params);

    } finally {
      if (!client) {
        usedClient.release();
      }
    }
  }

  private compareVersions(a: string, b: string): number {
    return parseInt(a) - parseInt(b);
  }
}

// Types
interface MigrationState {
  currentVersion: string;
  appliedMigrations: string[];
  lastUpdated: Date;
}