import { Pool, PoolClient } from 'pg';
import winston from 'winston';
import { Migration } from './migration-manager.js';

/**
 * MigrationValidator - Comprehensive validation and testing of database migrations
 * 
 * Features:
 * - Pre-execution validation of migration scripts
 * - Syntax and semantic validation
 * - Data integrity checks
 * - Rollback testing
 * - Dependency validation
 * - Performance impact assessment
 */
export class MigrationValidator {
  constructor(
    private pool: Pool,
    private logger: winston.Logger
  ) {}

  /**
   * Comprehensive validation of a migration before execution
   */
  async validateMigration(migration: Migration): Promise<{
    valid: boolean;
    errors: string[];
    warnings: string[];
    recommendations: string[];
    checksPerformed: string[];
  }> {
    this.logger.debug(`Validating migration: ${migration.version}`);

    const errors: string[] = [];
    const warnings: string[] = [];
    const recommendations: string[] = [];
    const checksPerformed: string[] = [];

    try {
      // 1. Basic structure validation
      checksPerformed.push('basic_structure');
      const basicValidation = this.validateBasicStructure(migration);
      errors.push(...basicValidation.errors);
      warnings.push(...basicValidation.warnings);
      recommendations.push(...basicValidation.recommendations);

      // 2. SQL syntax validation
      checksPerformed.push('sql_syntax');
      const syntaxValidation = await this.validateSQLSyntax(migration);
      errors.push(...syntaxValidation.errors);
      warnings.push(...syntaxValidation.warnings);
      recommendations.push(...syntaxValidation.recommendations);

      // 3. Schema integrity validation
      checksPerformed.push('schema_integrity');
      const schemaValidation = await this.validateSchemaIntegrity(migration);
      errors.push(...schemaValidation.errors);
      warnings.push(...schemaValidation.warnings);
      recommendations.push(...schemaValidation.recommendations);

      // 4. Data integrity validation
      checksPerformed.push('data_integrity');
      const dataValidation = await this.validateDataIntegrity(migration);
      errors.push(...dataValidation.errors);
      warnings.push(...dataValidation.warnings);
      recommendations.push(...dataValidation.recommendations);

      // 5. Dependency validation
      checksPerformed.push('dependencies');
      const dependencyValidation = await this.validateDependencies(migration);
      errors.push(...dependencyValidation.errors);
      warnings.push(...dependencyValidation.warnings);
      recommendations.push(...dependencyValidation.recommendations);

      // 6. Performance impact assessment
      checksPerformed.push('performance');
      const performanceValidation = await this.validatePerformanceImpact(migration);
      errors.push(...performanceValidation.errors);
      warnings.push(...performanceValidation.warnings);
      recommendations.push(...performanceValidation.recommendations);

      // 7. Security validation
      checksPerformed.push('security');
      const securityValidation = await this.validateSecurityImpact(migration);
      errors.push(...securityValidation.errors);
      warnings.push(...securityValidation.warnings);
      recommendations.push(...securityValidation.recommendations);

      const valid = errors.length === 0;

      this.logger.debug(`Migration validation completed: ${migration.version}`, {
        valid,
        errorCount: errors.length,
        warningCount: warnings.length,
        recommendationCount: recommendations.length
      });

      return {
        valid,
        errors,
        warnings,
        recommendations,
        checksPerformed
      };

    } catch (error) {
      this.logger.error(`Migration validation failed: ${migration.version}`, { error });
      return {
        valid: false,
        errors: [`Validation process failed: ${error}`],
        warnings: [],
        recommendations: ['Review migration manually'],
        checksPerformed
      };
    }
  }

  /**
   * Validate rollback script
   */
  async validateRollback(migration: Migration): Promise<{
    valid: boolean;
    errors: string[];
    warnings: string[];
    recommendations: string[];
    rollbackAvailable: boolean;
  }> {
    const errors: string[] = [];
    const warnings: string[] = [];
    const recommendations: string[] = [];

    // Check if rollback script exists
    const rollbackAvailable = !!(migration.downScript && migration.downScript.trim().length > 0);

    if (!rollbackAvailable) {
      errors.push('No rollback script available');
      recommendations.push('Create a rollback script before proceeding');
      return {
        valid: false,
        errors,
        warnings,
        recommendations,
        rollbackAvailable: false
      };
    }

    try {
      // Validate rollback syntax
      const rollbackSyntaxValidation = await this.validateSQLSyntax({
        ...migration,
        upScript: migration.downScript
      });
      errors.push(...rollbackSyntaxValidation.errors);
      warnings.push(...rollbackSyntaxValidation.warnings);
      recommendations.push(...rollbackSyntaxValidation.recommendations);

      // Check rollback safety
      const rollbackSafety = await this.validateRollbackSafety(migration);
      errors.push(...rollbackSafety.errors);
      warnings.push(...rollbackSafety.warnings);
      recommendations.push(...rollbackSafety.recommendations);

      // Validate rollback doesn't break referential integrity
      const referentialValidation = await this.validateReferentialIntegrity(migration, 'rollback');
      errors.push(...referentialValidation.errors);
      warnings.push(...referentialValidation.warnings);
      recommendations.push(...referentialValidation.recommendations);

      return {
        valid: errors.length === 0,
        errors,
        warnings,
        recommendations,
        rollbackAvailable: true
      };

    } catch (error) {
      this.logger.error(`Rollback validation failed: ${migration.version}`, { error });
      return {
        valid: false,
        errors: [`Rollback validation process failed: ${error}`],
        warnings: [],
        recommendations: ['Review rollback script manually'],
        rollbackAvailable: true
      };
    }
  }

  /**
   * Test migration in a safe environment
   */
  async testMigration(
    migration: Migration,
    options?: {
      createTestSchema?: boolean;
      simulateData?: boolean;
      testRollback?: boolean;
    }
  ): Promise<{
    success: boolean;
    testResults: Array<{
      test: string;
      passed: boolean;
      duration: number;
      error?: string;
      details?: any;
    }>;
    totalDuration: number;
    warnings: string[];
  }> {
    const {
      createTestSchema = true,
      simulateData = false,
      testRollback = true
    } = options || {};

    const startTime = Date.now();
    const testResults: Array<{
      test: string;
      passed: boolean;
      duration: number;
      error?: string;
      details?: any;
    }> = [];
    const warnings: string[] = [];

    const client = await this.pool.connect();

    try {
      this.logger.info(`Testing migration: ${migration.version}`);

      if (createTestSchema) {
        await client.query('BEGIN');
        await client.query('SAVEPOINT migration_test');
      }

      // Test 1: Schema Creation
      try {
        const testStart = Date.now();
        await this.testSchemaCreation(client, migration);
        testResults.push({
          test: 'schema_creation',
          passed: true,
          duration: Date.now() - testStart
        });
      } catch (error) {
        testResults.push({
          test: 'schema_creation',
          passed: false,
          duration: 0,
          error: error as Error
        });
      }

      // Test 2: Data Integrity
      if (simulateData) {
        try {
          const testStart = Date.now();
          const result = await this.testDataIntegrity(client, migration);
          testResults.push({
            test: 'data_integrity',
            passed: result.success,
            duration: Date.now() - testStart,
            details: result.details
          });
          warnings.push(...result.warnings);
        } catch (error) {
          testResults.push({
            test: 'data_integrity',
            passed: false,
            duration: 0,
            error: error as Error
          });
        }
      }

      // Test 3: Index Performance
      try {
        const testStart = Date.now();
        const result = await this.testIndexPerformance(client, migration);
        testResults.push({
          test: 'index_performance',
          passed: result.success,
          duration: Date.now() - testStart,
          details: result.details
        });
      } catch (error) {
        testResults.push({
          test: 'index_performance',
          passed: false,
          duration: 0,
          error: error as Error
        });
      }

      // Test 4: Rollback Testing
      if (testRollback && migration.downScript) {
        try {
          const testStart = Date.now();
          const result = await this.testRollback(client, migration);
          testResults.push({
            test: 'rollback',
            passed: result.success,
            duration: Date.now() - testStart,
            details: result.details
          });
        } catch (error) {
          testResults.push({
            test: 'rollback',
            passed: false,
            duration: 0,
            error: error as Error
          });
        }
      }

      if (createTestSchema) {
        await client.query('ROLLBACK TO SAVEPOINT migration_test');
        await client.query('COMMIT');
      }

      const totalDuration = Date.now() - startTime;
      const success = testResults.every(result => result.passed);

      this.logger.info(`Migration testing completed: ${migration.version}`, {
        success,
        totalDuration: `${totalDuration}ms`,
        passedTests: testResults.filter(r => r.passed).length,
        failedTests: testResults.filter(r => !r.passed).length
      });

      return {
        success,
        testResults,
        totalDuration,
        warnings
      };

    } catch (error) {
      if (createTestSchema) {
        await client.query('ROLLBACK');
      }
      const totalDuration = Date.now() - startTime;

      this.logger.error(`Migration testing failed: ${migration.version}`, {
        totalDuration: `${totalDuration}ms`,
        error
      });

      return {
        success: false,
        testResults,
        totalDuration,
        warnings: ['Test execution failed']
      };
    } finally {
      client.release();
    }
  }

  private validateBasicStructure(migration: Migration): {
    errors: string[];
    warnings: string[];
    recommendations: string[];
  } {
    const errors: string[] = [];
    const warnings: string[] = [];
    const recommendations: string[] = [];

    // Required fields
    if (!migration.version || migration.version.trim().length === 0) {
      errors.push('Migration version is required');
    }

    if (!migration.description || migration.description.trim().length === 0) {
      errors.push('Migration description is required');
    }

    if (!migration.upScript || migration.upScript.trim().length === 0) {
      errors.push('Migration up script is required');
    }

    // Version format validation
    if (migration.version && !/^\d+$/.test(migration.version)) {
      errors.push('Migration version must be numeric');
    }

    // Description validation
    if (migration.description && migration.description.length > 255) {
      warnings.push('Description is quite long, consider shortening');
    }

    // Dependencies validation
    if (migration.dependencies && migration.dependencies.length > 0) {
      for (const dep of migration.dependencies) {
        if (!/^\d+$/.test(dep)) {
          errors.push(`Invalid dependency version format: ${dep}`);
        }
      }
    }

    // Duration estimation
    if (!migration.estimatedDuration || migration.estimatedDuration < 0) {
      recommendations.push('Add estimated duration for better progress tracking');
    }

    return { errors, warnings, recommendations };
  }

  private async validateSQLSyntax(migration: Migration): Promise<{
    errors: string[];
    warnings: string[];
    recommendations: string[];
  }> {
    const errors: string[] = [];
    const warnings: string[] = [];
    const recommendations: string[] = [];

    try {
      // Split SQL into statements
      const statements = this.splitSQLStatements(migration.upScript);

      for (const statement of statements) {
        const trimmed = statement.trim();
        if (!trimmed || trimmed.startsWith('--') || trimmed.startsWith('/*')) {
          continue;
        }

        // Validate SQL syntax by attempting to parse it
        const syntaxError = await this.validateStatementSyntax(trimmed);
        if (syntaxError) {
          errors.push(`SQL syntax error: ${syntaxError}`);
        }

        // Check for potentially problematic patterns
        if (this.containsProblematicPatterns(trimmed)) {
          warnings.push(`Potentially problematic SQL detected: ${trimmed.substring(0, 50)}...`);
        }
      }

    } catch (error) {
      errors.push(`SQL syntax validation failed: ${error}`);
    }

    return { errors, warnings, recommendations };
  }

  private async validateSchemaIntegrity(migration: Migration): Promise<{
    errors: string[];
    warnings: string[];
    recommendations: string[];
  }> {
    const errors: string[] = [];
    const warnings: string[] = [];
    const recommendations: string[] = [];

    try {
      const statements = this.splitSQLStatements(migration.upScript);

      for (const statement of statements) {
        const trimmed = statement.trim().toUpperCase();

        // Check CREATE TABLE statements
        if (trimmed.startsWith('CREATE TABLE')) {
          const tableName = this.extractTableName(statement);
          if (tableName) {
            // Check if table already exists
            const exists = await this.tableExists(tableName);
            if (exists) {
              errors.push(`Table ${tableName} already exists`);
            }
          }
        }

        // Check ALTER TABLE statements
        if (trimmed.startsWith('ALTER TABLE')) {
          const tableName = this.extractTableName(statement);
          if (tableName) {
            const exists = await this.tableExists(tableName);
            if (!exists) {
              errors.push(`Table ${tableName} does not exist for ALTER operation`);
            }
          }
        }
      }

    } catch (error) {
      errors.push(`Schema integrity validation failed: ${error}`);
    }

    return { errors, warnings, recommendations };
  }

  private async validateDataIntegrity(migration: Migration): Promise<{
    errors: string[];
    warnings: string[];
    recommendations: string[];
  }> {
    const errors: string[] = [];
    const warnings: string[] = [];
    const recommendations: string[] = [];

    try {
      const statements = this.splitSQLStatements(migration.upScript);

      for (const statement of statements) {
        const trimmed = statement.trim().toUpperCase();

        // Check for INSERT statements with missing columns
        if (trimmed.startsWith('INSERT INTO')) {
          const validation = await this.validateInsertStatement(statement);
          if (!validation.valid) {
            errors.push(...validation.errors);
          }
          warnings.push(...validation.warnings);
        }

        // Check for UPDATE statements without WHERE clause
        if (trimmed.startsWith('UPDATE')) {
          if (!/UPDATE\s+\w+\s+SET\s+[\s\S]+WHERE\s+/i.test(statement)) {
            warnings.push('UPDATE statement without WHERE clause detected');
          }
        }

        // Check for DELETE statements without WHERE clause
        if (trimmed.startsWith('DELETE FROM')) {
          if (!/DELETE\s+FROM\s+\w+\s+WHERE\s+/i.test(statement)) {
            warnings.push('DELETE statement without WHERE clause detected - this will delete all rows!');
            recommendations.push('Add WHERE clause to DELETE statements for safety');
          }
        }
      }

    } catch (error) {
      errors.push(`Data integrity validation failed: ${error}`);
    }

    return { errors, warnings, recommendations };
  }

  private async validateDependencies(migration: Migration): Promise<{
    errors: string[];
    warnings: string[];
    recommendations: string[];
  }> {
    const errors: string[] = [];
    const warnings: string[] = [];
    const recommendations: string[] = [];

    try {
      // Check if dependencies exist and are applied
      for (const depVersion of migration.dependencies) {
        const depExists = await this.migrationExists(depVersion);
        if (!depExists) {
          errors.push(`Dependency migration ${depVersion} not found`);
        } else {
          const isApplied = await this.isMigrationApplied(depVersion);
          if (!isApplied) {
            errors.push(`Dependency migration ${depVersion} is not applied`);
          }
        }
      }

      // Check for circular dependencies
      const hasCircularDependency = await this.checkCircularDependencies(migration);
      if (hasCircularDependency) {
        errors.push('Circular dependency detected');
      }

    } catch (error) {
      errors.push(`Dependency validation failed: ${error}`);
    }

    return { errors, warnings, recommendations };
  }

  private async validatePerformanceImpact(migration: Migration): Promise<{
    errors: string[];
    warnings: string[];
    recommendations: string[];
  }> {
    const errors: string[] = [];
    const warnings: string[] = [];
    const recommendations: string[] = [];

    try {
      const statements = this.splitSQLStatements(migration.upScript);

      for (const statement of statements) {
        const trimmed = statement.trim().toUpperCase();

        // Check for potentially slow operations
        if (trimmed.includes('CREATE INDEX') && !trimmed.includes('CONCURRENTLY')) {
          warnings.push('CREATE INDEX without CONCURRENTLY may cause table locking');
          recommendations.push('Consider using CONCURRENTLY for production indexes');
        }

        if (trimmed.includes('DROP INDEX') && !trimmed.includes('CONCURRENTLY')) {
          warnings.push('DROP INDEX without CONCURRENTLY may cause table locking');
          recommendations.push('Consider using CONCURRENTLY for production index drops');
        }

        if (trimmed.includes('ALTER TABLE') && !trimmed.includes('LOCK')) {
          const alterTableOps = ['ADD COLUMN', 'DROP COLUMN', 'ALTER COLUMN'];
          const hasBlockingOp = alterTableOps.some(op => trimmed.includes(op));
          if (hasBlockingOp) {
            warnings.push('ALTER TABLE operation may cause table locking');
            recommendations.push('Consider scheduling during maintenance window');
          }
        }

        // Check for long-running operations
        if (trimmed.includes('CREATE TABLE') || trimmed.includes('CREATE INDEX')) {
          const estimatedTime = this.estimateOperationTime(statement);
          if (estimatedTime > 300000) { // 5 minutes
            warnings.push(`Potentially long-running operation detected (${estimatedTime}s)`);
            recommendations.push('Consider breaking into smaller operations or scheduling during low traffic');
          }
        }
      }

    } catch (error) {
      errors.push(`Performance validation failed: ${error}`);
    }

    return { errors, warnings, recommendations };
  }

  private async validateSecurityImpact(migration: Migration): Promise<{
    errors: string[];
    warnings: string[];
    recommendations: string[];
  }> {
    const errors: string[] = [];
    const warnings: string[] = [];
    const recommendations: string[] = [];

    try {
      const statements = this.splitSQLStatements(migration.upScript);

      const securityPatterns = [
        { pattern: /\bGRANT\s+ALL/i, message: 'GRANT ALL permissions detected' },
        { pattern: /\bREVOKE/i, message: 'REVOKE permissions detected' },
        { pattern: /\bDROP\s+ROLE/i, message: 'DROP ROLE detected' },
        { pattern: /\bALTER\s+ROLE/i, message: 'ALTER ROLE detected' }
      ];

      for (const statement of statements) {
        for (const { pattern, message } of securityPatterns) {
          if (pattern.test(statement)) {
            warnings.push(message);
            recommendations.push('Review security implications of this operation');
          }
        }
      }

    } catch (error) {
      errors.push(`Security validation failed: ${error}`);
    }

    return { errors, warnings, recommendations };
  }

  // Helper methods for validation

  private splitSQLStatements(script: string): string[] {
    // Implementation similar to MigrationRunner
    const statements: string[] = [];
    let current = '';
    let inString = false;
    let stringDelimiter = '';
    let inComment = false;
    let inBlockComment = false;

    for (let i = 0; i < script.length; i++) {
      const char = script[i];
      const nextChar = script[i + 1];

      if (!inString && !inBlockComment) {
        if (char === '-' && nextChar === '-') {
          inComment = true;
          i++;
          continue;
        }
        if (char === '/' && nextChar === '*') {
          inBlockComment = true;
          i++;
          continue;
        }
      }

      if (inComment) {
        if (char === '\n') {
          inComment = false;
        }
        continue;
      }

      if (inBlockComment) {
        if (char === '*' && nextChar === '/') {
          inBlockComment = false;
          i++;
        }
        continue;
      }

      if ((char === "'" || char === '"') && !inString) {
        inString = true;
        stringDelimiter = char;
      } else if (char === stringDelimiter && inString) {
        if (script[i - 1] !== '\\') {
          inString = false;
          stringDelimiter = '';
        }
      }

      if (char === ';' && !inString) {
        if (current.trim()) {
          statements.push(current.trim());
        }
        current = '';
      } else {
        current += char;
      }
    }

    if (current.trim()) {
      statements.push(current.trim());
    }

    return statements.filter(s => s.length > 0);
  }

  private async validateStatementSyntax(statement: string): Promise<string | null> {
    // Simplified syntax validation - could use a proper SQL parser
    try {
      await this.pool.query(`EXPLAIN ${statement}`);
      return null;
    } catch (error) {
      return (error as Error).message;
    }
  }

  private containsProblematicPatterns(statement: string): boolean {
    const problematicPatterns = [
      /\bSELECT\s+\*\s+FROM/i,
      /\bINSERT\s+INTO\s+\w+\s+VALUES\s+\(\s*\)/i,
      /\bUPDATE\s+\w+\s+SET\s+\w+\s*=\s*NULL/i
    ];

    return problematicPatterns.some(pattern => pattern.test(statement));
  }

  private extractTableName(statement: string): string | null {
    const match = statement.match(/\b(?:CREATE\s+TABLE|ALTER\s+TABLE|DROP\s+TABLE)\s+(\w+)/i);
    return match ? match[1] : null;
  }

  private async tableExists(tableName: string): Promise<boolean> {
    try {
      const result = await this.pool.query(
        'SELECT 1 FROM information_schema.tables WHERE table_name = $1',
        [tableName]
      );
      return result.rows.length > 0;
    } catch (error) {
      this.logger.error('Error checking table existence', { error });
      return false;
    }
  }

  private async migrationExists(version: string): Promise<boolean> {
    try {
      const result = await this.pool.query(
        'SELECT 1 FROM migration_history WHERE current_version = $1',
        [version]
      );
      return result.rows.length > 0;
    } catch (error) {
      this.logger.error('Error checking migration existence', { error });
      return false;
    }
  }

  private async isMigrationApplied(version: string): Promise<boolean> {
    try {
      const result = await this.pool.query(
        'SELECT 1 FROM migration_history WHERE applied_migrations @> $1::jsonb',
        [JSON.stringify([version])]
      );
      return result.rows.length > 0;
    } catch (error) {
      this.logger.error('Error checking migration application', { error });
      return false;
    }
  }

  private async checkCircularDependencies(migration: Migration): Promise<boolean> {
    // Simplified circular dependency check
    const visited = new Set<string>();
    const recursionStack = new Set<string>();

    const hasCycle = (version: string, dependencies: string[]): boolean => {
      if (recursionStack.has(version)) return true;
      if (visited.has(version)) return false;

      visited.add(version);
      recursionStack.add(version);

      for (const dep of dependencies) {
        if (hasCycle(dep, [])) return true;
      }

      recursionStack.delete(version);
      return false;
    };

    return hasCycle(migration.version, migration.dependencies);
  }

  private estimateOperationTime(statement: string): number {
    // Very simplified time estimation
    if (statement.toUpperCase().includes('CREATE INDEX')) {
      return 30000; // 30 seconds
    }
    if (statement.toUpperCase().includes('CREATE TABLE')) {
      return 10000; // 10 seconds
    }
    return 1000; // 1 second default
  }

  // Test helper methods
  private async testSchemaCreation(client: PoolClient, migration: Migration): Promise<void> {
    const statements = this.splitSQLStatements(migration.upScript);
    for (const statement of statements) {
      await client.query(statement);
    }
  }

  private async testDataIntegrity(client: PoolClient, migration: Migration): Promise<{
    success: boolean;
    details: any;
    warnings: string[];
  }> {
    // Implementation would test data integrity constraints
    return { success: true, details: {}, warnings: [] };
  }

  private async testIndexPerformance(client: PoolClient, migration: Migration): Promise<{
    success: boolean;
    details: any;
  }> {
    // Implementation would test index performance
    return { success: true, details: {} };
  }

  private async testRollback(client: PoolClient, migration: Migration): Promise<{
    success: boolean;
    details: any;
  }> {
    // Implementation would test rollback
    return { success: true, details: {} };
  }

  private async validateInsertStatement(statement: string): Promise<{
    valid: boolean;
    errors: string[];
    warnings: string[];
  }> {
    // Basic INSERT validation
    const errors: string[] = [];
    const warnings: string[] = [];

    // Check for VALUES without column specification
    if (statement.match(/\bINSERT\s+INTO\s+\w+\s+VALUES/i) && !statement.includes('(')) {
      warnings.push('INSERT without explicit column list detected');
    }

    return { valid: errors.length === 0, errors, warnings };
  }

  private async validateRollbackSafety(migration: Migration): Promise<{
    errors: string[];
    warnings: string[];
    recommendations: string[];
  }> {
    const errors: string[] = [];
    const warnings: string[] = [];
    const recommendations: string[] = [];

    // Check rollback script safety
    const rollbackStatements = this.splitSQLStatements(migration.downScript);
    
    for (const statement of rollbackStatements) {
      const trimmed = statement.trim().toUpperCase();
      
      if (trimmed.startsWith('DROP')) {
        warnings.push(`DROP operation in rollback: ${trimmed.substring(0, 50)}...`);
        recommendations.push('Ensure data can be recovered before dropping objects');
      }
    }

    return { errors, warnings, recommendations };
  }

  private async validateReferentialIntegrity(migration: Migration, direction: 'up' | 'rollback'): Promise<{
    errors: string[];
    warnings: string[];
    recommendations: string[];
  }> {
    const errors: string[] = [];
    const warnings: string[] = [];
    const recommendations: string[] = [];

    // Check if rollback would break foreign key constraints
    const script = direction === 'rollback' ? migration.downScript : migration.upScript;
    const statements = this.splitSQLStatements(script);

    for (const statement of statements) {
      const trimmed = statement.trim().toUpperCase();
      
      if (trimmed.startsWith('DROP TABLE')) {
        const tableName = this.extractTableName(statement);
        if (tableName) {
          const hasForeignKeys = await this.tableHasForeignKeys(tableName);
          if (hasForeignKeys) {
            warnings.push(`Table ${tableName} has foreign key dependencies`);
            recommendations.push('Drop dependent tables first or use CASCADE');
          }
        }
      }
    }

    return { errors, warnings, recommendations };
  }

  private async tableHasForeignKeys(tableName: string): Promise<boolean> {
    try {
      const result = await this.pool.query(`
        SELECT COUNT(*) as count 
        FROM information_schema.table_constraints 
        WHERE constraint_type = 'FOREIGN KEY' 
        AND table_name = $1
      `, [tableName]);
      
      return parseInt(result.rows[0]?.count || '0') > 0;
    } catch (error) {
      this.logger.error('Error checking table foreign keys', { error });
      return false;
    }
  }
}