import { Pool, PoolClient, QueryResult } from 'pg';
import winston from 'winston';

/**
 * MigrationRunner - Safe execution of database migrations
 * 
 * Features:
 * - Transaction management with automatic rollback on failure
 * - Performance monitoring and timeout handling
 * - Lock management to prevent concurrent migrations
 * - Progress tracking and detailed logging
 */
export class MigrationRunner {
  private readonly MIGRATION_LOCK_KEY = 'migration_lock';
  private readonly DEFAULT_TIMEOUT = 60000; // 60 seconds

  constructor(
    private pool: Pool,
    private logger: winston.Logger
  ) {}

  /**
   * Execute a single migration safely with transaction protection
   */
  async executeMigration(
    client: PoolClient,
    migration: Migration
  ): Promise<{
    success: boolean;
    duration: number;
    rowsAffected: number;
    error?: Error;
  }> {
    const startTime = Date.now();

    try {
      this.logger.info(`Starting migration execution: ${migration.version}`, {
        description: migration.description,
        dependencies: migration.dependencies,
        estimatedDuration: migration.estimatedDuration
      });

      // Validate migration before execution
      await this.validateMigrationScript(migration);

      // Execute with timeout protection
      const result = await this.executeWithTimeout(
        () => this.executeMigrationScript(client, migration),
        Math.max(migration.estimatedDuration * 3, this.DEFAULT_TIMEOUT)
      );

      const duration = Date.now() - startTime;
      const rowsAffected = result.rowCount || 0;

      this.logger.info(`Migration ${migration.version} completed successfully`, {
        duration: `${duration}ms`,
        rowsAffected
      });

      return {
        success: true,
        duration,
        rowsAffected
      };

    } catch (error) {
      const duration = Date.now() - startTime;
      const migrationError = error as Error;

      this.logger.error(`Migration ${migration.version} failed`, {
        duration: `${duration}ms`,
        error: migrationError.message,
        stack: migrationError.stack
      });

      return {
        success: false,
        duration,
        rowsAffected: 0,
        error: migrationError
      };
    }
  }

  /**
   * Execute migration batch with proper error handling
   */
  async executeMigrationBatch(
    client: PoolClient,
    migrations: Migration[],
    onProgress?: (migration: Migration, progress: number) => void
  ): Promise<{
    success: boolean;
    results: Array<{
      migration: Migration;
      success: boolean;
      duration: number;
      rowsAffected: number;
      error?: Error;
    }>;
    totalDuration: number;
    totalRowsAffected: number;
  }> {
    const startTime = Date.now();
    const results: Array<{
      migration: Migration;
      success: boolean;
      duration: number;
      rowsAffected: number;
      error?: Error;
    }> = [];
    let totalRowsAffected = 0;
    let totalSuccess = true;

    try {
      this.logger.info(`Starting migration batch execution: ${migrations.length} migrations`);

      for (let i = 0; i < migrations.length; i++) {
        const migration = migrations[i];
        const progress = ((i + 1) / migrations.length) * 100;

        this.logger.debug(`Executing migration ${i + 1}/${migrations.length}`, {
          version: migration.version,
          progress: `${progress.toFixed(1)}%`
        });

        try {
          const result = await this.executeMigration(client, migration);
          results.push({
            migration,
            ...result
          });

          if (!result.success) {
            totalSuccess = false;
            // Stop on first failure
            break;
          }

          totalRowsAffected += result.rowsAffected;
          
        } catch (error) {
          const result = {
            migration,
            success: false,
            duration: 0,
            rowsAffected: 0,
            error: error as Error
          };
          results.push(result);
          totalSuccess = false;
          break;
        }

        // Call progress callback
        if (onProgress) {
          onProgress(migration, progress);
        }
      }

      const totalDuration = Date.now() - startTime;

      if (totalSuccess) {
        this.logger.info('Migration batch completed successfully', {
          totalDuration: `${totalDuration}ms`,
          totalMigrations: migrations.length,
          totalRowsAffected
        });
      } else {
        const failedMigration = results[results.length - 1]?.migration?.version;
        this.logger.error('Migration batch failed', {
          failedMigration,
          completedMigrations: results.length,
          totalDuration: `${totalDuration}ms`
        });
      }

      return {
        success: totalSuccess,
        results,
        totalDuration,
        totalRowsAffected
      };

    } catch (error) {
      const totalDuration = Date.now() - startTime;
      this.logger.error('Migration batch execution failed', {
        totalDuration: `${totalDuration}ms`,
        error: error as Error
      });

      return {
        success: false,
        results,
        totalDuration,
        totalRowsAffected
      };
    }
  }

  /**
   * Acquire migration lock to prevent concurrent migrations
   */
  async acquireLock(client: PoolClient, timeoutMs: number = 30000): Promise<boolean> {
    const lockId = `${this.MIGRATION_LOCK_KEY}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    try {
      // Try to acquire lock with advisory lock
      const result = await client.query(
        'SELECT pg_try_advisory_lock($1) as acquired',
        [this.hashLockKey(this.MIGRATION_LOCK_KEY)]
      );

      if (result.rows[0]?.acquired) {
        this.logger.info('Migration lock acquired', { lockId });
        return true;
      }

      this.logger.warn('Failed to acquire migration lock', { timeoutMs });
      return false;

    } catch (error) {
      this.logger.error('Error acquiring migration lock', { error });
      return false;
    }
  }

  /**
   * Release migration lock
   */
  async releaseLock(client: PoolClient): Promise<void> {
    try {
      await client.query(
        'SELECT pg_advisory_unlock($1)',
        [this.hashLockKey(this.MIGRATION_LOCK_KEY)]
      );
      this.logger.debug('Migration lock released');
    } catch (error) {
      this.logger.error('Error releasing migration lock', { error });
    }
  }

  /**
   * Check if migrations are currently running
   */
  async isMigrationRunning(client: PoolClient): Promise<boolean> {
    try {
      const result = await client.query(
        'SELECT pg_advisory_lock_exists($1) as locked',
        [this.hashLockKey(this.MIGRATION_LOCK_KEY)]
      );
      return result.rows[0]?.locked || false;
    } catch (error) {
      this.logger.error('Error checking migration lock status', { error });
      return false;
    }
  }

  /**
   * Kill long-running migrations (emergency use only)
   */
  async killRunningMigrations(): Promise<number> {
    try {
      const result = await this.pool.query(`
        SELECT pg_terminate_backend(pid) 
        FROM pg_stat_activity 
        WHERE state = 'active' 
        AND query LIKE '%migration%'
        AND pid != pg_backend_pid()
      `);
      
      const killed = result.rowCount || 0;
      this.logger.warn('Emergency migration termination', { killed });
      return killed;

    } catch (error) {
      this.logger.error('Error killing running migrations', { error });
      return 0;
    }
  }

  private async executeMigrationScript(client: PoolClient, migration: Migration): Promise<QueryResult> {
    // Split migration script into individual statements
    const statements = this.splitSQLStatements(migration.upScript);
    
    let totalRowsAffected = 0;

    for (const statement of statements) {
      const trimmed = statement.trim();
      if (!trimmed || trimmed.startsWith('--') || trimmed.startsWith('/*')) {
        continue; // Skip comments and empty lines
      }

      try {
        const result = await client.query(statement);
        totalRowsAffected += result.rowCount || 0;
        
        this.logger.debug('SQL statement executed', {
          statement: trimmed.substring(0, 100) + (trimmed.length > 100 ? '...' : ''),
          rowsAffected: result.rowCount
        });

      } catch (error) {
        const sqlError = error as Error;
        this.logger.error('SQL statement failed', {
          statement: trimmed.substring(0, 100),
          error: sqlError.message
        });
        throw new Error(`SQL Error in migration ${migration.version}: ${sqlError.message}`);
      }
    }

    return { rowCount: totalRowsAffected } as QueryResult;
  }

  private async validateMigrationScript(migration: Migration): Promise<void> {
    // Basic validation of migration script
    if (!migration.version || !migration.upScript) {
      throw new Error('Invalid migration: missing version or upScript');
    }

    // Check for potentially dangerous operations in upScript
    const dangerousPatterns = [
      /\bDROP\s+DATABASE\b/i,
      /\bDROP\s+USER\b/i,
      /\bDROP\s+ROLE\b/i,
      /\bSHUTDOWN\b/i,
      /\bKILL\b/i
    ];

    for (const pattern of dangerousPatterns) {
      if (pattern.test(migration.upScript)) {
        throw new Error(`Dangerous operation detected in migration ${migration.version}`);
      }
    }

    // Validate SQL syntax (basic check)
    const statements = this.splitSQLStatements(migration.upScript);
    for (const statement of statements) {
      const trimmed = statement.trim();
      if (trimmed && !trimmed.startsWith('--') && !trimmed.startsWith('/*')) {
        // Basic SQL syntax validation could be added here
        if (trimmed.length > 10000) {
          throw new Error(`Migration statement too long in ${migration.version}`);
        }
      }
    }
  }

  private splitSQLStatements(script: string): string[] {
    // Simple SQL statement splitter - enhanced version could handle more complex cases
    const statements: string[] = [];
    let current = '';
    let inString = false;
    let stringDelimiter = '';
    let inComment = false;
    let inBlockComment = false;

    for (let i = 0; i < script.length; i++) {
      const char = script[i];
      const nextChar = script[i + 1];

      // Handle comments
      if (!inString && !inBlockComment) {
        if (char === '-' && nextChar === '-') {
          inComment = true;
          i++; // Skip next character
          continue;
        }
        if (char === '/' && nextChar === '*') {
          inBlockComment = true;
          i++; // Skip next character
          continue;
        }
      }

      if (inComment) {
        if (char === '\n') {
          inComment = false;
        }
        continue;
      }

      if (inBlockComment) {
        if (char === '*' && nextChar === '/') {
          inBlockComment = false;
          i++; // Skip next character
        }
        continue;
      }

      // Handle strings
      if ((char === "'" || char === '"') && !inString) {
        inString = true;
        stringDelimiter = char;
      } else if (char === stringDelimiter && inString) {
        // Check if it's escaped
        if (script[i - 1] !== '\\') {
          inString = false;
          stringDelimiter = '';
        }
      }

      // Statement separator
      if (char === ';' && !inString) {
        if (current.trim()) {
          statements.push(current.trim());
        }
        current = '';
      } else {
        current += char;
      }
    }

    if (current.trim()) {
      statements.push(current.trim());
    }

    return statements.filter(s => s.length > 0);
  }

  private async executeWithTimeout<T>(
    operation: () => Promise<T>,
    timeoutMs: number
  ): Promise<T> {
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error(`Operation timed out after ${timeoutMs}ms`));
      }, timeoutMs);

      operation()
        .then(result => {
          clearTimeout(timeout);
          resolve(result);
        })
        .catch(error => {
          clearTimeout(timeout);
          reject(error);
        });
    });
  }

  private hashLockKey(key: string): number {
    // Simple hash function for advisory locks
    let hash = 0;
    for (let i = 0; i < key.length; i++) {
      const char = key.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash);
  }
}

// Re-export Migration interface
export interface Migration {
  version: string;
  description: string;
  dependencies: string[];
  estimatedDuration: number;
  upScript: string;
  downScript: string;
  checksum: string;
}