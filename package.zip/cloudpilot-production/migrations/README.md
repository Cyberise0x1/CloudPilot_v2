# Database Migration System

A comprehensive, production-ready database migration system for PostgreSQL with advanced features including dependency tracking, rollback capabilities, validation, and comprehensive history management.

## Features

### 🚀 Core Features
- **Migration Management**: Central coordination of migration operations
- **Safe Execution**: Transaction-protected migrations with automatic rollback on failure
- **Rollback Procedures**: Safe rollback with backup creation and dependency awareness
- **Validation & Testing**: Comprehensive validation, syntax checking, and rollback testing
- **History Tracking**: Complete audit trail with performance metrics and analytics

### 🛡️ Safety & Reliability
- **Advisory Locks**: Prevent concurrent migration execution
- **Transaction Safety**: All operations wrapped in transactions with rollback capability
- **Backup Creation**: Automatic backup before destructive operations
- **Timeout Protection**: Prevent long-running migrations from causing issues
- **Dependency Tracking**: Ensure migrations run in correct order with dependency resolution

### 📊 Monitoring & Analytics
- **Performance Tracking**: Execution time, rows affected, success rates
- **Error Analytics**: Most frequent errors, failure patterns
- **History Management**: Complete migration audit trail with pagination
- **Statistics Dashboard**: Migration analytics and performance metrics

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Migration Manager                        │
│                   (Central Coordinator)                         │
└─────────────────────┬───────────────────────────────────────────┘
                      │
        ┌─────────────┼─────────────┐
        │             │             │
┌───────▼─────┐ ┌─────▼─────┐ ┌────▼────────┐
│Migration    │ │Migration  │ │Migration    │
│Runner       │ │Validator  │ │Rollback     │
│(Execution)  │ │(Testing)  │ │(Recovery)   │
└─────────────┘ └───────────┘ └─────────────┘
                      │
              ┌───────▼────────┐
              │Migration       │
              │History         │
              │(Storage &      │
              │Tracking)       │
              └────────────────┘
```

## Installation

1. **Install Dependencies**:
```bash
npm install pg winston
```

2. **Add Environment Variables**:
```bash
DATABASE_URL=postgresql://user:password@localhost:5432/database
```

3. **Initialize Migration Tables**:
```bash
# The system automatically creates tables on first use
# Or run manually:
node migration-cli.js status
```

## Quick Start

### Basic Migration Execution

```typescript
import { MigrationManager } from './migrations/migration-manager.js';
import { Pool } from 'pg';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const manager = new MigrationManager(pool);

// Execute all pending migrations
const result = await manager.migrate();

if (result.success) {
  console.log(`Applied ${result.executedMigrations.length} migrations`);
} else {
  console.error('Migration failed:', result.error);
}
```

### CLI Usage

```bash
# Apply all pending migrations
npm run migrate

# Migrate to specific version
npm run migrate 003

# Rollback to version
npm run rollback 002

# Check status
npm run status

# Validate migrations
npm run validate

# Test migration
npm run test 003

# View statistics
npm run stats
```

## Components

### 1. Migration Manager (`migration-manager.ts`)

The central coordinator that manages the entire migration lifecycle.

**Key Features**:
- Coordinates between all components
- Manages dependency resolution
- Provides comprehensive error handling
- Supports both forward and backward migrations

**Usage**:
```typescript
const manager = new MigrationManager(pool, logger);

// Execute migrations
const result = await manager.migrate('003', {
  validate: true,
  dryRun: false,
  dependencies: []
});

// Rollback migrations
const rollbackResult = await manager.rollbackTo('002', {
  validate: true,
  dryRun: false
});

// Get current status
const status = await manager.getStatus();
```

### 2. Migration Runner (`migration-runner.ts`)

Handles safe execution of migration scripts with transaction protection.

**Key Features**:
- Advisory lock management to prevent concurrent execution
- Transaction safety with automatic rollback
- Performance monitoring and timeout protection
- SQL statement parsing and execution
- Progress tracking

**Usage**:
```typescript
const runner = new MigrationRunner(pool, logger);

// Execute single migration
const result = await runner.executeMigration(client, migration);

if (result.success) {
  console.log(`Migration completed in ${result.duration}ms`);
} else {
  console.error('Migration failed:', result.error);
}

// Execute batch with progress
const batchResult = await runner.executeMigrationBatch(
  client, 
  migrations,
  (migration, progress) => {
    console.log(`Progress: ${progress.toFixed(1)}%`);
  }
);
```

### 3. Migration Rollback (`migration-rollback.ts`)

Provides comprehensive rollback capabilities with safety checks.

**Key Features**:
- Automatic backup creation before rollback
- Transaction-safe rollback operations
- Dependency-aware rollback ordering
- Safety verification before destructive operations
- Emergency recovery procedures

**Usage**:
```typescript
const rollback = new MigrationRollback(pool, logger);

// Rollback single migration
const result = await rollback.rollbackMigration(migration);

// Rollback multiple migrations
const batchResult = await rollback.rollbackMigrations(migrations);

// Verify rollback safety
const safetyCheck = await rollback.verifyRollbackSafety(migration);
if (!safetyCheck.safe) {
  console.warn('Rollback risks:', safetyCheck.risks);
}
```

### 4. Migration Validator (`migration-validator.ts`)

Comprehensive validation and testing of migrations before execution.

**Key Features**:
- SQL syntax validation
- Schema integrity checking
- Data integrity validation
- Performance impact assessment
- Security validation
- Rollback testing
- Dependency checking

**Validation Checks**:
- Basic structure validation
- SQL syntax and semantic validation
- Schema integrity (table existence, foreign keys)
- Data integrity (INSERT/UPDATE/DELETE safety)
- Dependency validation and circular dependency detection
- Performance impact (index creation, table locking)
- Security impact (permissions, role changes)

**Usage**:
```typescript
const validator = new MigrationValidator(pool, logger);

// Validate migration
const validation = await validator.validateMigration(migration);
if (!validation.valid) {
  console.error('Validation failed:', validation.errors);
}

// Test migration
const test = await validator.testMigration(migration, {
  createTestSchema: true,
  simulateData: true,
  testRollback: true
});

// Validate rollback
const rollbackValidation = await validator.validateRollback(migration);
```

### 5. Migration History (`migration-history.ts`)

Tracks complete migration history with analytics and recovery capabilities.

**Key Features**:
- Complete migration audit trail
- Performance metrics and analytics
- State management and recovery
- Historical data with pagination
- Statistics and reporting
- Automatic cleanup

**Usage**:
```typescript
const history = new MigrationHistory(pool, logger);

// Get current state
const state = await history.getCurrentState();

// Get migration history with filters
const history = await history.getMigrationHistory(50, 0, {
  status: 'applied',
  dateFrom: new Date('2024-01-01'),
  success: true
});

// Get statistics
const stats = await history.getMigrationStatistics(
  new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) // Last 30 days
);

// Record migration execution
await history.recordMigrationBatch(['001', '002'], {
  executionDuration: 5000,
  rowsAffected: 150,
  success: true
});
```

## Migration File Format

Migration files follow a specific format with metadata:

```typescript
interface Migration {
  version: string;           // Unique version identifier (e.g., "001", "002")
  description: string;       // Human-readable description
  dependencies: string[];    // Array of version dependencies
  estimatedDuration: number; // Estimated execution time in milliseconds
  upScript: string;         // SQL script to apply migration
  downScript: string;       // SQL script to rollback migration
  checksum: string;         // Optional checksum for integrity
}
```

**Example Migration**:
```typescript
const migration: Migration = {
  version: '003',
  description: 'Add user roles and permissions',
  dependencies: ['001'], // Depends on user schema
  estimatedDuration: 3000,
  upScript: `
    CREATE TABLE user_roles (
      id SERIAL PRIMARY KEY,
      user_id INTEGER REFERENCES users(id),
      role VARCHAR(100) NOT NULL
    );
    
    CREATE INDEX idx_user_roles_user_id ON user_roles(user_id);
  `,
  downScript: `
    DROP INDEX IF EXISTS idx_user_roles_user_id;
    DROP TABLE IF EXISTS user_roles;
  `,
  checksum: 'abc123def456'
};
```

## Database Schema

The migration system creates the following tables:

### `migration_history`
Stores overall migration batch execution history.

```sql
CREATE TABLE migration_history (
  id SERIAL PRIMARY KEY,
  current_version VARCHAR(255) NOT NULL UNIQUE,
  applied_migrations JSONB NOT NULL DEFAULT '[]',
  last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  execution_duration INTEGER,
  rows_affected INTEGER DEFAULT 0,
  success BOOLEAN NOT NULL DEFAULT false,
  error_message TEXT,
  rollback_migrations JSONB DEFAULT '[]',
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### `migration_status`
Tracks individual migration status and metadata.

```sql
CREATE TABLE migration_status (
  version VARCHAR(255) PRIMARY KEY,
  status VARCHAR(50) NOT NULL CHECK (status IN (
    'pending', 'applying', 'applied', 
    'failed', 'rolling_back', 'rolled_back'
  )),
  applied_at TIMESTAMP WITH TIME ZONE,
  execution_duration INTEGER,
  rows_affected INTEGER DEFAULT 0,
  error_message TEXT,
  checksum VARCHAR(255),
  dependencies JSONB DEFAULT '[]',
  rollback_script TEXT,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### `migration_backups`
Stores backup information for recovery.

```sql
CREATE TABLE migration_backups (
  id VARCHAR(255) PRIMARY KEY,
  migration_version VARCHAR(255) NOT NULL,
  backup_type VARCHAR(50) NOT NULL CHECK (backup_type IN (
    'pre_migration', 'pre_rollback', 'manual'
  )),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  size INTEGER,
  checksum VARCHAR(255),
  storage_location TEXT,
  metadata JSONB DEFAULT '{}'
);
```

## CLI Commands

### Migration Commands

```bash
# Apply all pending migrations
npm run migrate

# Apply migrations up to specific version
npm run migrate 003

# Dry run (show what would be executed)
npm run migrate --dry-run

# Skip validation
npm run migrate --no-validate
```

### Rollback Commands

```bash
# Rollback to specific version
npm run rollback 002

# Rollback with validation
npm run rollback 002 --no-validate

# Dry run rollback
npm run rollback 002 --dry-run
```

### Status & Monitoring

```bash
# Show current migration status
npm run status

# Show migration history
npm run history 20 0

# Show statistics
npm run stats 30

# Validate migrations
npm run validate

# Test migration
npm run test 003
```

## Error Handling

The system provides comprehensive error handling at multiple levels:

### Migration Level
- Automatic transaction rollback on failure
- Detailed error logging and reporting
- Failed migration tracking in history
- Retry mechanisms for transient failures

### System Level
- Advisory locks prevent concurrent execution
- Timeout protection for long-running operations
- Resource cleanup on errors
- Graceful degradation for non-critical failures

### Recovery Procedures
- Automatic rollback on failed migrations
- Backup creation before destructive operations
- State recovery utilities
- Emergency force-set-state capability

## Performance Considerations

### Optimization Features
- **Batch Execution**: Process multiple migrations in a single transaction
- **Progress Tracking**: Monitor long-running migrations
- **Index Optimization**: Guidance on index creation impact
- **Connection Pooling**: Efficient database connection management

### Monitoring
- **Execution Time Tracking**: Monitor migration performance
- **Rows Affected Metrics**: Track data modification impact
- **Success Rate Analytics**: Monitor migration reliability
- **Historical Performance**: Identify slow migrations

## Security

### Safety Measures
- **SQL Injection Protection**: Parameterized queries throughout
- **Permission Validation**: Check for dangerous operations
- **Transaction Safety**: All operations atomic
- **Access Control**: Proper database permissions required

### Security Validation
The validator checks for:
- Dangerous operations (DROP DATABASE, etc.)
- Permission changes (GRANT/REVOKE statements)
- Role modifications (ALTER ROLE, DROP ROLE)
- Potential security impacts

## Best Practices

### 1. Migration Development
```typescript
// Good: Include proper dependencies and descriptions
const migration: Migration = {
  version: '003',
  description: 'Add user roles and permissions',
  dependencies: ['001'], // Always specify dependencies
  estimatedDuration: 3000, // Estimate execution time
  upScript: `
    -- Add clear comments
    CREATE TABLE user_roles (...);
  `,
  downScript: `
    -- Always provide rollback script
    DROP TABLE user_roles;
  `,
  checksum: '' // Optional integrity check
};
```

### 2. Transaction Safety
```typescript
// Always wrap migrations in transactions
await client.query('BEGIN');
try {
  await executeMigration(client, migration);
  await client.query('COMMIT');
} catch (error) {
  await client.query('ROLLBACK');
  throw error;
}
```

### 3. Error Handling
```typescript
try {
  const result = await manager.migrate('003');
  if (!result.success) {
    console.error('Migration failed:', result.error);
    // Handle failure appropriately
  }
} catch (error) {
  // Handle unexpected errors
  logger.error('Migration system error', { error });
}
```

### 4. Monitoring
```typescript
// Monitor migration performance
const history = await historyManager.getMigrationStatistics(
  new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) // Last week
);

console.log(`Success rate: ${(history.successfulMigrations / history.totalMigrations * 100).toFixed(1)}%`);
```

## Integration with Drizzle

This migration system works seamlessly with Drizzle ORM:

```typescript
import { drizzle } from 'drizzle-orm/node-postgres';
import { MigrationManager } from './migrations/migration-manager.js';

// Use with Drizzle
const client = new Pool({ connectionString: process.env.DATABASE_URL });
const db = drizzle(client);
const manager = new MigrationManager(client, logger);

// Run migrations
await manager.migrate();

// Continue using Drizzle normally
const users = await db.select().from(usersTable);
```

## Troubleshooting

### Common Issues

1. **Migration Lock Timeout**
```
Error: Could not acquire migration lock
```
**Solution**: Wait for current migration to complete or kill stuck processes.

2. **Dependency Conflicts**
```
Error: Dependency migration not found
```
**Solution**: Ensure all dependencies exist and are properly ordered.

3. **Rollback Failures**
```
Error: Cannot rollback to version
```
**Solution**: Check if target version exists in applied migrations.

4. **Validation Failures**
```
Error: SQL syntax error in migration
```
**Solution**: Review and fix migration SQL syntax before execution.

### Debug Mode

Enable detailed logging:

```typescript
const logger = winston.createLogger({
  level: 'debug',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [new winston.transports.Console()]
});

const manager = new MigrationManager(pool, logger);
```

### Recovery Procedures

1. **Force State Reset** (emergency only):
```typescript
await manager.forceSetState('002', ['001', '002'], client);
```

2. **Restore from Backup**:
```typescript
await rollback.restoreFromBackup(backupId, targetState);
```

3. **Cleanup Failed Migrations**:
```sql
DELETE FROM migration_status WHERE status = 'failed';
```

## Contributing

1. **Code Style**: Follow TypeScript best practices
2. **Error Handling**: Always provide comprehensive error handling
3. **Documentation**: Document all public APIs and complex logic
4. **Testing**: Include tests for new features
5. **Performance**: Consider performance implications

## License

MIT License - see LICENSE file for details.

## Changelog

### v1.0.0
- Initial release with core migration functionality
- Complete validation and testing system
- Comprehensive rollback capabilities
- History tracking and analytics
- CLI interface with full command set