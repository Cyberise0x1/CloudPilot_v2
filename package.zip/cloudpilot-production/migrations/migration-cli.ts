#!/usr/bin/env node
/**
 * Migration System CLI - Example implementation
 * 
 * This script demonstrates how to use the complete migration system
 * including manager, runner, validator, rollback, and history components.
 */

import { Pool } from 'pg';
import winston from 'winston';
import { MigrationManager } from './migration-manager.js';
import { Migration, MigrationResult } from './migration-manager.js';

// Initialize database connection and logger
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.printf(({ timestamp, level, message, ...meta }) => {
      return `${timestamp} [${level.toUpperCase()}]: ${message} ${Object.keys(meta).length ? JSON.stringify(meta) : ''}`;
    })
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'migration.log' })
  ],
});

// Example migration files
const exampleMigrations: Migration[] = [
  {
    version: '001',
    description: 'Create initial user schema',
    dependencies: [],
    estimatedDuration: 2000,
    upScript: `
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username VARCHAR(255) UNIQUE NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
      
      CREATE INDEX idx_users_username ON users(username);
      CREATE INDEX idx_users_email ON users(email);
    `,
    downScript: `
      DROP INDEX IF EXISTS idx_users_email;
      DROP INDEX IF EXISTS idx_users_username;
      DROP TABLE IF EXISTS users;
    `,
    checksum: 'abc123'
  },
  {
    version: '002',
    description: 'Add audit logging table',
    dependencies: [],
    estimatedDuration: 1500,
    upScript: `
      CREATE TABLE IF NOT EXISTS audit_logs (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
        action VARCHAR(255) NOT NULL,
        resource_type VARCHAR(100),
        resource_id VARCHAR(255),
        details JSONB,
        ip_address INET,
        user_agent TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
      
      CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
      CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at);
      CREATE INDEX idx_audit_logs_action ON audit_logs(action);
    `,
    downScript: `
      DROP INDEX IF EXISTS idx_audit_logs_action;
      DROP INDEX IF EXISTS idx_audit_logs_created_at;
      DROP INDEX IF EXISTS idx_audit_logs_user_id;
      DROP TABLE IF EXISTS audit_logs;
    `,
    checksum: 'def456'
  },
  {
    version: '003',
    description: 'Add user roles and permissions',
    dependencies: ['001'],
    estimatedDuration: 3000,
    upScript: `
      CREATE TABLE IF NOT EXISTS user_roles (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        role VARCHAR(100) NOT NULL,
        granted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        granted_by INTEGER REFERENCES users(id) ON DELETE SET NULL
      );
      
      CREATE TABLE IF NOT EXISTS permissions (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) UNIQUE NOT NULL,
        description TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
      
      CREATE TABLE IF NOT EXISTS role_permissions (
        role VARCHAR(100) NOT NULL,
        permission_id INTEGER REFERENCES permissions(id) ON DELETE CASCADE,
        PRIMARY KEY (role, permission_id)
      );
      
      CREATE INDEX idx_user_roles_user_id ON user_roles(user_id);
      CREATE INDEX idx_user_roles_role ON user_roles(role);
      CREATE INDEX idx_role_permissions_role ON role_permissions(role);
      
      -- Insert default permissions
      INSERT INTO permissions (name, description) VALUES
        ('read:users', 'Read user information'),
        ('write:users', 'Create and update users'),
        ('delete:users', 'Delete users'),
        ('read:audit', 'Read audit logs'),
        ('admin:system', 'System administration')
      ON CONFLICT (name) DO NOTHING;
    `,
    downScript: `
      DROP TABLE IF EXISTS role_permissions;
      DROP TABLE IF EXISTS permissions;
      DROP TABLE IF EXISTS user_roles;
      DROP INDEX IF EXISTS idx_user_roles_role;
      DROP INDEX IF EXISTS idx_user_roles_user_id;
      DROP INDEX IF EXISTS idx_role_permissions_role;
    `,
    checksum: 'ghi789'
  },
  {
    version: '004',
    description: 'Add session management',
    dependencies: ['001'],
    estimatedDuration: 1000,
    upScript: `
      CREATE TABLE IF NOT EXISTS user_sessions (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        refresh_token_hash VARCHAR(255) NOT NULL,
        expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        last_used_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        ip_address INET,
        user_agent TEXT,
        is_active BOOLEAN DEFAULT TRUE
      );
      
      CREATE INDEX idx_user_sessions_user_id ON user_sessions(user_id);
      CREATE INDEX idx_user_sessions_refresh_token ON user_sessions(refresh_token_hash);
      CREATE INDEX idx_user_sessions_expires_at ON user_sessions(expires_at);
      
      CREATE OR REPLACE FUNCTION cleanup_expired_sessions()
      RETURNS void AS $$
      BEGIN
        DELETE FROM user_sessions 
        WHERE expires_at < NOW() OR is_active = FALSE;
      END;
      $$ LANGUAGE plpgsql;
    `,
    downScript: `
      DROP FUNCTION IF EXISTS cleanup_expired_sessions;
      DROP INDEX IF EXISTS idx_user_sessions_expires_at;
      DROP INDEX IF EXISTS idx_user_sessions_refresh_token;
      DROP INDEX IF EXISTS idx_user_sessions_user_id;
      DROP TABLE IF EXISTS user_sessions;
    `,
    checksum: 'jkl012'
  }
];

/**
 * Main CLI interface
 */
async function main() {
  const command = process.argv[2];
  const args = process.argv.slice(3);

  try {
    const manager = new MigrationManager(pool, logger);

    switch (command) {
      case 'migrate':
        await handleMigrate(manager, args);
        break;
      case 'rollback':
        await handleRollback(manager, args);
        break;
      case 'status':
        await handleStatus(manager, args);
        break;
      case 'validate':
        await handleValidate(manager, args);
        break;
      case 'history':
        await handleHistory(manager, args);
        break;
      case 'test':
        await handleTest(manager, args);
        break;
      case 'stats':
        await handleStats(manager, args);
        break;
      default:
        showUsage();
        process.exit(1);
    }

  } catch (error) {
    logger.error('Command execution failed', { error });
    process.exit(1);
  } finally {
    await pool.end();
  }
}

/**
 * Handle migrate command
 */
async function handleMigrate(manager: MigrationManager, args: string[]) {
  const targetVersion = args[0];
  const validate = !args.includes('--no-validate');
  const dryRun = args.includes('--dry-run');

  logger.info('Starting migration', { targetVersion, validate, dryRun });

  // Simulate discovered migrations
  const discoveredMigrations = await simulateMigrationDiscovery(exampleMigrations);
  
  const result = await manager.migrate(targetVersion, {
    validate,
    dryRun,
    dependencies: []
  });

  if (result.success) {
    logger.info('Migration completed successfully', {
      executedMigrations: result.executedMigrations,
      dryRun
    });
  } else {
    logger.error('Migration failed', {
      failedMigration: result.failedMigration,
      error: result.error?.message
    });
    process.exit(1);
  }
}

/**
 * Handle rollback command
 */
async function handleRollback(manager: MigrationManager, args: string[]) {
  const targetVersion = args[0];
  const validate = !args.includes('--no-validate');
  const dryRun = args.includes('--dry-run');

  if (!targetVersion) {
    logger.error('Target version required for rollback');
    process.exit(1);
  }

  logger.info('Starting rollback', { targetVersion, validate, dryRun });

  const result = await manager.rollbackTo(targetVersion, {
    validate,
    dryRun
  });

  if (result.success) {
    logger.info('Rollback completed successfully', {
      rolledBackMigrations: result.rolledBackMigrations,
      dryRun
    });
  } else {
    logger.error('Rollback failed', {
      error: result.error?.message
    });
    process.exit(1);
  }
}

/**
 * Handle status command
 */
async function handleStatus(manager: MigrationManager, args: string[]) {
  const status = await manager.getStatus();

  console.log('\n=== Migration Status ===');
  console.log(`Current Version: ${status.currentVersion}`);
  console.log(`Total Migrations: ${status.totalMigrations}`);
  console.log(`Applied Migrations: ${status.appliedMigrations.length}`);
  console.log(`Pending Migrations: ${status.pendingMigrations.length}`);
  console.log(`Failed Migrations: ${status.failedMigrations.length}`);

  if (status.appliedMigrations.length > 0) {
    console.log('\nApplied Migrations:');
    status.appliedMigrations.forEach(version => {
      const migration = exampleMigrations.find(m => m.version === version);
      console.log(`  ✓ ${version} - ${migration?.description || 'Unknown'}`);
    });
  }

  if (status.pendingMigrations.length > 0) {
    console.log('\nPending Migrations:');
    status.pendingMigrations.forEach(version => {
      const migration = exampleMigrations.find(m => m.version === version);
      console.log(`  → ${version} - ${migration?.description || 'Unknown'}`);
    });
  }

  if (status.failedMigrations.length > 0) {
    console.log('\nFailed Migrations:');
    status.failedMigrations.forEach(version => {
      const migration = exampleMigrations.find(m => m.version === version);
      console.log(`  ✗ ${version} - ${migration?.description || 'Unknown'}`);
    });
  }
}

/**
 * Handle validate command
 */
async function handleValidate(manager: MigrationManager, args: string[]) {
  const targetVersion = args[0];
  const migrations = await simulateMigrationDiscovery(exampleMigrations);
  const validator = manager['validator']; // Access private property for demo

  let migrationsToValidate: Migration[] = [];

  if (targetVersion) {
    const migration = migrations.find(m => m.version === targetVersion);
    if (migration) {
      migrationsToValidate = [migration];
    } else {
      logger.error(`Migration ${targetVersion} not found`);
      process.exit(1);
    }
  } else {
    migrationsToValidate = migrations;
  }

  console.log(`\n=== Validating ${migrationsToValidate.length} Migration(s) ===\n`);

  let allValid = true;

  for (const migration of migrationsToValidate) {
    const result = await validator.validateMigration(migration);
    
    console.log(`Migration ${migration.version}: ${migration.description}`);
    console.log(`Valid: ${result.valid ? '✓' : '✗'}`);

    if (result.errors.length > 0) {
      console.log('Errors:');
      result.errors.forEach(error => console.log(`  - ${error}`));
      allValid = false;
    }

    if (result.warnings.length > 0) {
      console.log('Warnings:');
      result.warnings.forEach(warning => console.log(`  ! ${warning}`));
    }

    if (result.recommendations.length > 0) {
      console.log('Recommendations:');
      result.recommendations.forEach(rec => console.log(`  → ${rec}`));
    }

    console.log(`Checks performed: ${result.checksPerformed.join(', ')}`);
    console.log('');
  }

  if (!allValid) {
    console.log('❌ Validation failed - please fix errors before proceeding');
    process.exit(1);
  } else {
    console.log('✅ All migrations passed validation');
  }
}

/**
 * Handle history command
 */
async function handleHistory(manager: MigrationManager, args: string[]) {
  const limit = parseInt(args[0]) || 20;
  const offset = parseInt(args[1]) || 0;
  
  const history = await manager['history'].getMigrationHistory(limit, offset);

  console.log('\n=== Migration History ===');
  console.log(`Total records: ${history.total}`);
  console.log(`Showing ${history.migrations.length} records\n`);

  if (history.migrations.length === 0) {
    console.log('No migration history found');
    return;
  }

  history.migrations.forEach(migration => {
    const status = migration.status === 'applied' ? '✓' : migration.status === 'failed' ? '✗' : '→';
    const duration = migration.executionDuration ? `${migration.executionDuration}ms` : '';
    const appliedAt = migration.appliedAt ? new Date(migration.appliedAt).toLocaleString() : '';
    
    console.log(`${status} ${migration.version} - ${migration.description || 'No description'}`);
    console.log(`   Status: ${migration.status} ${duration ? `(${duration})` : ''} ${appliedAt}`);
    
    if (migration.errorMessage) {
      console.log(`   Error: ${migration.errorMessage}`);
    }
    console.log('');
  });

  if (history.hasMore) {
    console.log('More history available...');
  }
}

/**
 * Handle test command
 */
async function handleTest(manager: MigrationManager, args: string[]) {
  const targetVersion = args[0];
  const migrations = await simulateMigrationDiscovery(exampleMigrations);

  let migrationToTest: Migration | undefined;

  if (targetVersion) {
    migrationToTest = migrations.find(m => m.version === targetVersion);
    if (!migrationToTest) {
      logger.error(`Migration ${targetVersion} not found`);
      process.exit(1);
    }
  } else {
    // Test the first pending migration
    const status = await manager.getStatus();
    const firstPending = status.pendingMigrations[0];
    if (firstPending) {
      migrationToTest = migrations.find(m => m.version === firstPending);
    }
  }

  if (!migrationToTest) {
    console.log('No migrations to test');
    return;
  }

  const validator = manager['validator']; // Access private property for demo

  console.log(`\n=== Testing Migration ${migrationToTest.version} ===`);
  console.log(`${migrationToTest.description}\n`);

  // Validate migration
  const validationResult = await validator.validateMigration(migrationToTest);
  console.log('Validation Result:');
  console.log(`  Valid: ${validationResult.valid ? '✓' : '✗'}`);
  
  if (validationResult.errors.length > 0) {
    console.log('  Errors:');
    validationResult.errors.forEach(error => console.log(`    - ${error}`));
  }

  if (validationResult.warnings.length > 0) {
    console.log('  Warnings:');
    validationResult.warnings.forEach(warning => console.log(`    ! ${warning}`));
  }

  if (!validationResult.valid) {
    console.log('\n❌ Migration failed validation - cannot test');
    process.exit(1);
  }

  // Test migration
  console.log('\nTesting migration execution...');
  const testResult = await validator.testMigration(migrationToTest, {
    createTestSchema: true,
    simulateData: true,
    testRollback: true
  });

  console.log(`Test completed in ${testResult.totalDuration}ms`);
  console.log(`Overall result: ${testResult.success ? '✓ PASSED' : '✗ FAILED'}`);

  testResult.testResults.forEach(result => {
    const icon = result.passed ? '✓' : '✗';
    console.log(`  ${icon} ${result.test}: ${result.passed ? 'PASSED' : 'FAILED'} (${result.duration}ms)`);
    
    if (result.error) {
      console.log(`    Error: ${result.error}`);
    }
  });

  if (testResult.warnings.length > 0) {
    console.log('\nTest Warnings:');
    testResult.warnings.forEach(warning => console.log(`  ! ${warning}`));
  }

  if (!testResult.success) {
    console.log('\n❌ Migration testing failed');
    process.exit(1);
  } else {
    console.log('\n✅ Migration testing passed');
  }
}

/**
 * Handle stats command
 */
async function handleStats(manager: MigrationManager, args: string[]) {
  const days = parseInt(args[0]) || 30;
  const dateFrom = new Date();
  dateFrom.setDate(dateFrom.getDate() - days);

  const stats = await manager['history'].getMigrationStatistics(dateFrom);

  console.log('\n=== Migration Statistics ===');
  console.log(`Period: Last ${days} days`);
  console.log(`Total Migrations: ${stats.totalMigrations}`);
  console.log(`Successful: ${stats.successfulMigrations}`);
  console.log(`Failed: ${stats.failedMigrations}`);
  console.log(`Success Rate: ${stats.totalMigrations > 0 ? ((stats.successfulMigrations / stats.totalMigrations) * 100).toFixed(1) : 0}%`);

  if (stats.totalExecutionTime > 0) {
    console.log(`\nPerformance:`);
    console.log(`  Total Execution Time: ${(stats.totalExecutionTime / 1000).toFixed(1)}s`);
    console.log(`  Average Execution Time: ${stats.averageExecutionTime}ms`);
    
    if (stats.performanceMetrics.slowestMigration) {
      console.log(`  Slowest: ${stats.performanceMetrics.slowestMigration.version} (${stats.performanceMetrics.slowestMigration.duration}ms)`);
    }
    
    if (stats.performanceMetrics.fastestMigration) {
      console.log(`  Fastest: ${stats.performanceMetrics.fastestMigration.version} (${stats.performanceMetrics.fastestMigration.duration}ms)`);
    }
    
    console.log(`  Total Rows Affected: ${stats.performanceMetrics.totalRowsAffected}`);
  }

  if (stats.mostFrequentErrors.length > 0) {
    console.log(`\nMost Frequent Errors:`);
    stats.mostFrequentErrors.forEach(error => {
      console.log(`  ${error.count}x: ${error.error}`);
    });
  }
}

/**
 * Show usage information
 */
function showUsage() {
  console.log(`
Migration System CLI

Usage: migration-cli.js <command> [options]

Commands:
  migrate [version]    Execute migrations up to version (or all pending)
  rollback <version>   Rollback to specific version
  status               Show current migration status
  validate [version]   Validate migration(s) before execution
  history [limit] [offset] Show migration history
  test [version]       Test migration execution and rollback
  stats [days]         Show migration statistics

Options:
  --dry-run           Show what would be executed without running
  --no-skip-validate  Skip validation checks
  --help             Show this help message

Examples:
  # Run all pending migrations
  npm run migrate

  # Migrate to specific version
  npm run migrate 003

  # Dry run migration
  npm run migrate --dry-run

  # Rollback to version 002
  npm run rollback 002

  # Check status
  npm run status

  # Validate migrations
  npm run validate

  # Test specific migration
  npm run test 003

  # View statistics for last 30 days
  npm run stats 30
`);
}

/**
 * Simulate migration file discovery
 */
async function simulateMigrationDiscovery(migrationFiles: Migration[]): Promise<Migration[]> {
  // In a real implementation, this would scan the migrations directory
  // and load migration files dynamically
  
  // Add file paths for demonstration
  return migrationFiles.map(migration => ({
    ...migration,
    filePath: `migrations/${migration.version}_${migration.description.replace(/\s+/g, '_')}.sql`
  }));
}

// Initialize tables on startup
async function initializeTables() {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS migration_history (
        id SERIAL PRIMARY KEY,
        current_version VARCHAR(255) NOT NULL UNIQUE,
        applied_migrations JSONB NOT NULL DEFAULT '[]',
        last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        execution_duration INTEGER,
        rows_affected INTEGER DEFAULT 0,
        success BOOLEAN NOT NULL DEFAULT false,
        error_message TEXT,
        rollback_migrations JSONB DEFAULT '[]',
        metadata JSONB DEFAULT '{}',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS migration_status (
        version VARCHAR(255) PRIMARY KEY,
        status VARCHAR(50) NOT NULL CHECK (status IN ('pending', 'applying', 'applied', 'failed', 'rolling_back', 'rolled_back')),
        applied_at TIMESTAMP WITH TIME ZONE,
        execution_duration INTEGER,
        rows_affected INTEGER DEFAULT 0,
        error_message TEXT,
        checksum VARCHAR(255),
        dependencies JSONB DEFAULT '[]',
        rollback_script TEXT,
        metadata JSONB DEFAULT '{}',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS migration_backups (
        id VARCHAR(255) PRIMARY KEY,
        migration_version VARCHAR(255) NOT NULL,
        backup_type VARCHAR(50) NOT NULL CHECK (backup_type IN ('pre_migration', 'pre_rollback', 'manual')),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        size INTEGER,
        checksum VARCHAR(255),
        storage_location TEXT,
        metadata JSONB DEFAULT '{}'
      )
    `);

    logger.info('Migration tables initialized successfully');
  } catch (error) {
    logger.error('Failed to initialize migration tables', { error });
    throw error;
  }
}

// Run if called directly
if (import.meta.url === `file://${process.argv[1]}`) {
  initializeTables().then(() => main());
}