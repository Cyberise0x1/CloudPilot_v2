import { Pool, PoolClient, QueryResult } from 'pg';
import winston from 'winston';
import { Migration } from './migration-manager.js';

/**
 * MigrationRollback - Safe rollback procedures for database migrations
 * 
 * Features:
 * - Automatic backup creation before rollback
 * - Transaction-safe rollback operations
 * - Dependency-aware rollback ordering
 * - Partial rollback capabilities with state verification
 */
export class MigrationRollback {
  private readonly BACKUP_PREFIX = 'migration_backup_';
  private readonly ROLLBACK_LOCK_KEY = 'rollback_lock';

  constructor(
    private pool: Pool,
    private logger: winston.Logger
  ) {}

  /**
   * Rollback a single migration
   */
  async rollbackMigration(
    migration: Migration,
    client?: PoolClient
  ): Promise<{
    success: boolean;
    backupCreated: boolean;
    duration: number;
    rowsAffected: number;
    error?: Error;
  }> {
    const startTime = Date.now();
    const usedClient = client || await this.pool.connect();
    let backupCreated = false;

    try {
      this.logger.info(`Starting rollback for migration: ${migration.version}`, {
        description: migration.description,
        hasDownScript: !!migration.downScript
      });

      if (!migration.downScript) {
        throw new Error(`Migration ${migration.version} has no rollback script`);
      }

      // Acquire rollback lock
      const hasLock = await this.acquireRollbackLock(usedClient);
      if (!hasLock) {
        throw new Error('Unable to acquire rollback lock');
      }

      try {
        // Create backup before rollback
        backupCreated = await this.createBackup(usedClient, migration);
        
        // Execute rollback
        const result = await this.executeRollbackScript(usedClient, migration);
        const duration = Date.now() - startTime;
        const rowsAffected = result.rowCount || 0;

        this.logger.info(`Migration rollback completed successfully: ${migration.version}`, {
          duration: `${duration}ms`,
          rowsAffected,
          backupCreated
        });

        return {
          success: true,
          backupCreated,
          duration,
          rowsAffected
        };

      } finally {
        await this.releaseRollbackLock(usedClient);
      }

    } catch (error) {
      const duration = Date.now() - startTime;
      const rollbackError = error as Error;

      this.logger.error(`Migration rollback failed: ${migration.version}`, {
        duration: `${duration}ms`,
        error: rollbackError.message,
        backupCreated
      });

      return {
        success: false,
        backupCreated,
        duration,
        rowsAffected: 0,
        error: rollbackError
      };

    } finally {
      if (!client) {
        usedClient.release();
      }
    }
  }

  /**
   * Rollback multiple migrations in sequence
   */
  async rollbackMigrations(
    migrations: Migration[],
    onProgress?: (migration: Migration, progress: number) => void
  ): Promise<{
    success: boolean;
    rolledBackMigrations: string[];
    failedMigration?: string;
    totalDuration: number;
    totalRowsAffected: number;
    error?: Error;
  }> {
    const startTime = Date.now();
    const rolledBackMigrations: string[] = [];
    let totalRowsAffected = 0;
    let failedMigration: string | undefined;

    // Sort migrations for rollback (reverse order of application)
    const sortedMigrations = migrations.sort((a, b) => 
      this.compareVersions(b.version, a.version)
    );

    const client = await this.pool.connect();
    
    try {
      this.logger.info(`Starting rollback of ${migrations.length} migrations`);

      await client.query('BEGIN');

      for (let i = 0; i < sortedMigrations.length; i++) {
        const migration = sortedMigrations[i];
        const progress = ((i + 1) / sortedMigrations.length) * 100;

        this.logger.debug(`Rolling back migration ${i + 1}/${sortedMigrations.length}`, {
          version: migration.version,
          progress: `${progress.toFixed(1)}%`
        });

        try {
          const result = await this.rollbackMigration(migration, client);
          
          if (!result.success) {
            failedMigration = migration.version;
            throw result.error || new Error(`Unknown error rolling back ${migration.version}`);
          }

          rolledBackMigrations.push(migration.version);
          totalRowsAffected += result.rowsAffected;

          if (onProgress) {
            onProgress(migration, progress);
          }

        } catch (error) {
          this.logger.error(`Failed to rollback migration ${migration.version}`, { error });
          failedMigration = migration.version;
          throw error;
        }
      }

      await client.query('COMMIT');
      const totalDuration = Date.now() - startTime;

      this.logger.info('All migrations rolled back successfully', {
        totalDuration: `${totalDuration}ms`,
        rolledBackMigrations
      });

      return {
        success: true,
        rolledBackMigrations,
        totalDuration,
        totalRowsAffected
      };

    } catch (error) {
      await client.query('ROLLBACK');
      const totalDuration = Date.now() - startTime;
      
      this.logger.error('Rollback process failed', {
        totalDuration: `${totalDuration}ms`,
        rolledBackMigrations,
        failedMigration
      });

      return {
        success: false,
        rolledBackMigrations,
        failedMigration,
        totalDuration,
        totalRowsAffected,
        error: error as Error
      };

    } finally {
      client.release();
    }
  }

  /**
   * Rollback to a previous state (emergency recovery)
   */
  async rollbackToPreviousState(
    client: PoolClient,
    previousState: MigrationState
  ): Promise<void> {
    try {
      this.logger.info('Rolling back to previous state', {
        version: previousState.currentVersion,
        migrations: previousState.appliedMigrations
      });

      // Get current state
      const currentState = await this.getCurrentState();
      
      // Find migrations to rollback
      const migrationsToRollback = currentState.appliedMigrations
        .filter(version => !previousState.appliedMigrations.includes(version))
        .reverse(); // Rollback in reverse order

      if (migrationsToRollback.length === 0) {
        this.logger.info('No migrations to rollback to previous state');
        return;
      }

      // Load migration objects
      const migrations = await Promise.all(
        migrationsToRollback.map(version => this.loadMigration(version))
      );

      // Rollback each migration
      for (const migration of migrations) {
        if (migration) {
          await this.rollbackMigration(migration, client);
        }
      }

      // Update migration history
      await this.updateMigrationHistory(client, previousState);

      this.logger.info('Successfully rolled back to previous state');

    } catch (error) {
      this.logger.error('Failed to rollback to previous state', { error });
      throw error;
    }
  }

  /**
   * Restore from a migration backup
   */
  async restoreFromBackup(
    backupId: string,
    targetState?: MigrationState
  ): Promise<{
    success: boolean;
    restoredMigration?: string;
    duration: number;
    error?: Error;
  }> {
    const startTime = Date.now();

    try {
      this.logger.info('Starting restore from backup', { backupId });

      const backup = await this.getBackup(backupId);
      if (!backup) {
        throw new Error(`Backup ${backupId} not found`);
      }

      const client = await this.pool.connect();
      try {
        await client.query('BEGIN');

        // Apply backup restoration logic here
        // This would depend on how backups are stored
        const result = await this.applyBackup(client, backup, targetState);

        await client.query('COMMIT');
        const duration = Date.now() - startTime;

        this.logger.info('Backup restoration completed successfully', {
          backupId,
          duration: `${duration}ms`
        });

        return {
          success: true,
          restoredMigration: backup.migrationVersion,
          duration
        };

      } catch (error) {
        await client.query('ROLLBACK');
        throw error;

      } finally {
        client.release();
      }

    } catch (error) {
      const duration = Date.now() - startTime;
      this.logger.error('Backup restoration failed', {
        backupId,
        duration: `${duration}ms`,
        error
      });

      return {
        success: false,
        duration,
        error: error as Error
      };
    }
  }

  /**
   * Verify rollback safety before proceeding
   */
  async verifyRollbackSafety(
    migration: Migration,
    affectedTables?: string[]
  ): Promise<{
    safe: boolean;
    risks: string[];
    recommendations: string[];
    backupAvailable: boolean;
  }> {
    const risks: string[] = [];
    const recommendations: string[] = [];

    try {
      // Check if backup exists
      const backupAvailable = await this.hasBackup(migration.version);

      if (!backupAvailable) {
        risks.push('No backup available for this migration');
        recommendations.push('Create a backup before proceeding with rollback');
      }

      // Check for foreign key dependencies
      if (affectedTables && affectedTables.length > 0) {
        const dependencies = await this.checkForeignKeyDependencies(affectedTables);
        if (dependencies.length > 0) {
          risks.push(`Foreign key dependencies detected: ${dependencies.join(', ')}`);
          recommendations.push('Review foreign key constraints before rollback');
        }
      }

      // Check for active connections
      const activeConnections = await this.checkActiveConnections(migration.version);
      if (activeConnections > 0) {
        risks.push(`${activeConnections} active connections may be affected`);
        recommendations.push('Consider waiting for active queries to complete');
      }

      // Validate rollback script
      if (!migration.downScript || migration.downScript.trim().length === 0) {
        risks.push('No rollback script available');
        recommendations.push('Create a proper rollback script before proceeding');
      }

      const safe = risks.length === 0;

      return {
        safe,
        risks,
        recommendations,
        backupAvailable
      };

    } catch (error) {
      this.logger.error('Error verifying rollback safety', { error });
      return {
        safe: false,
        risks: ['Unable to verify rollback safety'],
        recommendations: ['Manual review recommended'],
        backupAvailable: false
      };
    }
  }

  private async createBackup(client: PoolClient, migration: Migration): Promise<boolean> {
    try {
      const backupId = `${this.BACKUP_PREFIX}${migration.version}_${Date.now()}`;
      
      // Store backup information
      await this.storeBackup(client, {
        id: backupId,
        migrationVersion: migration.version,
        createdAt: new Date(),
        size: migration.upScript.length,
        checksum: migration.checksum
      });

      this.logger.debug('Backup created', { backupId, migrationVersion: migration.version });
      return true;

    } catch (error) {
      this.logger.error('Failed to create backup', { error });
      return false;
    }
  }

  private async executeRollbackScript(client: PoolClient, migration: Migration): Promise<QueryResult> {
    const statements = this.splitSQLStatements(migration.downScript);
    let totalRowsAffected = 0;

    for (const statement of statements) {
      const trimmed = statement.trim();
      if (!trimmed || trimmed.startsWith('--') || trimmed.startsWith('/*')) {
        continue;
      }

      try {
        const result = await client.query(statement);
        totalRowsAffected += result.rowCount || 0;
        
        this.logger.debug('Rollback SQL statement executed', {
          statement: trimmed.substring(0, 100) + (trimmed.length > 100 ? '...' : ''),
          rowsAffected: result.rowCount
        });

      } catch (error) {
        const sqlError = error as Error;
        this.logger.error('Rollback SQL statement failed', {
          statement: trimmed.substring(0, 100),
          error: sqlError.message
        });
        throw new Error(`Rollback SQL Error in migration ${migration.version}: ${sqlError.message}`);
      }
    }

    return { rowCount: totalRowsAffected } as QueryResult;
  }

  private splitSQLStatements(script: string): string[] {
    // Reuse the same logic as MigrationRunner
    const statements: string[] = [];
    let current = '';
    let inString = false;
    let stringDelimiter = '';
    let inComment = false;
    let inBlockComment = false;

    for (let i = 0; i < script.length; i++) {
      const char = script[i];
      const nextChar = script[i + 1];

      if (!inString && !inBlockComment) {
        if (char === '-' && nextChar === '-') {
          inComment = true;
          i++;
          continue;
        }
        if (char === '/' && nextChar === '*') {
          inBlockComment = true;
          i++;
          continue;
        }
      }

      if (inComment) {
        if (char === '\n') {
          inComment = false;
        }
        continue;
      }

      if (inBlockComment) {
        if (char === '*' && nextChar === '/') {
          inBlockComment = false;
          i++;
        }
        continue;
      }

      if ((char === "'" || char === '"') && !inString) {
        inString = true;
        stringDelimiter = char;
      } else if (char === stringDelimiter && inString) {
        if (script[i - 1] !== '\\') {
          inString = false;
          stringDelimiter = '';
        }
      }

      if (char === ';' && !inString) {
        if (current.trim()) {
          statements.push(current.trim());
        }
        current = '';
      } else {
        current += char;
      }
    }

    if (current.trim()) {
      statements.push(current.trim());
    }

    return statements.filter(s => s.length > 0);
  }

  private async acquireRollbackLock(client: PoolClient): Promise<boolean> {
    try {
      const result = await client.query(
        'SELECT pg_try_advisory_lock($1) as acquired',
        [this.hashLockKey(this.ROLLBACK_LOCK_KEY)]
      );
      return result.rows[0]?.acquired || false;
    } catch (error) {
      this.logger.error('Error acquiring rollback lock', { error });
      return false;
    }
  }

  private async releaseRollbackLock(client: PoolClient): Promise<void> {
    try {
      await client.query(
        'SELECT pg_advisory_unlock($1)',
        [this.hashLockKey(this.ROLLBACK_LOCK_KEY)]
      );
    } catch (error) {
      this.logger.error('Error releasing rollback lock', { error });
    }
  }

  private async hasBackup(migrationVersion: string): Promise<boolean> {
    try {
      const result = await this.pool.query(
        'SELECT COUNT(*) as count FROM migration_backups WHERE migration_version = $1',
        [migrationVersion]
      );
      return parseInt(result.rows[0]?.count || '0') > 0;
    } catch (error) {
      this.logger.error('Error checking backup existence', { error });
      return false;
    }
  }

  private async getBackup(backupId: string): Promise<MigrationBackup | null> {
    try {
      const result = await this.pool.query(
        'SELECT * FROM migration_backups WHERE id = $1',
        [backupId]
      );
      return result.rows[0] || null;
    } catch (error) {
      this.logger.error('Error retrieving backup', { error });
      return null;
    }
  }

  private async storeBackup(client: PoolClient, backup: MigrationBackup): Promise<void> {
    await client.query(
      'INSERT INTO migration_backups (id, migration_version, created_at, size, checksum) VALUES ($1, $2, $3, $4, $5)',
      [backup.id, backup.migrationVersion, backup.createdAt, backup.size, backup.checksum]
    );
  }

  private async checkForeignKeyDependencies(tables: string[]): Promise<string[]> {
    try {
      const result = await this.pool.query(`
        SELECT DISTINCT 
          tc.constraint_name, 
          tc.table_name, 
          kcu.column_name, 
          ccu.table_name AS foreign_table_name,
          ccu.column_name AS foreign_column_name 
        FROM information_schema.table_constraints AS tc 
        JOIN information_schema.key_column_usage AS kcu
          ON tc.constraint_name = kcu.constraint_name
          AND tc.table_schema = kcu.table_schema
        JOIN information_schema.constraint_column_usage AS ccu
          ON ccu.constraint_name = tc.constraint_name
          AND ccu.table_schema = tc.table_schema
        WHERE tc.constraint_type = 'FOREIGN KEY' 
          AND (tc.table_name = ANY($1) OR ccu.table_name = ANY($1))
      `, [tables]);
      
      return result.rows.map(row => 
        `${row.table_name}.${row.constraint_name} -> ${row.foreign_table_name}.${row.foreign_column_name}`
      );
    } catch (error) {
      this.logger.error('Error checking foreign key dependencies', { error });
      return [];
    }
  }

  private async checkActiveConnections(migrationVersion: string): Promise<number> {
    try {
      const result = await this.pool.query(`
        SELECT COUNT(*) as count 
        FROM pg_stat_activity 
        WHERE state = 'active' 
          AND query LIKE '%' || $1 || '%'
          AND pid != pg_backend_pid()
      `, [migrationVersion]);
      
      return parseInt(result.rows[0]?.count || '0');
    } catch (error) {
      this.logger.error('Error checking active connections', { error });
      return 0;
    }
  }

  private compareVersions(a: string, b: string): number {
    return parseInt(a) - parseInt(b);
  }

  private hashLockKey(key: string): number {
    let hash = 0;
    for (let i = 0; i < key.length; i++) {
      const char = key.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash);
  }

  // Helper methods that would be implemented based on specific needs
  private async getCurrentState(): Promise<MigrationState> {
    const result = await this.pool.query('SELECT * FROM migration_history ORDER BY applied_at DESC LIMIT 1');
    return result.rows[0] || {
      currentVersion: '0',
      appliedMigrations: [],
      lastUpdated: new Date()
    };
  }

  private async loadMigration(version: string): Promise<Migration | null> {
    // Load migration from file or database
    // Implementation depends on your migration storage approach
    return null;
  }

  private async updateMigrationHistory(client: PoolClient, state: MigrationState): Promise<void> {
    await client.query(`
      INSERT INTO migration_history (current_version, applied_migrations, last_updated)
      VALUES ($1, $2, $3)
    `, [state.currentVersion, JSON.stringify(state.appliedMigrations), state.lastUpdated]);
  }

  private async applyBackup(client: PoolClient, backup: any, targetState?: MigrationState): Promise<void> {
    // Implement backup restoration logic
    // This is a placeholder that would contain the actual backup restoration code
  }
}

// Types
interface MigrationState {
  currentVersion: string;
  appliedMigrations: string[];
  lastUpdated: Date;
}

interface MigrationBackup {
  id: string;
  migrationVersion: string;
  createdAt: Date;
  size: number;
  checksum: string;
}