import { Pool, PoolClient } from 'pg';
import { MigrationHistory } from './migration-history.js';
import { MigrationRunner } from './migration-runner.js';
import { MigrationValidator } from './migration-validator.js';
import { MigrationRollback } from './migration-rollback.js';
import winston from 'winston';

/**
 * MigrationManager - Central coordinator for database migration operations
 * 
 * Features:
 * - Manages migration execution order with dependency tracking
 * - Coordinates between validator, runner, and rollback components
 * - Provides comprehensive logging and error handling
 * - Supports both forward and backward migrations
 */
export class MigrationManager {
  private history: MigrationHistory;
  private runner: MigrationRunner;
  private validator: MigrationValidator;
  private rollback: MigrationRollback;
  private logger: winston.Logger;

  constructor(
    private pool: Pool,
    private logger?: winston.Logger
  ) {
    this.logger = logger || this.createDefaultLogger();
    this.history = new MigrationHistory(pool, this.logger);
    this.runner = new MigrationRunner(pool, this.logger);
    this.validator = new MigrationValidator(pool, this.logger);
    this.rollback = new MigrationRollback(pool, this.logger);
  }

  private createDefaultLogger(): winston.Logger {
    return winston.createLogger({
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.printf(({ timestamp, level, message, ...meta }) => {
          return `${timestamp} [MigrationManager] ${level}: ${message} ${Object.keys(meta).length ? JSON.stringify(meta) : ''}`;
        })
      ),
      transports: [
        new winston.transports.Console(),
        new winston.transports.File({ filename: 'migration-manager.log' })
      ]
    });
  }

  /**
   * Execute migrations up to a specific version or all pending migrations
   */
  async migrate(targetVersion?: string, options?: {
    validate?: boolean;
    dryRun?: boolean;
    dependencies?: string[];
  }): Promise<{
    success: boolean;
    executedMigrations: string[];
    failedMigration?: string;
    error?: Error;
  }> {
    const { validate = true, dryRun = false, dependencies = [] } = options || {};
    
    try {
      this.logger.info('Starting migration process', { targetVersion, validate, dryRun, dependencies });

      // Get current migration state
      const currentState = await this.history.getCurrentState();
      this.logger.info('Current migration state', { currentState });

      // Get pending migrations with dependency resolution
      const pendingMigrations = await this.getPendingMigrations(targetVersion, dependencies);
      
      if (pendingMigrations.length === 0) {
        this.logger.info('No pending migrations found');
        return { success: true, executedMigrations: [] };
      }

      this.logger.info(`Found ${pendingMigrations.length} pending migrations`, { 
        migrations: pendingMigrations.map(m => m.version) 
      });

      // Validate migrations if requested
      if (validate) {
        const validationResults = await Promise.all(
          pendingMigrations.map(migration => this.validator.validateMigration(migration))
        );
        
        const failedValidations = validationResults.filter(r => !r.valid);
        if (failedValidations.length > 0) {
          const errors = failedValidations.map(r => r.errors).flat();
          throw new Error(`Migration validation failed: ${errors.join(', ')}`);
        }
        this.logger.info('Migration validation completed successfully');
      }

      // Execute migrations
      const client = await this.pool.connect();
      try {
        await client.query('BEGIN');
        
        const executedMigrations: string[] = [];
        let failedMigration: string | undefined;
        let lastError: Error | undefined;

        for (const migration of pendingMigrations) {
          try {
            if (dryRun) {
              this.logger.info(`[DRY RUN] Would execute migration: ${migration.version}`, {
                description: migration.description,
                dependencies: migration.dependencies,
                estimatedDuration: migration.estimatedDuration
              });
            } else {
              await this.runner.executeMigration(client, migration);
              await this.history.recordMigrationStart(migration.version, migration.description);
            }
            
            executedMigrations.push(migration.version);
            this.logger.info(`Migration ${migration.version} completed successfully`);
            
          } catch (error) {
            failedMigration = migration.version;
            lastError = error as Error;
            this.logger.error(`Migration ${migration.version} failed`, { error });
            
            if (!dryRun) {
              await this.rollback.rollbackToPreviousState(client, currentState);
            }
            break;
          }
        }

        if (dryRun || !failedMigration) {
          await client.query('COMMIT');
          if (!dryRun) {
            await this.history.recordMigrationBatch(executedMigrations);
          }
          this.logger.info('Migration process completed successfully', { executedMigrations });
        } else {
          await client.query('ROLLBACK');
          this.logger.error('Migration process failed and rolled back', { failedMigration });
        }

        return {
          success: !failedMigration,
          executedMigrations,
          failedMigration,
          error: lastError
        };

      } finally {
        client.release();
      }

    } catch (error) {
      this.logger.error('Migration process failed', { error });
      return {
        success: false,
        executedMigrations: [],
        error: error as Error
      };
    }
  }

  /**
   * Rollback migrations to a specific version
   */
  async rollbackTo(targetVersion: string, options?: {
    validate?: boolean;
    dryRun?: boolean;
  }): Promise<{
    success: boolean;
    rolledBackMigrations: string[];
    error?: Error;
  }> {
    const { validate = true, dryRun = false } = options || {};
    
    try {
      this.logger.info('Starting rollback process', { targetVersion, validate, dryRun });

      const currentState = await this.history.getCurrentState();
      
      if (currentState.appliedMigrations.includes(targetVersion)) {
        throw new Error(`Cannot rollback to ${targetVersion}: migration is currently applied`);
      }

      // Get migrations to rollback
      const migrationsToRollback = await this.history.getMigrationsToRollback(targetVersion);
      
      if (migrationsToRollback.length === 0) {
        this.logger.info('No migrations to rollback');
        return { success: true, rolledBackMigrations: [] };
      }

      this.logger.info(`Found ${migrationsToRollback.length} migrations to rollback`);

      if (validate) {
        const validationResults = await Promise.all(
          migrationsToRollback.map(migration => this.validator.validateRollback(migration))
        );
        
        const failedValidations = validationResults.filter(r => !r.valid);
        if (failedValidations.length > 0) {
          const errors = failedValidations.map(r => r.errors).flat();
          throw new Error(`Rollback validation failed: ${errors.join(', ')}`);
        }
        this.logger.info('Rollback validation completed successfully');
      }

      const rolledBackMigrations: string[] = [];
      
      for (const migration of migrationsToRollback.reverse()) {
        try {
          if (dryRun) {
            this.logger.info(`[DRY RUN] Would rollback migration: ${migration.version}`);
          } else {
            await this.rollback.rollbackMigration(migration);
            rolledBackMigrations.push(migration.version);
          }
          this.logger.info(`Migration ${migration.version} rolled back successfully`);
          
        } catch (error) {
          this.logger.error(`Rollback of migration ${migration.version} failed`, { error });
          return {
            success: false,
            rolledBackMigrations,
            error: error as Error
          };
        }
      }

      return {
        success: true,
        rolledBackMigrations: rolledBackMigrations.reverse()
      };

    } catch (error) {
      this.logger.error('Rollback process failed', { error });
      return {
        success: false,
        rolledBackMigrations: [],
        error: error as Error
      };
    }
  }

  /**
   * Get status of all migrations
   */
  async getStatus(): Promise<{
    currentVersion: string;
    appliedMigrations: string[];
    pendingMigrations: string[];
    failedMigrations: string[];
    totalMigrations: number;
  }> {
    const state = await this.history.getCurrentState();
    const allMigrations = await this.discoverMigrations();
    
    const pendingMigrations = allMigrations
      .filter(m => !state.appliedMigrations.includes(m.version))
      .map(m => m.version);

    const failedMigrations = state.failedMigrations || [];

    return {
      currentVersion: state.currentVersion,
      appliedMigrations: state.appliedMigrations,
      pendingMigrations,
      failedMigrations,
      totalMigrations: allMigrations.length
    };
  }

  /**
   * Force set migration state (use with caution)
   */
  async forceSetState(version: string, appliedMigrations: string[], client?: PoolClient): Promise<void> {
    const usedClient = client || await this.pool.connect();
    try {
      if (!client) {
        await usedClient.query('BEGIN');
      }

      await this.history.forceUpdateState(usedClient, {
        currentVersion: version,
        appliedMigrations,
        lastUpdated: new Date()
      });

      if (!client) {
        await usedClient.query('COMMIT');
      }
      
      this.logger.info('Migration state force updated', { version, appliedMigrations });
      
    } catch (error) {
      if (!client) {
        await usedClient.query('ROLLBACK');
      }
      throw error;
    } finally {
      if (!client) {
        usedClient.release();
      }
    }
  }

  private async getPendingMigrations(targetVersion?: string, dependencies: string[] = []): Promise<Migration[]> {
    const allMigrations = await this.discoverMigrations();
    const currentState = await this.history.getCurrentState();
    
    let pending = allMigrations.filter(m => 
      !currentState.appliedMigrations.includes(m.version)
    );

    // Filter by target version if specified
    if (targetVersion) {
      const targetIndex = pending.findIndex(m => m.version === targetVersion);
      if (targetIndex === -1) {
        throw new Error(`Target version ${targetVersion} not found or already applied`);
      }
      pending = pending.slice(0, targetIndex + 1);
    }

    // Apply dependency filtering
    if (dependencies.length > 0) {
      pending = pending.filter(m => 
        m.dependencies.some(dep => dependencies.includes(dep)) || 
        m.dependencies.length === 0
      );
    }

    // Sort by dependencies
    return this.resolveDependencies(pending);
  }

  private async discoverMigrations(): Promise<Migration[]> {
    const migrationFiles = await this.getMigrationFiles();
    const migrations: Migration[] = [];

    for (const file of migrationFiles) {
      const migration = await this.loadMigrationFromFile(file);
      if (migration) {
        migrations.push(migration);
      }
    }

    return migrations.sort((a, b) => this.compareVersions(a.version, b.version));
  }

  private async getMigrationFiles(): Promise<string[]> {
    // This would scan the migrations directory for migration files
    // Implementation depends on your file structure
    return [
      '001_initial_schema.sql',
      '002_add_users_table.sql',
      '003_add_audit_logs.sql'
      // etc...
    ];
  }

  private async loadMigrationFromFile(file: string): Promise<Migration | null> {
    // Load migration metadata and scripts from file
    // This is a simplified implementation
    const match = file.match(/^(\d+)_(.+)\.sql$/);
    if (!match) return null;

    const [, version, description] = match;
    const upScript = `-- UP migration for ${file}`;
    const downScript = `-- DOWN migration for ${file}`;

    return {
      version,
      description: description.replace(/_/g, ' '),
      dependencies: [],
      estimatedDuration: 1000, // ms
      upScript,
      downScript,
      checksum: ''
    };
  }

  private resolveDependencies(migrations: Migration[]): Migration[] {
    // Topological sort based on dependencies
    const visited = new Set<string>();
    const result: Migration[] = [];

    const visit = (migration: Migration) => {
      if (visited.has(migration.version)) return;

      // Visit dependencies first
      for (const dep of migration.dependencies) {
        const depMigration = migrations.find(m => m.version === dep);
        if (depMigration) {
          visit(depMigration);
        }
      }

      visited.add(migration.version);
      result.push(migration);
    };

    migrations.forEach(visit);
    return result;
  }

  private compareVersions(a: string, b: string): number {
    // Simple version comparison - can be enhanced for complex version schemes
    return parseInt(a) - parseInt(b);
  }
}

// Migration interface and types
export interface Migration {
  version: string;
  description: string;
  dependencies: string[];
  estimatedDuration: number; // in milliseconds
  upScript: string;
  downScript: string;
  checksum: string;
}

export interface MigrationResult {
  success: boolean;
  migration: Migration;
  duration: number;
  error?: Error;
  rollbackPerformed?: boolean;
}