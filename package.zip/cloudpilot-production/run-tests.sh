#!/bin/bash

# CloudPilot Production Test Runner
# Comprehensive test execution script for the Jest testing framework

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Test environment setup
export NODE_ENV=test
export JEST_WORKER_ID=1
export DEBUG_TESTS=false

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if Jest is installed
check_dependencies() {
    print_status "Checking test dependencies..."
    
    if ! command -v npm &> /dev/null; then
        print_error "npm is not installed"
        exit 1
    fi
    
    if [ ! -f "jest.config.js" ]; then
        print_error "jest.config.js not found"
        exit 1
    fi
    
    if [ ! -f "tests/setup/setup.ts" ]; then
        print_error "Test setup files not found"
        exit 1
    fi
    
    print_success "Dependencies check passed"
}

# Function to run Jest with options
run_jest() {
    local test_type=$1
    local coverage=$2
    local watch=$3
    local additional_args="${@:4}"
    
    local jest_args="--config jest.config.js"
    
    # Add test type specific args
    case $test_type in
        "unit")
            jest_args="$jest_args --testPathPattern=tests/unit"
            ;;
        "integration")
            jest_args="$jest_args --testPathPattern=tests/integration"
            ;;
        "e2e")
            jest_args="$jest_args --testPathPattern=tests/e2e"
            ;;
        "all")
            # No specific pattern for all tests
            ;;
    esac
    
    # Add coverage flag
    if [ "$coverage" = "true" ]; then
        jest_args="$jest_args --coverage"
    fi
    
    # Add watch flag
    if [ "$watch" = "true" ]; then
        jest_args="$jest_args --watch"
    fi
    
    # Add additional arguments
    jest_args="$jest_args $additional_args"
    
    print_status "Running: npm test -- $jest_args"
    npm test -- $jest_args
}

# Function to clean test cache
clean_cache() {
    print_status "Cleaning Jest cache..."
    npm run test:clear
    print_success "Cache cleaned"
}

# Function to show test statistics
show_stats() {
    print_status "Jest version: $(npm run jest:info 2>/dev/null | head -n 1)"
    print_status "Node version: $(node --version)"
    print_status "NPM version: $(npm --version)"
}

# Main function
main() {
    local command=$1
    local test_type=$2
    local coverage=false
    local watch=false
    local additional_args=""
    
    # Parse arguments
    shift
    while [[ $# -gt 0 ]]; do
        case $1 in
            --coverage)
                coverage=true
                shift
                ;;
            --watch)
                watch=true
                shift
                ;;
            --verbose)
                additional_args="$additional_args --verbose"
                shift
                ;;
            --silent)
                additional_args="$additional_args --silent"
                shift
                ;;
            --passWithNoTests)
                additional_args="$additional_args --passWithNoTests"
                shift
                ;;
            --runInBand)
                additional_args="$additional_args --runInBand"
                shift
                ;;
            --detectOpenHandles)
                additional_args="$additional_args --detectOpenHandles"
                shift
                ;;
            --forceExit)
                additional_args="$additional_args --forceExit"
                shift
                ;;
            --maxWorkers=*)
                additional_args="$additional_args $1"
                shift
                ;;
            *)
                additional_args="$additional_args $1"
                shift
                ;;
        esac
    done
    
    case $command in
        "install")
            print_status "Installing test dependencies..."
            npm install
            print_success "Dependencies installed"
            ;;
        "check")
            check_dependencies
            ;;
        "unit")
            check_dependencies
            print_status "Running unit tests..."
            run_jest "unit" "$coverage" "$watch" "$additional_args"
            ;;
        "integration")
            check_dependencies
            print_status "Running integration tests..."
            run_jest "integration" "$coverage" "$watch" "$additional_args"
            ;;
        "e2e")
            check_dependencies
            print_status "Running E2E tests..."
            run_jest "e2e" "$coverage" "$watch" "$additional_args"
            ;;
        "all")
            check_dependencies
            print_status "Running all tests..."
            run_jest "all" "$coverage" "$watch" "$additional_args"
            ;;
        "coverage")
            check_dependencies
            print_status "Running tests with coverage..."
            run_jest "$test_type" "true" "$watch" "$additional_args"
            ;;
        "watch")
            check_dependencies
            if [ -z "$test_type" ]; then
                print_status "Starting Jest in watch mode..."
                run_jest "all" "false" "true" "$additional_args"
            else
                print_status "Starting Jest in watch mode for $test_type tests..."
                run_jest "$test_type" "false" "true" "$additional_args"
            fi
            ;;
        "clean")
            clean_cache
            ;;
        "stats")
            show_stats
            ;;
        "debug")
            check_dependencies
            print_status "Running tests in debug mode..."
            npm run test:debug
            ;;
        "ci")
            check_dependencies
            print_status "Running CI tests..."
            npm run test:ci
            ;;
        "help")
            echo "CloudPilot Production Test Runner"
            echo ""
            echo "Usage: ./run-tests.sh [command] [test-type] [options]"
            echo ""
            echo "Commands:"
            echo "  install     - Install test dependencies"
            echo "  check       - Check test setup and dependencies"
            echo "  unit        - Run unit tests"
            echo "  integration - Run integration tests"
            echo "  e2e         - Run E2E tests"
            echo "  all         - Run all tests"
            echo "  coverage    - Run tests with coverage"
            echo "  watch       - Run tests in watch mode"
            echo "  clean       - Clean Jest cache"
            echo "  stats       - Show test environment statistics"
            echo "  debug       - Run tests in debug mode"
            echo "  ci          - Run CI-compatible tests"
            echo "  help        - Show this help message"
            echo ""
            echo "Test Types:"
            echo "  all         - All test types"
            echo "  unit        - Unit tests only"
            echo "  integration - Integration tests only"
            echo "  e2e         - E2E tests only"
            echo ""
            echo "Options:"
            echo "  --coverage        - Generate coverage report"
            echo "  --watch           - Run in watch mode"
            echo "  --verbose         - Verbose output"
            echo "  --silent          - Silent output"
            echo "  --runInBand       - Run tests serially"
            echo "  --detectOpenHandles - Detect open handles"
            echo "  --forceExit       - Force exit after tests"
            echo "  --maxWorkers=<N>  - Number of worker processes"
            echo ""
            echo "Examples:"
            echo "  ./run-tests.sh unit unit --coverage"
            echo "  ./run-tests.sh integration integration --verbose"
            echo "  ./run-tests.sh watch unit"
            echo "  ./run-tests.sh coverage all"
            ;;
        *)
            print_error "Unknown command: $command"
            echo "Use './run-tests.sh help' for usage information"
            exit 1
            ;;
    esac
}

# Check if script is being run directly
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi
