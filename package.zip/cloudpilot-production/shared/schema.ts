import { sql } from "drizzle-orm";
import { pgTable, text, varchar, json, timestamp, boolean, integer, index, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").notNull().unique(),
  passwordHash: varchar("password_hash").notNull(),
  fullName: varchar("full_name").notNull(),
  role: text("role").notNull().$type<'admin' | 'user'>(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const refreshTokens = pgTable("refresh_tokens", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  token: text("token").notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const awsAccounts = pgTable("aws_accounts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  accessKeyId: text("access_key_id").notNull(),
  secretAccessKey: text("secret_access_key").notNull(),
  isActive: boolean("is_active").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const ec2Instances = pgTable("ec2_instances", {
  id: varchar("id").primaryKey(),
  instanceId: text("instance_id").notNull(),
  name: text("name"),
  region: text("region").notNull(),
  state: text("state").notNull(),
  instanceType: text("instance_type").notNull(),
  publicIpAddress: text("public_ip_address"),
  privateIpAddress: text("private_ip_address"),
  elasticIpAddress: text("elastic_ip_address"),
  trafficInbound: text("traffic_inbound"), // Mock values like "1.2 GB"
  trafficOutbound: text("traffic_outbound"), // Mock values like "456 MB"
  launchTime: timestamp("launch_time"),
  platformDetails: text("platform_details"),
  availabilityZone: text("availability_zone"),
  monitoring: text("monitoring"),
  volumes: json("volumes").$type<any[]>(),
  networkInterfaces: json("network_interfaces").$type<any[]>(),
  securityGroups: json("security_groups").$type<any[]>(),
  tags: json("tags").$type<Record<string, string>>(),
  accountId: varchar("account_id").references(() => awsAccounts.id),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const insertAwsAccountSchema = createInsertSchema(awsAccounts).pick({
  name: true,
  accessKeyId: true,
  secretAccessKey: true,
});

// User validation schemas
export const createUserSchema = z.object({
  email: z.string().email("Invalid email address"),
  passwordHash: z.string().min(1, "Password hash is required"),
  fullName: z.string().min(1, "Full name is required"),
  role: z.enum(['admin', 'user']),
  isActive: z.boolean().default(true),
});

export const updateUserSchema = z.object({
  email: z.string().email("Invalid email address").optional(),
  passwordHash: z.string().min(1, "Password hash is required").optional(),
  fullName: z.string().min(1, "Full name is required").optional(),
  role: z.enum(['admin', 'user']).optional(),
  isActive: z.boolean().optional(),
  updatedAt: z.date().optional(),
});

// Auth validation schemas
export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export const registerSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  fullName: z.string().min(1, "Full name is required"),
});

export const refreshTokenSchema = z.object({
  refreshToken: z.string().min(1, "Refresh token is required"),
});

export const s3Buckets = pgTable("s3_buckets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  region: text("region").notNull(),
  creationDate: timestamp("creation_date"),
  accountId: varchar("account_id").references(() => awsAccounts.id),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const rdsInstances = pgTable("rds_instances", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  dbInstanceIdentifier: text("db_instance_identifier").notNull(),
  region: text("region").notNull(),
  dbInstanceClass: text("db_instance_class").notNull(),
  engine: text("engine").notNull(),
  engineVersion: text("engine_version"),
  dbInstanceStatus: text("db_instance_status").notNull(),
  masterUsername: text("master_username"),
  endpoint: text("endpoint"),
  port: text("port"),
  availabilityZone: text("availability_zone"),
  allocatedStorage: text("allocated_storage"),
  storageType: text("storage_type"),
  storageEncrypted: boolean("storage_encrypted"),
  vpcSecurityGroups: json("vpc_security_groups").$type<string[]>(),
  dbSubnetGroupName: text("db_subnet_group_name"),
  multiAz: boolean("multi_az"),
  publiclyAccessible: boolean("publicly_accessible"),
  instanceCreateTime: timestamp("instance_create_time"),
  accountId: varchar("account_id").references(() => awsAccounts.id),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const cloudFrontDistributions = pgTable("cloudfront_distributions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  distributionId: text("distribution_id").notNull(),
  arn: text("arn"),
  status: text("status").notNull(),
  domainName: text("domain_name").notNull(),
  enabled: boolean("enabled").notNull(),
  comment: text("comment"),
  origins: json("origins").$type<any[]>(),
  defaultRootObject: text("default_root_object"),
  customErrorResponses: json("custom_error_responses").$type<any[]>(),
  lastModifiedTime: timestamp("last_modified_time"),
  priceClass: text("price_class"),
  webAclId: text("web_acl_id"),
  httpVersion: text("http_version"),
  isIPV6Enabled: boolean("is_ipv6_enabled"),
  distributionConfig: json("distribution_config").$type<any>(),
  accountId: varchar("account_id").references(() => awsAccounts.id),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const instanceTemplates = pgTable("instance_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  region: text("region").notNull(),
  instanceType: text("instance_type").notNull(),
  imageId: text("image_id").notNull(),
  keyName: text("key_name"),
  password: text("password"),
  diskSize: integer("disk_size").default(20),
  amount: integer("amount").default(1),
  userData: text("user_data"),
  instanceName: text("instance_name"),
  isSpotInstance: boolean("is_spot_instance").default(false),
  spotMaxPrice: text("spot_max_price"),
  enableIpv6: boolean("enable_ipv6").default(false),
  enableWavelength: boolean("enable_wavelength").default(false),
  authMode: text("auth_mode").default("key"),
  securityGroups: json("security_groups").$type<string[]>(),
  subnetId: text("subnet_id"),
  publicIpAddress: boolean("public_ip_address").default(true),
  ebsOptimized: boolean("ebs_optimized").default(false),
  monitoring: boolean("monitoring").default(false),
  tags: json("tags").$type<Record<string, string>>(),
  accountId: varchar("account_id").references(() => awsAccounts.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Audit trail tables
export const auditLogs = pgTable("audit_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: 'set null' }),
  action: text("action").notNull(),
  resourceType: text("resource_type").notNull(),
  resourceId: varchar("resource_id"),
  details: json("details").$type<Record<string, any>>(),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  timestamp: timestamp("timestamp").defaultNow(),
  success: boolean("success").notNull().default(true),
  errorMessage: text("error_message"),
}, (table) => ({
  userIdIdx: index("idx_audit_logs_user_id").on(table.userId),
  actionIdx: index("idx_audit_logs_action").on(table.action),
  resourceIdx: index("idx_audit_logs_resource").on(table.resourceType, table.resourceId),
  timestampIdx: index("idx_audit_logs_timestamp").on(table.timestamp),
  successIdx: index("idx_audit_logs_success").on(table.success),
}));

export const auditSessions = pgTable("audit_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  sessionId: text("session_id").notNull().unique(),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  loginTime: timestamp("login_time").defaultNow(),
  lastActivity: timestamp("last_activity").defaultNow(),
  logoutTime: timestamp("logout_time"),
  isActive: boolean("is_active").default(true),
  metadata: json("metadata").$type<Record<string, any>>(),
}, (table) => ({
  userIdIdx: index("idx_audit_sessions_user_id").on(table.userId),
  sessionIdIdx: index("idx_audit_sessions_session_id").on(table.sessionId),
  lastActivityIdx: index("idx_audit_sessions_last_activity").on(table.lastActivity),
  isActiveIdx: index("idx_audit_sessions_is_active").on(table.isActive),
}));

export const auditEvents = pgTable("audit_events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: 'set null' }),
  sessionId: varchar("session_id").references(() => auditSessions.id, { onDelete: 'set null' }),
  eventType: text("event_type").notNull(),
  eventCategory: text("event_category").notNull(),
  description: text("description").notNull(),
  severity: text("severity").notNull().$type<'info' | 'warning' | 'error' | 'critical'>().default('info'),
  resourceType: text("resource_type"),
  resourceId: varchar("resource_id"),
  oldValues: json("old_values").$type<Record<string, any>>(),
  newValues: json("new_values").$type<Record<string, any>>(),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  timestamp: timestamp("timestamp").defaultNow(),
  metadata: json("metadata").$type<Record<string, any>>(),
}, (table) => ({
  userIdIdx: index("idx_audit_events_user_id").on(table.userId),
  sessionIdIdx: index("idx_audit_events_session_id").on(table.sessionId),
  eventTypeIdx: index("idx_audit_events_event_type").on(table.eventType),
  eventCategoryIdx: index("idx_audit_events_event_category").on(table.eventCategory),
  resourceIdx: index("idx_audit_events_resource").on(table.resourceType, table.resourceId),
  timestampIdx: index("idx_audit_events_timestamp").on(table.timestamp),
  severityIdx: index("idx_audit_events_severity").on(table.severity),
}));

export const insertEc2InstanceSchema = createInsertSchema(ec2Instances).omit({
  id: true,
  lastUpdated: true,
});

export const insertS3BucketSchema = createInsertSchema(s3Buckets).omit({
  id: true,
  lastUpdated: true,
});

export const insertRdsInstanceSchema = createInsertSchema(rdsInstances).omit({
  id: true,
  lastUpdated: true,
});

export const insertCloudFrontDistributionSchema = createInsertSchema(cloudFrontDistributions).omit({
  id: true,
  lastUpdated: true,
});

export const insertInstanceTemplateSchema = createInsertSchema(instanceTemplates).omit({
  id: true,
  createdAt: true,
});

// Audit trail validation schemas
export const createAuditLogSchema = z.object({
  userId: z.string().uuid().optional(),
  action: z.string().min(1, "Action is required"),
  resourceType: z.string().min(1, "Resource type is required"),
  resourceId: z.string().optional(),
  details: z.record(z.any()).optional(),
  ipAddress: z.string().optional(),
  userAgent: z.string().optional(),
  success: z.boolean().default(true),
  errorMessage: z.string().optional(),
});

export const updateAuditLogSchema = z.object({
  userId: z.string().uuid().optional(),
  action: z.string().min(1, "Action is required").optional(),
  resourceType: z.string().min(1, "Resource type is required").optional(),
  resourceId: z.string().optional(),
  details: z.record(z.any()).optional(),
  ipAddress: z.string().optional(),
  userAgent: z.string().optional(),
  success: z.boolean().optional(),
  errorMessage: z.string().optional(),
});

export const createAuditSessionSchema = z.object({
  userId: z.string().uuid(),
  sessionId: z.string().min(1, "Session ID is required"),
  ipAddress: z.string().optional(),
  userAgent: z.string().optional(),
  metadata: z.record(z.any()).optional(),
});

export const updateAuditSessionSchema = z.object({
  ipAddress: z.string().optional(),
  userAgent: z.string().optional(),
  lastActivity: z.date().optional(),
  logoutTime: z.date().optional(),
  isActive: z.boolean().optional(),
  metadata: z.record(z.any()).optional(),
});

export const createAuditEventSchema = z.object({
  userId: z.string().uuid().optional(),
  sessionId: z.string().uuid().optional(),
  eventType: z.string().min(1, "Event type is required"),
  eventCategory: z.string().min(1, "Event category is required"),
  description: z.string().min(1, "Description is required"),
  severity: z.enum(['info', 'warning', 'error', 'critical']).default('info'),
  resourceType: z.string().optional(),
  resourceId: z.string().optional(),
  oldValues: z.record(z.any()).optional(),
  newValues: z.record(z.any()).optional(),
  ipAddress: z.string().optional(),
  userAgent: z.string().optional(),
  metadata: z.record(z.any()).optional(),
});

export const updateAuditEventSchema = z.object({
  userId: z.string().uuid().optional(),
  sessionId: z.string().uuid().optional(),
  eventType: z.string().min(1, "Event type is required").optional(),
  eventCategory: z.string().min(1, "Event category is required").optional(),
  description: z.string().min(1, "Description is required").optional(),
  severity: z.enum(['info', 'warning', 'error', 'critical']).optional(),
  resourceType: z.string().optional(),
  resourceId: z.string().optional(),
  oldValues: z.record(z.any()).optional(),
  newValues: z.record(z.any()).optional(),
  ipAddress: z.string().optional(),
  userAgent: z.string().optional(),
  metadata: z.record(z.any()).optional(),
});

export const launchInstanceSchema = z.object({
  region: z.string().min(1, "Region is required"),
  instanceType: z.string().min(1, "Instance type is required"),
  imageId: z.string().min(1, "Image ID is required"),
  keyName: z.string().optional(),
  password: z.string().optional(),
  diskSize: z.number().min(8).max(1000).default(20),
  amount: z.number().min(1).max(20).default(1),
  userData: z.string().optional(),
  instanceName: z.string().optional(),
  isSpotInstance: z.boolean().default(false),
  spotMaxPrice: z.string().optional(),
  enableIpv6: z.boolean().default(false),
  enableWavelength: z.boolean().default(false),
  authMode: z.enum(["key", "password"]).default("key"),
  securityGroups: z.array(z.string()).optional(),
  subnetId: z.string().optional(),
  publicIpAddress: z.boolean().default(true),
  ebsOptimized: z.boolean().default(false),
  monitoring: z.boolean().default(false),
  tags: z.record(z.string()).optional(),
});

export const createS3BucketSchema = z.object({
  bucketName: z.string().min(1, "Bucket name is required"),
  region: z.string().min(1, "Region is required"),
  accountId: z.string().min(1, "Account ID is required"),
});

export const createRdsInstanceSchema = z.object({
  dbInstanceIdentifier: z.string().min(1, "DB instance identifier is required"),
  dbInstanceClass: z.string().min(1, "DB instance class is required"),
  engine: z.string().min(1, "Engine is required"),
  engineVersion: z.string().optional(),
  masterUsername: z.string().min(1, "Master username is required"),
  masterUserPassword: z.string().min(8, "Password must be at least 8 characters"),
  allocatedStorage: z.number().min(20).max(65536).default(20),
  region: z.string().min(1, "Region is required"),
  accountId: z.string().min(1, "Account ID is required"),
  storageType: z.string().default("gp2"),
  storageEncrypted: z.boolean().default(false),
  vpcSecurityGroupIds: z.array(z.string()).optional(),
  dbSubnetGroupName: z.string().optional(),
  multiAz: z.boolean().default(false),
  publiclyAccessible: z.boolean().default(false),
});

export const createCloudFrontDistributionSchema = z.object({
  callerReference: z.string().min(1, "Caller reference is required"),
  comment: z.string().optional(),
  enabled: z.boolean().default(true),
  priceClass: z.string().default("PriceClass_All"),
  origins: z.array(z.object({
    id: z.string().min(1, "Origin ID is required"),
    domainName: z.string().min(1, "Domain name is required"),
    originPath: z.string().optional(),
    customOriginConfig: z.object({
      httpPort: z.number().default(80),
      httpsPort: z.number().default(443),
      originProtocolPolicy: z.string().default("https-only"),
      originSslProtocols: z.array(z.string()).default(["TLSv1.2"]),
    }).optional(),
  })).min(1, "At least one origin is required"),
  defaultRootObject: z.string().optional(),
  accountId: z.string().min(1, "Account ID is required"),
});

export type InsertAwsAccount = z.infer<typeof insertAwsAccountSchema>;
export type AwsAccount = typeof awsAccounts.$inferSelect;
export type InsertUser = z.infer<typeof createUserSchema>;
export type User = typeof users.$inferSelect;
export type UpdateUser = z.infer<typeof updateUserSchema>;
export type LoginRequest = z.infer<typeof loginSchema>;
export type RegisterRequest = z.infer<typeof registerSchema>;
export type RefreshTokenRequest = z.infer<typeof refreshTokenSchema>;
export type InsertEc2Instance = z.infer<typeof insertEc2InstanceSchema>;
export type Ec2Instance = typeof ec2Instances.$inferSelect;
export type InsertS3Bucket = z.infer<typeof insertS3BucketSchema>;
export type S3Bucket = typeof s3Buckets.$inferSelect;
export type InsertRdsInstance = z.infer<typeof insertRdsInstanceSchema>;
export type RdsInstance = typeof rdsInstances.$inferSelect;
export type InsertCloudFrontDistribution = z.infer<typeof insertCloudFrontDistributionSchema>;
export type CloudFrontDistribution = typeof cloudFrontDistributions.$inferSelect;
export type InsertInstanceTemplate = z.infer<typeof insertInstanceTemplateSchema>;
export type InstanceTemplate = typeof instanceTemplates.$inferSelect;
export type LaunchInstanceRequest = z.infer<typeof launchInstanceSchema>;
export type CreateS3BucketRequest = z.infer<typeof createS3BucketSchema>;
export type CreateRdsInstanceRequest = z.infer<typeof createRdsInstanceSchema>;
export type CreateCloudFrontDistributionRequest = z.infer<typeof createCloudFrontDistributionSchema>;

// Audit trail types
export type InsertAuditLog = z.infer<typeof createAuditLogSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;
export type UpdateAuditLog = z.infer<typeof updateAuditLogSchema>;
export type InsertAuditSession = z.infer<typeof createAuditSessionSchema>;
export type AuditSession = typeof auditSessions.$inferSelect;
export type UpdateAuditSession = z.infer<typeof updateAuditSessionSchema>;
export type InsertAuditEvent = z.infer<typeof createAuditEventSchema>;
export type AuditEvent = typeof auditEvents.$inferSelect;
export type UpdateAuditEvent = z.infer<typeof updateAuditEventSchema>;

// Safe DTO types that exclude sensitive credential fields for frontend consumption
export type SafeAwsAccount = Omit<AwsAccount, 'accessKeyId' | 'secretAccessKey'>;
