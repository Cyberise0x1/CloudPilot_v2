/**
 * General Test Utilities
 * Provides common test utilities, helpers, and utilities for test suites
 */

import { vi } from 'vitest';
import { Request, Response, NextFunction } from 'express';

// =============================================================================
// DATE/TIME UTILITIES
// =============================================================================

/**
 * Create a fixed date for testing
 */
export const createFixedDate = (date: Date | string | number) => {
  return new Date(date);
};

/**
 * Get current timestamp for testing
 */
export const getCurrentTimestamp = () => {
  return Math.floor(Date.now() / 1000);
};

/**
 * Create expired date
 */
export const createExpiredDate = (offset: number = -3600) => {
  const date = new Date();
  date.setSeconds(date.getSeconds() + offset);
  return date;
};

/**
 * Create future date
 */
export const createFutureDate = (offset: number = 3600) => {
  const date = new Date();
  date.setSeconds(date.getSeconds() + offset);
  return date;
};

/**
 * Format date for comparison
 */
export const formatDate = (date: Date, format: 'iso' | 'timestamp' | 'locale' = 'iso') => {
  switch (format) {
    case 'iso':
      return date.toISOString();
    case 'timestamp':
      return Math.floor(date.getTime() / 1000);
    case 'locale':
      return date.toLocaleString();
    default:
      return date.toISOString();
  }
};

// =============================================================================
// STRING UTILITIES
// =============================================================================

/**
 * Generate random string
 */
export const generateRandomString = (length: number = 10): string => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
};

/**
 * Generate random email
 */
export const generateRandomEmail = (domain: string = 'example.com'): string => {
  const username = generateRandomString(8).toLowerCase();
  return `${username}@${domain}`;
};

/**
 * Generate random UUID (simplified for testing)
 */
export const generateRandomUUID = (): string => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

/**
 * Sanitize string for comparison
 */
export const sanitizeString = (str: string): string => {
  return str.trim().replace(/\s+/g, ' ').toLowerCase();
};

/**
 * Create slug from string
 */
export const createSlug = (str: string): string => {
  return str
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
};

// =============================================================================
// NUMBER UTILITIES
// =============================================================================

/**
 * Generate random number
 */
export const generateRandomNumber = (min: number = 0, max: number = 100): number => {
  return Math.floor(Math.random() * (max - min + 1)) + min;
};

/**
 * Generate random float
 */
export const generateRandomFloat = (min: number = 0, max: number = 1): number => {
  return Math.random() * (max - min) + min;
};

/**
 * Clamp number between min and max
 */
export const clampNumber = (value: number, min: number, max: number): number => {
  return Math.min(Math.max(value, min), max);
};

/**
 * Format number with decimal places
 */
export const formatNumber = (value: number, decimals: number = 2): string => {
  return value.toFixed(decimals);
};

/**
 * Parse number safely
 */
export const safeParseNumber = (value: any, defaultValue: number = 0): number => {
  const parsed = parseFloat(value);
  return isNaN(parsed) ? defaultValue : parsed;
};

// =============================================================================
// ARRAY UTILITIES
// =============================================================================

/**
 * Generate random array
 */
export const generateRandomArray = <T>(length: number, generator: () => T): T[] => {
  return Array.from({ length }, generator);
};

/**
 * Shuffle array
 */
export const shuffleArray = <T>(array: T[]): T[] => {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
};

/**
 * Pick random element from array
 */
export const pickRandomElement = <T>(array: T[]): T => {
  return array[Math.floor(Math.random() * array.length)];
};

/**
 * Remove duplicates from array
 */
export const removeDuplicates = <T>(array: T[]): T[] => {
  return [...new Set(array)];
};

/**
 * Chunk array into smaller arrays
 */
export const chunkArray = <T>(array: T[], size: number): T[][] => {
  const chunks: T[][] = [];
  for (let i = 0; i < array.length; i += size) {
    chunks.push(array.slice(i, i + size));
  }
  return chunks;
};

// =============================================================================
// OBJECT UTILITIES
// =============================================================================

/**
 * Deep clone object
 */
export const deepClone = <T>(obj: T): T => {
  if (obj === null || typeof obj !== 'object') {
    return obj;
  }
  
  if (obj instanceof Date) {
    return new Date(obj.getTime()) as any;
  }
  
  if (obj instanceof Array) {
    return obj.map(item => deepClone(item)) as any;
  }
  
  if (typeof obj === 'object') {
    const clonedObj = {} as any;
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        clonedObj[key] = deepClone(obj[key]);
      }
    }
    return clonedObj;
  }
  
  return obj;
};

/**
 * Deep compare objects
 */
export const deepEqual = (obj1: any, obj2: any): boolean => {
  if (obj1 === obj2) {
    return true;
  }
  
  if (obj1 instanceof Date && obj2 instanceof Date) {
    return obj1.getTime() === obj2.getTime();
  }
  
  if (!obj1 || !obj2 || (typeof obj1 !== 'object' && typeof obj2 !== 'object')) {
    return obj1 === obj2;
  }
  
  if (obj1 === null || obj1 === undefined || obj2 === null || obj2 === undefined) {
    return false;
  }
  
  if (obj1.prototype !== obj2.prototype) {
    return false;
  }
  
  const keys1 = Object.keys(obj1);
  const keys2 = Object.keys(obj2);
  
  if (keys1.length !== keys2.length) {
    return false;
  }
  
  for (const key of keys1) {
    if (!keys2.includes(key)) {
      return false;
    }
    if (!deepEqual(obj1[key], obj2[key])) {
      return false;
    }
  }
  
  return true;
};

/**
 * Omit properties from object
 */
export const omit = <T, K extends keyof T>(obj: T, keys: K[]): Omit<T, K> => {
  const result = { ...obj };
  keys.forEach(key => delete result[key]);
  return result;
};

/**
 * Pick properties from object
 */
export const pick = <T, K extends keyof T>(obj: T, keys: K[]): Pick<T, K> => {
  const result = {} as Pick<T, K>;
  keys.forEach(key => {
    if (key in obj) {
      result[key] = obj[key];
    }
  });
  return result;
};

/**
 * Check if object is empty
 */
export const isEmpty = (obj: any): boolean => {
  if (obj == null) {
    return true;
  }
  
  if (Array.isArray(obj) || typeof obj === 'string') {
    return obj.length === 0;
  }
  
  if (typeof obj === 'object') {
    return Object.keys(obj).length === 0;
  }
  
  return false;
};

// =============================================================================
// VALIDATION UTILITIES
// =============================================================================

/**
 * Check if value is email
 */
export const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

/**
 * Check if value is URL
 */
export const isValidURL = (url: string): boolean => {
  try {
    new URL(url);
    return true;
  } catch {
    return false;
  }
};

/**
 * Check if value is UUID
 */
export const isValidUUID = (uuid: string): boolean => {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  return uuidRegex.test(uuid);
};

/**
 * Validate password strength
 */
export const validatePasswordStrength = (password: string): {
  isValid: boolean;
  score: number;
  feedback: string[];
} => {
  const feedback: string[] = [];
  let score = 0;
  
  if (password.length < 8) {
    feedback.push('Password must be at least 8 characters long');
  } else {
    score += 1;
  }
  
  if (!/[a-z]/.test(password)) {
    feedback.push('Password must contain at least one lowercase letter');
  } else {
    score += 1;
  }
  
  if (!/[A-Z]/.test(password)) {
    feedback.push('Password must contain at least one uppercase letter');
  } else {
    score += 1;
  }
  
  if (!/\d/.test(password)) {
    feedback.push('Password must contain at least one number');
  } else {
    score += 1;
  }
  
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
    feedback.push('Password must contain at least one special character');
  } else {
    score += 1;
  }
  
  return {
    isValid: score >= 4,
    score,
    feedback,
  };
};

// =============================================================================
// FILE UTILITIES
// =============================================================================

/**
 * Get file extension
 */
export const getFileExtension = (filename: string): string => {
  return filename.slice((filename.lastIndexOf('.') - 1 >>> 0) + 2);
};

/**
 * Check if file is image
 */
export const isImageFile = (filename: string): boolean => {
  const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg'];
  const extension = getFileExtension(filename).toLowerCase();
  return imageExtensions.includes(extension);
};

/**
 * Check if file is video
 */
export const isVideoFile = (filename: string): boolean => {
  const videoExtensions = ['mp4', 'avi', 'mov', 'wmv', 'flv', 'webm', 'mkv'];
  const extension = getFileExtension(filename).toLowerCase();
  return videoExtensions.includes(extension);
};

/**
 * Format file size
 */
export const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

// =============================================================================
// ASYNC UTILITIES
// =============================================================================

/**
 * Wait for specified time
 */
export const wait = (ms: number): Promise<void> => {
  return new Promise(resolve => setTimeout(resolve, ms));
};

/**
 * Retry function with exponential backoff
 */
export const retry = async <T>(
  fn: () => Promise<T>,
  maxAttempts: number = 3,
  delay: number = 1000
): Promise<T> => {
  let lastError: Error;
  
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error as Error;
      if (attempt === maxAttempts) {
        throw lastError;
      }
      await wait(delay * Math.pow(2, attempt - 1));
    }
  }
  
  throw lastError!;
};

/**
 * Timeout wrapper for promises
 */
export const withTimeout = <T>(
  promise: Promise<T>,
  timeoutMs: number,
  errorMessage: string = 'Operation timed out'
): Promise<T> => {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) => {
      setTimeout(() => reject(new Error(errorMessage)), timeoutMs);
    }),
  ]);
};

/**
 * Sleep helper for test delays
 */
export const sleep = (ms: number) => {
  return new Promise(resolve => setTimeout(resolve, ms));
};

// =============================================================================
// TEST ASSERTION HELPERS
// =============================================================================

/**
 * Assert response status
 */
export const expectResponseStatus = (res: Response, status: number) => {
  expect(res.status).toHaveBeenCalledWith(status);
};

/**
 * Assert response JSON
 */
export const expectResponseJSON = (res: Response, expectedData: any) => {
  expect(res.json).toHaveBeenCalledWith(expectedData);
};

/**
 * Assert response message
 */
export const expectResponseMessage = (res: Response, message: string) => {
  expect(res.json).toHaveBeenCalledWith(
    expect.objectContaining({ message })
  );
};

/**
 * Assert error response
 */
export const expectErrorResponse = (
  res: Response,
  status: number,
  message?: string
) => {
  expect(res.status).toHaveBeenCalledWith(status);
  
  if (message) {
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ message })
    );
  } else {
    expect(res.json).toHaveBeenCalledWith(
      expect.objectContaining({ error: expect.any(String) })
    );
  }
};

/**
 * Assert function was called
 */
export const expectFunctionCalled = (fn: Mock, times?: number) => {
  if (times !== undefined) {
    expect(fn).toHaveBeenCalledTimes(times);
  } else {
    expect(fn).toHaveBeenCalled();
  }
};

/**
 * Assert function was called with specific arguments
 */
export const expectFunctionCalledWith = (fn: Mock, ...args: any[]) => {
  expect(fn).toHaveBeenCalledWith(...args);
};

// =============================================================================
// TEST SETUP/TEARDOWN HELPERS
// =============================================================================

/**
 * Setup test environment
 */
export const setupTestEnvironment = () => {
  // Set test environment variables
  process.env.NODE_ENV = 'test';
  process.env.JWT_SECRET = 'test-secret-key';
  process.env.JWT_REFRESH_TOKEN_SECRET = 'test-refresh-secret';
  process.env.DATABASE_URL = 'postgresql://test:test@localhost:5432/test';
  
  // Mock console methods to reduce noise in tests
  vi.spyOn(console, 'log').mockImplementation(() => {});
  vi.spyOn(console, 'warn').mockImplementation(() => {});
  vi.spyOn(console, 'error').mockImplementation(() => {});
};

/**
 * Cleanup test environment
 */
export const cleanupTestEnvironment = () => {
  vi.restoreAllMocks();
  vi.clearAllTimers();
  vi.clearAllMocks();
};

/**
 * Create test timeout
 */
export const createTestTimeout = (ms: number = 5000) => {
  return setTimeout(() => {
    throw new Error('Test timed out');
  }, ms);
};

// =============================================================================
// PERFORMANCE UTILITIES
// =============================================================================

/**
 * Measure execution time
 */
export const measureExecutionTime = async <T>(
  fn: () => Promise<T> | T
): Promise<{ result: T; executionTime: number }> => {
  const start = performance.now();
  const result = await fn();
  const end = performance.now();
  
  return {
    result,
    executionTime: end - start,
  };
};

/**
 * Wait for condition to be true
 */
export const waitForCondition = async (
  condition: () => boolean,
  timeout: number = 5000,
  interval: number = 100
): Promise<void> => {
  const start = Date.now();
  
  while (!condition()) {
    if (Date.now() - start > timeout) {
      throw new Error('Condition not met within timeout');
    }
    await sleep(interval);
  }
};

/**
 * Retry until condition is met
 */
export const retryUntil = async <T>(
  fn: () => Promise<T>,
  condition: (result: T) => boolean,
  maxAttempts: number = 10,
  delay: number = 1000
): Promise<T> => {
  let lastError: Error;
  
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const result = await fn();
      if (condition(result)) {
        return result;
      }
    } catch (error) {
      lastError = error as Error;
    }
    
    if (attempt < maxAttempts) {
      await sleep(delay);
    }
  }
  
  throw lastError || new Error('Condition not met after all attempts');
};

export default {
  // Date/Time
  createFixedDate,
  getCurrentTimestamp,
  createExpiredDate,
  createFutureDate,
  formatDate,
  
  // String
  generateRandomString,
  generateRandomEmail,
  generateRandomUUID,
  sanitizeString,
  createSlug,
  
  // Number
  generateRandomNumber,
  generateRandomFloat,
  clampNumber,
  formatNumber,
  safeParseNumber,
  
  // Array
  generateRandomArray,
  shuffleArray,
  pickRandomElement,
  removeDuplicates,
  chunkArray,
  
  // Object
  deepClone,
  deepEqual,
  omit,
  pick,
  isEmpty,
  
  // Validation
  isValidEmail,
  isValidURL,
  isValidUUID,
  validatePasswordStrength,
  
  // File
  getFileExtension,
  isImageFile,
  isVideoFile,
  formatFileSize,
  
  // Async
  wait,
  retry,
  withTimeout,
  sleep,
  
  // Assertions
  expectResponseStatus,
  expectResponseJSON,
  expectResponseMessage,
  expectErrorResponse,
  expectFunctionCalled,
  expectFunctionCalledWith,
  
  // Setup/Teardown
  setupTestEnvironment,
  cleanupTestEnvironment,
  createTestTimeout,
  
  // Performance
  measureExecutionTime,
  waitForCondition,
  retryUntil,
};
