/**
 * AWS Service Mocking Utilities
 * Provides mocks for AWS SDK services used in the application
 */

import { vi } from 'vitest';

// Mock AWS SDK v3 clients
export class MockEC2Client {
  send = vi.fn();
  config = { region: 'us-east-1' };
}

export class MockS3Client {
  send = vi.fn();
  config = { region: 'us-east-1' };
}

export class MockRDSClient {
  send = vi.fn();
  config = { region: 'us-east-1' };
}

export class MockCloudFrontClient {
  send = vi.fn();
  config = { region: 'us-east-1' };
}

// Mock responses for EC2
export const MOCK_EC2_RESPONSES = {
  DESCRIBE_INSTANCES: {
    Reservations: [
      {
        Instances: [
          {
            InstanceId: 'i-1234567890abcdef0',
            InstanceType: 't2.micro',
            State: { Name: 'running' },
            PublicIpAddress: '54.123.45.67',
            PrivateIpAddress: '10.0.0.1',
            LaunchTime: new Date('2024-01-01T00:00:00Z'),
            Region: 'us-east-1',
            AvailabilityZone: 'us-east-1a',
            PlatformDetails: 'Linux/UNIX',
            Monitoring: { State: 'disabled' },
            Tags: [
              { Key: 'Name', Value: 'Test Instance' },
              { Key: 'Environment', Value: 'test' },
            ],
          },
        ],
      },
    ],
  },
  
  RUN_INSTANCES: {
    Instances: [
      {
        InstanceId: 'i-1234567890abcdef0',
        InstanceType: 't2.micro',
        State: { Name: 'pending' },
        PublicIpAddress: null,
        PrivateIpAddress: '10.0.0.1',
        LaunchTime: new Date(),
        Region: 'us-east-1',
        AvailabilityZone: 'us-east-1a',
      },
    ],
  },
  
  TERMINATE_INSTANCES: {
    TerminatingInstances: [
      {
        InstanceId: 'i-1234567890abcdef0',
        CurrentState: { Name: 'shutting-down' },
        PreviousState: { Name: 'running' },
      },
    ],
  },
};

// Mock responses for S3
export const MOCK_S3_RESPONSES = {
  LIST_BUCKETS: {
    Buckets: [
      {
        Name: 'test-bucket-1',
        CreationDate: new Date('2024-01-01T00:00:00Z'),
      },
      {
        Name: 'test-bucket-2',
        CreationDate: new Date('2024-01-02T00:00:00Z'),
      },
    ],
  },
  
  CREATE_BUCKET: {
    Location: 'us-east-1',
  },
  
  HEAD_BUCKET: {
    // No content for successful head bucket
  },
};

// Mock responses for RDS
export const MOCK_RDS_RESPONSES = {
  DESCRIBE_DB_INSTANCES: {
    DBInstances: [
      {
        DBInstanceIdentifier: 'test-db-1',
        DBInstanceClass: 'db.t3.micro',
        Engine: 'postgres',
        EngineVersion: '13.7',
        DBInstanceStatus: 'available',
        MasterUsername: 'admin',
        Endpoint: {
          Address: 'test-db-1.amazonaws.com',
          Port: 5432,
        },
        AvailabilityZone: 'us-east-1a',
        AllocatedStorage: 20,
        StorageType: 'gp2',
        StorageEncrypted: false,
        MultiAZ: false,
        PubliclyAccessible: false,
        InstanceCreateTime: new Date('2024-01-01T00:00:00Z'),
      },
    ],
  },
  
  CREATE_DB_INSTANCE: {
    DBInstance: {
      DBInstanceIdentifier: 'test-db-1',
      DBInstanceClass: 'db.t3.micro',
      Engine: 'postgres',
      DBInstanceStatus: 'creating',
      MasterUsername: 'admin',
      Endpoint: null,
    },
  },
  
  DELETE_DB_INSTANCE: {
    DBInstance: {
      DBInstanceIdentifier: 'test-db-1',
      DBInstanceStatus: 'deleting',
    },
  },
};

// Mock responses for CloudFront
export const MOCK_CLOUDFRONT_RESPONSES = {
  LIST_DISTRIBUTIONS: {
    DistributionList: {
      Items: [
        {
          Id: 'E1234567890ABC',
          ARN: 'arn:aws:cloudfront::123456789012:distribution/E1234567890ABC',
          Status: 'Deployed',
          DomainName: 'd123.cloudfront.net',
          Enabled: true,
          Comment: 'Test Distribution',
          LastModifiedTime: new Date('2024-01-01T00:00:00Z'),
          PriceClass: 'PriceClass_All',
          IsIPV6Enabled: true,
        },
      ],
    },
  },
  
  CREATE_DISTRIBUTION: {
    Distribution: {
      Id: 'E1234567890ABC',
      ARN: 'arn:aws:cloudfront::123456789012:distribution/E1234567890ABC',
      Status: 'InProgress',
      DomainName: 'd123.cloudfront.net',
      Enabled: true,
      Comment: 'Test Distribution',
    },
  },
  
  DELETE_DISTRIBUTION: {
    // No content for successful delete
  },
};

/**
 * Setup EC2 client mock
 */
export const setupEC2Mock = (mockResponse?: any) => {
  const ec2Client = new MockEC2Client();
  
  if (mockResponse) {
    ec2Client.send.mockResolvedValue(mockResponse);
  } else {
    ec2Client.send.mockResolvedValue(MOCK_EC2_RESPONSES.DESCRIBE_INSTANCES);
  }
  
  return ec2Client;
};

/**
 * Setup S3 client mock
 */
export const setupS3Mock = (mockResponse?: any) => {
  const s3Client = new MockS3Client();
  
  if (mockResponse) {
    s3Client.send.mockResolvedValue(mockResponse);
  } else {
    s3Client.send.mockResolvedValue(MOCK_S3_RESPONSES.LIST_BUCKETS);
  }
  
  return s3Client;
};

/**
 * Setup RDS client mock
 */
export const setupRDSMock = (mockResponse?: any) => {
  const rdsClient = new MockRDSClient();
  
  if (mockResponse) {
    rdsClient.send.mockResolvedValue(mockResponse);
  } else {
    rdsClient.send.mockResolvedValue(MOCK_RDS_RESPONSES.DESCRIBE_DB_INSTANCES);
  }
  
  return rdsClient;
};

/**
 * Setup CloudFront client mock
 */
export const setupCloudFrontMock = (mockResponse?: any) => {
  const cloudFrontClient = new MockCloudFrontClient();
  
  if (mockResponse) {
    cloudFrontClient.send.mockResolvedValue(mockResponse);
  } else {
    cloudFrontClient.send.mockResolvedValue(MOCK_CLOUDFRONT_RESPONSES.LIST_DISTRIBUTIONS);
  }
  
  return cloudFrontClient;
};

/**
 * Mock AWS credentials
 */
export const MOCK_AWS_CREDENTIALS = {
  accessKeyId: 'AKIAIOSFODNN7EXAMPLE',
  secretAccessKey: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
  region: 'us-east-1',
};

/**
 * Setup all AWS client mocks
 */
export const setupAllAWSMocks = () => {
  const ec2Client = setupEC2Mock();
  const s3Client = setupS3Mock();
  const rdsClient = setupRDSMock();
  const cloudFrontClient = setupCloudFrontMock();
  
  return {
    ec2Client,
    s3Client,
    rdsClient,
    cloudFrontClient,
  };
};

/**
 * Reset all AWS client mocks
 */
export const resetAWSMocks = () => {
  vi.clearAllMocks();
};

/**
 * Mock AWS environment variables
 */
export const mockAWSEnvironment = () => {
  process.env.AWS_REGION = 'us-east-1';
  process.env.AWS_ACCESS_KEY_ID = MOCK_AWS_CREDENTIALS.accessKeyId;
  process.env.AWS_SECRET_ACCESS_KEY = MOCK_AWS_CREDENTIALS.secretAccessKey;
};

/**
 * Test scenarios for AWS operations
 */
export const AWS_TEST_SCENARIOS = {
  SUCCESS: {
    ec2: MOCK_EC2_RESPONSES.DESCRIBE_INSTANCES,
    s3: MOCK_S3_RESPONSES.LIST_BUCKETS,
    rds: MOCK_RDS_RESPONSES.DESCRIBE_DB_INSTANCES,
    cloudfront: MOCK_CLOUDFRONT_RESPONSES.LIST_DISTRIBUTIONS,
  },
  
  NOT_FOUND: {
    ec2: { Reservations: [] },
    s3: { Buckets: [] },
    rds: { DBInstances: [] },
    cloudfront: { DistributionList: { Items: [] } },
  },
  
  ERROR: {
    ec2: new Error('EC2 service unavailable'),
    s3: new Error('S3 service unavailable'),
    rds: new Error('RDS service unavailable'),
    cloudfront: new Error('CloudFront service unavailable'),
  },
  
  RATE_LIMITED: {
    ec2: { __type: 'ThrottlingException', message: 'Rate exceeded' },
    s3: { __type: 'ThrottlingException', message: 'Rate exceeded' },
    rds: { __type: 'ThrottlingException', message: 'Rate exceeded' },
    cloudfront: { __type: 'ThrottlingException', message: 'Rate exceeded' },
  },
};

/**
 * Create mock AWS account for testing
 */
export const createMockAWSAccount = () => {
  return {
    id: 'mock-account-1',
    name: 'Mock AWS Account',
    accessKeyId: MOCK_AWS_CREDENTIALS.accessKeyId,
    secretAccessKey: MOCK_AWS_CREDENTIALS.secretAccessKey,
    isActive: true,
  };
};

/**
 * Mock AWS service errors
 */
export const AWS_MOCK_ERRORS = {
  INVALID_CREDENTIALS: {
    name: 'CredentialsError',
    message: 'The AWS Access Key Id you provided does not exist',
    code: 'InvalidAccessKeyId',
  },
  
  ACCESS_DENIED: {
    name: 'AccessDeniedError',
    message: 'Access Denied',
    code: 'AccessDenied',
  },
  
  RESOURCE_NOT_FOUND: {
    name: 'NotFoundError',
    message: 'The specified resource does not exist',
    code: 'ResourceNotFound',
  },
  
  RATE_LIMITED: {
    name: 'ThrottlingError',
    message: 'Rate exceeded',
    code: 'Throttling',
  },
  
  SERVICE_UNAVAILABLE: {
    name: 'ServiceUnavailableError',
    message: 'Service is temporarily unavailable',
    code: 'ServiceUnavailable',
  },
};

/**
 * Setup AWS client with error simulation
 */
export const setupAWSClientWithError = (service: 'ec2' | 's3' | 'rds' | 'cloudfront', errorType: keyof typeof AWS_MOCK_ERRORS) => {
  const error = AWS_MOCK_ERRORS[errorType];
  const mockError = new Error(error.message);
  mockError.name = error.name;
  
  switch (service) {
    case 'ec2':
      return setupEC2Mock().send.mockRejectedValue(mockError);
    case 's3':
      return setupS3Mock().send.mockRejectedValue(mockError);
    case 'rds':
      return setupRDSMock().send.mockRejectedValue(mockError);
    case 'cloudfront':
      return setupCloudFrontMock().send.mockRejectedValue(mockError);
  }
};

/**
 * Mock AWS request/response cycle
 */
export const mockAWSRequest = (service: string, operation: string, response: any) => {
  const mock = vi.fn().mockResolvedValue(response);
  return mock;
};

/**
 * Create test AWS resource
 */
export const createTestAWSResource = {
  ec2Instance: () => ({
    instanceId: 'i-test1234567890',
    name: 'Test EC2 Instance',
    region: 'us-east-1',
    state: 'running',
    instanceType: 't2.micro',
    publicIpAddress: '54.123.45.67',
    privateIpAddress: '10.0.0.1',
  }),
  
  s3Bucket: () => ({
    name: 'test-bucket-123',
    region: 'us-east-1',
    creationDate: new Date(),
  }),
  
  rdsInstance: () => ({
    dbInstanceIdentifier: 'test-db-1',
    region: 'us-east-1',
    dbInstanceClass: 'db.t3.micro',
    engine: 'postgres',
    engineVersion: '13.7',
    dbInstanceStatus: 'available',
    endpoint: 'test-db-1.amazonaws.com',
    port: 5432,
  }),
  
  cloudfrontDistribution: () => ({
    distributionId: 'E1234567890ABC',
    status: 'Deployed',
    domainName: 'd123.cloudfront.net',
    enabled: true,
    comment: 'Test Distribution',
  }),
};

export default {
  MockEC2Client,
  MockS3Client,
  MockRDSClient,
  MockCloudFrontClient,
  MOCK_EC2_RESPONSES,
  MOCK_S3_RESPONSES,
  MOCK_RDS_RESPONSES,
  MOCK_CLOUDFRONT_RESPONSES,
  setupEC2Mock,
  setupS3Mock,
  setupRDSMock,
  setupCloudFrontMock,
  setupAllAWSMocks,
  resetAWSMocks,
  mockAWSEnvironment,
  AWS_TEST_SCENARIOS,
  createMockAWSAccount,
  AWS_MOCK_ERRORS,
  setupAWSClientWithError,
  mockAWSRequest,
  createTestAWSResource,
};
