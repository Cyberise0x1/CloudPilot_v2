/**
 * Authentication Test Utilities
 * Provides helpers for testing authentication, JWT tokens, and user sessions
 */

import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { Request, Response, NextFunction } from 'express';
import { UserRole } from '@server/protected';
import { AuthenticatedUser } from '@server/protected';

// Mock user data for testing
export interface TestUser {
  id: string;
  email: string;
  password: string;
  username: string;
  role: UserRole;
  fullName: string;
}

// Predefined test users
export const TEST_USERS: Record<string, TestUser> = {
  ADMIN: {
    id: 'test-admin-1',
    email: 'admin@test.com',
    password: 'TestPassword123!',
    username: 'testadmin',
    role: UserRole.ADMIN,
    fullName: 'Test Administrator',
  },
  MANAGER: {
    id: 'test-manager-1',
    email: 'manager@test.com',
    password: 'TestPassword123!',
    username: 'testmanager',
    role: UserRole.MANAGER,
    fullName: 'Test Manager',
  },
  USER: {
    id: 'test-user-1',
    email: 'user@test.com',
    password: 'TestPassword123!',
    username: 'testuser',
    role: UserRole.USER,
    fullName: 'Test User',
  },
  VIEWER: {
    id: 'test-viewer-1',
    email: 'viewer@test.com',
    password: 'TestPassword123!',
    username: 'testviewer',
    role: UserRole.VIEWER,
    fullName: 'Test Viewer',
  },
  INACTIVE: {
    id: 'test-inactive-1',
    email: 'inactive@test.com',
    password: 'TestPassword123!',
    username: 'testinactive',
    role: UserRole.USER,
    fullName: 'Test Inactive User',
  },
};

// Create password hash for testing
export const createTestPasswordHash = async (password: string): Promise<string> => {
  return await bcrypt.hash(password, 10);
};

/**
 * Generate access token for test user
 */
export const generateAccessToken = (user: TestUser): string => {
  const jwtSecret = process.env.JWT_SECRET || 'test-secret-key-for-middleware';
  
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      username: user.username,
      role: user.role,
    },
    jwtSecret,
    { expiresIn: '1h' }
  );
};

/**
 * Generate refresh token for test user
 */
export const generateRefreshToken = (user: TestUser): string => {
  const refreshSecret = process.env.JWT_REFRESH_TOKEN_SECRET || 'test-refresh-secret';
  
  return jwt.sign(
    {
      id: user.id,
      type: 'refresh',
    },
    refreshSecret,
    { expiresIn: '7d' }
  );
};

/**
 * Generate expired access token
 */
export const generateExpiredToken = (user: TestUser): string => {
  const jwtSecret = process.env.JWT_SECRET || 'test-secret-key';
  
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      username: user.username,
      role: user.role,
    },
    jwtSecret,
    { expiresIn: '-1h' } // Already expired
  );
};

/**
 * Generate invalid token (malformed)
 */
export const generateInvalidToken = (): string => {
  return 'invalid.token.format';
};

/**
 * Create mock Express request with authentication
 */
export const createAuthenticatedRequest = (
  user: TestUser,
  options: {
    includeRefreshToken?: boolean;
    includeExpiredToken?: boolean;
    includeInvalidToken?: boolean;
  } = {}
): Request => {
  let token: string;
  
  if (options.includeExpiredToken) {
    token = generateExpiredToken(user);
  } else if (options.includeInvalidToken) {
    token = generateInvalidToken();
  } else {
    token = generateAccessToken(user);
  }
  
  const req: Partial<Request> = {
    headers: {
      authorization: `Bearer ${token}`,
    },
    body: options.includeRefreshToken 
      ? { refreshToken: generateRefreshToken(user) }
      : {},
  };
  
  return req as Request;
};

/**
 * Create mock Express request without authentication
 */
export const createUnauthenticatedRequest = (): Request => {
  const req: Partial<Request> = {
    headers: {},
    body: {},
  };
  
  return req as Request;
};

/**
 * Create mock Express response
 */
export const createMockResponse = (): Response => {
  const res: Partial<Response> = {
    status: vi.fn().mockReturnThis(),
    json: vi.fn().mockReturnThis(),
    send: vi.fn().mockReturnThis(),
    end: vi.fn().mockReturnThis(),
  };
  
  return res as Response;
};

/**
 * Create mock Next function
 */
export const createMockNext = (): NextFunction => {
  return vi.fn() as NextFunction;
};

/**
 * Create mock request/response/next for middleware testing
 */
export const createMockMiddlewareContext = (
  user?: TestUser,
  options: {
    includeRefreshToken?: boolean;
    includeExpiredToken?: boolean;
    includeInvalidToken?: boolean;
  } = {}
) => {
  const req = user 
    ? createAuthenticatedRequest(user, options)
    : createUnauthenticatedRequest();
  
  const res = createMockResponse();
  const next = createMockNext();
  
  return { req, res, next };
};

/**
 * Verify JWT token
 */
export const verifyToken = (token: string, secret: string): AuthenticatedUser | null => {
  try {
    return jwt.verify(token, secret) as AuthenticatedUser;
  } catch (error) {
    return null;
  }
};

/**
 * Decode JWT token without verification
 */
export const decodeToken = (token: string): any => {
  try {
    return jwt.decode(token);
  } catch (error) {
    return null;
  }
};

/**
 * Check if user has required role
 */
export const userHasRole = (user: AuthenticatedUser, requiredRoles: UserRole | UserRole[]): boolean => {
  const roles = Array.isArray(requiredRoles) ? requiredRoles : [requiredRoles];
  
  // Admin can access any role
  if (user.role === UserRole.ADMIN) {
    return true;
  }
  
  return roles.includes(user.role);
};

/**
 * Simulate login flow
 */
export const simulateLogin = async (email: string, password: string) => {
  // Find user by email
  const user = Object.values(TEST_USERS).find(u => u.email === email);
  
  if (!user) {
    return { success: false, error: 'User not found' };
  }
  
  // Verify password
  const isValidPassword = await bcrypt.compare(password, await createTestPasswordHash(user.password));
  
  if (!isValidPassword) {
    return { success: false, error: 'Invalid password' };
  }
  
  // Generate tokens
  const accessToken = generateAccessToken(user);
  const refreshToken = generateRefreshToken(user);
  
  return {
    success: true,
    user: {
      id: user.id,
      email: user.email,
      username: user.username,
      role: user.role,
      fullName: user.fullName,
    },
    accessToken,
    refreshToken,
  };
};

/**
 * Simulate token refresh
 */
export const simulateTokenRefresh = (refreshToken: string) => {
  try {
    const refreshSecret = process.env.JWT_REFRESH_TOKEN_SECRET || 'test-refresh-secret';
    const decoded = jwt.verify(refreshToken, refreshSecret) as { id: string };
    
    const user = Object.values(TEST_USERS).find(u => u.id === decoded.id);
    
    if (!user) {
      return { success: false, error: 'User not found' };
    }
    
    const newAccessToken = generateAccessToken(user);
    const newRefreshToken = generateRefreshToken(user);
    
    return {
      success: true,
      accessToken: newAccessToken,
      refreshToken: newRefreshToken,
    };
  } catch (error) {
    return { success: false, error: 'Invalid refresh token' };
  }
};

/**
 * Create test session data
 */
export const createTestSession = (user: TestUser) => {
  return {
    user: {
      id: user.id,
      email: user.email,
      username: user.username,
      role: user.role,
      fullName: user.fullName,
    },
    authenticated: true,
    createdAt: new Date(),
  };
};

/**
 * Validate token expiration
 */
export const isTokenExpired = (token: string): boolean => {
  const decoded = decodeToken(token);
  
  if (!decoded || !decoded.exp) {
    return true;
  }
  
  const currentTime = Math.floor(Date.now() / 1000);
  return decoded.exp < currentTime;
};

/**
 * Get token expiration time
 */
export const getTokenExpiration = (token: string): Date | null => {
  const decoded = decodeToken(token);
  
  if (!decoded || !decoded.exp) {
    return null;
  }
  
  return new Date(decoded.exp * 1000);
};

/**
 * Create authorization header value
 */
export const createAuthHeader = (token: string): string => {
  return `Bearer ${token}`;
};

/**
 * Mock Passport authentication
 */
export const mockPassportAuth = (user?: TestUser) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (user) {
      req.user = {
        id: user.id,
        email: user.email,
        username: user.username,
        role: user.role,
      };
    }
    next();
  };
};

/**
 * Test data for authentication scenarios
 */
export const AUTHENTICATION_TEST_SCENARIOS = {
  VALID_LOGIN: {
    email: TEST_USERS.ADMIN.email,
    password: TEST_USERS.ADMIN.password,
  },
  INVALID_EMAIL: {
    email: 'nonexistent@test.com',
    password: 'password123',
  },
  INVALID_PASSWORD: {
    email: TEST_USERS.ADMIN.email,
    password: 'wrongpassword',
  },
  EMPTY_CREDENTIALS: {
    email: '',
    password: '',
  },
  MALFORMED_EMAIL: {
    email: 'not-an-email',
    password: 'password123',
  },
  SHORT_PASSWORD: {
    email: TEST_USERS.ADMIN.email,
    password: '123',
  },
};

export default {
  TEST_USERS,
  createTestPasswordHash,
  generateAccessToken,
  generateRefreshToken,
  generateExpiredToken,
  generateInvalidToken,
  createAuthenticatedRequest,
  createUnauthenticatedRequest,
  createMockResponse,
  createMockNext,
  createMockMiddlewareContext,
  verifyToken,
  decodeToken,
  userHasRole,
  simulateLogin,
  simulateTokenRefresh,
  createTestSession,
  isTokenExpired,
  getTokenExpiration,
  createAuthHeader,
  mockPassportAuth,
  AUTHENTICATION_TEST_SCENARIOS,
};
