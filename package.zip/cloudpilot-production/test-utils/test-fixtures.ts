/**
 * Test Fixtures
 * Provides consistent test data fixtures for all test suites
 */

import { UserRole, AuthenticatedUser } from '@server/protected';
import { randomUUID } from 'crypto';

// User fixtures
export interface UserFixture {
  id: string;
  email: string;
  password: string;
  passwordHash: string;
  username: string;
  role: UserRole;
  fullName: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export const createUserFixture = (
  overrides: Partial<UserFixture> = {}
): UserFixture => {
  const id = overrides.id || `user-${randomUUID()}`;
  const timestamp = new Date();
  
  return {
    id,
    email: overrides.email || `user${id.slice(-6)}@example.com`,
    password: overrides.password || 'TestPassword123!',
    passwordHash: overrides.passwordHash || '$2a$10$hashedpassword123',
    username: overrides.username || `user${id.slice(-6)}`,
    role: overrides.role || UserRole.USER,
    fullName: overrides.fullName || 'Test User',
    isActive: overrides.isActive !== undefined ? overrides.isActive : true,
    createdAt: overrides.createdAt || timestamp,
    updatedAt: overrides.updatedAt || timestamp,
  };
};

export const USER_FIXTURES = {
  ADMIN: createUserFixture({
    id: 'admin-123',
    email: 'admin@example.com',
    username: 'admin',
    role: UserRole.ADMIN,
    fullName: 'Administrator',
    isActive: true,
  }),
  
  MANAGER: createUserFixture({
    id: 'manager-123',
    email: 'manager@example.com',
    username: 'manager',
    role: UserRole.MANAGER,
    fullName: 'Manager User',
    isActive: true,
  }),
  
  USER: createUserFixture({
    id: 'user-123',
    email: 'user@example.com',
    username: 'user',
    role: UserRole.USER,
    fullName: 'Regular User',
    isActive: true,
  }),
  
  VIEWER: createUserFixture({
    id: 'viewer-123',
    email: 'viewer@example.com',
    username: 'viewer',
    role: UserRole.VIEWER,
    fullName: 'Viewer User',
    isActive: true,
  }),
  
  INACTIVE: createUserFixture({
    id: 'inactive-123',
    email: 'inactive@example.com',
    username: 'inactive',
    role: UserRole.USER,
    fullName: 'Inactive User',
    isActive: false,
  }),
};

// AWS Account fixtures
export interface AWSAccountFixture {
  id: string;
  name: string;
  accessKeyId: string;
  secretAccessKey: string;
  isActive: boolean;
  createdAt: Date;
}

export const createAWSAccountFixture = (
  overrides: Partial<AWSAccountFixture> = {}
): AWSAccountFixture => {
  const id = overrides.id || `aws-account-${randomUUID()}`;
  
  return {
    id,
    name: overrides.name || `AWS Account ${id.slice(-6)}`,
    accessKeyId: overrides.accessKeyId || 'AKIAIOSFODNN7EXAMPLE',
    secretAccessKey: overrides.secretAccessKey || 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
    isActive: overrides.isActive !== undefined ? overrides.isActive : false,
    createdAt: overrides.createdAt || new Date(),
  };
};

export const AWS_ACCOUNT_FIXTURES = {
  DEFAULT: createAWSAccountFixture({
    id: 'aws-account-1',
    name: 'Default Test Account',
    isActive: true,
  }),
  
  INACTIVE: createAWSAccountFixture({
    id: 'aws-account-2',
    name: 'Inactive Test Account',
    isActive: false,
  }),
};

// EC2 Instance fixtures
export interface EC2InstanceFixture {
  id: string;
  instanceId: string;
  name?: string;
  region: string;
  state: string;
  instanceType: string;
  publicIpAddress?: string;
  privateIpAddress?: string;
  elasticIpAddress?: string;
  trafficInbound?: string;
  trafficOutbound?: string;
  launchTime?: Date;
  platformDetails?: string;
  availabilityZone?: string;
  monitoring?: string;
  volumes?: any[];
  networkInterfaces?: any[];
  securityGroups?: any[];
  tags?: Record<string, string>;
  accountId?: string;
  lastUpdated: Date;
}

export const createEC2InstanceFixture = (
  overrides: Partial<EC2InstanceFixture> = {}
): EC2InstanceFixture => {
  const id = overrides.id || `ec2-${randomUUID()}`;
  
  return {
    id,
    instanceId: overrides.instanceId || `i-${randomUUID().replace(/-/g, '').slice(0, 17)}`,
    name: overrides.name || `EC2 Instance ${id.slice(-6)}`,
    region: overrides.region || 'us-east-1',
    state: overrides.state || 'running',
    instanceType: overrides.instanceType || 't2.micro',
    publicIpAddress: overrides.publicIpAddress || '54.123.45.67',
    privateIpAddress: overrides.privateIpAddress || '10.0.0.1',
    elasticIpAddress: overrides.elasticIpAddress,
    trafficInbound: overrides.trafficInbound || '1.2 GB',
    trafficOutbound: overrides.trafficOutbound || '456 MB',
    launchTime: overrides.launchTime || new Date('2024-01-01T00:00:00Z'),
    platformDetails: overrides.platformDetails || 'Linux/UNIX',
    availabilityZone: overrides.availabilityZone || 'us-east-1a',
    monitoring: overrides.monitoring || 'disabled',
    volumes: overrides.volumes || [],
    networkInterfaces: overrides.networkInterfaces || [],
    securityGroups: overrides.securityGroups || [],
    tags: overrides.tags || { Environment: 'test', Name: `Instance ${id.slice(-6)}` },
    accountId: overrides.accountId,
    lastUpdated: overrides.lastUpdated || new Date(),
  };
};

export const EC2_INSTANCE_FIXTURES = {
  RUNNING: createEC2InstanceFixture({
    id: 'ec2-running-1',
    state: 'running',
  }),
  
  STOPPED: createEC2InstanceFixture({
    id: 'ec2-stopped-1',
    state: 'stopped',
  }),
  
  PENDING: createEC2InstanceFixture({
    id: 'ec2-pending-1',
    state: 'pending',
  }),
  
  TERMINATED: createEC2InstanceFixture({
    id: 'ec2-terminated-1',
    state: 'terminated',
  }),
};

// S3 Bucket fixtures
export interface S3BucketFixture {
  id: string;
  name: string;
  region: string;
  creationDate?: Date;
  accountId?: string;
  lastUpdated: Date;
}

export const createS3BucketFixture = (
  overrides: Partial<S3BucketFixture> = {}
): S3BucketFixture => {
  const id = overrides.id || `s3-bucket-${randomUUID()}`;
  
  return {
    id,
    name: overrides.name || `test-bucket-${id.slice(-8)}`,
    region: overrides.region || 'us-east-1',
    creationDate: overrides.creationDate || new Date(),
    accountId: overrides.accountId,
    lastUpdated: overrides.lastUpdated || new Date(),
  };
};

export const S3_BUCKET_FIXTURES = {
  STANDARD: createS3BucketFixture({
    id: 's3-bucket-1',
    name: 'test-bucket-123',
  }),
  
  VERSIONING_ENABLED: createS3BucketFixture({
    id: 's3-bucket-2',
    name: 'test-bucket-versioned',
  }),
  
  DIFFERENT_REGION: createS3BucketFixture({
    id: 's3-bucket-3',
    name: 'test-bucket-eu-west-1',
    region: 'eu-west-1',
  }),
};

// RDS Instance fixtures
export interface RDSInstanceFixture {
  id: string;
  dbInstanceIdentifier: string;
  region: string;
  dbInstanceClass: string;
  engine: string;
  engineVersion?: string;
  dbInstanceStatus: string;
  masterUsername?: string;
  endpoint?: string;
  port?: string;
  availabilityZone?: string;
  allocatedStorage?: string;
  storageType?: string;
  storageEncrypted?: boolean;
  vpcSecurityGroups?: string[];
  dbSubnetGroupName?: string;
  multiAz?: boolean;
  publiclyAccessible?: boolean;
  instanceCreateTime?: Date;
  accountId?: string;
  lastUpdated: Date;
}

export const createRDSInstanceFixture = (
  overrides: Partial<RDSInstanceFixture> = {}
): RDSInstanceFixture => {
  const id = overrides.id || `rds-${randomUUID()}`;
  
  return {
    id,
    dbInstanceIdentifier: overrides.dbInstanceIdentifier || `test-db-${id.slice(-8)}`,
    region: overrides.region || 'us-east-1',
    dbInstanceClass: overrides.dbInstanceClass || 'db.t3.micro',
    engine: overrides.engine || 'postgres',
    engineVersion: overrides.engineVersion || '13.7',
    dbInstanceStatus: overrides.dbInstanceStatus || 'available',
    masterUsername: overrides.masterUsername || 'admin',
    endpoint: overrides.endpoint || `${id.slice(-8)}.amazonaws.com`,
    port: overrides.port || '5432',
    availabilityZone: overrides.availabilityZone || 'us-east-1a',
    allocatedStorage: overrides.allocatedStorage || '20',
    storageType: overrides.storageType || 'gp2',
    storageEncrypted: overrides.storageEncrypted || false,
    vpcSecurityGroups: overrides.vpcSecurityGroups || [],
    dbSubnetGroupName: overrides.dbSubnetGroupName,
    multiAz: overrides.multiAz || false,
    publiclyAccessible: overrides.publiclyAccessible || false,
    instanceCreateTime: overrides.instanceCreateTime || new Date(),
    accountId: overrides.accountId,
    lastUpdated: overrides.lastUpdated || new Date(),
  };
};

export const RDS_INSTANCE_FIXTURES = {
  AVAILABLE: createRDSInstanceFixture({
    id: 'rds-available-1',
    dbInstanceStatus: 'available',
  }),
  
  CREATING: createRDSInstanceFixture({
    id: 'rds-creating-1',
    dbInstanceStatus: 'creating',
  }),
  
  BACKING_UP: createRDSInstanceFixture({
    id: 'rds-backup-1',
    dbInstanceStatus: 'backing-up',
  }),
};

// CloudFront Distribution fixtures
export interface CloudFrontDistributionFixture {
  id: string;
  distributionId: string;
  arn?: string;
  status: string;
  domainName: string;
  enabled: boolean;
  comment?: string;
  origins?: any[];
  defaultRootObject?: string;
  customErrorResponses?: any[];
  lastModifiedTime?: Date;
  priceClass?: string;
  webAclId?: string;
  httpVersion?: string;
  isIPV6Enabled?: boolean;
  distributionConfig?: any;
  accountId?: string;
  lastUpdated: Date;
}

export const createCloudFrontDistributionFixture = (
  overrides: Partial<CloudFrontDistributionFixture> = {}
): CloudFrontDistributionFixture => {
  const id = overrides.id || `cf-${randomUUID()}`;
  const distributionId = overrides.distributionId || `E${randomUUID().replace(/-/g, '').slice(0, 12)}`;
  
  return {
    id,
    distributionId,
    arn: overrides.arn || `arn:aws:cloudfront::123456789012:distribution/${distributionId}`,
    status: overrides.status || 'Deployed',
    domainName: overrides.domainName || `${distributionId.toLowerCase()}.cloudfront.net`,
    enabled: overrides.enabled !== undefined ? overrides.enabled : true,
    comment: overrides.comment || `Distribution ${id.slice(-6)}`,
    origins: overrides.origins || [],
    defaultRootObject: overrides.defaultRootObject,
    customErrorResponses: overrides.customErrorResponses || [],
    lastModifiedTime: overrides.lastModifiedTime || new Date(),
    priceClass: overrides.priceClass || 'PriceClass_All',
    webAclId: overrides.webAclId,
    httpVersion: overrides.httpVersion || 'http2',
    isIPV6Enabled: overrides.isIPV6Enabled !== undefined ? overrides.isIPV6Enabled : true,
    distributionConfig: overrides.distributionConfig || {},
    accountId: overrides.accountId,
    lastUpdated: overrides.lastUpdated || new Date(),
  };
};

export const CLOUDFRONT_DISTRIBUTION_FIXTURES = {
  DEPLOYED: createCloudFrontDistributionFixture({
    id: 'cf-deployed-1',
    status: 'Deployed',
  }),
  
  IN_PROGRESS: createCloudFrontDistributionFixture({
    id: 'cf-progress-1',
    status: 'InProgress',
  }),
  
  DISABLED: createCloudFrontDistributionFixture({
    id: 'cf-disabled-1',
    enabled: false,
  }),
};

// Instance Template fixtures
export interface InstanceTemplateFixture {
  id: string;
  name: string;
  description?: string;
  region: string;
  instanceType: string;
  imageId: string;
  keyName?: string;
  password?: string;
  diskSize: number;
  amount: number;
  userData?: string;
  instanceName?: string;
  isSpotInstance: boolean;
  spotMaxPrice?: string;
  enableIpv6: boolean;
  enableWavelength: boolean;
  authMode: string;
  securityGroups?: string[];
  subnetId?: string;
  publicIpAddress: boolean;
  ebsOptimized: boolean;
  monitoring: boolean;
  tags?: Record<string, string>;
  accountId?: string;
  createdAt: Date;
}

export const createInstanceTemplateFixture = (
  overrides: Partial<InstanceTemplateFixture> = {}
): InstanceTemplateFixture => {
  const id = overrides.id || `template-${randomUUID()}`;
  
  return {
    id,
    name: overrides.name || `Template ${id.slice(-6)}`,
    description: overrides.description,
    region: overrides.region || 'us-east-1',
    instanceType: overrides.instanceType || 't2.micro',
    imageId: overrides.imageId || 'ami-0c02fb55956c7d316',
    keyName: overrides.keyName,
    password: overrides.password,
    diskSize: overrides.diskSize || 20,
    amount: overrides.amount || 1,
    userData: overrides.userData,
    instanceName: overrides.instanceName,
    isSpotInstance: overrides.isSpotInstance || false,
    spotMaxPrice: overrides.spotMaxPrice,
    enableIpv6: overrides.enableIpv6 || false,
    enableWavelength: overrides.enableWavelength || false,
    authMode: overrides.authMode || 'key',
    securityGroups: overrides.securityGroups || [],
    subnetId: overrides.subnetId,
    publicIpAddress: overrides.publicIpAddress !== undefined ? overrides.publicIpAddress : true,
    ebsOptimized: overrides.ebsOptimized || false,
    monitoring: overrides.monitoring || false,
    tags: overrides.tags || {},
    accountId: overrides.accountId,
    createdAt: overrides.createdAt || new Date(),
  };
};

export const INSTANCE_TEMPLATE_FIXTURES = {
  STANDARD: createInstanceTemplateFixture({
    id: 'template-standard-1',
    name: 'Standard Template',
  }),
  
  SPOT: createInstanceTemplateFixture({
    id: 'template-spot-1',
    name: 'Spot Instance Template',
    isSpotInstance: true,
    spotMaxPrice: '0.05',
  }),
  
  PASSWORD_AUTH: createInstanceTemplateFixture({
    id: 'template-password-1',
    name: 'Password Auth Template',
    authMode: 'password',
    password: 'TestPassword123!',
  }),
};

// Refresh Token fixtures
export interface RefreshTokenFixture {
  id: string;
  userId: string;
  token: string;
  expiresAt: Date;
  createdAt: Date;
}

export const createRefreshTokenFixture = (
  userId: string,
  overrides: Partial<RefreshTokenFixture> = {}
): RefreshTokenFixture => {
  const id = overrides.id || `refresh-${randomUUID()}`;
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + 7); // 7 days from now
  
  return {
    id,
    userId,
    token: overrides.token || `refresh-token-${id}`,
    expiresAt: overrides.expiresAt || expiresAt,
    createdAt: overrides.createdAt || new Date(),
  };
};

// Authenticated user fixtures
export const createAuthenticatedUserFixture = (
  user: UserFixture
): AuthenticatedUser => {
  return {
    id: user.id,
    email: user.email,
    username: user.username,
    role: user.role,
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor(Date.now() / 1000) + 3600, // 1 hour from now
  };
};

// Common test data sets
export const TEST_DATA_SETS = {
  USERS: {
    ALL: [USER_FIXTURES.ADMIN, USER_FIXTURES.MANAGER, USER_FIXTURES.USER, USER_FIXTURES.VIEWER],
    ACTIVE: [USER_FIXTURES.ADMIN, USER_FIXTURES.MANAGER, USER_FIXTURES.USER, USER_FIXTURES.VIEWER],
    INACTIVE: [USER_FIXTURES.INACTIVE],
  },
  
  AWS_ACCOUNTS: {
    ALL: [AWS_ACCOUNT_FIXTURES.DEFAULT, AWS_ACCOUNT_FIXTURES.INACTIVE],
    ACTIVE: [AWS_ACCOUNT_FIXTURES.DEFAULT],
    INACTIVE: [AWS_ACCOUNT_FIXTURES.INACTIVE],
  },
  
  EC2_INSTANCES: {
    ALL: [EC2_INSTANCE_FIXTURES.RUNNING, EC2_INSTANCE_FIXTURES.STOPPED],
    RUNNING: [EC2_INSTANCE_FIXTURES.RUNNING],
    STOPPED: [EC2_INSTANCE_FIXTURES.STOPPED],
  },
};

// Generate random test data
export const generateRandomTestData = {
  user: () => createUserFixture(),
  awsAccount: () => createAWSAccountFixture(),
  ec2Instance: () => createEC2InstanceFixture(),
  s3Bucket: () => createS3BucketFixture(),
  rdsInstance: () => createRDSInstanceFixture(),
  cloudFrontDistribution: () => createCloudFrontDistributionFixture(),
  instanceTemplate: () => createInstanceTemplateFixture(),
};

export default {
  createUserFixture,
  USER_FIXTURES,
  createAWSAccountFixture,
  AWS_ACCOUNT_FIXTURES,
  createEC2InstanceFixture,
  EC2_INSTANCE_FIXTURES,
  createS3BucketFixture,
  S3_BUCKET_FIXTURES,
  createRDSInstanceFixture,
  RDS_INSTANCE_FIXTURES,
  createCloudFrontDistributionFixture,
  CLOUDFRONT_DISTRIBUTION_FIXTURES,
  createInstanceTemplateFixture,
  INSTANCE_TEMPLATE_FIXTURES,
  createRefreshTokenFixture,
  createAuthenticatedUserFixture,
  TEST_DATA_SETS,
  generateRandomTestData,
};
