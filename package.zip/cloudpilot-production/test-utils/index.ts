/**
 * Test Utilities Index
 * Centralized exports for all test utilities
 */

// Database testing utilities
export * from './test-database';

// Authentication testing utilities
export * from './test-auth';

// AWS service mocking utilities
export * from './test-aws';

// Test fixtures and data
export * from './test-fixtures';

// Common mocks and spies
export * from './test-mocks';

// General test utilities
export * from './test-utils';

// =============================================================================
// COMPOSITE HELPERS - COMBINE MULTIPLE UTILITIES
// =============================================================================

import { setupTestDatabase, cleanDatabase, getTestDatabase } from './test-database';
import { TEST_USERS, createAuthenticatedRequest } from './test-auth';
import { setupAllAWSMocks, resetAWSMocks } from './test-aws';
import { createUserFixture, USER_FIXTURES } from './test-fixtures';
import { createMockRequest, createMockResponse, createMockNext } from './test-mocks';
import { setupTestEnvironment, cleanupTestEnvironment } from './test-utils';

/**
 * Complete test setup for database + authentication + AWS mocks
 */
export const createCompleteTestSetup = () => {
  return {
    // Database
    setupTestDatabase,
    cleanDatabase,
    getTestDatabase,
    
    // Authentication
    TEST_USERS,
    createAuthenticatedRequest,
    USER_FIXTURES,
    
    // AWS
    setupAllAWSMocks,
    resetAWSMocks,
    
    // Mocks
    createMockRequest,
    createMockResponse,
    createMockNext,
    
    // Environment
    setupTestEnvironment,
    cleanupTestEnvironment,
  };
};

/**
 * Standard beforeAll hook setup
 */
export const createBeforeAllSetup = async () => {
  setupTestEnvironment();
  await setupTestDatabase();
  setupAllAWSMocks();
};

/**
 * Standard afterAll hook cleanup
 */
export const createAfterAllCleanup = async () => {
  resetAWSMocks();
  await cleanupTestEnvironment();
  cleanupTestEnvironment();
};

/**
 * Standard beforeEach hook setup
 */
export const createBeforeEachSetup = async () => {
  await cleanDatabase();
};

/**
 * Standard afterEach hook cleanup
 */
export const createAfterEachCleanup = async () => {
  // Database is already cleaned beforeEach, so no cleanup needed here
  // Reset any per-test mocks if needed
};

/**
 * Create comprehensive test hooks
 */
export const createTestHooks = () => {
  return {
    beforeAll: createBeforeAllSetup,
    afterAll: createAfterAllCleanup,
    beforeEach: createBeforeEachSetup,
    afterEach: createAfterEachCleanup,
  };
};

// =============================================================================
// QUICK START GUIDE
// =============================================================================

/**
 * Quick start guide for using test utilities
 */
export const QUICK_START = {
  basicSetup: `
import { describe, it, expect } from 'vitest';
import { 
  createTestHooks, 
  createMockMiddlewareContext,
  TEST_USERS 
} from './test-utils';

const hooks = createTestHooks();

describe('My Test Suite', () => {
  hooks.beforeAll();
  hooks.beforeEach();
  hooks.afterEach();
  hooks.afterAll();

  it('should test with authentication', () => {
    const { req, res, next } = createMockMiddlewareContext(TEST_USERS.ADMIN);
    
    // Your test code here
    expect(req.headers.authorization).toBeDefined();
  });
});
  `,
  
  databaseSetup: `
import { setupTestDatabase, cleanDatabase } from './test-utils';

describe('Database Tests', () => {
  beforeAll(async () => {
    await setupTestDatabase();
  });

  beforeEach(async () => {
    await cleanDatabase();
  });

  it('should work with database', async () => {
    // Your database test code
  });
});
  `,
  
  awsMocks: `
import { setupAllAWSMocks, resetAWSMocks } from './test-utils';

describe('AWS Service Tests', () => {
  beforeAll(() => {
    setupAllAWSMocks();
  });

  afterAll(() => {
    resetAWSMocks();
  });

  it('should test AWS service', async () => {
    // Your AWS test code
  });
});
  `,
};

// =============================================================================
// VERSION INFO
// =============================================================================

export const TEST_UTILS_VERSION = '1.0.0';

export const getVersionInfo = () => ({
  version: TEST_UTILS_VERSION,
  description: 'Comprehensive test utilities for CloudPilot application',
  features: [
    'Database setup and cleanup',
    'Authentication testing helpers',
    'AWS service mocking',
    'Test fixtures and data',
    'Common mocks and spies',
    'General test utilities',
  ],
  lastUpdated: new Date().toISOString(),
});

// =============================================================================
// DEFAULT EXPORT
// =============================================================================

const defaultExport = {
  // Database
  setupTestDatabase,
  cleanDatabase,
  getTestDatabase,
  
  // Auth
  TEST_USERS,
  createAuthenticatedRequest,
  USER_FIXTURES,
  
  // AWS
  setupAllAWSMocks,
  resetAWSMocks,
  
  // Mocks
  createMockRequest,
  createMockResponse,
  createMockNext,
  
  // Environment
  setupTestEnvironment,
  cleanupTestEnvironment,
  
  // Composite helpers
  createCompleteTestSetup,
  createBeforeAllSetup,
  createAfterAllCleanup,
  createBeforeEachSetup,
  createAfterEachCleanup,
  createTestHooks,
  
  // Version
  version: TEST_UTILS_VERSION,
  getVersionInfo,
  QUICK_START,
};

export default defaultExport;
