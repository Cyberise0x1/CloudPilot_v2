# Test Utilities Documentation

This directory contains comprehensive test utilities and helpers for the CloudPilot application. These utilities provide a consistent, reusable foundation for writing reliable tests.

## 📁 File Overview

- **`test-database.ts`** - Database setup, cleanup, and testing helpers
- **`test-auth.ts`** - Authentication and JWT token testing utilities  
- **`test-aws.ts`** - AWS service mocking and test scenarios
- **`test-fixtures.ts`** - Consistent test data fixtures
- **`test-mocks.ts`** - Common mocks and spies for Express, AWS, etc.
- **`test-utils.ts`** - General utilities for dates, strings, validation, etc.
- **`index.ts`** - Centralized exports and composite helpers

## 🚀 Quick Start

### Basic Setup

```typescript
import { describe, it, expect } from 'vitest';
import { 
  createTestHooks, 
  createMockMiddlewareContext,
  TEST_USERS 
} from './test-utils';

const hooks = createTestHooks();

describe('My Test Suite', () => {
  hooks.beforeAll();
  hooks.beforeEach();
  hooks.afterEach();
  hooks.afterAll();

  it('should test with authentication', () => {
    const { req, res, next } = createMockMiddlewareContext(TEST_USERS.ADMIN);
    
    expect(req.headers.authorization).toBeDefined();
  });
});
```

### Database Tests

```typescript
import { setupTestDatabase, cleanDatabase } from './test-utils';

describe('User Service Tests', () => {
  beforeAll(async () => {
    await setupTestDatabase();
  });

  beforeEach(async () => {
    await cleanDatabase();
  });

  it('should create a user', async () => {
    // Your database test code
  });
});
```

### AWS Service Tests

```typescript
import { setupAllAWSMocks, resetAWSMocks } from './test-utils';

describe('AWS Service Tests', () => {
  beforeAll(() => {
    setupAllAWSMocks();
  });

  afterAll(() => {
    resetAWSMocks();
  });

  it('should list EC2 instances', async () => {
    // Your AWS test code
  });
});
```

## 📋 Detailed Usage Guide

### Database Testing (`test-database.ts`)

#### Setup and Cleanup

```typescript
import { setupTestDatabase, cleanDatabase, getTestDatabase } from './test-utils';

// Setup database connection
beforeAll(async () => {
  await setupTestDatabase();
});

// Clean database before each test
beforeEach(async () => {
  await cleanDatabase();
});

// Close connection
afterAll(async () => {
  await closeTestDatabase();
});
```

#### Seeding Test Data

```typescript
import { seedDatabase, USER_FIXTURES, AWS_ACCOUNT_FIXTURES } from './test-utils';

beforeEach(async () => {
  await seedDatabase({
    users: [USER_FIXTURES.ADMIN],
    awsAccounts: [AWS_ACCOUNT_FIXTURES.DEFAULT],
  });
});
```

### Authentication Testing (`test-auth.ts`)

#### Mock Authentication

```typescript
import { 
  createMockMiddlewareContext,
  TEST_USERS 
} from './test-utils';

// With valid user
const { req, res, next } = createMockMiddlewareContext(TEST_USERS.ADMIN);

// With expired token
const { req, res, next } = createMockMiddlewareContext(TEST_USERS.USER, {
  includeExpiredToken: true
});

// Without authentication
const { req, res, next } = createMockMiddlewareContext();
```

#### Token Generation

```typescript
import { 
  generateAccessToken,
  generateRefreshToken,
  generateExpiredToken 
} from './test-utils';

const token = generateAccessToken(TEST_USERS.ADMIN);
const refreshToken = generateRefreshToken(TEST_USERS.ADMIN);
const expiredToken = generateExpiredToken(TEST_USERS.ADMIN);
```

#### Login Simulation

```typescript
import { simulateLogin } from './test-utils';

const result = await simulateLogin('admin@test.com', 'password123');
expect(result.success).toBe(true);
expect(result.accessToken).toBeDefined();
```

### AWS Service Testing (`test-aws.ts`)

#### Mock AWS Clients

```typescript
import { 
  setupEC2Mock,
  setupS3Mock,
  setupRDSMock,
  setupCloudFrontMock 
} from './test-utils';

// Setup individual service
const ec2Client = setupEC2Mock();

// Setup all services
const { ec2Client, s3Client, rdsClient, cloudFrontClient } = setupAllAWSMocks();
```

#### Mock Responses

```typescript
import { 
  MOCK_EC2_RESPONSES,
  MOCK_S3_RESPONSES,
  MOCK_RDS_RESPONSES 
} from './test-utils';

const ec2Client = setupEC2Mock(MOCK_EC2_RESPONSES.DESCRIBE_INSTANCES);
```

#### Error Simulation

```typescript
import { setupAWSClientWithError } from './test-utils';

setupAWSClientWithError('ec2', 'ACCESS_DENIED');
```

### Test Fixtures (`test-fixtures.ts`)

#### User Fixtures

```typescript
import { 
  USER_FIXTURES,
  createUserFixture 
} from './test-utils';

// Use predefined fixtures
const admin = USER_FIXTURES.ADMIN;
const user = USER_FIXTURES.USER;

// Create custom fixture
const customUser = createUserFixture({
  email: 'custom@example.com',
  role: UserRole.MANAGER,
});
```

#### AWS Resource Fixtures

```typescript
import { 
  EC2_INSTANCE_FIXTURES,
  S3_BUCKET_FIXTURES,
  createEC2InstanceFixture 
} from './test-utils';

const runningInstance = EC2_INSTANCE_FIXTURES.RUNNING;
const customInstance = createEC2InstanceFixture({
  instanceType: 't3.large',
  state: 'running',
});
```

### Common Mocks (`test-mocks.ts`)

#### Express Mocks

```typescript
import { 
  createMockRequest,
  createMockResponse,
  createMockNext 
} from './test-utils';

const req = createMockRequest({
  method: 'POST',
  body: { data: 'test' },
});

const res = createMockResponse();
const next = createMockNext();
```

#### Database Mocks

```typescript
import { createMockDatabase } from './test-utils';

const mockDb = createMockDatabase();
mockDb.select.mockReturnValue([{ id: 1 }]);
```

#### AWS Client Mocks

```typescript
import { createMockEC2Client } from './test-utils';

const ec2Client = createMockEC2Client();
ec2Client.send.mockResolvedValue(MOCK_EC2_RESPONSES.DESCRIBE_INSTANCES);
```

### General Utilities (`test-utils.ts`)

#### String Utilities

```typescript
import { 
  generateRandomString,
  generateRandomEmail,
  createSlug 
} from './test-utils';

const randomEmail = generateRandomEmail();
const slug = createSlug('Hello World Example');
```

#### Array Utilities

```typescript
import { 
  generateRandomArray,
  shuffleArray,
  pickRandomElement 
} from './test-utils';

const randomNumbers = generateRandomArray(10, () => Math.random());
const shuffled = shuffleArray([1, 2, 3, 4, 5]);
const element = pickRandomElement([1, 2, 3]);
```

#### Object Utilities

```typescript
import { deepClone, deepEqual, omit, pick } from './test-utils';

const cloned = deepClone(original);
const equal = deepEqual(obj1, obj2);
const withoutId = omit(user, ['id', 'password']);
const onlyUserData = pick(user, ['id', 'email', 'name']);
```

#### Validation Utilities

```typescript
import { 
  isValidEmail,
  isValidURL,
  validatePasswordStrength 
} from './test-utils';

const validEmail = isValidEmail('test@example.com');
const strength = validatePasswordStrength('MyPassword123!');
```

## 🏗️ Best Practices

### 1. Use Hooks for Setup/Teardown

```typescript
const hooks = createTestHooks();

describe('My Tests', () => {
  hooks.beforeAll();
  hooks.beforeEach();
  hooks.afterEach();
  hooks.afterAll();
  
  // Your tests
});
```

### 2. Clean Database Before Each Test

```typescript
beforeEach(async () => {
  await cleanDatabase();
  // Or seed with fresh test data
  await seedDatabase(testData);
});
```

### 3. Reset Mocks After Each Test

```typescript
afterEach(() => {
  vi.clearAllMocks();
});
```

### 4. Use Test Fixtures for Consistency

```typescript
// Bad - Magic values scattered throughout tests
const user = { id: '123', email: 'test@example.com', role: 'admin' };

// Good - Using fixtures
const user = USER_FIXTURES.ADMIN;
```

### 5. Mock External Services

```typescript
beforeAll(() => {
  setupAllAWSMocks();
});

afterAll(() => {
  resetAWSMocks();
});
```

### 6. Validate Responses Properly

```typescript
it('should return user', () => {
  const res = createMockResponse();
  
  // Call your function
  yourFunction(req, res, next);
  
  // Validate response
  expect(res.status).toHaveBeenCalledWith(200);
  expect(res.json).toHaveBeenCalledWith(
    expect.objectContaining({ id: expect.any(String) })
  );
});
```

## 🔧 Environment Setup

### Required Environment Variables

```bash
NODE_ENV=test
JWT_SECRET=test-secret-key
JWT_REFRESH_TOKEN_SECRET=test-refresh-secret
TEST_DATABASE_URL=postgresql://test:test@localhost:5432/test
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=mock-access-key
AWS_SECRET_ACCESS_KEY=mock-secret-key
```

### Vitest Configuration

Add to your `vitest.config.ts`:

```typescript
import { defineConfig } from 'vitest/config';
import path from 'path';

export default defineConfig({
  test: {
    globals: true,
    environment: 'node',
    setupFiles: ['./test-setup.ts'],
  },
  resolve: {
    alias: {
      '@test-utils': path.resolve(__dirname, './test-utils'),
    },
  },
});
```

### Test Setup File

Create `test-setup.ts`:

```typescript
import { setupTestEnvironment } from './test-utils';

setupTestEnvironment();
```

## 📝 Example Test Files

### Complete User Test Example

```typescript
import { describe, it, expect } from 'vitest';
import { 
  createTestHooks,
  TEST_USERS,
  createMockMiddlewareContext,
  expectErrorResponse 
} from './test-utils';
import { requireAuth } from '../server/protected';

const hooks = createTestHooks();

describe('Authentication Middleware', () => {
  hooks.beforeAll();
  hooks.beforeEach();
  hooks.afterEach();
  hooks.afterAll();

  it('should allow access with valid token', () => {
    const { req, res, next } = createMockMiddlewareContext(TEST_USERS.ADMIN);
    
    requireAuth(req, res, next);
    
    expect(next).toHaveBeenCalled();
    expect(req.user).toBeDefined();
  });

  it('should deny access without token', () => {
    const { req, res, next } = createMockMiddlewareContext();
    
    requireAuth(req, res, next);
    
    expectErrorResponse(res, 401, 'Authorization header is required');
    expect(next).not.toHaveBeenCalled();
  });
});
```

## 🤝 Contributing

When adding new test utilities:

1. Follow the existing patterns
2. Add comprehensive JSDoc comments
3. Include TypeScript types
4. Add examples in this README
5. Update the index.ts exports
6. Add tests for the utilities themselves

## 📚 Additional Resources

- [Vitest Documentation](https://vitest.dev/)
- [Testing Library](https://testing-library.com/)
- [Express Testing Guide](https://expressjs.com/en/guide/testing.html)

---

For questions or issues with these test utilities, please refer to the inline documentation in each file or contact the development team.
