/**
 * Common Mocks and Spies
 * Provides reusable mocks and spies for testing
 */

import { vi, Mock } from 'vitest';
import { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

// =============================================================================
// REQUEST/RESPONSE MOCKS
// =============================================================================

/**
 * Create a mock Express Request
 */
export const createMockRequest = (overrides: Partial<Request> = {}): Request => {
  const req: Partial<Request> = {
    method: overrides.method || 'GET',
    url: overrides.url || '/',
    headers: overrides.headers || {},
    body: overrides.body || {},
    params: overrides.params || {},
    query: overrides.query || {},
    user: overrides.user,
    ...overrides,
  };
  
  return req as Request;
};

/**
 * Create a mock Express Response
 */
export const createMockResponse = (): Response => {
  const res: Partial<Response> = {
    status: vi.fn().mockReturnThis(),
    json: vi.fn().mockReturnThis(),
    send: vi.fn().mockReturnThis(),
    sendFile: vi.fn().mockReturnThis(),
    redirect: vi.fn().mockReturnThis(),
    cookie: vi.fn().mockReturnThis(),
    clearCookie: vi.fn().mockReturnThis(),
    set: vi.fn().mockReturnThis(),
    setHeader: vi.fn().mockReturnThis(),
    get: vi.fn(),
    end: vi.fn().mockReturnThis(),
    locals: {},
    ...overrides,
  };
  
  return res as Response;
};

/**
 * Create a mock Next function
 */
export const createMockNext = (): NextFunction => {
  return vi.fn() as NextFunction;
};

// =============================================================================
// DATABASE MOCKS
// =============================================================================

/**
 * Mock drizzle database operations
 */
export const createMockDatabase = () => {
  return {
    select: vi.fn().mockReturnThis(),
    insert: vi.fn().mockReturnThis(),
    update: vi.fn().mockReturnThis(),
    delete: vi.fn().mockReturnThis(),
    from: vi.fn().mockReturnThis(),
    values: vi.fn().mockReturnThis(),
    set: vi.fn().mockReturnThis(),
    where: vi.fn().mockReturnThis(),
    returning: vi.fn().mockReturnThis(),
    execute: vi.fn(),
    transaction: vi.fn(),
    $transaction: vi.fn(),
  };
};

/**
 * Mock database transaction
 */
export const createMockTransaction = () => {
  return {
    select: vi.fn().mockReturnThis(),
    insert: vi.fn().mockReturnThis(),
    update: vi.fn().mockReturnThis(),
    delete: vi.fn().mockReturnThis(),
    from: vi.fn().mockReturnThis(),
    values: vi.fn().mockReturnThis(),
    set: vi.fn().mockReturnThis(),
    where: vi.fn().mockReturnThis(),
    execute: vi.fn(),
  };
};

// =============================================================================
// AUTHENTICATION MOCKS
// =============================================================================

/**
 * Mock bcrypt operations
 */
export const mockBcrypt = {
  hash: vi.fn(),
  compare: vi.fn(),
  genSalt: vi.fn(),
};

// =============================================================================
// JWT MOCKS
// =============================================================================

/**
 * Mock JWT operations
 */
export const mockJwt = {
  sign: vi.fn(),
  verify: vi.fn(),
  decode: vi.fn(),
};

// =============================================================================
// AWS SERVICE MOCKS
// =============================================================================

/**
 * Mock AWS client
 */
export const createMockAWSClient = (serviceName: string) => {
  return {
    config: {
      region: 'us-east-1',
      credentials: {
        accessKeyId: 'mock-access-key',
        secretAccessKey: 'mock-secret-key',
      },
    },
    send: vi.fn(),
    [serviceName]: vi.fn(),
  };
};

/**
 * Mock AWS EC2 client
 */
export const createMockEC2Client = () => {
  return {
    config: {
      region: 'us-east-1',
      credentials: {
        accessKeyId: 'mock-access-key',
        secretAccessKey: 'mock-secret-key',
      },
    },
    send: vi.fn(),
    describeInstances: vi.fn().mockReturnThis(),
    runInstances: vi.fn().mockReturnThis(),
    terminateInstances: vi.fn().mockReturnThis(),
    stopInstances: vi.fn().mockReturnThis(),
    startInstances: vi.fn().mockReturnThis(),
  };
};

/**
 * Mock AWS S3 client
 */
export const createMockS3Client = () => {
  return {
    config: {
      region: 'us-east-1',
      credentials: {
        accessKeyId: 'mock-access-key',
        secretAccessKey: 'mock-secret-key',
      },
    },
    send: vi.fn(),
    listBuckets: vi.fn().mockReturnThis(),
    createBucket: vi.fn().mockReturnThis(),
    deleteBucket: vi.fn().mockReturnThis(),
  };
};

/**
 * Mock AWS RDS client
 */
export const createMockRDSClient = () => {
  return {
    config: {
      region: 'us-east-1',
      credentials: {
        accessKeyId: 'mock-access-key',
        secretAccessKey: 'mock-secret-key',
      },
    },
    send: vi.fn(),
    describeDBInstances: vi.fn().mockReturnThis(),
    createDBInstance: vi.fn().mockReturnThis(),
    deleteDBInstance: vi.fn().mockReturnThis(),
  };
};

/**
 * Mock AWS CloudFront client
 */
export const createMockCloudFrontClient = () => {
  return {
    config: {
      region: 'us-east-1',
      credentials: {
        accessKeyId: 'mock-access-key',
        secretAccessKey: 'mock-secret-key',
      },
    },
    send: vi.fn(),
    listDistributions: vi.fn().mockReturnThis(),
    createDistribution: vi.fn().mockReturnThis(),
    deleteDistribution: vi.fn().mockReturnThis(),
  };
};

// =============================================================================
// MIDDLEWARE MOCKS
// =============================================================================

/**
 * Mock authentication middleware
 */
export const createMockAuthMiddleware = (user?: any) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (user) {
      req.user = user;
    }
    next();
  };
};

/**
 * Mock role-based authorization middleware
 */
export const createMockRoleMiddleware = (requiredRole: string) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Unauthorized' });
    }
    
    if (req.user.role !== requiredRole && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Forbidden' });
    }
    
    next();
  };
};

/**
 * Mock error handling middleware
 */
export const createMockErrorHandler = () => {
  return (error: Error, req: Request, res: Response, next: NextFunction) => {
    const status = error.status || 500;
    const message = error.message || 'Internal Server Error';
    
    res.status(status).json({
      message,
      ...(process.env.NODE_ENV === 'development' && { stack: error.stack }),
    });
  };
};

// =============================================================================
// HTTP CLIENT MOCKS
// =============================================================================

/**
 * Mock fetch API
 */
export const mockFetch = vi.fn();

/**
 * Mock axios
 */
export const createMockAxios = () => {
  return {
    get: vi.fn(),
    post: vi.fn(),
    put: vi.fn(),
    delete: vi.fn(),
    patch: vi.fn(),
    interceptors: {
      request: {
        use: vi.fn(),
      },
      response: {
        use: vi.fn(),
      },
    },
  };
};

// =============================================================================
// FILE SYSTEM MOCKS
// =============================================================================

/**
 * Mock fs/promises
 */
export const mockFs = {
  readFile: vi.fn(),
  writeFile: vi.fn(),
  unlink: vi.fn(),
  mkdir: vi.fn(),
  rmdir: vi.fn(),
  readdir: vi.fn(),
  stat: vi.fn(),
  exists: vi.fn(),
};

/**
 * Mock fs/promises path
 */
export const mockPath = {
  join: vi.fn(),
  resolve: vi.fn(),
  dirname: vi.fn(),
  basename: vi.fn(),
  extname: vi.fn(),
};

// =============================================================================
// UTILITY MOCKS
// =============================================================================

/**
 * Mock logger
 */
export const createMockLogger = () => {
  return {
    info: vi.fn(),
    error: vi.fn(),
    warn: vi.fn(),
    debug: vi.fn(),
    trace: vi.fn(),
    fatal: vi.fn(),
  };
};

/**
 * Mock validator
 */
export const createMockValidator = () => {
  return {
    validate: vi.fn(),
    parse: vi.fn(),
    safeParse: vi.fn(),
  };
};

/**
 * Mock cache
 */
export const createMockCache = () => {
  return {
    get: vi.fn(),
    set: vi.fn(),
    del: vi.fn(),
    clear: vi.fn(),
    has: vi.fn(),
  };
};

// =============================================================================
// REUSABLE SPY HELPERS
// =============================================================================

/**
 * Create a spy on an object method
 */
export const createSpy = (obj: any, method: string) => {
  return vi.spyOn(obj, method);
};

/**
 * Spy on constructor
 */
export const spyOnConstructor = (constructor: any, method: string, implementation?: Function) => {
  return vi.spyOn(constructor.prototype, method).mockImplementation(implementation || vi.fn());
};

/**
 * Mock module
 */
export const mockModule = (modulePath: string, exports: Record<string, any>) => {
  return vi.mock(modulePath, () => exports);
};

// =============================================================================
// MOCK CONFIGURATIONS
// =============================================================================

/**
 * Mock environment variables
 */
export const mockEnvironment = (variables: Record<string, string>) => {
  Object.entries(variables).forEach(([key, value]) => {
    vi.stubGlobal(key, value);
  });
};

/**
 * Mock process variables
 */
export const mockProcess = {
  env: {
    ...process.env,
    NODE_ENV: 'test',
    JWT_SECRET: 'test-secret',
    JWT_REFRESH_TOKEN_SECRET: 'test-refresh-secret',
    DATABASE_URL: 'postgresql://test:test@localhost:5432/test',
  },
  cwd: vi.fn(() => '/test'),
  nextTick: vi.fn(),
  version: '18.0.0',
  browser: false,
};

// =============================================================================
// MOCK SETUP/TEARDOWN HELPERS
// =============================================================================

/**
 * Setup all common mocks
 */
export const setupAllMocks = () => {
  // Mock bcrypt
  mockBcrypt.hash.mockResolvedValue('hashed-password');
  mockBcrypt.compare.mockResolvedValue(true);
  mockBcrypt.genSalt.mockResolvedValue('salt');
  
  // Mock JWT
  mockJwt.sign.mockReturnValue('mock-token');
  mockJwt.verify.mockReturnValue({ id: 'user-id', role: 'user' });
  mockJwt.decode.mockReturnValue({ id: 'user-id', role: 'user' });
  
  // Mock fetch
  mockFetch.mockResolvedValue({
    ok: true,
    status: 200,
    json: () => Promise.resolve({}),
    text: () => Promise.resolve(''),
  });
  
  // Mock environment
  mockEnvironment(mockProcess.env);
};

/**
 * Clear all mocks
 */
export const clearAllMocks = () => {
  vi.clearAllMocks();
  vi.clearAllTimers();
};

/**
 * Restore all mocks
 */
export const restoreAllMocks = () => {
  vi.restoreAllMocks();
};

// =============================================================================
// ASSOCATION MOCKS
// =============================================================================

/**
 * Mock Express application
 */
export const createMockApp = () => {
  return {
    use: vi.fn(),
    get: vi.fn(),
    post: vi.fn(),
    put: vi.fn(),
    delete: vi.fn(),
    patch: vi.fn(),
    listen: vi.fn(),
    handle: vi.fn(),
  };
};

/**
 * Mock Express router
 */
export const createMockRouter = () => {
  return {
    use: vi.fn(),
    get: vi.fn(),
    post: vi.fn(),
    put: vi.fn(),
    delete: vi.fn(),
    patch: vi.fn(),
  };
};

/**
 * Mock session
 */
export const createMockSession = () => {
  return {
    id: 'session-id',
    userId: 'user-id',
    createdAt: new Date(),
    expiredAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
    regenerate: vi.fn(),
    destroy: vi.fn(),
    save: vi.fn(),
  };
};

/**
 * Mock cookie
 */
export const createMockCookie = () => {
  return {
    name: 'cookie-name',
    value: 'cookie-value',
    options: {},
  };
};

export default {
  // Request/Response
  createMockRequest,
  createMockResponse,
  createMockNext,
  
  // Database
  createMockDatabase,
  createMockTransaction,
  
  // Auth
  mockBcrypt,
  mockJwt,
  
  // AWS
  createMockAWSClient,
  createMockEC2Client,
  createMockS3Client,
  createMockRDSClient,
  createMockCloudFrontClient,
  
  // Middleware
  createMockAuthMiddleware,
  createMockRoleMiddleware,
  createMockErrorHandler,
  
  // HTTP
  mockFetch,
  createMockAxios,
  
  // File System
  mockFs,
  mockPath,
  
  // Utilities
  createMockLogger,
  createMockValidator,
  createMockCache,
  
  // Spy helpers
  createSpy,
  spyOnConstructor,
  mockModule,
  
  // Mock configs
  mockEnvironment,
  mockProcess,
  
  // Setup/Teardown
  setupAllMocks,
  clearAllMocks,
  restoreAllMocks,
  
  // Association mocks
  createMockApp,
  createMockRouter,
  createMockSession,
  createMockCookie,
};
