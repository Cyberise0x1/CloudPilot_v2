/**
 * Test Database Utilities
 * Provides setup, cleanup, and helper functions for database testing
 */

import { Pool } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import { neon } from '@neondatabase/serverless';
import * as schema from '@shared/schema';
import { beforeAll, afterAll, beforeEach, afterEach } from 'vitest';
import { sql } from 'drizzle-orm';

// Test database configuration
export const TEST_DATABASE_URL = process.env.TEST_DATABASE_URL || 
  'postgres://user:password@localhost:5432/test_db';

// In-memory test database for isolated tests
export const createTestDatabase = async () => {
  const sql = neon(TEST_DATABASE_URL);
  const db = drizzle(sql);
  return db;
};

// Database connection pool for tests
let testPool: Pool | null = null;

/**
 * Setup test database connection
 * Should be called in beforeAll hook
 */
export const setupTestDatabase = async () => {
  if (!testPool) {
    testPool = new Pool({ 
      connectionString: TEST_DATABASE_URL,
      // Configure for test environment
      max: 5,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000,
    });
  }
  return testPool;
};

/**
 * Get test database instance
 */
export const getTestDatabase = () => {
  if (!testPool) {
    throw new Error('Test database not initialized. Call setupTestDatabase() first.');
  }
  return drizzle(testPool, { schema });
};

/**
 * Clean database before test suite
 */
export const cleanDatabase = async () => {
  const db = getTestDatabase();
  
  // Disable foreign key checks temporarily
  await db.execute(sql`SET session_replication_role = replica;`);
  
  try {
    // Truncate all tables in reverse dependency order
    await db.execute(sql`TRUNCATE TABLE refresh_tokens, ec2_instances, s3_buckets, rds_instances, cloudfront_distributions, instance_templates, aws_accounts, users CASCADE;`);
  } finally {
    // Re-enable foreign key checks
    await db.execute(sql`SET session_replication_role = DEFAULT;`);
  }
};

/**
 * Clean database after each test
 */
export const cleanDatabaseAfterEach = async () => {
  await cleanDatabase();
};

/**
 * Setup database with test data
 */
export const setupDatabaseWithTestData = async () => {
  const db = getTestDatabase();
  
  // Create test users
  const testUsers = [
    {
      id: 'test-admin-1',
      email: 'admin@test.com',
      passwordHash: '$2a$10$testhashadmin',
      fullName: 'Test Admin',
      role: 'admin' as const,
      isActive: true,
    },
    {
      id: 'test-user-1',
      email: 'user@test.com',
      passwordHash: '$2a$10$testhashuser',
      fullName: 'Test User',
      role: 'user' as const,
      isActive: true,
    },
    {
      id: 'test-manager-1',
      email: 'manager@test.com',
      passwordHash: '$2a$10$testhashmanager',
      fullName: 'Test Manager',
      role: 'manager' as const,
      isActive: true,
    },
  ];
  
  await db.insert(schema.users).values(testUsers);
  
  // Create test AWS account
  const testAccount = {
    id: 'test-account-1',
    name: 'Test AWS Account',
    accessKeyId: 'AKIAIOSFODNN7EXAMPLE',
    secretAccessKey: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
    isActive: true,
  };
  
  await db.insert(schema.awsAccounts).values(testAccount);
  
  return {
    testUsers,
    testAccount,
  };
};

/**
 * Rollback database changes after test
 */
export const rollbackDatabase = async () => {
  // This is a placeholder for transaction rollback if using transactional tests
  await cleanDatabase();
};

/**
 * Database transaction helpers for tests
 */
export const withTransaction = async <T>(
  callback: (db: any) => Promise<T>
): Promise<T> => {
  const db = getTestDatabase();
  
  try {
    await db.execute(sql`BEGIN`);
    const result = await callback(db);
    await db.execute(sql`COMMIT`);
    return result;
  } catch (error) {
    await db.execute(sql`ROLLBACK`);
    throw error;
  }
};

/**
 * Seed database with specific test data
 */
export const seedDatabase = async (seedData: {
  users?: Array<typeof schema.users.$inferInsert>;
  awsAccounts?: Array<typeof schema.awsAccounts.$inferInsert>;
  ec2Instances?: Array<typeof schema.ec2Instances.$inferInsert>;
  s3Buckets?: Array<typeof schema.s3Buckets.$inferInsert>;
  rdsInstances?: Array<typeof schema.rdsInstances.$inferInsert>;
}) => {
  const db = getTestDatabase();
  
  if (seedData.users) {
    await db.insert(schema.users).values(seedData.users);
  }
  
  if (seedData.awsAccounts) {
    await db.insert(schema.awsAccounts).values(seedData.awsAccounts);
  }
  
  if (seedData.ec2Instances) {
    await db.insert(schema.ec2Instances).values(seedData.ec2Instances);
  }
  
  if (seedData.s3Buckets) {
    await db.insert(schema.s3Buckets).values(seedData.s3Buckets);
  }
  
  if (seedData.rdsInstances) {
    await db.insert(schema.rdsInstances).values(seedData.rdsInstances);
  }
};

/**
 * Verify database state after operations
 */
export const verifyDatabaseState = async (checks: {
  usersCount?: number;
  awsAccountsCount?: number;
  ec2InstancesCount?: number;
  s3BucketsCount?: number;
  rdsInstancesCount?: number;
}) => {
  const db = getTestDatabase();
  
  if (checks.usersCount !== undefined) {
    const result = await db.select().from(schema.users);
    if (result.length !== checks.usersCount) {
      throw new Error(`Expected ${checks.usersCount} users, got ${result.length}`);
    }
  }
  
  if (checks.awsAccountsCount !== undefined) {
    const result = await db.select().from(schema.awsAccounts);
    if (result.length !== checks.awsAccountsCount) {
      throw new Error(`Expected ${checks.awsAccountsCount} AWS accounts, got ${result.length}`);
    }
  }
  
  if (checks.ec2InstancesCount !== undefined) {
    const result = await db.select().from(schema.ec2Instances);
    if (result.length !== checks.ec2InstancesCount) {
      throw new Error(`Expected ${checks.ec2InstancesCount} EC2 instances, got ${result.length}`);
    }
  }
  
  if (checks.s3BucketsCount !== undefined) {
    const result = await db.select().from(schema.s3Buckets);
    if (result.length !== checks.s3BucketsCount) {
      throw new Error(`Expected ${checks.s3BucketsCount} S3 buckets, got ${result.length}`);
    }
  }
  
  if (checks.rdsInstancesCount !== undefined) {
    const result = await db.select().from(schema.rdsInstances);
    if (result.length !== checks.rdsInstancesCount) {
      throw new Error(`Expected ${checks.rdsInstancesCount} RDS instances, got ${result.length}`);
    }
  }
};

/**
 * Close test database connection
 * Should be called in afterAll hook
 */
export const closeTestDatabase = async () => {
  if (testPool) {
    await testPool.end();
    testPool = null;
  }
};

/**
 * Hooks for automatic database setup/teardown
 */
export const createDatabaseHooks = () => {
  beforeAll(async () => {
    await setupTestDatabase();
    await cleanDatabase();
  });
  
  beforeEach(async () => {
    await cleanDatabaseAfterEach();
  });
  
  afterEach(async () => {
    // Optional: verify database state after each test
  });
  
  afterAll(async () => {
    await closeTestDatabase();
  });
};

export default {
  setupTestDatabase,
  getTestDatabase,
  cleanDatabase,
  cleanDatabaseAfterEach,
  setupDatabaseWithTestData,
  rollbackDatabase,
  withTransaction,
  seedDatabase,
  verifyDatabaseState,
  closeTestDatabase,
  createDatabaseHooks,
};
