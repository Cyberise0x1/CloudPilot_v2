/**
 * Example Test File
 * Demonstrates how to use the test utilities in a real test scenario
 */

import { describe, it, expect, vi } from 'vitest';
import { Request, Response, NextFunction } from 'express';
import {
  // Hooks setup
  createTestHooks,
  
  // Database
  setupTestDatabase,
  cleanDatabase,
  getTestDatabase,
  seedDatabase,
  
  // Auth
  TEST_USERS,
  createMockMiddlewareContext,
  generateAccessToken,
  simulateLogin,
  
  // AWS
  setupAllAWSMocks,
  resetAWSMocks,
  MOCK_EC2_RESPONSES,
  
  // Fixtures
  USER_FIXTURES,
  EC2_INSTANCE_FIXTURES,
  createUserFixture,
  
  // Mocks
  createMockRequest,
  createMockResponse,
  createMockNext,
  
  // Utilities
  expectResponseStatus,
  expectResponseMessage,
  formatDate,
  generateRandomEmail,
} from './index';

// =============================================================================
// EXAMPLE 1: Basic Test with Authentication
// =============================================================================

describe('Authentication Middleware - Basic Example', () => {
  const hooks = createTestHooks();
  
  hooks.beforeAll();
  hooks.beforeEach();
  hooks.afterEach();
  hooks.afterAll();

  it('should allow access with valid admin token', () => {
    // Use the mock middleware context helper
    const { req, res, next } = createMockMiddlewareContext(TEST_USERS.ADMIN);
    
    // Simulate middleware processing
    const middleware = (req: Request, res: Response, next: NextFunction) => {
      if (req.headers.authorization) {
        req.user = {
          id: 'admin-123',
          email: 'admin@test.com',
          username: 'admin',
          role: 'admin' as any,
        };
        next();
      } else {
        res.status(401).json({ message: 'Unauthorized' });
      }
    };
    
    middleware(req, res, next);
    
    // Assert using our custom helpers
    expect(next).toHaveBeenCalled();
    expect(req.user).toBeDefined();
    expect(req.user?.role).toBe('admin');
  });

  it('should deny access without authentication', () => {
    const { req, res, next } = createMockMiddlewareContext();
    
    const middleware = (req: Request, res: Response, next: NextFunction) => {
      if (req.headers.authorization) {
        next();
      } else {
        res.status(401).json({ message: 'Authorization header is required' });
      }
    };
    
    middleware(req, res, next);
    
    // Use our response assertion helper
    expectResponseStatus(res, 401);
    expectResponseMessage(res, 'Authorization header is required');
    expect(next).not.toHaveBeenCalled();
  });

  it('should handle expired tokens', () => {
    const { req, res, next } = createMockMiddlewareContext(TEST_USERS.ADMIN, {
      includeExpiredToken: true
    });
    
    middleware(req, res, next);
    
    expectResponseStatus(res, 401);
    expect(next).not.toHaveBeenCalled();
  });
});

// =============================================================================
// EXAMPLE 2: Database Testing
// =============================================================================

describe('User Service - Database Example', () => {
  const hooks = createTestHooks();
  
  hooks.beforeAll(async () => {
    await setupTestDatabase();
  });
  
  hooks.beforeEach(async () => {
    await cleanDatabase();
    // Seed with test data
    await seedDatabase({
      users: [
        USER_FIXTURES.ADMIN,
        USER_FIXTURES.USER,
        {
          id: 'user-123',
          email: 'test@example.com',
          passwordHash: 'hashedpassword',
          fullName: 'Test User',
          role: 'user' as any,
          isActive: true,
          createdAt: new Date(),
          updatedAt: new Date(),
        }
      ],
    });
  });
  
  hooks.afterEach(async () => {
    // Database is already cleaned in beforeEach
  });
  
  hooks.afterAll(async () => {
    await getTestDatabase().destroy?.(); // Close connection if needed
  });

  it('should find users by email', async () => {
    const db = getTestDatabase();
    
    // Mock the database query for testing
    const mockSelect = vi.fn().mockReturnValue({
      from: vi.fn().mockReturnValue({
        where: vi.fn().mockResolvedValue([USER_FIXTURES.ADMIN])
      })
    });
    
    vi.mocked(mockSelect).from().where.mockResolvedValue([USER_FIXTURES.ADMIN]);
    
    // Your actual service method would use the real database
    const users = await mockSelect.from('users').where({ email: 'admin@example.com' });
    
    expect(users).toBeDefined();
    expect(Array.isArray(users)).toBe(true);
  });

  it('should create new user with fixture data', async () => {
    const newUser = createUserFixture({
      email: 'newuser@example.com',
      role: 'user' as any,
    });
    
    // Simulate database insertion
    const mockInsert = vi.fn().mockResolvedValue([newUser]);
    
    const result = await mockInsert('users', newUser);
    
    expect(result).toHaveLength(1);
    expect(result[0].email).toBe('newuser@example.com');
  });
});

// =============================================================================
// EXAMPLE 3: AWS Service Testing
// =============================================================================

describe('AWS EC2 Service - Example', () => {
  const hooks = createTestHooks();
  
  hooks.beforeAll(() => {
    setupAllAWSMocks();
  });
  
  hooks.afterAll(() => {
    resetAWSMocks();
  });

  it('should list EC2 instances', async () => {
    // Mock EC2 client
    const mockEC2Client = {
      send: vi.fn().mockResolvedValue(MOCK_EC2_RESPONSES.DESCRIBE_INSTANCES),
    };
    
    // Your service method
    const listInstances = async (ec2Client: any) => {
      const result = await ec2Client.send('DescribeInstancesCommand', {});
      return result.Reservations?.flatMap((r: any) => r.Instances) || [];
    };
    
    const instances = await listInstances(mockEC2Client);
    
    expect(instances).toBeDefined();
    expect(instances).toHaveLength(1);
    expect(instances[0]).toHaveProperty('InstanceId', 'i-1234567890abcdef0');
    expect(instances[0]).toHaveProperty('State', expect.objectContaining({ Name: 'running' }));
  });

  it('should handle AWS errors gracefully', async () => {
    const mockEC2Client = {
      send: vi.fn().mockRejectedValue(new Error('AWS service unavailable')),
    };
    
    const listInstances = async (ec2Client: any) => {
      try {
        return await ec2Client.send('DescribeInstancesCommand', {});
      } catch (error) {
        throw new Error(`Failed to list instances: ${error.message}`);
      }
    };
    
    await expect(listInstances(mockEC2Client)).rejects.toThrow('Failed to list instances');
  });
});

// =============================================================================
// EXAMPLE 4: Complete Integration Test
// =============================================================================

describe('User Service Integration - Complete Example', () => {
  const hooks = createTestHooks();
  
  hooks.beforeAll(async () => {
    await setupTestDatabase();
    setupAllAWSMocks();
  });
  
  hooks.beforeEach(async () => {
    await cleanDatabase();
  });
  
  hooks.afterAll(async () => {
    resetAWSMocks();
  });

  it('should complete user login flow', async () => {
    // 1. Setup test data
    const testUser = {
      ...TEST_USERS.USER,
      passwordHash: '$2a$10$hashedpassword123', // Mock hashed password
    };
    
    await seedDatabase({ users: [testUser] });
    
    // 2. Simulate login
    const loginResult = await simulateLogin(testUser.email, testUser.password);
    
    expect(loginResult.success).toBe(true);
    expect(loginResult.user).toBeDefined();
    expect(loginResult.accessToken).toBeDefined();
    expect(loginResult.refreshToken).toBeDefined();
    
    // 3. Test token verification
    const token = loginResult.accessToken;
    const mockJwt = {
      verify: vi.fn().mockReturnValue({
        id: testUser.id,
        email: testUser.email,
        username: testUser.username,
        role: testUser.role,
      })
    };
    
    const decoded = mockJwt.verify(token, 'test-secret');
    
    expect(decoded).toBeDefined();
    expect(decoded.id).toBe(testUser.id);
    expect(decoded.email).toBe(testUser.email);
    expect(decoded.role).toBe(testUser.role);
    
    // 4. Test authenticated request
    const { req, res, next } = createMockMiddlewareContext(testUser);
    
    const middleware = (req: Request, res: Response, next: NextFunction) => {
      if (req.user?.role === 'user' || req.user?.role === 'admin') {
        next();
      } else {
        res.status(403).json({ message: 'Forbidden' });
      }
    };
    
    middleware(req, res, next);
    
    expect(next).toHaveBeenCalled();
    expect(req.user).toBeDefined();
  });

  it('should handle database and AWS operations together', async () => {
    // Setup users and AWS accounts
    await seedDatabase({
      users: [TEST_USERS.ADMIN, TEST_USERS.USER],
      awsAccounts: [{
        id: 'aws-account-1',
        name: 'Test AWS Account',
        accessKeyId: 'AKIAIOSFODNN7EXAMPLE',
        secretAccessKey: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
        isActive: true,
        createdAt: new Date(),
      }],
    });
    
    // Mock AWS EC2 service
    const mockEC2Client = {
      send: vi.fn().mockResolvedValue(MOCK_EC2_RESPONSES.DESCRIBE_INSTANCES),
    };
    
    // Simulate a complete workflow
    const workflow = async () => {
      // 1. Authenticate (simulated)
      const authUser = TEST_USERS.ADMIN;
      
      // 2. Query database (simulated)
      const mockUsers = [authUser];
      
      // 3. Query AWS (simulated)
      const instances = await mockEC2Client.send('DescribeInstancesCommand', {});
      
      // 4. Return combined result
      return {
        user: authUser,
        users: mockUsers,
        instances: instances.Reservations?.flatMap((r: any) => r.Instances) || [],
      };
    };
    
    const result = await workflow();
    
    expect(result.user).toBeDefined();
    expect(result.users).toHaveLength(1);
    expect(result.instances).toHaveLength(1);
  });
});

// =============================================================================
// EXAMPLE 5: Utility Functions Testing
// =============================================================================

describe('Utility Functions - Examples', () => {
  it('should format dates correctly', () => {
    const date = new Date('2024-01-15T10:30:00Z');
    
    const iso = formatDate(date, 'iso');
    const timestamp = formatDate(date, 'timestamp');
    const locale = formatDate(date, 'locale');
    
    expect(iso).toBe('2024-01-15T10:30:00.000Z');
    expect(typeof timestamp).toBe('number');
    expect(locale).toBeDefined();
  });

  it('should generate random data', () => {
    const email = generateRandomEmail();
    
    expect(email).toMatch(/^[a-z0-9]{8}@example\.com$/);
    expect(email).not.toBe(generateRandomEmail()); // Should be different
  });

  it('should use fixtures consistently', () => {
    const admin = USER_FIXTURES.ADMIN;
    const ec2Instance = EC2_INSTANCE_FIXTURES.RUNNING;
    
    expect(admin).toHaveProperty('role', 'admin');
    expect(admin).toHaveProperty('email', 'admin@example.com');
    
    expect(ec2Instance).toHaveProperty('state', 'running');
    expect(ec2Instance).toHaveProperty('instanceType', 't2.micro');
  });

  it('should create custom fixtures', () => {
    const customUser = createUserFixture({
      email: 'custom@test.com',
      role: 'manager' as any,
      isActive: false,
    });
    
    expect(customUser.email).toBe('custom@test.com');
    expect(customUser.role).toBe('manager');
    expect(customUser.isActive).toBe(false);
    expect(customUser).toHaveProperty('passwordHash');
    expect(customUser).toHaveProperty('createdAt');
  });
});

// =============================================================================
// EXAMPLE 6: Error Handling and Edge Cases
// =============================================================================

describe('Error Handling - Examples', () => {
  it('should handle malformed requests', () => {
    const malformedReq = createMockRequest({
      body: { invalid: 'data' },
      params: { id: 'invalid-id' },
    });
    
    const res = createMockResponse();
    const next = createMockNext();
    
    // Simulate validation middleware
    const validateMiddleware = (req: Request, res: Response, next: NextFunction) => {
      if (!req.body.email) {
        return res.status(400).json({ message: 'Email is required' });
      }
      next();
    };
    
    validateMiddleware(malformedReq, res, next);
    
    expectResponseStatus(res, 400);
    expectResponseMessage(res, 'Email is required');
  });

  it('should handle AWS service failures', async () => {
    const failingEC2Client = {
      send: vi.fn().mockRejectedValue(new Error('Service temporarily unavailable')),
    };
    
    const retryWithFallback = async (client: any) => {
      try {
        return await client.send('DescribeInstancesCommand', {});
      } catch (error) {
        // Return fallback data
        return { Reservations: [] };
      }
    };
    
    const result = await retryWithFallback(failingEC2Client);
    
    expect(result).toBeDefined();
    expect(result.Reservations).toEqual([]);
  });
});

// =============================================================================
// EXAMPLE 7: Mock Setup and Cleanup
// =============================================================================

describe('Mock Management - Examples', () => {
  let mockFn: ReturnType<typeof vi.fn>;
  
  beforeEach(() => {
    mockFn = vi.fn();
  });
  
  afterEach(() => {
    vi.clearAllMocks();
  });

  it('should properly mock and clear functions', () => {
    mockFn.mockReturnValue('mocked result');
    
    const result = mockFn();
    
    expect(result).toBe('mocked result');
    expect(mockFn).toHaveBeenCalledTimes(1);
    
    // Clear mocks for next test
    vi.clearAllMocks();
  });

  it('should have clean state after clearing', () => {
    expect(mockFn).not.toHaveBeenCalled();
    
    mockFn.mockReturnValue('new result');
    expect(mockFn).toHaveBeenCalledTimes(1);
    
    // Clear for next test
    vi.clearAllMocks();
  });
});

// =============================================================================
// EXAMPLE 8: Test with Multiple Roles
// =============================================================================

describe('Role-Based Access Control - Examples', () => {
  const hooks = createTestHooks();
  
  hooks.beforeEach();
  hooks.afterEach();

  it('should enforce role hierarchy', () => {
    const roles = ['viewer', 'user', 'manager', 'admin'];
    
    const checkAccess = (userRole: string, requiredRole: string) => {
      const roleHierarchy = ['viewer', 'user', 'manager', 'admin'];
      const userLevel = roleHierarchy.indexOf(userRole);
      const requiredLevel = roleHierarchy.indexOf(requiredRole);
      
      return userLevel >= requiredLevel;
    };
    
    // Admin can access everything
    expect(checkAccess('admin', 'viewer')).toBe(true);
    expect(checkAccess('admin', 'user')).toBe(true);
    expect(checkAccess('admin', 'manager')).toBe(true);
    expect(checkAccess('admin', 'admin')).toBe(true);
    
    // User cannot access manager or admin
    expect(checkAccess('user', 'viewer')).toBe(true);
    expect(checkAccess('user', 'user')).toBe(true);
    expect(checkAccess('user', 'manager')).toBe(false);
    expect(checkAccess('user', 'admin')).toBe(false);
    
    // Viewer can only access viewer
    expect(checkAccess('viewer', 'viewer')).toBe(true);
    expect(checkAccess('viewer', 'user')).toBe(false);
    expect(checkAccess('viewer', 'manager')).toBe(false);
    expect(checkAccess('viewer', 'admin')).toBe(false);
  });

  it('should test middleware with different roles', () => {
    const testRoleAccess = (userRole: string, requiredRole: string) => {
      const user = { ...TEST_USERS.USER, role: userRole };
      const { req, res, next } = createMockMiddlewareContext(user);
      
      const middleware = (req: Request, res: Response, next: NextFunction) => {
        const roleHierarchy = ['viewer', 'user', 'manager', 'admin'];
        const userLevel = roleHierarchy.indexOf(userRole);
        const requiredLevel = roleHierarchy.indexOf(requiredRole);
        
        if (userLevel >= requiredLevel) {
          next();
        } else {
          res.status(403).json({ message: 'Insufficient permissions' });
        }
      };
      
      middleware(req, res, next);
      return { allowed: next.mock.calls.length > 0 };
    };
    
    expect(testRoleAccess('admin', 'user').allowed).toBe(true);
    expect(testRoleAccess('user', 'admin').allowed).toBe(false);
    expect(testRoleAccess('viewer', 'viewer').allowed).toBe(true);
  });
});
