/**
 * Global test setup and configuration
 */

import { vi } from 'vitest';
import { config } from '@vitest/ui';

// Extend expect matchers if needed
expect.extend({
  // Custom matchers can be added here
});

// Global test setup
beforeAll(() => {
  // Set test environment variables
  process.env.NODE_ENV = 'test';
  process.env.TZ = 'UTC';
  
  // Mock console methods in test environment to reduce noise
  vi.spyOn(console, 'log').mockImplementation(() => {});
  vi.spyOn(console, 'info').mockImplementation(() => {});
  vi.spyOn(console, 'warn').mockImplementation(() => {});
  
  // Keep console.error and console.debug for debugging failed tests
  // vi.spyOn(console, 'error').mockImplementation(() => {});
  // vi.spyOn(console, 'debug').mockImplementation(() => {});
});

afterEach(() => {
  // Clear all mocks after each test
  vi.clearAllMocks();
  vi.clearAllTimers();
});

afterAll(() => {
  // Restore all mocks after all tests
  vi.restoreAllMocks();
});

// Global test configuration
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: vi.fn().mockImplementation(query => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: vi.fn(), // deprecated
    removeListener: vi.fn(), // deprecated
    addEventListener: vi.fn(),
    removeEventListener: vi.fn(),
    dispatchEvent: vi.fn(),
  })),
});

// Mock fetch globally for tests that need it
if (!global.fetch) {
  global.fetch = vi.fn();
}

// Mock WebSocket for tests that need it
if (typeof WebSocket === 'undefined') {
  global.WebSocket = vi.fn();
}

// Set up timers
vi.useFakeTimers();

// Helper functions for tests
export const createMockRequest = (overrides = {}) => ({
  method: 'GET',
  url: '/test',
  headers: {},
  params: {},
  query: {},
  body: {},
  ip: '127.0.0.1',
  user: null,
  ...overrides
});

export const createMockResponse = () => {
  const res: any = {
    status: vi.fn().mockReturnThis(),
    json: vi.fn().mockReturnThis(),
    send: vi.fn().mockReturnThis(),
    end: vi.fn().mockReturnThis(),
    setHeader: vi.fn().mockReturnThis(),
    getHeader: vi.fn(),
    locals: {}
  };
  return res;
};

export const createMockNext = () => vi.fn();

// Helper to wait for async operations in tests
export const waitFor = (condition: () => boolean, timeout = 1000) => {
  return new Promise((resolve, reject) => {
    const startTime = Date.now();
    const check = () => {
      if (condition()) {
        resolve(true);
      } else if (Date.now() - startTime > timeout) {
        reject(new Error('Timeout waiting for condition'));
      } else {
        setTimeout(check, 10);
      }
    };
    check();
  });
};

// Helper to create test data
export const createTestUser = (overrides = {}) => ({
  id: 'test-user-1',
  email: 'test@example.com',
  password: 'hashedPassword123',
  role: 'user',
  createdAt: new Date(),
  updatedAt: new Date(),
  isActive: true,
  ...overrides
});

export const createTestAWSAccount = (overrides = {}) => ({
  id: 'test-aws-account-1',
  name: 'Test AWS Account',
  accessKeyId: 'AKIA_TEST_ACCESS_KEY',
  secretAccessKey: 'mockedSecretKey',
  region: 'us-east-1',
  isActive: true,
  createdAt: new Date(),
  updatedAt: new Date(),
  ...overrides
});

export const createTestEC2Instance = (overrides = {}) => ({
  id: 'test-ec2-1',
  instanceId: 'i-test1234567890abcdef0',
  awsAccountId: 'test-aws-account-1',
  name: 'Test EC2 Instance',
  state: 'running',
  type: 't2.micro',
  region: 'us-east-1',
  availabilityZone: 'us-east-1a',
  vpcId: 'vpc-test123',
  subnetId: 'subnet-test123',
  createdAt: new Date(),
  updatedAt: new Date(),
  ...overrides
});

// Mock external services
export const mockAWSService = {
  EC2: {
    describeInstances: vi.fn().mockResolvedValue({
      Reservations: [
        {
          Instances: [
            {
              InstanceId: 'i-test123',
              State: { Name: 'running' },
              InstanceType: 't2.micro',
              PublicIpAddress: '1.2.3.4',
              PrivateIpAddress: '10.0.0.1'
            }
          ]
        }
      ]
    })
  },
  S3: {
    listBuckets: vi.fn().mockResolvedValue({
      Buckets: [
        { Name: 'test-bucket-1', CreationDate: new Date() },
        { Name: 'test-bucket-2', CreationDate: new Date() }
      ]
    })
  },
  RDS: {
    describeDBInstances: vi.fn().mockResolvedValue({
      DBInstances: [
        {
          DBInstanceIdentifier: 'test-db-1',
          DBInstanceStatus: 'available',
          Engine: 'postgresql',
          InstanceCreateTime: new Date()
        }
      ]
    })
  },
  CloudFront: {
    listDistributions: vi.fn().mockResolvedValue({
      DistributionList: {
        Items: [
          {
            Id: 'E1234567890ABC',
            Status: 'Deployed',
            DomainName: 'd123.cloudfront.net'
          }
        ]
      }
    })
  }
};

// Mock database
export const mockDatabase = {
  query: vi.fn(),
  execute: vi.fn().mockResolvedValue({
    rows: [],
    rowCount: 0
  }),
  transaction: vi.fn(async (callback) => {
    const mockTx = {
      query: vi.fn(),
      execute: vi.fn()
    };
    return callback(mockTx);
  })
};

// Mock secrets manager
export const mockSecretsManager = {
  getSecret: vi.fn((key) => {
    const secrets: Record<string, string> = {
      'AWS_ACCESS_KEY_ID': 'test-access-key',
      'AWS_SECRET_ACCESS_KEY': 'test-secret-key',
      'AWS_REGION': 'us-east-1',
      'JWT_SECRET': 'test-jwt-secret',
      'DATABASE_URL': 'postgresql://test:test@localhost:5432/test'
    };
    return secrets[key];
  }),
  getStatistics: vi.fn().mockReturnValue({
    totalSecrets: 5,
    validatedSecrets: 5,
    lastValidated: new Date()
  }),
  refreshSecrets: vi.fn().mockResolvedValue(undefined)
};

// Mock metrics
export const mockMetrics = {
  trackRequest: vi.fn(),
  trackAwsOperation: vi.fn(),
  trackBusinessEvent: {
    userRegistration: vi.fn(),
    userLogin: vi.fn(),
    apiCall: vi.fn(),
    dbQuery: vi.fn(),
    cacheHit: vi.fn(),
    cacheMiss: vi.fn()
  },
  getDashboardData: vi.fn().mockReturnValue({
    timestamp: Date.now(),
    realTimeMetrics: {
      requestsPerSecond: 10,
      averageResponseTime: 150,
      errorRate: 0.02,
      activeConnections: 5,
      memoryUsage: 500000000
    },
    aggregatedMetrics: {
      totalRequests: 1000,
      totalErrors: 20,
      averageResponseTime: 145,
      p95ResponseTime: 300,
      p99ResponseTime: 500,
      requestRateByEndpoint: {},
      errorRateByEndpoint: {},
      topErrors: []
    },
    systemMetrics: {
      memory: {
        used: 1000000000,
        total: 2000000000,
        percentage: 50,
        heapUsed: 800000000,
        heapTotal: 1000000000,
        external: 100000000
      },
      cpu: {
        usage: 25,
        loadAverage: [1, 2, 3]
      },
      activeConnections: 5,
      uptime: 3600,
      eventLoopLag: 1
    },
    businessMetrics: {
      user_registrations: 100,
      user_logins: 500,
      api_calls: 1000,
      db_queries: 2500,
      cache_hits: 800,
      cache_misses: 200,
      file_uploads: 50,
      emails_sent: 150,
      errors_total: 20,
      successful_operations: 980
    }
  })
};

// Mock error tracking
export const mockErrorTracking = {
  trackError: vi.fn().mockResolvedValue({
    id: 'test-error-1',
    message: 'Test error',
    metadata: {
      category: 'application',
      severity: 'medium',
      timestamp: new Date(),
      endpoint: '/test'
    },
    fingerprint: 'test-fingerprint',
    count: 1,
    firstOccurrence: new Date(),
    lastOccurrence: new Date(),
    status: 'active'
  }),
  trackRequest: vi.fn(),
  getActiveErrors: vi.fn().mockReturnValue([]),
  getErrors: vi.fn().mockReturnValue([]),
  resolveError: vi.fn().mockReturnValue(true),
  ignoreError: vi.fn().mockReturnValue(true),
  getPerformanceMetrics: vi.fn().mockReturnValue(new Map()),
  getErrorTrends: vi.fn().mockReturnValue({
    byCategory: new Map(),
    bySeverity: new Map(),
    hourlyDistribution: new Array(24).fill(0)
  }),
  getTopErrors: vi.fn().mockReturnValue([]),
  getErrorPatterns: vi.fn().mockReturnValue({
    frequentCombinations: [],
    timeBasedPatterns: []
  }),
  addAlertRule: vi.fn(),
  configureNotifications: vi.fn(),
  getAlertRules: vi.fn().mockReturnValue([]),
  getSystemStats: vi.fn().mockReturnValue({
    totalErrors: 0,
    activeErrors: 0,
    resolvedErrors: 0,
    ignoredErrors: 0,
    avgErrorRate: 0,
    topCategories: []
  })
};

// Export commonly used test utilities
export {
  vi,
  expect,
  beforeAll,
  beforeEach,
  afterAll,
  afterEach,
  describe,
  it,
  test,
  skip
};
