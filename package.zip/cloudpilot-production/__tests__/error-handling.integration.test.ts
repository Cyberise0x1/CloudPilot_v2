/**
 * Error Handling Integration Tests
 * Tests for error scenarios, validation, and edge cases across all API endpoints
 */

import { describe, it, expect, beforeAll, afterAll, beforeEach, afterEach } from 'vitest';
import request from 'supertest';
import { app } from '../server/index';

describe('Error Handling Integration Tests', () => {
  let authToken: string;

  beforeAll(async () => {
    // Login to get authentication token for protected endpoints
    try {
      const loginResponse = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'test@example.com',
          password: 'TestPassword123!'
        });

      if (loginResponse.status === 200) {
        authToken = loginResponse.body.accessToken;
      }
    } catch (error) {
      // Auth might not be available during testing
    }
  });

  describe('Authentication Error Handling', () => {
    describe('Invalid Tokens', () => {
      it('should return 401 for malformed JWT token', async () => {
        const response = await request(app)
          .get('/api/aws-accounts')
          .set('Authorization', 'Bearer malformed-token');

        expect(response.status).toBe(401);
        expect(response.body).toHaveProperty('message');
      });

      it('should return 401 for expired JWT token', async () => {
        const response = await request(app)
          .get('/api/aws-accounts')
          .set('Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.expired');

        expect(response.status).toBe(401);
      });

      it('should return 401 for malformed authorization header', async () => {
        const response = await request(app)
          .get('/api/aws-accounts')
          .set('Authorization', 'InvalidFormat token');

        expect(response.status).toBe(401);
      });

      it('should return 401 for missing authorization header', async () => {
        const response = await request(app)
          .get('/api/aws-accounts');

        expect(response.status).toBe(401);
      });
    });

    describe('Authorization Edge Cases', () => {
      it('should handle very long authorization headers', async () => {
        const longToken = 'a'.repeat(10000);
        const response = await request(app)
          .get('/api/aws-accounts')
          .set('Authorization', `Bearer ${longToken}`);

        expect([400, 401, 413]).toContain(response.status);
      });

      it('should handle special characters in authorization header', async () => {
        const response = await request(app)
          .get('/api/aws-accounts')
          .set('Authorization', 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.<script>alert("xss")</script>');

        expect(response.status).toBe(401);
      });
    });
  });

  describe('Validation Error Handling', () => {
    describe('Request Body Validation', () => {
      it('should reject requests with invalid JSON', async () => {
        const response = await request(app)
          .post('/api/auth/register')
          .set('Content-Type', 'application/json')
          .send('{ invalid json }');

        expect([400, 500]).toContain(response.status);
      });

      it('should reject requests with missing content type for JSON endpoints', async () => {
        const response = await request(app)
          .post('/api/auth/register')
          .send('plain text');

        expect([400, 415, 500]).toContain(response.status);
      });

      it('should handle oversized request bodies', async () => {
        const largeObject = {
          data: 'a'.repeat(10 * 1024 * 1024) // 10MB
        };

        const response = await request(app)
          .post('/api/auth/register')
          .send(largeObject);

        expect([400, 413, 422]).toContain(response.status);
      });

      it('should reject requests with invalid field types', async () => {
        const response = await request(app)
          .post('/api/auth/register')
          .send({
            email: 123, // Should be string
            password: true, // Should be string
            fullName: null // Should be string
          });

        expect(response.status).toBe(400);
      });
    });

    describe('Parameter Validation', () => {
      it('should reject invalid UUID parameters', async () => {
        const response = await request(app)
          .get('/api/aws/instances/invalid-uuid/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`);

        expect([400, 404, 500]).toContain(response.status);
      });

      it('should handle very long path parameters', async () => {
        const longParam = 'a'.repeat(2000);
        const response = await request(app)
          .get(`/api/aws/instances/${longParam}/us-east-1/test-account-id`)
          .set('Authorization', `Bearer ${authToken}`);

        expect([400, 414, 500]).toContain(response.status);
      });

      it('should reject invalid region names', async () => {
        const response = await request(app)
          .get('/api/aws/instances/invalid-region-name-123/test-account-id')
          .set('Authorization', `Bearer ${authToken}`);

        expect([400, 500]).toContain(response.status);
      });
    });

    describe('Query Parameter Validation', () => {
      it('should handle invalid date formats in query parameters', async () => {
        const response = await request(app)
          .get('/api/monitoring/metrics?start_time=invalid-date-format')
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200); // Should handle gracefully
      });

      it('should handle negative numeric query parameters', async () => {
        const response = await request(app)
          .get('/api/monitoring/metrics?limit=-1')
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200); // Should handle gracefully
      });

      it('should handle non-numeric parameters where numbers are expected', async () => {
        const response = await request(app)
          .get('/api/monitoring/metrics?limit=abc')
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200); // Should handle gracefully
      });
    });
  });

  describe('Resource Not Found Errors', () => {
    it('should return 404 for non-existent AWS account', async () => {
      const response = await request(app)
        .get('/api/aws-accounts')
        .set('Authorization', `Bearer ${authToken}`);

      // This depends on implementation - might return empty array or 404
      expect([200, 404]).toContain(response.status);
    });

    it('should return 404 for non-existent instance', async () => {
      const response = await request(app)
        .get('/api/aws/instances/i-1234567890abcdef0/details/us-east-1/test-account-id')
        .set('Authorization', `Bearer ${authToken}`);

      expect([404, 500]).toContain(response.status);
    });

    it('should return 404 for non-existent route', async () => {
      const response = await request(app)
        .get('/api/non-existent-endpoint');

      expect(response.status).toBe(404);
    });

    it('should return 404 for malformed route paths', async () => {
      const response = await request(app)
        .get('/api/aws/instances///multiple//slashes///');

      expect([400, 404]).toContain(response.status);
    });
  });

  describe('Method Not Allowed Errors', () => {
    it('should return 405 for unsupported HTTP methods', async () => {
      const response = await request(app)
        .patch('/api/auth/login');

      expect([405, 404]).toContain(response.status);
    });

    it('should return 405 for unsupported methods on existing routes', async () => {
      const response = await request(app)
        .delete('/api/auth/login');

      expect([405, 404]).toContain(response.status);
    });
  });

  describe('Rate Limiting and Throttling', () => {
    it('should handle rapid successive requests', async () => {
      const requests = Array(50).fill(null).map(() =>
        request(app)
          .get('/api/health/status')
          .set('Authorization', `Bearer ${authToken}`)
      );

      const responses = await Promise.all(requests);
      
      responses.forEach(response => {
        expect([200, 429, 503]).toContain(response.status);
      });
    });

    it('should handle concurrent authentication attempts', async () => {
      const requests = Array(20).fill(null).map(() =>
        request(app)
          .post('/api/auth/login')
          .send({
            email: 'test@example.com',
            password: 'wrongpassword'
          })
      );

      const responses = await Promise.all(requests);
      
      responses.forEach(response => {
        expect([401, 429]).toContain(response.status);
      });
    });
  });

  describe('Server Error Handling', () => {
    it('should handle database connection errors gracefully', async () => {
      // This test would require simulating database failure
      // For now, we test that the server responds with proper error structure
      const response = await request(app)
        .get('/api/health/ready');

      expect([200, 503]).toContain(response.status);
      if (response.status === 503) {
        expect(response.body).toHaveProperty('status', 'not_ready');
        expect(response.body).toHaveProperty('error');
      }
    });

    it('should handle AWS service errors gracefully', async () => {
      // Simulate AWS API errors by using invalid credentials
      const response = await request(app)
        .post('/api/aws-accounts')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          accountName: 'Test Account',
          accessKeyId: 'invalid-key',
          secretAccessKey: 'invalid-secret',
          region: 'us-east-1'
        });

      expect(response.status).toBe(400);
      expect(response.body).toHaveProperty('message');
    });

    it('should return consistent error format', async () => {
      const invalidRequests = [
        { method: 'POST', path: '/api/auth/register', data: { invalid: 'data' } },
        { method: 'GET', path: '/api/non-existent-route' },
        { method: 'GET', path: '/api/aws-accounts' } // Without auth
      ];

      for (const req of invalidRequests) {
        const response = await request(app)
          [req.method.toLowerCase()](req.path)
          .send(req.data || {});

        expect(response.status).toBeGreaterThanOrEqual(400);
        expect(response.body).toHaveProperty('message');
      }
    });
  });

  describe('Input Sanitization', () => {
    it('should handle XSS attempts in request bodies', async () => {
      const xssPayloads = [
        '<script>alert("xss")</script>',
        '"><script>alert("xss")</script>',
        "'; DROP TABLE users; --",
        '${7*7}',
        '{{7*7}}'
      ];

      for (const payload of xssPayloads) {
        const response = await request(app)
          .post('/api/auth/register')
          .send({
            email: `${payload}@example.com`,
            password: 'TestPassword123!',
            fullName: payload
          });

        expect([400, 409]).toContain(response.status);
      }
    });

    it('should handle XSS attempts in query parameters', async () => {
      const xssPayload = '<script>alert("xss")</script>';
      const response = await request(app)
        .get(`/api/monitoring/metrics?metric_name=${encodeURIComponent(xssPayload)}`)
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200); // Should handle gracefully
    });

    it('should handle SQL injection attempts', async () => {
      const sqlPayloads = [
        "' OR '1'='1",
        "'; DROP TABLE users; --",
        "' UNION SELECT * FROM users --"
      ];

      for (const payload of sqlPayloads) {
        const response = await request(app)
          .post('/api/auth/login')
          .send({
            email: payload,
            password: 'anypassword'
          });

        expect([400, 401]).toContain(response.status);
      }
    });
  });

  describe('File Upload Error Handling', () => {
    it('should handle oversized file uploads', async () => {
      const largeFile = Buffer.alloc(50 * 1024 * 1024, 'a'); // 50MB file

      const response = await request(app)
        .post('/api/aws/s3/upload')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          bucketName: 'test-bucket',
          fileName: 'large-file.txt',
          fileContent: largeFile.toString('base64'),
          region: 'us-east-1',
          accountId: 'test-account-id'
        });

      expect([400, 413, 422]).toContain(response.status);
    });

    it('should handle invalid file content encoding', async () => {
      const response = await request(app)
        .post('/api/aws/s3/upload')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          bucketName: 'test-bucket',
          fileName: 'test.txt',
          fileContent: 'invalid-base64-content!@#$%',
          region: 'us-east-1',
          accountId: 'test-account-id'
        });

      expect([400, 422]).toContain(response.status);
    });
  });

  describe('Memory and Resource Limits', () => {
    it('should handle requests with very large JSON payloads', async () => {
      const largePayload = {
        data: Array(100000).fill('a'.repeat(1000))
      };

      const response = await request(app)
        .post('/api/monitoring/metrics')
        .set('Authorization', `Bearer ${authToken}`)
        .send(largePayload);

      expect([400, 413, 422]).toContain(response.status);
    });

    it('should handle deeply nested JSON structures', async () => {
      let nestedObj = {};
      for (let i = 0; i < 100; i++) {
        nestedObj = { nested: nestedObj };
      }

      const response = await request(app)
        .post('/api/auth/register')
        .send({
          email: 'test@example.com',
          password: 'TestPassword123!',
          fullName: 'Test User',
          metadata: nestedObj
        });

      expect([400, 422]).toContain(response.status);
    });
  });

  describe('Network and Timeout Errors', () => {
    it('should handle requests that take too long', async () => {
      // This would require configuring timeouts or simulating slow responses
      // For now, we test that the endpoint responds
      const response = await request(app)
        .get('/api/health/health')
        .timeout(5000);

      expect(response.status).toBe(200);
    });

    it('should handle incomplete request bodies', async () => {
      const response = await request(app)
        .post('/api/auth/register')
        .set('Content-Type', 'application/json')
        .send('{"incomplete":');

      expect([400, 500]).toContain(response.status);
    });
  });

  describe('Error Response Format', () => {
    it('should return consistent error response structure', async () => {
      const errorCases = [
        { path: '/api/auth/login', method: 'POST', data: {} },
        { path: '/api/non-existent', method: 'GET', data: {} },
        { path: '/api/aws-accounts', method: 'GET', data: {} }
      ];

      for (const testCase of errorCases) {
        const response = await request(app)
          [testCase.method.toLowerCase()](testCase.path)
          .send(testCase.data);

        if (response.status >= 400) {
          expect(response.body).toHaveProperty('message');
          
          // In development mode, might include stack trace
          if (process.env.NODE_ENV === 'development') {
            expect(response.body).toHaveProperty('stack');
          }
        }
      }
    });

    it('should include appropriate HTTP status codes', async () => {
      const testCases = [
        { path: '/api/auth/login', method: 'POST', data: {}, expectedStatus: 400 },
        { path: '/api/non-existent', method: 'GET', data: {}, expectedStatus: 404 },
        { path: '/api/aws-accounts', method: 'GET', data: {}, expectedStatus: 401 }
      ];

      for (const testCase of testCases) {
        const response = await request(app)
          [testCase.method.toLowerCase()](testCase.path)
          .send(testCase.data);

        expect(response.status).toBe(testCase.expectedStatus);
      }
    });
  });

  describe('Content-Type Error Handling', () => {
    it('should reject requests with incorrect content-type', async () => {
      const response = await request(app)
        .post('/api/auth/register')
        .set('Content-Type', 'text/plain')
        .send('plain text');

      expect([400, 415, 500]).toContain(response.status);
    });

    it('should handle requests with multiple content-type headers', async () => {
      const response = await request(app)
        .post('/api/auth/register')
        .set('Content-Type', 'application/json')
        .set('content-type', 'text/plain')
        .send('{"email": "test@example.com"}');

      expect([400, 415, 500]).toContain(response.status);
    });
  });

  describe('Header Validation', () => {
    it('should handle invalid header characters', async () => {
      const response = await request(app)
        .get('/api/health/status')
        .set('Authorization', 'Bearer valid-token')
        .set('X-Custom-Header', 'valid<header>');

      expect(response.status).toBe(200);
    });

    it('should handle very long header values', async () => {
      const longValue = 'a'.repeat(10000);
      const response = await request(app)
        .get('/api/health/status')
        .set('X-Custom-Header', longValue);

      expect([200, 400, 431]).toContain(response.status);
    });

    it('should handle null bytes in headers', async () => {
      const response = await request(app)
        .get('/api/health/status')
        .set('X-Custom-Header', 'valid\x00header');

      expect([200, 400]).toContain(response.status);
    });
  });

  describe('Graceful Degradation', () => {
    it('should continue functioning when non-critical services fail', async () => {
      // Test that core functionality works even if monitoring fails
      const authResponse = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'test@example.com',
          password: 'TestPassword123!'
        });

      expect(authResponse.status).toBe(200);
    });

    it('should provide fallback responses when possible', async () => {
      const healthResponse = await request(app)
        .get('/api/health/status');

      expect(healthResponse.status).toBe(200);
      expect(healthResponse.body).toHaveProperty('status');
    });
  });

  describe('Security Headers', () => {
    it('should include security headers in error responses', async () => {
      const response = await request(app)
        .get('/api/non-existent-endpoint');

      expect(response.headers).toHaveProperty('x-content-type-options');
      expect(response.headers['x-content-type-options']).toBe('nosniff');
    });

    it('should not expose sensitive information in error messages', async () => {
      const response = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'test@example.com',
          password: 'TestPassword123!'
        });

      if (response.status >= 400) {
        const errorMessage = JSON.stringify(response.body);
        expect(errorMessage).not.toContain('stack');
        expect(errorMessage).not.toContain('config');
        expect(errorMessage).not.toContain('secret');
      }
    });
  });
});
