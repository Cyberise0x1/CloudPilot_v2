/**
 * Authentication Integration Tests
 * Comprehensive tests for login, register, logout, and token refresh functionality
 */

import { describe, it, expect, beforeAll, afterAll, beforeEach, afterEach } from 'vitest';
import request from 'supertest';
import { app } from '../server/index';

describe('Authentication Integration Tests', () => {
  const testUser = {
    email: 'test@example.com',
    password: 'TestPassword123!',
    fullName: 'Test User'
  };

  let authToken: string;
  let refreshToken: string;
  let userId: string;
  let appInstance: any;

  beforeAll(async () => {
    // Get app instance
    appInstance = app;
    
    // Clean up any existing test user
    try {
      await request(appInstance)
        .post('/api/auth/register')
        .send(testUser);
    } catch (error) {
      // User might already exist, that's okay
    }
  });

  afterAll(async () => {
    // Clean up test user after all tests
    try {
      if (authToken) {
        await request(appInstance)
          .post('/api/auth/logout')
          .set('Authorization', `Bearer ${authToken}`)
          .send({ refreshToken });
      }
    } catch (error) {
      // Cleanup might fail, that's okay
    }
  });

  describe('POST /api/auth/register', () => {
    it('should register a new user successfully', async () => {
      const uniqueEmail = `test-${Date.now()}@example.com`;
      const response = await request(appInstance)
        .post('/api/auth/register')
        .send({
          ...testUser,
          email: uniqueEmail
        });

      expect(response.status).toBe(201);
      expect(response.body).toHaveProperty('user');
      expect(response.body).toHaveProperty('accessToken');
      expect(response.body).toHaveProperty('refreshToken');
      expect(response.body.user.email).toBe(uniqueEmail);
      expect(response.body.user).not.toHaveProperty('passwordHash');
      expect(typeof response.body.accessToken).toBe('string');
      expect(response.body.accessToken.split('.').length).toBe(3); // JWT format
      expect(response.body.accessToken.length).toBeGreaterThan(0);
    });

    it('should return 409 if user already exists', async () => {
      const response = await request(appInstance)
        .post('/api/auth/register')
        .send(testUser);

      expect(response.status).toBe(409);
      expect(response.body).toHaveProperty('message');
      expect(response.body.message).toMatch(/already exists|already registered/i);
    });

    it('should return 400 for invalid email format', async () => {
      const invalidEmails = [
        'invalid-email',
        '@example.com',
        'user@',
        'user..user@example.com',
        'user@.com',
        'user@example.'
      ];

      for (const email of invalidEmails) {
        const response = await request(appInstance)
          .post('/api/auth/register')
          .send({
            ...testUser,
            email
          });

        expect(response.status).toBe(400);
        expect(response.body).toHaveProperty('message');
      }
    });

    it('should return 400 for weak password', async () => {
      const weakPasswords = [
        '123',
        'password',
        'abc',
        '12',
        'short',
        'a'.repeat(7) // Too short
      ];

      for (const password of weakPasswords) {
        const response = await request(appInstance)
          .post('/api/auth/register')
          .send({
            ...testUser,
            password
          });

        expect(response.status).toBe(400);
        expect(response.body).toHaveProperty('message');
      }
    });

    it('should return 400 for missing required fields', async () => {
      const incompleteData = [
        { email: 'test@example.com' }, // Missing password and fullName
        { password: 'TestPassword123!' }, // Missing email and fullName
        { fullName: 'Test User' }, // Missing email and password
        {}, // Missing all
        { email: '', password: '', fullName: '' } // Empty fields
      ];

      for (const data of incompleteData) {
        const response = await request(appInstance)
          .post('/api/auth/register')
          .send(data);

        expect(response.status).toBe(400);
        expect(response.body).toHaveProperty('message');
      }
    });

    it('should handle XSS attempts in fullName', async () => {
      const xssPayloads = [
        '<script>alert("xss")</script>',
        '"><script>alert("xss")</script>',
        '${7*7}',
        '{{7*7}}',
        '"><img src=x onerror=alert(1)>'
      ];

      for (const payload of xssPayloads) {
        const uniqueEmail = `test-${Date.now()}-${Math.random()}@example.com`;
        const response = await request(appInstance)
          .post('/api/auth/register')
          .send({
            ...testUser,
            email: uniqueEmail,
            fullName: payload
          });

        // Should either sanitize or reject
        expect([400, 201]).toContain(response.status);
      }
    });
  });

  describe('POST /api/auth/login', () => {
    beforeAll(async () => {
      // Login to get tokens for subsequent tests
      const response = await request(appInstance)
        .post('/api/auth/login')
        .send({
          email: testUser.email,
          password: testUser.password
        });

      if (response.status === 200) {
        authToken = response.body.accessToken;
        refreshToken = response.body.refreshToken;
        userId = response.body.user.id;
      }
    });

    it('should login successfully with valid credentials', async () => {
      const response = await request(appInstance)
        .post('/api/auth/login')
        .send({
          email: testUser.email,
          password: testUser.password
        });

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('user');
      expect(response.body).toHaveProperty('accessToken');
      expect(response.body).toHaveProperty('refreshToken');
      expect(response.body.user.email).toBe(testUser.email);
      expect(response.body.user).not.toHaveProperty('password');
      expect(response.body.user).not.toHaveProperty('passwordHash');
    });

    it('should return 401 for invalid email', async () => {
      const response = await request(appInstance)
        .post('/api/auth/login')
        .send({
          email: 'nonexistent@example.com',
          password: testUser.password
        });

      expect(response.status).toBe(401);
      expect(response.body).toHaveProperty('message');
      expect(response.body.message).toMatch(/invalid credentials|not found/i);
    });

    it('should return 401 for invalid password', async () => {
      const response = await request(appInstance)
        .post('/api/auth/login')
        .send({
          email: testUser.email,
          password: 'wrongpassword'
        });

      expect(response.status).toBe(401);
      expect(response.body).toHaveProperty('message');
      expect(response.body.message).toMatch(/invalid credentials|incorrect/i);
    });

    it('should return 401 for wrong case email', async () => {
      const response = await request(appInstance)
        .post('/api/auth/login')
        .send({
          email: testUser.email.toUpperCase(),
          password: testUser.password
        });

      expect(response.status).toBe(401);
    });

    it('should return 400 for missing email', async () => {
      const response = await request(appInstance)
        .post('/api/auth/login')
        .send({
          password: testUser.password
        });

      expect(response.status).toBe(400);
      expect(response.body).toHaveProperty('message');
    });

    it('should return 400 for missing password', async () => {
      const response = await request(appInstance)
        .post('/api/auth/login')
        .send({
          email: testUser.email
        });

      expect(response.status).toBe(400);
      expect(response.body).toHaveProperty('message');
    });

    it('should return 400 for empty request body', async () => {
      const response = await request(appInstance)
        .post('/api/auth/login')
        .send({});

      expect(response.status).toBe(400);
      expect(response.body).toHaveProperty('message');
    });

    it('should handle SQL injection attempts', async () => {
      const sqlPayloads = [
        "' OR '1'='1",
        "'; DROP TABLE users; --",
        "' UNION SELECT * FROM users --",
        "admin'--",
        "' OR 1=1--"
      ];

      for (const payload of sqlPayloads) {
        const response = await request(appInstance)
          .post('/api/auth/login')
          .send({
            email: payload,
            password: 'anypassword'
          });

        expect([400, 401]).toContain(response.status);
      }
    });

    it('should prevent timing attacks', async () => {
      const startTime1 = Date.now();
      await request(appInstance)
        .post('/api/auth/login')
        .send({
          email: 'fake@example.com',
          password: 'fakepassword'
        });
      const invalidTime = Date.now() - startTime1;

      const startTime2 = Date.now();
      await request(appInstance)
        .post('/api/auth/login')
        .send({
          email: testUser.email,
          password: 'wrongpassword'
        });
      const wrongPasswordTime = Date.now() - startTime2;

      // Times should be relatively similar (within reasonable bounds)
      const timeDiff = Math.abs(invalidTime - wrongPasswordTime);
      expect(timeDiff).toBeLessThan(1000); // Should be less than 1 second difference
    });
  });

  describe('GET /api/auth/me', () => {
    it('should return user info with valid token', async () => {
      const response = await request(appInstance)
        .get('/api/auth/me')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('user');
      expect(response.body.user.email).toBe(testUser.email);
      expect(response.body.user).not.toHaveProperty('password');
      expect(response.body.user).not.toHaveProperty('passwordHash');
    });

    it('should return 401 without authorization header', async () => {
      const response = await request(appInstance)
        .get('/api/auth/me');

      expect(response.status).toBe(401);
      expect(response.body).toHaveProperty('message');
    });

    it('should return 401 with invalid token', async () => {
      const response = await request(appInstance)
        .get('/api/auth/me')
        .set('Authorization', 'Bearer invalid-token');

      expect(response.status).toBe(401);
      expect(response.body).toHaveProperty('message');
    });

    it('should return 401 with malformed authorization header', async () => {
      const response = await request(appInstance)
        .get('/api/auth/me')
        .set('Authorization', 'InvalidFormat token');

      expect(response.status).toBe(401);
      expect(response.body).toHaveProperty('message');
    });

    it('should handle expired token', async () => {
      // Create a token with very short expiry for testing
      const expiredToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.' +
        Buffer.from(JSON.stringify({ exp: Math.floor(Date.now() / 1000) - 3600 })).toString('base64url') +
        '.signature';

      const response = await request(appInstance)
        .get('/api/auth/me')
        .set('Authorization', `Bearer ${expiredToken}`);

      expect(response.status).toBe(401);
    });

    it('should handle very long authorization headers', async () => {
      const longToken = 'a'.repeat(10000);
      const response = await request(appInstance)
        .get('/api/auth/me')
        .set('Authorization', `Bearer ${longToken}`);

      expect([400, 401, 413]).toContain(response.status);
    });

    it('should include user metadata', async () => {
      const response = await request(appInstance)
        .get('/api/auth/me')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      expect(response.body.user).toHaveProperty('id');
      expect(response.body.user).toHaveProperty('email');
      expect(response.body.user).toHaveProperty('fullName');
      expect(response.body.user).toHaveProperty('createdAt');
    });
  });

  describe('POST /api/auth/refresh', () => {
    it('should refresh token successfully', async () => {
      const response = await request(appInstance)
        .post('/api/auth/refresh')
        .send({ refreshToken });

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('accessToken');
      expect(response.body).toHaveProperty('refreshToken');
      expect(response.body).toHaveProperty('user');
      expect(response.body.accessToken).not.toBe(authToken); // Should be different
      expect(response.body.refreshToken).not.toBe(refreshToken); // Should be different
    });

    it('should return 401 for invalid refresh token', async () => {
      const response = await request(appInstance)
        .post('/api/auth/refresh')
        .send({ refreshToken: 'invalid-refresh-token' });

      expect(response.status).toBe(401);
      expect(response.body).toHaveProperty('message');
    });

    it('should return 400 for missing refresh token', async () => {
      const response = await request(appInstance)
        .post('/api/auth/refresh')
        .send({});

      expect(response.status).toBe(400);
      expect(response.body).toHaveProperty('message');
    });

    it('should return 400 for null refresh token', async () => {
      const response = await request(appInstance)
        .post('/api/auth/refresh')
        .send({ refreshToken: null });

      expect(response.status).toBe(400);
    });

    it('should handle expired refresh token', async () => {
      const expiredRefreshToken = 'expired-token';
      const response = await request(appInstance)
        .post('/api/auth/refresh')
        .send({ refreshToken: expiredRefreshToken });

      expect([400, 401]).toContain(response.status);
    });
  });

  describe('POST /api/auth/logout', () => {
    it('should logout successfully', async () => {
      // Login again to get fresh tokens
      const loginResponse = await request(appInstance)
        .post('/api/auth/login')
        .send({
          email: testUser.email,
          password: testUser.password
        });

      if (loginResponse.status === 200) {
        const token = loginResponse.body.accessToken;
        const refresh = loginResponse.body.refreshToken;

        const response = await request(appInstance)
          .post('/api/auth/logout')
          .set('Authorization', `Bearer ${token}`)
          .send({ refreshToken: refresh });

        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('message');
        expect(response.body.message).toMatch(/successfully|logged out/i);
      }
    });

    it('should logout successfully without refresh token', async () => {
      // Login again to get fresh tokens
      const loginResponse = await request(appInstance)
        .post('/api/auth/login')
        .send({
          email: testUser.email,
          password: testUser.password
        });

      if (loginResponse.status === 200) {
        const token = loginResponse.body.accessToken;

        const response = await request(appInstance)
          .post('/api/auth/logout')
          .set('Authorization', `Bearer ${token}`)
          .send({});

        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('message');
      }
    });

    it('should handle logout errors gracefully', async () => {
      const response = await request(appInstance)
        .post('/api/auth/logout')
        .set('Authorization', `Bearer ${authToken}`)
        .send({ refreshToken: 'non-existent-token' });

      expect(response.status).toBe(200); // Even if refresh token deletion fails, logout should succeed
      expect(response.body).toHaveProperty('message');
    });

    it('should return 401 without authorization', async () => {
      const response = await request(appInstance)
        .post('/api/auth/logout')
        .send({ refreshToken: refreshToken });

      expect(response.status).toBe(401);
    });

    it('should invalidate access token after logout', async () => {
      // Login again to get fresh tokens
      const loginResponse = await request(appInstance)
        .post('/api/auth/login')
        .send({
          email: testUser.email,
          password: testUser.password
        });

      if (loginResponse.status === 200) {
        const token = loginResponse.body.accessToken;
        const refresh = loginResponse.body.refreshToken;

        // Logout
        await request(appInstance)
          .post('/api/auth/logout')
          .set('Authorization', `Bearer ${token}`)
          .send({ refreshToken: refresh });

        // Try to use the token
        const meResponse = await request(appInstance)
          .get('/api/auth/me')
          .set('Authorization', `Bearer ${token}`);

        expect(meResponse.status).toBe(401);
      }
    });
  });

  describe('Protected Routes', () => {
    it('should require authentication for AWS accounts endpoint', async () => {
      const response = await request(appInstance)
        .get('/api/aws-accounts');

      expect(response.status).toBe(401);
    });

    it('should allow access with valid token', async () => {
      const response = await request(appInstance)
        .get('/api/aws-accounts')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      expect(Array.isArray(response.body)).toBe(true);
    });

    it('should require authentication for AWS operations', async () => {
      const protectedEndpoints = [
        { method: 'GET', path: '/api/aws/instances/us-east-1/test-account-id' },
        { method: 'POST', path: '/api/aws/instances/launch' },
        { method: 'GET', path: '/api/aws/s3/buckets/test-account-id' },
        { method: 'GET', path: '/api/aws/rds/us-east-1/test-account-id' },
        { method: 'GET', path: '/api/aws/cloudfront/test-account-id' }
      ];

      for (const endpoint of protectedEndpoints) {
        const response = await request(appInstance)
          [endpoint.method.toLowerCase()](endpoint.path)
          .send({});

        expect(response.status).toBe(401);
      }
    });
  });

  describe('Security Tests', () => {
    it('should not expose password hash in responses', async () => {
      const response = await request(appInstance)
        .post('/api/auth/login')
        .send({
          email: testUser.email,
          password: testUser.password
        });

      expect(response.body.user).not.toHaveProperty('passwordHash');
      expect(response.body.user).not.toHaveProperty('password');
    });

    it('should use secure JWT tokens', async () => {
      const response = await request(appInstance)
        .post('/api/auth/login')
        .send({
          email: testUser.email,
          password: testUser.password
        });

      const token = response.body.accessToken;
      expect(token).toBeDefined();
      expect(typeof token).toBe('string');
      expect(token.split('.').length).toBe(3); // JWT should have 3 parts
    });

    it('should handle concurrent requests properly', async () => {
      const requests = Array(10).fill(null).map(() =>
        request(appInstance)
          .post('/api/auth/login')
          .send({
            email: testUser.email,
            password: testUser.password
          })
      );

      const responses = await Promise.all(requests);
      
      responses.forEach(response => {
        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('accessToken');
      });
    });

    it('should not expose sensitive information in error messages', async () => {
      const response = await request(appInstance)
        .post('/api/auth/login')
        .send({
          email: testUser.email,
          password: 'wrongpassword'
        });

      const errorMessage = JSON.stringify(response.body);
      expect(errorMessage).not.toContain('password');
      expect(errorMessage).not.toContain('hash');
      expect(errorMessage).not.toContain('salt');
    });

    it('should handle rate limiting for login attempts', async () => {
      const requests = Array(20).fill(null).map(() =>
        request(appInstance)
          .post('/api/auth/login')
          .send({
            email: testUser.email,
            password: 'wrongpassword'
          })
      );

      const responses = await Promise.all(requests);
      
      // Some requests might be rate limited
      responses.forEach(response => {
        expect([400, 401, 429]).toContain(response.status);
      });
    });
  });

  describe('Input Validation', () => {
    it('should handle very long email addresses', async () => {
      const longEmail = 'a'.repeat(100) + '@example.com';
      const response = await request(appInstance)
        .post('/api/auth/register')
        .send({
          ...testUser,
          email: longEmail
        });

      expect(response.status).toBe(400);
    });

    it('should handle very long passwords', async () => {
      const longPassword = 'a'.repeat(1000);
      const response = await request(appInstance)
        .post('/api/auth/register')
        .send({
          ...testUser,
          password: longPassword,
          email: `test-${Date.now()}@example.com`
        });

      expect(response.status).toBe(400);
    });

    it('should handle special characters in inputs', async () => {
      const specialCharEmail = `test+${Date.now()}@example.com`;
      const specialChars = [
        'User with émojis 🎉',
        'User with spëcial çhars',
        'User with Ünicöde',
        'User with "quotes"',
        "User with 'apostrophes'"
      ];

      for (const fullName of specialChars) {
        const response = await request(appInstance)
          .post('/api/auth/register')
          .send({
            ...testUser,
            email: specialCharEmail,
            fullName
          });

        expect([200, 201, 400]).toContain(response.status);
      }
    });

    it('should handle Unicode in email addresses', async () => {
      const unicodeEmail = `test+üñíçøðé@exämple.com`;
      const response = await request(appInstance)
        .post('/api/auth/register')
        .send({
          ...testUser,
          email: unicodeEmail
        });

      expect([200, 201, 400]).toContain(response.status);
    });
  });

  describe('Session Management', () => {
    it('should handle multiple concurrent sessions', async () => {
      const session1 = await request(appInstance)
        .post('/api/auth/login')
        .send({
          email: testUser.email,
          password: testUser.password
        });

      const session2 = await request(appInstance)
        .post('/api/auth/login')
        .send({
          email: testUser.email,
          password: testUser.password
        });

      expect(session1.status).toBe(200);
      expect(session2.status).toBe(200);
      expect(session1.body.accessToken).not.toBe(session2.body.accessToken);
    });

    it('should allow token refresh without affecting other sessions', async () => {
      // Login twice to get two sessions
      const session1 = await request(appInstance)
        .post('/api/auth/login')
        .send({
          email: testUser.email,
          password: testUser.password
        });

      if (session1.status === 200) {
        const token1 = session1.body.accessToken;
        const refresh1 = session1.body.refreshToken;

        // Refresh first token
        const refreshResponse = await request(appInstance)
          .post('/api/auth/refresh')
          .send({ refreshToken: refresh1 });

        expect(refreshResponse.status).toBe(200);

        // Both old and new tokens should work initially
        const meResponse1 = await request(appInstance)
          .get('/api/auth/me')
          .set('Authorization', `Bearer ${token1}`);

        expect(meResponse1.status).toBe(200);
      }
    });
  });

  describe('Edge Cases', () => {
    it('should handle empty request body', async () => {
      const response = await request(appInstance)
        .post('/api/auth/login')
        .set('Content-Type', 'application/json')
        .send('');

      expect(response.status).toBe(400);
    });

    it('should handle malformed JSON', async () => {
      const response = await request(appInstance)
        .post('/api/auth/login')
        .set('Content-Type', 'application/json')
        .send('{ invalid json }');

      expect([400, 500]).toContain(response.status);
    });

    it('should handle incorrect content type', async () => {
      const response = await request(appInstance)
        .post('/api/auth/login')
        .set('Content-Type', 'text/plain')
        .send('email=test@example.com&password=password');

      expect([400, 415, 500]).toContain(response.status);
    });

    it('should handle very large request bodies', async () => {
      const largeObject = {
        ...testUser,
        metadata: 'a'.repeat(10 * 1024 * 1024) // 10MB
      };

      const response = await request(appInstance)
        .post('/api/auth/register')
        .send(largeObject);

      expect([400, 413, 422]).toContain(response.status);
    });
  });

  describe('Performance Tests', () => {
    it('should respond to login requests within reasonable time', async () => {
      const startTime = Date.now();
      const response = await request(appInstance)
        .post('/api/auth/login')
        .send({
          email: testUser.email,
          password: testUser.password
        });
      const responseTime = Date.now() - startTime;

      expect(response.status).toBe(200);
      expect(responseTime).toBeLessThan(5000); // Should respond within 5 seconds
    });

    it('should handle burst requests', async () => {
      const requests = Array(50).fill(null).map(() =>
        request(appInstance)
          .post('/api/auth/login')
          .send({
            email: testUser.email,
            password: testUser.password
          })
      );

      const responses = await Promise.all(requests);
      
      responses.forEach(response => {
        expect([200, 429, 503]).toContain(response.status);
      });
    });
  });
});
