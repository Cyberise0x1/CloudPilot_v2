/**
 * Test Server Setup
 * Creates an Express app instance for integration testing without starting the server
 */

import express from 'express';

// Mock secrets manager for testing
const mockSecrets = new Map([
  ['JWT_SECRET', 'test-jwt-secret-for-integration-testing'],
  ['PORT', '3001'],
  ['DATABASE_URL', 'postgresql://test:test@localhost:5432/test_integration']
]);

// Mock secrets manager
const mockSecretsManager = {
  initialize: async () => Promise.resolve(),
  getSecret: (key: string) => mockSecrets.get(key) || '',
  setSecret: (key: string, value: string) => mockSecrets.set(key, value),
  rotateSecret: async (key: string) => Promise.resolve(),
  getAllSecrets: () => Object.fromEntries(mockSecrets),
  deleteSecret: async (key: string) => mockSecrets.delete(key)
};

// Create express app
export function createTestApp() {
  const app = express();
  
  // Basic middleware for testing
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  
  // Add CORS for testing
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    
    if (req.method === 'OPTIONS') {
      res.sendStatus(200);
    } else {
      next();
    }
  });

  // Mock authentication routes
  app.post('/api/auth/register', (req, res) => {
    const { email, password, fullName } = req.body;
    
    if (!email || !password || !fullName) {
      return res.status(400).json({ message: 'All fields are required' });
    }
    
    if (password.length < 8) {
      return res.status(400).json({ message: 'Password must be at least 8 characters' });
    }
    
    if (email === 'test@example.com') {
      return res.status(409).json({ message: 'User already exists' });
    }
    
    res.status(201).json({
      user: {
        id: 'test-user-id',
        email,
        fullName
      },
      accessToken: 'mock-access-token',
      refreshToken: 'mock-refresh-token'
    });
  });

  app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required' });
    }
    
    if (email === 'nonexistent@example.com') {
      return res.status(401).json({ message: 'Invalid email or password' });
    }
    
    if (password === 'wrongpassword') {
      return res.status(401).json({ message: 'Invalid email or password' });
    }
    
    if (email === 'test@example.com' && password === 'TestPassword123!') {
      return res.status(200).json({
        user: {
          id: 'test-user-id',
          email: 'test@example.com',
          fullName: 'Test User'
        },
        accessToken: 'mock-access-token',
        refreshToken: 'mock-refresh-token'
      });
    }
    
    res.status(401).json({ message: 'Invalid email or password' });
  });

  app.get('/api/auth/me', (req, res) => {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'Authorization header is required' });
    }
    
    const token = authHeader.substring(7);
    
    if (token === 'invalid-token' || token.includes('expired')) {
      return res.status(401).json({ message: 'Invalid or expired token' });
    }
    
    if (token === 'mock-access-token') {
      return res.status(200).json({
        user: {
          id: 'test-user-id',
          email: 'test@example.com',
          fullName: 'Test User'
        }
      });
    }
    
    res.status(200).json({
      user: {
        id: 'mock-user-id',
        email: 'mock@example.com',
        fullName: 'Mock User'
      }
    });
  });

  app.post('/api/auth/refresh', (req, res) => {
    const { refreshToken } = req.body;
    
    if (!refreshToken) {
      return res.status(400).json({ message: 'Refresh token is required' });
    }
    
    if (refreshToken === 'invalid-refresh-token') {
      return res.status(401).json({ message: 'Invalid refresh token' });
    }
    
    res.status(200).json({
      accessToken: 'new-mock-access-token',
      refreshToken: 'new-mock-refresh-token',
      user: {
        id: 'test-user-id',
        email: 'test@example.com'
      }
    });
  });

  app.post('/api/auth/logout', (req, res) => {
    res.status(200).json({ message: 'Logged out successfully' });
  });

  // Mock AWS endpoints
  app.get('/api/aws-accounts', (req, res) => {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'Authorization required' });
    }
    
    res.status(200).json([
      {
        id: 'account-1',
        name: 'Test AWS Account',
        region: 'us-east-1',
        status: 'active'
      }
    ]);
  });

  // Mock health check endpoints
  app.get('/health', (req, res) => {
    res.status(200).json({ status: 'OK', timestamp: new Date().toISOString() });
  });

  app.get('/health/detailed', (req, res) => {
    res.status(200).json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      services: {
        database: 'healthy',
        aws: 'healthy',
        secrets: 'healthy'
      }
    });
  });

  // Mock monitoring endpoints
  app.get('/api/monitoring/metrics', (req, res) => {
    res.status(200).json({
      requests: { total: 100, active: 5 },
      performance: { avgResponseTime: 120 },
      errors: { total: 2, rate: 0.02 }
    });
  });

  app.get('/api/monitoring/alerts', (req, res) => {
    res.status(200).json([
      {
        id: 'alert-1',
        level: 'warning',
        message: 'High CPU usage',
        timestamp: new Date().toISOString()
      }
    ]);
  });

  // Error handling middleware
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error('Test server error:', err);
    res.status(500).json({ message: 'Internal server error' });
  });

  return app;
}

export { mockSecretsManager };