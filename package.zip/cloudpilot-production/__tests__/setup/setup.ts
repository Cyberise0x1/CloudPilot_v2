/**
 * Global Test Setup
 * Sets up the test environment, database connections, and test utilities
 */

import { jest } from '@jest/globals';

// Global test configuration
beforeAll(async () => {
  // Set test environment variables
  process.env.NODE_ENV = 'test';
  process.env.JWT_SECRET = 'test-jwt-secret-key-for-integration-tests';
  process.env.DATABASE_URL = 'postgresql://test:test@localhost:5432/test_db';
  process.env.AWS_ACCESS_KEY_ID = 'test-access-key-id';
  process.env.AWS_SECRET_ACCESS_KEY = 'test-secret-access-key';
  process.env.AWS_REGION = 'us-east-1';

  // Increase timeout for database operations
  jest.setTimeout(30000);

  // Suppress console logs during tests unless debugging
  if (!process.env.DEBUG_TESTS) {
    jest.spyOn(console, 'log').mockImplementation(() => {});
    jest.spyOn(console, 'info').mockImplementation(() => {});
    jest.spyOn(console, 'warn').mockImplementation(() => {});
  }
});

// Setup before each test
beforeEach(async () => {
  // Reset all mocks
  jest.clearAllMocks();

  // Reset any database state if needed
  // This would require actual database cleanup in a real implementation
});

// Cleanup after each test
afterEach(async () => {
  // Clean up any test data
  jest.restoreAllMocks();
});

// Global test cleanup
afterAll(async () => {
  // Clean up any remaining resources
  jest.clearAllTimers();
});

// Mock external dependencies
jest.mock('../server/middleware-local/logger', () => ({
  requestLoggingMiddleware: jest.fn().mockImplementation((req, res, next) => next()),
  performanceMiddleware: jest.fn().mockImplementation(() => (req, res, next) => next()),
  userContextMiddleware: jest.fn().mockImplementation((req, res, next) => next()),
  securityMiddleware: jest.fn().mockImplementation((req, res, next) => next()),
}));

jest.mock('../server/metrics-local', () => ({
  metricsMiddleware: jest.fn().mockImplementation((req, res, next) => next()),
  trackRequest: jest.fn(),
  trackAwsOperation: jest.fn(),
  trackBusinessEvent: jest.fn(),
  getHealthMetrics: jest.fn().mockReturnValue({}),
}));

jest.mock('../server/error-tracking-local', () => ({
  errorTrackingMiddleware: jest.fn().mockImplementation((req, res, next) => next()),
  getErrorTracking: jest.fn().mockReturnValue({
    getSystemStats: jest.fn().mockReturnValue({}),
  }),
  createErrorTracking: jest.fn().mockReturnValue({
    trackError: jest.fn(),
    getSystemStats: jest.fn().mockReturnValue({}),
  }),
}));

// Mock AWS services
jest.mock('../server/services/aws-service', () => ({
  awsService: {
    validateCredentials: jest.fn().mockResolvedValue(true),
    listInstances: jest.fn().mockResolvedValue([]),
    launchInstance: jest.fn().mockResolvedValue({ instanceId: 'test-instance' }),
    startInstance: jest.fn().mockResolvedValue({}),
    stopInstance: jest.fn().mockResolvedValue({}),
    terminateInstance: jest.fn().mockResolvedValue({}),
    listS3Buckets: jest.fn().mockResolvedValue([]),
    createS3Bucket: jest.fn().mockResolvedValue({}),
    listRdsInstances: jest.fn().mockResolvedValue([]),
    createRdsInstance: jest.fn().mockResolvedValue({}),
    listCloudFrontDistributions: jest.fn().mockResolvedValue([]),
    createCloudFrontDistribution: jest.fn().mockResolvedValue({}),
    generateMockTrafficData: jest.fn().mockReturnValue({
      inbound: Math.random() * 1000,
      outbound: Math.random() * 1000,
    }),
  },
}));

// Mock secrets manager
jest.mock('../server/secrets-manager', () => ({
  secretsManager: {
    initialize: jest.fn().mockResolvedValue(undefined),
    getSecret: jest.fn().mockImplementation((key) => {
      const secrets: Record<string, string> = {
        JWT_SECRET: process.env.JWT_SECRET || 'test-secret',
        AWS_ACCESS_KEY_ID: process.env.AWS_ACCESS_KEY_ID || 'test-key',
        AWS_SECRET_ACCESS_KEY: process.env.AWS_SECRET_ACCESS_KEY || 'test-secret',
        AWS_REGION: process.env.AWS_REGION || 'us-east-1',
        PORT: '5000',
      };
      return secrets[key];
    }),
    getStatistics: jest.fn().mockReturnValue({
      requiredSecrets: 4,
      validatedSecrets: 4,
    }),
  },
}));

// Mock environment validator
jest.mock('../server/env-validator', () => ({
  validateConfig: jest.fn().mockReturnValue({
    isValid: true,
    errors: [],
    warnings: [],
  }),
}));

// Mock database operations
jest.mock('../server/db', () => ({
  pool: {
    connect: jest.fn(),
    query: jest.fn(),
    end: jest.fn(),
  },
  db: {
    execute: jest.fn().mockResolvedValue({
      rows: [{ current_time: new Date(), db_version: 'PostgreSQL 14' }],
    }),
  },
}));

// Mock storage operations
jest.mock('../server/storage', () => ({
  storage: {
    getUserByEmail: jest.fn(),
    createUser: jest.fn(),
    getUserById: jest.fn(),
    createRefreshToken: jest.fn(),
    deleteRefreshToken: jest.fn(),
    getRefreshToken: jest.fn(),
    getSafeAwsAccounts: jest.fn().mockResolvedValue([]),
    createAwsAccount: jest.fn(),
    getAwsAccount: jest.fn(),
    activateAwsAccount: jest.fn(),
    upsertEc2Instance: jest.fn(),
    getEc2InstancesByRegion: jest.fn().mockResolvedValue([]),
    updateInstanceName: jest.fn(),
    upsertS3Bucket: jest.fn(),
    getS3BucketsByAccount: jest.fn().mockResolvedValue([]),
    deleteS3Bucket: jest.fn(),
    upsertRdsInstance: jest.fn(),
    getRdsInstancesByRegion: jest.fn().mockResolvedValue([]),
    deleteRdsInstance: jest.fn(),
    upsertCloudFrontDistribution: jest.fn(),
    getCloudFrontDistributionsByAccount: jest.fn().mockResolvedValue([]),
    deleteCloudFrontDistribution: jest.fn(),
    getInstanceTemplatesByAccount: jest.fn().mockResolvedValue([]),
    createInstanceTemplate: jest.fn(),
    updateInstanceTemplate: jest.fn(),
    deleteInstanceTemplate: jest.fn(),
  },
}));

// Global test utilities
global.testUtils = {
  // Wait for a condition to be true
  waitFor: async (condition: () => boolean, timeout = 5000): Promise<void> => {
    const startTime = Date.now();
    while (!condition() && Date.now() - startTime < timeout) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    if (!condition()) {
      throw new Error(`Condition not met within ${timeout}ms`);
    }
  },

  // Generate random test data
  generateTestData: {
    email: () => `test-${Date.now()}-${Math.random().toString(36).substr(2, 9)}@example.com`,
    accountId: () => `test-account-${Date.now()}`,
    instanceId: () => `i-${Math.random().toString(36).substr(2, 17)}`,
    bucketName: () => `test-bucket-${Date.now()}`,
    region: () => 'us-east-1',
  },

  // Mock response helpers
  createMockResponse: () => {
    const res: any = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
      send: jest.fn().mockReturnThis(),
      setHeader: jest.fn().mockReturnThis(),
      end: jest.fn().mockReturnThis(),
    };
    return res;
  },

  // Create mock request
  createMockRequest: (overrides = {}) => {
    return {
      method: 'GET',
      url: '/',
      path: '/',
      headers: {},
      body: {},
      params: {},
      query: {},
      ip: '127.0.0.1',
      get: jest.fn().mockReturnValue('127.0.0.1'),
      ...overrides,
    };
  },
};

// Extend Jest matchers
expect.extend({
  toBeWithinRange(received: number, floor: number, ceiling: number) {
    const pass = received >= floor && received <= ceiling;
    if (pass) {
      return {
        message: () => `expected ${received} not to be within range ${floor} - ${ceiling}`,
        pass: true,
      };
    } else {
      return {
        message: () => `expected ${received} to be within range ${floor} - ${ceiling}`,
        pass: false,
      };
    }
  },

  toHaveValidJsonStructure(received: any) {
    const isValid = typeof received === 'object' && received !== null;
    return {
      message: () => `expected ${received} to have valid JSON structure`,
      pass: isValid,
    };
  },
});

declare global {
  namespace jest {
    interface Matchers<R> {
      toBeWithinRange(floor: number, ceiling: number): R;
      toHaveValidJsonStructure(): R;
    }
  }

  interface GlobalTestUtils {
    waitFor: (condition: () => boolean, timeout?: number) => Promise<void>;
    generateTestData: {
      email: () => string;
      accountId: () => string;
      instanceId: () => string;
      bucketName: () => string;
      region: () => string;
    };
    createMockResponse: () => any;
    createMockRequest: (overrides?: any) => any;
  }
}

declare const global: {
  testUtils: GlobalTestUtils;
};
