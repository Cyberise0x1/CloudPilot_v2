/**
 * Health Check Integration Tests
 * Comprehensive tests for health check endpoints, monitoring, and system status
 */

import { describe, it, expect, beforeAll, afterAll, beforeEach, afterEach } from 'vitest';
import request from 'supertest';
import { app } from '../server/index';

describe('Health Check Integration Tests', () => {
  describe('GET /api/health/health', () => {
    it('should return comprehensive health report', async () => {
      const response = await request(app)
        .get('/api/health/health');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('status');
      expect(response.body).toHaveProperty('timestamp');
      expect(response.body).toHaveProperty('checks');
      expect(response.body).toHaveProperty('systemMetrics');
      expect(response.body).toHaveProperty('summary');
      expect(['healthy', 'degraded', 'unhealthy']).toContain(response.body.status);
    });

    it('should return all health check components', async () => {
      const response = await request(app)
        .get('/api/health/health');

      expect(response.body.checks).toHaveProperty('database');
      expect(response.body.checks).toHaveProperty('aws');
      expect(response.body.checks).toHaveProperty('system');
      expect(response.body.checks).toHaveProperty('application');
      
      // Additional components based on implementation
      const expectedComponents = ['database', 'aws', 'system', 'application'];
      const actualComponents = Object.keys(response.body.checks);
      
      expectedComponents.forEach(component => {
        expect(actualComponents).toContain(component);
      });
    });

    it('should include system metrics', async () => {
      const response = await request(app)
        .get('/api/health/health');

      const metrics = response.body.systemMetrics;
      expect(metrics).toHaveProperty('cpu');
      expect(metrics).toHaveProperty('memory');
      expect(metrics).toHaveProperty('disk');
      expect(metrics).toHaveProperty('uptime');
      
      expect(metrics.cpu).toHaveProperty('usage');
      expect(metrics.cpu).toHaveProperty('loadAverage');
      expect(metrics.cpu).toHaveProperty('cores');
      
      expect(metrics.memory).toHaveProperty('used');
      expect(metrics.memory).toHaveProperty('total');
      expect(metrics.memory).toHaveProperty('percentage');
      
      expect(metrics.disk).toHaveProperty('used');
      expect(metrics.disk).toHaveProperty('total');
      expect(metrics.disk).toHaveProperty('percentage');
      
      expect(metrics.uptime).toBeGreaterThanOrEqual(0);
    });

    it('should provide summary statistics', async () => {
      const response = await request(app)
        .get('/api/health/health');

      const summary = response.body.summary;
      expect(summary).toHaveProperty('total');
      expect(summary).toHaveProperty('healthy');
      expect(summary).toHaveProperty('degraded');
      expect(summary).toHaveProperty('unhealthy');
      expect(summary).toHaveProperty('avgResponseTime');
      expect(summary.total).toBeGreaterThan(0);
      expect(summary.total).toBe(summary.healthy + summary.degraded + summary.unhealthy);
      expect(summary.avgResponseTime).toBeGreaterThanOrEqual(0);
    });

    it('should calculate correct percentages', async () => {
      const response = await request(app)
        .get('/api/health/health');

      const summary = response.body.summary;
      const total = summary.total;
      if (total > 0) {
        const healthyPercent = (summary.healthy / total) * 100;
        const degradedPercent = (summary.degraded / total) * 100;
        const unhealthyPercent = (summary.unhealthy / total) * 100;
        
        expect(healthyPercent + degradedPercent + unhealthyPercent).toBeCloseTo(100, 0.01);
      }
    });

    it('should include environment information', async () => {
      const response = await request(app)
        .get('/api/health/health');

      expect(response.body).toHaveProperty('environment');
      expect(response.body).toHaveProperty('version');
      expect(response.body.environment).toBeDefined();
      expect(response.body.version).toBeDefined();
    });

    it('should track response times', async () => {
      const response = await request(app)
        .get('/api/health/health');

      expect(response.body).toHaveProperty('responseTime');
      expect(response.body.responseTime).toBeGreaterThanOrEqual(0);
    });

    it('should include timestamp in ISO format', async () => {
      const response = await request(app)
        .get('/api/health/health');

      expect(response.body).toHaveProperty('timestamp');
      expect(typeof response.body.timestamp).toBe('number');
      
      const date = new Date(response.body.timestamp);
      expect(date).toBeInstanceOf(Date);
      expect(isNaN(date.getTime())).toBe(false);
    });

    it('should return consistent structure across requests', async () => {
      const responses = await Promise.all([
        request(app).get('/api/health/health'),
        request(app).get('/api/health/health'),
        request(app).get('/api/health/health')
      ]);

      responses.forEach(response => {
        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('status');
        expect(response.body).toHaveProperty('checks');
        expect(response.body).toHaveProperty('systemMetrics');
        expect(response.body).toHaveProperty('summary');
      });
    });

    it('should not require authentication', async () => {
      const response = await request(app)
        .get('/api/health/health');

      expect(response.status).toBe(200);
    });

    it('should include build information', async () => {
      const response = await request(app)
        .get('/api/health/health');

      expect(response.body).toHaveProperty('build');
      if (response.body.build) {
        expect(response.body.build).toHaveProperty('commit');
        expect(response.body.build).toHaveProperty('branch');
      }
    });

    it('should provide detailed component status', async () => {
      const response = await request(app)
        .get('/api/health/health');

      Object.entries(response.body.checks).forEach(([component, status]) => {
        expect(status).toHaveProperty('status');
        expect(status).toHaveProperty('responseTime');
        expect(['healthy', 'degraded', 'unhealthy']).toContain(status.status);
        expect(status.responseTime).toBeGreaterThanOrEqual(0);
        
        if (status.status === 'unhealthy' && status.error) {
          expect(typeof status.error).toBe('string');
        }
      });
    });
  });

  describe('GET /api/health/health/:service', () => {
    it('should return database health check', async () => {
      const response = await request(app)
        .get('/api/health/health/database');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('service', 'database');
      expect(response.body).toHaveProperty('status');
      expect(response.body).toHaveProperty('responseTime');
      expect(['healthy', 'degraded', 'unhealthy']).toContain(response.body.status);
      expect(response.body.responseTime).toBeGreaterThanOrEqual(0);
    });

    it('should include database-specific metrics', async () => {
      const response = await request(app)
        .get('/api/health/health/database');

      if (response.body.details) {
        expect(response.body.details).toHaveProperty('connections');
        expect(response.body.details).toHaveProperty('activeQueries');
        expect(response.body.details).toHaveProperty('poolSize');
        expect(response.body.details.connections).toBeGreaterThanOrEqual(0);
      }
    });

    it('should return AWS services health check', async () => {
      const response = await request(app)
        .get('/api/health/health/aws');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('checks');
      expect(response.body.checks).toHaveProperty('ec2');
      expect(response.body.checks).toHaveProperty('s3');
      expect(response.body.checks).toHaveProperty('rds');
      expect(response.body.checks).toHaveProperty('cloudfront');
      
      // Check individual service statuses
      Object.values(response.body.checks).forEach(service => {
        expect(service).toHaveProperty('status');
        expect(service).toHaveProperty('responseTime');
      });
    });

    it('should include AWS service-specific details', async () => {
      const response = await request(app)
        .get('/api/health/health/aws');

      if (response.body.details) {
        expect(response.body.details).toHaveProperty('regionsChecked');
        expect(response.body.details).toHaveProperty('servicesAvailable');
        expect(response.body.details).toHaveProperty('servicesTotal');
        expect(response.body.details.regionsChecked).toBeGreaterThan(0);
      }
    });

    it('should return system health check', async () => {
      const response = await request(app)
        .get('/api/health/health/system');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('service', 'system');
      expect(response.body).toHaveProperty('status');
      expect(response.body).toHaveProperty('metadata');
      expect(response.body.metadata).toHaveProperty('cpu');
      expect(response.body.metadata).toHaveProperty('memory');
      expect(response.body.metadata).toHaveProperty('disk');
      
      // Validate CPU metrics
      const cpu = response.body.metadata.cpu;
      expect(cpu.usage).toBeGreaterThanOrEqual(0);
      expect(cpu.usage).toBeLessThanOrEqual(100);
      expect(Array.isArray(cpu.loadAverage)).toBe(true);
      expect(cpu.cores).toBeGreaterThan(0);
      
      // Validate memory metrics
      const memory = response.body.metadata.memory;
      expect(memory.percentage).toBeGreaterThanOrEqual(0);
      expect(memory.percentage).toBeLessThanOrEqual(100);
      expect(memory.used).toBeGreaterThanOrEqual(0);
      expect(memory.total).toBeGreaterThan(0);
    });

    it('should include process information', async () => {
      const response = await request(app)
        .get('/api/health/health/system');

      if (response.body.process) {
        expect(response.body.process).toHaveProperty('pid');
        expect(response.body.process).toHaveProperty('uptime');
        expect(response.body.process).toHaveProperty('memoryUsage');
        expect(response.body.process.pid).toBeGreaterThan(0);
        expect(response.body.process.uptime).toBeGreaterThan(0);
      }
    });

    it('should return application health check', async () => {
      const response = await request(app)
        .get('/api/health/health/application');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('service', 'application');
      expect(response.body).toHaveProperty('status');
      expect(response.body).toHaveProperty('metadata');
      
      if (response.body.metadata) {
        expect(response.body.metadata).toHaveProperty('version');
        expect(response.body.metadata).toHaveProperty('environment');
        expect(response.body.metadata).toHaveProperty('uptime');
        expect(response.body.metadata.uptime).toBeGreaterThanOrEqual(0);
      }
    });

    it('should include application-specific metrics', async () => {
      const response = await request(app)
        .get('/api/health/health/application');

      if (response.body.metrics) {
        expect(response.body.metrics).toHaveProperty('activeRequests');
        expect(response.body.metrics).toHaveProperty('requestsPerSecond');
        expect(response.body.metrics).toHaveProperty('errorRate');
        expect(response.body.metrics.activeRequests).toBeGreaterThanOrEqual(0);
        expect(response.body.metrics.requestsPerSecond).toBeGreaterThanOrEqual(0);
        expect(response.body.metrics.errorRate).toBeGreaterThanOrEqual(0);
      }
    });

    it('should return external dependencies health check', async () => {
      const response = await request(app)
        .get('/api/health/health/external');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('service', 'external-dependencies');
      expect(response.body).toHaveProperty('status');
      expect(response.body).toHaveProperty('metadata');
      expect(response.body.metadata).toHaveProperty('count');
      expect(response.body.metadata.count).toBeGreaterThanOrEqual(0);
    });

    it('should list all external services', async () => {
      const response = await request(app)
        .get('/api/health/health/external');

      if (response.body.services) {
        expect(Array.isArray(response.body.services)).toBe(true);
        response.body.services.forEach(service => {
          expect(service).toHaveProperty('name');
          expect(service).toHaveProperty('status');
          expect(service).toHaveProperty('responseTime');
        });
      }
    });

    it('should check GitHub API availability', async () => {
      const response = await request(app)
        .get('/api/health/health/external');

      expect(response.status).toBe(200);
      if (response.body.services) {
        const githubService = response.body.services.find(s => 
          s.name.toLowerCase().includes('github')
        );
        expect(githubService).toBeDefined();
        expect(githubService.status).toBeDefined();
      }
    });

    it('should check NPM registry availability', async () => {
      const response = await request(app)
        .get('/api/health/health/external');

      expect(response.status).toBe(200);
      if (response.body.services) {
        const npmService = response.body.services.find(s => 
          s.name.toLowerCase().includes('npm')
        );
        expect(npmService).toBeDefined();
        expect(npmService.status).toBeDefined();
      }
    });

    it('should return 404 for invalid service name', async () => {
      const response = await request(app)
        .get('/api/health/health/invalid-service');

      expect(response.status).toBe(404);
      expect(response.body).toHaveProperty('message');
      expect(response.body.message).toMatch(/not found|invalid/i);
    });

    it('should handle service name case sensitivity', async () => {
      const responses = await Promise.all([
        request(app).get('/api/health/health/DATABASE'),
        request(app).get('/api/health/health/Database'),
        request(app).get('/api/health/health/database')
      ]);

      responses.forEach(response => {
        expect([200, 404]).toContain(response.status);
      });
    });

    it('should include service-specific response times', async () => {
      const response = await request(app)
        .get('/api/health/health/database');

      expect(response.body.responseTime).toBeGreaterThanOrEqual(0);
      expect(typeof response.body.responseTime).toBe('number');
    });

    it('should handle nested service checks', async () => {
      const response = await request(app)
        .get('/api/health/health/aws');

      if (response.body.checks) {
        Object.values(response.body.checks).forEach(service => {
          expect(service).toHaveProperty('status');
          expect(service).toHaveProperty('responseTime');
          expect(['healthy', 'degraded', 'unhealthy']).toContain(service.status);
        });
      }
    });
  });

  describe('GET /api/health/health/history', () => {
    it('should return health check history', async () => {
      const response = await request(app)
        .get('/api/health/health/history');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('history');
      expect(response.body).toHaveProperty('trends');
      expect(response.body).toHaveProperty('totalEntries');
      expect(response.body).toHaveProperty('timeRange');
      expect(Array.isArray(response.body.history)).toBe(true);
      expect(response.body.totalEntries).toBeGreaterThanOrEqual(0);
      expect(response.body.timeRange).toHaveProperty('start');
      expect(response.body.timeRange).toHaveProperty('end');
    });

    it('should include historical data points', async () => {
      const response = await request(app)
        .get('/api/health/health/history');

      if (response.body.history.length > 0) {
        const entry = response.body.history[0];
        expect(entry).toHaveProperty('timestamp');
        expect(entry).toHaveProperty('overallStatus');
        expect(entry).toHaveProperty('componentStatuses');
        expect(entry).toHaveProperty('responseTime');
        expect(entry.responseTime).toBeGreaterThanOrEqual(0);
      }
    });

    it('should respect limit parameter', async () => {
      const limit = 10;
      const response = await request(app)
        .get(`/api/health/health/history?limit=${limit}`);

      expect(response.status).toBe(200);
      expect(response.body.history.length).toBeLessThanOrEqual(limit);
    });

    it('should handle different limit values', async () => {
      const limits = [1, 5, 10, 50, 100];
      
      for (const limit of limits) {
        const response = await request(app)
          .get(`/api/health/health/history?limit=${limit}`);

        expect(response.status).toBe(200);
        expect(response.body.history.length).toBeLessThanOrEqual(limit);
      }
    });

    it('should filter by time period', async () => {
      const periods = ['1h', '24h', '7d', '30d'];
      
      for (const period of periods) {
        const response = await request(app)
          .get(`/api/health/health/history?period=${period}`);

        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('history');
        expect(response.body).toHaveProperty('trends');
      }
    });

    it('should validate period parameter', async () => {
      const invalidPeriods = ['invalid', '123', 'year', 'hour'];
      
      for (const period of invalidPeriods) {
        const response = await request(app)
          .get(`/api/health/health/history?period=${period}`);

        expect(response.status).toBe(400);
        expect(response.body).toHaveProperty('message');
      }
    });

    it('should calculate trends correctly', async () => {
      const response = await request(app)
        .get('/api/health/health/history');

      expect(response.body.trends).toHaveProperty('last24Hours');
      expect(response.body.trends).toHaveProperty('last7Days');
      expect(response.body.trends).toHaveProperty('last30Days');
      
      // Check trend structure
      Object.values(response.body.trends).forEach(trend => {
        expect(trend).toHaveProperty('availability');
        expect(trend).toHaveProperty('avgResponseTime');
        expect(trend).toHaveProperty('errorCount');
        expect(trend.availability).toBeGreaterThanOrEqual(0);
        expect(trend.availability).toBeLessThanOrEqual(100);
        expect(trend.avgResponseTime).toBeGreaterThanOrEqual(0);
        expect(trend.errorCount).toBeGreaterThanOrEqual(0);
      });
    });

    it('should provide availability metrics', async () => {
      const response = await request(app)
        .get('/api/health/health/history');

      const trends = response.body.trends;
      if (trends.last24Hours) {
        expect(trends.last24Hours.availability).toBeGreaterThanOrEqual(0);
        expect(trends.last24Hours.availability).toBeLessThanOrEqual(100);
        
        if (trends.last24Hours.availability === 100) {
          expect(trends.last24Hours.errorCount).toBe(0);
        }
      }
    });

    it('should include uptime percentage', async () => {
      const response = await request(app)
        .get('/api/health/health/history');

      const trends = response.body.trends;
      if (trends.last7Days) {
        expect(trends.last7Days.uptime).toBeGreaterThanOrEqual(0);
        expect(trends.last7Days.uptime).toBeLessThanOrEqual(100);
      }
    });

    it('should track error frequency', async () => {
      const response = await request(app)
        .get('/api/health/health/history');

      const trends = response.body.trends;
      if (trends.last24Hours) {
        expect(trends.last24Hours.errorRate).toBeGreaterThanOrEqual(0);
        expect(trends.last24Hours.errorRate).toBeLessThanOrEqual(100);
      }
    });

    it('should sort history by timestamp', async () => {
      const response = await request(app)
        .get('/api/health/health/history');

      if (response.body.history.length > 1) {
        const history = response.body.history;
        for (let i = 1; i < history.length; i++) {
          expect(history[i].timestamp).toBeLessThanOrEqual(history[i - 1].timestamp);
        }
      }
    });

    it('should handle empty history', async () => {
      const response = await request(app)
        .get('/api/health/health/history?period=1h');

      expect(response.status).toBe(200);
      expect(Array.isArray(response.body.history)).toBe(true);
      expect(response.body.history).toHaveLength(0);
    });

    it('should include trend visualization data', async () => {
      const response = await request(app)
        .get('/api/health/health/history');

      if (response.body.visualization) {
        expect(response.body.visualization).toHaveProperty('dataPoints');
        expect(response.body.visualization).toHaveProperty('labels');
        expect(Array.isArray(response.body.visualization.dataPoints)).toBe(true);
        expect(Array.isArray(response.body.visualization.labels)).toBe(true);
      }
    });

    it('should calculate moving averages', async () => {
      const response = await request(app)
        .get('/api/health/health/history');

      if (response.body.trends) {
        const trend = response.body.trends.last7Days;
        if (trend.avgResponseTime && trend.movingAvgResponseTime) {
          expect(trend.movingAvgResponseTime).toBeGreaterThanOrEqual(0);
        }
      }
    });
  });

  describe('GET /api/health/health/metrics', () => {
    it('should return system metrics', async () => {
      const response = await request(app)
        .get('/api/health/health/metrics');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('timestamp');
      expect(response.body).toHaveProperty('metrics');
      expect(response.body.metrics).toHaveProperty('cpu');
      expect(response.body.metrics).toHaveProperty('memory');
      expect(response.body.metrics).toHaveProperty('disk');
      expect(response.body.metrics).toHaveProperty('network');
    });

    it('should include CPU metrics', async () => {
      const response = await request(app)
        .get('/api/health/health/metrics');

      const cpu = response.body.metrics.cpu;
      expect(cpu).toHaveProperty('usage');
      expect(cpu).toHaveProperty('loadAverage');
      expect(cpu).toHaveProperty('cores');
      expect(cpu).toHaveProperty('processUsage');
      expect(cpu.usage).toBeGreaterThanOrEqual(0);
      expect(cpu.usage).toBeLessThanOrEqual(100);
      expect(cpu.loadAverage).toHaveLength(3); // 1, 5, 15 minute averages
      expect(cpu.processUsage).toBeGreaterThanOrEqual(0);
      expect(cpu.processUsage).toBeLessThanOrEqual(100);
    });

    it('should include memory metrics', async () => {
      const response = await request(app)
        .get('/api/health/health/metrics');

      const memory = response.body.metrics.memory;
      expect(memory).toHaveProperty('used');
      expect(memory).toHaveProperty('total');
      expect(memory).toHaveProperty('percentage');
      expect(memory).toHaveProperty('heapUsed');
      expect(memory).toHaveProperty('heapTotal');
      expect(memory.percentage).toBeGreaterThanOrEqual(0);
      expect(memory.percentage).toBeLessThanOrEqual(100);
      expect(memory.heapUsed).toBeGreaterThanOrEqual(0);
      expect(memory.heapTotal).toBeGreaterThan(0);
    });

    it('should include disk metrics', async () => {
      const response = await request(app)
        .get('/api/health/health/metrics');

      const disk = response.body.metrics.disk;
      expect(disk).toHaveProperty('used');
      expect(disk).toHaveProperty('total');
      expect(disk).toHaveProperty('percentage');
      expect(disk).toHaveProperty('free');
      expect(disk.percentage).toBeGreaterThanOrEqual(0);
      expect(disk.total).toBeGreaterThan(0);
      expect(disk.free).toBeGreaterThanOrEqual(0);
    });

    it('should include network metrics', async () => {
      const response = await request(app)
        .get('/api/health/health/metrics');

      const network = response.body.metrics.network;
      expect(network).toHaveProperty('bytesIn');
      expect(network).toHaveProperty('bytesOut');
      expect(network).toHaveProperty('packetsIn');
      expect(network).toHaveProperty('packetsOut');
      expect(network.bytesIn).toBeGreaterThanOrEqual(0);
      expect(network.bytesOut).toBeGreaterThanOrEqual(0);
    });

    it('should include process metrics', async () => {
      const response = await request(app)
        .get('/api/health/health/metrics');

      const process = response.body.metrics.process;
      if (process) {
        expect(process).toHaveProperty('uptime');
        expect(process).toHaveProperty('cpuUsage');
        expect(process).toHaveProperty('memoryUsage');
        expect(process.uptime).toBeGreaterThan(0);
        expect(process.cpuUsage).toBeGreaterThanOrEqual(0);
        expect(process.memoryUsage).toBeGreaterThanOrEqual(0);
      }
    });

    it('should provide timestamps', async () => {
      const response = await request(app)
        .get('/api/health/health/metrics');

      expect(typeof response.body.timestamp).toBe('number');
      expect(response.body.timestamp).toBeGreaterThan(Date.now() - 60000); // Within last minute
    });

    it('should handle metric history', async () => {
      const response = await request(app)
        .get('/api/health/health/metrics?history=true');

      expect(response.status).toBe(200);
      if (response.body.history) {
        expect(Array.isArray(response.body.history)).toBe(true);
        expect(response.body.history.length).toBeGreaterThan(0);
      }
    });

    it('should support metric filtering', async () => {
      const response = await request(app)
        .get('/api/health/health/metrics?metrics=cpu,memory');

      expect(response.status).toBe(200);
      expect(response.body.metrics).toHaveProperty('cpu');
      expect(response.body.metrics).toHaveProperty('memory');
    });

    it('should validate metric names', async () => {
      const response = await request(app)
        .get('/api/health/health/metrics?metrics=invalid,metrics');

      expect(response.status).toBe(400);
      expect(response.body).toHaveProperty('message');
    });

    it('should include event loop lag', async () => {
      const response = await request(app)
        .get('/api/health/health/metrics');

      if (response.body.metrics.eventLoop) {
        expect(response.body.metrics.eventLoop).toHaveProperty('lag');
        expect(response.body.metrics.eventLoop.lag).toBeGreaterThanOrEqual(0);
      }
    });
  });

  describe('GET /api/health/status', () => {
    it('should return basic status', async () => {
      const response = await request(app)
        .get('/api/health/status');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('status', 'ok');
      expect(response.body).toHaveProperty('timestamp');
      expect(response.body).toHaveProperty('uptime');
      expect(response.body).toHaveProperty('environment');
      expect(response.body).toHaveProperty('version');
      expect(typeof response.body.uptime).toBe('number');
      expect(response.body.uptime).toBeGreaterThan(0);
    });

    it('should include build information', async () => {
      const response = await request(app)
        .get('/api/health/status');

      expect(response.body).toHaveProperty('build');
      if (response.body.build) {
        expect(response.body.build).toHaveProperty('timestamp');
        expect(response.body.build).toHaveProperty('commit');
      }
    });

    it('should provide runtime information', async () => {
      const response = await request(app)
        .get('/api/health/status');

      expect(response.body).toHaveProperty('runtime');
      if (response.body.runtime) {
        expect(response.body.runtime).toHaveProperty('nodeVersion');
        expect(response.body.runtime).toHaveProperty('platform');
        expect(response.body.runtime).toHaveProperty('arch');
      }
    });

    it('should include dependencies version', async () => {
      const response = await request(app)
        .get('/api/health/status');

      if (response.body.dependencies) {
        expect(response.body.dependencies).toHaveProperty('express');
        expect(response.body.dependencies).toHaveProperty('node');
      }
    });

    it('should track request count', async () => {
      const response = await request(app)
        .get('/api/health/status');

      if (response.body.metrics) {
        expect(response.body.metrics).toHaveProperty('totalRequests');
        expect(response.body.metrics.totalRequests).toBeGreaterThanOrEqual(0);
      }
    });
  });

  describe('GET /api/health/ready', () => {
    it('should return readiness probe status', async () => {
      const response = await request(app)
        .get('/api/health/ready');

      expect([200, 503]).toContain(response.status);
      expect(response.body).toHaveProperty('status');
      expect(response.body).toHaveProperty('timestamp');
      
      if (response.status === 200) {
        expect(response.body.status).toBe('ready');
        expect(response.body).toHaveProperty('checks');
      } else if (response.status === 503) {
        expect(response.body.status).toBe('not_ready');
        expect(response.body).toHaveProperty('error');
        expect(response.body).toHaveProperty('failedChecks');
      }
    });

    it('should check database connectivity', async () => {
      const response = await request(app)
        .get('/api/health/ready');

      // If database is healthy, should return 200
      // If database is unhealthy, should return 503
      expect([200, 503]).toContain(response.status);
      
      if (response.body.checks) {
        const dbCheck = response.body.checks.find(check => 
          check.service === 'database' || check.name === 'database'
        );
        expect(dbCheck).toBeDefined();
        expect(dbCheck).toHaveProperty('status');
      }
    });

    it('should check AWS connectivity', async () => {
      const response = await request(app)
        .get('/api/health/ready');

      if (response.body.checks) {
        const awsCheck = response.body.checks.find(check => 
          check.service === 'aws' || check.name === 'aws'
        );
        expect(awsCheck).toBeDefined();
        expect(awsCheck).toHaveProperty('status');
      }
    });

    it('should validate critical services', async () => {
      const response = await request(app)
        .get('/api/health/ready');

      if (response.status === 503) {
        expect(response.body).toHaveProperty('failedChecks');
        expect(Array.isArray(response.body.failedChecks)).toBe(true);
      }
    });

    it('should include dependency health', async () => {
      const response = await request(app)
        .get('/api/health/ready');

      if (response.body.checks) {
        response.body.checks.forEach(check => {
          expect(check).toHaveProperty('service');
          expect(check).toHaveProperty('status');
          expect(['healthy', 'unhealthy']).toContain(check.status);
        });
      }
    });

    it('should provide response times for checks', async () => {
      const response = await request(app)
        .get('/api/health/ready');

      if (response.body.checks) {
        response.body.checks.forEach(check => {
          if (check.responseTime !== undefined) {
            expect(check.responseTime).toBeGreaterThanOrEqual(0);
          }
        });
      }
    });
  });

  describe('GET /api/health/live', () => {
    it('should return liveness probe status', async () => {
      const response = await request(app)
        .get('/api/health/live');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('status', 'alive');
      expect(response.body).toHaveProperty('timestamp');
      expect(response.body).toHaveProperty('uptime');
      expect(response.body.uptime).toBeGreaterThan(0);
    });

    it('should include process ID', async () => {
      const response = await request(app)
        .get('/api/health/live');

      expect(response.body).toHaveProperty('pid');
      expect(response.body.pid).toBeGreaterThan(0);
    });

    it('should provide memory usage', async () => {
      const response = await request(app)
        .get('/api/health/live');

      if (response.body.memory) {
        expect(response.body.memory).toHaveProperty('used');
        expect(response.body.memory).toHaveProperty('total');
        expect(response.body.memory.used).toBeGreaterThan(0);
        expect(response.body.memory.total).toBeGreaterThan(0);
      }
    });

    it('should include event loop status', async () => {
      const response = await request(app)
        .get('/api/health/live');

      if (response.body.eventLoop) {
        expect(response.body.eventLoop).toHaveProperty('lag');
        expect(response.body.eventLoop.lag).toBeGreaterThanOrEqual(0);
      }
    });

    it('should handle concurrent requests', async () => {
      const requests = Array(10).fill(null).map(() =>
        request(app).get('/api/health/live')
      );

      const responses = await Promise.all(requests);
      
      responses.forEach(response => {
        expect(response.status).toBe(200);
        expect(response.body.status).toBe('alive');
      });
    });
  });

  describe('Query Parameter Tests', () => {
    it('should handle service query parameter', async () => {
      const response = await request(app)
        .get('/api/health/health?service=database');

      expect(response.status).toBe(200);
      expect(response.body.service).toBe('database');
    });

    it('should validate service parameter', async () => {
      const response = await request(app)
        .get('/api/health/health?service=invalid-service');

      expect(response.status).toBe(404);
    });

    it('should return full report without service parameter', async () => {
      const response = await request(app)
        .get('/api/health/health');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('checks');
      expect(response.body).toHaveProperty('systemMetrics');
      expect(response.body).toHaveProperty('summary');
    });

    it('should handle includeDetails parameter', async () => {
      const response = await request(app)
        .get('/api/health/health?includeDetails=true');

      expect(response.status).toBe(200);
      if (response.body.details) {
        expect(typeof response.body.details).toBe('object');
      }
    });

    it('should handle format parameter', async () => {
      const response = await request(app)
        .get('/api/health/health?format=json');

      expect(response.status).toBe(200);
      expect(response.headers['content-type']).toContain('application/json');
    });

    it('should validate format parameter', async () => {
      const response = await request(app)
        .get('/api/health/health?format=xml');

      expect(response.status).toBe(400);
      expect(response.body).toHaveProperty('message');
    });

    it('should handle compact response', async () => {
      const response = await request(app)
        .get('/api/health/health?compact=true');

      expect(response.status).toBe(200);
      // Should have fewer properties
      expect(Object.keys(response.body).length).toBeLessThan(10);
    });

    it('should include metadata when requested', async () => {
      const response = await request(app)
        .get('/api/health/health?metadata=true');

      expect(response.status).toBe(200);
      if (response.body.metadata) {
        expect(typeof response.body.metadata).toBe('object');
      }
    });
  });

  describe('Health Status Validation', () => {
    it('should have consistent status across endpoints', async () => {
      const [basicStatus, readyStatus, liveStatus] = await Promise.all([
        request(app).get('/api/health/status'),
        request(app).get('/api/health/ready'),
        request(app).get('/api/health/live')
      ]);

      // All endpoints should respond successfully
      expect(basicStatus.status).toBe(200);
      expect([200, 503]).toContain(readyStatus.status);
      expect(liveStatus.status).toBe(200);
      
      // Status field should be consistent
      if (basicStatus.body.status && readyStatus.body.status) {
        expect(basicStatus.body.status).toBeDefined();
        expect(readyStatus.body.status).toBeDefined();
      }
    });

    it('should handle concurrent health checks', async () => {
      const requests = Array(10).fill(null).map(() =>
        request(app).get('/api/health/health')
      );

      const responses = await Promise.all(requests);
      
      responses.forEach(response => {
        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('status');
        expect(['healthy', 'degraded', 'unhealthy']).toContain(response.body.status);
      });
    });

    it('should calculate overall health correctly', async () => {
      const response = await request(app)
        .get('/api/health/health');

      const summary = response.body.summary;
      const overallStatus = response.body.status;
      
      if (overallStatus === 'healthy') {
        expect(summary.unhealthy).toBe(0);
        expect(summary.degraded).toBe(0);
      } else if (overallStatus === 'degraded') {
        expect(summary.degraded).toBeGreaterThan(0);
        expect(summary.unhealthy).toBe(0);
      } else if (overallStatus === 'unhealthy') {
        expect(summary.unhealthy).toBeGreaterThan(0);
      }
    });

    it('should track health changes over time', async () => {
      // This would require monitoring system in place
      const responses = [];
      for (let i = 0; i < 3; i++) {
        const response = await request(app).get('/api/health/health');
        responses.push(response);
        await new Promise(resolve => setTimeout(resolve, 100)); // Small delay
      }
      
      responses.forEach(response => {
        expect(response.status).toBe(200);
      });
    });

    it('should validate health check integrity', async () => {
      const response = await request(app)
        .get('/api/health/health');

      // Check that all reported checks are accounted for in summary
      const reportedChecks = Object.keys(response.body.checks);
      const summaryTotal = response.body.summary.total;
      
      expect(reportedChecks.length).toBe(summaryTotal);
    });
  });

  describe('Performance Tests', () => {
    it('should respond to health checks within reasonable time', async () => {
      const startTime = Date.now();
      const response = await request(app)
        .get('/api/health/health');
      const responseTime = Date.now() - startTime;

      expect(response.status).toBe(200);
      expect(responseTime).toBeLessThan(5000); // Should respond within 5 seconds
    });

    it('should handle multiple rapid health check requests', async () => {
      const requests = Array(20).fill(null).map(() =>
        request(app).get('/api/health/health')
      );

      const responses = await Promise.all(requests);
      
      responses.forEach(response => {
        expect(response.status).toBe(200);
      });
    });

    it('should measure response time accurately', async () => {
      const startTime = Date.now();
      const response = await request(app)
        .get('/api/health/status');
      const responseTime = Date.now() - startTime;

      expect(response.status).toBe(200);
      expect(responseTime).toBeGreaterThan(0);
      
      // Response time should be reasonable (under 1 second for status check)
      expect(responseTime).toBeLessThan(1000);
    });

    it('should handle expensive health checks efficiently', async () => {
      const startTime = Date.now();
      const response = await request(app)
        .get('/api/health/health?full=true');
      const responseTime = Date.now() - startTime;

      expect(response.status).toBe(200);
      // Full health check should complete within 10 seconds
      expect(responseTime).toBeLessThan(10000);
    });

    it('should cache expensive operations', async () => {
      const start1 = Date.now();
      await request(app).get('/api/health/health?cached=true');
      const time1 = Date.now() - start1;

      const start2 = Date.now();
      await request(app).get('/api/health/health?cached=true');
      const time2 = Date.now() - start2;

      // Second request should be faster due to caching
      expect(time2).toBeLessThanOrEqual(time1);
    });
  });

  describe('Error Handling', () => {
    it('should handle database connection failures gracefully', async () => {
      const response = await request(app)
        .get('/api/health/health');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('status');
      
      if (response.body.checks.database.status === 'unhealthy') {
        expect(response.body.checks.database).toHaveProperty('error');
        expect(response.body.status).toBe('degraded');
      }
    });

    it('should handle AWS service unavailability', async () => {
      const response = await request(app)
        .get('/api/health/health/aws');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('checks');
      
      // Should still return a response even if AWS is down
      Object.values(response.body.checks).forEach(service => {
        expect(service).toHaveProperty('status');
        expect(['healthy', 'degraded', 'unhealthy']).toContain(service.status);
      });
    });

    it('should provide meaningful error messages', async () => {
      const response = await request(app)
        .get('/api/health/health/invalid-service');

      expect(response.status).toBe(404);
      expect(response.body).toHaveProperty('error');
      expect(response.body).toHaveProperty('message');
      expect(response.body.message).toMatch(/not found|invalid/i);
    });

    it('should handle timeout scenarios', async () => {
      const response = await request(app)
        .get('/api/health/health?timeout=1000')
        .timeout(500);

      expect([200, 408, 500]).toContain(response.status);
    });

    it('should return fallback status when checks fail', async () => {
      const response = await request(app)
        .get('/api/health/health?forceError=true');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('status');
      expect(['degraded', 'unhealthy']).toContain(response.body.status);
    });

    it('should track error frequency', async () => {
      const response = await request(app)
        .get('/api/health/health');

      if (response.body.summary) {
        expect(response.body.summary).toHaveProperty('errorCount');
        expect(response.body.summary.errorCount).toBeGreaterThanOrEqual(0);
      }
    });

    it('should provide diagnostic information for failures', async () => {
      const response = await request(app)
        .get('/api/health/health?detailedErrors=true');

      if (response.body.status === 'degraded' || response.body.status === 'unhealthy') {
        expect(response.body).toHaveProperty('failedChecks');
        expect(Array.isArray(response.body.failedChecks)).toBe(true);
      }
    });
  });

  describe('External Dependencies Health', () => {
    it('should check GitHub API availability', async () => {
      const response = await request(app)
        .get('/api/health/health/external');

      expect(response.status).toBe(200);
      if (response.body.services) {
        const githubService = response.body.services.find(s => 
          s.name.toLowerCase().includes('github')
        );
        expect(githubService).toBeDefined();
        expect(githubService).toHaveProperty('status');
        expect(githubService).toHaveProperty('responseTime');
      }
    });

    it('should check NPM registry availability', async () => {
      const response = await request(app)
        .get('/api/health/health/external');

      expect(response.status).toBe(200);
      if (response.body.services) {
        const npmService = response.body.services.find(s => 
          s.name.toLowerCase().includes('npm')
        );
        expect(npmService).toBeDefined();
        expect(npmService).toHaveProperty('status');
        expect(npmService).toHaveProperty('responseTime');
      }
    });

    it('should handle external service timeouts', async () => {
      const response = await request(app)
        .get('/api/health/health/external?slowCheck=true');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('status');
    });

    it('should retry failed external checks', async () => {
      const response = await request(app)
        .get('/api/health/health/external?retry=true');

      expect(response.status).toBe(200);
      if (response.body.services) {
        response.body.services.forEach(service => {
          expect(service).toHaveProperty('retryCount');
          expect(service.retryCount).toBeGreaterThanOrEqual(0);
        });
      }
    });

    it('should track external dependency trends', async () => {
      const response = await request(app)
        .get('/api/health/health/history?includeExternal=true');

      expect(response.status).toBe(200);
      if (response.body.trends) {
        expect(response.body.trends).toHaveProperty('externalServices');
      }
    });
  });

  describe('System Resource Monitoring', () => {
    it('should monitor CPU usage', async () => {
      const response = await request(app)
        .get('/api/health/health/system');

      expect(response.status).toBe(200);
      const cpu = response.body.metadata.cpu;
      expect(cpu.usage).toBeGreaterThanOrEqual(0);
      expect(cpu.usage).toBeLessThanOrEqual(100);
      expect(Array.isArray(cpu.loadAverage)).toBe(true);
      expect(cpu.loadAverage.length).toBe(3);
      expect(cpu.cores).toBeGreaterThan(0);
    });

    it('should monitor memory usage', async () => {
      const response = await request(app)
        .get('/api/health/health/system');

      expect(response.status).toBe(200);
      const memory = response.body.metadata.memory;
      expect(memory.percentage).toBeGreaterThanOrEqual(0);
      expect(memory.percentage).toBeLessThanOrEqual(100);
      expect(memory.used).toBeGreaterThanOrEqual(0);
      expect(memory.total).toBeGreaterThan(0);
    });

    it('should monitor disk usage', async () => {
      const response = await request(app)
        .get('/api/health/health/system');

      expect(response.status).toBe(200);
      const disk = response.body.metadata.disk;
      expect(disk.percentage).toBeGreaterThanOrEqual(0);
      expect(disk.percentage).toBeLessThanOrEqual(100);
      expect(disk.used).toBeGreaterThanOrEqual(0);
      expect(disk.total).toBeGreaterThan(0);
    });

    it('should track system uptime', async () => {
      const response = await request(app)
        .get('/api/health/health');

      expect(response.status).toBe(200);
      expect(response.body.uptime).toBeGreaterThan(0);
      expect(typeof response.body.uptime).toBe('number');
      expect(response.body.uptime).toBeGreaterThan(60); // Should be at least 60 seconds
    });

    it('should include process information', async () => {
      const response = await request(app)
        .get('/api/health/health/system');

      if (response.body.process) {
        expect(response.body.process).toHaveProperty('pid');
        expect(response.body.process).toHaveProperty('uptime');
        expect(response.body.process).toHaveProperty('memoryUsage');
        expect(response.body.process.pid).toBeGreaterThan(0);
        expect(response.body.process.uptime).toBeGreaterThan(0);
      }
    });

    it('should track event loop lag', async () => {
      const response = await request(app)
        .get('/api/health/health/metrics');

      if (response.body.metrics.eventLoop) {
        expect(response.body.metrics.eventLoop).toHaveProperty('lag');
        expect(response.body.metrics.eventLoop.lag).toBeGreaterThanOrEqual(0);
      }
    });

    it('should monitor garbage collection', async () => {
      const response = await request(app)
        .get('/api/health/health/metrics');

      if (response.body.metrics.gc) {
        expect(response.body.metrics.gc).toHaveProperty('collections');
        expect(response.body.metrics.gc.collections).toBeGreaterThanOrEqual(0);
        expect(response.body.metrics.gc).toHaveProperty('totalTime');
        expect(response.body.metrics.gc.totalTime).toBeGreaterThanOrEqual(0);
      }
    });

    it('should track network statistics', async () => {
      const response = await request(app)
        .get('/api/health/health/metrics');

      const network = response.body.metrics.network;
      expect(network).toHaveProperty('bytesIn');
      expect(network).toHaveProperty('bytesOut');
      expect(network).toHaveProperty('packetsIn');
      expect(network).toHaveProperty('packetsOut');
      expect(network.bytesIn).toBeGreaterThanOrEqual(0);
      expect(network.bytesOut).toBeGreaterThanOrEqual(0);
    });
  });

  describe('Health Trends and History', () => {
    it('should calculate health trends', async () => {
      const response = await request(app)
        .get('/api/health/health/history');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('trends');
      expect(response.body.trends).toHaveProperty('last24Hours');
      expect(response.body.trends).toHaveProperty('last7Days');
      expect(response.body.trends).toHaveProperty('last30Days');
    });

    it('should provide availability metrics', async () => {
      const response = await request(app)
        .get('/api/health/health/history');

      expect(response.status).toBe(200);
      const trends = response.body.trends;
      
      Object.values(trends).forEach(trend => {
        expect(trend).toHaveProperty('availability');
        expect(trend.availability).toBeGreaterThanOrEqual(0);
        expect(trend.availability).toBeLessThanOrEqual(100);
      });
    });

    it('should track error rates over time', async () => {
      const response = await request(app)
        .get('/api/health/health/history');

      const trends = response.body.trends;
      if (trends.last24Hours) {
        expect(trends.last24Hours).toHaveProperty('errorRate');
        expect(trends.last24Hours.errorRate).toBeGreaterThanOrEqual(0);
        expect(trends.last24Hours.errorRate).toBeLessThanOrEqual(100);
      }
    });

    it('should calculate mean time between failures', async () => {
      const response = await request(app)
        .get('/api/health/health/history');

      const trends = response.body.trends;
      if (trends.last7Days && trends.last7Days.mtbf) {
        expect(trends.last7Days.mtbf).toBeGreaterThanOrEqual(0);
      }
    });

    it('should provide performance trends', async () => {
      const response = await request(app)
        .get('/api/health/health/history');

      const trends = response.body.trends;
      if (trends.last24Hours) {
        expect(trends.last24Hours).toHaveProperty('avgResponseTime');
        expect(trends.last24Hours.avgResponseTime).toBeGreaterThanOrEqual(0);
      }
    });

    it('should include uptime percentage', async () => {
      const response = await request(app)
        .get('/api/health/health/history');

      const trends = response.body.trends;
      if (trends.last30Days) {
        expect(trends.last30Days).toHaveProperty('uptime');
        expect(trends.last30Days.uptime).toBeGreaterThanOrEqual(0);
        expect(trends.last30Days.uptime).toBeLessThanOrEqual(100);
      }
    });
  });

  describe('Content Type and Headers', () => {
    it('should return JSON content type', async () => {
      const response = await request(app)
        .get('/api/health/health');

      expect(response.headers['content-type']).toContain('application/json');
    });

    it('should include timestamp in response', async () => {
      const response = await request(app)
        .get('/api/health/health');

      expect(response.body.timestamp).toBeDefined();
      expect(typeof response.body.timestamp).toBe('number');
      
      const timestamp = new Date(response.body.timestamp);
      expect(isNaN(timestamp.getTime())).toBe(false);
    });

    it('should include version information', async () => {
      const response = await request(app)
        .get('/api/health/health');

      expect(response.body).toHaveProperty('version');
      expect(response.body).toHaveProperty('environment');
      expect(response.body.version).toBeDefined();
      expect(response.body.environment).toBeDefined();
    });

    it('should include server information', async () => {
      const response = await request(app)
        .get('/api/health/health');

      expect(response.headers).toHaveProperty('server');
    });

    it('should include response headers', async () => {
      const response = await request(app)
        .get('/api/health/health');

      expect(response.headers).toHaveProperty('content-length');
      expect(response.headers).toHaveProperty('content-type');
    });

    it('should handle caching headers', async () => {
      const response = await request(app)
        .get('/api/health/status');

      // Health checks often have no-cache headers
      if (response.headers['cache-control']) {
        expect(response.headers['cache-control']).toContain('no-cache');
      }
    });
  });

  describe('Real-time Monitoring', () => {
    it('should provide real-time health updates', async () => {
      // This would require WebSocket or SSE in real implementation
      const responses = [];
      for (let i = 0; i < 3; i++) {
        const response = await request(app).get('/api/health/health');
        responses.push(response.body.timestamp);
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      // Timestamps should be increasing
      for (let i = 1; i < responses.length; i++) {
        expect(responses[i]).toBeGreaterThanOrEqual(responses[i - 1]);
      }
    });

    it('should track health changes', async () => {
      const response1 = await request(app).get('/api/health/health');
      await new Promise(resolve => setTimeout(resolve, 1000));
      const response2 = await request(app).get('/api/health/health');

      expect(response1.status).toBe(200);
      expect(response2.status).toBe(200);
      
      // Status might change over time
      expect(['healthy', 'degraded', 'unhealthy']).toContain(response2.body.status);
    });

    it('should monitor alert thresholds', async () => {
      const response = await request(app)
        .get('/api/health/health?alerts=true');

      expect(response.status).toBe(200);
      if (response.body.alerts) {
        expect(response.body.alerts).toBeInstanceOf(Array);
        response.body.alerts.forEach(alert => {
          expect(alert).toHaveProperty('level');
          expect(alert).toHaveProperty('message');
          expect(['info', 'warning', 'critical']).toContain(alert.level);
        });
      }
    });
  });

  describe('Integration with Monitoring Systems', () => {
    it('should provide Prometheus format metrics', async () => {
      const response = await request(app)
        .get('/api/metrics');

      expect(response.status).toBe(200);
      expect(response.headers['content-type']).toContain('text/plain');
      expect(typeof response.text).toBe('string');
    });

    it('should include health check counters', async () => {
      const response = await request(app)
        .get('/api/metrics');

      if (response.text) {
        expect(response.text).toContain('health_check');
      }
    });

    it('should track health check duration', async () => {
      const response = await request(app)
        .get('/api/metrics');

      if (response.text) {
        expect(response.text).toContain('health_check_duration');
      }
    });

    it('should expose system metrics', async () => {
      const response = await request(app)
        .get('/api/metrics');

      if (response.text) {
        expect(response.text).toContain('process_cpu_seconds_total');
        expect(response.text).toContain('process_resident_memory_bytes');
      }
    });
  });

  describe('Edge Cases and Special Scenarios', () => {
    it('should handle startup scenario', async () => {
      const response = await request(app)
        .get('/api/health/health?startup=true');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('phase');
      expect(response.body.phase).toBe('startup');
    });

    it('should handle maintenance mode', async () => {
      const response = await request(app)
        .get('/api/health/health?maintenance=true');

      expect(response.status).toBe(200);
      if (response.body.maintenance) {
        expect(response.body.maintenance).toHaveProperty('mode');
        expect(response.body.maintenance.mode).toBe(true);
      }
    });

    it('should handle deployment scenarios', async () => {
      const response = await request(app)
        .get('/api/health/health?deployment=true');

      expect(response.status).toBe(200);
      if (response.body.deployment) {
        expect(response.body.deployment).toHaveProperty('status');
      }
    });

    it('should handle resource exhaustion', async () => {
      const response = await request(app)
        .get('/api/health/health?stressTest=true');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('status');
    });

    it('should handle network partition scenarios', async () => {
      const response = await request(app)
        .get('/api/health/health?networkPartition=true');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('status');
    });
  });
});
