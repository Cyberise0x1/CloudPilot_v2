# Integration Tests Guide

This directory contains comprehensive integration tests for the CloudPilot Production API. The tests cover all major functionality including authentication, AWS endpoints, health checks, monitoring, and error handling.

## Test Structure

```
__tests__/
├── auth.integration.test.ts          # Authentication tests (login, register, logout)
├── aws-endpoints.integration.test.ts # AWS CRUD operations (EC2, S3, RDS, CloudFront)
├── health.integration.test.ts        # Health check endpoints
├── monitoring.integration.test.ts    # Metrics and logging tests
├── error-handling.integration.test.ts # Error scenarios and validation
├── setup/
│   ├── setup.ts                      # Global test setup and utilities
│   └── global-teardown.ts            # Global test cleanup
└── test-sequencer.js                 # Custom test execution order
```

## Test Coverage

### Authentication Tests (`auth.integration.test.ts`)
- ✅ User registration with validation
- ✅ User login with credential verification
- ✅ Token refresh mechanism
- ✅ User logout and session cleanup
- ✅ Protected route access control
- ✅ JWT token validation and expiration
- ✅ Security tests (timing attacks, concurrent requests)
- ✅ Input validation and sanitization

### AWS Endpoints Tests (`aws-endpoints.integration.test.ts`)
- ✅ AWS Account management (create, activate, list)
- ✅ EC2 Instance operations (launch, start, stop, terminate, bulk actions)
- ✅ Elastic IP management (allocate, release, associate)
- ✅ S3 Bucket operations (create, delete, list, upload, download)
- ✅ RDS Instance management (create, start, stop, delete, reboot)
- ✅ CloudFront Distribution operations (create, delete, invalidate)
- ✅ Utility endpoints (quota check, region enablement, export)
- ✅ Authentication requirements for all AWS endpoints
- ✅ Error handling for AWS service failures

### Health Check Tests (`health.integration.test.ts`)
- ✅ Comprehensive health reporting (`/api/health/health`)
- ✅ Service-specific health checks (database, AWS, system, application)
- ✅ Health check history and trends
- ✅ System metrics monitoring (CPU, memory, disk, uptime)
- ✅ Liveness and readiness probes
- ✅ External dependencies monitoring
- ✅ Performance and concurrent request handling
- ✅ Health status validation and consistency

### Monitoring Tests (`monitoring.integration.test.ts`)
- ✅ Prometheus metrics endpoint (`/api/metrics`)
- ✅ Monitoring dashboard endpoints
- ✅ Metrics collection and visualization
- ✅ Performance trends and comparisons
- ✅ Error logging and analysis
- ✅ Alert creation and management
- ✅ Health overview and service status
- ✅ Data export functionality
- ✅ Authentication requirements

### Error Handling Tests (`error-handling.integration.test.ts`)
- ✅ Authentication error scenarios (invalid tokens, expired tokens)
- ✅ Request validation and input sanitization
- ✅ Resource not found errors (404, 405)
- ✅ Server error handling and graceful degradation
- ✅ Rate limiting and throttling
- ✅ Security vulnerabilities (XSS, SQL injection)
- ✅ File upload error handling
- ✅ Memory and resource limit testing
- ✅ Network timeout handling
- ✅ Error response format consistency

## Prerequisites

Before running the integration tests, ensure you have:

1. **Dependencies installed**: Run `npm install` to install all required packages
2. **Test environment configured**: The tests automatically configure test environment variables
3. **Server dependencies**: All server dependencies should be available (mocked in tests)

## Running the Tests

### Run All Integration Tests
```bash
npm run test:integration:__tests__
```

### Run Specific Test Suites
```bash
# Authentication tests only
npm run test:integration:auth:__tests__

# AWS endpoints tests only
npm run test:integration:aws:__tests__

# Health check tests only
npm run test:integration:health:__tests__

# Monitoring tests only
npm run test:integration:monitoring:__tests__

# Error handling tests only
npm run test:integration:errors:__tests__
```

### Run Tests with Different Options

#### Watch Mode (auto-rerun on file changes)
```bash
npm run test:watch -- --testPathPattern='__tests__/.*integration\\.test\\.ts'
```

#### With Coverage Report
```bash
npm run test:integration:__tests__ -- --coverage
```

#### Specific Test Pattern
```bash
npm test -- --testNamePattern="should login successfully"
```

#### Debug Mode (runs tests in sequence)
```bash
npm run test:integration:__tests__ -- --runInBand
```

#### Verbose Output
```bash
npm run test:integration:__tests__ -- --verbose
```

### Test Execution Order

The tests run in the following order for optimal reliability:
1. Authentication tests (dependencies for other tests)
2. Health check tests (infrastructure validation)
3. Monitoring tests (system functionality)
4. Error handling tests (system robustness)
5. AWS endpoints tests (functional testing)

## Configuration

### Environment Variables
The tests automatically set these environment variables:
```javascript
NODE_ENV = 'test'
JWT_SECRET = 'test-jwt-secret-key-for-integration-tests'
DATABASE_URL = 'postgresql://test:test@localhost:5432/test_db'
AWS_ACCESS_KEY_ID = 'test-access-key-id'
AWS_SECRET_ACCESS_KEY = 'test-secret-access-key'
AWS_REGION = 'us-east-1'
```

### Test Timeout
- Default timeout: 30 seconds per test
- Database operations: 30 seconds
- Can be adjusted per test with `jest.setTimeout()`

### Coverage Thresholds
The Jest configuration includes coverage thresholds:
- Branches: 80%
- Functions: 80%
- Lines: 80%
- Statements: 80%

## Mock Services

The tests use comprehensive mocking to avoid external dependencies:

### External Services
- ✅ AWS SDK services (mocked)
- ✅ Database connections (mocked)
- ✅ Secrets manager (mocked)
- ✅ Environment validator (mocked)

### Middleware
- ✅ Request logging middleware (mocked)
- ✅ Metrics tracking middleware (mocked)
- ✅ Error tracking middleware (mocked)
- ✅ Performance monitoring middleware (mocked)

## Test Utilities

Global utilities available in all tests:

### `waitFor(condition, timeout)`
Wait for a condition to become true within a timeout period.

### `generateTestData`
Generate random test data:
- `email()`: Random test email
- `accountId()`: Random AWS account ID
- `instanceId()`: Random EC2 instance ID
- `bucketName()`: Random S3 bucket name
- `region()`: AWS region

### `createMockRequest(overrides)`
Create a mock Express request object with optional overrides.

### `createMockResponse()`
Create a mock Express response object.

### Custom Matchers
- `toBeWithinRange(floor, ceiling)`: Assert number is within range
- `toHaveValidJsonStructure()`: Assert object has valid JSON structure

## Troubleshooting

### Common Issues

#### Tests Timeout
```bash
# Increase timeout for specific test
jest.setTimeout(60000); // 60 seconds
```

#### Database Connection Issues
Tests use mocked database operations, so actual database connections aren't required.

#### AWS Credentials Errors
Tests use mocked AWS services, so real AWS credentials aren't needed.

#### Port Binding Errors
Tests run in isolation and don't require the actual server to be running.

### Debug Mode
```bash
# Enable debug logging
DEBUG_TESTS=1 npm run test:integration:__tests__

# Run specific test with debugging
npm test -- --testNamePattern="should login successfully" --verbose
```

### Clear Jest Cache
```bash
npm run test:clear
```

## Performance Considerations

### Test Execution
- Tests run in parallel by default (max 50% of CPU cores)
- Sequential execution available with `--runInBand`
- Specific test patterns can reduce execution time

### Memory Usage
- Tests clean up after each test case
- Global teardown ensures complete cleanup
- Mock services prevent memory leaks from external connections

## CI/CD Integration

For continuous integration, use:
```bash
npm run test:integration:__tests__ -- --ci --coverage --watchAll=false --maxWorkers=2
```

This configuration:
- Runs tests in CI mode
- Generates coverage reports
- Disables watch mode
- Limits workers for stability

## Best Practices

### Writing New Tests
1. Follow the existing pattern structure
2. Use descriptive test names
3. Include both positive and negative test cases
4. Mock external dependencies
5. Clean up after each test
6. Use the provided utility functions

### Test Data Management
1. Use `generateTestData` for random data
2. Avoid hard-coded values
3. Use unique identifiers to prevent conflicts
4. Clean up test data in `afterEach` or `afterAll`

### Error Testing
1. Test both happy path and error scenarios
2. Verify error response format
3. Test input validation thoroughly
4. Include security vulnerability tests

## Contributing

When adding new integration tests:
1. Place in appropriate test file
2. Follow existing naming conventions
3. Update this README if adding new test categories
4. Ensure all tests pass before submitting
5. Include coverage for edge cases and error conditions

## Support

If you encounter issues with the integration tests:
1. Check the troubleshooting section above
2. Review the test output for specific error messages
3. Ensure all dependencies are installed
4. Try running with increased timeout or debug mode
5. Check Jest configuration if tests aren't being discovered

The integration tests are designed to be comprehensive, reliable, and maintainable. They provide thorough coverage of the API functionality and help ensure the quality and stability of the CloudPilot Production system.
