/**
 * AWS Endpoints Integration Tests
 * Comprehensive tests for all AWS CRUD operations including EC2, S3, RDS, CloudFront
 */

import { describe, it, expect, beforeAll, afterAll, beforeEach, afterEach } from 'vitest';
import request from 'supertest';
import { app } from '../server/index';

describe('AWS Endpoints Integration Tests', () => {
  let authToken: string;
  let refreshToken: string;
  let accountId: string;

  const validAccountData = {
    accountName: 'Test AWS Account',
    accessKeyId: 'AKIAIOSFODNN7EXAMPLE',
    secretAccessKey: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
    region: 'us-east-1'
  };

  const validLaunchData = {
    accountId: 'test-account-id',
    imageId: 'ami-0abcdef1234567890',
    instanceType: 't2.micro',
    minCount: 1,
    maxCount: 1,
    region: 'us-east-1'
  };

  beforeAll(async () => {
    // Login to get authentication token
    const loginResponse = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'test@example.com',
        password: 'TestPassword123!'
      });

    if (loginResponse.status === 200) {
      authToken = loginResponse.body.accessToken;
      refreshToken = loginResponse.body.refreshToken;
      accountId = 'test-account-id'; // This would be set after creating an account
    }
  });

  describe('AWS Account Management', () => {
    describe('POST /api/aws-accounts', () => {
      it('should create AWS account successfully', async () => {
        const uniqueAccountName = `Test Account ${Date.now()}`;
        const response = await request(app)
          .post('/api/aws-accounts')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            ...validAccountData,
            accountName: uniqueAccountName
          });

        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('id');
        expect(response.body).toHaveProperty('accountName');
      });

      it('should return 400 for invalid AWS credentials', async () => {
        const response = await request(app)
          .post('/api/aws-accounts')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            ...validAccountData,
            accessKeyId: 'invalid-key'
          });

        expect(response.status).toBe(400);
        expect(response.body).toHaveProperty('message');
      });

      it('should return 400 for invalid secret key format', async () => {
        const response = await request(app)
          .post('/api/aws-accounts')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            ...validAccountData,
            secretAccessKey: 'invalid-secret'
          });

        expect(response.status).toBe(400);
        expect(response.body).toHaveProperty('message');
      });

      it('should return 400 for invalid region', async () => {
        const response = await request(app)
          .post('/api/aws-accounts')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            ...validAccountData,
            region: 'invalid-region'
          });

        expect(response.status).toBe(400);
        expect(response.body).toHaveProperty('message');
      });

      it('should return 400 for missing required fields', async () => {
        const incompleteData = [
          { accountName: 'Test Account' }, // Missing accessKeyId and secretAccessKey
          { accessKeyId: 'AKIAIOSFODNN7EXAMPLE' }, // Missing accountName and secretAccessKey
          { secretAccessKey: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY' }, // Missing accountName and accessKeyId
          {}, // Missing all
          { accountName: '', accessKeyId: '', secretAccessKey: '' } // Empty fields
        ];

        for (const data of incompleteData) {
          const response = await request(app)
            .post('/api/aws-accounts')
            .set('Authorization', `Bearer ${authToken}`)
            .send(data);

          expect(response.status).toBe(400);
          expect(response.body).toHaveProperty('message');
        }
      });

      it('should return 401 without authentication', async () => {
        const response = await request(app)
          .post('/api/aws-accounts')
          .send(validAccountData);

        expect(response.status).toBe(401);
      });

      it('should sanitize account names', async () => {
        const response = await request(app)
          .post('/api/aws-accounts')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            ...validAccountData,
            accountName: '<script>alert("xss")</script>'
          });

        // Should either sanitize or reject
        expect([400, 500]).toContain(response.status);
      });

      it('should handle very long account names', async () => {
        const longAccountName = 'a'.repeat(2000);
        const response = await request(app)
          .post('/api/aws-accounts')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            ...validAccountData,
            accountName: longAccountName
          });

        expect([400, 413]).toContain(response.status);
      });

      it('should validate AWS access key format', async () => {
        const invalidAccessKeys = [
          'AKIA1234567890', // Too short
          'AKIAIOSFODNN7EXAMPL', // Too long
          'invalid-key-format',
          '12345678901234567890',
          'AKIAI44QH8DHBEXAMPLE' // Invalid checksum
        ];

        for (const key of invalidAccessKeys) {
          const response = await request(app)
            .post('/api/aws-accounts')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              ...validAccountData,
              accessKeyId: key
            });

          expect(response.status).toBe(400);
        }
      });

      it('should handle special characters in account name', async () => {
        const specialNames = [
          'Account with "quotes"',
          "Account with 'apostrophes'",
          'Account with Ünicöde',
          'Account\twith\ttabs',
          'Account\nwith\nnewlines'
        ];

        for (const name of specialNames) {
          const response = await request(app)
            .post('/api/aws-accounts')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              ...validAccountData,
              accountName: name
            });

          expect([200, 400, 500]).toContain(response.status);
        }
      });
    });

    describe('GET /api/aws-accounts', () => {
      it('should return list of AWS accounts', async () => {
        const response = await request(app)
          .get('/api/aws-accounts')
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
        expect(Array.isArray(response.body)).toBe(true);
      });

      it('should return 401 without authentication', async () => {
        const response = await request(app)
          .get('/api/aws-accounts');

        expect(response.status).toBe(401);
      });

      it('should return empty array when no accounts exist', async () => {
        const response = await request(app)
          .get('/api/aws-accounts')
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
        expect(Array.isArray(response.body)).toBe(true);
        expect(response.body).toHaveLength(0);
      });

      it('should include account metadata', async () => {
        const response = await request(app)
          .get('/api/aws-accounts')
          .set('Authorization', `Bearer ${authToken}`);

        if (response.body.length > 0) {
          const account = response.body[0];
          expect(account).toHaveProperty('id');
          expect(account).toHaveProperty('accountName');
          expect(account).toHaveProperty('region');
          expect(account).toHaveProperty('isActive');
        }
      });

      it('should handle concurrent requests', async () => {
        const requests = Array(5).fill(null).map(() =>
          request(app)
            .get('/api/aws-accounts')
            .set('Authorization', `Bearer ${authToken}`)
        );

        const responses = await Promise.all(requests);
        
        responses.forEach(response => {
          expect(response.status).toBe(200);
          expect(Array.isArray(response.body)).toBe(true);
        });
      });
    });

    describe('POST /api/aws-accounts/:id/activate', () => {
      it('should activate AWS account', async () => {
        const response = await request(app)
          .post(`/api/aws-accounts/${accountId}/activate`)
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('success', true);
      });

      it('should return 404 for non-existent account', async () => {
        const response = await request(app)
          .post('/api/aws-accounts/non-existent-id/activate')
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(404);
      });

      it('should return 401 without authentication', async () => {
        const response = await request(app)
          .post(`/api/aws-accounts/${accountId}/activate`);

        expect(response.status).toBe(401);
      });

      it('should handle invalid account ID format', async () => {
        const response = await request(app)
          .post('/api/aws-accounts/invalid-id-format/activate')
          .set('Authorization', `Bearer ${authToken}`);

        expect([400, 404]).toContain(response.status);
      });

      it('should handle activation errors gracefully', async () => {
        // This would depend on AWS service availability
        const response = await request(app)
          .post(`/api/aws-accounts/${accountId}/activate`)
          .set('Authorization', `Bearer ${authToken}`);

        expect([200, 500]).toContain(response.status);
        if (response.status === 200) {
          expect(response.body).toHaveProperty('success');
        }
      });
    });
  });

  describe('EC2 Instance Management', () => {
    describe('GET /api/aws/instances/:region/:accountId', () => {
      it('should return EC2 instances list', async () => {
        const response = await request(app)
          .get('/api/aws/instances/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
        expect(Array.isArray(response.body)).toBe(true);
      });

      it('should return 404 for non-existent account', async () => {
        const response = await request(app)
          .get('/api/aws/instances/us-east-1/non-existent-account')
          .set('Authorization', `Bearer ${authToken}`);

        expect([404, 500]).toContain(response.status);
        if (response.status === 404) {
          expect(response.body).toHaveProperty('message');
        }
      });

      it('should return 400 for invalid region', async () => {
        const response = await request(app)
          .get('/api/aws/instances/invalid-region/test-account-id')
          .set('Authorization', `Bearer ${authToken}`);

        expect([400, 500]).toContain(response.status);
      });

      it('should handle AWS API errors gracefully', async () => {
        const response = await request(app)
          .get('/api/aws/instances/invalid-region/test-account-id')
          .set('Authorization', `Bearer ${authToken}`);

        // This might return 500 due to AWS API errors
        expect([400, 500]).toContain(response.status);
        expect(response.body).toHaveProperty('message');
      });

      it('should filter instances by state', async () => {
        const response = await request(app)
          .get('/api/aws/instances/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
          .query({ state: 'running' });

        expect(response.status).toBe(200);
        expect(Array.isArray(response.body)).toBe(true);
      });

      it('should paginate results', async () => {
        const response = await request(app)
          .get('/api/aws/instances/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
          .query({ limit: 10, offset: 0 });

        expect(response.status).toBe(200);
        expect(Array.isArray(response.body)).toBe(true);
      });

      it('should return instance metadata', async () => {
        const response = await request(app)
          .get('/api/aws/instances/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`);

        if (response.body.length > 0) {
          const instance = response.body[0];
          expect(instance).toHaveProperty('InstanceId');
          expect(instance).toHaveProperty('State');
          expect(instance).toHaveProperty('InstanceType');
        }
      });
    });

    describe('POST /api/aws/instances/launch', () => {
      it('should launch EC2 instance successfully', async () => {
        const launchData = {
          ...validLaunchData,
          accountId: 'test-account-id'
        };

        const response = await request(app)
          .post('/api/aws/instances/launch')
          .set('Authorization', `Bearer ${authToken}`)
          .send(launchData);

        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('instanceId');
      });

      it('should return 400 for invalid instance type', async () => {
        const response = await request(app)
          .post('/api/aws/instances/launch')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            ...validLaunchData,
            instanceType: 'invalid-type'
          });

        expect(response.status).toBe(400);
        expect(response.body).toHaveProperty('message');
      });

      it('should return 400 for invalid AMI', async () => {
        const response = await request(app)
          .post('/api/aws/instances/launch')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            ...validLaunchData,
            imageId: 'ami-invalid'
          });

        expect(response.status).toBe(400);
        expect(response.body).toHaveProperty('message');
      });

      it('should return 400 for invalid min/max count', async () => {
        const invalidCounts = [
          { minCount: 0, maxCount: 1 },
          { minCount: 5, maxCount: 3 },
          { minCount: -1, maxCount: 1 },
          { minCount: 1, maxCount: 0 }
        ];

        for (const count of invalidCounts) {
          const response = await request(app)
            .post('/api/aws/instances/launch')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              ...validLaunchData,
              ...count
            });

          expect(response.status).toBe(400);
        }
      });

      it('should return 404 for non-existent account', async () => {
        const response = await request(app)
          .post('/api/aws/instances/launch')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            ...validLaunchData,
            accountId: 'non-existent-account'
          });

        expect(response.status).toBe(404);
        expect(response.body).toHaveProperty('message');
      });

      it('should validate security groups', async () => {
        const response = await request(app)
          .post('/api/aws/instances/launch')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            ...validLaunchData,
            securityGroupIds: ['sg-invalid']
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should handle key pair validation', async () => {
        const response = await request(app)
          .post('/api/aws/instances/launch')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            ...validLaunchData,
            keyName: 'non-existent-key'
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should handle subnet selection', async () => {
        const response = await request(app)
          .post('/api/aws/instances/launch')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            ...validLaunchData,
            subnetId: 'subnet-12345'
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should handle user data', async () => {
        const response = await request(app)
          .post('/api/aws/instances/launch')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            ...validLaunchData,
            userData: '#!/bin/bash\necho "Hello World"'
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should handle tags', async () => {
        const response = await request(app)
          .post('/api/aws/instances/launch')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            ...validLaunchData,
            tags: [
              { Key: 'Name', Value: 'Test Instance' },
              { Key: 'Environment', Value: 'Test' }
            ]
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should handle monitoring options', async () => {
        const response = await request(app)
          .post('/api/aws/instances/launch')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            ...validLaunchData,
            monitoring: { Enabled: true }
          });

        expect([200, 400, 500]).toContain(response.status);
      });
    });

    describe('POST /api/aws/instances/start', () => {
      it('should start EC2 instance', async () => {
        const response = await request(app)
          .post('/api/aws/instances/start')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            instanceId: 'i-1234567890abcdef0',
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([200, 500]).toContain(response.status);
      });

      it('should return 400 for invalid instance ID format', async () => {
        const response = await request(app)
          .post('/api/aws/instances/start')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            instanceId: 'invalid-id',
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([400, 500]).toContain(response.status);
      });

      it('should return 400 for missing required fields', async () => {
        const incompleteData = [
          { region: 'us-east-1', accountId: 'test-account-id' }, // Missing instanceId
          { instanceId: 'i-1234567890abcdef0', accountId: 'test-account-id' }, // Missing region
          { instanceId: 'i-1234567890abcdef0', region: 'us-east-1' } // Missing accountId
        ];

        for (const data of incompleteData) {
          const response = await request(app)
            .post('/api/aws/instances/start')
            .set('Authorization', `Bearer ${authToken}`)
            .send(data);

          expect(response.status).toBe(400);
          expect(response.body).toHaveProperty('message');
        }
      });

      it('should handle already running instances', async () => {
        const response = await request(app)
          .post('/api/aws/instances/start')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            instanceId: 'i-running-instance',
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should return 404 for non-existent instance', async () => {
        const response = await request(app)
          .post('/api/aws/instances/start')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            instanceId: 'i-non-existent',
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([404, 500]).toContain(response.status);
      });
    });

    describe('POST /api/aws/instances/stop', () => {
      it('should stop EC2 instance', async () => {
        const response = await request(app)
          .post('/api/aws/instances/stop')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            instanceId: 'i-1234567890abcdef0',
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([200, 500]).toContain(response.status);
      });

      it('should handle force stop option', async () => {
        const response = await request(app)
          .post('/api/aws/instances/stop')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            instanceId: 'i-1234567890abcdef0',
            region: 'us-east-1',
            accountId: 'test-account-id',
            force: true
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should return 400 for already stopped instances', async () => {
        const response = await request(app)
          .post('/api/aws/instances/stop')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            instanceId: 'i-stopped-instance',
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should validate stop permissions', async () => {
        const response = await request(app)
          .post('/api/aws/instances/stop')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            instanceId: 'i-no-permission',
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([200, 400, 500, 403]).toContain(response.status);
      });
    });

    describe('POST /api/aws/instances/terminate', () => {
      it('should terminate EC2 instance', async () => {
        const response = await request(app)
          .post('/api/aws/instances/terminate')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            instanceId: 'i-1234567890abcdef0',
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([200, 500]).toContain(response.status);
      });

      it('should ask for confirmation for termination', async () => {
        const response = await request(app)
          .post('/api/aws/instances/terminate')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            instanceId: 'i-1234567890abcdef0',
            region: 'us-east-1',
            accountId: 'test-account-id',
            confirm: true
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should return 400 without confirmation', async () => {
        const response = await request(app)
          .post('/api/aws/instances/terminate')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            instanceId: 'i-1234567890abcdef0',
            region: 'us-east-1',
            accountId: 'test-account-id'
            // No confirm field
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should handle protected instances', async () => {
        const response = await request(app)
          .post('/api/aws/instances/terminate')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            instanceId: 'i-protected',
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should handle termination protection', async () => {
        const response = await request(app)
          .post('/api/aws/instances/terminate')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            instanceId: 'i-with-protection',
            region: 'us-east-1',
            accountId: 'test-account-id',
            force: true
          });

        expect([200, 400, 500]).toContain(response.status);
      });
    });

    describe('Bulk Operations', () => {
      describe('POST /api/aws/instances/bulk-action', () => {
        it('should perform bulk start operation', async () => {
          const response = await request(app)
            .post('/api/aws/instances/bulk-action')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              instanceIds: ['i-1234567890abcdef0', 'i-abcdef1234567890'],
              action: 'start',
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect(response.status).toBe(200);
          expect(response.body).toHaveProperty('results');
          expect(Array.isArray(response.body.results)).toBe(true);
        });

        it('should perform bulk stop operation', async () => {
          const response = await request(app)
            .post('/api/aws/instances/bulk-action')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              instanceIds: ['i-1234567890abcdef0'],
              action: 'stop',
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect(response.status).toBe(200);
          expect(response.body).toHaveProperty('results');
        });

        it('should perform bulk terminate operation', async () => {
          const response = await request(app)
            .post('/api/aws/instances/bulk-action')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              instanceIds: ['i-1234567890abcdef0'],
              action: 'terminate',
              region: 'us-east-1',
              accountId: 'test-account-id',
              confirm: true
            });

          expect(response.status).toBe(200);
          expect(response.body).toHaveProperty('results');
        });

        it('should handle mixed success/failure results', async () => {
          const response = await request(app)
            .post('/api/aws/instances/bulk-action')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              instanceIds: ['i-valid', 'i-invalid'],
              action: 'start',
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect(response.status).toBe(200);
          expect(response.body.results).toHaveLength(2);
          expect(response.body.results[0]).toHaveProperty('instanceId');
          expect(response.body.results[0]).toHaveProperty('status');
        });

        it('should return 400 for invalid action', async () => {
          const response = await request(app)
            .post('/api/aws/instances/bulk-action')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              instanceIds: ['i-1234567890abcdef0'],
              action: 'invalid-action',
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect(response.status).toBe(400);
          expect(response.body).toHaveProperty('message');
        });

        it('should return 400 for empty instance list', async () => {
          const response = await request(app)
            .post('/api/aws/instances/bulk-action')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              instanceIds: [],
              action: 'start',
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect(response.status).toBe(400);
          expect(response.body).toHaveProperty('message');
        });

        it('should validate instance ID formats', async () => {
          const response = await request(app)
            .post('/api/aws/instances/bulk-action')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              instanceIds: ['invalid-id', 'i-valid1234567890abcdef'],
              action: 'start',
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect([200, 400, 500]).toContain(response.status);
        });

        it('should limit batch size', async () => {
          const largeBatch = Array(100).fill(null).map((_, i) => `i-instance${i}`);
          const response = await request(app)
            .post('/api/aws/instances/bulk-action')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              instanceIds: largeBatch,
              action: 'start',
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect([200, 400]).toContain(response.status);
        });

        it('should handle partial failures gracefully', async () => {
          const response = await request(app)
            .post('/api/aws/instances/bulk-action')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              instanceIds: ['i-running', 'i-stopped', 'i-nonexistent'],
              action: 'start',
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect(response.status).toBe(200);
          expect(response.body).toHaveProperty('results');
          expect(response.body.results).toHaveLength(3);
        });
      });
    });

    describe('Instance Details and Management', () => {
      describe('GET /api/aws/instances/:instanceId/details/:region/:accountId', () => {
        it('should return instance details', async () => {
          const response = await request(app)
            .get('/api/aws/instances/i-1234567890abcdef0/details/us-east-1/test-account-id')
            .set('Authorization', `Bearer ${authToken}`);

          expect(response.status).toBe(200);
          expect(response.body).toHaveProperty('InstanceId');
          expect(response.body).toHaveProperty('State');
        });

        it('should return 404 for non-existent instance', async () => {
          const response = await request(app)
            .get('/api/aws/instances/i-non-existent/details/us-east-1/test-account-id')
            .set('Authorization', `Bearer ${authToken}`);

          expect([404, 500]).toContain(response.status);
        });

        it('should include detailed metadata', async () => {
          const response = await request(app)
            .get('/api/aws/instances/i-1234567890abcdef0/details/us-east-1/test-account-id')
            .set('Authorization', `Bearer ${authToken}`);

          if (response.status === 200) {
            const instance = response.body;
            expect(instance).toHaveProperty('InstanceId');
            expect(instance).toHaveProperty('State');
            expect(instance).toHaveProperty('InstanceType');
            expect(instance).toHaveProperty('LaunchTime');
            expect(instance).toHaveProperty('Tags');
          }
        });

        it('should handle instance with special characters in tags', async () => {
          const response = await request(app)
            .get('/api/aws/instances/i-special-tags/details/us-east-1/test-account-id')
            .set('Authorization', `Bearer ${authToken}`);

          expect([200, 404, 500]).toContain(response.status);
        });
      });

      describe('POST /api/aws/instances/update-name', () => {
        it('should update instance name', async () => {
          const response = await request(app)
            .post('/api/aws/instances/update-name')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              instanceId: 'i-1234567890abcdef0',
              name: 'Test Instance Updated',
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect(response.status).toBe(200);
        });

        it('should validate name format', async () => {
          const invalidNames = [
            '', // Empty
            'a'.repeat(200), // Too long
            'Name/With/Slashes',
            'Name\\With\\Backslashes',
            'Name"WithQuotes"'
          ];

          for (const name of invalidNames) {
            const response = await request(app)
              .post('/api/aws/instances/update-name')
              .set('Authorization', `Bearer ${authToken}`)
              .send({
                instanceId: 'i-1234567890abcdef0',
                name,
                region: 'us-east-1',
                accountId: 'test-account-id'
              });

            expect(response.status).toBe(400);
          }
        });

        it('should handle XSS in name', async () => {
          const response = await request(app)
            .post('/api/aws/instances/update-name')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              instanceId: 'i-1234567890abcdef0',
              name: '<script>alert("xss")</script>',
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect([200, 400, 500]).toContain(response.status);
        });

        it('should handle concurrent updates', async () => {
          const requests = Array(5).fill(null).map(() =>
            request(app)
              .post('/api/aws/instances/update-name')
              .set('Authorization', `Bearer ${authToken}`)
              .send({
                instanceId: 'i-1234567890abcdef0',
                name: `Update ${Date.now()}`,
                region: 'us-east-1',
                accountId: 'test-account-id'
              })
          );

          const responses = await Promise.all(requests);
          responses.forEach(response => {
            expect([200, 409, 500]).toContain(response.status);
          });
        });
      });

      describe('POST /api/aws/instances/rotate-ip', () => {
        it('should rotate instance IP', async () => {
          const response = await request(app)
            .post('/api/aws/instances/rotate-ip')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              instanceId: 'i-1234567890abcdef0',
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect([200, 500]).toContain(response.status);
        });

        it('should require elastic IP association', async () => {
          const response = await request(app)
            .post('/api/aws/instances/rotate-ip')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              instanceId: 'i-no-eip',
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect([200, 400, 500]).toContain(response.status);
        });

        it('should handle multiple ENIs', async () => {
          const response = await request(app)
            .post('/api/aws/instances/rotate-ip')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              instanceId: 'i-multiple-eni',
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect([200, 400, 500]).toContain(response.status);
        });

        it('should validate IP rotation permissions', async () => {
          const response = await request(app)
            .post('/api/aws/instances/rotate-ip')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              instanceId: 'i-no-permission',
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect([200, 400, 403, 500]).toContain(response.status);
        });
      });
    });
  });

  describe('Elastic IP Management', () => {
    describe('GET /api/aws/elastic-ips/:region/:accountId', () => {
      it('should return Elastic IPs list', async () => {
        const response = await request(app)
          .get('/api/aws/elastic-ips/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
        expect(Array.isArray(response.body)).toBe(true);
      });

      it('should filter by allocation ID', async () => {
        const response = await request(app)
          .get('/api/aws/elastic-ips/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
          .query({ allocationId: 'eipalloc-12345' });

        expect(response.status).toBe(200);
      });

      it('should filter by instance association', async () => {
        const response = await request(app)
          .get('/api/aws/elastic-ips/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
          .query({ associated: true });

        expect(response.status).toBe(200);
      });

      it('should handle region-specific IPs', async () => {
        const response = await request(app)
          .get('/api/aws/elastic-ips/eu-west-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
      });
    });

    describe('POST /api/aws/elastic-ips/allocate', () => {
      it('should allocate Elastic IP', async () => {
        const response = await request(app)
          .post('/api/aws/elastic-ips/allocate')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([200, 500]).toContain(response.status);
      });

      it('should allocate VPC-specific Elastic IP', async () => {
        const response = await request(app)
          .post('/api/aws/elastic-ips/allocate')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            region: 'us-east-1',
            accountId: 'test-account-id',
            vpc: true
          });

        expect([200, 500]).toContain(response.status);
      });

      it('should check IP quota limits', async () => {
        const response = await request(app)
          .post('/api/aws/elastic-ips/allocate')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        if (response.status === 500) {
          expect(response.body.message).toMatch(/quota|limit/i);
        }
      });

      it('should validate region support', async () => {
        const response = await request(app)
          .post('/api/aws/elastic-ips/allocate')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            region: 'invalid-region',
            accountId: 'test-account-id'
          });

        expect(response.status).toBe(400);
      });
    });

    describe('POST /api/aws/elastic-ips/release', () => {
      it('should release Elastic IP', async () => {
        const response = await request(app)
          .post('/api/aws/elastic-ips/release')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            allocationId: 'eipalloc-12345678',
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([200, 500]).toContain(response.status);
      });

      it('should return 400 for invalid allocation ID', async () => {
        const response = await request(app)
          .post('/api/aws/elastic-ips/release')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            allocationId: 'invalid-id',
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([400, 500]).toContain(response.status);
      });

      it('should prevent releasing associated IPs', async () => {
        const response = await request(app)
          .post('/api/aws/elastic-ips/release')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            allocationId: 'eipassoc-associated',
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should require release confirmation', async () => {
        const response = await request(app)
          .post('/api/aws/elastic-ips/release')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            allocationId: 'eipalloc-12345678',
            region: 'us-east-1',
            accountId: 'test-account-id',
            confirm: true
          });

        expect([200, 400, 500]).toContain(response.status);
      });
    });

    describe('POST /api/aws/elastic-ips/associate', () => {
      it('should associate Elastic IP with instance', async () => {
        const response = await request(app)
          .post('/api/aws/elastic-ips/associate')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            allocationId: 'eipalloc-12345678',
            instanceId: 'i-1234567890abcdef0',
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([200, 500]).toContain(response.status);
      });

      it('should handle private IP association', async () => {
        const response = await request(app)
          .post('/api/aws/elastic-ips/associate')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            allocationId: 'eipalloc-12345678',
            instanceId: 'i-1234567890abcdef0',
            privateIpAddress: '10.0.0.1',
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should disassociate old IP if needed', async () => {
        const response = await request(app)
          .post('/api/aws/elastic-ips/associate')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            allocationId: 'eipalloc-12345678',
            instanceId: 'i-with-existing-eip',
            region: 'us-east-1',
            accountId: 'test-account-id',
            allowReassociation: true
          });

        expect([200, 400, 500]).toContain(response.status);
      });
    });

    describe('POST /api/aws/elastic-ips/disassociate', () => {
      it('should disassociate Elastic IP', async () => {
        const response = await request(app)
          .post('/api/aws/elastic-ips/disassociate')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            associationId: 'eipassoc-12345678',
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([200, 500]).toContain(response.status);
      });

      it('should validate association ID format', async () => {
        const response = await request(app)
          .post('/api/aws/elastic-ips/disassociate')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            associationId: 'invalid-id',
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([400, 500]).toContain(response.status);
      });
    });
  });

  describe('S3 Bucket Management', () => {
    describe('GET /api/aws/s3/buckets/:accountId', () => {
      it('should return S3 buckets list', async () => {
        const response = await request(app)
          .get('/api/aws/s3/buckets/test-account-id')
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
        expect(Array.isArray(response.body)).toBe(true);
      });

      it('should include bucket metadata', async () => {
        const response = await request(app)
          .get('/api/aws/s3/buckets/test-account-id')
          .set('Authorization', `Bearer ${authToken}`);

        if (response.body.length > 0) {
          const bucket = response.body[0];
          expect(bucket).toHaveProperty('Name');
          expect(bucket).toHaveProperty('CreationDate');
        }
      });

      it('should handle account without S3 access', async () => {
        const response = await request(app)
          .get('/api/aws/s3/buckets/no-s3-access')
          .set('Authorization', `Bearer ${authToken}`);

        expect([200, 403, 500]).toContain(response.status);
      });
    });

    describe('POST /api/aws/s3/buckets', () => {
      it('should create S3 bucket', async () => {
        const bucketData = {
          bucketName: `test-bucket-${Date.now()}`,
          region: 'us-east-1',
          accountId: 'test-account-id'
        };

        const response = await request(app)
          .post('/api/aws/s3/buckets')
          .set('Authorization', `Bearer ${authToken}`)
          .send(bucketData);

        expect([200, 500]).toContain(response.status);
      });

      it('should validate bucket name format', async () => {
        const invalidNames = [
          'Invalid Bucket Name With Spaces',
          'Invalid_Bucket_Name_With_Underscores',
          '-invalid-bucket-name',
          'invalid-bucket-name-',
          'bucket..name',
          '.bucket',
          'bucket.',
          'a'.repeat(64) // Too long
        ];

        for (const bucketName of invalidNames) {
          const response = await request(app)
            .post('/api/aws/s3/buckets')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              bucketName,
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect(response.status).toBe(400);
        }
      });

      it('should create bucket in specific region', async () => {
        const response = await request(app)
          .post('/api/aws/s3/buckets')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            bucketName: `test-bucket-${Date.now()}`,
            region: 'eu-west-1',
            accountId: 'test-account-id'
          });

        expect([200, 500]).toContain(response.status);
      });

      it('should handle bucket name conflicts', async () => {
        const response = await request(app)
          .post('/api/aws/s3/buckets')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            bucketName: 'existing-bucket',
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([200, 400, 409, 500]).toContain(response.status);
      });

      it('should set bucket versioning', async () => {
        const response = await request(app)
          .post('/api/aws/s3/buckets')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            bucketName: `test-bucket-${Date.now()}`,
            region: 'us-east-1',
            accountId: 'test-account-id',
            versioning: { Enabled: true }
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should configure bucket encryption', async () => {
        const response = await request(app)
          .post('/api/aws/s3/buckets')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            bucketName: `test-bucket-${Date.now()}`,
            region: 'us-east-1',
            accountId: 'test-account-id',
            encryption: {
              enabled: true,
              algorithm: 'AES256'
            }
          });

        expect([200, 400, 500]).toContain(response.status);
      });
    });

    describe('DELETE /api/aws/s3/buckets/:bucketName/:accountId', () => {
      it('should delete S3 bucket', async () => {
        const response = await request(app)
          .delete('/api/aws/s3/buckets/test-bucket/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
          .send({ region: 'us-east-1' });

        expect([200, 500]).toContain(response.status);
      });

      it('should require empty bucket for deletion', async () => {
        const response = await request(app)
          .delete('/api/aws/s3/buckets/non-empty-bucket/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
          .send({ region: 'us-east-1' });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should force delete non-empty bucket', async () => {
        const response = await request(app)
          .delete('/api/aws/s3/buckets/non-empty-bucket/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            region: 'us-east-1',
            force: true
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should validate bucket name on deletion', async () => {
        const response = await request(app)
          .delete('/api/aws/s3/buckets/invalid%bucket/name/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
          .send({ region: 'us-east-1' });

        expect([400, 404]).toContain(response.status);
      });
    });

    describe('S3 Object Operations', () => {
      describe('GET /api/aws/s3/objects/:bucketName/:accountId', () => {
        it('should list S3 objects', async () => {
          const response = await request(app)
            .get('/api/aws/s3/objects/test-bucket/test-account-id')
            .set('Authorization', `Bearer ${authToken}`)
            .query({ region: 'us-east-1' });

          expect(response.status).toBe(200);
          expect(Array.isArray(response.body)).toBe(true);
        });

        it('should paginate object listings', async () => {
          const response = await request(app)
            .get('/api/aws/s3/objects/test-bucket/test-account-id')
            .set('Authorization', `Bearer ${authToken}`)
            .query({
              region: 'us-east-1',
              maxKeys: 10,
              continuationToken: 'token123'
            });

          expect(response.status).toBe(200);
        });

        it('should filter by prefix', async () => {
          const response = await request(app)
            .get('/api/aws/s3/objects/test-bucket/test-account-id')
            .set('Authorization', `Bearer ${authToken}`)
            .query({
              region: 'us-east-1',
              prefix: 'images/'
            });

          expect(response.status).toBe(200);
        });

        it('should include object metadata', async () => {
          const response = await request(app)
            .get('/api/aws/s3/objects/test-bucket/test-account-id')
            .set('Authorization', `Bearer ${authToken}`)
            .query({
              region: 'us-east-1',
              fetchMetadata: true
            });

          expect(response.status).toBe(200);
          if (response.body.length > 0) {
            const obj = response.body[0];
            expect(obj).toHaveProperty('Key');
            expect(obj).toHaveProperty('LastModified');
            expect(obj).toHaveProperty('Size');
          }
        });
      });

      describe('POST /api/aws/s3/upload', () => {
        it('should upload file to S3', async () => {
          const fileContent = Buffer.from('test file content').toString('base64');
          const response = await request(app)
            .post('/api/aws/s3/upload')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              bucketName: 'test-bucket',
              fileName: 'test-file.txt',
              fileContent,
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect([200, 500]).toContain(response.status);
        });

        it('should validate base64 encoding', async () => {
          const response = await request(app)
            .post('/api/aws/s3/upload')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              bucketName: 'test-bucket',
              fileName: 'test.txt',
              fileContent: 'invalid-base64-content!@#$%',
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect(response.status).toBe(400);
        });

        it('should handle file size limits', async () => {
          const largeContent = Buffer.alloc(50 * 1024 * 1024, 'a').toString('base64');
          const response = await request(app)
            .post('/api/aws/s3/upload')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              bucketName: 'test-bucket',
              fileName: 'large-file.txt',
              fileContent: largeContent,
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect([200, 400, 413, 500]).toContain(response.status);
        });

        it('should handle special characters in file names', async () => {
          const fileContent = Buffer.from('test').toString('base64');
          const specialNames = [
            'file with spaces.txt',
            'file-with-émojis.txt',
            'file%20with%20encoding.txt',
            'file(with)parentheses.txt'
          ];

          for (const fileName of specialNames) {
            const response = await request(app)
              .post('/api/aws/s3/upload')
              .set('Authorization', `Bearer ${authToken}`)
              .send({
                bucketName: 'test-bucket',
                fileName,
                fileContent,
                region: 'us-east-1',
                accountId: 'test-account-id'
              });

            expect([200, 400, 500]).toContain(response.status);
          }
        });

        it('should set content type', async () => {
          const fileContent = Buffer.from('{"test": "data"}').toString('base64');
          const response = await request(app)
            .post('/api/aws/s3/upload')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              bucketName: 'test-bucket',
              fileName: 'data.json',
              fileContent,
              region: 'us-east-1',
              accountId: 'test-account-id',
              contentType: 'application/json'
            });

          expect([200, 400, 500]).toContain(response.status);
        });

        it('should handle multipart upload', async () => {
          const response = await request(app)
            .post('/api/aws/s3/upload')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              bucketName: 'test-bucket',
              fileName: 'multipart-file.txt',
              fileContent: Buffer.from('test').toString('base64'),
              region: 'us-east-1',
              accountId: 'test-account-id',
              multipart: true,
              partSize: 1024 * 1024
            });

          expect([200, 400, 500]).toContain(response.status);
        });
      });

      describe('DELETE /api/aws/s3/objects/:bucketName/:accountId', () => {
        it('should delete S3 object', async () => {
          const response = await request(app)
            .delete('/api/aws/s3/objects/test-bucket/test-account-id')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              region: 'us-east-1',
              objectKey: 'test-file.txt'
            });

          expect([200, 404, 500]).toContain(response.status);
        });

        it('should handle batch deletion', async () => {
          const response = await request(app)
            .delete('/api/aws/s3/objects/test-bucket/test-account-id')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              region: 'us-east-1',
              objectKeys: ['file1.txt', 'file2.txt', 'file3.txt']
            });

          expect([200, 400, 500]).toContain(response.status);
        });

        it('should require version ID for versioned objects', async () => {
          const response = await request(app)
            .delete('/api/aws/s3/objects/versioned-bucket/test-account-id')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              region: 'us-east-1',
              objectKey: 'versioned-file.txt'
              // No versionId
            });

          expect([200, 400, 500]).toContain(response.status);
        });
      });
    });
  });

  describe('RDS Instance Management', () => {
    describe('GET /api/aws/rds/:region/:accountId', () => {
      it('should return RDS instances list', async () => {
        const response = await request(app)
          .get('/api/aws/rds/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
        expect(Array.isArray(response.body)).toBe(true);
      });

      it('should filter by instance status', async () => {
        const response = await request(app)
          .get('/api/aws/rds/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
          .query({ status: 'available' });

        expect(response.status).toBe(200);
      });

      it('should handle cross-region requests', async () => {
        const response = await request(app)
          .get('/api/aws/rds/eu-west-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
      });
    });

    describe('POST /api/aws/rds', () => {
      it('should create RDS instance', async () => {
        const rdsData = {
          dbInstanceIdentifier: `test-db-${Date.now()}`,
          dbInstanceClass: 'db.t3.micro',
          engine: 'mysql',
          masterUsername: 'admin',
          masterUserPassword: 'password123',
          region: 'us-east-1',
          accountId: 'test-account-id'
        };

        const response = await request(app)
          .post('/api/aws/rds')
          .set('Authorization', `Bearer ${authToken}`)
          .send(rdsData);

        expect([200, 500]).toContain(response.status);
      });

      it('should validate instance classes', async () => {
        const invalidClasses = [
          'invalid-class',
          'db.t1.micro', // Deprecated
          'db.invalid.size'
        ];

        for (const dbInstanceClass of invalidClasses) {
          const response = await request(app)
            .post('/api/aws/rds')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              dbInstanceIdentifier: `test-db-${Date.now()}`,
              dbInstanceClass,
              engine: 'mysql',
              masterUsername: 'admin',
              masterUserPassword: 'password123',
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect(response.status).toBe(400);
        }
      });

      it('should validate engine types', async () => {
        const invalidEngines = [
          'unsupported-engine',
          'oracle-ee', // Not supported in all regions
          'sqlserver-2019-invalid'
        ];

        for (const engine of invalidEngines) {
          const response = await request(app)
            .post('/api/aws/rds')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              dbInstanceIdentifier: `test-db-${Date.now()}`,
              dbInstanceClass: 'db.t3.micro',
              engine,
              masterUsername: 'admin',
              masterUserPassword: 'password123',
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect(response.status).toBe(400);
        }
      });

      it('should validate password strength', async () => {
        const weakPasswords = [
          '123',
          'password',
          'short',
          'a'.repeat(7)
        ];

        for (const password of weakPasswords) {
          const response = await request(app)
            .post('/api/aws/rds')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              dbInstanceIdentifier: `test-db-${Date.now()}`,
              dbInstanceClass: 'db.t3.micro',
              engine: 'mysql',
              masterUsername: 'admin',
              masterUserPassword: password,
              region: 'us-east-1',
              accountId: 'test-account-id'
            });

          expect(response.status).toBe(400);
        }
      });

      it('should handle Multi-AZ deployment', async () => {
        const response = await request(app)
          .post('/api/aws/rds')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            dbInstanceIdentifier: `test-db-${Date.now()}`,
            dbInstanceClass: 'db.t3.micro',
            engine: 'mysql',
            masterUsername: 'admin',
            masterUserPassword: 'password123',
            region: 'us-east-1',
            accountId: 'test-account-id',
            multiAz: true
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should configure storage encryption', async () => {
        const response = await request(app)
          .post('/api/aws/rds')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            dbInstanceIdentifier: `test-db-${Date.now()}`,
            dbInstanceClass: 'db.t3.micro',
            engine: 'mysql',
            masterUsername: 'admin',
            masterUserPassword: 'password123',
            region: 'us-east-1',
            accountId: 'test-account-id',
            storageEncrypted: true,
            kmsKeyId: 'arn:aws:kms:us-east-1:123456789012:key/12345678-1234-1234-1234-123456789012'
          });

        expect([200, 400, 500]).toContain(response.status);
      });
    });

    describe('RDS Instance Operations', () => {
      describe('POST /api/aws/rds/:dbInstanceIdentifier/:accountId/start', () => {
        it('should start RDS instance', async () => {
          const response = await request(app)
            .post('/api/aws/rds/test-db-instance/test-account-id/start')
            .set('Authorization', `Bearer ${authToken}`)
            .send({ region: 'us-east-1' });

          expect([200, 500]).toContain(response.status);
        });

        it('should handle already running instances', async () => {
          const response = await request(app)
            .post('/api/aws/rds/running-db-instance/test-account-id/start')
            .set('Authorization', `Bearer ${authToken}`)
            .send({ region: 'us-east-1' });

          expect([200, 400, 500]).toContain(response.status);
        });
      });

      describe('POST /api/aws/rds/:dbInstanceIdentifier/:accountId/stop', () => {
        it('should stop RDS instance', async () => {
          const response = await request(app)
            .post('/api/aws/rds/test-db-instance/test-account-id/stop')
            .set('Authorization', `Bearer ${authToken}`)
            .send({ region: 'us-east-1' });

          expect([200, 500]).toContain(response.status);
        });

        it('should handle instances with active connections', async () => {
          const response = await request(app)
            .post('/api/aws/rds/active-db-instance/test-account-id/stop')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              region: 'us-east-1',
              dbInstanceStatus: 'available',
              activeConnections: true
            });

          expect([200, 400, 500]).toContain(response.status);
        });
      });

      describe('DELETE /api/aws/rds/:dbInstanceIdentifier/:accountId', () => {
        it('should delete RDS instance', async () => {
          const response = await request(app)
            .delete('/api/aws/rds/test-db-instance/test-account-id')
            .set('Authorization', `Bearer ${authToken}`)
            .send({ region: 'us-east-1' });

          expect([200, 500]).toContain(response.status);
        });

        it('should require deletion protection off', async () => {
          const response = await request(app)
            .delete('/api/aws/rds/protected-db-instance/test-account-id')
            .set('Authorization', `Bearer ${authToken}`)
            .send({ region: 'us-east-1' });

          expect([200, 400, 500]).toContain(response.status);
        });

        it('should handle final snapshot creation', async () => {
          const response = await request(app)
            .delete('/api/aws/rds/test-db-instance/test-account-id')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              region: 'us-east-1',
              finalDBSnapshotIdentifier: `final-snapshot-${Date.now()}`
            });

          expect([200, 400, 500]).toContain(response.status);
        });
      });

      describe('POST /api/aws/rds/:dbInstanceIdentifier/:accountId/reboot', () => {
        it('should reboot RDS instance', async () => {
          const response = await request(app)
            .post('/api/aws/rds/test-db-instance/test-account-id/reboot')
            .set('Authorization', `Bearer ${authToken}`)
            .send({ region: 'us-east-1' });

          expect([200, 500]).toContain(response.status);
        });

        it('should force reboot option', async () => {
          const response = await request(app)
            .post('/api/aws/rds/test-db-instance/test-account-id/reboot')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              region: 'us-east-1',
              forceFailover: true
            });

          expect([200, 400, 500]).toContain(response.status);
        });
      });
    });
  });

  describe('CloudFront Distribution Management', () => {
    describe('GET /api/aws/cloudfront/:accountId', () => {
      it('should return CloudFront distributions list', async () => {
        const response = await request(app)
          .get('/api/aws/cloudfront/test-account-id')
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
        expect(Array.isArray(response.body)).toBe(true);
      });

      it('should filter by distribution status', async () => {
        const response = await request(app)
          .get('/api/aws/cloudfront/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
          .query({ status: 'Deployed' });

        expect(response.status).toBe(200);
      });

      it('should include distribution metadata', async () => {
        const response = await request(app)
          .get('/api/aws/cloudfront/test-account-id')
          .set('Authorization', `Bearer ${authToken}`);

        if (response.body.length > 0) {
          const distribution = response.body[0];
          expect(distribution).toHaveProperty('Id');
          expect(distribution).toHaveProperty('Status');
          expect(distribution).toHaveProperty('DomainName');
        }
      });
    });

    describe('POST /api/aws/cloudfront', () => {
      it('should create CloudFront distribution', async () => {
        const distributionData = {
          distributionConfig: {
            CallerReference: `test-${Date.now()}`,
            Comment: 'Test distribution',
            Enabled: true,
            Origins: {
              Quantity: 1,
              Items: [{
                Id: 'origin1',
                DomainName: 'example.com',
                CustomOriginConfig: {
                  HTTPPort: 80,
                  HTTPSPort: 443,
                  OriginProtocolPolicy: 'https-only'
                }
              }]
            }
          },
          accountId: 'test-account-id'
        };

        const response = await request(app)
          .post('/api/aws/cloudfront')
          .set('Authorization', `Bearer ${authToken}`)
          .send(distributionData);

        expect([200, 500]).toContain(response.status);
      });

      it('should validate origin configuration', async () => {
        const invalidOrigins = [
          { Id: '', DomainName: 'example.com' }, // Empty ID
          { Id: 'origin1', DomainName: '' }, // Empty domain
          { Id: 'origin1', DomainName: 'invalid-domain' } // Invalid domain
        ];

        for (const origin of invalidOrigins) {
          const response = await request(app)
            .post('/api/aws/cloudfront')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              distributionConfig: {
                CallerReference: `test-${Date.now()}`,
                Comment: 'Test distribution',
                Enabled: true,
                Origins: {
                  Quantity: 1,
                  Items: [origin]
                }
              },
              accountId: 'test-account-id'
            });

          expect(response.status).toBe(400);
        }
      });

      it('should configure default cache behavior', async () => {
        const response = await request(app)
          .post('/api/aws/cloudfront')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            distributionConfig: {
              CallerReference: `test-${Date.now()}`,
              Comment: 'Test distribution',
              Enabled: true,
              Origins: {
                Quantity: 1,
                Items: [{
                  Id: 'origin1',
                  DomainName: 'example.com',
                  CustomOriginConfig: {
                    HTTPPort: 80,
                    HTTPSPort: 443,
                    OriginProtocolPolicy: 'https-only'
                  }
                }]
              },
              DefaultCacheBehavior: {
                TargetOriginId: 'origin1',
                ViewerProtocolPolicy: 'redirect-to-https',
                CachePolicyId: '4135ea2d-6df8-44a3-9df3-4b5a84be39ad'
              }
            },
            accountId: 'test-account-id'
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should configure custom error responses', async () => {
        const response = await request(app)
          .post('/api/aws/cloudfront')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            distributionConfig: {
              CallerReference: `test-${Date.now()}`,
              Comment: 'Test distribution',
              Enabled: true,
              Origins: {
                Quantity: 1,
                Items: [{
                  Id: 'origin1',
                  DomainName: 'example.com',
                  CustomOriginConfig: {
                    HTTPPort: 80,
                    HTTPSPort: 443,
                    OriginProtocolPolicy: 'https-only'
                  }
                }]
              },
              CustomErrorResponses: {
                Quantity: 1,
                Items: [{
                  ErrorCode: 404,
                  ResponsePagePath: '/error.html',
                  ResponseCode: '404',
                  ErrorCachingMinTTL: 300
                }]
              }
            },
            accountId: 'test-account-id'
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should handle restrictions', async () => {
        const response = await request(app)
          .post('/api/aws/cloudfront')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            distributionConfig: {
              CallerReference: `test-${Date.now()}`,
              Comment: 'Test distribution',
              Enabled: true,
              Origins: {
                Quantity: 1,
                Items: [{
                  Id: 'origin1',
                  DomainName: 'example.com',
                  CustomOriginConfig: {
                    HTTPPort: 80,
                    HTTPSPort: 443,
                    OriginProtocolPolicy: 'https-only'
                  }
                }]
              },
              Restrictions: {
                GeoRestriction: {
                  RestrictionType: 'whitelist',
                  Quantity: 1,
                  Items: ['US']
                }
              }
            },
            accountId: 'test-account-id'
          });

        expect([200, 400, 500]).toContain(response.status);
      });
    });

    describe('POST /api/aws/cloudfront/:distributionId/:accountId/invalidate', () => {
      it('should create CloudFront invalidation', async () => {
        const response = await request(app)
          .post('/api/aws/cloudfront/E1234567890/test-account-id/invalidate')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            paths: ['/*']
          });

        expect([200, 500]).toContain(response.status);
      });

      it('should validate invalidation paths', async () => {
        const invalidPaths = [
          [], // Empty
          [''], // Empty path
          ['/*'], // Valid
          ['/path with spaces/*'], // Spaces (might be valid)
          ['../invalid/*'], // Path traversal
          ['/*?query=value'] // Query params
        ];

        for (const paths of invalidPaths) {
          const response = await request(app)
            .post('/api/aws/cloudfront/E1234567890/test-account-id/invalidate')
            .set('Authorization', `Bearer ${authToken}`)
            .send({ paths });

          expect([200, 400]).toContain(response.status);
        }
      });

      it('should limit number of paths', async () => {
        const manyPaths = Array(100).fill(null).map((_, i) => `/path${i}/*`);
        const response = await request(app)
          .post('/api/aws/cloudfront/E1234567890/test-account-id/invalidate')
          .set('Authorization', `Bearer ${authToken}`)
          .send({ paths: manyPaths });

        expect([200, 400]).toContain(response.status);
      });

      it('should handle wildcards in paths', async () => {
        const response = await request(app)
          .post('/api/aws/cloudfront/E1234567890/test-account-id/invalidate')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            paths: ['/*', '/images/*', '/css/*', '/js/*']
          });

        expect([200, 400]).toContain(response.status);
      });
    });

    describe('PUT /api/aws/cloudfront/:distributionId/:accountId', () => {
      it('should update distribution configuration', async () => {
        const response = await request(app)
          .put('/api/aws/cloudfront/E1234567890/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            distributionConfig: {
              CallerReference: 'existing-reference',
              Comment: 'Updated distribution',
              Enabled: false
            }
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should validate ETag header', async () => {
        const response = await request(app)
          .put('/api/aws/cloudfront/E1234567890/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
          .set('If-Match', 'invalid-etag')
          .send({
            distributionConfig: {
              CallerReference: 'existing-reference',
              Comment: 'Updated distribution',
              Enabled: false
            }
          });

        expect([200, 400, 412, 500]).toContain(response.status);
      });

      it('should handle partial updates', async () => {
        const response = await request(app)
          .put('/api/aws/cloudfront/E1234567890/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            distributionConfig: {
              CallerReference: 'existing-reference',
              Comment: 'Comment only update'
            }
          });

        expect([200, 400, 500]).toContain(response.status);
      });
    });

    describe('DELETE /api/aws/cloudfront/:distributionId/:accountId', () => {
      it('should delete distribution', async () => {
        const response = await request(app)
          .delete('/api/aws/cloudfront/E1234567890/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            distributionConfig: {
              Enabled: false
            }
          });

        expect([200, 400, 500]).toContain(response.status);
      });

      it('should require distribution to be disabled', async () => {
        const response = await request(app)
          .delete('/api/aws/cloudfront/E1234567890/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            distributionConfig: {
              Enabled: true // Must be false for deletion
            }
          });

        expect([200, 400, 500]).toContain(response.status);
      });
    });
  });

  describe('Utility Endpoints', () => {
    describe('POST /api/aws/check-quota', () => {
      it('should check AWS quota', async () => {
        const response = await request(app)
          .post('/api/aws/check-quota')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            region: 'us-east-1',
            accountId: 'test-account-id',
            service: 'ec2'
          });

        expect([200, 500]).toContain(response.status);
      });

      it('should validate service parameter', async () => {
        const invalidServices = [
          'invalid-service',
          '',
          '  '
        ];

        for (const service of invalidServices) {
          const response = await request(app)
            .post('/api/aws/check-quota')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              region: 'us-east-1',
              accountId: 'test-account-id',
              service
            });

          expect(response.status).toBe(400);
        }
      });

      it('should return quota usage', async () => {
        const response = await request(app)
          .post('/api/aws/check-quota')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            region: 'us-east-1',
            accountId: 'test-account-id',
            service: 'rds'
          });

        if (response.status === 200) {
          expect(response.body).toHaveProperty('quota');
          expect(response.body).toHaveProperty('usage');
          expect(response.body).toHaveProperty('limit');
        }
      });
    });

    describe('POST /api/aws/enable-region', () => {
      it('should check region access', async () => {
        const response = await request(app)
          .post('/api/aws/enable-region')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect([200, 500]).toContain(response.status);
      });

      it('should validate region format', async () => {
        const invalidRegions = [
          'invalid-region',
          'us-east',
          'region-1',
          'US-EAST-1', // Wrong format
          ''
        ];

        for (const region of invalidRegions) {
          const response = await request(app)
            .post('/api/aws/enable-region')
            .set('Authorization', `Bearer ${authToken}`)
            .send({
              region,
              accountId: 'test-account-id'
            });

          expect(response.status).toBe(400);
        }
      });

      it('should handle region availability', async () => {
        const response = await request(app)
          .post('/api/aws/enable-region')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            region: 'us-gov-west-1',
            accountId: 'test-account-id'
          });

        expect([200, 400, 500]).toContain(response.status);
      });
    });

    describe('GET /api/aws/instances/export/:format/:region/:accountId', () => {
      it('should export instances as JSON', async () => {
        const response = await request(app)
          .get('/api/aws/instances/export/json/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
      });

      it('should export instances as CSV', async () => {
        const response = await request(app)
          .get('/api/aws/instances/export/csv/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
        expect(response.headers['content-type']).toContain('text/csv');
      });

      it('should export instances as Excel', async () => {
        const response = await request(app)
          .get('/api/aws/instances/export/xlsx/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
        expect(response.headers['content-type']).toContain('application/vnd');
      });

      it('should filter exports by criteria', async () => {
        const response = await request(app)
          .get('/api/aws/instances/export/json/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
          .query({
            state: 'running',
            instanceType: 't2.micro',
            tagName: 'Environment',
            tagValue: 'Production'
          });

        expect(response.status).toBe(200);
      });

      it('should validate format parameter', async () => {
        const response = await request(app)
          .get('/api/aws/instances/export/invalid/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(400);
      });

      it('should handle large exports', async () => {
        const response = await request(app)
          .get('/api/aws/instances/export/json/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
          .query({ limit: 10000 });

        expect(response.status).toBe(200);
      });
    });
  });

  describe('Authentication Requirements', () => {
    it('should require authentication for all AWS endpoints', async () => {
      const endpoints = [
        { method: 'GET', path: '/api/aws-accounts' },
        { method: 'GET', path: '/api/aws/instances/us-east-1/test-account-id' },
        { method: 'POST', path: '/api/aws/instances/launch' },
        { method: 'GET', path: '/api/aws/s3/buckets/test-account-id' },
        { method: 'GET', path: '/api/aws/rds/us-east-1/test-account-id' },
        { method: 'GET', path: '/api/aws/cloudfront/test-account-id' },
        { method: 'GET', path: '/api/aws/elastic-ips/us-east-1/test-account-id' }
      ];

      for (const endpoint of endpoints) {
        const response = await request(app)
          [endpoint.method.toLowerCase()](endpoint.path)
          .send({});

        expect(response.status).toBe(401);
      }
    });

    it('should handle invalid tokens', async () => {
      const response = await request(app)
        .get('/api/aws-accounts')
        .set('Authorization', 'Bearer invalid-token');

      expect(response.status).toBe(401);
    });

    it('should handle expired tokens', async () => {
      const expiredToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.expired';
      const response = await request(app)
        .get('/api/aws-accounts')
        .set('Authorization', `Bearer ${expiredToken}`);

      expect(response.status).toBe(401);
    });

    it('should handle concurrent requests with same token', async () => {
      const requests = Array(5).fill(null).map(() =>
        request(app)
          .get('/api/aws/instances/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
      );

      const responses = await Promise.all(requests);
      responses.forEach(response => {
        expect([200, 401]).toContain(response.status);
      });
    });
  });

  describe('Error Handling', () => {
    it('should handle AWS service errors gracefully', async () => {
      const response = await request(app)
        .get('/api/aws/instances/invalid-region/test-account-id')
        .set('Authorization', `Bearer ${authToken}`);

      expect([400, 500]).toContain(response.status);
      expect(response.body).toHaveProperty('message');
    });

    it('should validate required parameters', async () => {
      const response = await request(app)
        .post('/api/aws/instances/launch')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          // Missing required fields
        });

      expect(response.status).toBe(400);
      expect(response.body).toHaveProperty('message');
    });

    it('should handle AWS API rate limiting', async () => {
      const requests = Array(20).fill(null).map(() =>
        request(app)
          .get('/api/aws/instances/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
      );

      const responses = await Promise.all(requests);
      responses.forEach(response => {
        expect([200, 429, 500]).toContain(response.status);
      });
    });

    it('should return consistent error format', async () => {
      const errorCases = [
        { path: '/api/aws/instances/launch', method: 'POST', data: {} },
        { path: '/api/aws/instances/us-east-1/test-account-id', method: 'GET' },
        { path: '/api/aws/instances/invalid-id/stop', method: 'POST', data: {} }
      ];

      for (const testCase of errorCases) {
        const response = await request(app)
          [testCase.method.toLowerCase()](testCase.path)
          .set('Authorization', `Bearer ${authToken}`)
          .send(testCase.data || {});

        if (response.status >= 400) {
          expect(response.body).toHaveProperty('message');
        }
      }
    });

    it('should handle network timeouts', async () => {
      const response = await request(app)
        .get('/api/aws/instances/us-east-1/slow-account')
        .set('Authorization', `Bearer ${authToken}`)
        .timeout(1000);

      expect([200, 408, 500]).toContain(response.status);
    });

    it('should handle partial AWS failures', async () => {
      const response = await request(app)
        .get('/api/aws/instances/us-east-1/partial-failure-account')
        .set('Authorization', `Bearer ${authToken}`);

      expect([200, 207, 500]).toContain(response.status);
      if (response.status === 207) {
        expect(response.body).toHaveProperty('partialSuccess');
      }
    });

    it('should validate AWS credentials', async () => {
      const response = await request(app)
        .post('/api/aws-accounts')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          accountName: 'Test',
          accessKeyId: 'AKIAINVALID',
          secretAccessKey: 'invalid-secret',
          region: 'us-east-1'
        });

      expect(response.status).toBe(400);
      expect(response.body.message).toMatch(/invalid|error/i);
    });

    it('should handle region-specific AWS errors', async () => {
      const response = await request(app)
        .post('/api/aws/rds')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          dbInstanceIdentifier: `test-db-${Date.now()}`,
          dbInstanceClass: 'db.r6g.16xlarge',
          engine: 'mysql',
          masterUsername: 'admin',
          masterUserPassword: 'password123',
          region: 'us-west-2',
          accountId: 'test-account-id'
        });

      expect([200, 400, 500]).toContain(response.status);
    });
  });

  describe('Performance Tests', () => {
    it('should handle concurrent requests', async () => {
      const requests = Array(10).fill(null).map(() =>
        request(app)
          .get('/api/aws/instances/us-east-1/test-account-id')
          .set('Authorization', `Bearer ${authToken}`)
      );

      const responses = await Promise.all(requests);
      responses.forEach(response => {
        expect([200, 401, 429]).toContain(response.status);
      });
    });

    it('should respond to requests within reasonable time', async () => {
      const startTime = Date.now();
      const response = await request(app)
        .get('/api/aws/instances/us-east-1/test-account-id')
        .set('Authorization', `Bearer ${authToken}`);
      const responseTime = Date.now() - startTime;

      expect(response.status).toBe(200);
      expect(responseTime).toBeLessThan(10000); // Should respond within 10 seconds
    });

    it('should handle bulk operations efficiently', async () => {
      const startTime = Date.now();
      const response = await request(app)
        .post('/api/aws/instances/bulk-action')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          instanceIds: Array(10).fill(null).map((_, i) => `i-instance${i}`),
          action: 'start',
          region: 'us-east-1',
          accountId: 'test-account-id'
        });
      const responseTime = Date.now() - startTime;

      expect(response.status).toBe(200);
      expect(responseTime).toBeLessThan(30000); // Bulk operations can take longer
    });
  });

  describe('Security Tests', () => {
    it('should not expose AWS credentials in responses', async () => {
      const response = await request(app)
        .get('/api/aws-accounts')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.body).not.toContain('secretAccessKey');
      expect(response.body).not.toContain('password');
    });

    it('should sanitize input parameters', async () => {
      const response = await request(app)
        .post('/api/aws/instances/launch')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          ...validLaunchData,
          userData: '<script>alert("xss")</script>'
        });

      expect([200, 400, 500]).toContain(response.status);
    });

    it('should handle path traversal attempts', async () => {
      const response = await request(app)
        .delete('/api/aws/s3/buckets/../../../test/test-account-id')
        .set('Authorization', `Bearer ${authToken}`)
        .send({ region: 'us-east-1' });

      expect([400, 404]).toContain(response.status);
    });

    it('should validate AWS resource ARNs', async () => {
      const response = await request(app)
        .post('/api/aws/instances/start')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          instanceId: 'arn:aws:ec2:us-east-1:123456789012:instance/i-1234567890abcdef0',
          region: 'us-east-1',
          accountId: 'test-account-id'
        });

      expect([200, 400, 500]).toContain(response.status);
    });

    it('should prevent information disclosure', async () => {
      const response = await request(app)
        .get('/api/aws/instances/non-existent-account/us-east-1')
        .set('Authorization', `Bearer ${authToken}`);

      if (response.status === 404) {
        expect(response.body.message).not.toContain('account');
        expect(response.body.message).not.toContain('number');
      }
    });
  });

  describe('Data Validation Tests', () => {
    it('should validate AWS resource IDs', async () => {
      const invalidIds = [
        'i-invalid',
        'i-123',
        'i-abcdefghijklmnopqrstuvwxyz',
        '',
        '  '
      ];

      for (const instanceId of invalidIds) {
        const response = await request(app)
          .post('/api/aws/instances/start')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            instanceId,
            region: 'us-east-1',
            accountId: 'test-account-id'
          });

        expect(response.status).toBe(400);
      }
    });

    it('should validate instance states', async () => {
      const response = await request(app)
        .post('/api/aws/instances/stop')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          instanceId: 'i-stopped-instance',
          region: 'us-east-1',
          accountId: 'test-account-id'
        });

      expect([200, 400, 500]).toContain(response.status);
    });

    it('should validate region support', async () => {
      const response = await request(app)
        .get('/api/aws/instances/us-gov-1/test-account-id')
        .set('Authorization', `Bearer ${authToken}`);

      expect([200, 400, 500]).toContain(response.status);
    });

    it('should validate resource limits', async () => {
      const response = await request(app)
        .post('/api/aws/instances/bulk-action')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          instanceIds: Array(1000).fill(null).map((_, i) => `i-instance${i}`),
          action: 'start',
          region: 'us-east-1',
          accountId: 'test-account-id'
        });

      expect([200, 400, 413]).toContain(response.status);
    });
  });

  describe('Edge Cases', () => {
    it('should handle empty AWS accounts list', async () => {
      const response = await request(app)
        .get('/api/aws-accounts')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      expect(Array.isArray(response.body)).toBe(true);
      expect(response.body).toHaveLength(0);
    });

    it('should handle instances with no tags', async () => {
      const response = await request(app)
        .get('/api/aws/instances/us-east-1/test-account-id')
        .set('Authorization', `Bearer ${authToken}`)
        .query({ filter: 'no-tags' });

      expect(response.status).toBe(200);
    });

    it('should handle instances with many tags', async () => {
      const response = await request(app)
        .get('/api/aws/instances/us-east-1/test-account-id')
        .set('Authorization', `Bearer ${authToken}`)
        .query({ filter: 'many-tags' });

      expect(response.status).toBe(200);
    });

    it('should handle special characters in bucket names', async () => {
      const specialNames = [
        'bucket.with.dots',
        'bucket-with-hyphens',
        '123-bucket-numeric'
      ];

      for (const bucketName of specialNames) {
        const response = await request(app)
          .get(`/api/aws/s3/objects/${bucketName}/test-account-id`)
          .set('Authorization', `Bearer ${authToken}`)
          .query({ region: 'us-east-1' });

        expect([200, 404, 500]).toContain(response.status);
      }
    });

    it('should handle database snapshots', async () => {
      const response = await request(app)
        .post('/api/aws/rds/test-db-instance/test-account-id/create-snapshot')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          region: 'us-east-1',
          snapshotIdentifier: `snapshot-${Date.now()}`
        });

      expect([200, 400, 500]).toContain(response.status);
    });

    it('should handle edge distribution states', async () => {
      const response = await request(app)
        .get('/api/aws/cloudfront/test-account-id')
        .set('Authorization', `Bearer ${authToken}`)
        .query({ status: 'InProgress' });

      expect(response.status).toBe(200);
    });
  });

  describe('Monitoring Integration', () => {
    it('should track AWS API calls', async () => {
      const response = await request(app)
        .get('/api/aws/instances/us-east-1/test-account-id')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      // This would be verified in actual monitoring system
    });

    it('should log errors with context', async () => {
      const response = await request(app)
        .get('/api/aws/instances/invalid-region/test-account-id')
        .set('Authorization', `Bearer ${authToken}`);

      expect([400, 500]).toContain(response.status);
      // This would be verified in actual logging system
    });

    it('should collect performance metrics', async () => {
      const startTime = Date.now();
      const response = await request(app)
        .get('/api/aws/instances/us-east-1/test-account-id')
        .set('Authorization', `Bearer ${authToken}`);
      const responseTime = Date.now() - startTime;

      expect(response.status).toBe(200);
      expect(responseTime).toBeGreaterThan(0);
      // This would be verified in actual metrics system
    });
  });

  describe('Caching Tests', () => {
    it('should cache frequently accessed data', async () => {
      const start1 = Date.now();
      await request(app)
        .get('/api/aws/instances/us-east-1/test-account-id')
        .set('Authorization', `Bearer ${authToken}`);
      const time1 = Date.now() - start1;

      const start2 = Date.now();
      await request(app)
        .get('/api/aws/instances/us-east-1/test-account-id')
        .set('Authorization', `Bearer ${authToken}`);
      const time2 = Date.now() - start2;

      // Second request should be faster due to caching
      expect(time2).toBeLessThanOrEqual(time1 * 1.5);
    });

    it('should invalidate cache on updates', async () => {
      await request(app)
        .post('/api/aws/instances/start')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          instanceId: 'i-1234567890abcdef0',
          region: 'us-east-1',
          accountId: 'test-account-id'
        });

      const response = await request(app)
        .get('/api/aws/instances/us-east-1/test-account-id')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      // Cache should be invalidated
    });
  });
});
