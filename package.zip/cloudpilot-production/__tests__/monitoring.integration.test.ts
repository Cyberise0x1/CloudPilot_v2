/**
 * Monitoring Integration Tests
 * Comprehensive tests for metrics, logging, dashboard, and performance monitoring endpoints
 */

import { describe, it, expect, beforeAll, afterAll, beforeEach, afterEach } from 'vitest';
import request from 'supertest';
import { app } from '../server/index';

describe('Monitoring Integration Tests', () => {
  let authToken: string;

  beforeAll(async () => {
    // Login to get authentication token for protected endpoints
    try {
      const loginResponse = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'test@example.com',
          password: 'TestPassword123!'
        });

      if (loginResponse.status === 200) {
        authToken = loginResponse.body.accessToken;
      }
    } catch (error) {
      // Auth might not be available during testing
    }
  });

  describe('GET /api/metrics', () => {
    it('should return Prometheus format metrics', async () => {
      const response = await request(app)
        .get('/api/metrics');

      expect(response.status).toBe(200);
      expect(response.headers['content-type']).toContain('text/plain');
      expect(typeof response.text).toBe('string');
      expect(response.text.length).toBeGreaterThan(0);
    });

    it('should include standard Prometheus metrics', async () => {
      const response = await request(app)
        .get('/api/metrics');

      const metrics = response.text;
      expect(metrics).toContain('http_requests_total');
      expect(metrics).toContain('http_request_duration_seconds');
      expect(metrics).toContain('process_cpu_seconds_total');
      expect(metrics).toContain('process_resident_memory_bytes');
    });

    it('should include custom application metrics', async () => {
      const response = await request(app)
        .get('/api/metrics');

      const metrics = response.text;
      expect(metrics).toContain('app_info');
      expect(metrics).toContain('health_check_total');
      expect(metrics).toContain('aws_operations_total');
    });

    it('should not require authentication', async () => {
      const response = await request(app)
        .get('/api/metrics');

      expect(response.status).toBe(200);
    });

    it('should handle concurrent requests', async () => {
      const requests = Array(10).fill(null).map(() =>
        request(app).get('/api/metrics')
      );

      const responses = await Promise.all(requests);
      
      responses.forEach(response => {
        expect(response.status).toBe(200);
        expect(response.headers['content-type']).toContain('text/plain');
      });
    });

    it('should include timestamp in metrics', async () => {
      const response = await request(app)
        .get('/api/metrics');

      expect(response.text).toContain('#');
      expect(response.text).toMatch(/\d+/); // Should have timestamps
    });

    it('should include help text for metrics', async () => {
      const response = await request(app)
        .get('/api/metrics');

      expect(response.text).toContain('# HELP');
      expect(response.text).toContain('# TYPE');
    });

    it('should have proper metric types', async () => {
      const response = await request(app)
        .get('/api/metrics');

      const metrics = response.text;
      expect(metrics).toContain('counter');
      expect(metrics).toContain('gauge');
      expect(metrics).toContain('histogram');
      expect(metrics).toContain('summary');
    });

    it('should include process metrics', async () => {
      const response = await request(app)
        .get('/api/metrics');

      const metrics = response.text;
      expect(metrics).toContain('process_start_time_seconds');
      expect(metrics).toContain('process_resident_memory_bytes');
      expect(metrics).toContain('process_cpu_seconds_total');
      expect(metrics).toContain('process_virtual_memory_bytes');
    });

    it('should include HTTP metrics', async () => {
      const response = await request(app)
        .get('/api/metrics');

      const metrics = response.text;
      expect(metrics).toContain('http_requests_total');
      expect(metrics).toContain('http_request_duration_seconds');
    });

    it('should label metrics properly', async () => {
      const response = await request(app)
        .get('/api/metrics');

      const metrics = response.text;
      expect(metrics).toContain('{');
      expect(metrics).toContain('}');
      expect(metrics).toContain('method=');
      expect(metrics).toContain('route=');
    });

    it('should handle slow requests gracefully', async () => {
      const response = await request(app)
        .get('/api/metrics?slow=true');

      expect(response.status).toBe(200);
      expect(response.text.length).toBeGreaterThan(0);
    });

    it('should include database metrics', async () => {
      const response = await request(app)
        .get('/api/metrics');

      const metrics = response.text;
      expect(metrics).toContain('db_operations_total');
      expect(metrics).toContain('db_query_duration_seconds');
    });

    it('should track memory usage accurately', async () => {
      const response = await request(app)
        .get('/api/metrics');

      expect(response.text).toContain('process_resident_memory_bytes');
    });
  });

  describe('GET /api/monitoring/status', () => {
    it('should return monitoring status', async () => {
      const response = await request(app)
        .get('/api/monitoring/status');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('status');
      expect(response.body).toHaveProperty('timestamp');
      expect(response.body).toHaveProperty('health');
      expect(response.body).toHaveProperty('errors');
      expect(response.body).toHaveProperty('performance');
    });

    it('should include health metrics', async () => {
      const response = await request(app)
        .get('/api/monitoring/status');

      expect(response.body.health).toBeDefined();
      expect(response.body.health).toHaveProperty('database');
      expect(response.body.health).toHaveProperty('system');
      expect(response.body.health).toHaveProperty('aws');
      expect(response.body.health).toHaveProperty('application');
    });

    it('should include error statistics', async () => {
      const response = await request(app)
        .get('/api/monitoring/status');

      expect(response.body.errors).toBeDefined();
      expect(response.body.errors).toHaveProperty('total');
      expect(response.body.errors).toHaveProperty('recent');
      expect(response.body.errors).toHaveProperty('byLevel');
      expect(response.body.errors.total).toBeGreaterThanOrEqual(0);
      expect(response.body.errors.recent).toBeGreaterThanOrEqual(0);
    });

    it('should include performance metrics', async () => {
      const response = await request(app)
        .get('/api/monitoring/status');

      expect(response.body.performance).toBeDefined();
      expect(response.body.performance).toHaveProperty('averageResponseTime');
      expect(response.body.performance).toHaveProperty('requestsPerSecond');
      expect(response.body.performance).toHaveProperty('errorRate');
      expect(response.body.performance.averageResponseTime).toBeGreaterThanOrEqual(0);
      expect(response.body.performance.requestsPerSecond).toBeGreaterThanOrEqual(0);
      expect(response.body.performance.errorRate).toBeGreaterThanOrEqual(0);
    });

    it('should include system information', async () => {
      const response = await request(app)
        .get('/api/monitoring/status');

      expect(response.body).toHaveProperty('system');
      if (response.body.system) {
        expect(response.body.system).toHaveProperty('uptime');
        expect(response.body.system).toHaveProperty('memory');
        expect(response.body.system).toHaveProperty('cpu');
        expect(response.body.system.uptime).toBeGreaterThan(0);
      }
    });

    it('should track monitoring health', async () => {
      const response = await request(app)
        .get('/api/monitoring/status');

      expect(response.body).toHaveProperty('monitoring');
      if (response.body.monitoring) {
        expect(response.body.monitoring).toHaveProperty('status');
        expect(response.body.monitoring).toHaveProperty('lastCheck');
        expect(['healthy', 'degraded', 'unhealthy']).toContain(response.body.monitoring.status);
      }
    });

    it('should include version information', async () => {
      const response = await request(app)
        .get('/api/monitoring/status');

      expect(response.body).toHaveProperty('version');
      expect(response.body).toHaveProperty('environment');
      expect(response.body.version).toBeDefined();
    });
  });

  describe('GET /api/monitoring/metrics', () => {
    it('should return metrics data', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('success');
      expect(response.body).toHaveProperty('data');
      expect(response.body.success).toBe(true);
    });

    it('should return metrics with authentication', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('data');
    });

    it('should support metric name filtering', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics?metric_name=http_requests')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('success', true);
      expect(response.body.data).toBeDefined();
    });

    it('should validate metric name parameter', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics?metric_name=invalid@metric!name')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200); // Should handle gracefully
    });

    it('should support time range filtering', async () => {
      const now = new Date();
      const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000);

      const response = await request(app)
        .get(`/api/monitoring/metrics?start_time=${oneHourAgo.toISOString()}`)
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('data');
    });

    it('should handle invalid date formats', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics?start_time=invalid-date-format')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200); // Should handle gracefully
    });

    it('should support limit parameter', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics?limit=10')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('count');
      expect(response.body.count).toBeLessThanOrEqual(10);
    });

    it('should validate limit parameter', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics?limit=-1')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200); // Should handle gracefully
    });

    it('should include pagination info', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics?page=2&limit=10')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      if (response.body.pagination) {
        expect(response.body.pagination).toHaveProperty('page');
        expect(response.body.pagination).toHaveProperty('limit');
        expect(response.body.pagination).toHaveProperty('total');
      }
    });

    it('should support aggregation', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics?aggregate=sum&interval=1h')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('data');
    });

    it('should support multiple filters', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics?metric_name=http_requests&start_time=2024-01-01T00:00:00Z&limit=50&page=1')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
    });

    it('should include metadata in response', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.body).toHaveProperty('metadata');
      if (response.body.metadata) {
        expect(response.body.metadata).toHaveProperty('total');
        expect(response.body.metadata).toHaveProperty('timeRange');
      }
    });
  });

  describe('POST /api/monitoring/metrics', () => {
    it('should add new metric', async () => {
      const metricData = {
        name: 'test_metric',
        value: 42,
        labels: { environment: 'test' },
        unit: 'count'
      };

      const response = await request(app)
        .post('/api/monitoring/metrics')
        .send(metricData);

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('success', true);
      expect(response.body).toHaveProperty('data');
      expect(response.body.data.name).toBe('test_metric');
    });

    it('should require authentication', async () => {
      const metricData = {
        name: 'test_metric',
        value: 42
      };

      const response = await request(app)
        .post('/api/monitoring/metrics')
        .send(metricData);

      expect(response.status).toBe(401);
    });

    it('should return 400 for missing required fields', async () => {
      const metricData = {
        name: 'test_metric'
        // Missing value
      };

      const response = await request(app)
        .post('/api/monitoring/metrics')
        .set('Authorization', `Bearer ${authToken}`)
        .send(metricData);

      expect(response.status).toBe(400);
      expect(response.body).toHaveProperty('success', false);
      expect(response.body).toHaveProperty('message');
    });

    it('should handle numeric values', async () => {
      const metricData = {
        name: 'numeric_test',
        value: 123.456,
        unit: 'bytes'
      };

      const response = await request(app)
        .post('/api/monitoring/metrics')
        .set('Authorization', `Bearer ${authToken}`)
        .send(metricData);

      expect(response.status).toBe(200);
      expect(response.body.data.value).toBe(123.456);
    });

    it('should validate metric name format', async () => {
      const invalidNames = [
        'invalid metric name', // Contains space
        'invalid-metric@name', // Contains special char
        '', // Empty
        'a'.repeat(200) // Too long
      ];

      for (const name of invalidNames) {
        const response = await request(app)
          .post('/api/monitoring/metrics')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            name,
            value: 42
          });

        expect(response.status).toBe(400);
      }
    });

    it('should handle different metric types', async () => {
      const metricTypes = [
        { name: 'counter_metric', value: 1, type: 'counter' },
        { name: 'gauge_metric', value: 100, type: 'gauge' },
        { name: 'histogram_metric', value: 50, type: 'histogram' }
      ];

      for (const metric of metricTypes) {
        const response = await request(app)
          .post('/api/monitoring/metrics')
          .set('Authorization', `Bearer ${authToken}`)
          .send(metric);

        expect([200, 400]).toContain(response.status);
      }
    });

    it('should validate label names', async () => {
      const response = await request(app)
        .post('/api/monitoring/metrics')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'test_metric',
          value: 42,
          labels: {
            'invalid-label-name': 'value', // Contains dash
            'ValidLabel': 'value' // Should be valid
          }
        });

      expect([200, 400]).toContain(response.status);
    });

    it('should handle large values', async () => {
      const response = await request(app)
        .post('/api/monitoring/metrics')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'large_value_metric',
          value: Number.MAX_SAFE_INTEGER,
          unit: 'count'
        });

      expect(response.status).toBe(200);
    });

    it('should handle negative values', async () => {
      const response = await request(app)
        .post('/api/monitoring/metrics')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'negative_metric',
          value: -100,
          unit: 'bytes'
        });

      expect(response.status).toBe(200);
    });

    it('should support batch metrics', async () => {
      const batchMetrics = [
        { name: 'metric1', value: 10 },
        { name: 'metric2', value: 20 },
        { name: 'metric3', value: 30 }
      ];

      const response = await request(app)
        .post('/api/monitoring/metrics')
        .set('Authorization', `Bearer ${authToken}`)
        .send({ metrics: batchMetrics });

      expect([200, 400]).toContain(response.status);
    });
  });

  describe('GET /api/monitoring/status/health', () => {
    it('should return system health data', async () => {
      const response = await request(app)
        .get('/api/monitoring/status/health');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('success');
      expect(response.body.data).toHaveProperty('status');
      expect(response.body.data).toHaveProperty('uptime');
      expect(response.body.data).toHaveProperty('last_check');
      expect(response.body.success).toBe(true);
    });

    it('should include service status information', async () => {
      const response = await request(app)
        .get('/api/monitoring/status/health');

      expect(response.body.data).toHaveProperty('services');
      expect(Array.isArray(response.body.data.services)).toBe(true);
      
      if (response.body.data.services.length > 0) {
        const service = response.body.data.services[0];
        expect(service).toHaveProperty('name');
        expect(service).toHaveProperty('status');
        expect(service).toHaveProperty('response_time');
        expect(['healthy', 'degraded', 'unhealthy']).toContain(service.status);
      }
    });

    it('should track response times', async () => {
      const response = await request(app)
        .get('/api/monitoring/status/health');

      if (response.body.data.services) {
        response.body.data.services.forEach(service => {
          expect(service.response_time).toBeGreaterThanOrEqual(0);
        });
      }
    });

    it('should include resource utilization', async () => {
      const response = await request(app)
        .get('/api/monitoring/status/health');

      if (response.body.data.resources) {
        expect(response.body.data.resources).toHaveProperty('cpu');
        expect(response.body.data.resources).toHaveProperty('memory');
        expect(response.body.data.resources).toHaveProperty('disk');
        expect(response.body.data.resources.cpu).toBeGreaterThanOrEqual(0);
        expect(response.body.data.resources.memory).toBeGreaterThanOrEqual(0);
      }
    });
  });

  describe('GET /api/monitoring/status/live', () => {
    it('should return live status', async () => {
      const response = await request(app)
        .get('/api/monitoring/status/live');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('success', true);
      expect(response.body.data).toHaveProperty('system_health');
      expect(response.body.data).toHaveProperty('active_alerts');
      expect(response.body.data).toHaveProperty('recent_errors');
      expect(response.body.data).toHaveProperty('timestamp');
    });

    it('should include real-time metrics', async () => {
      const response = await request(app)
        .get('/api/monitoring/status/live');

      if (response.body.data.metrics) {
        expect(response.body.data.metrics).toHaveProperty('requests_per_second');
        expect(response.body.data.metrics).toHaveProperty('error_rate');
        expect(response.body.data.metrics).toHaveProperty('average_response_time');
        expect(response.body.data.metrics.requests_per_second).toBeGreaterThanOrEqual(0);
      }
    });

    it('should track active alerts', async () => {
      const response = await request(app)
        .get('/api/monitoring/status/live');

      expect(response.body.data).toHaveProperty('active_alerts');
      expect(Array.isArray(response.body.data.active_alerts)).toBe(true);
      
      response.body.data.active_alerts.forEach(alert => {
        expect(alert).toHaveProperty('severity');
        expect(alert).toHaveProperty('message');
        expect(alert).toHaveProperty('timestamp');
      });
    });

    it('should list recent errors', async () => {
      const response = await request(app)
        .get('/api/monitoring/status/live');

      expect(response.body.data).toHaveProperty('recent_errors');
      expect(Array.isArray(response.body.data.recent_errors)).toBe(true);
    });

    it('should update timestamps', async () => {
      const response1 = await request(app).get('/api/monitoring/status/live');
      await new Promise(resolve => setTimeout(resolve, 100));
      const response2 = await request(app).get('/api/monitoring/status/live');

      expect(response1.body.data.timestamp).toBeLessThanOrEqual(response2.body.data.timestamp);
    });
  });

  describe('GET /api/monitoring/performance/trends', () => {
    it('should return performance trends', async () => {
      const response = await request(app)
        .get('/api/monitoring/performance/trends');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('success', true);
      expect(response.body.data).toHaveProperty('trends');
      expect(response.body.data).toHaveProperty('period');
      expect(response.body.data).toHaveProperty('metrics');
    });

    it('should support period parameter', async () => {
      const response = await request(app)
        .get('/api/monitoring/performance/trends?period=24h');

      expect(response.status).toBe(200);
      expect(response.body.data.period).toBe('24h');
    });

    it('should validate period parameter', async () => {
      const invalidPeriods = ['invalid', '123', 'year'];
      
      for (const period of invalidPeriods) {
        const response = await request(app)
          .get(`/api/monitoring/performance/trends?period=${period}`);

        expect(response.status).toBe(400);
        expect(response.body).toHaveProperty('message');
      }
    });

    it('should support metrics filtering', async () => {
      const response = await request(app)
        .get('/api/monitoring/performance/trends?metrics=response_time,cpu_usage');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('data');
    });

    it('should include trend data', async () => {
      const response = await request(app)
        .get('/api/monitoring/performance/trends');

      expect(response.body.data.trends).toBeDefined();
      if (response.body.data.trends.response_time) {
        expect(response.body.data.trends.response_time).toHaveProperty('current');
        expect(response.body.data.trends.response_time).toHaveProperty('previous');
        expect(response.body.data.trends.response_time).toHaveProperty('change');
      }
    });

    it('should calculate percentage changes', async () => {
      const response = await request(app)
        .get('/api/monitoring/performance/trends?period=7d');

      if (response.body.data.trends) {
        Object.values(response.body.data.trends).forEach(trend => {
          if (trend.change !== undefined) {
            expect(typeof trend.change).toBe('number');
          }
        });
      }
    });
  });

  describe('GET /api/monitoring/performance/comparison', () => {
    it('should return performance comparison data', async () => {
      const response = await request(app)
        .get('/api/monitoring/performance/comparison');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('success', true);
      expect(response.body.data).toHaveProperty('metric');
      expect(response.body.data).toHaveProperty('current_period');
      expect(response.body.data).toHaveProperty('previous_period');
      expect(response.body.data).toHaveProperty('change_percent');
    });

    it('should support metric selection', async () => {
      const response = await request(app)
        .get('/api/monitoring/performance/comparison?metric=response_time');

      expect(response.status).toBe(200);
      expect(response.body.data.metric).toBe('response_time');
    });

    it('should calculate comparison correctly', async () => {
      const response = await request(app)
        .get('/api/monitoring/performance/comparison?metric=cpu_usage&period=7d');

      if (response.body.data.change_percent !== undefined) {
        expect(typeof response.body.data.change_percent).toBe('number');
      }
    });

    it('should include period details', async () => {
      const response = await request(app)
        .get('/api/monitoring/performance/comparison?metric=memory_usage');

      expect(response.body.data.current_period).toHaveProperty('start');
      expect(response.body.data.current_period).toHaveProperty('end');
      expect(response.body.data.previous_period).toHaveProperty('start');
      expect(response.body.data.previous_period).toHaveProperty('end');
    });
  });

  describe('GET /api/monitoring/performance/summary', () => {
    it('should return performance summary', async () => {
      const response = await request(app)
        .get('/api/monitoring/performance/summary');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('success', true);
      expect(response.body.data).toHaveProperty('overall_performance');
      expect(response.body.data).toHaveProperty('key_metrics');
      expect(response.body.data).toHaveProperty('trends');
      expect(response.body.data).toHaveProperty('recommendations');
    });

    it('should include overall performance rating', async () => {
      const response = await request(app)
        .get('/api/monitoring/performance/summary');

      expect(response.body.data.overall_performance).toHaveProperty('rating');
      expect(response.body.data.overall_performance).toHaveProperty('score');
      expect(['excellent', 'good', 'fair', 'poor']).toContain(response.body.data.overall_performance.rating);
      expect(response.body.data.overall_performance.score).toBeGreaterThanOrEqual(0);
      expect(response.body.data.overall_performance.score).toBeLessThanOrEqual(100);
    });

    it('should list key metrics', async () => {
      const response = await request(app)
        .get('/api/monitoring/performance/summary');

      expect(response.body.data.key_metrics).toBeInstanceOf(Array);
      expect(response.body.data.key_metrics.length).toBeGreaterThan(0);
      
      response.body.data.key_metrics.forEach(metric => {
        expect(metric).toHaveProperty('name');
        expect(metric).toHaveProperty('value');
        expect(metric).toHaveProperty('unit');
      });
    });

    it('should provide trend analysis', async () => {
      const response = await request(app)
        .get('/api/monitoring/performance/summary');

      expect(response.body.data.trends).toBeDefined();
      expect(response.body.data.trends).toHaveProperty('summary');
      expect(response.body.data.trends).toHaveProperty('direction');
      expect(['improving', 'declining', 'stable']).toContain(response.body.data.trends.direction);
    });

    it('should generate recommendations', async () => {
      const response = await request(app)
        .get('/api/monitoring/performance/summary');

      expect(response.body.data.recommendations).toBeInstanceOf(Array);
      
      response.body.data.recommendations.forEach(rec => {
        expect(rec).toHaveProperty('priority');
        expect(rec).toHaveProperty('description');
        expect(['high', 'medium', 'low']).toContain(rec.priority);
      });
    });
  });

  describe('GET /api/monitoring/errors', () => {
    it('should return error logs', async () => {
      const response = await request(app)
        .get('/api/monitoring/errors');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('success', true);
      expect(response.body).toHaveProperty('data');
      expect(response.body).toHaveProperty('count');
      expect(Array.isArray(response.body.data)).toBe(true);
      expect(response.body.count).toBeGreaterThanOrEqual(0);
    });

    it('should require authentication', async () => {
      const response = await request(app)
        .get('/api/monitoring/errors');

      expect([200, 401]).toContain(response.status);
    });

    it('should support level filtering', async () => {
      const response = await request(app)
        .get('/api/monitoring/errors?level=error')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
    });

    it('should validate level parameter', async () => {
      const invalidLevels = ['invalid', 'debug', 'trace'];
      
      for (const level of invalidLevels) {
        const response = await request(app)
          .get(`/api/monitoring/errors?level=${level}`)
          .set('Authorization', `Bearer ${authToken}`);

        expect([200, 400]).toContain(response.status);
      }
    });

    it('should support time range filtering', async () => {
      const now = new Date();
      const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000);

      const response = await request(app)
        .get(`/api/monitoring/errors?start_time=${oneHourAgo.toISOString()}`)
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
    });

    it('should handle invalid date parameters', async () => {
      const response = await request(app)
        .get('/api/monitoring/errors?start_time=invalid-date')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200); // Should handle gracefully
    });

    it('should support search filtering', async () => {
      const response = await request(app)
        .get('/api/monitoring/errors?search=database')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
    });

    it('should include error details', async () => {
      const response = await request(app)
        .get('/api/monitoring/errors')
        .set('Authorization', `Bearer ${authToken}`);

      if (response.body.data.length > 0) {
        const error = response.body.data[0];
        expect(error).toHaveProperty('timestamp');
        expect(error).toHaveProperty('level');
        expect(error).toHaveProperty('message');
        expect(error).toHaveProperty('source');
      }
    });

    it('should support pagination', async () => {
      const response = await request(app)
        .get('/api/monitoring/errors?page=1&limit=20')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      if (response.body.pagination) {
        expect(response.body.pagination).toHaveProperty('total');
        expect(response.body.pagination).toHaveProperty('page');
        expect(response.body.pagination).toHaveProperty('limit');
      }
    });

    it('should aggregate error statistics', async () => {
      const response = await request(app)
        .get('/api/monitoring/errors?aggregate=true')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      if (response.body.aggregated) {
        expect(response.body.aggregated).toHaveProperty('by_level');
        expect(response.body.aggregated).toHaveProperty('by_source');
      }
    });
  });

  describe('POST /api/monitoring/errors/log', () => {
    it('should log new error', async () => {
      const errorData = {
        level: 'error',
        message: 'Test error message',
        stack: 'Error stack trace',
        source: 'test-module'
      };

      const response = await request(app)
        .post('/api/monitoring/errors/log')
        .send(errorData);

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('success', true);
      expect(response.body).toHaveProperty('data');
      expect(response.body.data.level).toBe('error');
      expect(response.body.data.message).toBe('Test error message');
    });

    it('should require authentication', async () => {
      const errorData = {
        level: 'error',
        message: 'Test error message'
      };

      const response = await request(app)
        .post('/api/monitoring/errors/log')
        .send(errorData);

      expect(response.status).toBe(401);
    });

    it('should return 400 for missing required fields', async () => {
      const response = await request(app)
        .post('/api/monitoring/errors/log')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          level: 'error'
          // Missing message
        });

      expect(response.status).toBe(400);
      expect(response.body).toHaveProperty('success', false);
      expect(response.body).toHaveProperty('message');
    });

    it('should support different error levels', async () => {
      const levels = ['error', 'warning', 'info', 'debug'];
      
      for (const level of levels) {
        const response = await request(app)
          .post('/api/monitoring/errors/log')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            level,
            message: `Test ${level} message`
          });

        expect(response.status).toBe(200);
        expect(response.body.data.level).toBe(level);
      }
    });

    it('should validate error levels', async () => {
      const invalidLevels = ['invalid', 'trace', 'fatal'];
      
      for (const level of invalidLevels) {
        const response = await request(app)
          .post('/api/monitoring/errors/log')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            level,
            message: 'Test message'
          });

        expect(response.status).toBe(400);
      }
    });

    it('should handle error context', async () => {
      const response = await request(app)
        .post('/api/monitoring/errors/log')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          level: 'error',
          message: 'Test error with context',
          context: {
            userId: '123',
            requestId: 'abc-123',
            endpoint: '/api/test'
          }
        });

      expect(response.status).toBe(200);
      if (response.body.data.context) {
        expect(response.body.data.context).toHaveProperty('userId');
        expect(response.body.data.context).toHaveProperty('requestId');
      }
    });

    it('should sanitize error messages', async () => {
      const response = await request(app)
        .post('/api/monitoring/errors/log')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          level: 'error',
          message: '<script>alert("xss")</script>'
        });

      expect(response.status).toBe(200);
      // Message should be sanitized or rejected
    });

    it('should include timestamp', async () => {
      const before = Date.now();
      const response = await request(app)
        .post('/api/monitoring/errors/log')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          level: 'error',
          message: 'Test timestamp'
        });
      const after = Date.now();

      expect(response.status).toBe(200);
      expect(response.body.data.timestamp).toBeGreaterThanOrEqual(before);
      expect(response.body.data.timestamp).toBeLessThanOrEqual(after);
    });

    it('should support batch error logging', async () => {
      const batchErrors = [
        { level: 'error', message: 'Error 1' },
        { level: 'warning', message: 'Warning 1' },
        { level: 'info', message: 'Info 1' }
      ];

      const response = await request(app)
        .post('/api/monitoring/errors/log')
        .set('Authorization', `Bearer ${authToken}`)
        .send({ errors: batchErrors });

      expect([200, 400]).toContain(response.status);
    });
  });

  describe('GET /api/monitoring/health/overview', () => {
    it('should return health overview', async () => {
      const response = await request(app)
        .get('/api/monitoring/health/overview');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('success', true);
      expect(response.body.data).toHaveProperty('overall_status');
      expect(response.body.data).toHaveProperty('components');
      expect(response.body.data).toHaveProperty('alerts');
      expect(response.body.data).toHaveProperty('uptime_percentage');
    });

    it('should include uptime percentage', async () => {
      const response = await request(app)
        .get('/api/monitoring/health/overview');

      expect(response.body.data).toHaveProperty('uptime_percentage');
      expect(response.body.data.uptime_percentage).toBeGreaterThan(0);
      expect(response.body.data.uptime_percentage).toBeLessThanOrEqual(100);
    });

    it('should list all monitored components', async () => {
      const response = await request(app)
        .get('/api/monitoring/health/overview');

      expect(response.body.data.components).toBeInstanceOf(Array);
      expect(response.body.data.components.length).toBeGreaterThan(0);
      
      response.body.data.components.forEach(component => {
        expect(component).toHaveProperty('name');
        expect(component).toHaveProperty('status');
        expect(component).toHaveProperty('last_check');
      });
    });

    it('should include alert summary', async () => {
      const response = await request(app)
        .get('/api/monitoring/health/overview');

      expect(response.body.data.alerts).toBeInstanceOf(Array);
      
      response.body.data.alerts.forEach(alert => {
        expect(alert).toHaveProperty('severity');
        expect(alert).toHaveProperty('message');
        expect(['low', 'medium', 'high', 'critical']).toContain(alert.severity);
      });
    });

    it('should calculate overall status correctly', async () => {
      const response = await request(app)
        .get('/api/monitoring/health/overview');

      const overallStatus = response.body.data.overall_status;
      expect(['healthy', 'degraded', 'unhealthy']).toContain(overallStatus);
    });

    it('should include health score', async () => {
      const response = await request(app)
        .get('/api/monitoring/health/overview');

      if (response.body.data.health_score !== undefined) {
        expect(response.body.data.health_score).toBeGreaterThanOrEqual(0);
        expect(response.body.data.health_score).toBeLessThanOrEqual(100);
      }
    });
  });

  describe('GET /api/monitoring/health/metrics', () => {
    it('should return health metrics', async () => {
      const response = await request(app)
        .get('/api/monitoring/health/metrics');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('success', true);
      expect(response.body.data).toHaveProperty('cpu');
      expect(response.body.data).toHaveProperty('memory');
      expect(response.body.data).toHaveProperty('disk');
      expect(response.body.data).toHaveProperty('network');
    });

    it('should include CPU metrics', async () => {
      const response = await request(app)
        .get('/api/monitoring/health/metrics');

      const cpu = response.body.data.cpu;
      expect(cpu).toHaveProperty('usage');
      expect(cpu).toHaveProperty('load_average');
      expect(cpu).toHaveProperty('cores');
      expect(cpu.usage).toBeGreaterThanOrEqual(0);
      expect(cpu.usage).toBeLessThanOrEqual(100);
      expect(cpu.cores).toBeGreaterThan(0);
    });

    it('should include memory metrics', async () => {
      const response = await request(app)
        .get('/api/monitoring/health/metrics');

      const memory = response.body.data.memory;
      expect(memory).toHaveProperty('usage');
      expect(memory).toHaveProperty('total');
      expect(memory).toHaveProperty('available');
      expect(memory.usage).toBeGreaterThanOrEqual(0);
      expect(memory.usage).toBeLessThanOrEqual(100);
    });

    it('should include disk metrics', async () => {
      const response = await request(app)
        .get('/api/monitoring/health/metrics');

      const disk = response.body.data.disk;
      expect(disk).toHaveProperty('usage');
      expect(disk).toHaveProperty('total');
      expect(disk).toHaveProperty('free');
      expect(disk.usage).toBeGreaterThanOrEqual(0);
      expect(disk.usage).toBeLessThanOrEqual(100);
    });

    it('should include network metrics', async () => {
      const response = await request(app)
        .get('/api/monitoring/health/metrics');

      const network = response.body.data.network;
      expect(network).toHaveProperty('bytes_sent');
      expect(network).toHaveProperty('bytes_received');
      expect(network).toHaveProperty('packets_sent');
      expect(network).toHaveProperty('packets_received');
      expect(network.bytes_sent).toBeGreaterThanOrEqual(0);
      expect(network.bytes_received).toBeGreaterThanOrEqual(0);
    });

    it('should include process metrics', async () => {
      const response = await request(app)
        .get('/api/monitoring/health/metrics');

      if (response.body.data.process) {
        expect(response.body.data.process).toHaveProperty('uptime');
        expect(response.body.data.process).toHaveProperty('memory_usage');
        expect(response.body.data.process).toHaveProperty('cpu_usage');
        expect(response.body.data.process.uptime).toBeGreaterThan(0);
      }
    });

    it('should track metrics over time', async () => {
      const response = await request(app)
        .get('/api/monitoring/health/metrics?history=true');

      expect(response.status).toBe(200);
      if (response.body.data.history) {
        expect(response.body.data.history).toBeInstanceOf(Array);
        expect(response.body.data.history.length).toBeGreaterThan(0);
      }
    });
  });

  describe('GET /api/monitoring/health/services', () => {
    it('should return service health status', async () => {
      const response = await request(app)
        .get('/api/monitoring/health/services');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('success', true);
      expect(response.body.data).toBeInstanceOf(Array);
      
      if (response.body.data.length > 0) {
        const service = response.body.data[0];
        expect(service).toHaveProperty('name');
        expect(service).toHaveProperty('status');
        expect(service).toHaveProperty('response_time');
        expect(['healthy', 'degraded', 'unhealthy']).toContain(service.status);
        expect(service.response_time).toBeGreaterThanOrEqual(0);
      }
    });

    it('should include service dependencies', async () => {
      const response = await request(app)
        .get('/api/monitoring/health/services');

      if (response.body.data.length > 0) {
        const service = response.body.data[0];
        if (service.dependencies) {
          expect(Array.isArray(service.dependencies)).toBe(true);
        }
      }
    });

    it('should track service availability', async () => {
      const response = await request(app)
        .get('/api/monitoring/health/services');

      if (response.body.data.length > 0) {
        response.body.data.forEach(service => {
          expect(service).toHaveProperty('availability');
          expect(service.availability).toBeGreaterThanOrEqual(0);
          expect(service.availability).toBeLessThanOrEqual(100);
        });
      }
    });

    it('should include last check time', async () => {
      const response = await request(app)
        .get('/api/monitoring/health/services');

      if (response.body.data.length > 0) {
        response.body.data.forEach(service => {
          expect(service).toHaveProperty('last_check');
          expect(typeof service.last_check).toBe('number');
        });
      }
    });
  });

  describe('GET /api/monitoring/alerts', () => {
    it('should return alerts list', async () => {
      const response = await request(app)
        .get('/api/monitoring/alerts');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('success', true);
      expect(response.body).toHaveProperty('data');
      expect(response.body).toHaveProperty('count');
      expect(Array.isArray(response.body.data)).toBe(true);
      expect(response.body.count).toBeGreaterThanOrEqual(0);
    });

    it('should require authentication', async () => {
      const response = await request(app)
        .get('/api/monitoring/alerts');

      expect([200, 401]).toContain(response.status);
    });

    it('should support status filtering', async () => {
      const response = await request(app)
        .get('/api/monitoring/alerts?status=active')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
    });

    it('should validate status parameter', async () => {
      const invalidStatuses = ['invalid', 'pending', 'closed'];
      
      for (const status of invalidStatuses) {
        const response = await request(app)
          .get(`/api/monitoring/alerts?status=${status}`)
          .set('Authorization', `Bearer ${authToken}`);

        expect([200, 400]).toContain(response.status);
      }
    });

    it('should support severity filtering', async () => {
      const response = await request(app)
        .get('/api/monitoring/alerts?severity=critical')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
    });

    it('should validate severity parameter', async () => {
      const invalidSeverities = ['lowest', 'highest', 'urgent'];
      
      for (const severity of invalidSeverities) {
        const response = await request(app)
          .get(`/api/monitoring/alerts?severity=${severity}`)
          .set('Authorization', `Bearer ${authToken}`);

        expect([200, 400]).toContain(response.status);
      }
    });

    it('should include alert details', async () => {
      const response = await request(app)
        .get('/api/monitoring/alerts')
        .set('Authorization', `Bearer ${authToken}`);

      if (response.body.data.length > 0) {
        const alert = response.body.data[0];
        expect(alert).toHaveProperty('id');
        expect(alert).toHaveProperty('name');
        expect(alert).toHaveProperty('severity');
        expect(alert).toHaveProperty('status');
        expect(alert).toHaveProperty('created_at');
        expect(['low', 'medium', 'high', 'critical']).toContain(alert.severity);
        expect(['active', 'acknowledged', 'resolved']).toContain(alert.status);
      }
    });

    it('should support pagination', async () => {
      const response = await request(app)
        .get('/api/monitoring/alerts?page=1&limit=10')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      if (response.body.pagination) {
        expect(response.body.pagination).toHaveProperty('total');
        expect(response.body.pagination).toHaveProperty('page');
        expect(response.body.pagination).toHaveProperty('limit');
      }
    });

    it('should filter by time range', async () => {
      const response = await request(app)
        .get('/api/monitoring/alerts?since=2024-01-01T00:00:00Z')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
    });

    it('should include alert metadata', async () => {
      const response = await request(app)
        .get('/api/monitoring/alerts')
        .set('Authorization', `Bearer ${authToken}`);

      if (response.body.data.length > 0) {
        const alert = response.body.data[0];
        expect(alert).toHaveProperty('metric');
        expect(alert).toHaveProperty('threshold');
        expect(alert).toHaveProperty('current_value');
      }
    });
  });

  describe('POST /api/monitoring/alerts', () => {
    it('should create new alert', async () => {
      const alertData = {
        name: 'Test Alert',
        description: 'Test alert description',
        condition: 'cpu_usage > 80',
        threshold: 80,
        severity: 'high'
      };

      const response = await request(app)
        .post('/api/monitoring/alerts')
        .set('Authorization', `Bearer ${authToken}`)
        .send(alertData);

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('success', true);
      expect(response.body).toHaveProperty('data');
      expect(response.body.data.name).toBe('Test Alert');
    });

    it('should return 400 for missing required fields', async () => {
      const response = await request(app)
        .post('/api/monitoring/alerts')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'Test Alert'
          // Missing condition and threshold
        });

      expect(response.status).toBe(400);
      expect(response.body).toHaveProperty('success', false);
      expect(response.body).toHaveProperty('message');
    });

    it('should validate alert name', async () => {
      const invalidNames = ['', 'a'.repeat(200), 'Alert with <script>'];

      for (const name of invalidNames) {
        const response = await request(app)
          .post('/api/monitoring/alerts')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            name,
            condition: 'cpu_usage > 80',
            threshold: 80,
            severity: 'high'
          });

        expect(response.status).toBe(400);
      }
    });

    it('should validate condition format', async () => {
      const invalidConditions = ['', 'invalid_condition', 'metric > value < other'];

      for (const condition of invalidConditions) {
        const response = await request(app)
          .post('/api/monitoring/alerts')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            name: 'Test Alert',
            condition,
            threshold: 80,
            severity: 'high'
          });

        expect(response.status).toBe(400);
      }
    });

    it('should validate severity levels', async () => {
      const invalidSeverities = ['lowest', 'urgent', 'critical_high'];

      for (const severity of invalidSeverities) {
        const response = await request(app)
          .post('/api/monitoring/alerts')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            name: 'Test Alert',
            condition: 'cpu_usage > 80',
            threshold: 80,
            severity
          });

        expect(response.status).toBe(400);
      }
    });

    it('should handle different alert types', async () => {
      const alertTypes = [
        { name: 'Threshold Alert', condition: 'cpu_usage > 80', threshold: 80, type: 'threshold' },
        { name: 'Anomaly Alert', condition: 'error_rate > baseline + 2*stddev', type: 'anomaly' },
        { name: 'Change Alert', condition: 'disk_usage increased by 50%', type: 'change' }
      ];

      for (const alert of alertTypes) {
        const response = await request(app)
          .post('/api/monitoring/alerts')
          .set('Authorization', `Bearer ${authToken}`)
          .send(alert);

        expect([200, 400]).toContain(response.status);
      }
    });
  });

  describe('Alert Management', () => {
    let alertId: string;

    beforeAll(async () => {
      // Create a test alert
      const response = await request(app)
        .post('/api/monitoring/alerts')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'Test Alert for Management',
          description: 'Test alert',
          condition: 'test_metric > 100',
          threshold: 100,
          severity: 'medium'
        });

      if (response.status === 200) {
        alertId = response.body.data.id;
      }
    });

    describe('PUT /api/monitoring/alerts/:id', () => {
      it('should update alert', async () => {
        if (!alertId) {
          console.log('Skipping alert update test - no alert ID');
          return;
        }

        const response = await request(app)
          .put(`/api/monitoring/alerts/${alertId}`)
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            name: 'Updated Test Alert',
            description: 'Updated description'
          });

        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('success', true);
      });

      it('should return 404 for non-existent alert', async () => {
        const response = await request(app)
          .put('/api/monitoring/alerts/non-existent-id')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            name: 'Updated Alert'
          });

        expect(response.status).toBe(404);
      });

      it('should validate update data', async () => {
        if (!alertId) {
          console.log('Skipping alert validation test - no alert ID');
          return;
        }

        const response = await request(app)
          .put(`/api/monitoring/alerts/${alertId}`)
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            severity: 'invalid_severity'
          });

        expect(response.status).toBe(400);
      });
    });

    describe('POST /api/monitoring/alerts/:id/acknowledge', () => {
      it('should acknowledge alert', async () => {
        if (!alertId) {
          console.log('Skipping alert acknowledge test - no alert ID');
          return;
        }

        const response = await request(app)
          .post(`/api/monitoring/alerts/${alertId}/acknowledge`)
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('success', true);
      });

      it('should include acknowledgment details', async () => {
        if (!alertId) {
          console.log('Skipping alert acknowledge details test - no alert ID');
          return;
        }

        const response = await request(app)
          .post(`/api/monitoring/alerts/${alertId}/acknowledge`)
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            comment: 'Investigating the issue'
          });

        expect(response.status).toBe(200);
        if (response.body.data.acknowledged_at) {
          expect(typeof response.body.data.acknowledged_at).toBe('number');
        }
      });
    });

    describe('POST /api/monitoring/alerts/:id/resolve', () => {
      it('should resolve alert', async () => {
        if (!alertId) {
          console.log('Skipping alert resolve test - no alert ID');
          return;
        }

        const response = await request(app)
          .post(`/api/monitoring/alerts/${alertId}/resolve`)
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('success', true);
      });

      it('should include resolution details', async () => {
        if (!alertId) {
          console.log('Skipping alert resolution details test - no alert ID');
          return;
        }

        const response = await request(app)
          .post(`/api/monitoring/alerts/${alertId}/resolve`)
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            comment: 'Issue has been resolved'
          });

        expect(response.status).toBe(200);
        if (response.body.data.resolved_at) {
          expect(typeof response.body.data.resolved_at).toBe('number');
        }
      });
    });

    describe('DELETE /api/monitoring/alerts/:id', () => {
      it('should delete alert', async () => {
        if (!alertId) {
          console.log('Skipping alert delete test - no alert ID');
          return;
        }

        const response = await request(app)
          .delete(`/api/monitoring/alerts/${alertId}`)
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
        expect(response.body).toHaveProperty('success', true);
      });

      it('should return 404 for non-existent alert', async () => {
        const response = await request(app)
          .delete('/api/monitoring/alerts/non-existent-id')
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(404);
      });
    });
  });

  describe('GET /api/monitoring/export', () => {
    it('should export monitoring data', async () => {
      const response = await request(app)
        .get('/api/monitoring/export');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('success', true);
      expect(response.body).toHaveProperty('exported_at');
      expect(response.body).toHaveProperty('type');
      expect(response.body).toHaveProperty('data');
      expect(typeof response.body.exported_at).toBe('number');
    });

    it('should require authentication', async () => {
      const response = await request(app)
        .get('/api/monitoring/export');

      expect([200, 401]).toContain(response.status);
    });

    it('should support different export types', async () => {
      const types = ['metrics', 'alerts', 'errors', 'health'];
      
      for (const type of types) {
        const response = await request(app)
          .get(`/api/monitoring/export?type=${type}`)
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
        expect(response.body.type).toBe(type);
      }
    });

    it('should validate export type', async () => {
      const response = await request(app)
        .get('/api/monitoring/export?type=invalid')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(400);
    });

    it('should support date range filtering', async () => {
      const response = await request(app)
        .get('/api/monitoring/export?start_date=2024-01-01&end_date=2024-12-31')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
    });

    it('should include export metadata', async () => {
      const response = await request(app)
        .get('/api/monitoring/export')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.body).toHaveProperty('record_count');
      expect(response.body).toHaveProperty('date_range');
      expect(response.body.record_count).toBeGreaterThanOrEqual(0);
    });

    it('should support different formats', async () => {
      const formats = ['json', 'csv', 'xml'];
      
      for (const format of formats) {
        const response = await request(app)
          .get(`/api/monitoring/export?format=${format}`)
          .set('Authorization', `Bearer ${authToken}`);

        expect(response.status).toBe(200);
      }
    });

    it('should handle large exports', async () => {
      const response = await request(app)
        .get('/api/monitoring/export?large=true')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
    });
  });

  describe('GET /api/monitoring/health-check', () => {
    it('should return monitoring health check', async () => {
      const response = await request(app)
        .get('/api/monitoring/health-check');

      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('success', true);
      expect(response.body.data).toHaveProperty('status');
      expect(response.body.data).toHaveProperty('timestamp');
      expect(response.body.data).toHaveProperty('uptime');
      expect(response.body.data.status).toBe('healthy');
    });

    it('should include monitoring system metrics', async () => {
      const response = await request(app)
        .get('/api/monitoring/health-check');

      expect(response.body.data).toHaveProperty('metrics_collected');
      expect(response.body.data).toHaveProperty('alerts_active');
      expect(response.body.data).toHaveProperty('error_rate');
      expect(response.body.data.metrics_collected).toBeGreaterThanOrEqual(0);
    });

    it('should track monitoring performance', async () => {
      const response = await request(app)
        .get('/api/monitoring/health-check');

      if (response.body.data.performance) {
        expect(response.body.data.performance).toHaveProperty('avg_collection_time');
        expect(response.body.data.performance).toHaveProperty('last_collection');
        expect(response.body.data.performance.avg_collection_time).toBeGreaterThanOrEqual(0);
      }
    });
  });

  describe('Authentication Requirements', () => {
    it('should require authentication for protected monitoring endpoints', async () => {
      const protectedEndpoints = [
        { method: 'GET', path: '/api/monitoring/metrics' },
        { method: 'POST', path: '/api/monitoring/metrics' },
        { method: 'GET', path: '/api/monitoring/alerts' },
        { method: 'POST', path: '/api/monitoring/alerts' },
        { method: 'GET', path: '/api/monitoring/errors' },
        { method: 'POST', path: '/api/monitoring/errors/log' }
      ];

      for (const endpoint of protectedEndpoints) {
        const response = await request(app)
          [endpoint.method.toLowerCase()](endpoint.path)
          .send({});

        // Some endpoints might be public, so we check if they require auth
        if (response.status === 401) {
          expect(response.status).toBe(401);
        }
      }
    });

    it('should allow public access to metrics endpoint', async () => {
      const response = await request(app)
        .get('/api/metrics');

      expect(response.status).toBe(200);
    });

    it('should handle invalid tokens', async () => {
      const response = await request(app)
        .get('/api/monitoring/status')
        .set('Authorization', 'Bearer invalid-token');

      expect(response.status).toBe(401);
    });

    it('should handle expired tokens', async () => {
      const expiredToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.expired';
      const response = await request(app)
        .get('/api/monitoring/status')
        .set('Authorization', `Bearer ${expiredToken}`);

      expect(response.status).toBe(401);
    });
  });

  describe('Performance Tests', () => {
    it('should handle concurrent metric requests', async () => {
      const requests = Array(20).fill(null).map(() =>
        request(app).get('/api/monitoring/metrics')
      );

      const responses = await Promise.all(requests);
      
      responses.forEach(response => {
        expect([200, 401]).toContain(response.status);
      });
    });

    it('should respond to monitoring requests within reasonable time', async () => {
      const startTime = Date.now();
      const response = await request(app)
        .get('/api/monitoring/status');
      const responseTime = Date.now() - startTime;

      expect(response.status).toBe(200);
      expect(responseTime).toBeLessThan(3000); // Should respond within 3 seconds
    });

    it('should handle bulk operations efficiently', async () => {
      const startTime = Date.now();
      const response = await request(app)
        .post('/api/monitoring/metrics')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          metrics: Array(100).fill(null).map((_, i) => ({
            name: `bulk_metric_${i}`,
            value: i
          }))
        });
      const responseTime = Date.now() - startTime;

      expect([200, 400]).toContain(response.status);
      // Should complete within reasonable time
      expect(responseTime).toBeLessThan(10000);
    });

    it('should cache expensive queries', async () => {
      const start1 = Date.now();
      await request(app)
        .get('/api/monitoring/performance/trends?cached=true')
        .set('Authorization', `Bearer ${authToken}`);
      const time1 = Date.now() - start1;

      const start2 = Date.now();
      await request(app)
        .get('/api/monitoring/performance/trends?cached=true')
        .set('Authorization', `Bearer ${authToken}`);
      const time2 = Date.now() - start2;

      // Second request should be faster due to caching
      expect(time2).toBeLessThanOrEqual(time1);
    });

    it('should handle pagination efficiently', async () => {
      const requests = Array(5).fill(null).map((_, i) =>
        request(app)
          .get(`/api/monitoring/errors?page=${i + 1}&limit=50`)
          .set('Authorization', `Bearer ${authToken}`)
      );

      const responses = await Promise.all(requests);
      responses.forEach(response => {
        expect([200, 401]).toContain(response.status);
      });
    });
  });

  describe('Error Handling', () => {
    it('should handle invalid metric names gracefully', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics?metric_name=invalid@metric!name')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
    });

    it('should handle invalid time parameters', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics?start_time=invalid-date')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
    });

    it('should handle invalid limit values', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics?limit=-1')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
    });

    it('should handle malformed requests', async () => {
      const response = await request(app)
        .post('/api/monitoring/metrics')
        .set('Authorization', `Bearer ${authToken}`)
        .set('Content-Type', 'application/json')
        .send('{ invalid json }');

      expect([400, 500]).toContain(response.status);
    });

    it('should provide meaningful error messages', async () => {
      const response = await request(app)
        .post('/api/monitoring/metrics')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          // Missing required fields
        });

      expect(response.status).toBe(400);
      expect(response.body).toHaveProperty('message');
      expect(response.body.message).toBeDefined();
    });

    it('should handle database errors gracefully', async () => {
      const response = await request(app)
        .get('/api/monitoring/alerts')
        .set('Authorization', `Bearer ${authToken}`);

      expect([200, 500]).toContain(response.status);
      if (response.status === 500) {
        expect(response.body).toHaveProperty('error');
      }
    });

    it('should validate input parameters', async () => {
      const response = await request(app)
        .get('/api/monitoring/alerts?severity=invalid')
        .set('Authorization', `Bearer ${authToken}`);

      expect([200, 400]).toContain(response.status);
    });

    it('should handle rate limiting', async () => {
      const requests = Array(100).fill(null).map(() =>
        request(app).get('/api/monitoring/status')
      );

      const responses = await Promise.all(requests);
      responses.forEach(response => {
        expect([200, 429, 503]).toContain(response.status);
      });
    });

    it('should log monitoring errors', async () => {
      // This would be verified in actual logging system
      const response = await request(app)
        .get('/api/monitoring/errors?level=invalid')
        .set('Authorization', `Bearer ${authToken}`);

      expect([200, 400]).toContain(response.status);
    });

    it('should maintain monitoring during failures', async () => {
      const response = await request(app)
        .get('/api/monitoring/health-check');

      expect(response.status).toBe(200);
      expect(response.body.data.status).toBe('healthy');
    });
  });

  describe('Data Validation Tests', () => {
    it('should validate metric value ranges', async () => {
      const invalidValues = [
        { name: 'test_metric', value: Infinity },
        { name: 'test_metric', value: -Infinity },
        { name: 'test_metric', value: NaN },
        { name: 'test_metric', value: 'not_a_number' }
      ];

      for (const data of invalidValues) {
        const response = await request(app)
          .post('/api/monitoring/metrics')
          .set('Authorization', `Bearer ${authToken}`)
          .send(data);

        expect(response.status).toBe(400);
      }
    });

    it('should validate alert thresholds', async () => {
      const response = await request(app)
        .post('/api/monitoring/alerts')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'Test Alert',
          condition: 'cpu_usage > 80',
          threshold: 'invalid_number',
          severity: 'high'
        });

      expect(response.status).toBe(400);
    });

    it('should validate time ranges', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics?start_time=2024-01-01&end_time=2023-01-01')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(400);
    });

    it('should validate pagination parameters', async () => {
      const response = await request(app)
        .get('/api/monitoring/errors?page=-1&limit=0')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(400);
    });

    it('should validate label formats', async () => {
      const response = await request(app)
        .post('/api/monitoring/metrics')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'test_metric',
          value: 42,
          labels: {
            'invalid-label-name': 'value',
            'valid_label': 'value'
          }
        });

      expect([200, 400]).toContain(response.status);
    });
  });

  describe('Edge Cases', () => {
    it('should handle empty data sets', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics?start_time=2099-01-01')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      expect(response.body.data).toHaveLength(0);
    });

    it('should handle maximum data limits', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics?limit=10000')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      expect(response.body.count).toBeLessThanOrEqual(10000);
    });

    it('should handle very long metric names', async () => {
      const longName = 'a'.repeat(1000);
      const response = await request(app)
        .post('/api/monitoring/metrics')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: longName,
          value: 42
        });

      expect(response.status).toBe(400);
    });

    it('should handle special characters in messages', async () => {
      const response = await request(app)
        .post('/api/monitoring/errors/log')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          level: 'error',
          message: 'Error with émojis 🎉 and spëcial çhars'
        });

      expect(response.status).toBe(200);
    });

    it('should handle concurrent updates', async () => {
      const requests = Array(10).fill(null).map(() =>
        request(app)
          .post('/api/monitoring/metrics')
          .set('Authorization', `Bearer ${authToken}`)
          .send({
            name: 'concurrent_metric',
            value: Math.random() * 100
          })
      );

      const responses = await Promise.all(requests);
      responses.forEach(response => {
        expect([200, 400, 429]).toContain(response.status);
      });
    });

    it('should handle system clock changes', async () => {
      const response = await request(app)
        .get('/api/monitoring/status');

      expect(response.status).toBe(200);
      // Should handle time-related logic gracefully
    });

    it('should handle database connection pool exhaustion', async () => {
      const requests = Array(50).fill(null).map(() =>
        request(app).get('/api/monitoring/alerts')
      );

      const responses = await Promise.all(requests);
      responses.forEach(response => {
        expect([200, 429, 500, 503]).toContain(response.status);
      });
    });

    it('should handle memory pressure', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics?large=true')
        .set('Authorization', `Bearer ${authToken}`);

      expect([200, 500]).toContain(response.status);
    });
  });

  describe('Security Tests', () => {
    it('should not expose sensitive information', async () => {
      const response = await request(app)
        .post('/api/monitoring/metrics')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'test_metric',
          value: 42,
          labels: {
            password: 'secret123',
            api_key: 'key123'
          }
        });

      expect(response.status).toBe(200);
      // Labels should be sanitized
    });

    it('should sanitize input parameters', async () => {
      const response = await request(app)
        .get('/api/monitoring/metrics?metric_name=<script>alert("xss")</script>')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
    });

    it('should validate authorization tokens', async () => {
      const response = await request(app)
        .get('/api/monitoring/alerts')
        .set('Authorization', 'Bearer invalid-token-signature');

      expect(response.status).toBe(401);
    });

    it('should handle SQL injection attempts', async () => {
      const response = await request(app)
        .get('/api/monitoring/errors?search=\'; DROP TABLE alerts; --')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
    });

    it('should validate file uploads', async () => {
      const response = await request(app)
        .post('/api/monitoring/import')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          filename: '../../../etc/passwd',
          data: 'malicious content'
        });

      expect([400, 500]).toContain(response.status);
    });
  });

  describe('Integration with External Systems', () => {
    it('should integrate with Prometheus', async () => {
      const response = await request(app)
        .get('/api/metrics');

      expect(response.status).toBe(200);
      expect(response.headers['content-type']).toContain('text/plain');
      // Should be compatible with Prometheus format
    });

    it('should support webhook notifications', async () => {
      const response = await request(app)
        .post('/api/monitoring/alerts')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'Webhook Test Alert',
          condition: 'cpu_usage > 90',
          threshold: 90,
          severity: 'high',
          notifications: {
            webhook: 'https://example.com/webhook'
          }
        });

      expect([200, 400]).toContain(response.status);
    });

    it('should handle external API timeouts', async () => {
      const response = await request(app)
        .get('/api/monitoring/status?timeout_external=true');

      expect(response.status).toBe(200);
    });

    it('should support multiple notification channels', async () => {
      const response = await request(app)
        .post('/api/monitoring/alerts')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'Multi-Channel Alert',
          condition: 'error_rate > 10%',
          threshold: 10,
          severity: 'high',
          notifications: {
            email: ['admin@example.com'],
            slack: '#alerts',
            webhook: 'https://hooks.slack.com/services/...'
          }
        });

      expect([200, 400]).toContain(response.status);
    });
  });

  describe('Monitoring Best Practices', () => {
    it('should follow SLI/SLO patterns', async () => {
      const response = await request(app)
        .get('/api/monitoring/performance/summary');

      expect(response.status).toBe(200);
      if (response.body.data.sli) {
        expect(response.body.data.sli).toHaveProperty('availability');
        expect(response.body.data.sli).toHaveProperty('latency');
      }
    });

    it('should implement golden signals monitoring', async () => {
      const response = await request(app)
        .get('/api/monitoring/health/overview');

      expect(response.status).toBe(200);
      const data = response.body.data;
      
      // Should include latency (response time)
      if (data.metrics) {
        expect(data.metrics).toHaveProperty('latency');
      }
      
      // Should include traffic (requests)
      if (data.metrics) {
        expect(data.metrics).toHaveProperty('traffic');
      }
      
      // Should include errors
      if (data.metrics) {
        expect(data.metrics).toHaveProperty('errors');
      }
      
      // Should include saturation (resource usage)
      if (data.metrics) {
        expect(data.metrics).toHaveProperty('saturation');
      }
    });

    it('should implement distributed tracing', async () => {
      const response = await request(app)
        .get('/api/monitoring/status');

      expect(response.status).toBe(200);
      if (response.body.tracing) {
        expect(response.body.tracing).toHaveProperty('trace_id');
        expect(response.body.tracing).toHaveProperty('span_id');
      }
    });

    it('should support custom dashboards', async () => {
      const response = await request(app)
        .get('/api/monitoring/dashboards');

      expect([200, 404]).toContain(response.status);
      if (response.status === 200) {
        expect(response.body).toHaveProperty('dashboards');
      }
    });

    it('should implement alerting best practices', async () => {
      const response = await request(app)
        .get('/api/monitoring/alerts')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      if (response.body.data.length > 0) {
        response.body.data.forEach(alert => {
          expect(alert).toHaveProperty('runbook_url');
          expect(alert).toHaveProperty('escalation_policy');
        });
      }
    });
  });

  describe('Monitoring Performance', () => {
    it('should measure monitoring overhead', async () => {
      const startTime = Date.now();
      const response = await request(app)
        .get('/api/monitoring/status');
      const overheadTime = Date.now() - startTime;

      expect(response.status).toBe(200);
      // Monitoring should not add significant overhead
      expect(overheadTime).toBeLessThan(1000);
    });

    it('should track monitoring accuracy', async () => {
      const response = await request(app)
        .get('/api/monitoring/health-check');

      expect(response.status).toBe(200);
      if (response.body.data.accuracy) {
        expect(response.body.data.accuracy).toBeGreaterThan(0.95); // 95% accuracy
        expect(response.body.data.accuracy).toBeLessThanOrEqual(1.0);
      }
    });

    it('should optimize query performance', async () => {
      const startTime = Date.now();
      const response = await request(app)
        .get('/api/monitoring/metrics?optimized=true')
        .set('Authorization', `Bearer ${authToken}`);
      const queryTime = Date.now() - startTime;

      expect(response.status).toBe(200);
      // Optimized queries should be fast
      expect(queryTime).toBeLessThan(2000);
    });

    it('should handle monitoring data growth', async () => {
      const response = await request(app)
        .get('/api/monitoring/export?large_dataset=true')
        .set('Authorization', `Bearer ${authToken}`);

      expect(response.status).toBe(200);
      expect(response.body.record_count).toBeGreaterThan(0);
    });
  });
});
