/**
 * Custom Test Sequencer
 * Controls the order in which tests are executed
 */

const { Sequencer, TestCollection } = require('@jest/core');

class CustomTestSequencer extends Sequencer {
  /**
   * Select the order of tests to run
   * Priority: auth tests → health tests → monitoring tests → error handling → AWS tests
   */
  sort(tests: TestCollection): TestCollection {
    const priority = [
      'auth.integration.test.ts',
      'health.integration.test.ts',
      'monitoring.integration.test.ts',
      'error-handling.integration.test.ts',
      'aws-endpoints.integration.test.ts',
    ];

    const sortedTests = tests.slice().sort((testA, testB) => {
      const pathA = testA.path || '';
      const pathB = testB.path || '';
      
      const indexA = priority.findIndex(priority => pathA.includes(priority));
      const indexB = priority.findIndex(priority => pathB.includes(priority));
      
      // If both tests are in priority list, sort by priority
      if (indexA !== -1 && indexB !== -1) {
        return indexA - indexB;
      }
      
      // If only one test is in priority list, prioritize that one
      if (indexA !== -1) return -1;
      if (indexB !== -1) return 1;
      
      // If neither test is in priority list, maintain original order
      return 0;
    });

    return sortedTests;
  }
}

module.exports = CustomTestSequencer;
