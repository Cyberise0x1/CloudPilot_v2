#!/usr/bin/env node

/**
 * Security Middleware Integration Validation Script
 * 
 * This script validates that all security middleware is properly integrated
 * and functioning correctly in the server.
 */

const fs = require('fs');
const path = require('path');

console.log('🔒 Security Middleware Integration Validation\n');

// Check if index.ts has all required imports
const indexPath = path.join(__dirname, 'server', 'index.ts');
const indexContent = fs.readFileSync(indexPath, 'utf8');

const checks = [
  {
    name: 'Security Headers Import',
    pattern: /import.*securityHeaders.*from.*middleware\/securityHeaders/,
    description: 'Security headers middleware is imported'
  },
  {
    name: 'Rate Limiter Import',
    pattern: /import.*rateLimiter.*from.*middleware\/rateLimiter/,
    description: 'Rate limiting middleware is imported'
  },
  {
    name: 'Validation Import',
    pattern: /import.*validateBody.*from.*middleware\/validation/,
    description: 'Input validation middleware is imported'
  },
  {
    name: 'SQL Protection Import',
    pattern: /import.*sqlProtection.*from.*utils\/sqlProtection/,
    description: 'SQL protection utilities are imported'
  },
  {
    name: 'Security Headers Registration',
    pattern: /app\.use\(securityHeaders\)/,
    description: 'Security headers middleware is registered'
  },
  {
    name: 'CORS Registration',
    pattern: /app\.use\(corsHandler\)/,
    description: 'CORS middleware is registered'
  },
  {
    name: 'Rate Limiter Registration',
    pattern: /app\.use\(rateLimiter\(/,
    description: 'Rate limiting middleware is registered'
  },
  {
    name: 'Input Sanitization Registration',
    pattern: /app\.use\(sanitizeAllInputs\)/,
    description: 'Input sanitization middleware is registered'
  },
  {
    name: 'Security Initialization Function',
    pattern: /async function initializeSecurityMiddleware/,
    description: 'Security middleware initialization function exists'
  },
  {
    name: 'Security Initialization Call',
    pattern: /await initializeSecurityMiddleware\(\)/,
    description: 'Security initialization is called at startup'
  },
  {
    name: 'Security Health Endpoint',
    pattern: /app\.get\('\/api\/security\/health'/,
    description: 'Security health endpoint is registered'
  },
  {
    name: 'Enhanced Monitoring Status',
    pattern: /security:/,
    description: 'Security status is included in monitoring endpoint'
  }
];

let passed = 0;
let failed = 0;

checks.forEach(check => {
  const result = check.pattern.test(indexContent);
  if (result) {
    console.log(`✅ ${check.name}`);
    console.log(`   ${check.description}`);
    passed++;
  } else {
    console.log(`❌ ${check.name}`);
    console.log(`   ${check.description}`);
    failed++;
  }
  console.log('');
});

console.log('─'.repeat(60));
console.log(`Total Checks: ${checks.length}`);
console.log(`✅ Passed: ${passed}`);
console.log(`❌ Failed: ${failed}`);
console.log('─'.repeat(60));

// Check middleware registration order
console.log('\n📋 Middleware Registration Order:\n');

const middlewareOrder = [
  'securityHeaders',
  'corsHandler',
  'rateLimiter',
  'sanitizeAllInputs',
  'securityMiddleware',
  'requestLoggingMiddleware',
  'performanceMiddleware',
  'metricsMiddleware',
  'userContextMiddleware',
  'auditMiddleware'
];

let orderIndex = {};
let lastIndex = -1;

middlewareOrder.forEach((middleware, index) => {
  const pattern = new RegExp(`app\\.use\\(${middleware}`);
  const match = indexContent.match(pattern);
  if (match) {
    const currentIndex = indexContent.indexOf(match[0]);
    orderIndex[middleware] = currentIndex;
    
    if (currentIndex >= lastIndex) {
      console.log(`✅ ${middleware}`);
      lastIndex = currentIndex;
    } else {
      console.log(`⚠️  ${middleware} (order issue)`);
    }
  }
});

console.log('\n🔍 Security Features Validation:\n');

// Check for environment-specific configurations
const envConfigs = [
  {
    name: 'Production CSP',
    pattern: /production.*csp.*enabled.*true/,
    description: 'Production CSP is enabled'
  },
  {
    name: 'Development HSTS',
    pattern: /development.*hsts.*enabled.*false/,
    description: 'Development HSTS is disabled'
  },
  {
    name: 'Rate Limit Configuration',
    pattern: /rateLimitConfig/,
    description: 'Environment-specific rate limits configured'
  },
  {
    name: 'SQL Protection Testing',
    pattern: /DROP TABLE users/,
    description: 'SQL protection is tested at startup'
  }
];

envConfigs.forEach(config => {
  const result = config.pattern.test(indexContent);
  console.log(`${result ? '✅' : '⚠️'} ${config.name}: ${config.description}`);
});

console.log('\n' + '═'.repeat(60));
console.log('SECURITY MIDDLEWARE INTEGRATION STATUS');
console.log('═'.repeat(60));

if (failed === 0) {
  console.log('✅ All validation checks passed!');
  console.log('✅ Security middleware is fully integrated');
  console.log('✅ Server is ready for secure operation');
  process.exit(0);
} else {
  console.log(`❌ ${failed} validation check(s) failed`);
  console.log('❌ Please review the integration');
  process.exit(1);
}
