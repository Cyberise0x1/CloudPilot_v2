# Audit Trail System Implementation

## Overview

This implementation provides a comprehensive audit trail system for tracking all system activities, security events, and user actions within the CloudPilot application.

## Components Created

### 1. Database Schema (`shared/schema.ts`)

Three main audit tables are defined:

#### `audit_logs`
- Tracks all user actions and system events
- Fields: id, userId, action, resourceType, resourceId, details, ipAddress, userAgent, timestamp, success, errorMessage
- Indexed for efficient querying by user, action, resource, timestamp, and success status

#### `audit_sessions`
- Tracks user login sessions
- Fields: id, userId, sessionId, ipAddress, userAgent, loginTime, lastActivity, logoutTime, isActive, metadata
- Useful for monitoring active sessions and session duration

#### `audit_events`
- Tracks detailed security and system events
- Fields: id, userId, sessionId, eventType, eventCategory, description, severity, resourceType, resourceId, oldValues, newValues, ipAddress, userAgent, timestamp, metadata
- Supports before/after values for change tracking
- Includes severity levels: info, warning, error, critical

### 2. Storage Layer (`server/storage.ts`)

Added comprehensive audit storage methods:

#### Audit Logs Methods
- `getAuditLogs(filters)` - Get filtered audit logs with pagination
- `createAuditLog(log)` - Create a new audit log entry
- `getAuditLogsByUserId(userId)` - Get logs for a specific user
- `getAuditLogsByResource(type, id)` - Get logs for a specific resource
- `getAuditLogsByDateRange(start, end)` - Get logs within a date range
- `getAuditStatistics(filters)` - Get aggregate statistics and trends

#### Audit Events Methods
- `getAuditEvents(filters)` - Get filtered audit events
- `createAuditEvent(event)` - Create a new audit event
- `getSecurityEvents(limit)` - Get security-specific events
- `updateAuditEvent()` / `deleteAuditEvent()` - Event management

#### Audit Sessions Methods
- `getAuditSessions(filters)` - Get audit sessions
- `createAuditSession(session)` - Create a new session log
- `updateAuditSession()` / `deleteAuditSession()` - Session management
- `endAuditSession(sessionId)` - End an active session

### 3. API Routes (`server/audit-routes.ts`)

Six main endpoints implemented:

#### GET `/api/audit/logs`
- **Description**: Retrieve filtered audit logs
- **Authentication**: Required (JWT token)
- **Authorization**: Admin role required
- **Query Parameters**:
  - `userId` - Filter by user ID
  - `action` - Filter by action type
  - `resourceType` - Filter by resource type
  - `resourceId` - Filter by resource ID
  - `success` - Filter by success status (true/false)
  - `startDate` / `endDate` - Date range filter
  - `limit` / `offset` - Pagination
- **Response**: Array of audit log entries

#### GET `/api/audit/user/:userId`
- **Description**: Get complete audit trail for a specific user
- **Authentication**: Required (JWT token)
- **Authorization**: Admin role required
- **Parameters**:
  - `userId` - User ID from URL path
  - `limit` - Number of records (default: 50)
  - `page` - Page number (default: 1)
- **Response**: User information + audit logs + pagination metadata

#### GET `/api/audit/resource/:type/:id`
- **Description**: Get audit trail for a specific resource
- **Authentication**: Required (JWT token)
- **Authorization**: Admin role required
- **Parameters**:
  - `type` - Resource type (e.g., "INSTANCE", "BUCKET")
  - `id` - Resource ID
  - `startDate` / `endDate` - Optional date range
  - `limit` - Maximum records (default: 100)
- **Response**: Resource info + audit logs + events

#### GET `/api/audit/security`
- **Description**: Retrieve security-related events
- **Authentication**: Required (JWT token)
- **Authorization**: Admin role required
- **Query Parameters**:
  - `severity` - Filter by severity level
  - `eventType` - Filter by event type
  - `startDate` / `endDate` - Date range
  - `limit` / `offset` - Pagination
- **Response**: Security events + failed login attempts

#### GET `/api/audit/export`
- **Description**: Export audit data in JSON or CSV format
- **Authentication**: Required (JWT token)
- **Authorization**: Admin role required
- **Query Parameters**:
  - `format` - Output format: "json" or "csv" (default: json)
  - `startDate` / `endDate` - Date range filter
  - `userId`, `action`, `resourceType` - Additional filters
- **Response**: Exported audit data as file download or JSON

#### GET `/api/audit/analytics`
- **Description**: Get audit statistics, trends, and insights
- **Authentication**: Required (JWT token)
- **Authorization**: Admin role required
- **Query Parameters**:
  - `startDate` / `endDate` - Date range for analysis
  - `userId` - Filter by specific user
- **Response**: Comprehensive analytics including:
  - Overall statistics (total, success, failed counts)
  - Breakdown by action, resource, and user
  - Security events
  - Recent activity
  - Trend analysis (period-over-period comparison)
  - Activity by hour for charting

#### Additional Management Endpoints

- **POST `/api/audit/log`** - Create manual audit log entry
- **POST `/api/audit/event`** - Create manual audit event
- **GET `/api/audit/sessions`** - Retrieve audit sessions
- **DELETE `/api/audit/log/:id`** - Delete audit log (admin only)
- **DELETE `/api/audit/event/:id`** - Delete audit event (admin only)

### 4. Database Migration (`migrations/002_create_audit_tables.sql`)

Complete SQL migration script to create all audit tables with:
- Proper indexes for performance
- Foreign key constraints
- Helper function `log_audit_action()` for programmatic logging
- Appropriate permissions

## Security Features

### Authentication & Authorization
- All audit endpoints require JWT token authentication
- Role-based access control (admin role required for most endpoints)
- IP address and user agent tracking for all actions

### Data Protection
- Sensitive data is not logged (passwords, tokens, etc.)
- Proper error handling without exposing internals
- Pagination to prevent large data exposure

### Compliance
- Comprehensive audit trail for compliance requirements
- Timestamps with timezone information
- Before/after values for change tracking
- Export capabilities for external auditing

## Usage Examples

### 1. Get Recent Audit Logs
```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.example.com/api/audit/logs?limit=50"
```

### 2. Filter by User and Date Range
```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.example.com/api/audit/logs?userId=<user-id>&startDate=2024-01-01&endDate=2024-12-31"
```

### 3. Get User Activity Summary
```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.example.com/api/audit/user/<user-id>?limit=20&page=1"
```

### 4. Check Security Events
```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.example.com/api/audit/security?severity=critical&limit=100"
```

### 5. Export Audit Data
```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.example.com/api/audit/export?format=csv&startDate=2024-01-01&endDate=2024-12-31" \
  --output audit-export.csv
```

### 6. Get Analytics Dashboard Data
```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.example.com/api/audit/analytics?startDate=2024-01-01&endDate=2024-12-31"
```

## Database Setup

1. Run the migration script:
```bash
psql -d <database> -f migrations/002_create_audit_tables.sql
```

2. Ensure the application is started with the new routes:
```bash
npm run dev
```

## Integration

The audit system is automatically registered in the main routes. No additional setup required after database migration.

### Manual Audit Logging

You can manually create audit entries from your application code:

```typescript
import { storage } from './storage';

// Log a user action
await storage.createAuditLog({
  userId: user.id,
  action: 'LAUNCH_INSTANCE',
  resourceType: 'EC2_INSTANCE',
  resourceId: 'i-1234567890abcdef0',
  details: {
    instanceType: 't2.micro',
    region: 'us-east-1'
  },
  ipAddress: '192.168.1.1',
  userAgent: 'Mozilla/5.0...',
  success: true
});

// Log a security event
await storage.createAuditEvent({
  userId: user.id,
  eventType: 'FAILED_LOGIN',
  eventCategory: 'SECURITY',
  description: 'Failed login attempt',
  severity: 'warning',
  resourceType: 'USER',
  resourceId: user.id,
  ipAddress: '192.168.1.1',
  metadata: {
    attempts: 3,
    blocked: false
  }
});
```

## Best Practices

1. **Always log sensitive operations** - Create, update, delete actions should be audited
2. **Include relevant context** - Add details JSON with relevant information
3. **Handle errors properly** - Log failed operations with error messages
4. **Regular exports** - Periodically export audit data for backup/compliance
5. **Monitor security events** - Set up alerts for critical security events
6. **Data retention** - Implement data retention policies (can be added via cron job)

## Performance Considerations

- All tables are properly indexed for common query patterns
- Use pagination for large datasets
- Filters are applied at the database level
- Statistics queries use efficient aggregations

## Future Enhancements

Potential improvements that can be added:
- Real-time audit streaming via WebSocket
- Automated data retention and archiving
- Custom alert rules for security events
- Integration with external SIEM systems
- Audit log compression and encryption at rest
- Multi-tenant audit isolation
