# CloudPilot Production Deployment

## Prerequisites
- Node.js 18+ installed
- PostgreSQL database
- npm or yarn package manager

## Deployment Steps

### 1. Environment Setup
1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```

2. Edit `.env` with your production values:
   - `DATABASE_URL`: Your PostgreSQL connection string
   - `PORT`: Application port (default: 5000)
   - `NODE_ENV`: Should be set to "production"

### 2. Install Dependencies
```bash
npm install --production
```

### 3. Database Setup
Run database migrations:
```bash
npm run db:push
```

### 4. Start the Application

#### Using npm scripts:
```bash
npm start
```

#### Using the start script directly:
```bash
node start.js
```

### 5. Optional: Process Management

For production deployments, use a process manager like PM2:

```bash
# Install PM2 globally
npm install -g pm2

# Start application with PM2
pm2 start start.js --name cloudpilot

# Save PM2 configuration
pm2 save

# Setup PM2 to start on system boot
pm2 startup
```

## Folder Structure
```
cloudpilot-production/
├── dist/               # Compiled frontend and backend
│   ├── public/        # Frontend assets
│   └── index.js       # Backend entry point
├── server/            # Server source files
├── shared/            # Shared schemas
├── package.json       # Dependencies
├── package-lock.json  # Lock file
├── drizzle.config.ts  # Database configuration
├── start.js           # Production startup script
├── .env.example       # Environment template
└── README.md          # This file
```

## Ports and Networking
- Default port: 5000
- Bind address: 0.0.0.0 (all interfaces)
- Ensure firewall allows incoming connections on the configured port

## Troubleshooting

### Database Connection Issues
- Verify DATABASE_URL is correct
- Check PostgreSQL is running and accessible
- Ensure database user has proper permissions

### Port Already in Use
- Change PORT in .env file
- Or stop the process using the port

### Module Not Found Errors
- Run `npm install` to install all dependencies
- Ensure NODE_ENV is set correctly

## Support
For issues or questions, please refer to the CloudPilot documentation.