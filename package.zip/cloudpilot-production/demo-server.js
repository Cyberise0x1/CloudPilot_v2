import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import cors from 'cors';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'dist', 'public')));

// Mock authentication endpoints
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  
  // Mock successful login
  res.json({
    success: true,
    user: {
      id: '1',
      email: email,
      name: 'Demo User',
      role: 'admin',
      avatar: null
    },
    token: 'mock-jwt-token-' + Date.now(),
    refreshToken: 'mock-refresh-token-' + Date.now()
  });
});

app.post('/api/auth/register', (req, res) => {
  const { email, password, name } = req.body;
  
  // Mock successful registration
  res.json({
    success: true,
    user: {
      id: '2',
      email: email,
      name: name || 'New User',
      role: 'user',
      avatar: null
    },
    token: 'mock-jwt-token-' + Date.now(),
    refreshToken: 'mock-refresh-token-' + Date.now()
  });
});

app.get('/api/auth/me', (req, res) => {
  res.json({
    success: true,
    user: {
      id: '1',
      email: 'demo@cloudpilot.io',
      name: 'Demo User',
      role: 'admin',
      avatar: null
    }
  });
});

// Mock AWS endpoints
app.get('/api/aws/instances', (req, res) => {
  res.json({
    success: true,
    instances: [
      {
        id: 'i-1234567890abcdef0',
        name: 'Demo Web Server',
        type: 't3.medium',
        state: 'running',
        region: 'us-east-1',
        ip: '54.123.45.67',
        launched: '2024-01-15T10:30:00Z'
      },
      {
        id: 'i-0987654321fedcba0',
        name: 'Demo Database',
        type: 't3.large',
        state: 'running',
        region: 'us-east-1',
        ip: '54.234.56.78',
        launched: '2024-01-10T14:20:00Z'
      }
    ]
  });
});

app.get('/api/aws/buckets', (req, res) => {
  res.json({
    success: true,
    buckets: [
      {
        name: 'demo-cloudpilot-assets',
        region: 'us-east-1',
        created: '2024-01-01T00:00:00Z',
        size: '1.2 GB',
        objects: 156
      },
      {
        name: 'demo-user-uploads',
        region: 'us-west-2',
        created: '2024-01-05T12:00:00Z',
        size: '543 MB',
        objects: 23
      }
    ]
  });
});

// Mock monitoring endpoints
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    services: {
      database: 'healthy',
      aws: 'healthy',
      auth: 'healthy',
      monitoring: 'healthy'
    },
    uptime: '99.9%',
    responseTime: '45ms'
  });
});

app.get('/api/metrics', (req, res) => {
  res.json({
    success: true,
    metrics: {
      cpu: 35.2,
      memory: 62.8,
      disk: 23.1,
      networkIn: '12.3 MB/s',
      networkOut: '8.7 MB/s',
      activeUsers: 42,
      requestsPerMinute: 156,
      errorRate: 0.2
    }
  });
});

app.get('/api/audit', (req, res) => {
  res.json({
    success: true,
    events: [
      {
        id: '1',
        user: 'demo@cloudpilot.io',
        action: 'login',
        resource: 'authentication',
        timestamp: '2025-10-31T16:30:00Z',
        status: 'success',
        ip: '192.168.1.100'
      },
      {
        id: '2',
        user: 'demo@cloudpilot.io',
        action: 'view_instances',
        resource: 'aws.ec2',
        timestamp: '2025-10-31T16:25:00Z',
        status: 'success',
        ip: '192.168.1.100'
      },
      {
        id: '3',
        user: 'demo@cloudpilot.io',
        action: 'create_bucket',
        resource: 'aws.s3',
        timestamp: '2025-10-31T16:20:00Z',
        status: 'success',
        ip: '192.168.1.100'
      }
    ]
  });
});

// Serve the frontend for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`🚀 CloudPilot Demo Server running on http://localhost:${PORT}`);
  console.log(`📊 Mock data enabled for testing`);
  console.log(`🔐 Login with any email/password to test authentication`);
});