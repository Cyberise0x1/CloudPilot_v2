#!/usr/bin/env node

/**
 * CloudPilot Production Startup Script
 * This script starts the CloudPilot application in production mode
 */

import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Ensure we're in production mode
process.env.NODE_ENV = 'production';

// Start the server
const serverPath = join(__dirname, 'dist', 'index.js');

console.log('🚀 Starting CloudPilot in production mode...');
console.log(`📁 Server path: ${serverPath}`);
console.log(`🌐 Port: ${process.env.PORT || 5000}`);
console.log(`🔧 Environment: ${process.env.NODE_ENV}`);

const server = spawn('node', [serverPath], {
  stdio: 'inherit',
  env: process.env
});

server.on('error', (err) => {
  console.error('❌ Failed to start server:', err);
  process.exit(1);
});

server.on('exit', (code) => {
  if (code !== 0) {
    console.error(`❌ Server exited with code ${code}`);
    process.exit(code);
  }
});

// Handle graceful shutdown
process.on('SIGINT', () => {
  console.log('\n🛑 Shutting down CloudPilot...');
  server.kill('SIGINT');
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\n🛑 Shutting down CloudPilot...');
  server.kill('SIGTERM');
  process.exit(0);
});