/**
 * Environment Variable Validation Module
 * 
 * This module provides comprehensive validation for all environment variables
 * used in the CloudPilot application. It includes:
 * - Type checking and format validation
 * - Required vs optional variables
 * - Startup validation that fails fast if missing critical variables
 * - Detailed error messages with setup instructions
 */

// Type definitions for environment variables
export interface DatabaseConfig {
  url: string;
  host?: string;
  port?: number;
  database?: string;
  username?: string;
  password?: string;
  ssl?: boolean;
}

export interface JWTConfig {
  secret: string;
  expiresIn: string;
  refreshExpiresIn: string;
  accessTokenSecret?: string;
  refreshTokenSecret?: string;
  refreshExpiration?: string;
}

export interface AWSConfig {
  accessKeyId?: string;
  secretAccessKey?: string;
  defaultRegion?: string;
}

export interface ServerConfig {
  port: number;
  nodeEnv: 'development' | 'production' | 'test';
}

export interface AuthConfig {
  rateLimitWindow: number;
  rateLimitMax: number;
  apiKey?: string;
}

export interface BackupConfig {
  enabled: boolean;
  monitoringEnabled: boolean;
  alertingEnabled: boolean;
  schedulerEnabled: boolean;
  recoveryEnabled: boolean;
  scheduleBackupScheduler: boolean;
  emailAlerts: boolean;
  slackAlerts: boolean;
  monitoringInterval: number;
  healthCheckInterval: number;
}

export interface ResilienceConfig {
  circuitBreakerEnabled: boolean;
  errorRecoveryEnabled: boolean;
  chaosEngineeringEnabled: boolean;
  testingEnabled: boolean;
  circuitBreakerFailureThreshold: number;
  circuitBreakerResetTimeout: number;
  retryMaxAttempts: number;
  retryBaseDelay: number;
  fallbackEnabled: boolean;
  healthCheckInterval: number;
  monitoringEnabled: boolean;
  alertingEnabled: boolean;
}

export interface EnvConfig {
  database: DatabaseConfig;
  jwt: JWTConfig;
  aws: AWSConfig;
  server: ServerConfig;
  auth: AuthConfig;
  backup: BackupConfig;
  resilience: ResilienceConfig;
}

// Validation error class
export class EnvValidationError extends Error {
  constructor(message: string, public variable: string) {
    super(message);
    this.name = 'EnvValidationError';
  }
}

// Base validation functions
export const isString = (value: unknown): value is string => {
  return typeof value === 'string';
};

export const isNumber = (value: unknown): value is number => {
  return typeof value === 'number' && !isNaN(value);
};

export const isBoolean = (value: unknown): value is boolean => {
  return typeof value === 'boolean';
};

export const isNonEmptyString = (value: unknown): value is string => {
  return isString(value) && value.trim().length > 0;
};

export const isValidPort = (value: unknown): value is number => {
  if (!isNumber(value)) return false;
  return value >= 1 && value <= 65535;
};

export const isValidURL = (value: string): boolean => {
  try {
    new URL(value);
    return true;
  } catch {
    return false;
  }
};

export const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

export const isStrongPassword = (password: string): boolean => {
  // At least 8 characters, 1 uppercase, 1 lowercase, 1 number, 1 special character
  const strongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  return strongPasswordRegex.test(password);
};

export const isValidDuration = (duration: string): boolean => {
  const durationRegex = /^\d+(ms|s|m|h|d|w)$/;
  return durationRegex.test(duration);
};

export const isValidAWSRegion = (region: string): boolean => {
  const validRegions = [
    'us-east-1', 'us-east-2', 'us-west-1', 'us-west-2',
    'ca-central-1', 'eu-central-1', 'eu-west-1', 'eu-west-2', 'eu-west-3',
    'eu-north-1', 'ap-east-1', 'ap-south-1', 'ap-northeast-1', 'ap-northeast-2',
    'ap-northeast-3', 'ap-southeast-1', 'ap-southeast-2', 'ap-southeast-3',
    'eu-central-2', 'eu-south-1', 'eu-south-2', 'me-south-1', 'me-central-1',
    'il-central-1', 'sa-east-1'
  ];
  return validRegions.includes(region);
};

export const isValidRedisUrl = (url: string): boolean => {
  const redisRegex = /^redis:\/\/[^:]+:[^@]+@[^:]+:\d+$/;
  return redisRegex.test(url);
};

// Specific validator functions
export const validateDatabaseUrl = (url: string): DatabaseConfig => {
  if (!isNonEmptyString(url)) {
    throw new EnvValidationError(
      'DATABASE_URL must be a non-empty string',
      'DATABASE_URL'
    );
  }

  if (!isValidURL(url)) {
    throw new EnvValidationError(
      'DATABASE_URL must be a valid URL',
      'DATABASE_URL'
    );
  }

  // Parse URL components
  let parsedUrl: URL;
  try {
    parsedUrl = new URL(url);
  } catch {
    throw new EnvValidationError(
      'DATABASE_URL must be a valid URL format (e.g., postgresql://user:pass@host:port/db)',
      'DATABASE_URL'
    );
  }

  // Validate protocol
  if (!['postgresql:', 'postgres:'].includes(parsedUrl.protocol)) {
    throw new EnvValidationError(
      'DATABASE_URL must use postgresql:// or postgres:// protocol',
      'DATABASE_URL'
    );
  }

  return {
    url,
    host: parsedUrl.hostname,
    port: parsedUrl.port ? parseInt(parsedUrl.port) : 5432,
    database: parsedUrl.pathname.slice(1), // Remove leading slash
    username: parsedUrl.username,
    password: parsedUrl.password,
    ssl: parsedUrl.searchParams.get('ssl') === 'true' || 
         parsedUrl.hostname.endsWith('.neon.tech') || 
         parsedUrl.hostname.includes('supabase')
  };
};

export const validateJWTSecret = (secret: string): void => {
  if (!isNonEmptyString(secret)) {
    throw new EnvValidationError(
      'JWT_SECRET must be a non-empty string',
      'JWT_SECRET'
    );
  }

  if (secret.length < 32) {
    throw new EnvValidationError(
      'JWT_SECRET must be at least 32 characters long for security',
      'JWT_SECRET'
    );
  }

  if (secret === 'your-secret-key-change-in-production') {
    throw new EnvValidationError(
      'JWT_SECRET cannot be the default development value. Please set a secure secret.',
      'JWT_SECRET'
    );
  }
};

export const validateJWTDuration = (duration: string, defaultValue: string, envVar: string): string => {
  if (!isNonEmptyString(duration)) {
    return defaultValue;
  }

  if (!isValidDuration(duration)) {
    throw new EnvValidationError(
      `${envVar} must be a valid duration (e.g., "24h", "7d", "30m")`,
      envVar
    );
  }

  return duration;
};

export const validatePort = (port: string | number, defaultPort: number = 5000): number => {
  const portNum = typeof port === 'string' ? parseInt(port) : port;

  if (isNaN(portNum)) {
    throw new EnvValidationError(
      `PORT must be a valid number, got: ${port}`,
      'PORT'
    );
  }

  if (!isValidPort(portNum)) {
    throw new EnvValidationError(
      'PORT must be between 1 and 65535',
      'PORT'
    );
  }

  return portNum;
};

export const validateNodeEnv = (env: string | undefined): 'development' | 'production' | 'test' => {
  const validEnvs = ['development', 'production', 'test'];
  
  if (!env || !validEnvs.includes(env)) {
    return 'development';
  }

  return env as 'development' | 'production' | 'test';
};

export const validateAWSRegion = (region: string | undefined): string | undefined => {
  if (!region) {
    return undefined;
  }

  if (!isValidAWSRegion(region)) {
    throw new EnvValidationError(
      `AWS_DEFAULT_REGION must be a valid AWS region, got: ${region}`,
      'AWS_DEFAULT_REGION'
    );
  }

  return region;
};

export const validateRateLimitWindow = (window: string | number): number => {
  const windowNum = typeof window === 'string' ? parseInt(window) : window;

  if (isNaN(windowNum) || windowNum <= 0) {
    throw new EnvValidationError(
      `AUTH_RATE_LIMIT_WINDOW must be a positive number (milliseconds), got: ${window}`,
      'AUTH_RATE_LIMIT_WINDOW'
    );
  }

  return windowNum;
};

export const validateRateLimitMax = (max: string | number): number => {
  const maxNum = typeof max === 'string' ? parseInt(max) : max;

  if (isNaN(maxNum) || maxNum <= 0) {
    throw new EnvValidationError(
      `AUTH_RATE_LIMIT_MAX must be a positive number, got: ${max}`,
      'AUTH_RATE_LIMIT_MAX'
    );
  }

  return maxNum;
};

export const validatePositiveInteger = (
  value: string | number, 
  variableName: string,
  min: number = 1,
  max?: number
): number => {
  const num = typeof value === 'string' ? parseInt(value, 10) : value;

  if (!isNumber(num)) {
    throw new EnvValidationError(
      `${variableName} must be a valid number`,
      variableName
    );
  }

  if (num < min) {
    throw new EnvValidationError(
      `${variableName} must be at least ${min}`,
      variableName
    );
  }

  if (max !== undefined && num > max) {
    throw new EnvValidationError(
      `${variableName} must be at most ${max}`,
      variableName
    );
  }

  return num;
};

// Main configuration validators
export const validateDatabaseConfig = (): DatabaseConfig => {
  const databaseUrl = process.env.DATABASE_URL;

  if (!databaseUrl) {
    throw new EnvValidationError(
      'DATABASE_URL is required. Set it in your .env file or environment variables.\n\n' +
      'Setup Instructions:\n' +
      '1. Create a PostgreSQL database (e.g., Neon, Supabase, Railway, or local PostgreSQL)\n' +
      '2. Get the connection string in format: postgresql://user:password@host:port/database\n' +
      '3. Add to .env: DATABASE_URL="your-connection-string"\n' +
      '4. For Neon/Supabase, use the provided connection string',
      'DATABASE_URL'
    );
  }

  return validateDatabaseUrl(databaseUrl);
};

export const validateJWTConfig = (): JWTConfig => {
  const jwtSecret = process.env.JWT_SECRET;

  if (!jwtSecret) {
    throw new EnvValidationError(
      'JWT_SECRET is required. Set it in your .env file or environment variables.\n\n' +
      'Setup Instructions:\n' +
      '1. Generate a secure random string (32+ characters)\n' +
      '2. Example: node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'hex\'))"\n' +
      '3. Add to .env: JWT_SECRET="your-secure-secret"\n' +
      '4. Never commit this to version control',
      'JWT_SECRET'
    );
  }

  validateJWTSecret(jwtSecret);

  const expiresIn = validateJWTDuration(
    process.env.JWT_EXPIRES_IN,
    '24h',
    'JWT_EXPIRES_IN'
  );

  const refreshExpiresIn = validateJWTDuration(
    process.env.JWT_REFRESH_EXPIRES_IN,
    '7d',
    'JWT_REFRESH_EXPIRES_IN'
  );

  return {
    secret: jwtSecret,
    expiresIn,
    refreshExpiresIn,
    accessTokenSecret: process.env.JWT_ACCESS_TOKEN_SECRET,
    refreshTokenSecret: process.env.JWT_REFRESH_TOKEN_SECRET,
    refreshExpiration: process.env.JWT_REFRESH_EXPIRATION || refreshExpiresIn
  };
};

export const validateAWSConfig = (): AWSConfig => {
  const accessKeyId = process.env.AWS_ACCESS_KEY_ID;
  const secretAccessKey = process.env.AWS_SECRET_ACCESS_KEY;
  const defaultRegion = validateAWSRegion(process.env.AWS_DEFAULT_REGION);

  // AWS credentials are optional but recommended for cloud operations
  if (accessKeyId && !secretAccessKey) {
    throw new EnvValidationError(
      'AWS_SECRET_ACCESS_KEY must be provided when AWS_ACCESS_KEY_ID is set',
      'AWS_SECRET_ACCESS_KEY'
    );
  }

  if (secretAccessKey && !accessKeyId) {
    throw new EnvValidationError(
      'AWS_ACCESS_KEY_ID must be provided when AWS_SECRET_ACCESS_KEY is set',
      'AWS_ACCESS_KEY_ID'
    );
  }

  if (accessKeyId && secretAccessKey) {
    // Validate AWS credentials format
    if (!isNonEmptyString(accessKeyId) || accessKeyId.length < 16) {
      throw new EnvValidationError(
        'AWS_ACCESS_KEY_ID must be a valid AWS access key ID',
        'AWS_ACCESS_KEY_ID'
      );
    }

    if (!isNonEmptyString(secretAccessKey) || secretAccessKey.length < 16) {
      throw new EnvValidationError(
        'AWS_SECRET_ACCESS_KEY must be a valid AWS secret access key',
        'AWS_SECRET_ACCESS_KEY'
      );
    }
  }

  return {
    accessKeyId,
    secretAccessKey,
    defaultRegion: defaultRegion || 'us-east-1'
  };
};

export const validateServerConfig = (): ServerConfig => {
  const port = validatePort(process.env.PORT, 5000);
  const nodeEnv = validateNodeEnv(process.env.NODE_ENV);

  return {
    port,
    nodeEnv
  };
};

export const validateAuthConfig = (): AuthConfig => {
  const rateLimitWindow = validateRateLimitWindow(
    process.env.AUTH_RATE_LIMIT_WINDOW || '900000' // 15 minutes
  );

  const rateLimitMax = validateRateLimitMax(
    process.env.AUTH_RATE_LIMIT_MAX || '5'
  );

  const apiKey = process.env.API_KEY; // Optional

  if (apiKey && !isNonEmptyString(apiKey)) {
    throw new EnvValidationError(
      'API_KEY must be a non-empty string if provided',
      'API_KEY'
    );
  }

  return {
    rateLimitWindow,
    rateLimitMax,
    apiKey
  };
};

export const validateBackupConfig = (): BackupConfig => {
  // Backup system is optional but can be enabled via environment variables
  
  const enabled = process.env.ENABLE_BACKUP_SYSTEM !== 'false'; // Default enabled
  
  const monitoringEnabled = process.env.ENABLE_BACKUP_MONITORING !== 'false'; // Default enabled
  
  const alertingEnabled = process.env.ENABLE_BACKUP_ALERTING === 'true'; // Default disabled
  
  const schedulerEnabled = process.env.ENABLE_BACKUP_SCHEDULER !== 'false'; // Default enabled
  
  const recoveryEnabled = process.env.ENABLE_BACKUP_RECOVERY !== 'false'; // Default enabled
  
  const scheduleBackupScheduler = process.env.START_BACKUP_SCHEDULER === 'true'; // Default not started
  
  const emailAlerts = process.env.ENABLE_EMAIL_ALERTS === 'true'; // Default disabled
  
  const slackAlerts = process.env.ENABLE_SLACK_ALERTS === 'true'; // Default disabled
  
  const monitoringInterval = validatePositiveInteger(
    process.env.BACKUP_MONITORING_INTERVAL || '300', // 5 minutes default
    'BACKUP_MONITORING_INTERVAL'
  );
  
  const healthCheckInterval = validatePositiveInteger(
    process.env.BACKUP_HEALTH_CHECK_INTERVAL || '900', // 15 minutes default
    'BACKUP_HEALTH_CHECK_INTERVAL'
  );
  
  // Log configuration status
  if (enabled) {
    console.log('✅ Backup system is enabled');
    
    if (monitoringEnabled) {
      console.log('✅ Backup monitoring is enabled');
    }
    
    if (alertingEnabled) {
      console.log('✅ Backup alerting is enabled');
    }
    
    if (schedulerEnabled) {
      console.log('✅ Backup scheduler is enabled');
    }
    
    if (recoveryEnabled) {
      console.log('✅ Backup recovery is enabled');
    }
    
    if (emailAlerts || slackAlerts) {
      console.log('✅ Backup notifications are enabled');
    }
    
    // Validate notification configuration if enabled
    if (emailAlerts) {
      if (!process.env.SMTP_HOST || !process.env.TO_EMAILS) {
        console.warn('⚠️  Email alerts enabled but SMTP configuration incomplete');
      }
    }
    
    if (slackAlerts) {
      if (!process.env.SLACK_WEBHOOK_URL) {
        console.warn('⚠️  Slack alerts enabled but webhook URL not configured');
      }
    }
  } else {
    console.log('ℹ️  Backup system is disabled');
  }
  
  return {
    enabled,
    monitoringEnabled,
    alertingEnabled,
    schedulerEnabled,
    recoveryEnabled,
    scheduleBackupScheduler,
    emailAlerts,
    slackAlerts,
    monitoringInterval,
    healthCheckInterval
  };
};

export const validateResilienceConfig = (): ResilienceConfig => {
  console.log('🔄 Validating resilience configuration...');
  
  // Circuit breaker system
  const circuitBreakerEnabled = process.env.ENABLE_CIRCUIT_BREAKER !== 'false'; // Default enabled
  console.log(`✅ Circuit breaker system: ${circuitBreakerEnabled ? 'enabled' : 'disabled'}`);
  
  // Error recovery system
  const errorRecoveryEnabled = process.env.ENABLE_ERROR_RECOVERY !== 'false'; // Default enabled
  console.log(`✅ Error recovery system: ${errorRecoveryEnabled ? 'enabled' : 'disabled'}`);
  
  // Chaos engineering (only enabled in non-production by default)
  const chaosEngineeringEnabled = process.env.ENABLE_CHAOS_ENGINEERING === 'true' || 
                                  (process.env.NODE_ENV !== 'production' && process.env.ENABLE_CHAOS_ENGINEERING !== 'false');
  console.log(`✅ Chaos engineering: ${chaosEngineeringEnabled ? 'enabled' : 'disabled'}`);
  
  // Testing system
  const testingEnabled = process.env.ENABLE_RESILIENCE_TESTING !== 'false'; // Default enabled
  console.log(`✅ Resilience testing: ${testingEnabled ? 'enabled' : 'disabled'}`);
  
  // Circuit breaker specific settings
  const circuitBreakerFailureThreshold = validatePositiveInteger(
    process.env.CIRCUIT_BREAKER_FAILURE_THRESHOLD || '5',
    'CIRCUIT_BREAKER_FAILURE_THRESHOLD',
    1,
    100
  );
  console.log(`✅ Circuit breaker failure threshold: ${circuitBreakerFailureThreshold}`);
  
  const circuitBreakerResetTimeout = validatePositiveInteger(
    process.env.CIRCUIT_BREAKER_RESET_TIMEOUT || '60000', // 60 seconds
    'CIRCUIT_BREAKER_RESET_TIMEOUT',
    1000,
    600000
  );
  console.log(`✅ Circuit breaker reset timeout: ${circuitBreakerResetTimeout}ms`);
  
  // Retry policy settings
  const retryMaxAttempts = validatePositiveInteger(
    process.env.RETRY_MAX_ATTEMPTS || '3',
    'RETRY_MAX_ATTEMPTS',
    1,
    10
  );
  console.log(`✅ Retry max attempts: ${retryMaxAttempts}`);
  
  const retryBaseDelay = validatePositiveInteger(
    process.env.RETRY_BASE_DELAY || '1000', // 1 second
    'RETRY_BASE_DELAY',
    100,
    30000
  );
  console.log(`✅ Retry base delay: ${retryBaseDelay}ms`);
  
  // Fallback system
  const fallbackEnabled = process.env.ENABLE_FALLBACK !== 'false'; // Default enabled
  console.log(`✅ Fallback system: ${fallbackEnabled ? 'enabled' : 'disabled'}`);
  
  // Health check settings
  const healthCheckInterval = validatePositiveInteger(
    process.env.RESILIENCE_HEALTH_CHECK_INTERVAL || '30000', // 30 seconds
    'RESILIENCE_HEALTH_CHECK_INTERVAL',
    5000,
    300000
  );
  console.log(`✅ Resilience health check interval: ${healthCheckInterval}ms`);
  
  // Monitoring and alerting
  const monitoringEnabled = process.env.ENABLE_RESILIENCE_MONITORING !== 'false'; // Default enabled
  console.log(`✅ Resilience monitoring: ${monitoringEnabled ? 'enabled' : 'disabled'}`);
  
  const alertingEnabled = process.env.ENABLE_RESILIENCE_ALERTING === 'true'; // Default disabled
  console.log(`✅ Resilience alerting: ${alertingEnabled ? 'enabled' : 'disabled'}`);
  
  // Validate alerting configuration if enabled
  if (alertingEnabled && !monitoringEnabled) {
    console.warn('⚠️  Resilience alerting enabled but monitoring is disabled - enabling monitoring');
  }
  
  return {
    circuitBreakerEnabled,
    errorRecoveryEnabled,
    chaosEngineeringEnabled,
    testingEnabled,
    circuitBreakerFailureThreshold,
    circuitBreakerResetTimeout,
    retryMaxAttempts,
    retryBaseDelay,
    fallbackEnabled,
    healthCheckInterval,
    monitoringEnabled,
    alertingEnabled
  };
};

// Combined configuration validation
export const validateConfig = (): EnvConfig => {
  console.log('🔍 Validating environment configuration...');

  const startTime = Date.now();

  try {
    const database = validateDatabaseConfig();
    console.log('✅ Database configuration validated');

    const jwt = validateJWTConfig();
    console.log('✅ JWT configuration validated');

    const aws = validateAWSConfig();
    console.log('✅ AWS configuration validated');

    const server = validateServerConfig();
    console.log('✅ Server configuration validated');

    const auth = validateAuthConfig();
    console.log('✅ Auth configuration validated');

    const backup = validateBackupConfig();
    console.log('✅ Backup configuration validated');
    
    const resilience = validateResilienceConfig();
    console.log('✅ Resilience configuration validated');

    const validationTime = Date.now() - startTime;
    console.log(`✅ Environment validation completed in ${validationTime}ms`);

    return {
      database,
      jwt,
      aws,
      server,
      auth,
      backup,
      resilience
    };
  } catch (error) {
    if (error instanceof EnvValidationError) {
      console.error('\n❌ Environment Validation Failed');
      console.error(`Variable: ${error.variable}`);
      console.error(`Error: ${error.message}\n`);
      
      // Print helpful setup information
      if (error.variable === 'DATABASE_URL') {
        console.error('📚 Database Setup Guide:');
        console.error('  - Neon: https://neon.tech');
        console.error('  - Supabase: https://supabase.com');
        console.error('  - Railway: https://railway.app');
        console.error('  - PlanetScale: https://planetscale.com');
      } else if (error.variable === 'JWT_SECRET') {
        console.error('🔐 JWT Secret Generation:');
        console.error('  - Node.js: node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'hex\'))"');
        console.error('  - Online: https://generate-secret.vercel.app/32');
        console.error('  - OpenSSL: openssl rand -hex 32');
      }
      
      console.error('\n💡 Quick Start:');
      console.error('1. Create a .env file in your project root');
      console.error('2. Add the required environment variables');
      console.error('3. Restart your application\n');
    } else {
      console.error('❌ Unexpected validation error:', error);
    }

    process.exit(1);
    throw error;
  }
};

// Utility functions for development and debugging
export const printConfigSummary = (config: EnvConfig): void => {
  console.log('\n📋 Environment Configuration Summary:');
  console.log('='.repeat(50));

  // Database (mask password)
  const dbUrl = config.database.url;
  const maskedUrl = dbUrl.replace(/:([^:@]+)@/, ':****@');
  console.log(`Database: ${maskedUrl}`);
  console.log(`  - Host: ${config.database.host}`);
  console.log(`  - Port: ${config.database.port}`);
  console.log(`  - SSL: ${config.database.ssl ? 'Enabled' : 'Disabled'}`);

  // JWT (mask secret)
  const maskedSecret = config.jwt.secret.substring(0, 8) + '****' + 
                      config.jwt.secret.substring(config.jwt.secret.length - 4);
  console.log(`JWT: ${maskedSecret}`);
  console.log(`  - Access Token Expires: ${config.jwt.expiresIn}`);
  console.log(`  - Refresh Token Expires: ${config.jwt.refreshExpiresIn}`);

  // AWS (mask credentials)
  console.log(`AWS:`);
  console.log(`  - Region: ${config.aws.defaultRegion}`);
  console.log(`  - Access Key: ${config.aws.accessKeyId ? 
    config.aws.accessKeyId.substring(0, 4) + '****' : 'Not configured'}`);

  // Server
  console.log(`Server:`);
  console.log(`  - Port: ${config.server.port}`);
  console.log(`  - Environment: ${config.server.nodeEnv}`);

  // Auth
  console.log(`Auth:`);
  console.log(`  - Rate Limit Window: ${config.auth.rateLimitWindow}ms`);
  console.log(`  - Rate Limit Max: ${config.auth.rateLimitMax} attempts`);
  console.log(`  - API Key: ${config.auth.apiKey ? 'Configured' : 'Not configured'}`);

  // Backup
  console.log(`Backup:`);
  console.log(`  - System Enabled: ${config.backup.enabled ? 'Yes' : 'No'}`);
  console.log(`  - Monitoring: ${config.backup.monitoringEnabled ? 'Enabled' : 'Disabled'}`);
  console.log(`  - Alerting: ${config.backup.alertingEnabled ? 'Enabled' : 'Disabled'}`);
  console.log(`  - Scheduler: ${config.backup.schedulerEnabled ? 'Enabled' : 'Disabled'}`);
  console.log(`  - Recovery: ${config.backup.recoveryEnabled ? 'Enabled' : 'Disabled'}`);
  console.log(`  - Email Alerts: ${config.backup.emailAlerts ? 'Enabled' : 'Disabled'}`);
  console.log(`  - Slack Alerts: ${config.backup.slackAlerts ? 'Enabled' : 'Disabled'}`);
  console.log(`  - Monitoring Interval: ${config.backup.monitoringInterval}s`);
  console.log(`  - Health Check Interval: ${config.backup.healthCheckInterval}s`);

  console.log('='.repeat(50));
};

export const validateConfigForEnvironment = (environment: 'development' | 'production' | 'test'): EnvConfig => {
  const config = validateConfig();

  // Additional environment-specific validations
  if (environment === 'production') {
    // Production-specific checks
    if (!config.jwt.secret || config.jwt.secret.length < 32) {
      throw new EnvValidationError(
        'Production requires a JWT_SECRET of at least 32 characters',
        'JWT_SECRET'
      );
    }

    if (config.server.port !== 5000) {
      console.warn('⚠️  Production server not running on port 5000');
    }

    if (config.aws.accessKeyId && config.server.nodeEnv === 'production') {
      console.log('✅ AWS credentials configured for production');
    }
  } else if (environment === 'development') {
    // Development-specific checks
    if (config.server.nodeEnv !== 'development') {
      console.warn('⚠️  Development environment detected but NODE_ENV is not "development"');
    }
  }

  return config;
};

// Export all validation functions for external use
export const validators = {
  // Base validators
  isString,
  isNumber,
  isBoolean,
  isNonEmptyString,
  isValidPort,
  isValidURL,
  isValidEmail,
  isStrongPassword,
  isValidDuration,
  isValidAWSRegion,
  isValidRedisUrl,

  // Specific validators
  validateDatabaseUrl,
  validateJWTSecret,
  validateJWTDuration,
  validatePort,
  validateNodeEnv,
  validateAWSRegion,
  validateRateLimitWindow,
  validateRateLimitMax,
  validatePositiveInteger,

  // Configuration validators
  validateDatabaseConfig,
  validateJWTConfig,
  validateAWSConfig,
  validateServerConfig,
  validateAuthConfig,
  validateBackupConfig,
  validateResilienceConfig,
  validateConfig,
  validateConfigForEnvironment,

  // Utility functions
  printConfigSummary
};

export default validators;
