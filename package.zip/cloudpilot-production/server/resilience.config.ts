/**
 * Comprehensive Resilience and Error Recovery Configuration
 * Manages circuit breaker settings, retry policies, timeout configurations, fallback strategies,
 * error thresholds, monitoring settings, health check configuration, and resilience testing
 */

import { EventEmitter } from 'events';

// Resilience Configuration Types
export interface ResilienceConfig {
  // Circuit Breaker Configuration
  circuitBreaker: CircuitBreakerConfig;
  
  // Retry Policy Configuration
  retry: RetryConfig;
  
  // Timeout Configuration
  timeout: TimeoutConfig;
  
  // Fallback Strategies
  fallback: FallbackConfig;
  
  // Error Thresholds and Limits
  errorThresholds: ErrorThresholdConfig;
  
  // Monitoring and Metrics
  monitoring: ResilienceMonitoringConfig;
  
  // Health Check Configuration
  healthCheck: HealthCheckConfig;
  
  // Resilience Testing Settings
  testing: ResilienceTestingConfig;
  
  // Environment-specific Overrides
  environments: EnvironmentOverrides;
}

export interface CircuitBreakerConfig {
  enabled: boolean;
  failureThreshold: number; // Number of failures to open circuit
  successThreshold: number; // Number of successes to close circuit
  timeout: number; // Time in milliseconds before attempting to close
  resetTimeout: number; // Time to wait before trying to close circuit
  monitoringPeriod: number; // Time window for monitoring failures
  halfOpenMaxCalls: number; // Max calls allowed in half-open state
  errorTypes: string[]; // Error types that trigger circuit breaker
  excludeErrors: string[]; // Error types to exclude from circuit breaking
}

export interface RetryConfig {
  enabled: boolean;
  maxAttempts: number;
  baseDelay: number; // Base delay in milliseconds
  maxDelay: number; // Maximum delay between retries
  backoffMultiplier: number; // Exponential backoff multiplier
  jitterEnabled: boolean; // Add random jitter to delays
  jitterFactor: number; // Jitter strength (0-1)
  retryableErrors: string[]; // Error types that should be retried
  nonRetryableErrors: string[]; // Error types that should not be retried
  exponentialBackoff: boolean;
  maxRetryTime: number; // Maximum total time spent retrying
}

export interface TimeoutConfig {
  defaultTimeout: number; // Default timeout in milliseconds
  operationTimeouts: Record<string, number>; // Custom timeouts per operation type
  connectionTimeout: number; // Connection timeout
  readTimeout: number; // Read timeout
  writeTimeout: number; // Write timeout
  enableTimeouts: boolean;
  timeoutStrategy: 'fail-fast' | 'warn' | 'log';
  timeoutCallbacks: TimeoutCallback[];
}

export interface FallbackConfig {
  enabled: boolean;
  strategies: Record<string, FallbackStrategy>;
  defaultFallback: FallbackStrategy;
  cacheEnabled: boolean;
  cacheTimeout: number; // Cache fallback responses
  cacheInvalidation: CacheInvalidationConfig;
  fallbackOrder: string[]; // Order of fallback strategies to try
}

export interface FallbackStrategy {
  name: string;
  type: 'static-response' | 'cached-response' | 'alternative-service' | 'circuit-breaker' | 'custom';
  config: StaticResponseFallback | CachedResponseFallback | AlternativeServiceFallback | CircuitBreakerFallback | CustomFallback;
  priority: number;
  enabled: boolean;
  conditions: FallbackCondition[];
}

export interface StaticResponseFallback {
  response: {
    statusCode: number;
    headers: Record<string, string>;
    body: any;
  };
  delay: number; // Delay before returning fallback response
}

export interface CachedResponseFallback {
  cacheKey: string;
  maxAge: number; // Maximum age of cached response
  staleWhileRevalidate: boolean;
}

export interface AlternativeServiceFallback {
  serviceUrl: string;
  timeout: number;
  headers: Record<string, string>;
  weighted: boolean; // Use weighted routing
}

export interface CircuitBreakerFallback {
  threshold: number;
  timeout: number;
  fallbackOnOpen: boolean;
}

export interface CustomFallback {
  handler: string; // Function name or module path
  params: Record<string, any>;
}

export interface FallbackCondition {
  type: 'error-type' | 'response-code' | 'timeout' | 'custom';
  condition: string | number | ((data: any) => boolean);
  enabled: boolean;
}

export interface ErrorThresholdConfig {
  enabled: boolean;
  errorRateThreshold: number; // Error rate percentage (0-100)
  responseTimeThreshold: number; // Response time in milliseconds
  concurrentRequestsThreshold: number; // Max concurrent requests
  queueDepthThreshold: number; // Max queue depth
  memoryUsageThreshold: number; // Memory usage percentage
  cpuUsageThreshold: number; // CPU usage percentage
  failureStreakThreshold: number; // Max consecutive failures
  slidingWindowSize: number; // Size of sliding window for calculations
  alertThresholds: AlertThreshold[];
  escalationPolicies: EscalationPolicy[];
}

export interface AlertThreshold {
  metric: string;
  threshold: number;
  duration: number; // How long threshold must be exceeded
  severity: 'low' | 'medium' | 'high' | 'critical';
  actions: string[];
  notificationChannels: string[];
}

export interface EscalationPolicy {
  level: number;
  conditions: string[];
  actions: string[];
  autoRecovery: boolean;
  escalationTime: number; // Time to wait before escalating
}

export interface ResilienceMonitoringConfig {
  enabled: boolean;
  logLevel: 'debug' | 'info' | 'warn' | 'error';
  metricsEnabled: boolean;
  metricsInterval: number; // Metrics collection interval in milliseconds
  tracingEnabled: boolean;
  dashboardEnabled: boolean;
  alertingEnabled: boolean;
  healthEndpoints: string[];
  performanceMetrics: PerformanceMetric[];
  customMetrics: CustomMetric[];
}

export interface PerformanceMetric {
  name: string;
  type: 'counter' | 'gauge' | 'histogram' | 'timer';
  enabled: boolean;
  labels: string[];
  aggregation: 'sum' | 'avg' | 'max' | 'min' | 'count';
}

export interface CustomMetric {
  name: string;
  description: string;
  unit: string;
  type: 'counter' | 'gauge' | 'histogram';
  enabled: boolean;
  labels: string[];
}

export interface HealthCheckConfig {
  enabled: boolean;
  interval: number; // Health check interval in milliseconds
  timeout: number; // Health check timeout
  endpoints: HealthCheckEndpoint[];
  dependencies: DependencyHealthCheck[];
  circuitBreakerIntegration: boolean;
  healthCheckStrategies: HealthCheckStrategy[];
  unhealthyThreshold: number; // Consecutive failures before marking unhealthy
  healthyThreshold: number; // Consecutive successes before marking healthy
}

export interface HealthCheckEndpoint {
  name: string;
  url: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  timeout: number;
  expectedStatus: number[];
  headers: Record<string, string>;
  body?: any;
  enabled: boolean;
}

export interface DependencyHealthCheck {
  name: string;
  type: 'database' | 'redis' | 'external-api' | 'message-queue' | 'custom';
  check: HealthCheckFunction;
  config: Record<string, any>;
  enabled: boolean;
}

export interface HealthCheckStrategy {
  name: string;
  type: 'tcp' | 'http' | 'command' | 'custom';
  config: Record<string, any>;
  enabled: boolean;
}

export interface ResilienceTestingConfig {
  enabled: boolean;
  testScenarios: TestScenario[];
  chaosEngineering: ChaosEngineeringConfig;
  loadTesting: LoadTestingConfig;
  failoverTesting: FailoverTestingConfig;
  continuousTesting: ContinuousTestingConfig;
}

export interface TestScenario {
  name: string;
  type: 'circuit-breaker' | 'retry' | 'timeout' | 'fallback' | 'dependency-failure';
  description: string;
  enabled: boolean;
  schedule: TestSchedule;
  configuration: TestConfiguration;
  expectedResults: TestExpectedResults;
}

export interface TestSchedule {
  frequency: 'daily' | 'weekly' | 'monthly' | 'on-demand';
  time?: string; // HH:MM format
  dayOfWeek?: number; // 0-6, Sunday = 0
  dayOfMonth?: number; // 1-31
}

export interface TestConfiguration {
  duration: number; // Test duration in seconds
  iterations: number; // Number of test iterations
  concurrentUsers?: number; // For load testing
  rampUpTime?: number; // Ramp up time in seconds
  failureRate?: number; // Expected failure rate (0-1)
  errorInjection?: ErrorInjectionConfig;
}

export interface ErrorInjectionConfig {
  enabled: boolean;
  errorType: string;
  probability: number; // 0-1
  delay?: number; // Injected delay in milliseconds
  customError?: string;
}

export interface TestExpectedResults {
  circuitBreakerOpens: number;
  successfulRetries: number;
  fallbackTriggers: number;
  averageResponseTime: number;
  errorRate: number;
  availabilityTarget: number; // 0-1
}

export interface ChaosEngineeringConfig {
  enabled: boolean;
  experiments: ChaosExperiment[];
  schedule: ChaosSchedule;
  blastRadius: number; // 0-1, percentage of system affected
  rollbackEnabled: boolean;
}

export interface ChaosExperiment {
  name: string;
  type: 'latency' | 'timeout' | 'error' | 'dependency-failure' | 'resource-exhaustion';
  description: string;
  enabled: boolean;
  configuration: Record<string, any>;
  targets: string[]; // Service targets
}

export interface ChaosSchedule {
  enabled: boolean;
  frequency: 'daily' | 'weekly' | 'monthly';
  time?: string;
  maxDuration: number; // Maximum experiment duration in minutes
}

export interface LoadTestingConfig {
  enabled: boolean;
  profiles: LoadTestProfile[];
  baseline: LoadTestBaseline;
  stress: StressTestConfig;
  spike: SpikeTestConfig;
  endurance: EnduranceTestConfig;
}

export interface LoadTestProfile {
  name: string;
  virtualUsers: number;
  duration: number; // in minutes
  rampUp: number; // ramp up time in minutes
  scenarios: LoadTestScenario[];
}

export interface LoadTestScenario {
  name: string;
  weight: number; // Percentage
  requestRate: number; // Requests per second
  responseTimeTarget: number; // Target response time in milliseconds
}

export interface LoadTestBaseline {
  concurrentUsers: number;
  testDuration: number; // in minutes
  targetThroughput: number; // requests per second
  acceptableErrorRate: number; // 0-1
}

export interface StressTestConfig {
  enabled: boolean;
  maxUsers: number;
  stepSize: number;
  stepDuration: number; // in minutes
  targetResourceUtilization: Record<string, number>; // CPU, Memory, etc.
}

export interface SpikeTestConfig {
  enabled: boolean;
  spikeUsers: number;
  spikeDuration: number; // in minutes
  baseLoad: number;
  recoveryTime: number; // in minutes
}

export interface EnduranceTestConfig {
  enabled: boolean;
  constantUsers: number;
  testDuration: number; // in hours
  memoryLeakDetection: boolean;
  performanceDegradationThreshold: number; // percentage
}

export interface FailoverTestingConfig {
  enabled: boolean;
  scenarios: FailoverTestScenario[];
  automaticRecovery: boolean;
  gracefulDegradation: boolean;
}

export interface FailoverTestScenario {
  name: string;
  dependency: string; // Service or dependency to fail
  failureType: 'complete' | 'partial' | 'degraded';
  expectedRecoveryTime: number; // in seconds
  validationCriteria: string[];
}

export interface ContinuousTestingConfig {
  enabled: boolean;
  integration: ContinuousIntegrationConfig;
  deployment: ContinuousDeploymentConfig;
  monitoring: ContinuousMonitoringConfig;
}

export interface ContinuousIntegrationConfig {
  triggerOnCommit: boolean;
  testEnvironments: string[];
  requiredTests: string[];
  timeout: number; // in minutes
}

export interface ContinuousDeploymentConfig {
  autoRollback: boolean;
  rollbackTriggers: string[];
  canaryDeployments: boolean;
  canarySize: number; // percentage
}

export interface ContinuousMonitoringConfig {
  realTimeAlerts: boolean;
  performanceRegressionDetection: boolean;
  anomalyDetection: boolean;
  automatedEscalation: boolean;
}

export interface EnvironmentOverrides {
  development: Partial<ResilienceConfig>;
  staging: Partial<ResilienceConfig>;
  production: Partial<ResilienceConfig>;
  testing: Partial<ResilienceConfig>;
}

export interface CacheInvalidationConfig {
  strategy: 'time-based' | 'event-based' | 'manual' | 'hybrid';
  ttl: number; // Time to live in milliseconds
  maxSize: number; // Maximum cache size
  evictionPolicy: 'lru' | 'fifo' | 'lfu';
}

// Supporting Types
export interface TimeoutCallback {
  name: string;
  timeout: number;
  handler: string; // Function name or module path
  params: Record<string, any>;
}

export type HealthCheckFunction = () => Promise<HealthCheckResult>;

// Default Resilience Configuration
const defaultResilienceConfig: ResilienceConfig = {
  circuitBreaker: {
    enabled: true,
    failureThreshold: 5,
    successThreshold: 3,
    timeout: 60000, // 1 minute
    resetTimeout: 30000, // 30 seconds
    monitoringPeriod: 60000, // 1 minute
    halfOpenMaxCalls: 10,
    errorTypes: [
      'ECONNREFUSED',
      'ECONNRESET',
      'ENOTFOUND',
      'ETIMEDOUT',
      'EHOSTUNREACH',
      'NETWORK_ERROR',
      'TIMEOUT',
    ],
    excludeErrors: ['VALIDATION_ERROR', 'UNAUTHORIZED'],
  },
  retry: {
    enabled: true,
    maxAttempts: 3,
    baseDelay: 1000, // 1 second
    maxDelay: 30000, // 30 seconds
    backoffMultiplier: 2,
    jitterEnabled: true,
    jitterFactor: 0.1,
    retryableErrors: [
      'ECONNREFUSED',
      'ECONNRESET',
      'ENOTFOUND',
      'ETIMEDOUT',
      'EHOSTUNREACH',
      'NETWORK_ERROR',
      'TEMPORARY_FAILURE',
      'SERVICE_UNAVAILABLE',
      'GATEWAY_TIMEOUT',
    ],
    nonRetryableErrors: [
      'VALIDATION_ERROR',
      'UNAUTHORIZED',
      'FORBIDDEN',
      'NOT_FOUND',
      'CONFLICT',
      'BAD_REQUEST',
    ],
    exponentialBackoff: true,
    maxRetryTime: 60000, // 1 minute
  },
  timeout: {
    defaultTimeout: 30000, // 30 seconds
    operationTimeouts: {
      'database-query': 10000, // 10 seconds
      'external-api': 15000, // 15 seconds
      'file-upload': 60000, // 1 minute
      'bulk-operation': 120000, // 2 minutes
      'real-time-operation': 5000, // 5 seconds
    },
    connectionTimeout: 10000, // 10 seconds
    readTimeout: 30000, // 30 seconds
    writeTimeout: 30000, // 30 seconds
    enableTimeouts: true,
    timeoutStrategy: 'fail-fast',
    timeoutCallbacks: [
      {
        name: 'cleanup-resources',
        timeout: 5000,
        handler: 'cleanupResources',
        params: {},
      },
      {
        name: 'notify-timeout',
        timeout: 1000,
        handler: 'notifyTimeout',
        params: {},
      },
    ],
  },
  fallback: {
    enabled: true,
    strategies: {
      'static-response': {
        name: 'static-response',
        type: 'static-response',
        config: {
          response: {
            statusCode: 503,
            headers: {
              'Content-Type': 'application/json',
              'Retry-After': '60',
            },
            body: {
              error: 'Service Temporarily Unavailable',
              message: 'The service is temporarily unavailable. Please try again later.',
              retryAfter: 60,
            },
          },
          delay: 0,
        },
        priority: 1,
        enabled: true,
        conditions: [],
      },
      'cached-response': {
        name: 'cached-response',
        type: 'cached-response',
        config: {
          cacheKey: 'service-cache',
          maxAge: 300000, // 5 minutes
          staleWhileRevalidate: true,
        },
        priority: 2,
        enabled: true,
        conditions: [],
      },
    },
    defaultFallback: {
      name: 'default-error-response',
      type: 'static-response',
      config: {
        response: {
          statusCode: 500,
          headers: {
            'Content-Type': 'application/json',
          },
          body: {
            error: 'Internal Server Error',
            message: 'An unexpected error occurred.',
          },
        },
        delay: 0,
      },
      priority: 999,
      enabled: true,
      conditions: [],
    },
    cacheEnabled: true,
    cacheTimeout: 300000, // 5 minutes
    cacheInvalidation: {
      strategy: 'time-based',
      ttl: 300000,
      maxSize: 1000,
      evictionPolicy: 'lru',
    },
    fallbackOrder: ['static-response', 'cached-response', 'alternative-service'],
  },
  errorThresholds: {
    enabled: true,
    errorRateThreshold: 10, // 10%
    responseTimeThreshold: 5000, // 5 seconds
    concurrentRequestsThreshold: 1000,
    queueDepthThreshold: 500,
    memoryUsageThreshold: 80, // 80%
    cpuUsageThreshold: 80, // 80%
    failureStreakThreshold: 10,
    slidingWindowSize: 300, // 5 minutes
    alertThresholds: [
      {
        metric: 'error_rate',
        threshold: 15,
        duration: 300000, // 5 minutes
        severity: 'high',
        actions: ['alert-on-call', 'create-incident'],
        notificationChannels: ['slack', 'email'],
      },
      {
        metric: 'response_time',
        threshold: 10000,
        duration: 180000, // 3 minutes
        severity: 'medium',
        actions: ['log-warning'],
        notificationChannels: ['slack'],
      },
    ],
    escalationPolicies: [
      {
        level: 1,
        conditions: ['error_rate > 10%', 'response_time > 5s'],
        actions: ['increase-logging', 'notify-team'],
        autoRecovery: false,
        escalationTime: 600000, // 10 minutes
      },
      {
        level: 2,
        conditions: ['error_rate > 20%', 'service_unavailable > 5min'],
        actions: ['scale-horizontal', 'notify-management'],
        autoRecovery: true,
        escalationTime: 1800000, // 30 minutes
      },
    ],
  },
  monitoring: {
    enabled: true,
    logLevel: 'info',
    metricsEnabled: true,
    metricsInterval: 10000, // 10 seconds
    tracingEnabled: true,
    dashboardEnabled: true,
    alertingEnabled: true,
    healthEndpoints: [
      '/health/resilience',
      '/health/circuit-breaker',
      '/health/retry',
      '/health/fallback',
    ],
    performanceMetrics: [
      {
        name: 'request_count',
        type: 'counter',
        enabled: true,
        labels: ['service', 'method', 'status'],
        aggregation: 'sum',
      },
      {
        name: 'request_duration',
        type: 'histogram',
        enabled: true,
        labels: ['service', 'method'],
        aggregation: 'avg',
      },
      {
        name: 'circuit_breaker_state',
        type: 'gauge',
        enabled: true,
        labels: ['service', 'state'],
        aggregation: 'count',
      },
      {
        name: 'retry_attempts',
        type: 'counter',
        enabled: true,
        labels: ['service', 'attempt_number'],
        aggregation: 'sum',
      },
    ],
    customMetrics: [
      {
        name: 'fallback_usage_rate',
        description: 'Rate of fallback strategy usage',
        unit: 'percentage',
        type: 'gauge',
        enabled: true,
        labels: ['service', 'strategy'],
      },
      {
        name: 'recovery_time',
        description: 'Time taken to recover from failure',
        unit: 'milliseconds',
        type: 'histogram',
        enabled: true,
        labels: ['service', 'failure_type'],
      },
    ],
  },
  healthCheck: {
    enabled: true,
    interval: 30000, // 30 seconds
    timeout: 5000, // 5 seconds
    endpoints: [
      {
        name: 'self-health',
        url: '/health',
        method: 'GET',
        timeout: 5000,
        expectedStatus: [200],
        headers: {},
        enabled: true,
      },
      {
        name: 'dependency-health',
        url: '/health/dependencies',
        method: 'GET',
        timeout: 10000,
        expectedStatus: [200],
        headers: {},
        enabled: true,
      },
    ],
    dependencies: [
      {
        name: 'database',
        type: 'database',
        check: async () => ({ status: 'healthy', details: {} }),
        config: { connectionString: process.env.DATABASE_URL },
        enabled: true,
      },
      {
        name: 'redis',
        type: 'redis',
        check: async () => ({ status: 'healthy', details: {} }),
        config: { host: process.env.REDIS_HOST, port: parseInt(process.env.REDIS_PORT || '6379') },
        enabled: true,
      },
      {
        name: 'external-api',
        type: 'external-api',
        check: async () => ({ status: 'healthy', details: {} }),
        config: { apiUrl: process.env.EXTERNAL_API_URL },
        enabled: true,
      },
    ],
    circuitBreakerIntegration: true,
    healthCheckStrategies: [
      {
        name: 'tcp-check',
        type: 'tcp',
        config: { host: 'localhost', port: 3000 },
        enabled: true,
      },
      {
        name: 'http-check',
        type: 'http',
        config: { url: 'http://localhost:3000/health', method: 'GET' },
        enabled: true,
      },
    ],
    unhealthyThreshold: 3, // 3 consecutive failures
    healthyThreshold: 2, // 2 consecutive successes
  },
  testing: {
    enabled: true,
    testScenarios: [
      {
        name: 'circuit-breaker-test',
        type: 'circuit-breaker',
        description: 'Test circuit breaker behavior under failure conditions',
        enabled: true,
        schedule: {
          frequency: 'weekly',
          dayOfWeek: 1, // Monday
          time: '02:00',
        },
        configuration: {
          duration: 300, // 5 minutes
          iterations: 10,
          errorInjection: {
            enabled: true,
            errorType: 'CONNECTION_REFUSED',
            probability: 0.5,
            delay: 2000,
          },
        },
        expectedResults: {
          circuitBreakerOpens: 3,
          successfulRetries: 5,
          fallbackTriggers: 2,
          averageResponseTime: 1000,
          errorRate: 0.1,
          availabilityTarget: 0.99,
        },
      },
      {
        name: 'retry-policy-test',
        type: 'retry',
        description: 'Test retry policies and backoff strategies',
        enabled: true,
        schedule: {
          frequency: 'weekly',
          dayOfWeek: 1,
          time: '02:30',
        },
        configuration: {
          duration: 180,
          iterations: 5,
          errorInjection: {
            enabled: true,
            errorType: 'TEMPORARY_FAILURE',
            probability: 0.3,
          },
        },
        expectedResults: {
          circuitBreakerOpens: 0,
          successfulRetries: 8,
          fallbackTriggers: 0,
          averageResponseTime: 2000,
          errorRate: 0.05,
          availabilityTarget: 0.999,
        },
      },
      {
        name: 'fallback-strategy-test',
        type: 'fallback',
        description: 'Test fallback strategy effectiveness',
        enabled: true,
        schedule: {
          frequency: 'weekly',
          dayOfWeek: 1,
          time: '03:00',
        },
        configuration: {
          duration: 240,
          iterations: 8,
          errorInjection: {
            enabled: true,
            errorType: 'SERVICE_UNAVAILABLE',
            probability: 0.7,
          },
        },
        expectedResults: {
          circuitBreakerOpens: 1,
          successfulRetries: 0,
          fallbackTriggers: 6,
          averageResponseTime: 500,
          errorRate: 0.0,
          availabilityTarget: 1.0,
        },
      },
    ],
    chaosEngineering: {
      enabled: false, // Disabled by default, enable in testing environments
      experiments: [
        {
          name: 'latency-injection',
          type: 'latency',
          description: 'Inject network latency to test resilience',
          enabled: false,
          configuration: {
            delayRange: [1000, 5000],
            affectedServices: ['external-api'],
          },
          targets: ['external-api'],
        },
        {
          name: 'dependency-failure',
          type: 'dependency-failure',
          description: 'Simulate dependency service failures',
          enabled: false,
          configuration: {
            failureType: 'complete',
            duration: 30000,
            affectedDependencies: ['database'],
          },
          targets: ['database'],
        },
      ],
      schedule: {
        enabled: false,
        frequency: 'monthly',
        time: '03:00',
        maxDuration: 30, // 30 minutes
      },
      blastRadius: 0.1, // 10% of system
      rollbackEnabled: true,
    },
    loadTesting: {
      enabled: true,
      profiles: [
        {
          name: 'baseline-load',
          virtualUsers: 100,
          duration: 30, // 30 minutes
          rampUp: 5, // 5 minutes
          scenarios: [
            {
              name: 'api-requests',
              weight: 80,
              requestRate: 50,
              responseTimeTarget: 1000,
            },
            {
              name: 'bulk-operations',
              weight: 20,
              requestRate: 5,
              responseTimeTarget: 5000,
            },
          ],
        },
        {
          name: 'stress-test',
          virtualUsers: 500,
          duration: 15, // 15 minutes
          rampUp: 3,
          scenarios: [
            {
              name: 'api-requests',
              weight: 70,
              requestRate: 200,
              responseTimeTarget: 2000,
            },
            {
              name: 'concurrent-operations',
              weight: 30,
              requestRate: 50,
              responseTimeTarget: 10000,
            },
          ],
        },
      ],
      baseline: {
        concurrentUsers: 50,
        testDuration: 10, // 10 minutes
        targetThroughput: 25, // requests per second
        acceptableErrorRate: 0.01, // 1%
      },
      stress: {
        enabled: true,
        maxUsers: 1000,
        stepSize: 100,
        stepDuration: 5, // 5 minutes per step
        targetResourceUtilization: {
          cpu: 80,
          memory: 85,
          'disk-io': 70,
        },
      },
      spike: {
        enabled: true,
        spikeUsers: 1000,
        spikeDuration: 2, // 2 minutes
        baseLoad: 100,
        recoveryTime: 5, // 5 minutes
      },
      endurance: {
        enabled: false, // Disabled by default due to duration
        constantUsers: 200,
        testDuration: 24, // 24 hours
        memoryLeakDetection: true,
        performanceDegradationThreshold: 10, // 10%
      },
    },
    failoverTesting: {
      enabled: true,
      scenarios: [
        {
          name: 'database-failover',
          dependency: 'database',
          failureType: 'complete',
          expectedRecoveryTime: 60, // 60 seconds
          validationCriteria: [
            'fallback-strategies-activated',
            'no-data-loss',
            'automatic-recovery',
          ],
        },
        {
          name: 'api-degradation',
          dependency: 'external-api',
          failureType: 'degraded',
          expectedRecoveryTime: 30, // 30 seconds
          validationCriteria: [
            'circuit-breaker-activated',
            'cached-responses-used',
            'degraded-performance-acceptable',
          ],
        },
      ],
      automaticRecovery: true,
      gracefulDegradation: true,
    },
    continuousTesting: {
      enabled: true,
      integration: {
        triggerOnCommit: true,
        testEnvironments: ['staging', 'production'],
        requiredTests: ['circuit-breaker-test', 'retry-policy-test'],
        timeout: 30, // 30 minutes
      },
      deployment: {
        autoRollback: true,
        rollbackTriggers: [
          'error_rate > 5%',
          'response_time > 10s',
          'availability < 95%',
        ],
        canaryDeployments: true,
        canarySize: 10, // 10% canary
      },
      monitoring: {
        realTimeAlerts: true,
        performanceRegressionDetection: true,
        anomalyDetection: true,
        automatedEscalation: true,
      },
    },
  },
  environments: {
    development: {
      monitoring: {
        logLevel: 'debug',
        metricsEnabled: true,
      },
      circuitBreaker: {
        failureThreshold: 3,
        timeout: 30000,
      },
      retry: {
        maxAttempts: 2,
        baseDelay: 500,
      },
      testing: {
        chaosEngineering: {
          enabled: true,
        },
        loadTesting: {
          endurance: {
            enabled: true,
            testDuration: 1, // 1 hour in development
          },
        },
      },
    },
    staging: {
      monitoring: {
        logLevel: 'info',
        metricsEnabled: true,
      },
      testing: {
        chaosEngineering: {
          enabled: true,
          blastRadius: 0.05, // 5% in staging
        },
      },
    },
    production: {
      monitoring: {
        logLevel: 'warn',
        metricsEnabled: true,
      },
      circuitBreaker: {
        failureThreshold: 10,
        timeout: 60000,
      },
      retry: {
        maxAttempts: 5,
        baseDelay: 2000,
      },
      errorThresholds: {
        errorRateThreshold: 5, // Stricter in production
        responseTimeThreshold: 3000,
      },
    },
    testing: {
      monitoring: {
        logLevel: 'debug',
      },
      circuitBreaker: {
        enabled: false, // Disable in tests for deterministic behavior
      },
      retry: {
        maxAttempts: 1, // Fast failures in tests
      },
      testing: {
        chaosEngineering: {
          enabled: true,
        },
      },
    },
  },
};

// Resilience Configuration Manager
export class ResilienceConfigManager extends EventEmitter {
  private config: ResilienceConfig;
  private circuitBreakers: Map<string, CircuitBreaker> = new Map();
  private retryPolicies: Map<string, RetryPolicy> = new Map();
  private timeouts: Map<string, Timeout> = new Map();
  private fallbackStrategies: Map<string, FallbackStrategy> = new Map();
  private healthChecks: Map<string, HealthCheck> = new Map();
  private monitoringMetrics: Map<string, any> = new Map();
  private eventQueue: ResilienceEvent[] = [];

  constructor(initialConfig?: Partial<ResilienceConfig>) {
    super();
    
    // Merge default config with environment-specific overrides and provided config
    const envSpecificConfig = this.getEnvironmentConfig();
    this.config = this.deepMerge(defaultResilienceConfig, envSpecificConfig, initialConfig || {});
    
    this.initializeResilienceComponents();
    this.startMonitoring();
  }

  // Configuration Management
  getConfig(): ResilienceConfig {
    return { ...this.config };
  }

  updateConfig(updates: Partial<ResilienceConfig>): void {
    this.config = this.deepMerge(this.config, updates);
    this.emit('configUpdated', this.config);
    this.reinitializeResilienceComponents();
  }

  updateCircuitBreaker(updates: Partial<CircuitBreakerConfig>): void {
    this.config.circuitBreaker = { ...this.config.circuitBreaker, ...updates };
    this.emit('circuitBreakerUpdated', this.config.circuitBreaker);
  }

  updateRetry(updates: Partial<RetryConfig>): void {
    this.config.retry = { ...this.config.retry, ...updates };
    this.emit('retryUpdated', this.config.retry);
  }

  updateTimeout(updates: Partial<TimeoutConfig>): void {
    this.config.timeout = { ...this.config.timeout, ...updates };
    this.emit('timeoutUpdated', this.config.timeout);
  }

  updateFallback(updates: Partial<FallbackConfig>): void {
    this.config.fallback = { ...this.config.fallback, ...updates };
    this.emit('fallbackUpdated', this.config.fallback);
  }

  // Circuit Breaker Management
  getCircuitBreaker(serviceName: string): CircuitBreaker {
    if (!this.circuitBreakers.has(serviceName)) {
      const circuitBreaker = new CircuitBreaker(serviceName, this.config.circuitBreaker);
      this.circuitBreakers.set(serviceName, circuitBreaker);
      
      circuitBreaker.on('stateChanged', (state) => {
        this.emit('circuitBreakerStateChanged', { serviceName, state });
        this.recordMetric('circuit_breaker_state', { service: serviceName, state });
      });
    }
    
    return this.circuitBreakers.get(serviceName)!;
  }

  // Retry Policy Management
  getRetryPolicy(operationName: string): RetryPolicy {
    if (!this.retryPolicies.has(operationName)) {
      const retryPolicy = new RetryPolicy(operationName, this.config.retry);
      this.retryPolicies.set(operationName, retryPolicy);
    }
    
    return this.retryPolicies.get(operationName)!;
  }

  // Timeout Management
  getTimeout(operationType: string): Timeout {
    if (!this.timeouts.has(operationType)) {
      const timeout = new Timeout(operationType, this.config.timeout);
      this.timeouts.set(operationType, timeout);
    }
    
    return this.timeouts.get(operationType)!;
  }

  // Fallback Strategy Management
  executeFallback(strategyName: string, context: any): Promise<any> {
    const strategy = this.config.fallback.strategies[strategyName];
    if (!strategy) {
      throw new Error(`Fallback strategy '${strategyName}' not found`);
    }

    return this.performFallback(strategy, context);
  }

  getAvailableFallbacks(): string[] {
    return Object.keys(this.config.fallback.strategies);
  }

  // Health Check Management
  startHealthChecks(): void {
    if (!this.config.healthCheck.enabled) return;

    setInterval(() => {
      this.performHealthChecks();
    }, this.config.healthCheck.interval);
  }

  getHealthStatus(): HealthStatus {
    const healthChecks = Array.from(this.healthChecks.values());
    const overallStatus = healthChecks.every(hc => hc.isHealthy()) ? 'healthy' : 'unhealthy';
    
    return {
      status: overallStatus,
      checks: healthChecks.map(hc => hc.getStatus()),
      timestamp: new Date(),
    };
  }

  // Error Threshold Monitoring
  checkErrorThresholds(metrics: ResilienceMetrics): void {
    if (!this.config.errorThresholds.enabled) return;

    const thresholds = this.config.errorThresholds;
    
    // Check error rate threshold
    if (metrics.errorRate > thresholds.errorRateThreshold) {
      this.handleThresholdViolation('error_rate', metrics.errorRate, thresholds.errorRateThreshold);
    }

    // Check response time threshold
    if (metrics.averageResponseTime > thresholds.responseTimeThreshold) {
      this.handleThresholdViolation('response_time', metrics.averageResponseTime, thresholds.responseTimeThreshold);
    }

    // Check CPU usage threshold
    if (metrics.cpuUsage > thresholds.cpuUsageThreshold) {
      this.handleThresholdViolation('cpu_usage', metrics.cpuUsage, thresholds.cpuUsageThreshold);
    }

    // Check memory usage threshold
    if (metrics.memoryUsage > thresholds.memoryUsageThreshold) {
      this.handleThresholdViolation('memory_usage', metrics.memoryUsage, thresholds.memoryUsageThreshold);
    }
  }

  // Testing and Validation
  runResilienceTest(scenarioName: string): Promise<TestResult> {
    const scenario = this.config.testing.testScenarios.find(s => s.name === scenarioName);
    if (!scenario) {
      throw new Error(`Test scenario '${scenarioName}' not found`);
    }

    const testRunner = new ResilienceTestRunner(scenario);
    return testRunner.execute();
  }

  runChaosExperiment(experimentName: string): Promise<ChaosExperimentResult> {
    const experiment = this.config.testing.chaosEngineering.experiments.find(e => e.name === experimentName);
    if (!experiment) {
      throw new Error(`Chaos experiment '${experimentName}' not found`);
    }

    const chaosEngine = new ChaosEngine(experiment);
    return chaosEngine.execute();
  }

  runLoadTest(profileName: string): Promise<LoadTestResult> {
    const profile = this.config.testing.loadTesting.profiles.find(p => p.name === profileName);
    if (!profile) {
      throw new Error(`Load test profile '${profileName}' not found`);
    }

    const loadTester = new LoadTestRunner(profile);
    return loadTester.execute();
  }

  // Monitoring and Metrics
  recordMetric(name: string, value: number, labels: Record<string, string> = {}): void {
    if (!this.config.monitoring.metricsEnabled) return;

    const metric = {
      name,
      value,
      labels,
      timestamp: new Date(),
    };

    this.monitoringMetrics.set(`${name}_${Date.now()}`, metric);
    
    if (this.monitoringMetrics.size > 10000) {
      // Keep only latest 10000 metrics
      const keys = Array.from(this.monitoringMetrics.keys()).slice(0, 5000);
      keys.forEach(key => this.monitoringMetrics.delete(key));
    }

    this.emit('metricRecorded', metric);
  }

  getMetrics(timeRange?: { start: Date; end: Date }): Map<string, any[]> {
    const filteredMetrics = new Map<string, any[]>();

    for (const [key, metric] of this.monitoringMetrics) {
      if (timeRange) {
        if (metric.timestamp < timeRange.start || metric.timestamp > timeRange.end) {
          continue;
        }
      }

      if (!filteredMetrics.has(metric.name)) {
        filteredMetrics.set(metric.name, []);
      }
      filteredMetrics.get(metric.name)!.push(metric);
    }

    return filteredMetrics;
  }

  // Event Management
  createResilienceEvent(event: Omit<ResilienceEvent, 'id' | 'timestamp'>): ResilienceEvent {
    const resilienceEvent: ResilienceEvent = {
      id: this.generateEventId(),
      timestamp: new Date(),
      ...event,
    };

    this.eventQueue.push(resilienceEvent);
    
    // Process event queue
    if (this.eventQueue.length >= 100) {
      this.processEventQueue();
    }

    this.emit('resilienceEvent', resilienceEvent);
    return resilienceEvent;
  }

  // Private Methods
  private initializeResilienceComponents(): void {
    this.startHealthChecks();
  }

  private reinitializeResilienceComponents(): void {
    // Clear existing components
    this.circuitBreakers.clear();
    this.retryPolicies.clear();
    this.timeouts.clear();
    this.fallbackStrategies.clear();
    this.healthChecks.clear();
    
    // Reinitialize with updated configuration
    this.initializeResilienceComponents();
  }

  private getEnvironmentConfig(): Partial<ResilienceConfig> {
    const env = process.env.NODE_ENV || 'development';
    return this.config.environments[env] || {};
  }

  private deepMerge(target: any, ...sources: any[]): any {
    if (!sources.length) return target;
    const source = sources.shift();

    if (this.isObject(target) && this.isObject(source)) {
      for (const key in source) {
        if (this.isObject(source[key])) {
          if (!target[key]) Object.assign(target, { [key]: {} });
          this.deepMerge(target[key], source[key]);
        } else {
          Object.assign(target, { [key]: source[key] });
        }
      }
    }

    return this.deepMerge(target, ...sources);
  }

  private isObject(item: any): boolean {
    return item && typeof item === 'object' && !Array.isArray(item);
  }

  private performFallback(strategy: FallbackStrategy, context: any): Promise<any> {
    return new Promise((resolve, reject) => {
      try {
        switch (strategy.type) {
          case 'static-response':
            this.executeStaticFallback(strategy.config as StaticResponseFallback, resolve);
            break;
          case 'cached-response':
            this.executeCachedFallback(strategy.config as CachedResponseFallback, resolve);
            break;
          case 'alternative-service':
            this.executeAlternativeServiceFallback(strategy.config as AlternativeServiceFallback, resolve, reject);
            break;
          default:
            reject(new Error(`Unsupported fallback type: ${strategy.type}`));
        }
      } catch (error) {
        reject(error);
      }
    });
  }

  private executeStaticFallback(config: StaticResponseFallback, resolve: (value: any) => void): void {
    setTimeout(() => {
      resolve(config.response);
    }, config.delay);
  }

  private executeCachedFallback(config: CachedResponseFallback, resolve: (value: any) => void): void {
    // Implementation would retrieve from cache
    resolve({ cached: true, message: 'Cached response would be returned here' });
  }

  private executeAlternativeServiceFallback(
    config: AlternativeServiceFallback,
    resolve: (value: any) => void,
    reject: (reason?: any) => void
  ): void {
    // Implementation would make request to alternative service
    resolve({ redirected: true, serviceUrl: config.serviceUrl });
  }

  private performHealthChecks(): void {
    for (const [name, healthCheck] of this.healthChecks) {
      healthCheck.check().then(status => {
        this.emit('healthCheckResult', { name, status });
      }).catch(error => {
        this.emit('healthCheckError', { name, error });
      });
    }
  }

  private handleThresholdViolation(metric: string, value: number, threshold: number): void {
    const alert = {
      metric,
      value,
      threshold,
      severity: 'high',
      timestamp: new Date(),
    };

    this.createResilienceEvent({
      type: ResilienceEventType.THRESHOLD_VIOLATION,
      severity: 'high',
      source: 'threshold-monitor',
      description: `Threshold violation: ${metric} = ${value} > ${threshold}`,
      metadata: alert,
    });

    this.emit('thresholdViolation', alert);
  }

  private processEventQueue(): void {
    const events = this.eventQueue.splice(0, 50);
    this.emit('eventsProcessed', events);
  }

  private generateEventId(): string {
    return `res_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private startMonitoring(): void {
    if (!this.config.monitoring.enabled) return;

    setInterval(() => {
      this.collectMetrics();
    }, this.config.monitoring.metricsInterval);
  }

  private collectMetrics(): void {
    // Collect system metrics
    const memoryUsage = process.memoryUsage();
    const cpuUsage = process.cpuUsage();
    
    this.recordMetric('memory_usage_rss', memoryUsage.rss);
    this.recordMetric('memory_usage_heap_used', memoryUsage.heapUsed);
    this.recordMetric('cpu_usage_user', cpuUsage.user);
    this.recordMetric('cpu_usage_system', cpuUsage.system);

    // Check error thresholds
    const metrics: ResilienceMetrics = {
      errorRate: 0, // Would be calculated from actual metrics
      averageResponseTime: 0,
      cpuUsage: (cpuUsage.user + cpuUsage.system) / 2,
      memoryUsage: (memoryUsage.heapUsed / memoryUsage.rss) * 100,
      activeRequests: this.circuitBreakers.size,
      queuedRequests: 0,
    };

    this.checkErrorThresholds(metrics);
  }

  // Cleanup and maintenance
  cleanup(): void {
    // Clear monitoring data
    this.monitoringMetrics.clear();
    this.eventQueue = [];
    
    // Clear resilience components
    this.circuitBreakers.clear();
    this.retryPolicies.clear();
    this.timeouts.clear();
    this.fallbackStrategies.clear();
    this.healthChecks.clear();
    
    // Remove event listeners
    this.removeAllListeners();
  }
}

// Supporting Classes (simplified implementations)
class CircuitBreaker {
  private state: 'closed' | 'open' | 'half-open' = 'closed';
  private failureCount = 0;
  private lastFailureTime = 0;

  constructor(private serviceName: string, private config: CircuitBreakerConfig) {}

  async execute<T>(operation: () => Promise<T>): Promise<T> {
    if (this.state === 'open') {
      if (Date.now() - this.lastFailureTime > this.config.resetTimeout) {
        this.state = 'half-open';
      } else {
        throw new Error(`Circuit breaker is open for service: ${this.serviceName}`);
      }
    }

    try {
      const result = await operation();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }

  private onSuccess(): void {
    this.failureCount = 0;
    this.state = 'closed';
  }

  private onFailure(): void {
    this.failureCount++;
    this.lastFailureTime = Date.now();

    if (this.failureCount >= this.config.failureThreshold) {
      this.state = 'open';
    }
  }

  getState(): string {
    return this.state;
  }
}

class RetryPolicy {
  constructor(private operationName: string, private config: RetryConfig) {}

  async execute<T>(operation: () => Promise<T>): Promise<T> {
    let lastError: Error;

    for (let attempt = 1; attempt <= this.config.maxAttempts; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error as Error;

        if (attempt < this.config.maxAttempts && this.shouldRetry(error as Error)) {
          await this.delay(attempt);
          continue;
        }

        break;
      }
    }

    throw lastError!;
  }

  private shouldRetry(error: Error): boolean {
    const errorType = error.name || error.constructor.name;
    return this.config.retryableErrors.includes(errorType) &&
           !this.config.nonRetryableErrors.includes(errorType);
  }

  private delay(attempt: number): Promise<void> {
    let delay = this.config.baseDelay * Math.pow(this.config.backoffMultiplier, attempt - 1);
    
    if (this.config.jitterEnabled) {
      const jitter = delay * this.config.jitterFactor * Math.random();
      delay += jitter;
    }

    return new Promise(resolve => setTimeout(resolve, Math.min(delay, this.config.maxDelay)));
  }
}

class Timeout {
  constructor(private operationType: string, private config: TimeoutConfig) {}

  async execute<T>(operation: () => Promise<T>): Promise<T> {
    const timeout = this.config.operationTimeouts[this.operationType] || this.config.defaultTimeout;

    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        reject(new Error(`Operation timeout after ${timeout}ms`));
      }, timeout);

      operation()
        .then(result => {
          clearTimeout(timer);
          resolve(result);
        })
        .catch(error => {
          clearTimeout(timer);
          reject(error);
        });
    });
  }
}

class HealthCheck {
  constructor(private name: string, private check: HealthCheckFunction) {}

  async check(): Promise<HealthStatus> {
    try {
      const result = await this.check();
      return { ...result, name: this.name };
    } catch (error) {
      return {
        name: this.name,
        status: 'unhealthy',
        error: (error as Error).message,
      };
    }
  }

  isHealthy(): boolean {
    // This would check recent health check results
    return true;
  }

  getStatus(): HealthStatus {
    return {
      name: this.name,
      status: 'healthy',
    };
  }
}

class ResilienceTestRunner {
  constructor(private scenario: TestScenario) {}

  async execute(): Promise<TestResult> {
    const startTime = Date.now();
    
    try {
      // Simulate test execution
      await this.simulateTest();
      
      const duration = Date.now() - startTime;
      
      return {
        scenario: this.scenario.name,
        status: 'passed',
        duration,
        metrics: this.scenario.expectedResults,
      };
    } catch (error) {
      return {
        scenario: this.scenario.name,
        status: 'failed',
        duration: Date.now() - startTime,
        error: (error as Error).message,
      };
    }
  }

  private async simulateTest(): Promise<void> {
    // Simulate test duration
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
}

class ChaosEngine {
  constructor(private experiment: ChaosExperiment) {}

  async execute(): Promise<ChaosExperimentResult> {
    const startTime = Date.now();
    
    try {
      await this.executeExperiment();
      
      return {
        experiment: this.experiment.name,
        status: 'completed',
        duration: Date.now() - startTime,
      };
    } catch (error) {
      return {
        experiment: this.experiment.name,
        status: 'failed',
        duration: Date.now() - startTime,
        error: (error as Error).message,
      };
    }
  }

  private async executeExperiment(): Promise<void> {
    // Simulate chaos experiment
    await new Promise(resolve => setTimeout(resolve, 500));
  }
}

class LoadTestRunner {
  constructor(private profile: LoadTestProfile) {}

  async execute(): Promise<LoadTestResult> {
    const startTime = Date.now();
    
    try {
      await this.runLoadTest();
      
      return {
        profile: this.profile.name,
        status: 'completed',
        duration: Date.now() - startTime,
        metrics: {
          totalRequests: this.profile.virtualUsers * this.profile.duration * 60,
          averageResponseTime: 1000,
          errorRate: 0.01,
        },
      };
    } catch (error) {
      return {
        profile: this.profile.name,
        status: 'failed',
        duration: Date.now() - startTime,
        error: (error as Error).message,
      };
    }
  }

  private async runLoadTest(): Promise<void> {
    // Simulate load test
    await new Promise(resolve => setTimeout(resolve, 2000));
  }
}

// Resilience Event Types
export enum ResilienceEventType {
  CIRCUIT_BREAKER_OPENED = 'circuit_breaker_opened',
  CIRCUIT_BREAKER_CLOSED = 'circuit_breaker_closed',
  RETRY_ATTEMPT = 'retry_attempt',
  TIMEOUT_OCCURRED = 'timeout_occurred',
  FALLBACK_TRIGGERED = 'fallback_triggered',
  THRESHOLD_VIOLATION = 'threshold_violation',
  HEALTH_CHECK_FAILED = 'health_check_failed',
  CHAOS_EXPERIMENT_STARTED = 'chaos_experiment_started',
  CHAOS_EXPERIMENT_COMPLETED = 'chaos_experiment_completed',
  LOAD_TEST_STARTED = 'load_test_started',
  LOAD_TEST_COMPLETED = 'load_test_completed',
}

export interface ResilienceEvent {
  id: string;
  type: ResilienceEventType;
  timestamp: Date;
  severity: 'low' | 'medium' | 'high' | 'critical';
  source: string;
  description: string;
  metadata: Record<string, any>;
}

export interface HealthStatus {
  name?: string;
  status: 'healthy' | 'unhealthy' | 'degraded';
  error?: string;
  details?: any;
  timestamp?: Date;
  checks?: HealthStatus[];
}

export interface HealthCheckResult {
  name: string;
  status: 'healthy' | 'unhealthy' | 'degraded';
  error?: string;
  details?: any;
}

export interface ResilienceMetrics {
  errorRate: number;
  averageResponseTime: number;
  cpuUsage: number;
  memoryUsage: number;
  activeRequests: number;
  queuedRequests: number;
}

export interface TestResult {
  scenario: string;
  status: 'passed' | 'failed';
  duration: number;
  metrics?: any;
  error?: string;
}

export interface ChaosExperimentResult {
  experiment: string;
  status: 'completed' | 'failed';
  duration: number;
  error?: string;
}

export interface LoadTestResult {
  profile: string;
  status: 'completed' | 'failed';
  duration: number;
  metrics?: {
    totalRequests: number;
    averageResponseTime: number;
    errorRate: number;
  };
  error?: string;
}

// Default resilience configuration manager instance
export const defaultResilienceConfigManager = new ResilienceConfigManager();

// Export resilience management utilities
export const ResilienceConfigUtils = {
  createCustomConfig: (overrides: Partial<ResilienceConfig>) => new ResilienceConfigManager(overrides),
  
  createCircuitBreaker: (serviceName: string, config?: Partial<CircuitBreakerConfig>) => {
    const fullConfig = { ...defaultResilienceConfig.circuitBreaker, ...config };
    return new CircuitBreaker(serviceName, fullConfig);
  },
  
  createRetryPolicy: (operationName: string, config?: Partial<RetryConfig>) => {
    const fullConfig = { ...defaultResilienceConfig.retry, ...config };
    return new RetryPolicy(operationName, fullConfig);
  },
  
  createTimeout: (operationType: string, config?: Partial<TimeoutConfig>) => {
    const fullConfig = { ...defaultResilienceConfig.timeout, ...config };
    return new Timeout(operationType, fullConfig);
  },
  
  calculateBackoffDelay: (attempt: number, baseDelay: number, multiplier: number, maxDelay: number, jitterEnabled: boolean = true, jitterFactor: number = 0.1): number => {
    let delay = baseDelay * Math.pow(multiplier, attempt - 1);
    
    if (jitterEnabled) {
      const jitter = delay * jitterFactor * Math.random();
      delay += jitter;
    }
    
    return Math.min(delay, maxDelay);
  },
  
  isRetryableError: (error: Error, retryableErrors: string[], nonRetryableErrors: string[]): boolean => {
    const errorType = error.name || error.constructor.name;
    return retryableErrors.includes(errorType) && !nonRetryableErrors.includes(errorType);
  },
  
  validateResilienceConfig: (config: ResilienceConfig): ValidationResult => {
    const errors: string[] = [];

    // Validate circuit breaker config
    if (config.circuitBreaker.failureThreshold < 1 || config.circuitBreaker.failureThreshold > 100) {
      errors.push('Circuit breaker failure threshold must be between 1 and 100');
    }

    // Validate retry config
    if (config.retry.maxAttempts < 1 || config.retry.maxAttempts > 10) {
      errors.push('Retry max attempts must be between 1 and 10');
    }

    // Validate timeout config
    if (config.timeout.defaultTimeout < 1000 || config.timeout.defaultTimeout > 300000) {
      errors.push('Default timeout must be between 1000ms and 300000ms');
    }

    // Validate error thresholds
    if (config.errorThresholds.errorRateThreshold < 0 || config.errorThresholds.errorRateThreshold > 100) {
      errors.push('Error rate threshold must be between 0 and 100 percent');
    }

    return {
      valid: errors.length === 0,
      errors,
    };
  },
  
  formatHealthStatus: (status: HealthStatus): string => {
    const emoji = status.status === 'healthy' ? '✅' : status.status === 'degraded' ? '⚠️' : '❌';
    let formatted = `${emoji} ${status.status.toUpperCase()}`;
    
    if (status.name) {
      formatted += ` (${status.name})`;
    }
    
    if (status.error) {
      formatted += `: ${status.error}`;
    }
    
    return formatted;
  },
  
  formatDuration: (milliseconds: number): string => {
    if (milliseconds < 1000) {
      return `${milliseconds}ms`;
    } else if (milliseconds < 60000) {
      return `${(milliseconds / 1000).toFixed(1)}s`;
    } else {
      return `${(milliseconds / 60000).toFixed(1)}m`;
    }
  },
};

// Export event types for external use
// export { ResilienceEventType }; // Already exported as enum

// Default export
export default ResilienceConfigManager;