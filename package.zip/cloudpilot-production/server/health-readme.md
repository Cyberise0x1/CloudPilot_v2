# Health Check System

A comprehensive health monitoring system for the CloudPilot Production server that provides real-time monitoring of database connectivity, AWS services, system resources, and application health.

## Features

### 🏥 Comprehensive Health Monitoring
- **Database Connectivity**: PostgreSQL/Neon database health checks with retry logic
- **AWS Services**: S3, CloudFront, EC2, and RDS service availability checks
- **External Dependencies**: API endpoints and external service monitoring
- **System Resources**: CPU, memory, disk usage monitoring with configurable thresholds
- **Application Health**: Custom application indicators and cryptographic function tests

### 📊 Health Check Endpoints
- `/api/health` - Complete health report with all services
- `/api/health/:service` - Specific service health check
- `/api/health/history` - Historical health data with trends
- `/api/health/metrics` - System metrics only
- `/api/status` - Basic uptime status
- `/api/ready` - Readiness probe (database connectivity)
- `/api/live` - Liveness probe (basic application health)

### 📈 Health History & Trends
- **Real-time Monitoring**: Automated health checks every 30 seconds
- **Historical Data**: Up to 1000 entries with 7-day retention
- **Trend Analysis**: 24-hour and 7-day availability, uptime, and response time trends
- **Critical Incident Tracking**: Automatic detection and reporting of unhealthy states

### ⚡ Performance & Reliability
- **Concurrent Checks**: All health checks run in parallel for faster response
- **Retry Logic**: Automatic retries for transient failures
- **Configurable Timeouts**: Per-service timeout configuration
- **Graceful Degradation**: Handles partial failures without system crash

## Quick Start

### 1. Access Health Endpoints

```bash
# Get complete health report
curl http://localhost:5000/api/health

# Get specific service health
curl http://localhost:5000/api/health/database
curl http://localhost:5000/api/health/aws
curl http://localhost:5000/api/health/system

# Check readiness (Kubernetes style)
curl http://localhost:5000/api/ready

# Check liveness (Kubernetes style)
curl http://localhost:5000/api/live
```

### 2. Monitor System Health

```bash
# Get historical health data
curl http://localhost:5000/api/health/history?limit=50

# Get trends for last 24 hours
curl http://localhost:5000/api/health/history?period=24h

# Get system metrics only
curl http://localhost:5000/api/health/metrics
```

## API Reference

### GET `/api/health`

Returns a comprehensive health report including all services, system metrics, and trends.

**Response Format:**
```json
{
  "timestamp": 1703123456789,
  "status": "healthy",
  "version": "1.0.0",
  "environment": "production",
  "uptime": 12345,
  "checks": {
    "database": {
      "service": "database",
      "status": "healthy",
      "timestamp": 1703123456789,
      "responseTime": 45,
      "message": "Database connection successful",
      "metadata": {
        "currentTime": "2023-12-21 10:30:56",
        "version": "PostgreSQL 14.5",
        "retries": 0
      }
    },
    "aws": {
      "s3": { /* S3 health check result */ },
      "cloudfront": { /* CloudFront health check result */ },
      "ec2": { /* EC2 health check result */ },
      "rds": { /* RDS health check result */ }
    },
    "external": [ /* External dependency results */ ],
    "system": { /* System resource check result */ },
    "application": { /* Application health check result */ }
  },
  "systemMetrics": {
    "cpu": { "usage": 25, "loadAverage": [0.5, 0.3, 0.2], "cores": 4 },
    "memory": { "used": 512000000, "total": 2000000000, "percentage": 25, "free": 1488000000 },
    "disk": { "used": 50000000000, "total": 100000000000, "percentage": 50, "available": 50000000000 },
    "uptime": 12345,
    "pid": 12345,
    "platform": "linux",
    "nodeVersion": "v18.17.0"
  },
  "summary": {
    "total": 8,
    "healthy": 7,
    "degraded": 1,
    "unhealthy": 0,
    "avgResponseTime": 125
  },
  "trends": {
    "last24Hours": {
      "uptime": 99.5,
      "avgResponseTime": 130,
      "availability": 99.5,
      "criticalIncidents": 0
    },
    "last7Days": {
      "uptime": 99.2,
      "avgResponseTime": 145,
      "availability": 99.2,
      "criticalIncidents": 2
    }
  }
}
```

### GET `/api/health/:service`

Get health status for a specific service.

**Available Services:**
- `database` - Database connectivity check
- `aws` - All AWS services
- `external` - External dependencies
- `system` - System resources
- `application` - Application health
- `all` - Complete health report (same as `/api/health`)

### GET `/api/health/history`

Retrieve historical health check data.

**Query Parameters:**
- `limit` (optional): Number of entries to return (default: 100, max: 1000)
- `period` (optional): Time period filter (`1h`, `24h`, `7d`, `30d`)

**Response Format:**
```json
{
  "history": [ /* Array of historical entries */ ],
  "trends": {
    "last24Hours": { /* 24-hour trends */ },
    "last7Days": { /* 7-day trends */ }
  },
  "totalEntries": 150
}
```

### GET `/api/health/metrics`

Returns only system metrics (CPU, memory, disk, uptime).

### GET `/api/status`

Basic application status endpoint.

**Response:**
```json
{
  "status": "ok",
  "timestamp": 1703123456789,
  "uptime": 12345,
  "environment": "production",
  "version": "1.0.0"
}
```

### GET `/api/ready`

Readiness probe for Kubernetes/container orchestration.

**Success Response (200):**
```json
{
  "status": "ready",
  "timestamp": 1703123456789
}
```

**Failure Response (503):**
```json
{
  "status": "not_ready",
  "timestamp": 1703123456789,
  "error": "Database connection failed",
  "details": { /* Full health check details */ }
}
```

### GET `/api/live`

Liveness probe for Kubernetes/container orchestration.

**Response:**
```json
{
  "status": "alive",
  "timestamp": 1703123456789,
  "uptime": 12345
}
```

## Health Status Levels

### 🟢 Healthy (200)
- All services are operational
- Response times are within acceptable limits
- System resources are within thresholds
- No critical errors detected

### 🟡 Degraded (200 with warning)
- Some services have elevated response times
- Non-critical services are experiencing issues
- System resources are approaching thresholds
- Retry logic is active for some services

### 🔴 Unhealthy (503)
- Critical services are down or inaccessible
- Database connection failures
- AWS service connectivity issues
- System resources exceed critical thresholds
- Application cannot function properly

## Configuration

### Environment Variables

```bash
# AWS Configuration (optional)
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key
AWS_REGION=us-east-1

# Database Configuration
DATABASE_URL=postgresql://...

# Application Configuration
NODE_ENV=production
PORT=5000
```

### Health Check Thresholds

The system uses configurable thresholds for system resources:

- **CPU Usage**: 80% warning threshold
- **Memory Usage**: 85% warning threshold  
- **Disk Usage**: 90% warning threshold
- **Database Timeout**: 5 seconds
- **AWS Timeout**: 3 seconds
- **External Dependencies Timeout**: 10 seconds

These can be modified in the `HEALTH_CHECK_CONFIG` constant in `health.ts`.

## Monitoring Integration

### Kubernetes Probes

Use the health endpoints for Kubernetes liveness and readiness probes:

```yaml
apiVersion: v1
kind: Pod
spec:
  containers:
  - name: cloudpilot
    image: cloudpilot:latest
    livenessProbe:
      httpGet:
        path: /api/live
        port: 5000
      initialDelaySeconds: 30
      periodSeconds: 10
    readinessProbe:
      httpGet:
        path: /api/ready
        port: 5000
      initialDelaySeconds: 5
      periodSeconds: 5
```

### Docker Health Check

```dockerfile
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD curl -f http://localhost:5000/api/health || exit 1
```

### Prometheus Monitoring

The health endpoint can be scraped by Prometheus for monitoring:

```yaml
scrape_configs:
- job_name: 'cloudpilot'
  static_configs:
  - targets: ['localhost:5000']
  metrics_path: '/api/health'
  scrape_interval: 30s
```

## Troubleshooting

### Common Issues

#### 1. Database Connection Timeout
```
{
  "service": "database",
  "status": "unhealthy",
  "message": "Database connection failed",
  "error": "Connection timeout"
}
```
**Solution**: Check database connectivity, verify DATABASE_URL, ensure database is running.

#### 2. AWS Service Access Denied
```
{
  "service": "aws-s3", 
  "status": "unhealthy",
  "message": "AWS service initialization failed",
  "error": "Access Denied"
}
```
**Solution**: Verify AWS credentials and permissions in IAM.

#### 3. High Memory Usage
```
{
  "service": "system",
  "status": "degraded", 
  "message": "System resource issues: Memory usage (90%) exceeds threshold (85%)"
}
```
**Solution**: Check for memory leaks, consider scaling or optimization.

#### 4. External Dependency Failures
```
{
  "service": "external-github-api",
  "status": "degraded",
  "message": "GitHub API is not accessible",
  "error": "ENOTFOUND"
}
```
**Solution**: Check network connectivity, DNS resolution, external service status.

### Debug Mode

Enable debug logging by setting the log level in your environment:

```bash
DEBUG=health:* npm start
```

This will provide detailed logs of each health check operation.

## Advanced Usage

### Custom Health Checks

You can extend the health check system by adding custom checks:

```typescript
// In your application code
import { runHealthCheck } from './health';

// Run all health checks
const report = await runHealthCheck();

// Run specific service
const dbHealth = await runHealthCheck('database');
```

### Health Check Integration

Monitor health status in your application:

```typescript
import { getCurrentHealthStatus } from './health';

// Check if system is healthy before critical operations
const health = await getCurrentHealthStatus();
if (health.status === 'unhealthy') {
  // Handle unhealthy state
  console.error('System is unhealthy:', health.summary);
}
```

### Historical Analysis

Analyze health trends over time:

```typescript
import { getCurrentHealthStatus } from './health';

const report = await getCurrentHealthStatus();
const trends = report.trends;

console.log(`24h Uptime: ${trends.last24Hours.uptime}%`);
console.log(`Availability: ${trends.last24Hours.availability}%`);
console.log(`Critical Incidents: ${trends.last24Hours.criticalIncidents}`);
```

## Performance Considerations

- **Parallel Execution**: All health checks run concurrently to minimize response time
- **Efficient Resource Usage**: Lightweight checks that don't impact application performance
- **Configurable Intervals**: Adjust monitoring frequency based on your requirements
- **Memory Management**: Automatic cleanup of historical data to prevent memory leaks
- **Graceful Degradation**: System continues to function even if some health checks fail

## Security Notes

- Health check endpoints are publicly accessible (no authentication required for monitoring purposes)
- Sensitive information is not exposed in health check responses
- Database connection details are not logged or exposed
- AWS credentials are validated but not returned in responses
- Rate limiting may be needed for public deployments

## Support

For issues or questions about the health check system:

1. Check the troubleshooting section above
2. Review application logs for detailed error messages
3. Verify configuration and environment variables
4. Test individual health check endpoints
5. Check external service status and connectivity

---

**Health Check System v1.0.0** - Comprehensive monitoring for reliable applications 🏥