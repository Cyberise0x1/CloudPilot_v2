import type { Express } from "express";
import jwt from "jsonwebtoken";
import bcryptjs from "bcryptjs";
import { 
  loginSchema, 
  registerSchema, 
  refreshTokenSchema,
  type LoginRequest,
  type RegisterRequest,
  type RefreshTokenRequest
} from "@shared/schema";
import { storage } from "./storage";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-change-in-production";
const JWT_EXPIRES_IN = "15m";
const REFRESH_TOKEN_EXPIRES_IN_DAYS = 7;

interface JWTPayload {
  userId: string;
  email: string;
  role: string;
}

function generateAccessToken(payload: JWTPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
}

function generateRefreshToken(): string {
  return jwt.sign(
    { type: "refresh" },
    JWT_SECRET,
    { expiresIn: `${REFRESH_TOKEN_EXPIRES_IN_DAYS}d` }
  );
}

async function hashPassword(password: string): Promise<string> {
  return await bcryptjs.hash(password, 10);
}

async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return await bcryptjs.compare(password, hash);
}

function getUserSafeData(user: any) {
  const { passwordHash, ...safeUser } = user;
  return safeUser;
}

export function registerAuthRoutes(app: Express): void {
  // POST /api/auth/register - User registration
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = registerSchema.parse(req.body) as RegisterRequest;
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(409).json({ message: "User with this email already exists" });
      }

      // Hash password and create user
      const passwordHash = await hashPassword(validatedData.password);
      const user = await storage.createUser({
        email: validatedData.email,
        passwordHash,
        fullName: validatedData.fullName,
        role: 'user',
        isActive: true,
      });

      // Generate tokens
      const accessToken = generateAccessToken({
        userId: user.id,
        email: user.email,
        role: user.role,
      });

      const refreshToken = generateRefreshToken();
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + REFRESH_TOKEN_EXPIRES_IN_DAYS);
      
      await storage.createRefreshToken(user.id, refreshToken, expiresAt);

      res.status(201).json({
        user: getUserSafeData(user),
        accessToken,
        refreshToken,
      });
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  // POST /api/auth/login - User login
  app.post("/api/auth/login", async (req, res) => {
    try {
      const validatedData = loginSchema.parse(req.body) as LoginRequest;
      
      // Get user by email
      const user = await storage.getUserByEmail(validatedData.email);
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      // Verify password
      const isPasswordValid = await verifyPassword(validatedData.password, user.passwordHash);
      if (!isPasswordValid) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      // Check if user is active
      if (!user.isActive) {
        return res.status(403).json({ message: "Account is deactivated" });
      }

      // Generate tokens
      const accessToken = generateAccessToken({
        userId: user.id,
        email: user.email,
        role: user.role,
      });

      const refreshToken = generateRefreshToken();
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + REFRESH_TOKEN_EXPIRES_IN_DAYS);
      
      await storage.createRefreshToken(user.id, refreshToken, expiresAt);

      res.json({
        user: getUserSafeData(user),
        accessToken,
        refreshToken,
      });
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  // POST /api/auth/logout - User logout
  app.post("/api/auth/logout", async (req, res) => {
    try {
      const { refreshToken } = req.body as { refreshToken?: string };
      
      if (refreshToken) {
        await storage.deleteRefreshToken(refreshToken);
      }

      res.json({ message: "Logged out successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // POST /api/auth/refresh - Refresh JWT token
  app.post("/api/auth/refresh", async (req, res) => {
    try {
      const validatedData = refreshTokenSchema.parse(req.body) as RefreshTokenRequest;
      
      // Verify refresh token
      const storedToken = await storage.getRefreshToken(validatedData.refreshToken);
      if (!storedToken) {
        return res.status(401).json({ message: "Invalid refresh token" });
      }

      // Check if token is expired
      if (new Date() > storedToken.expiresAt) {
        await storage.deleteRefreshToken(validatedData.refreshToken);
        return res.status(401).json({ message: "Refresh token expired" });
      }

      // Get user
      const user = await storage.getUserById(storedToken.userId);
      if (!user || !user.isActive) {
        return res.status(401).json({ message: "User not found or inactive" });
      }

      // Delete old refresh token
      await storage.deleteRefreshToken(validatedData.refreshToken);

      // Generate new tokens
      const accessToken = generateAccessToken({
        userId: user.id,
        email: user.email,
        role: user.role,
      });

      const newRefreshToken = generateRefreshToken();
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + REFRESH_TOKEN_EXPIRES_IN_DAYS);
      
      await storage.createRefreshToken(user.id, newRefreshToken, expiresAt);

      res.json({
        accessToken,
        refreshToken: newRefreshToken,
        user: getUserSafeData(user),
      });
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: error.message });
    }
  });

  // GET /api/auth/me - Get current user info
  app.get("/api/auth/me", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({ message: "Authorization token required" });
      }

      const token = authHeader.substring(7);
      
      try {
        const decoded = jwt.verify(token, JWT_SECRET) as JWTPayload;
        const user = await storage.getUserById(decoded.userId);
        
        if (!user || !user.isActive) {
          return res.status(401).json({ message: "User not found or inactive" });
        }

        res.json({ user: getUserSafeData(user) });
      } catch (jwtError) {
        return res.status(401).json({ message: "Invalid or expired token" });
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });
}
