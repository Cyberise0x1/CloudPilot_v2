/**
 * SQL Injection Prevention Utilities
 * 
 * This module provides comprehensive utilities to prevent SQL injection attacks
 * including parameterized queries, input sanitization, query validation, and detection.
 */

import { QueryBuilder } from 'knex';

// ============================================================================
// TYPES AND INTERFACES
// ============================================================================

export interface QueryAnalysisResult {
  isSafe: boolean;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  issues: string[];
  suggestions: string[];
}

export interface ParameterizedQuery {
  query: string;
  params: any[];
}

export interface QueryValidationOptions {
  strictMode?: boolean;
  allowComments?: boolean;
  allowProcedures?: boolean;
  maxQueryLength?: number;
}

export interface SanitizationConfig {
  escapeHtml?: boolean;
  stripSql?: boolean;
  maxLength?: number;
  allowSpecialChars?: boolean;
}

// ============================================================================
// SQL INJECTION DETECTION PATTERNS
// ============================================================================

export const INJECTION_PATTERNS = {
  // Common SQL injection patterns
  SQL_KEYWORDS: /\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|EXECUTE|UNION|SCRIPT)\b/gi,
  
  // Comment patterns
  COMMENTS: /(--|\/\*|\*\/|#)/g,
  
  // Single quote injection
  UNESCAPED_QUOTES: /(?<!\\)['"]/g,
  
  // Dynamic query construction patterns
  CONCATENATION: /\+|\|\|/g,
  
  // Dangerous functions
  DANGEROUS_FUNCTIONS: /\b(EXEC|EXECUTE|xp_|sp_)\s*\(/gi,
  
  // Boolean-based injection
  BOOLEAN_INJECTION: /\b(OR|AND)\s+['"]?1['"]?\s*=\s*['"]?1\b/gi,
  
  // Time-based injection
  TIME_INJECTION: /\b(SLEEP|BENCHMARK|WAITFOR|DELAY)\s*\(/gi,
  
  // UNION-based injection
  UNION_INJECTION: /\bUNION\s+(ALL\s+)?SELECT\b/gi,
  
  // Script tag injection
  SCRIPT_TAG: /<\s*script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script\s*>/gi,
  
  // Multiple quotes
  MULTIPLE_QUOTES: /['"]{2,}/g,
  
  // Semicolons (statement separator)
  STATEMENT_SEPARATORS: /;/g,
  
  // OR 1=1 pattern
  OR_ONE_EQUALS_ONE: /\bOR\s+1\s*=\s*1\b/gi,
  
  // Always true conditions
  ALWAYS_TRUE: /(?:=|>|<|>=|<=)\s*(?:['"]?\d+['"]?|['"][^'"]*['"]?)\s*(?:OR|AND)\s*(?:['"]?\d+['"]?|['"][^'"]*['"]?)\s*=\s*(?:['"]?\d+['"]?|['"][^'"]*['"]?)/gi,
} as const;

// ============================================================================
// INPUT SANITIZATION
// ============================================================================

/**
 * Sanitizes input to prevent SQL injection
 */
export function sanitizeInput(input: any, config: SanitizationConfig = {}): string {
  if (input === null || input === undefined) {
    return '';
  }

  let value = String(input);

  // Apply max length limit
  if (config.maxLength && value.length > config.maxLength) {
    value = value.substring(0, config.maxLength);
  }

  // Escape dangerous SQL characters
  value = value
    .replace(/\\/g, '\\\\')    // Escape backslashes
    .replace(/'/g, "\\'")      // Escape single quotes
    .replace(/"/g, '\\"')      // Escape double quotes
    .replace(/\n/g, '\\n')     // Escape newlines
    .replace(/\r/g, '\\r')     // Escape carriage returns
    .replace(/\x00/g, '\\x00') // Escape null bytes
    .replace(/\x1a/g, '\\x1a'); // Escape EOF

  // Strip SQL keywords if requested
  if (config.stripSql) {
    for (const pattern of Object.values(INJECTION_PATTERNS)) {
      value = value.replace(pattern, '');
    }
  }

  return value;
}

/**
 * Sanitizes an array of inputs
 */
export function sanitizeInputArray(inputs: any[], config: SanitizationConfig = {}): string[] {
  return inputs.map(input => sanitizeInput(input, config));
}

/**
 * Validates and sanitizes object for SQL queries
 */
export function sanitizeObject(obj: Record<string, any>, config: SanitizationConfig = {}): Record<string, any> {
  const sanitized: Record<string, any> = {};
  
  for (const [key, value] of Object.entries(obj)) {
    // Sanitize keys
    const sanitizedKey = sanitizeInput(key, { ...config, maxLength: 128 });
    
    // Validate key is alphanumeric or underscore
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(sanitizedKey)) {
      throw new Error(`Invalid column name: ${key}`);
    }
    
    sanitized[sanitizedKey] = typeof value === 'string' 
      ? sanitizeInput(value, config)
      : value;
  }
  
  return sanitized;
}

// ============================================================================
// PARAMETERIZED QUERY HELPERS
// ============================================================================

/**
 * Creates a parameterized query from template and parameters
 */
export function createParameterizedQuery(
  template: string, 
  params: Record<string, any> = {}
): ParameterizedQuery {
  const queryParts: string[] = [];
  const queryParams: any[] = [];
  let paramIndex = 0;

  const processedTemplate = template.replace(/:\w+/g, (match) => {
    const paramName = match.substring(1);
    
    if (!(paramName in params)) {
      throw new Error(`Parameter '${paramName}' not provided`);
    }
    
    const value = params[paramName];
    queryParams.push(sanitizeInput(value));
    paramIndex++;
    
    return `$${paramIndex}`;
  });

  return {
    query: processedTemplate,
    params: queryParams
  };
}

/**
 * Creates a parameterized query from numbered placeholders
 */
export function createParameterizedQueryFromArray(
  template: string,
  params: any[]
): ParameterizedQuery {
  const processedTemplate = template.replace(/\?/g, () => {
    const param = params.shift();
    if (param === undefined) {
      throw new Error('Not enough parameters provided');
    }
    return sanitizeInput(param);
  });

  return {
    query: processedTemplate,
    params: []
  };
}

/**
 * Safe parameter extraction from object
 */
export function extractSafeParams(params: Record<string, any>): Record<string, any> {
  const safeParams: Record<string, any> = {};
  
  for (const [key, value] of Object.entries(params)) {
    // Only allow alphanumeric and underscore in parameter names
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(key)) {
      throw new Error(`Invalid parameter name: ${key}`);
    }
    safeParams[key] = typeof value === 'string' ? sanitizeInput(value) : value;
  }
  
  return safeParams;
}

// ============================================================================
// QUERY ANALYSIS
// ============================================================================

/**
 * Analyzes a query for potential SQL injection attempts
 */
export function analyzeQuery(query: string, options: QueryValidationOptions = {}): QueryAnalysisResult {
  const issues: string[] = [];
  const suggestions: string[] = [];
  const strictMode = options.strictMode ?? true;
  const maxLength = options.maxQueryLength ?? 10000;

  // Check query length
  if (query.length > maxLength) {
    issues.push(`Query exceeds maximum length of ${maxLength} characters`);
  }

  // Check for SQL keywords (potential injection)
  const sqlKeywordMatches = query.match(INJECTION_PATTERNS.SQL_KEYWORDS);
  if (sqlKeywordMatches) {
    const uniqueKeywords = [...new Set(sqlKeywordMatches.map(k => k.toUpperCase()))];
    if (strictMode || uniqueKeywords.some(k => !['SELECT', 'INSERT', 'UPDATE', 'DELETE'].includes(k))) {
      issues.push(`Potentially dangerous SQL keywords detected: ${uniqueKeywords.join(', ')}`);
    }
  }

  // Check for comments
  const commentMatches = query.match(INJECTION_PATTERNS.COMMENTS);
  if (commentMatches && !options.allowComments) {
    issues.push('SQL comments detected in query');
  }

  // Check for dangerous functions
  const functionMatches = query.match(INJECTION_PATTERNS.DANGEROUS_FUNCTIONS);
  if (functionMatches) {
    issues.push('Potentially dangerous database functions detected');
  }

  // Check for concatenation patterns
  if (query.match(INJECTION_PATTERNS.CONCATENATION)) {
    issues.push('String concatenation patterns detected (potential dynamic SQL)');
  }

  // Check for boolean injection patterns
  if (query.match(INJECTION_PATTERNS.BOOLEAN_INJECTION)) {
    issues.push('Boolean-based SQL injection pattern detected');
  }

  // Check for time-based injection
  if (query.match(INJECTION_PATTERNS.TIME_INJECTION)) {
    issues.push('Time-based SQL injection pattern detected');
  }

  // Check for UNION-based injection
  if (query.match(INJECTION_PATTERNS.UNION_INJECTION)) {
    issues.push('UNION-based SQL injection pattern detected');
  }

  // Check for script tags
  if (query.match(INJECTION_PATTERNS.SCRIPT_TAG)) {
    issues.push('Script tags detected in query');
  }

  // Check for multiple quotes
  if (query.match(INJECTION_PATTERNS.MULTIPLE_QUOTES)) {
    issues.push('Malformed quote patterns detected');
  }

  // Check for statement separators
  if (query.match(INJECTION_PATTERNS.STATEMENT_SEPARATORS)) {
    issues.push('Statement separators detected (multiple statements not allowed)');
  }

  // Generate suggestions
  if (issues.length > 0) {
    suggestions.push('Use parameterized queries instead of string concatenation');
    suggestions.push('Validate and sanitize all user inputs');
    suggestions.push('Implement query allowlist for dynamic queries');
    suggestions.push('Use ORM built-in query builders when possible');
  }

  // Determine risk level
  let riskLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' = 'LOW';
  if (issues.length > 5 || query.match(INJECTION_PATTERNS.TIME_INJECTION)) {
    riskLevel = 'CRITICAL';
  } else if (issues.length > 3) {
    riskLevel = 'HIGH';
  } else if (issues.length > 1) {
    riskLevel = 'MEDIUM';
  }

  return {
    isSafe: issues.length === 0,
    riskLevel,
    issues,
    suggestions
  };
}

/**
 * Validates a query before execution
 */
export function validateQuery(query: string, options: QueryValidationOptions = {}): void {
  const analysis = analyzeQuery(query, options);
  
  if (!analysis.isSafe) {
    const errorMessage = `Query validation failed (Risk Level: ${analysis.riskLevel}):\n${analysis.issues.join('\n')}`;
    throw new Error(errorMessage);
  }
}

// ============================================================================
// ORM QUERY VALIDATION
// ============================================================================

/**
 * Validates Knex query builder
 */
export function validateKnexQuery(queryBuilder: QueryBuilder): void {
  const sql = queryBuilder.toString();
  validateQuery(sql);
}

/**
 * Validates ORM where clauses
 */
export function validateWhereClause(where: any): void {
  if (typeof where === 'string') {
    // If where is a raw string, validate it
    if (where.includes('${') || where.includes('{{')) {
      throw new Error('Template string interpolation not allowed in where clauses');
    }
    validateQuery(where, { strictMode: true });
  } else if (typeof where === 'object' && where !== null) {
    // Recursively validate object-based where clauses
    for (const [key, value] of Object.entries(where)) {
      if (typeof value === 'string') {
        sanitizeInput(value);
      }
    }
  }
}

// ============================================================================
// SAFE QUERY CONSTRUCTION HELPERS
// ============================================================================

/**
 * Builds a safe SELECT query
 */
export function buildSafeSelectQuery(
  table: string,
  columns: string[] = ['*'],
  whereConditions: Record<string, any> = {},
  orderBy?: { column: string; direction?: 'ASC' | 'DESC' },
  limit?: number,
  offset?: number
): ParameterizedQuery {
  // Validate table name
  if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(table)) {
    throw new Error(`Invalid table name: ${table}`);
  }

  // Validate columns
  for (const column of columns) {
    if (column !== '*' && !/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(column)) {
      throw new Error(`Invalid column name: ${column}`);
    }
  }

  const sanitizedColumns = columns.map(col => col === '*' ? '*' : `"${sanitizeInput(col)}"`);
  let query = `SELECT ${sanitizedColumns.join(', ')} FROM "${sanitizeInput(table)}"`;
  
  const params: any[] = [];
  const whereClauses: string[] = [];

  for (const [column, value] of Object.entries(whereConditions)) {
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(column)) {
      throw new Error(`Invalid column name in where clause: ${column}`);
    }
    
    if (Array.isArray(value)) {
      // IN clause
      const placeholders = value.map(() => '?').join(', ');
      whereClauses.push(`"${sanitizeInput(column)}" IN (${placeholders})`);
      params.push(...value.map(v => sanitizeInput(v)));
    } else {
      // Simple equality
      whereClauses.push(`"${sanitizeInput(column)}" = ?`);
      params.push(sanitizeInput(value));
    }
  }

  if (whereClauses.length > 0) {
    query += ` WHERE ${whereClauses.join(' AND ')}`;
  }

  if (orderBy) {
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(orderBy.column)) {
      throw new Error(`Invalid order by column: ${orderBy.column}`);
    }
    const direction = orderBy.direction || 'ASC';
    query += ` ORDER BY "${sanitizeInput(orderBy.column)}" ${direction}`;
  }

  if (limit !== undefined) {
    if (typeof limit !== 'number' || limit < 0) {
      throw new Error('Invalid limit value');
    }
    query += ` LIMIT ${limit}`;
  }

  if (offset !== undefined) {
    if (typeof offset !== 'number' || offset < 0) {
      throw new Error('Invalid offset value');
    }
    query += ` OFFSET ${offset}`;
  }

  return { query, params };
}

/**
 * Builds a safe INSERT query
 */
export function buildSafeInsertQuery(
  table: string,
  data: Record<string, any>
): ParameterizedQuery {
  // Validate table name
  if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(table)) {
    throw new Error(`Invalid table name: ${table}`);
  }

  const sanitizedData = sanitizeObject(data);
  const columns = Object.keys(sanitizedData);
  const placeholders = columns.map(() => '?').join(', ');
  const columnNames = columns.map(col => `"${col}"`).join(', ');

  const query = `INSERT INTO "${sanitizeInput(table)}" (${columnNames}) VALUES (${placeholders})`;
  const params = Object.values(sanitizedData);

  return { query, params };
}

/**
 * Builds a safe UPDATE query
 */
export function buildSafeUpdateQuery(
  table: string,
  data: Record<string, any>,
  whereConditions: Record<string, any>
): ParameterizedQuery {
  // Validate table name
  if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(table)) {
    throw new Error(`Invalid table name: ${table}`);
  }

  const sanitizedData = sanitizeObject(data);
  const sanitizedWhere = sanitizeObject(whereConditions);

  const setClauses = Object.keys(sanitizedData).map(column => `"${column}" = ?`);
  const whereClauses = Object.keys(sanitizedWhere).map(column => `"${column}" = ?`);

  const query = `UPDATE "${sanitizeInput(table)}" SET ${setClauses.join(', ')} WHERE ${whereClauses.join(' AND ')}`;
  const params = [...Object.values(sanitizedData), ...Object.values(sanitizedWhere)];

  return { query, params };
}

/**
 * Builds a safe DELETE query
 */
export function buildSafeDeleteQuery(
  table: string,
  whereConditions: Record<string, any>
): ParameterizedQuery {
  // Validate table name
  if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(table)) {
    throw new Error(`Invalid table name: ${table}`);
  }

  const sanitizedWhere = sanitizeObject(whereConditions);
  const whereClauses = Object.keys(sanitizedWhere).map(column => `"${column}" = ?`);

  const query = `DELETE FROM "${sanitizeInput(table)}" WHERE ${whereClauses.join(' AND ')}`;
  const params = Object.values(sanitizedWhere);

  return { query, params };
}

// ============================================================================
// DYNAMIC QUERY BUILDERS
// ============================================================================

/**
 * Safe ORDER BY clause builder
 */
export function buildSafeOrderBy(
  allowedColumns: string[],
  column?: string,
  direction?: 'ASC' | 'DESC'
): string {
  if (!column) {
    return '';
  }

  if (!allowedColumns.includes(column)) {
    throw new Error(`Column '${column}' not allowed in ORDER BY clause`);
  }

  const safeDirection = direction && (direction === 'ASC' || direction === 'DESC') 
    ? direction 
    : 'ASC';

  return ` ORDER BY "${sanitizeInput(column)}" ${safeDirection}`;
}

/**
 * Safe LIMIT and OFFSET builder
 */
export function buildSafeLimitOffset(limit?: number, offset?: number): string {
  let clause = '';

  if (limit !== undefined) {
    if (typeof limit !== 'number' || limit < 0 || limit > 10000) {
      throw new Error('Invalid LIMIT value (must be 0-10000)');
    }
    clause += ` LIMIT ${limit}`;
  }

  if (offset !== undefined) {
    if (typeof offset !== 'number' || offset < 0) {
      throw new Error('Invalid OFFSET value (must be >= 0)');
    }
    clause += ` OFFSET ${offset}`;
  }

  return clause;
}

/**
 * Safe pagination builder
 */
export function buildSafePagination(page: number = 1, pageSize: number = 20): { limit: number; offset: number } {
  if (typeof page !== 'number' || page < 1) {
    throw new Error('Invalid page number (must be >= 1)');
  }

  if (typeof pageSize !== 'number' || pageSize < 1 || pageSize > 100) {
    throw new Error('Invalid page size (must be 1-100)');
  }

  return {
    limit: pageSize,
    offset: (page - 1) * pageSize
  };
}

// ============================================================================
// QUERY BUILDER COMPOSER
// ============================================================================

/**
 * Composes a safe query from components
 */
export class SafeQueryBuilder {
  private table: string;
  private columns: string[] = ['*'];
  private whereClauses: string[] = [];
  private orderByClauses: string[] = [];
  private params: any[] = [];
  private allowedTables: Set<string> = new Set();
  private allowedColumns: Map<string, Set<string>> = new Map();

  constructor(table: string, options: {
    allowedTables?: string[];
    allowedColumns?: Record<string, string[]>;
  } = {}) {
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(table)) {
      throw new Error(`Invalid table name: ${table}`);
    }

    this.table = table;

    if (options.allowedTables) {
      this.allowedTables = new Set(options.allowedTables);
      if (!this.allowedTables.has(table)) {
        throw new Error(`Table '${table}' not in allowlist`);
      }
    }

    if (options.allowedColumns) {
      for (const [tableName, columns] of Object.entries(options.allowedColumns)) {
        this.allowedColumns.set(tableName, new Set(columns));
      }
    }
  }

  select(columns: string[] = ['*']): this {
    for (const column of columns) {
      if (column !== '*' && !this.isColumnAllowed(column)) {
        throw new Error(`Column '${column}' not allowed`);
      }
    }
    this.columns = columns;
    return this;
  }

  where(column: string, operator: string, value: any): this {
    if (!this.isColumnAllowed(column)) {
      throw new Error(`Column '${column}' not allowed`);
    }

    const allowedOperators = ['=', '!=', '<', '>', '<=', '>=', 'LIKE', 'IN'];
    if (!allowedOperators.includes(operator.toUpperCase())) {
      throw new Error(`Operator '${operator}' not allowed`);
    }

    this.whereClauses.push(`"${sanitizeInput(column)}" ${operator} ?`);
    this.params.push(sanitizeInput(value));
    return this;
  }

  whereIn(column: string, values: any[]): this {
    if (!this.isColumnAllowed(column)) {
      throw new Error(`Column '${column}' not allowed`);
    }

    const placeholders = values.map(() => '?').join(', ');
    this.whereClauses.push(`"${sanitizeInput(column)}" IN (${placeholders})`);
    this.params.push(...values.map(v => sanitizeInput(v)));
    return this;
  }

  orderBy(column: string, direction: 'ASC' | 'DESC' = 'ASC'): this {
    if (!this.isColumnAllowed(column)) {
      throw new Error(`Column '${column}' not allowed`);
    }

    this.orderByClauses.push(`"${sanitizeInput(column)}" ${direction}`);
    return this;
  }

  limit(limit: number): this {
    if (typeof limit !== 'number' || limit < 0 || limit > 10000) {
      throw new Error('Invalid LIMIT value (must be 0-10000)');
    }
    this.params.push(limit);
    return this;
  }

  offset(offset: number): this {
    if (typeof offset !== 'number' || offset < 0) {
      throw new Error('Invalid OFFSET value (must be >= 0)');
    }
    this.params.push(offset);
    return this;
  }

  build(): ParameterizedQuery {
    let query = `SELECT ${this.columns.map(col => col === '*' ? '*' : `"${sanitizeInput(col)}"`).join(', ')} FROM "${sanitizeInput(this.table)}"`;

    if (this.whereClauses.length > 0) {
      query += ` WHERE ${this.whereClauses.join(' AND ')}`;
    }

    if (this.orderByClauses.length > 0) {
      query += ` ORDER BY ${this.orderByClauses.join(', ')}`;
    }

    return { query, params: this.params };
  }

  private isColumnAllowed(column: string): boolean {
    if (column === '*') {
      return true;
    }

    const allowedColumns = this.allowedColumns.get(this.table);
    if (!allowedColumns) {
      // If no allowlist specified, allow any valid column name
      return /^[a-zA-Z_][a-zA-Z0-9_]*$/.test(column);
    }

    return allowedColumns.has(column);
  }
}

// ============================================================================
// EXPORTS
// ============================================================================

export const sqlProtection = {
  // Core functions
  sanitizeInput,
  sanitizeInputArray,
  sanitizeObject,
  analyzeQuery,
  validateQuery,
  createParameterizedQuery,
  createParameterizedQueryFromArray,
  extractSafeParams,

  // Query builders
  buildSafeSelectQuery,
  buildSafeInsertQuery,
  buildSafeUpdateQuery,
  buildSafeDeleteQuery,
  buildSafeOrderBy,
  buildSafeLimitOffset,
  buildSafePagination,
  SafeQueryBuilder,

  // ORM helpers
  validateKnexQuery,
  validateWhereClause,

  // Constants
  INJECTION_PATTERNS
};

export default sqlProtection;
