import { Request, Response, NextFunction } from 'express';

/**
 * Security Headers Middleware Configuration
 * Provides comprehensive security headers for web applications
 */

// Environment types
export type Environment = 'development' | 'staging' | 'production';

// CORS Configuration interface
export interface CORSConfig {
  origin: string | string[] | boolean;
  methods: string[];
  allowedHeaders: string[];
  exposedHeaders: string[];
  credentials: boolean;
  maxAge?: number;
}

// Security Headers Configuration interface
export interface SecurityConfig {
  environment: Environment;
  csp: {
    enabled: boolean;
    directives: Record<string, string | string[]>;
  };
  hsts: {
    enabled: boolean;
    maxAge: number;
    includeSubDomains: boolean;
    preload: boolean;
  };
  cors: CORSConfig;
  additionalHeaders: Record<string, string>;
}

// Default security configurations for different environments
const SECURITY_CONFIGS: Record<Environment, SecurityConfig> = {
  development: {
    environment: 'development',
    csp: {
      enabled: true,
      directives: {
        'default-src': ["'self'"],
        'script-src': ["'self'", "'unsafe-inline'", "'unsafe-eval'", 'http://localhost:3000', 'http://localhost:3001'],
        'style-src': ["'self'", "'unsafe-inline'", 'http://localhost:3000'],
        'img-src': ["'self'", 'data:', 'http:', 'https:', 'blob:'],
        'font-src': ["'self'", 'data:', 'http:', 'https:'],
        'connect-src': ["'self'", 'ws:', 'wss:', 'http://localhost:3000', 'http://localhost:3001', 'http://localhost:5432', 'https://api.example.com'],
        'frame-ancestors': ["'self'"],
        'base-uri': ["'self'"],
        'form-action': ["'self'"],
        'object-src': ["'none'"],
        'media-src': ["'self'", 'blob:'],
        'worker-src': ["'self'", 'blob:'],
        'child-src': ["'self'", 'blob:']
      }
    },
    hsts: {
      enabled: false, // Disabled in development
      maxAge: 0,
      includeSubDomains: false,
      preload: false
    },
    cors: {
      origin: true, // Allow all origins in development
      methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
      exposedHeaders: ['X-Total-Count', 'X-Page-Count'],
      credentials: true,
      maxAge: 86400 // 24 hours
    },
    additionalHeaders: {
      'X-Frame-Options': 'SAMEORIGIN',
      'X-Content-Type-Options': 'nosniff',
      'X-XSS-Protection': '0', // Modern browsers don't need this
      'Referrer-Policy': 'strict-origin-when-cross-origin',
      'Permissions-Policy': [
        'geolocation=(self)',
        'microphone=()',
        'camera=()',
        'payment=(self)',
        'usb=()',
        'magnetometer=()',
        'gyroscope=()',
        'speaker=(self)',
        'fullscreen=(self)',
        'sync-xhr=(self)'
      ].join(', ')
    }
  },
  
  staging: {
    environment: 'staging',
    csp: {
      enabled: true,
      directives: {
        'default-src': ["'self'"],
        'script-src': ["'self'", "'unsafe-inline'", 'https://cdn.staging.example.com'],
        'style-src': ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        'img-src': ["'self'", 'data:', 'https:', 'blob:'],
        'font-src': ["'self'", 'https://fonts.gstatic.com'],
        'connect-src': ["'self'", 'https://api.staging.example.com', 'wss://api.staging.example.com'],
        'frame-ancestors': ["'none'"],
        'base-uri': ["'self'"],
        'form-action': ["'self'"],
        'object-src': ["'none'"],
        'media-src': ["'self'"],
        'worker-src': ["'self'"],
        'child-src': ["'none'"]
      }
    },
    hsts: {
      enabled: true,
      maxAge: 31536000, // 1 year
      includeSubDomains: true,
      preload: false
    },
    cors: {
      origin: ['https://staging.example.com', 'https://app.staging.example.com'],
      methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'X-API-Key'],
      exposedHeaders: ['X-Total-Count', 'X-Page-Count'],
      credentials: true,
      maxAge: 86400
    },
    additionalHeaders: {
      'X-Frame-Options': 'DENY',
      'X-Content-Type-Options': 'nosniff',
      'X-XSS-Protection': '0',
      'Referrer-Policy': 'strict-origin-when-cross-origin',
      'Permissions-Policy': [
        'geolocation=()',
        'microphone=()',
        'camera=()',
        'payment=(self)',
        'usb=()',
        'magnetometer=()',
        'gyroscope=()',
        'speaker=(self)',
        'fullscreen=(self)',
        'sync-xhr=(self)'
      ].join(', ')
    }
  },
  
  production: {
    environment: 'production',
    csp: {
      enabled: true,
      directives: {
        'default-src': ["'self'"],
        'script-src': ["'self'"], // No unsafe-inline in production
        'style-src': ["'self'", 'https://fonts.googleapis.com'],
        'img-src': ["'self'", 'data:', 'https:', 'blob:'],
        'font-src': ["'self'", 'https://fonts.gstatic.com'],
        'connect-src': ["'self'", 'https://api.example.com', 'wss://api.example.com'],
        'frame-ancestors': ["'none'"],
        'base-uri': ["'self'"],
        'form-action': ["'self'"],
        'object-src': ["'none'"],
        'media-src': ["'self'"],
        'worker-src': ["'self'"],
        'child-src': ["'none'"]
      }
    },
    hsts: {
      enabled: true,
      maxAge: 63072000, // 2 years
      includeSubDomains: true,
      preload: true // Only set to true if you understand the implications
    },
    cors: {
      origin: ['https://example.com', 'https://app.example.com'],
      methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'X-API-Key'],
      exposedHeaders: ['X-Total-Count', 'X-Page-Count'],
      credentials: true,
      maxAge: 86400
    },
    additionalHeaders: {
      'X-Frame-Options': 'DENY',
      'X-Content-Type-Options': 'nosniff',
      'X-XSS-Protection': '0',
      'Referrer-Policy': 'strict-origin-when-cross-origin',
      'Permissions-Policy': [
        'geolocation=()',
        'microphone=()',
        'camera=()',
        'payment=(self)',
        'usb=()',
        'magnetometer=()',
        'gyroscope=()',
        'speaker=(self)',
        'fullscreen=(self)',
        'sync-xhr=(self)'
      ].join(', ')
    }
  }
};

// Content Security Policy Header Builder
function buildCSPHeader(directives: Record<string, string | string[]>): string {
  return Object.entries(directives)
    .map(([key, value]) => {
      const directiveValue = Array.isArray(value) ? value.join(' ') : value;
      return `${key} ${directiveValue}`;
    })
    .join('; ');
}

// HSTS Header Builder
function buildHSTSHeader(hstsConfig: SecurityConfig['hsts']): string | null {
  if (!hstsConfig.enabled) return null;
  
  let header = `max-age=${hstsConfig.maxAge}`;
  if (hstsConfig.includeSubDomains) {
    header += '; includeSubDomains';
  }
  if (hstsConfig.preload) {
    header += '; preload';
  }
  return header;
}

// CORS Middleware
function corsMiddleware(config: CORSConfig) {
  return (req: Request, res: Response, next: NextFunction) => {
    // Handle preflight requests
    if (req.method === 'OPTIONS') {
      res.set({
        'Access-Control-Allow-Methods': config.methods.join(', '),
        'Access-Control-Allow-Headers': config.allowedHeaders.join(', '),
        'Access-Control-Max-Age': config.maxAge?.toString() || '86400'
      });
      
      if (config.credentials) {
        res.set('Access-Control-Allow-Credentials', 'true');
      }
      
      if (config.origin !== true) {
        res.set('Access-Control-Allow-Origin', Array.isArray(config.origin) ? config.origin.join(', ') : config.origin);
      } else {
        res.set('Access-Control-Allow-Origin', req.headers.origin || '*');
      }
      
      if (config.exposedHeaders.length > 0) {
        res.set('Access-Control-Expose-Headers', config.exposedHeaders.join(', '));
      }
      
      return res.status(204).end();
    }
    
    // Set CORS headers for actual requests
    if (config.origin !== true) {
      res.set('Access-Control-Allow-Origin', Array.isArray(config.origin) ? config.origin.join(', ') : config.origin);
    } else {
      res.set('Access-Control-Allow-Origin', req.headers.origin || '*');
    }
    
    if (config.credentials) {
      res.set('Access-Control-Allow-Credentials', 'true');
    }
    
    res.set('Access-Control-Allow-Methods', config.methods.join(', '));
    res.set('Access-Control-Allow-Headers', config.allowedHeaders.join(', '));
    
    if (config.exposedHeaders.length > 0) {
      res.set('Access-Control-Expose-Headers', config.exposedHeaders.join(', '));
    }
    
    next();
  };
}

/**
 * Create security headers middleware with custom configuration
 * @param customConfig Optional custom security configuration
 * @returns Express middleware function
 */
export function createSecurityHeaders(customConfig?: Partial<SecurityConfig>) {
  return (req: Request, res: Response, next: NextFunction) => {
    // Determine environment
    const env = (process.env.NODE_ENV || 'development') as Environment;
    
    // Merge configurations
    const config: SecurityConfig = {
      ...SECURITY_CONFIGS[env],
      ...customConfig,
      csp: {
        ...SECURITY_CONFIGS[env].csp,
        ...customConfig?.csp
      },
      hsts: {
        ...SECURITY_CONFIGS[env].hsts,
        ...customConfig?.hsts
      },
      cors: {
        ...SECURITY_CONFIGS[env].cors,
        ...customConfig?.cors
      },
      additionalHeaders: {
        ...SECURITY_CONFIGS[env].additionalHeaders,
        ...customConfig?.additionalHeaders
      }
    };
    
    // Set Content Security Policy
    if (config.csp.enabled) {
      const cspHeader = buildCSPHeader(config.csp.directives);
      res.set('Content-Security-Policy', cspHeader);
    }
    
    // Set HSTS header
    const hstsHeader = buildHSTSHeader(config.hsts);
    if (hstsHeader) {
      res.set('Strict-Transport-Security', hstsHeader);
    }
    
    // Set additional security headers
    Object.entries(config.additionalHeaders).forEach(([header, value]) => {
      res.set(header, value);
    });
    
    // Add custom headers
    if (customConfig?.additionalHeaders) {
      Object.entries(customConfig.additionalHeaders).forEach(([header, value]) => {
        res.set(header, value);
      });
    }
    
    // Set additional security headers for production
    if (env === 'production') {
      res.set('X-DNS-Prefetch-Control', 'off');
      res.set('Strict-Transport-Security', hstsHeader || 'max-age=63072000; includeSubDomains; preload');
    }
    
    next();
  };
}

/**
 * Apply CORS middleware with specified configuration
 * @param config CORS configuration
 * @returns Express middleware function
 */
export function applyCORS(config?: Partial<CORSConfig>) {
  const env = (process.env.NODE_ENV || 'development') as Environment;
  const corsConfig = { ...SECURITY_CONFIGS[env].cors, ...config };
  return corsMiddleware(corsConfig);
}

/**
 * Get security headers configuration for current environment
 * @param environment Target environment
 * @returns Security configuration
 */
export function getSecurityConfig(environment?: Environment): SecurityConfig {
  const env = environment || (process.env.NODE_ENV || 'development') as Environment;
  return SECURITY_CONFIGS[env];
}

/**
 * Validate security configuration
 * @param config Security configuration to validate
 * @returns Validation result
 */
export function validateSecurityConfig(config: SecurityConfig): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Validate CSP directives
  if (config.csp.enabled) {
    const requiredDirectives = ['default-src', 'object-src'];
    requiredDirectives.forEach(directive => {
      if (!config.csp.directives[directive]) {
        errors.push(`Missing required CSP directive: ${directive}`);
      }
    });
  }
  
  // Validate HSTS configuration
  if (config.hsts.enabled) {
    if (config.hsts.maxAge < 0) {
      errors.push('HSTS maxAge must be non-negative');
    }
  }
  
  // Validate CORS configuration
  if (!config.cors.methods.includes('GET') || !config.cors.methods.includes('OPTIONS')) {
    errors.push('CORS must allow GET and OPTIONS methods');
  }
  
  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Security headers middleware with default configuration
 */
export const securityHeaders = createSecurityHeaders();

/**
 * CORS middleware with default configuration
 */
export const corsHandler = applyCORS();

/**
 * Utility function to add custom security headers
 * @param headers Headers to add
 */
export function addCustomHeaders(headers: Record<string, string>) {
  return (req: Request, res: Response, next: NextFunction) => {
    Object.entries(headers).forEach(([header, value]) => {
      res.set(header, value);
    });
    next();
  };
}

/**
 * Utility function to remove specific headers for security
 * @param headers Headers to remove
 */
export function removeHeaders(headers: string[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    headers.forEach(header => {
      res.removeHeader(header);
    });
    next();
  };
}

export default {
  createSecurityHeaders,
  applyCORS,
  getSecurityConfig,
  validateSecurityConfig,
  securityHeaders,
  corsHandler,
  addCustomHeaders,
  removeHeaders,
  SECURITY_CONFIGS
};
