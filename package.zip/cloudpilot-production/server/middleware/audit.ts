import { Request, Response, NextFunction } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { auditService, CreateAuditLogOptions } from '../services/audit-service';
import { logger, LogLevel } from './logger';

/**
 * Comprehensive Audit Logging Middleware
 * 
 * This middleware provides comprehensive audit trail functionality including:
 * - Automatic audit logging for all API requests
 * - User action tracking and correlation
 * - AWS operation logging with detailed metadata
 * - Authentication events logging and security monitoring
 * - Security event detection and alerting
 * - Audit data sanitization and PII protection
 * - Performance impact minimization through async logging
 * - Advanced filtering and categorization
 * 
 * Features:
 * - Async audit logging to minimize performance impact
 * - Automatic data sanitization for sensitive information
 * - Correlation ID tracking across requests
 * - Request/response body capture and analysis
 * - Performance monitoring and slow operation detection
 * - Security threat detection and suspicious activity logging
 * - Granular filtering and configurable audit levels
 * - Database-backed audit storage with advanced querying
 * 
 * Usage Examples:
 * 
 * 1. Basic audit middleware setup:
 *    ```typescript
 *    import { auditMiddleware } from './middleware/audit';
 *    app.use(auditMiddleware());
 *    ```
 * 
 * 2. Custom audit configuration:
 *    ```typescript
 *    app.use(auditMiddleware({
 *      captureBodies: true,
 *      sanitizeBodies: true,
 *      excludePaths: ['/health', '/metrics'],
 *      includeBodiesForPaths: ['/api/auth/login'],
 *      auditLevel: 'detailed'
 *    }));
 *    ```
 * 
 * 3. Manual audit logging:
 *    ```typescript
 *    // In route handlers
 *    req.auditLog('user.login', 'authentication', {
 *      status: 'success',
 *      details: { method: 'password' }
 *    });
 *    ```
 * 
 * 4. Security event logging:
 *    ```typescript
 *    req.logSecurityEvent('suspicious_ip_detected', 'high', {
 *      ipAddress: '192.168.1.100',
 *      reason: 'Multiple failed attempts'
 *    });
 *    ```
 */

// Configuration interfaces
export interface AuditMiddlewareConfig {
  // Performance and filtering options
  enabled?: boolean;
  auditLevel?: 'basic' | 'detailed' | 'comprehensive';
  asyncLogging?: boolean;
  bufferSize?: number;
  flushInterval?: number;
  
  // Request/response capture options
  captureBodies?: boolean;
  captureHeaders?: boolean;
  sanitizeBodies?: boolean;
  maxBodySize?: number;
  
  // Filtering options
  excludePaths?: string[];
  includePaths?: string[];
  includeBodiesForPaths?: string[];
  excludeBodiesForPaths?: string[];
  
  // Security and authentication options
  logAuthenticationAttempts?: boolean;
  logSecurityEvents?: boolean;
  logSuspiciousRequests?: boolean;
  detectSuspiciousActivity?: boolean;
  
  // AWS operation tracking
  trackAWSOperations?: boolean;
  awsOperationPrefix?: string;
  
  // Performance monitoring
  slowRequestThreshold?: number;
  logSlowRequests?: boolean;
  
  // User context options
  includeUserContext?: boolean;
  requiredUserFields?: string[];
  
  // Custom filtering functions
  shouldAuditRequest?: (req: Request) => boolean;
  sanitizeRequestData?: (data: any) => any;
  categorizeRequest?: (req: Request) => string;
}

export interface AuditContext {
  correlationId: string;
  requestId: string;
  userId?: string;
  userEmail?: string;
  sessionId?: string;
  ipAddress: string;
  userAgent?: string;
  requestStartTime: number;
  auditEnabled: boolean;
}

// Suspicious activity patterns
const SUSPICIOUS_PATTERNS = {
  path: [
    /admin/i,
    /wp-admin/i,
    /\.env/i,
    /\.git/i,
    /config/i,
    /password/i,
    /login/i,
    /auth/i,
    /\.\./,
    /script/i,
    /javascript/i,
    /vulnerable/i,
    /exploit/i,
    /union.*select/i,
    /drop.*table/i,
    /delete.*from/i
  ],
  userAgent: [
    /bot/i,
    /crawler/i,
    /spider/i,
    /scanner/i,
    /sqlmap/i,
    /nikto/i,
    /nmap/i,
    /masscan/i,
    /zap/i,
    /burp/i,
    /dirb/i,
    /gobuster/i
  ],
  payload: [
    /<script/i,
    /javascript:/i,
    /onload/i,
    /onerror/i,
    /vbscript:/i,
    /data:/i,
    /file:/i,
    /ftp:/i,
    /\\\\/i,
    /etc\/passwd/i,
    /boot\.ini/i,
    /cmd\.exe/i,
    /powershell/i,
    /base64/i,
    /eval\(/i,
    /function\(/i
  ]
};

// Sensitive data patterns for sanitization
const SENSITIVE_PATTERNS = {
  fields: [
    /password/i,
    /passwd/i,
    /pwd/i,
    /secret/i,
    /token/i,
    /key/i,
    /ssn/i,
    /social.*security/i,
    /credit.*card/i,
    /card.*number/i,
    /cvv/i,
    /authorization/i,
    /bearer/i,
    /apikey/i,
    /api_key/i,
    /refresh.*token/i,
    /access.*token/i,
    /private.*key/i,
    /certificate/i,
    /credentials/i
  ],
  valuePatterns: [
    /eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*/, // JWT
    /sk_[a-zA-Z0-9]{48}/, // Stripe secret key
    /AKIA[0-9A-Z]{16}/, // AWS access key
    /[a-f0-9]{32}/i, // MD5 hash
    /[a-f0-9]{40}/i, // SHA1 hash
    /[a-fA-F0-9]{64}/, // SHA256 hash
    /[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}/, // Credit card
  ]
};

// Default configuration
const DEFAULT_CONFIG: Required<AuditMiddlewareConfig> = {
  enabled: true,
  auditLevel: 'detailed',
  asyncLogging: true,
  bufferSize: 100,
  flushInterval: 5000,
  
  captureBodies: false,
  captureHeaders: false,
  sanitizeBodies: true,
  maxBodySize: 10240, // 10KB
  
  excludePaths: ['/health', '/metrics', '/favicon.ico'],
  includePaths: [],
  includeBodiesForPaths: ['/api/auth/login', '/api/auth/register', '/api/users'],
  excludeBodiesForPaths: [],
  
  logAuthenticationAttempts: true,
  logSecurityEvents: true,
  logSuspiciousRequests: true,
  detectSuspiciousActivity: true,
  
  trackAWSOperations: true,
  awsOperationPrefix: 'aws.',
  
  slowRequestThreshold: 1000,
  logSlowRequests: true,
  
  includeUserContext: true,
  requiredUserFields: ['id', 'email', 'role'],
  
  shouldAuditRequest: () => true,
  sanitizeRequestData: (data) => sanitizeSensitiveData(data),
  categorizeRequest: categorizeRequestByPath
};

// Audit buffer for async logging
class AuditBuffer {
  private buffer: CreateAuditLogOptions[] = [];
  private config: Required<AuditMiddlewareConfig>;
  private flushTimer?: NodeJS.Timeout;
  
  constructor(config: Required<AuditMiddlewareConfig>) {
    this.config = config;
  }
  
  add(auditLog: CreateAuditLogOptions): void {
    this.buffer.push(auditLog);
    
    if (this.buffer.length >= this.config.bufferSize) {
      this.flush();
    } else {
      this.scheduleFlush();
    }
  }
  
  private scheduleFlush(): void {
    if (this.flushTimer) return;
    
    this.flushTimer = setTimeout(() => {
      this.flush();
    }, this.config.flushInterval);
  }
  
  async flush(): Promise<void> {
    if (this.buffer.length === 0) return;
    
    const logs = [...this.buffer];
    this.buffer = [];
    
    if (this.flushTimer) {
      clearTimeout(this.flushTimer);
      this.flushTimer = undefined;
    }
    
    // Process logs in batches to avoid overwhelming the database
    const batchSize = 10;
    for (let i = 0; i < logs.length; i += batchSize) {
      const batch = logs.slice(i, i + batchSize);
      await Promise.allSettled(
        batch.map(log => auditService.createAuditLog(log))
      );
    }
  }
  
  clear(): void {
    this.buffer = [];
    if (this.flushTimer) {
      clearTimeout(this.flushTimer);
      this.flushTimer = undefined;
    }
  }
}

// Utility functions
function sanitizeSensitiveData(data: any): any {
  if (!data || typeof data !== 'object') {
    return data;
  }
  
  if (Array.isArray(data)) {
    return data.map(item => sanitizeSensitiveData(item));
  }
  
  const sanitized: any = {};
  
  for (const [key, value] of Object.entries(data)) {
    // Check if key matches sensitive patterns
    const isSensitiveKey = SENSITIVE_PATTERNS.fields.some(pattern => pattern.test(key));
    
    if (isSensitiveKey) {
      sanitized[key] = '[FILTERED]';
    } else if (typeof value === 'string') {
      // Check if value contains sensitive patterns
      const isSensitiveValue = SENSITIVE_PATTERNS.valuePatterns.some(pattern => pattern.test(value)) ||
                               SENSITIVE_PATTERNS.fields.some(pattern => pattern.test(value));
      
      if (isSensitiveValue) {
        sanitized[key] = '[FILTERED]';
      } else {
        sanitized[key] = value;
      }
    } else if (typeof value === 'object') {
      sanitized[key] = sanitizeSensitiveData(value);
    } else {
      sanitized[key] = value;
    }
  }
  
  return sanitized;
}

function categorizeRequestByPath(req: Request): string {
  const path = req.path.toLowerCase();
  
  if (path.includes('/auth') || path.includes('/login') || path.includes('/register')) {
    return 'authentication';
  }
  
  if (path.includes('/api/aws') || path.includes('/aws')) {
    return 'aws_operations';
  }
  
  if (path.includes('/api/users') || path.includes('/user')) {
    return 'user_management';
  }
  
  if (path.includes('/api/admin') || path.includes('/admin')) {
    return 'administration';
  }
  
  if (path.includes('/api/files') || path.includes('/upload') || path.includes('/storage')) {
    return 'file_operations';
  }
  
  if (path.includes('/api/security') || path.includes('/security')) {
    return 'security';
  }
  
  return 'api_requests';
}

function detectSuspiciousActivity(req: Request, res: Response): {
  isSuspicious: boolean;
  reasons: string[];
  severity: 'low' | 'medium' | 'high' | 'critical';
} {
  const reasons: string[] = [];
  let severity: 'low' | 'medium' | 'high' | 'critical' = 'low';
  
  // Check path patterns
  if (SUSPICIOUS_PATTERNS.path.some(pattern => pattern.test(req.path))) {
    reasons.push('Suspicious path pattern');
    severity = 'high';
  }
  
  // Check user agent
  const userAgent = req.headers['user-agent'] || '';
  if (SUSPICIOUS_PATTERNS.userAgent.some(pattern => pattern.test(userAgent))) {
    reasons.push('Suspicious user agent');
    severity = severity === 'low' ? 'medium' : severity;
  }
  
  // Check for suspicious request characteristics
  const referer = req.headers.referer || '';
  const origin = req.headers.origin || '';
  
  if (referer && !referer.includes(req.get('host') || '')) {
    reasons.push('External referer');
  }
  
  if (origin && !origin.includes(req.get('host') || '')) {
    reasons.push('External origin');
  }
  
  // Check for rapid requests from same IP (rate limiting bypass)
  // This would require additional tracking logic
  
  const isSuspicious = reasons.length > 0;
  if (isSuspicious && reasons.length > 2) {
    severity = 'critical';
  }
  
  return { isSuspicious, reasons, severity };
}

function getRequestBody(req: Request, maxSize: number): any {
  try {
    if (!req.body || typeof req.body !== 'object') {
      return req.body;
    }
    
    const bodyString = JSON.stringify(req.body);
    if (bodyString.length > maxSize) {
      return {
        _truncated: true,
        _originalSize: bodyString.length,
        _message: 'Request body too large for audit logging'
      };
    }
    
    return req.body;
  } catch (error) {
    return { _error: 'Unable to capture request body' };
  }
}

function getResponseBody(req: Request, res: Response, maxSize: number): any {
  try {
    const originalJson = res.json;
    const originalSend = res.send;
    
    let responseBody: any = null;
    
    res.json = function(body: any) {
      responseBody = body;
      return originalJson.call(this, body);
    };
    
    res.send = function(body: any) {
      responseBody = body;
      return originalSend.call(this, body);
    };
    
    // Return the captured body after a short delay
    setTimeout(() => {
      try {
        if (responseBody) {
          const bodyString = JSON.stringify(responseBody);
          if (bodyString.length > maxSize) {
            req.auditContext = req.auditContext || {};
            (req.auditContext as any).responseBody = {
              _truncated: true,
              _originalSize: bodyString.length,
              _message: 'Response body too large for audit logging'
            };
          } else {
            req.auditContext = req.auditContext || {};
            (req.auditContext as any).responseBody = responseBody;
          }
        }
      } catch (error) {
        // Ignore errors in response body capture
      }
    }, 10);
    
    return null;
  } catch (error) {
    return { _error: 'Unable to capture response body' };
  }
}

// Main audit middleware factory
export function auditMiddleware(userConfig: AuditMiddlewareConfig = {}) {
  const config = { ...DEFAULT_CONFIG, ...userConfig };
  
  if (!config.enabled) {
    return (req: Request, res: Response, next: NextFunction) => next();
  }
  
  const auditBuffer = config.asyncLogging ? new AuditBuffer(config) : null;
  
  return async (req: Request, res: Response, next: NextFunction) => {
    const startTime = Date.now();
    const correlationId = req.headers['x-correlation-id'] as string || 
                         req.headers['x-request-id'] as string || 
                         uuidv4();
    
    // Initialize audit context
    const auditContext: AuditContext = {
      correlationId,
      requestId: uuidv4(),
      userId: (req as any).user?.id,
      userEmail: (req as any).user?.email,
      sessionId: (req as any).sessionID,
      ipAddress: req.ip || req.connection.remoteAddress || 'unknown',
      userAgent: req.headers['user-agent'],
      requestStartTime: startTime,
      auditEnabled: config.shouldAuditRequest(req)
    };
    
    // Attach audit context to request
    (req as any).auditContext = auditContext;
    
    // Add audit logging methods to request
    (req as any).auditLog = async (
      action: string,
      resource: string,
      options: Partial<CreateAuditLogOptions> = {}
    ) => {
      if (!auditContext.auditEnabled) return;
      
      const auditLog: CreateAuditLogOptions = {
        userId: auditContext.userId || 'anonymous',
        userEmail: auditContext.userEmail,
        action,
        resource,
        status: options.status || 'success',
        details: options.details || {},
        ipAddress: auditContext.ipAddress,
        userAgent: auditContext.userAgent,
        severity: options.severity || 'medium',
        category: options.category || config.categorizeRequest(req),
        metadata: {
          ...options.metadata,
          correlationId,
          requestId: auditContext.requestId,
          sessionId: auditContext.sessionId,
          executionTime: Date.now() - startTime
        },
        executionTime: Date.now() - startTime
      };
      
      if (config.asyncLogging && auditBuffer) {
        auditBuffer.add(auditLog);
      } else {
        try {
          await auditService.createAuditLog(auditLog);
        } catch (error) {
          logger.error('Failed to create audit log', {
            error: error instanceof Error ? error.message : 'Unknown error',
            action,
            resource,
            correlationId
          });
        }
      }
    };
    
    (req as any).logSecurityEvent = async (
      event: string,
      severity: 'low' | 'medium' | 'high' | 'critical',
      details: Record<string, any> = {}
    ) => {
      await (req as any).auditLog(`security.${event}`, 'security', {
        status: 'failure',
        severity,
        category: 'security',
        details: {
          ...details,
          securityEvent: true,
          detectedAt: new Date().toISOString()
        }
      });
    };
    
    // Check if request should be audited
    if (!auditContext.auditEnabled) {
      return next();
    }
    
    // Skip audit for excluded paths
    const isExcluded = config.excludePaths.some(path => {
      if (path.endsWith('*')) {
        return req.path.startsWith(path.slice(0, -1));
      }
      return req.path === path;
    });
    
    if (isExcluded) {
      return next();
    }
    
    // Include paths filter (if specified)
    if (config.includePaths.length > 0) {
      const isIncluded = config.includePaths.some(path => {
        if (path.endsWith('*')) {
          return req.path.startsWith(path.slice(0, -1));
        }
        return req.path === path;
      });
      
      if (!isIncluded) {
        return next();
      }
    }
    
    // Log incoming request
    try {
      await (req as any).auditLog('request.received', 'api_requests', {
        status: 'success',
        severity: 'low',
        category: config.categorizeRequest(req),
        details: {
          method: req.method,
          path: req.path,
          query: req.query,
          headers: config.captureHeaders ? sanitizeSensitiveData(req.headers) : undefined,
          body: config.captureBodies && shouldCaptureBody(req, config) ? 
                config.sanitizeRequestData(getRequestBody(req, config.maxBodySize)) : undefined
        }
      });
    } catch (error) {
      logger.error('Failed to log incoming request', {
        error: error instanceof Error ? error.message : 'Unknown error',
        path: req.path,
        correlationId
      });
    }
    
    // Capture response body for audit logging
    if (config.captureBodies) {
      getResponseBody(req, res, config.maxBodySize);
    }
    
    // Log authentication attempts
    if (config.logAuthenticationAttempts && (req.path.includes('/auth/') || req.path.includes('/login'))) {
      try {
        await (req as any).auditLog('auth.attempt', 'authentication', {
          status: req.method === 'POST' ? 'pending' : 'success',
          severity: 'medium',
          category: 'authentication',
          details: {
            attemptType: 'login',
            method: req.method,
            hasCredentials: !!(req.body && (req.body.email || req.body.username || req.body.password))
          }
        });
      } catch (error) {
        logger.error('Failed to log authentication attempt', {
          error: error instanceof Error ? error.message : 'Unknown error',
          path: req.path,
          correlationId
        });
      }
    }
    
    // Detect and log suspicious activity
    if (config.detectSuspiciousActivity || config.logSuspiciousRequests) {
      const suspicious = detectSuspiciousActivity(req, res);
      
      if (suspicious.isSuspicious && config.logSuspiciousRequests) {
        try {
          await (req as any).logSecurityEvent('suspicious_request', suspicious.severity, {
            reasons: suspicious.reasons,
            path: req.path,
            method: req.method,
            userAgent: req.headers['user-agent'],
            referer: req.headers.referer,
            origin: req.headers.origin,
            ipAddress: auditContext.ipAddress
          });
        } catch (error) {
          logger.error('Failed to log suspicious activity', {
            error: error instanceof Error ? error.message : 'Unknown error',
            path: req.path,
            correlationId
          });
        }
      }
    }
    
    // Response logging and performance monitoring
    const originalEnd = res.end;
    res.end = async function(...args: any[]) {
      const endTime = Date.now();
      const executionTime = endTime - startTime;
      
      try {
        // Get captured response body
        const responseBody = (req.auditContext as any)?.responseBody;
        
        // Log successful response
        await (req as any).auditLog('request.completed', 'api_requests', {
          status: res.statusCode < 400 ? 'success' : res.statusCode < 500 ? 'failure' : 'failure',
          severity: res.statusCode >= 500 ? 'high' : res.statusCode >= 400 ? 'medium' : 'low',
          category: config.categorizeRequest(req),
          executionTime,
          details: {
            method: req.method,
            path: req.path,
            statusCode: res.statusCode,
            responseTime: executionTime,
            responseBody: config.captureBodies && responseBody ? 
                         (config.sanitizeRequestData(responseBody)) : undefined
          }
        });
        
        // Log slow requests
        if (config.logSlowRequests && executionTime > config.slowRequestThreshold) {
          await (req as any).logSecurityEvent('slow_request', 'medium', {
            executionTime,
            threshold: config.slowRequestThreshold,
            path: req.path,
            method: req.method
          });
        }
        
        // Log failed authentication attempts
        if (config.logAuthenticationAttempts && 
            res.statusCode === 401 && 
            (req.path.includes('/auth/') || req.path.includes('/login'))) {
          await (req as any).auditLog('auth.failure', 'authentication', {
            status: 'failure',
            severity: 'high',
            category: 'authentication',
            details: {
              failureType: 'invalid_credentials',
              statusCode: res.statusCode,
              executionTime
            }
          });
        }
        
      } catch (error) {
        logger.error('Failed to log response completion', {
          error: error instanceof Error ? error.message : 'Unknown error',
          path: req.path,
          correlationId
        });
      }
      
      return originalEnd.apply(this, args);
    };
    
    // Cleanup on server shutdown
    const originalClose = res.socket?.server?.close;
    if (originalClose && auditBuffer) {
      res.socket.server.close = async () => {
        await auditBuffer.flush();
        return originalClose.call(res.socket.server);
      };
    }
    
    next();
  };
}

// Helper function to determine if request body should be captured
function shouldCaptureBody(req: Request, config: Required<AuditMiddlewareConfig>): boolean {
  // Check explicit exclusions
  if (config.excludeBodiesForPaths.some(path => {
    if (path.endsWith('*')) {
      return req.path.startsWith(path.slice(0, -1));
    }
    return req.path === path;
  })) {
    return false;
  }
  
  // Check explicit inclusions
  if (config.includeBodiesForPaths.length > 0) {
    return config.includeBodiesForPaths.some(path => {
      if (path.endsWith('*')) {
        return req.path.startsWith(path.slice(0, -1));
      }
      return req.path === path;
    });
  }
  
  // Default to captureBodies setting
  return config.captureBodies;
}

// AWS operation audit wrapper
export function createAWSAuditWrapper(service: string, operation: string) {
  return {
    before: async (resource: string, metadata: any = {}, req?: Request) => {
      if (!req || !(req as any).auditLog) return;
      
      await (req as any).auditLog(`aws.${operation}.before`, service, {
        status: 'pending',
        severity: 'low',
        category: 'aws_operations',
        details: {
          resource,
          metadata: sanitizeSensitiveData(metadata),
          phase: 'before'
        }
      });
    },
    
    after: async (resource: string, result: any, metadata: any = {}, req?: Request) => {
      if (!req || !(req as any).auditLog) return;
      
      await (req as any).auditLog(`aws.${operation}.after`, service, {
        status: 'success',
        severity: 'low',
        category: 'aws_operations',
        details: {
          resource,
          result: sanitizeSensitiveData(result),
          metadata: sanitizeSensitiveData(metadata),
          phase: 'after'
        }
      });
    },
    
    error: async (resource: string, error: Error, metadata: any = {}, req?: Request) => {
      if (!req || !(req as any).auditLog) return;
      
      await (req as any).auditLog(`aws.${operation}.error`, service, {
        status: 'failure',
        severity: 'medium',
        category: 'aws_operations',
        details: {
          resource,
          error: error.message,
          stack: error.stack,
          metadata: sanitizeSensitiveData(metadata),
          phase: 'error'
        }
      });
    }
  };
}

// Security event types for consistent logging
export const SECURITY_EVENTS = {
  // Authentication events
  AUTH_SUCCESS: 'auth.success',
  AUTH_FAILURE: 'auth.failure',
  AUTH_LOCKOUT: 'auth.lockout',
  AUTH_TOKEN_EXPIRED: 'auth.token_expired',
  AUTH_TOKEN_INVALID: 'auth.token_invalid',
  
  // Authorization events
  AUTHZ_DENIED: 'authorization.denied',
  AUTHZ_INSUFFICIENT_PERMISSIONS: 'authorization.insufficient_permissions',
  
  // Suspicious activity
  SUSPICIOUS_REQUEST: 'security.suspicious_request',
  SUSPICIOUS_IP: 'security.suspicious_ip',
  BRUTE_FORCE: 'security.brute_force',
  RATE_LIMIT_EXCEEDED: 'security.rate_limit_exceeded',
  
  // Data access
  DATA_EXPORT: 'data.export',
  DATA_DELETION: 'data.deletion',
  SENSITIVE_DATA_ACCESS: 'data.sensitive_access',
  
  // System events
  CONFIGURATION_CHANGE: 'system.configuration_change',
  ADMIN_ACTION: 'system.admin_action',
  SYSTEM_ERROR: 'system.error'
} as const;

// Utility functions for external use
export async function flushAuditBuffer(): Promise<void> {
  // This would be called during graceful shutdown
  // Implementation depends on how audit buffers are managed globally
}

export function createAuditLogger(context: string) {
  return {
    info: (action: string, resource: string, details?: any) => 
      logger.info(`[AUDIT:${context}] ${action}`, { action, resource, ...details }),
    warn: (action: string, resource: string, details?: any) => 
      logger.warn(`[AUDIT:${context}] ${action}`, { action, resource, ...details }),
    error: (action: string, resource: string, details?: any) => 
      logger.error(`[AUDIT:${context}] ${action}`, { action, resource, ...details })
  };
}

// Extend Request interface to include audit methods
declare global {
  namespace Express {
    interface Request {
      auditLog?: (action: string, resource: string, options?: Partial<CreateAuditLogOptions>) => Promise<void>;
      logSecurityEvent?: (event: string, severity: 'low' | 'medium' | 'high' | 'critical', details?: Record<string, any>) => Promise<void>;
      auditContext?: AuditContext;
    }
  }
}

export default auditMiddleware;
