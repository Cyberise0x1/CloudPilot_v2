import { Request, Response, NextFunction } from 'express';
import { ZodSchema, ZodError } from 'zod';
import Joi from 'joi';

/**
 * Custom validation error class
 */
export class ValidationError extends Error {
  public statusCode: number;
  public errors: ValidationErrorDetail[];

  constructor(message: string, errors: ValidationErrorDetail[] = []) {
    super(message);
    this.name = 'ValidationError';
    this.statusCode = 400;
    this.errors = errors;
  }
}

export interface ValidationErrorDetail {
  field: string;
  message: string;
  code: string;
  value?: any;
}

export interface ValidationOptions {
  stripUnknown?: boolean;
  abortEarly?: boolean;
  allowUnknown?: boolean;
  stripNull?: boolean;
  convert?: boolean;
}

/**
 * Input sanitization functions
 */
export const sanitizers = {
  /**
   * Remove HTML tags and potentially dangerous characters
   */
  sanitizeHtml: (input: string): string => {
    if (typeof input !== 'string') return input;
    
    return input
      .replace(/[<>]/g, '') // Remove angle brackets
      .replace(/javascript:/gi, '') // Remove javascript: protocol
      .replace(/on\w+\s*=/gi, '') // Remove event handlers
      .replace(/script/gi, '') // Remove script tags
      .replace(/vbscript/gi, '') // Remove vbscript
      .replace(/data:/gi, '') // Remove data: protocol
      .replace(/file:/gi, '') // Remove file: protocol
      .trim();
  },

  /**
   * Escape HTML entities
   */
  escapeHtml: (input: string): string => {
    if (typeof input !== 'string') return input;
    
    const htmlEscapes: Record<string, string> = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#x27;',
      '/': '&#x2F;'
    };
    
    return input.replace(/[&<>"'/]/g, (match) => htmlEscapes[match]);
  },

  /**
   * Normalize whitespace and remove control characters
   */
  sanitizeWhitespace: (input: string): string => {
    if (typeof input !== 'string') return input;
    
    return input
      .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '') // Remove control chars
      .replace(/\s+/g, ' ') // Normalize whitespace
      .trim();
  },

  /**
   * Remove null bytes
   */
  removeNullBytes: (input: string): string => {
    if (typeof input !== 'string') return input;
    return input.replace(/\0/g, '');
  },

  /**
   * Sanitize filename
   */
  sanitizeFilename: (input: string): string => {
    if (typeof input !== 'string') return input;
    
    return input
      .replace(/[/\\?%*:|"<>]/g, '') // Remove invalid filename chars
      .replace(/\.+/g, '.') // Replace multiple dots with single dot
      .replace(/^\./, '') // Remove leading dot
      .replace(/\.$/, '') // Remove trailing dot
      .substring(0, 255) // Limit length
      .trim();
  },

  /**
   * Remove SQL injection patterns
   */
  preventSQLInjection: (input: string): string => {
    if (typeof input !== 'string') return input;
    
    const sqlPatterns = [
      /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|EXECUTE|UNION|AND|OR)\b)/gi,
      /('|(\\')|(;)|(\\*)|(%))/gi,
      /(\b(OR|AND)\s+\d+\s*=\s*\d+)/gi,
      /(--|#|\/\*|\*\/)/gi
    ];
    
    let sanitized = input;
    sqlPatterns.forEach(pattern => {
      sanitized = sanitized.replace(pattern, '');
    });
    
    return sanitized;
  },

  /**
   * Prevent command injection
   */
  preventCommandInjection: (input: string): string => {
    if (typeof input !== 'string') return input;
    
    const commandPatterns = [
      /[;&|`$()]/g, // Shell metacharacters
      /(\b(sh|bash|cmd|powershell|nc|netcat|telnet|wget|curl)\b)/gi,
      /(\|\||&&)/g,
      /(>|<)/g,
      /\$/g,
      /`/g
    ];
    
    let sanitized = input;
    commandPatterns.forEach(pattern => {
      sanitized = sanitized.replace(pattern, '');
    });
    
    return sanitized;
  },

  /**
   * Sanitize object recursively
   */
  sanitizeObject: <T extends Record<string, any>>(obj: T): T => {
    if (typeof obj !== 'object' || obj === null) {
      return typeof obj === 'string' ? sanitizers.sanitizeHtml(obj) as any : obj;
    }

    if (Array.isArray(obj)) {
      return obj.map(item => sanitizers.sanitizeObject(item)) as any;
    }

    const sanitized: any = {};
    for (const [key, value] of Object.entries(obj)) {
      if (typeof value === 'string') {
        sanitized[key] = sanitizers.sanitizeHtml(
          sanitizers.removeNullBytes(
            sanitizers.sanitizeWhitespace(value)
          )
        );
      } else if (typeof value === 'object' && value !== null) {
        sanitized[key] = sanitizers.sanitizeObject(value);
      } else {
        sanitized[key] = value;
      }
    }
    return sanitized;
  }
};

/**
 * Common validation schemas
 */
export const validationSchemas = {
  // ID validation
  mongoId: Joi.string().pattern(/^[0-9a-fA-F]{24}$/, 'MongoDB ObjectId'),
  
  // UUID validation
  uuid: Joi.string().uuid({ version: 'uuidv4' }),
  
  // Email validation
  email: Joi.string().email().max(255),
  
  // Password validation
  password: Joi.string()
    .min(8)
    .max(128)
    .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/, 'password')
    .message('Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character'),
  
  // URL validation
  url: Joi.string().uri({ scheme: ['http', 'https'] }),
  
  // Phone validation (international format)
  phone: Joi.string().pattern(/^\+?[1-9]\d{1,14}$/, 'phone'),
  
  // Date validation
  date: Joi.date().iso(),
  
  // Pagination validation
  pagination: Joi.object({
    page: Joi.number().integer().min(1).default(1),
    limit: Joi.number().integer().min(1).max(100).default(10)
  }),
  
  // Search validation
  search: Joi.string().max(255).allow(''),
  
  // File validation
  file: Joi.object({
    fieldname: Joi.string().required(),
    originalname: Joi.string().required(),
    encoding: Joi.string().required(),
    mimetype: Joi.string().required(),
    size: Joi.number().max(10 * 1024 * 1024) // 10MB
  })
};

/**
 * Custom validation rules
 */
export const customValidators = {
  /**
   * Validate that a string contains only alphanumeric characters
   */
  alphanumeric: (value: string): boolean => {
    return /^[a-zA-Z0-9]+$/.test(value);
  },

  /**
   * Validate that a string contains only alphabetic characters
   */
  alpha: (value: string): boolean => {
    return /^[a-zA-Z]+$/.test(value);
  },

  /**
   * Validate strong password
   */
  strongPassword: (value: string): boolean => {
    return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,128}$/.test(value);
  },

  /**
   * Validate credit card number (Luhn algorithm)
   */
  creditCard: (value: string): boolean => {
    const sanitized = value.replace(/\s|-/g, '');
    if (!/^\d{13,19}$/.test(sanitized)) return false;
    
    let sum = 0;
    let shouldDouble = false;
    
    for (let i = sanitized.length - 1; i >= 0; i--) {
      let digit = parseInt(sanitized.charAt(i), 10);
      
      if (shouldDouble) {
        digit *= 2;
        if (digit > 9) digit -= 9;
      }
      
      sum += digit;
      shouldDouble = !shouldDouble;
    }
    
    return sum % 10 === 0;
  },

  /**
   * Validate not empty
   */
  notEmpty: (value: any): boolean => {
    if (value === null || value === undefined) return false;
    if (typeof value === 'string') return value.trim().length > 0;
    if (Array.isArray(value)) return value.length > 0;
    if (typeof value === 'object') return Object.keys(value).length > 0;
    return true;
  },

  /**
   * Validate within allowed values
   */
  isIn: (value: any, allowedValues: any[]): boolean => {
    return allowedValues.includes(value);
  },

  /**
   * Validate string length
   */
  lengthBetween: (value: string, min: number, max: number): boolean => {
    if (typeof value !== 'string') return false;
    const len = value.trim().length;
    return len >= min && len <= max;
  }
};

/**
 * Middleware to validate request body
 */
export const validateBody = (schema: Joi.ObjectSchema | ZodSchema, options: ValidationOptions = {}) => {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      // Sanitize input first
      if (req.body && typeof req.body === 'object') {
        req.body = sanitizers.sanitizeObject(req.body);
      }

      if ('safeParse' in schema) {
        // Zod schema
        const result = (schema as ZodSchema).safeParse(req.body);
        
        if (!result.success) {
          const errors: ValidationErrorDetail[] = result.error.errors.map(err => ({
            field: err.path.join('.'),
            message: err.message,
            code: err.code,
            value: err.input
          }));
          
          throw new ValidationError('Validation failed', errors);
        }
        
        req.body = result.data;
      } else {
        // Joi schema
        const { error, value } = (schema as Joi.ObjectSchema).validate(req.body, {
          stripUnknown: options.stripUnknown ?? true,
          abortEarly: options.abortEarly ?? false,
          allowUnknown: options.allowUnknown ?? false,
          stripNull: options.stripNull ?? false,
          convert: options.convert ?? true
        });
        
        if (error) {
          const errors: ValidationErrorDetail[] = error.details.map(detail => ({
            field: detail.path.join('.'),
            message: detail.message,
            code: detail.type,
            value: detail.context?.value
          }));
          
          throw new ValidationError('Validation failed', errors);
        }
        
        req.body = value;
      }
      
      next();
    } catch (error) {
      if (error instanceof ValidationError) {
        return res.status(error.statusCode).json({
          success: false,
          error: {
            message: error.message,
            code: 'VALIDATION_ERROR',
            details: error.errors
          }
        });
      }
      
      next(error);
    }
  };
};

/**
 * Middleware to validate query parameters
 */
export const validateQuery = (schema: Joi.ObjectSchema | ZodSchema, options: ValidationOptions = {}) => {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      // Sanitize query parameters
      if (req.query && typeof req.query === 'object') {
        const sanitized: any = {};
        for (const [key, value] of Object.entries(req.query)) {
          if (typeof value === 'string') {
            sanitized[key] = sanitizers.sanitizeHtml(
              sanitizers.removeNullBytes(value)
            );
          } else if (Array.isArray(value)) {
            sanitized[key] = value.map(v => 
              typeof v === 'string' ? sanitizers.sanitizeHtml(sanitizers.removeNullBytes(v)) : v
            );
          } else {
            sanitized[key] = value;
          }
        }
        req.query = sanitized;
      }

      if ('safeParse' in schema) {
        // Zod schema
        const result = (schema as ZodSchema).safeParse(req.query);
        
        if (!result.success) {
          const errors: ValidationErrorDetail[] = result.error.errors.map(err => ({
            field: err.path.join('.'),
            message: err.message,
            code: err.code,
            value: err.input
          }));
          
          throw new ValidationError('Query validation failed', errors);
        }
        
        req.query = result.data as any;
      } else {
        // Joi schema
        const { error, value } = (schema as Joi.ObjectSchema).validate(req.query, {
          stripUnknown: options.stripUnknown ?? true,
          abortEarly: options.abortEarly ?? false,
          allowUnknown: options.allowUnknown ?? true,
          convert: options.convert ?? true
        });
        
        if (error) {
          const errors: ValidationErrorDetail[] = error.details.map(detail => ({
            field: detail.path.join('.'),
            message: detail.message,
            code: detail.type,
            value: detail.context?.value
          }));
          
          throw new ValidationError('Query validation failed', errors);
        }
        
        req.query = value as any;
      }
      
      next();
    } catch (error) {
      if (error instanceof ValidationError) {
        return res.status(error.statusCode).json({
          success: false,
          error: {
            message: error.message,
            code: 'VALIDATION_ERROR',
            details: error.errors
          }
        });
      }
      
      next(error);
    }
  };
};

/**
 * Middleware to validate path parameters
 */
export const validateParams = (schema: Joi.ObjectSchema | ZodSchema, options: ValidationOptions = {}) => {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      // Sanitize path parameters
      if (req.params && typeof req.params === 'object') {
        const sanitized: any = {};
        for (const [key, value] of Object.entries(req.params)) {
          if (typeof value === 'string') {
            sanitized[key] = sanitizers.removeNullBytes(
              sanitizers.sanitizeWhitespace(value)
            );
          } else {
            sanitized[key] = value;
          }
        }
        req.params = sanitized;
      }

      if ('safeParse' in schema) {
        // Zod schema
        const result = (schema as ZodSchema).safeParse(req.params);
        
        if (!result.success) {
          const errors: ValidationErrorDetail[] = result.error.errors.map(err => ({
            field: err.path.join('.'),
            message: err.message,
            code: err.code,
            value: err.input
          }));
          
          throw new ValidationError('Path parameters validation failed', errors);
        }
        
        req.params = result.data as any;
      } else {
        // Joi schema
        const { error, value } = (schema as Joi.ObjectSchema).validate(req.params, {
          stripUnknown: false,
          abortEarly: options.abortEarly ?? false,
          allowUnknown: options.allowUnknown ?? false,
          convert: options.convert ?? true
        });
        
        if (error) {
          const errors: ValidationErrorDetail[] = error.details.map(detail => ({
            field: detail.path.join('.'),
            message: detail.message,
            code: detail.type,
            value: detail.context?.value
          }));
          
          throw new ValidationError('Path parameters validation failed', errors);
        }
        
        req.params = value as any;
      }
      
      next();
    } catch (error) {
      if (error instanceof ValidationError) {
        return res.status(error.statusCode).json({
          success: false,
          error: {
            message: error.message,
            code: 'VALIDATION_ERROR',
            details: error.errors
          }
        });
      }
      
      next(error);
    }
  };
};

/**
 * Middleware to validate file uploads
 */
export const validateFileUpload = (options: {
  allowedMimeTypes?: string[];
  maxFileSize?: number;
  required?: boolean;
  fieldName?: string;
}) => {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      const { allowedMimeTypes = [], maxFileSize = 10 * 1024 * 1024, required = false, fieldName = 'file' } = options;
      
      if (!req.files && required) {
        return res.status(400).json({
          success: false,
          error: {
            message: 'File upload is required',
            code: 'FILE_REQUIRED'
          }
        });
      }

      if (!req.files) {
        return next();
      }

      const files = Array.isArray(req.files) ? req.files : req.files[fieldName];
      
      if (!files && required) {
        return res.status(400).json({
          success: false,
          error: {
            message: 'File upload is required',
            code: 'FILE_REQUIRED'
          }
        });
      }

      if (!files) {
        return next();
      }

      const fileList = Array.isArray(files) ? files : [files];

      for (const file of fileList) {
        // Validate file size
        if (file.size > maxFileSize) {
          return res.status(400).json({
            success: false,
            error: {
              message: `File size exceeds maximum allowed size of ${maxFileSize} bytes`,
              code: 'FILE_TOO_LARGE'
            }
          });
        }

        // Validate MIME type
        if (allowedMimeTypes.length > 0 && !allowedMimeTypes.includes(file.mimetype)) {
          return res.status(400).json({
            success: false,
            error: {
              message: `File type ${file.mimetype} is not allowed`,
              code: 'INVALID_FILE_TYPE',
              allowedTypes: allowedMimeTypes
            }
          });
        }

        // Validate filename
        if (file.originalname) {
          file.originalname = sanitizers.sanitizeFilename(file.originalname);
          
          // Check for dangerous file extensions
          const dangerousExtensions = ['.exe', '.bat', '.cmd', '.scr', '.pif', '.com', '.vbs', '.js'];
          const fileExtension = file.originalname.toLowerCase().substring(file.originalname.lastIndexOf('.'));
          
          if (dangerousExtensions.includes(fileExtension)) {
            return res.status(400).json({
              success: false,
              error: {
                message: 'File type not allowed',
                code: 'DANGEROUS_FILE_TYPE'
              }
            });
          }
        }

        // Validate encoding
        if (file.encoding && !['7bit', '8bit', 'binary'].includes(file.encoding)) {
          return res.status(400).json({
            success: false,
            error: {
              message: 'Invalid file encoding',
              code: 'INVALID_ENCODING'
            }
          });
        }
      }

      // If using multer and files are stored in memory, sanitize buffer
      if (fileList[0]?.buffer && typeof fileList[0].buffer === 'string') {
        // Remove null bytes from buffer
        fileList.forEach(file => {
          if (file.buffer && typeof file.buffer === 'string') {
            file.buffer = sanitizers.removeNullBytes(file.buffer);
          }
        });
      }
      
      next();
    } catch (error) {
      if (error instanceof ValidationError) {
        return res.status(error.statusCode).json({
          success: false,
          error: {
            message: error.message,
            code: 'VALIDATION_ERROR',
            details: error.errors
          }
        });
      }
      
      next(error);
    }
  };
};

/**
 * Rate limiting for validation attempts
 */
const validationAttempts = new Map<string, { count: number; lastAttempt: number }>();
const MAX_VALIDATION_ATTEMPTS = 100;
const WINDOW_MS = 15 * 60 * 1000; // 15 minutes

export const validationRateLimit = (req: Request, res: Response, next: NextFunction) => {
  const clientIp = req.ip || req.connection.remoteAddress || 'unknown';
  const now = Date.now();
  const attempts = validationAttempts.get(clientIp);

  if (!attempts) {
    validationAttempts.set(clientIp, { count: 1, lastAttempt: now });
    return next();
  }

  if (now - attempts.lastAttempt > WINDOW_MS) {
    // Reset window
    validationAttempts.set(clientIp, { count: 1, lastAttempt: now });
    return next();
  }

  if (attempts.count >= MAX_VALIDATION_ATTEMPTS) {
    return res.status(429).json({
      success: false,
      error: {
        message: 'Too many validation attempts. Please try again later.',
        code: 'VALIDATION_RATE_LIMIT_EXCEEDED'
      }
    });
  }

  attempts.count++;
  attempts.lastAttempt = now;
  validationAttempts.set(clientIp, attempts);

  next();
};

/**
 * Sanitize all inputs in request
 */
export const sanitizeAllInputs = (req: Request, res: Response, next: NextFunction) => {
  // Sanitize body
  if (req.body && typeof req.body === 'object') {
    req.body = sanitizers.sanitizeObject(req.body);
  }

  // Sanitize query parameters
  if (req.query && typeof req.query === 'object') {
    const sanitizedQuery: any = {};
    for (const [key, value] of Object.entries(req.query)) {
      if (typeof value === 'string') {
        sanitizedQuery[key] = sanitizers.sanitizeHtml(
          sanitizers.removeNullBytes(value)
        );
      } else if (Array.isArray(value)) {
        sanitizedQuery[key] = value.map(v => 
          typeof v === 'string' ? sanitizers.sanitizeHtml(sanitizers.removeNullBytes(v)) : v
        );
      } else {
        sanitizedQuery[key] = value;
      }
    }
    req.query = sanitizedQuery;
  }

  // Sanitize path parameters
  if (req.params && typeof req.params === 'object') {
    const sanitizedParams: any = {};
    for (const [key, value] of Object.entries(req.params)) {
      if (typeof value === 'string') {
        sanitizedParams[key] = sanitizers.removeNullBytes(
          sanitizers.sanitizeWhitespace(value)
        );
      } else {
        sanitizedParams[key] = value;
      }
    }
    req.params = sanitizedParams;
  }

  next();
};

/**
 * Error handling for validation errors
 */
export const validationErrorHandler = (err: Error, req: Request, res: Response, next: NextFunction) => {
  if (err instanceof ZodError) {
    const errors: ValidationErrorDetail[] = err.errors.map(error => ({
      field: error.path.join('.'),
      message: error.message,
      code: error.code,
      value: error.input
    }));

    return res.status(400).json({
      success: false,
      error: {
        message: 'Validation failed',
        code: 'VALIDATION_ERROR',
        details: errors
      }
    });
  }

  if (err instanceof Joi.ValidationError) {
    const errors: ValidationErrorDetail[] = err.details.map(detail => ({
      field: detail.path.join('.'),
      message: detail.message,
      code: detail.type,
      value: detail.context?.value
    }));

    return res.status(400).json({
      success: false,
      error: {
        message: 'Validation failed',
        code: 'VALIDATION_ERROR',
        details: errors
      }
    });
  }

  next(err);
};

/**
 * Utility function to create custom validation middleware
 */
export const createValidator = (schema: Joi.ObjectSchema | ZodSchema, options: ValidationOptions = {}) => {
  return validateBody(schema, options);
};

/**
 * Comprehensive validation middleware that validates all inputs
 */
export const comprehensiveValidation = (options: {
  bodySchema?: Joi.ObjectSchema | ZodSchema;
  querySchema?: Joi.ObjectSchema | ZodSchema;
  paramsSchema?: Joi.ObjectSchema | ZodSchema;
  fileOptions?: {
    allowedMimeTypes?: string[];
    maxFileSize?: number;
    required?: boolean;
    fieldName?: string;
  };
  rateLimit?: boolean;
  sanitize?: boolean;
  validationOptions?: ValidationOptions;
}) => {
  const {
    bodySchema,
    querySchema,
    paramsSchema,
    fileOptions,
    rateLimit = true,
    sanitize = true,
    validationOptions = {}
  } = options;

  const middlewares: any[] = [];

  // Add rate limiting first
  if (rateLimit) {
    middlewares.push(validationRateLimit);
  }

  // Add input sanitization
  if (sanitize) {
    middlewares.push(sanitizeAllInputs);
  }

  // Add validation middleware
  if (paramsSchema) {
    middlewares.push(validateParams(paramsSchema, validationOptions));
  }

  if (querySchema) {
    middlewares.push(validateQuery(querySchema, validationOptions));
  }

  if (bodySchema) {
    middlewares.push(validateBody(bodySchema, validationOptions));
  }

  if (fileOptions) {
    middlewares.push(validateFileUpload(fileOptions));
  }

  return middlewares;
};

// Export all utilities
export default {
  ValidationError,
  ValidationErrorDetail,
  ValidationOptions,
  sanitizers,
  validationSchemas,
  customValidators,
  validateBody,
  validateQuery,
  validateParams,
  validateFileUpload,
  validationRateLimit,
  sanitizeAllInputs,
  validationErrorHandler,
  createValidator,
  comprehensiveValidation
};
