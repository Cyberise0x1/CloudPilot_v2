import { Request, Response, NextFunction } from 'express';
import Redis from 'ioredis';

// Types for rate limiting
interface RateLimitConfig {
  windowMs: number; // Time window in milliseconds
  maxRequests: number; // Maximum requests allowed in window
  skipSuccessfulRequests?: boolean; // Skip counting successful requests
  skipFailedRequests?: boolean; // Skip counting failed requests
  keyGenerator?: (req: Request) => string; // Custom key generator
  skip?: (req: Request) => boolean; // Skip rate limiting for this request
  message?: string | ((req: Request, res: Response) => string); // Custom message
  statusCode?: number; // HTTP status code for rate limit exceeded
  headers?: boolean; // Include rate limit headers in response
  skipUserBased?: boolean; // Skip user-based rate limiting
  skipIPBased?: boolean; // Skip IP-based rate limiting
}

interface RateLimitOptions {
  auth?: RateLimitConfig;
  aws?: RateLimitConfig;
  api?: RateLimitConfig;
  admin?: RateLimitConfig;
  default: RateLimitConfig;
}

interface RateLimitInfo {
  limit: number;
  remaining: number;
  reset: number;
  totalHits: number;
}

interface RateLimitStore {
  get(key: string): Promise<{ count: number; resetTime: number } | null>;
  set(key: string, count: number, expireTime: number): Promise<void>;
  increment(key: string, expireTime: number): Promise<number>;
  delete(key: string): Promise<void>;
}

// Redis-backed rate limit store
class RedisRateLimitStore implements RateLimitStore {
  private redis: Redis;
  private prefix: string;

  constructor(redis: Redis, prefix = 'ratelimit:') {
    this.redis = redis;
    this.prefix = prefix;
  }

  async get(key: string): Promise<{ count: number; resetTime: number } | null> {
    const data = await this.redis.get(`${this.prefix}${key}`);
    if (!data) return null;
    
    const parsed = JSON.parse(data);
    return {
      count: parsed.count,
      resetTime: parsed.resetTime,
    };
  }

  async set(key: string, count: number, expireTime: number): Promise<void> {
    const data = JSON.stringify({
      count,
      resetTime: expireTime,
    });
    await this.redis.setex(`${this.prefix}${key}`, Math.ceil(expireTime / 1000), data);
  }

  async increment(key: string, expireTime: number): Promise<number> {
    const fullKey = `${this.prefix}${key}`;
    const pipe = this.redis.pipeline();
    
    const multi = this.redis.multi();
    multi.incr(fullKey);
    multi.ttl(fullKey);
    const [newCount, ttl] = await multi.exec();
    
    if (!newCount || newCount[1] === -1) {
      // Key doesn't exist or has no TTL, set it with expiration
      await this.redis.setex(fullKey, Math.ceil(expireTime / 1000), 1);
      return 1;
    }
    
    return newCount[1] as number;
  }

  async delete(key: string): Promise<void> {
    await this.redis.del(`${this.prefix}${key}`);
  }
}

// In-memory rate limit store (fallback)
class MemoryRateLimitStore implements RateLimitStore {
  private store = new Map<string, { count: number; resetTime: number }>();
  private cleanupInterval: NodeJS.Timeout;

  constructor(cleanupIntervalMs = 60000) {
    this.cleanupInterval = setInterval(() => {
      const now = Date.now();
      for (const [key, value] of this.store.entries()) {
        if (value.resetTime <= now) {
          this.store.delete(key);
        }
      }
    }, cleanupIntervalMs);
  }

  async get(key: string): Promise<{ count: number; resetTime: number } | null> {
    const data = this.store.get(key);
    if (!data || data.resetTime <= Date.now()) {
      return null;
    }
    return data;
  }

  async set(key: string, count: number, expireTime: number): Promise<void> {
    this.store.set(key, { count, resetTime: expireTime });
  }

  async increment(key: string, expireTime: number): Promise<number> {
    const now = Date.now();
    let data = this.store.get(key);
    
    if (!data || data.resetTime <= now) {
      data = { count: 0, resetTime: expireTime };
    }
    
    data.count += 1;
    this.store.set(key, data);
    
    return data.count;
  }

  async delete(key: string): Promise<void> {
    this.store.delete(key);
  }

  // Cleanup when done
  destroy() {
    clearInterval(this.cleanupInterval);
    this.store.clear();
  }
}

// Default rate limit configurations
const defaultRateLimits: RateLimitOptions = {
  default: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    maxRequests: 100,
    headers: true,
    statusCode: 429,
    message: 'Too many requests, please try again later.',
  },
  auth: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    maxRequests: 5, // Strict limit for auth endpoints
    headers: true,
    statusCode: 429,
    message: 'Too many authentication attempts, please try again later.',
  },
  aws: {
    windowMs: 60 * 1000, // 1 minute
    maxRequests: 10, // Lower limit for AWS operations
    headers: true,
    statusCode: 429,
    message: 'AWS operation rate limit exceeded, please slow down.',
  },
  api: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    maxRequests: 1000,
    headers: true,
    statusCode: 429,
    message: 'API rate limit exceeded.',
  },
  admin: {
    windowMs: 5 * 60 * 1000, // 5 minutes
    maxRequests: 500,
    headers: true,
    statusCode: 429,
    message: 'Admin endpoint rate limit exceeded.',
  },
};

// Helper function to extract client IP
function getClientIP(req: Request): string {
  return (
    (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() ||
    req.ip ||
    req.connection.remoteAddress ||
    'unknown'
  );
}

// Helper function to check if user is admin
function isAdminUser(req: Request): boolean {
  // Check multiple sources for admin status
  if (req.user?.role === 'admin' || req.user?.isAdmin) {
    return true;
  }
  
  // Check headers for admin bypass (in development)
  if (process.env.NODE_ENV === 'development') {
    if (req.headers['x-admin-bypass'] === 'true' || req.headers['x-admin-user']) {
      return true;
    }
  }
  
  return false;
}

// Sliding window rate limiter
class SlidingWindowRateLimiter {
  private store: RateLimitStore;
  private config: RateLimitConfig;
  private type: keyof RateLimitOptions;

  constructor(
    store: RateLimitStore,
    config: RateLimitConfig,
    type: keyof RateLimitOptions
  ) {
    this.store = store;
    this.config = config;
    this.type = type;
  }

  async checkLimit(req: Request): Promise<{ allowed: boolean; info?: RateLimitInfo }> {
    const key = this.generateKey(req);
    const now = Date.now();
    const windowStart = now - this.config.windowMs;
    
    // Get current count from store
    const current = await this.store.get(key);
    const count = current?.count || 0;
    const resetTime = current?.resetTime || (now + this.config.windowMs);
    
    // If window has reset, start fresh
    if (!current || resetTime <= now) {
      const newCount = await this.store.increment(key, now + this.config.windowMs);
      
      return {
        allowed: newCount <= this.config.maxRequests,
        info: {
          limit: this.config.maxRequests,
          remaining: Math.max(0, this.config.maxRequests - newCount),
          reset: now + this.config.windowMs,
          totalHits: newCount,
        },
      };
    }
    
    // Check if limit exceeded
    if (count >= this.config.maxRequests) {
      return {
        allowed: false,
        info: {
          limit: this.config.maxRequests,
          remaining: 0,
          reset: resetTime,
          totalHits: count,
        },
      };
    }
    
    // Increment counter
    const newCount = await this.store.increment(key, resetTime);
    
    return {
      allowed: true,
      info: {
        limit: this.config.maxRequests,
        remaining: Math.max(0, this.config.maxRequests - newCount),
        reset: resetTime,
        totalHits: newCount,
      },
    };
  }

  private generateKey(req: Request): string {
    const parts: string[] = [];
    
    // Add user-based key if not skipped
    if (!this.config.skipUserBased && req.user?.id) {
      parts.push(`user:${req.user.id}`);
    }
    
    // Add IP-based key if not skipped
    if (!this.config.skipIPBased) {
      parts.push(`ip:${getClientIP(req)}`);
    }
    
    // Add endpoint-based key
    parts.push(`endpoint:${this.type}`);
    
    // Add custom key if provided
    if (this.config.keyGenerator) {
      const customKey = this.config.keyGenerator(req);
      if (customKey) {
        parts.push(`custom:${customKey}`);
      }
    }
    
    return parts.join(':');
  }
}

// Main rate limiting middleware factory
export function rateLimiter(
  options?: Partial<RateLimitOptions>,
  redisClient?: Redis
) {
  // Merge options with defaults
  const rateLimitOptions: RateLimitOptions = {
    default: { ...defaultRateLimits.default, ...options?.default },
    auth: { ...defaultRateLimits.auth, ...options?.auth },
    aws: { ...defaultRateLimits.aws, ...options?.aws },
    api: { ...defaultRateLimits.api, ...options?.api },
    admin: { ...defaultRateLimits.admin, ...options?.admin },
  };

  // Initialize store
  const store = redisClient
    ? new RedisRateLimitStore(redisClient)
    : new MemoryRateLimitStore();

  // Determine which config to use based on endpoint
  function getConfigForEndpoint(req: Request): RateLimitConfig {
    // Check for admin bypass first
    if (isAdminUser(req) && !req.headers['x-admin-bypass']) {
      // Return a very permissive config for admins
      return {
        ...rateLimitOptions.admin,
        windowMs: 60 * 1000,
        maxRequests: 10000,
        skip: () => false,
      };
    }

    const path = req.path.toLowerCase();
    const method = req.method.toUpperCase();

    // Auth endpoints (login, register, password reset, etc.)
    if (path.includes('/auth/') || path.includes('/login') || 
        path.includes('/register') || path.includes('/forgot-password') ||
        path.includes('/reset-password') || path.includes('/verify')) {
      return rateLimitOptions.auth;
    }

    // AWS-related endpoints
    if (path.includes('/aws/') || path.includes('/s3/') || 
        path.includes('/ec2/') || path.includes('/rds/') ||
        path.includes('/lambda/') || path.includes('/secrets-manager/')) {
      return rateLimitOptions.aws;
    }

    // Admin endpoints
    if (path.includes('/admin/') || path.includes('/management/')) {
      return rateLimitOptions.admin;
    }

    // API endpoints
    if (path.startsWith('/api/')) {
      return rateLimitOptions.api;
    }

    return rateLimitOptions.default;
  }

  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const config = getConfigForEndpoint(req);
      
      // Skip rate limiting if configured
      if (config.skip && config.skip(req)) {
        return next();
      }

      // Create limiter instance
      const limiter = new SlidingWindowRateLimiter(store, config, 'default');
      
      // Check rate limit
      const result = await limiter.checkLimit(req);
      
      // Add rate limit headers if configured
      if (config.headers && result.info) {
        res.set({
          'X-RateLimit-Limit': result.info.limit.toString(),
          'X-RateLimit-Remaining': result.info.remaining.toString(),
          'X-RateLimit-Reset': Math.ceil(result.info.reset / 1000).toString(),
        });
      }

      // If rate limit exceeded
      if (!result.allowed) {
        const retryAfter = Math.ceil((result.info!.reset - Date.now()) / 1000);
        
        res.set({
          'Retry-After': retryAfter.toString(),
        });

        // Custom message
        const message = typeof config.message === 'function'
          ? config.message(req, res)
          : (config.message || 'Too many requests');

        return res.status(config.statusCode || 429).json({
          error: 'Rate Limit Exceeded',
          message,
          retryAfter,
          limit: result.info!.limit,
          remaining: result.info!.remaining,
        });
      }

      next();
    } catch (error) {
      console.error('Rate limiter error:', error);
      // Fail open - allow request if rate limiter fails
      next();
    }
  };
}

// Specific middleware for different endpoint types
export const authRateLimiter = rateLimiter({
  auth: {
    windowMs: 15 * 60 * 1000,
    maxRequests: 5,
    message: 'Too many authentication attempts. Please try again in 15 minutes.',
  }
});

export const awsRateLimiter = rateLimiter({
  aws: {
    windowMs: 60 * 1000,
    maxRequests: 10,
    message: 'AWS operation rate limit exceeded. Please try again in 1 minute.',
  }
});

export const apiRateLimiter = rateLimiter({
  api: {
    windowMs: 15 * 60 * 1000,
    maxRequests: 1000,
    message: 'API rate limit exceeded. Please try again in 15 minutes.',
  }
});

// Utility functions for manual rate limit checks
export async function checkRateLimit(
  key: string,
  limit: number,
  windowMs: number,
  store: RateLimitStore
): Promise<{ allowed: boolean; remaining: number; reset: number }> {
  const now = Date.now();
  const current = await store.get(key);
  
  if (!current || current.resetTime <= now) {
    const newCount = await store.increment(key, now + windowMs);
    return {
      allowed: newCount <= limit,
      remaining: Math.max(0, limit - newCount),
      reset: now + windowMs,
    };
  }
  
  if (current.count >= limit) {
    return {
      allowed: false,
      remaining: 0,
      reset: current.resetTime,
    };
  }
  
  const newCount = await store.increment(key, current.resetTime);
  return {
    allowed: newCount <= limit,
    remaining: Math.max(0, limit - newCount),
    reset: current.resetTime,
  };
}

// Rate limit configuration helper
export function createCustomRateLimit(config: RateLimitConfig) {
  return rateLimiter({
    default: config
  });
}

// Get rate limit info for a user or IP
export async function getRateLimitInfo(
  identifier: string,
  store: RateLimitStore,
  windowMs: number = 15 * 60 * 1000
): Promise<{ count: number; resetTime: number; remaining: number } | null> {
  const current = await store.get(identifier);
  if (!current) return null;
  
  const limit = 100; // Default limit
  return {
    count: current.count,
    resetTime: current.resetTime,
    remaining: Math.max(0, limit - current.count),
  };
}

// Clear rate limit for a specific identifier
export async function clearRateLimit(
  identifier: string,
  store: RateLimitStore
): Promise<void> {
  await store.delete(identifier);
}

// Health check for rate limiter
export function createRateLimitHealthCheck(store: RateLimitStore) {
  return async (): Promise<{ healthy: boolean; store: string }> => {
    try {
      if (store instanceof MemoryRateLimitStore) {
        return { healthy: true, store: 'memory' };
      }
      
      // Test Redis connection
      const result = await store.get('health-check');
      return { healthy: true, store: 'redis' };
    } catch (error) {
      return { healthy: false, store: 'unknown' };
    }
  };
}

// Export types and defaults
export type { RateLimitConfig, RateLimitOptions, RateLimitInfo };
export { defaultRateLimits, SlidingWindowRateLimiter, RedisRateLimitStore, MemoryRateLimitStore };
