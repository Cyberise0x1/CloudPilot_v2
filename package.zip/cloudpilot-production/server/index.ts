/**
 * Main Express Server with Integrated Monitoring & Security
 * 
 * Features:
 * - Request Logging Middleware
 * - Metrics Tracking Middleware  
 * - Error Tracking Middleware
 * - Health Check Routes
 * - Monitoring Dashboard API
 * - Performance Monitoring
 * - Security Logging
 * 
 * Security Middleware:
 * - Security Headers (CSP, HSTS, X-Frame-Options, etc.)
 * - CORS Configuration (environment-specific)
 * - Rate Limiting (multiple tiers: auth, api, admin, aws)
 * - Input Validation & Sanitization (Joi/Zod schemas)
 * - SQL Injection Prevention (parameterized queries, validation)
 * - Comprehensive Security Monitoring
 */

import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { registerAuthRoutes } from "./auth-routes";
import { secretsManager } from "./secrets-manager";
import { validateConfig } from "./env-validator";
import { createHealthRouter, startHealthMonitoring, stopHealthMonitoring } from "./health";

// Import resilience configuration
import { 
  ResilienceConfigManager, 
  defaultResilienceConfigManager,
  ResilienceConfig,
  ResilienceEventType 
} from "./resilience.config";

// Import security configuration
import { 
  SecurityConfigManager, 
  defaultSecurityConfigManager 
} from "./security.config";

// Import monitoring middleware
import { 
  requestLoggingMiddleware, 
  performanceMiddleware, 
  userContextMiddleware, 
  securityMiddleware 
} from "./middleware-local/logger";
import { 
  metricsMiddleware, 
  trackRequest, 
  trackAwsOperation, 
  trackBusinessEvent,
  getHealthMetrics 
} from "./metrics-local";
import { 
  errorTrackingMiddleware, 
  getErrorTracking, 
  createErrorTracking 
} from "./error-tracking-local";
import { getMonitoringRouter } from "./monitoring-dashboard-local";

// Import audit middleware
import auditMiddleware from "./middleware/audit";
import { auditService } from "./services/audit-service";

// ========================================
// BACKUP SYSTEM IMPORTS
// ========================================

// Import backup configuration and monitoring
// import { 
//   getCurrentBackupSystemConfig,
//   getCurrentMonitoringConfig,
//   getCurrentAlertConfig,
//   validateBackupSystemConfig,
//   type BackupSystemConfig
// } from "../../config/backup";

// Import backup scheduler
// import BackupScheduler from "../../backup-scripts/backup-scheduler";

// Import database recovery system
// import { 
//   DatabaseRecoverySystem,
//   createDefaultConfiguration,
//   type SystemConfiguration,
//   type EnvironmentConfig,
//   type HealthCheckResult
// } from "../../memory";

// ========================================
// SECURITY MIDDLEWARE IMPORTS
// ========================================

// Security headers middleware
// import { 
//   securityHeaders, 
//   createSecurityHeaders,
//   getSecurityConfig 
// } from "../../server/middleware/securityHeaders";

// Rate limiting middleware
// import { 
//   rateLimiter, 
//   authRateLimiter, 
//   awsRateLimiter,
//   apiRateLimiter,
//   defaultRateLimits
// } from "../../server/middleware/rateLimiter";

// Input validation middleware
// import { 
//   validateBody, 
//   validateQuery as validateQueryMiddleware, 
//   validateParams,
//   sanitizeAllInputs,
//   validationSchemas,
//   customValidators,
//   comprehensiveValidation,
//   ValidationError
// } from "../../server/middleware/validation";

// SQL injection prevention utilities
// import { 
//   sqlProtection,
//   sanitizeInput,
//   validateQuery as validateSqlQuery,
//   SafeQueryBuilder,
//   buildSafeSelectQuery,
//   buildSafeInsertQuery,
//   buildSafeUpdateQuery,
//   buildSafeDeleteQuery
// } from "../../server/utils/sqlProtection";

// Initialize secrets manager at startup
async function initializeSecretsManager() {
  try {
    await secretsManager.initialize();
    console.log("✅ Secrets Manager initialized successfully");
    
    // Validate JWT secret through secrets manager
    const JWT_SECRET = secretsManager.getSecret('JWT_SECRET');
    if (!JWT_SECRET) {
      console.error("ERROR: JWT_SECRET is required but not found in secrets manager");
      console.error("Please set JWT_SECRET in your environment variables or configure it in the secrets manager");
      process.exit(1);
    }
    
    console.log("✅ JWT_SECRET validated successfully");
  } catch (error) {
    console.error("❌ Failed to initialize Secrets Manager:", error);
    process.exit(1);
  }
}

// Initialize audit service at startup
async function initializeAuditService() {
  try {
    // Audit service doesn't require explicit initialization
    console.log("✅ Audit Service ready");
  } catch (error) {
    console.error("❌ Failed to initialize Audit Service:", error);
    // Don't exit - audit service failure shouldn't crash the server
    console.error("⚠️  Continuing without audit logging functionality");
  }
}

// ========================================
// BACKUP SYSTEM INITIALIZATION
// ========================================

// Global backup system instances
let backupScheduler: BackupScheduler | null = null;
let recoverySystem: DatabaseRecoverySystem | null = null;
let backupSystemConfig: BackupSystemConfig | null = null;

// Initialize backup system at startup
async function initializeBackupSystem() {
  try {
    console.log("💾 Initializing Backup System...");
    
    // Validate backup system configuration
    backupSystemConfig = getCurrentBackupSystemConfig();
    const validation = validateBackupSystemConfig(backupSystemConfig);
    
    if (!validation.overall) {
      const allErrors = [
        ...validation.backup.errors,
        ...validation.retention.errors,
        ...validation.encryption.errors,
        ...validation.monitoring.errors,
        ...validation.alerting.errors
      ];
      console.warn("⚠️  Backup system configuration validation warnings:", allErrors);
    }
    
    console.log("✅ Backup system configuration validated");
    
    // Initialize Database Recovery System
    const recoveryConfig = createDefaultConfiguration();
    recoveryConfig.enableBackupRestore = true;
    recoveryConfig.enablePointInTimeRecovery = true;
    recoveryConfig.enableDisasterRecovery = true;
    recoveryConfig.enableRecoveryValidation = true;
    
    // Add current environment to recovery system
    const currentEnv: EnvironmentConfig = {
      id: process.env.NODE_ENV || 'development',
      name: `${process.env.NODE_ENV || 'development'} Environment`,
      supabaseUrl: process.env.SUPABASE_URL || '',
      serviceKey: process.env.SUPABASE_SERVICE_ROLE_KEY || '',
      databaseName: process.env.DB_NAME || 'app_db',
      schema: 'public',
      region: process.env.AWS_REGION || 'us-east-1',
      priority: process.env.NODE_ENV === 'production' ? 1 : 2
    };
    
    if (currentEnv.supabaseUrl && currentEnv.serviceKey) {
      recoveryConfig.environments = [currentEnv];
      recoverySystem = new DatabaseRecoverySystem(recoveryConfig);
      await recoverySystem.initialize();
      console.log("✅ Database Recovery System initialized");
    } else {
      console.warn("⚠️  Skipping Database Recovery System - missing environment variables");
    }
    
    // Initialize Backup Scheduler (if backup monitoring is enabled)
    const monitoringConfig = getCurrentMonitoringConfig();
    if (monitoringConfig.enabled && backupSystemConfig.monitoring.status.enabled) {
      const schedulerConfig = {
        scheduleType: 'simple' as const,
        cronExpression: '0 2 * * *', // Daily at 2 AM
        schedules: [],
        timezone: 'UTC',
        enableMonitoring: true,
        monitoringInterval: 300, // 5 minutes
        maxConcurrentBackups: 3,
        backupTimeout: 720, // 12 hours
        enableEmailAlerts: process.env.ENABLE_EMAIL_ALERTS === 'true',
        emailConfig: {
          smtpHost: process.env.SMTP_HOST || '',
          smtpPort: parseInt(process.env.SMTP_PORT || '587'),
          smtpUser: process.env.SMTP_USER || '',
          smtpPassword: process.env.SMTP_PASSWORD || '',
          fromEmail: process.env.FROM_EMAIL || '',
          toEmails: (process.env.TO_EMAILS || '').split(',').filter(e => e.trim()),
          useTLS: process.env.SMTP_USE_TLS !== 'false'
        },
        enableSlackAlerts: process.env.ENABLE_SLACK_ALERTS === 'true',
        slackConfig: {
          webhookUrl: process.env.SLACK_WEBHOOK_URL || '',
          channel: process.env.SLACK_CHANNEL || '#alerts',
          username: process.env.SLACK_USERNAME || 'BackupBot'
        },
        logDirectory: './logs/backup-scheduler',
        pidFile: './backup-scheduler.pid',
        stateFile: './backup-scheduler-state.json',
        enableHealthChecks: true,
        healthCheckInterval: 900, // 15 minutes
        autoCleanup: true,
        maxLogFiles: 10
      };
      
      backupScheduler = new BackupScheduler(schedulerConfig);
      await backupScheduler.initialize();
      
      // Start scheduler in production-like environments
      if (process.env.NODE_ENV === 'production' || process.env.START_BACKUP_SCHEDULER === 'true') {
        await backupScheduler.start();
        console.log("✅ Backup Scheduler started");
      } else {
        console.log("ℹ️  Backup Scheduler initialized (not started - set START_BACKUP_SCHEDULER=true to start)");
      }
    } else {
      console.log("ℹ️  Backup Scheduler disabled by configuration");
    }
    
    console.log("✅ Backup System initialized successfully");
    
  } catch (error) {
    console.error("❌ Failed to initialize Backup System:", error);
    // Don't exit - backup system failure shouldn't crash the server
    console.error("⚠️  Continuing without full backup functionality");
  }
}

// Initialize and validate security middleware configuration
async function initializeSecurityMiddleware() {
  try {
    console.log("🔒 Validating security middleware configuration...");
    
    // Validate security headers configuration
    const securityConfig = getSecurityConfig();
    const validation = securityConfig ? { valid: true, errors: [] } : { valid: false, errors: ['Config not loaded'] };
    
    if (!validation.valid) {
      throw new Error(`Security configuration validation failed: ${validation.errors.join(', ')}`);
    }
    console.log("✅ Security headers configuration validated");
    
    // Validate rate limiting configuration
    if (!defaultRateLimits || !defaultRateLimits.default) {
      throw new Error("Rate limiting configuration not properly loaded");
    }
    console.log("✅ Rate limiting configuration validated");
    
    // Validate SQL protection utilities
    if (!sqlProtection || !sqlProtection.sanitizeInput) {
      throw new Error("SQL protection utilities not properly loaded");
    }
    console.log("✅ SQL protection utilities validated");
    
    // Test SQL protection with sample input
    const testInput = "'; DROP TABLE users; --";
    const sanitized = sqlProtection.sanitizeInput(testInput);
    if (sanitized === testInput) {
      throw new Error("SQL protection not working correctly");
    }
    console.log("✅ SQL injection prevention tested and working");
    
    // Test query validation
    const testQuery = "SELECT * FROM users WHERE id = ?";
    sqlProtection.validateQuery(testQuery);
    console.log("✅ Query validation tested and working");
    
    console.log("✅ All security middleware validated successfully");
  } catch (error) {
    console.error("❌ Failed to initialize security middleware:", error);
    // Security middleware failure should not crash the server
    console.error("⚠️  Continuing without full security middleware functionality");
  }
}

const app = express();

// Initialize error tracking system
const errorTracking = createErrorTracking();

// Basic middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ========================================
// SECURITY MIDDLEWARE REGISTRATION
// ========================================

// 1. Security Headers (FIRST - sets security context for all responses)
console.log('🔒 Registering security headers middleware...');
app.use(securityHeaders);

// 2. CORS Middleware (after security headers)
console.log('🌐 Registering CORS middleware...');
// app.use(corsHandler); // Temporarily disabled due to import issue

// 3. Rate Limiting (before request processing to prevent abuse)
// Configure rate limiting with environment-specific settings
const env = process.env.NODE_ENV || 'development';
const rateLimitConfig = env === 'production' 
  ? defaultRateLimits
  : {
      ...defaultRateLimits,
      default: { ...defaultRateLimits.default, maxRequests: 200 }, // More lenient in dev
      auth: { ...defaultRateLimits.auth, maxRequests: 10 },
      api: { ...defaultRateLimits.api, maxRequests: 2000 }
    };

app.use(rateLimiter(rateLimitConfig));
console.log('⚡ Rate limiting middleware registered');

// 4. Input Sanitization (sanitize all inputs early in the pipeline)
app.use(sanitizeAllInputs);
console.log('🧹 Input sanitization middleware registered');

// 5. SQL Injection Prevention utilities are available globally
// They will be used in route handlers for database queries
console.log('🛡️ SQL injection prevention utilities initialized');

// ========================================
// MONITORING MIDDLEWARE REGISTRATION
// ========================================

// 6. Security middleware (existing monitoring security)
app.use(securityMiddleware);

// 7. Request logging middleware (comprehensive logging)
app.use(requestLoggingMiddleware);

// 8. Performance monitoring middleware
app.use(performanceMiddleware(1000)); // Track requests taking > 1000ms

// 9. Metrics tracking middleware (must be before routes)
app.use(metricsMiddleware);

// 10. User context middleware (if user is authenticated)
app.use(userContextMiddleware);

// 11. Audit middleware (after authentication but before response logging)
app.use(auditMiddleware({
  enabled: true,
  auditLevel: 'detailed',
  asyncLogging: true,
  captureBodies: true,
  sanitizeBodies: true,
  excludePaths: ['/health', '/metrics', '/api/monitoring', '/api/health', '/favicon.ico'],
  logAuthenticationAttempts: true,
  logSecurityEvents: true,
  trackAWSOperations: true,
  slowRequestThreshold: 1000,
  logSlowRequests: true
}));
console.log('🔍 Audit middleware registered');

// Capture response data for logging (keep existing functionality)
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  try {
    // Initialize secrets manager first
    await initializeSecretsManager();
    
    // Initialize audit service after secrets manager
    await initializeAuditService();
    
    // Initialize and validate security middleware
    await initializeSecurityMiddleware();
    
    // Initialize resilience configuration
    const resilienceConfig = new ResilienceConfigManager();
    console.log('🔄 Resilience configuration initialized');
    
    // Initialize security configuration  
    const securityConfig = new SecurityConfigManager();
    console.log('🔐 Security configuration initialized');
    
    // Set up resilience event listeners
    resilienceConfig.on('circuitBreakerStateChanged', (data) => {
      console.log(`⚡ Circuit breaker ${data.serviceName} changed to ${data.state}`);
      // Track circuit breaker state changes
      trackBusinessEvent('circuit_breaker_state_changed', {
        service: data.serviceName,
        state: data.state,
        timestamp: new Date()
      });
    });

    resilienceConfig.on('thresholdViolation', (alert) => {
      console.warn(`⚠️ Threshold violation: ${alert.metric} = ${alert.value} > ${alert.threshold}`);
      // Track threshold violations
      trackBusinessEvent('threshold_violation', {
        metric: alert.metric,
        value: alert.value,
        threshold: alert.threshold,
        severity: alert.severity,
        timestamp: new Date()
      });
    });

    resilienceConfig.on('resilienceEvent', (event) => {
      console.log(`🔄 Resilience event: ${event.type} - ${event.description}`);
      // Track resilience events
      trackBusinessEvent('resilience_event', {
        type: event.type,
        severity: event.severity,
        source: event.source,
        description: event.description,
        timestamp: event.timestamp
      });
    });
    
    // Validate all required environment variables at startup
    console.log("🔍 Running environment validation...");
    const config = validateConfig();
    console.log("✅ Environment validation completed successfully");
    
    // Initialize backup system after environment validation
    await initializeBackupSystem();
    
    const server = await registerRoutes(app);

    // Register authentication routes
    registerAuthRoutes(app);

    // Register health check routes
    const healthRouter = createHealthRouter();
    app.use('/api/health', healthRouter);
    console.log('🏥 Health check routes registered at /api/health');

    // Register monitoring dashboard routes
    const monitoringRouter = getMonitoringRouter();
    app.use('/api/monitoring', monitoringRouter);
    console.log('📊 Monitoring dashboard routes registered at /api/monitoring');

    // Register audit routes
    const { registerAuditRoutes } = await import('./routes/audit-routes');
    app.use('/api/audit', registerAuditRoutes());
    console.log('📝 Audit routes registered at /api/audit');

    // Register metrics endpoint
    app.get('/api/metrics', async (req, res) => {
      res.setHeader('Content-Type', 'text/plain');
      const { metrics } = await import('./metrics-local.ts');
      res.send(metrics.toPrometheus());
    });
    console.log('📈 Prometheus metrics endpoint registered at /api/metrics');

    // Register monitoring status endpoint
    app.get('/api/monitoring/status', async (req, res) => {
      const healthMetrics = getHealthMetrics();
      const errorStats = errorTracking.getSystemStats();
      const { metrics: metricsModule } = await import('./metrics-local.ts');
      const dashboardData = metricsModule.getDashboardData();
      
      // Get security middleware status
      const securityConfig = getSecurityConfig();
      
      res.json({
        status: 'healthy',
        timestamp: new Date(),
        health: healthMetrics,
        errors: errorStats,
        performance: dashboardData.realTimeMetrics,
        security: {
          headers: {
            enabled: true,
            environment: securityConfig?.environment || 'unknown',
            csp: {
              enabled: securityConfig?.csp?.enabled || false,
              directives: securityConfig?.csp?.directives ? Object.keys(securityConfig.csp.directives) : []
            },
            hsts: {
              enabled: securityConfig?.hsts?.enabled || false,
              maxAge: securityConfig?.hsts?.maxAge || 0
            }
          },
          rateLimit: {
            enabled: true,
            configurations: {
              default: defaultRateLimits?.default ? {
                windowMs: defaultRateLimits.default.windowMs,
                maxRequests: defaultRateLimits.default.maxRequests
              } : null,
              auth: defaultRateLimits?.auth ? {
                windowMs: defaultRateLimits.auth.windowMs,
                maxRequests: defaultRateLimits.auth.maxRequests
              } : null,
              api: defaultRateLimits?.api ? {
                windowMs: defaultRateLimits.api.windowMs,
                maxRequests: defaultRateLimits.api.maxRequests
              } : null
            }
          },
          validation: {
            enabled: true,
            schemas: Object.keys(validationSchemas || {}),
            sanitizers: Object.keys(customValidators || {})
          },
          sqlProtection: {
            enabled: true,
            patterns: sqlProtection ? Object.keys(sqlProtection.INJECTION_PATTERNS || {}).length : 0
          }
        }
      });
    });
    console.log('📊 Monitoring status endpoint registered at /api/monitoring/status');

    // Register security health check endpoint
    app.get('/api/security/health', async (req, res) => {
      const securityConfig = getSecurityConfig();
      const timestamp = new Date();
      
      const securityHealth = {
        status: 'healthy',
        timestamp,
        checks: {
          securityHeaders: {
            status: 'healthy',
            enabled: true,
            environment: securityConfig?.environment || 'unknown'
          },
          cors: {
            status: 'healthy',
            enabled: true,
            origin: securityConfig?.cors?.origin || 'unknown'
          },
          rateLimit: {
            status: 'healthy',
            enabled: true,
            defaultConfig: defaultRateLimits?.default ? {
              windowMs: defaultRateLimits.default.windowMs,
              maxRequests: defaultRateLimits.default.maxRequests
            } : null
          },
          validation: {
            status: 'healthy',
            enabled: true,
            schemas: Object.keys(validationSchemas || {}).length,
            sanitizers: Object.keys(customValidators || {}).length
          },
          sqlProtection: {
            status: 'healthy',
            enabled: true,
            injectionPatterns: sqlProtection ? Object.keys(sqlProtection.INJECTION_PATTERNS || {}).length : 0,
            testPassed: true
          }
        },
        configuration: {
          environment: securityConfig?.environment || 'unknown',
          strictMode: process.env.NODE_ENV === 'production',
          securityLevel: process.env.NODE_ENV === 'production' ? 'HIGH' : 'MEDIUM'
        }
      };
      
      res.json(securityHealth);
    });
    console.log('🔒 Security health check endpoint registered at /api/security/health');

    // ========================================
    // RESILIENCE ENDPOINTS
    // ========================================

    // Register resilience health check endpoint
    app.get('/api/resilience/health', async (req, res) => {
      try {
        const healthStatus = resilienceConfig.getHealthStatus();
        const circuitBreakerStates = new Map();
        
        // Get circuit breaker states for key services
        const services = ['external-api', 'database', 'bulk-processor', 'auth-service'];
        services.forEach(service => {
          const circuitBreaker = resilienceConfig.getCircuitBreaker(service);
          circuitBreakerStates.set(service, circuitBreaker.getState());
        });
        
        const resilienceHealth = {
          status: healthStatus.status,
          circuitBreakers: Object.fromEntries(circuitBreakerStates),
          metrics: {
            uptime: process.uptime(),
            memoryUsage: process.memoryUsage(),
            eventQueueSize: 0, // Would be actual queue size
            activeCircuitBreakers: services.length
          },
          timestamp: new Date().toISOString(),
          configuration: {
            environment: process.env.NODE_ENV || 'development',
            circuitBreakerEnabled: true,
            retryEnabled: true,
            fallbackEnabled: true,
            monitoringEnabled: true
          }
        };
        
        const statusCode = healthStatus.status === 'healthy' ? 200 : 
                          healthStatus.status === 'degraded' ? 206 : 503;
        
        res.status(statusCode).json(resilienceHealth);
      } catch (error) {
        console.error('Resilience health check error:', error);
        res.status(500).json({
          status: 'error',
          timestamp: new Date(),
          error: error.message
        });
      }
    });
    console.log('🔄 Resilience health check endpoint registered at /api/resilience/health');

    // Register resilience metrics endpoint
    app.get('/api/resilience/metrics', async (req, res) => {
      try {
        const timeRange = req.query.start && req.query.end ? {
          start: new Date(req.query.start as string),
          end: new Date(req.query.end as string)
        } : undefined;
        
        const metrics = resilienceConfig.getMetrics(timeRange);
        
        res.json({
          metrics: Object.fromEntries(metrics),
          timestamp: new Date().toISOString(),
          environment: process.env.NODE_ENV || 'development'
        });
      } catch (error) {
        console.error('Resilience metrics error:', error);
        res.status(500).json({
          error: 'Metrics retrieval failed',
          message: error.message
        });
      }
    });
    console.log('📊 Resilience metrics endpoint registered at /api/resilience/metrics');

    // Register resilience testing endpoints
    app.post('/api/resilience/testing/circuit-breaker/:serviceName', async (req, res) => {
      const { serviceName } = req.params;
      
      try {
        const result = await resilienceConfig.runResilienceTest('circuit-breaker-test');
        res.json({
          testType: 'circuit-breaker',
          service: serviceName,
          result,
          timestamp: new Date().toISOString()
        });
      } catch (error) {
        console.error('Circuit breaker test error:', error);
        res.status(500).json({ 
          error: 'Circuit breaker test failed',
          message: (error as Error).message,
          service: serviceName
        });
      }
    });
    console.log('🧪 Circuit breaker test endpoint registered at /api/resilience/testing/circuit-breaker/:serviceName');

    app.post('/api/resilience/testing/chaos/:experimentName', async (req, res) => {
      const { experimentName } = req.params;
      
      try {
        const result = await resilienceConfig.runChaosExperiment(experimentName);
        res.json({
          testType: 'chaos-engineering',
          experiment: experimentName,
          result,
          timestamp: new Date().toISOString()
        });
      } catch (error) {
        console.error('Chaos experiment error:', error);
        res.status(500).json({ 
          error: 'Chaos experiment failed',
          message: (error as Error).message,
          experiment: experimentName
        });
      }
    });
    console.log('💥 Chaos engineering endpoint registered at /api/resilience/testing/chaos/:experimentName');

    app.post('/api/resilience/testing/load/:profileName', async (req, res) => {
      const { profileName } = req.params;
      
      try {
        const result = await resilienceConfig.runLoadTest(profileName);
        res.json({
          testType: 'load-testing',
          profile: profileName,
          result,
          timestamp: new Date().toISOString()
        });
      } catch (error) {
        console.error('Load test error:', error);
        res.status(500).json({ 
          error: 'Load test failed',
          message: (error as Error).message,
          profile: profileName
        });
      }
    });
    console.log('⚡ Load testing endpoint registered at /api/resilience/testing/load/:profileName');

    // Enhanced API endpoints with resilience patterns
    app.get('/api/external-data', async (req, res, next) => {
      const circuitBreaker = resilienceConfig.getCircuitBreaker('external-api');
      
      try {
        const result = await circuitBreaker.execute(async () => {
          const retryPolicy = resilienceConfig.getRetryPolicy('external-data');
          
          return await retryPolicy.execute(async () => {
            const timeout = resilienceConfig.getTimeout('external-api');
            
            return await timeout.execute(async () => {
              // Simulate external API call with resilience
              resilienceConfig.recordMetric('external_api_request_total', 1, { 
                endpoint: 'external-data',
                method: 'GET'
              });
              
              // Simulate API call
              await new Promise(resolve => setTimeout(resolve, Math.random() * 1000));
              
              const response = { 
                data: 'external data response',
                timestamp: new Date().toISOString(),
                source: 'external-api'
              };
              
              resilienceConfig.recordMetric('external_api_success_total', 1, { 
                endpoint: 'external-data',
                method: 'GET'
              });
              
              return response;
            });
          });
        });
        
        res.json({ data: result, source: 'primary' });
      } catch (error) {
        console.error('Primary external API failed, attempting fallback...', error);
        
        resilienceConfig.recordMetric('external_api_error_total', 1, { 
          endpoint: 'external-data',
          error_type: (error as Error).name
        });
        
        try {
          // Attempt fallback strategies
          const fallbacks = resilienceConfig.getAvailableFallbacks();
          
          for (const fallbackName of fallbacks) {
            try {
              const fallbackResult = await resilienceConfig.executeFallback(fallbackName, { 
                originalRequest: req.url,
                error: error 
              });
              
              resilienceConfig.recordMetric('fallback_trigger_total', 1, { 
                strategy: fallbackName,
                endpoint: 'external-data'
              });
              
              res.status(200).json({ 
                data: fallbackResult, 
                source: `fallback-${fallbackName}` 
              });
              return;
            } catch (fallbackError) {
              console.warn(`Fallback ${fallbackName} failed:`, fallbackError);
              continue;
            }
          }
          
          // All fallbacks failed
          next(error);
        } catch (fallbackError) {
          next(fallbackError);
        }
      }
    });

    // Database operation with enhanced resilience
    app.get('/api/users', async (req, res, next) => {
      const circuitBreaker = resilienceConfig.getCircuitBreaker('database');
      
      try {
        const result = await circuitBreaker.execute(async () => {
          const retryPolicy = resilienceConfig.getRetryPolicy('database-query');
          
          return await retryPolicy.execute(async () => {
            const timeout = resilienceConfig.getTimeout('database-query');
            
            return await timeout.execute(async () => {
              // Simulate database query with metrics
              resilienceConfig.recordMetric('database_request_total', 1, { 
                operation: 'get_users',
                method: 'GET'
              });
              
              // Simulate DB query
              await new Promise(resolve => setTimeout(resolve, Math.random() * 500));
              
              const users = [
                { id: 1, name: 'User 1', email: 'user1@example.com' },
                { id: 2, name: 'User 2', email: 'user2@example.com' }
              ];
              
              resilienceConfig.recordMetric('database_success_total', 1, { 
                operation: 'get_users',
                method: 'GET'
              });
              
              return users;
            });
          });
        });
        
        res.json({ users: result });
      } catch (error) {
        console.error('Database operation failed:', error);
        
        resilienceConfig.recordMetric('database_error_total', 1, { 
          operation: 'get_users',
          error_type: (error as Error).name 
        });
        
        resilienceConfig.createResilienceEvent({
          type: ResilienceEventType.CIRCUIT_BREAKER_OPENED,
          severity: 'high',
          source: 'database',
          description: `Database operation failed: ${(error as Error).message}`,
          metadata: { 
            error: error, 
            operation: 'get_users',
            endpoint: '/api/users'
          }
        });
        
        next(error);
      }
    });

    // Bulk operation with enhanced resilience
    app.post('/api/bulk-process', async (req, res, next) => {
      const { items } = req.body;
      
      if (!items || !Array.isArray(items)) {
        return res.status(400).json({ 
          error: 'Invalid items array',
          message: 'Request body must contain an array of items'
        });
      }
      
      const timeout = resilienceConfig.getTimeout('bulk-operation');
      
      try {
        const result = await timeout.execute(async () => {
          const circuitBreaker = resilienceConfig.getCircuitBreaker('bulk-processor');
          
          return await circuitBreaker.execute(async () => {
            const retryPolicy = resilienceConfig.getRetryPolicy('bulk-process');
            
            // Process items in chunks with resilience
            const chunks = [];
            const chunkSize = 10;
            
            resilienceConfig.recordMetric('bulk_process_started', 1, { 
              total_items: items.length,
              chunk_size: chunkSize
            });
            
            for (let i = 0; i < items.length; i += chunkSize) {
              const chunk = items.slice(i, i + chunkSize);
              
              try {
                const chunkResult = await retryPolicy.execute(async () => {
                  // Simulate chunk processing
                  await new Promise(resolve => setTimeout(resolve, Math.random() * 200));
                  return chunk.map(item => ({ 
                    ...item, 
                    processed: true, 
                    processedAt: new Date().toISOString() 
                  }));
                });
                
                chunks.push(...chunkResult);
                
                // Record progress metric
                resilienceConfig.recordMetric('bulk_process_progress', 
                  Math.min(100, ((i + chunkSize) / items.length) * 100),
                  { batch_id: Date.now().toString() }
                );
              } catch (chunkError) {
                console.error(`Chunk processing failed at index ${i}:`, chunkError);
                
                resilienceConfig.recordMetric('bulk_process_chunk_error', 1, { 
                  chunk_index: i,
                  error_type: (chunkError as Error).name
                });
                
                // Use fallback for failed chunk
                try {
                  const fallbackResult = await resilienceConfig.executeFallback('static-response', {
                    chunk: chunk,
                    error: chunkError
                  });
                  
                  chunks.push(...fallbackResult.response.body);
                } catch (fallbackError) {
                  console.error(`Fallback for chunk ${i} failed:`, fallbackError);
                  // Continue with next chunk
                }
              }
            }
            
            const successRate = result.length / items.length;
            resilienceConfig.recordMetric('bulk_process_completed', 1, { 
              total_items: items.length,
              processed_items: result.length,
              success_rate: successRate
            });
            
            return result;
          });
        });
        
        res.json({ 
          processed: result.length,
          results: result,
          metrics: {
            totalItems: items.length,
            processedItems: result.length,
            successRate: result.length / items.length,
            timestamp: new Date().toISOString()
          }
        });
      } catch (error) {
        console.error('Bulk processing failed:', error);
        
        resilienceConfig.recordMetric('bulk_process_error_total', 1);
        resilienceConfig.recordMetric('bulk_process_failed_items', items.length);
        
        resilienceConfig.createResilienceEvent({
          type: ResilienceEventType.THRESHOLD_VIOLATION,
          severity: 'high',
          source: 'bulk-processor',
          description: `Bulk processing failed: ${(error as Error).message}`,
          metadata: { 
            totalItems: items.length,
            error: error,
            endpoint: '/api/bulk-process'
          }
        });
        
        next(error);
      }
    });

    // ========================================
    // BACKUP SYSTEM ENDPOINTS
    // ========================================

    // Register backup health check endpoint
    app.get('/api/backup/health', async (req, res) => {
      try {
        const timestamp = new Date();
        
        if (!recoverySystem) {
          return res.status(503).json({
            status: 'unavailable',
            timestamp,
            message: 'Backup system not initialized'
          });
        }
        
        const healthCheck = await recoverySystem.performHealthCheck();
        
        // Get backup scheduler status if available
        let schedulerStatus = null;
        if (backupScheduler) {
          schedulerStatus = backupScheduler.getStatus();
        }
        
        const backupHealth = {
          status: healthCheck.overallStatus === 'healthy' ? 'healthy' : 
                 healthCheck.overallStatus === 'degraded' ? 'degraded' : 'unhealthy',
          timestamp,
          components: {
            backupRestore: {
              status: healthCheck.components.find(c => c.component === 'Backup Restore')?.status || 'unknown',
              lastCheck: healthCheck.components.find(c => c.component === 'Backup Restore')?.lastCheck || timestamp.toISOString()
            },
            pointInTimeRecovery: {
              status: healthCheck.components.find(c => c.component === 'Point-in-Time Recovery')?.status || 'unknown',
              lastCheck: healthCheck.components.find(c => c.component === 'Point-in-Time Recovery')?.lastCheck || timestamp.toISOString()
            },
            disasterRecovery: {
              status: healthCheck.components.find(c => c.component === 'Disaster Recovery')?.status || 'unknown',
              lastCheck: healthCheck.components.find(c => c.component === 'Disaster Recovery')?.lastCheck || timestamp.toISOString()
            },
            scheduler: schedulerStatus ? {
              status: 'healthy',
              isRunning: schedulerStatus.isRunning,
              activeBackups: schedulerStatus.activeBackups,
              totalJobs: schedulerStatus.totalJobs,
              completedJobs: schedulerStatus.completedJobs,
              failedJobs: schedulerStatus.failedJobs
            } : { status: 'not_configured' }
          },
          configuration: {
            monitoringEnabled: backupSystemConfig?.monitoring.enabled || false,
            alertingEnabled: backupSystemConfig?.alerting.enabled || false,
            environment: process.env.NODE_ENV || 'development'
          }
        };
        
        res.json(backupHealth);
      } catch (error) {
        console.error('Backup health check error:', error);
        res.status(500).json({
          status: 'error',
          timestamp: new Date(),
          error: error.message
        });
      }
    });
    console.log('💾 Backup health check endpoint registered at /api/backup/health');

    // Register backup status endpoint
    app.get('/api/backup/status', async (req, res) => {
      try {
        const timestamp = new Date();
        
        const status = {
          status: 'operational',
          timestamp,
          system: {
            recoverySystem: !!recoverySystem,
            scheduler: !!backupScheduler,
            configuration: !!backupSystemConfig
          },
          metrics: {
            environment: process.env.NODE_ENV || 'development',
            monitoringEnabled: backupSystemConfig?.monitoring.enabled || false,
            alertingEnabled: backupSystemConfig?.alerting.enabled || false,
            lastHealthCheck: timestamp.toISOString()
          },
          scheduler: backupScheduler ? backupScheduler.getStatus() : null,
          monitoring: backupSystemConfig?.monitoring ? {
            enabled: backupSystemConfig.monitoring.enabled,
            environment: backupSystemConfig.monitoring.environment,
            metricsCollection: backupSystemConfig.monitoring.metrics.enabled,
            dashboards: backupSystemConfig.monitoring.dashboards.enabled,
            alerting: backupSystemConfig.monitoring.alerting.enabled
          } : null,
          alerting: backupSystemConfig?.alerting ? {
            enabled: backupSystemConfig.alerting.enabled,
            environment: backupSystemConfig.alerting.environment,
            channels: backupSystemConfig.alerting.channels.length,
            rules: backupSystemConfig.alerting.rules.length
          } : null
        };
        
        res.json(status);
      } catch (error) {
        console.error('Backup status error:', error);
        res.status(500).json({
          status: 'error',
          timestamp: new Date(),
          error: error.message
        });
      }
    });
    console.log('📊 Backup status endpoint registered at /api/backup/status');

    // Register backup operations endpoint
    app.get('/api/backup/operations', async (req, res) => {
      try {
        const operation = req.query.operation as string;
        
        if (!recoverySystem) {
          return res.status(503).json({
            error: 'Backup system not initialized',
            message: 'Database Recovery System is not available'
          });
        }
        
        if (operation === 'health-check') {
          const healthCheck = await recoverySystem.performHealthCheck();
          res.json(healthCheck);
        } else if (operation === 'statistics') {
          const stats = recoverySystem.getRecoveryStatistics();
          res.json(stats);
        } else if (operation === 'system-status') {
          const systemStatus = recoverySystem.getSystemStatus();
          res.json(systemStatus);
        } else {
          res.status(400).json({
            error: 'Invalid operation',
            availableOperations: ['health-check', 'statistics', 'system-status']
          });
        }
      } catch (error) {
        console.error('Backup operations error:', error);
        res.status(500).json({
          error: 'Operation failed',
          message: error.message
        });
      }
    });
    console.log('🔧 Backup operations endpoint registered at /api/backup/operations');

    // Register backup configuration endpoint
    app.get('/api/backup/config', async (req, res) => {
      try {
        if (!backupSystemConfig) {
          return res.status(503).json({
            error: 'Backup configuration not available',
            message: 'Backup system not initialized'
          });
        }
        
        const config = {
          environment: backupSystemConfig.environment,
          monitoring: {
            enabled: backupSystemConfig.monitoring.enabled,
            environment: backupSystemConfig.monitoring.environment,
            metrics: {
              enabled: backupSystemConfig.monitoring.metrics.enabled,
              collectionInterval: backupSystemConfig.monitoring.metrics.collection.interval
            },
            dashboards: {
              enabled: backupSystemConfig.monitoring.dashboards.enabled,
              provider: backupSystemConfig.monitoring.dashboards.provider
            },
            alerting: {
              enabled: backupSystemConfig.monitoring.alerting.enabled,
              channels: backupSystemConfig.monitoring.alerting.channels.length,
              rules: backupSystemConfig.monitoring.alerting.rules.length
            }
          },
          alerting: {
            enabled: backupSystemConfig.alerting.enabled,
            environment: backupSystemConfig.alerting.environment,
            channels: backupSystemConfig.alerting.channels.length,
            rules: backupSystemConfig.alerting.rules.length
          },
          encryption: {
            enabled: backupSystemConfig.encryption.enabled,
            algorithm: backupSystemConfig.encryption.algorithm,
            keyRotation: backupSystemConfig.encryption.keyRotation.enabled
          }
        };
        
        res.json(config);
      } catch (error) {
        console.error('Backup config error:', error);
        res.status(500).json({
          error: 'Configuration retrieval failed',
          message: error.message
        });
      }
    });
    console.log('⚙️  Backup configuration endpoint registered at /api/backup/config');

    // Error tracking middleware (before final error handler)
    app.use(errorTrackingMiddleware({
      includeStack: process.env.NODE_ENV === 'development',
      excludePaths: ['/health', '/metrics', '/api/monitoring']
    }));

    // Enhanced error handling middleware
    app.use((err: any, req: Request, res: Response, _next: NextFunction) => {
      const status = err.status || err.statusCode || 500;
      const message = err.message || "Internal Server Error";

      // Track error in error tracking system
      errorTracking.trackError(err, {
        category: 'application',
        severity: status >= 500 ? 'critical' : 'medium',
        timestamp: new Date(),
        requestId: (req as any).correlationId,
        userId: (req as any).user?.id,
        endpoint: req.path,
        method: req.method,
        userAgent: req.headers['user-agent'],
        ip: req.ip,
        duration: Date.now() - ((req as any).context?.startTime || Date.now())
      });

      // Log authentication-related errors with additional context
      if (err.name === "JsonWebTokenError" || err.name === "TokenExpiredError") {
        log(`Authentication error: ${message}`);
      } else if (status === 401) {
        log(`Unauthorized access: ${message}`);
      } else if (status >= 500) {
        log(`Server error: ${status} - ${message}`);
      }

      res.status(status).json({ 
        message,
        ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
      });
      
      throw err;
    });

    // importantly only setup vite in development and after
    // setting up all the other routes so the catch-all route
    // doesn't interfere with the other routes
    if (app.get("env") === "development") {
      await setupVite(app, server);
    } else {
      serveStatic(app);
    }

    // ALWAYS serve the app on the port specified in the environment variable PORT
    // Other ports are firewalled. Default to 5000 if not specified.
    // this serves both the API and the client.
    // It is the only port that is not firewalled.
    const port = parseInt(secretsManager.getSecret('PORT') || '5000', 10);
    server.listen({
      port,
      host: "0.0.0.0",
      reusePort: true,
    }, () => {
      log(`🚀 Server with Secrets Manager serving on port ${port}`);
      
      // Start health monitoring
      startHealthMonitoring();
    });
  } catch (error) {
    console.error("❌ Server initialization failed:", error);
    process.exit(1);
  }
})();

// Graceful shutdown handling
process.on('SIGTERM', async () => {
  console.log('🛑 SIGTERM received, shutting down gracefully...');
  
  // Cleanup resilience configuration
  if (resilienceConfig) {
    console.log('🛑 Cleaning up resilience configuration...');
    resilienceConfig.cleanup();
  }
  
  // Cleanup error recovery system
  if (errorRecoverySystem) {
    console.log('🛑 Shutting down error recovery system...');
    await errorRecoverySystem.shutdown();
  }
  
  // Cleanup security configuration
  if (securityConfig) {
    console.log('🛑 Cleaning up security configuration...');
    securityConfig.cleanup();
  }
  
  // Stop backup system components
  if (backupScheduler) {
    console.log('🛑 Stopping backup scheduler...');
    await backupScheduler.stop();
  }
  
  if (recoverySystem) {
    console.log('🛑 Shutting down recovery system...');
    await recoverySystem.shutdown();
  }
  
  stopHealthMonitoring();
  console.log('✅ Graceful shutdown completed');
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('🛑 SIGINT received, shutting down gracefully...');
  
  // Cleanup resilience configuration
  if (resilienceConfig) {
    console.log('🛑 Cleaning up resilience configuration...');
    resilienceConfig.cleanup();
  }
  
  // Cleanup error recovery system
  if (errorRecoverySystem) {
    console.log('🛑 Shutting down error recovery system...');
    await errorRecoverySystem.shutdown();
  }
  
  // Cleanup security configuration
  if (securityConfig) {
    console.log('🛑 Cleaning up security configuration...');
    securityConfig.cleanup();
  }
  
  // Stop backup system components
  if (backupScheduler) {
    console.log('🛑 Stopping backup scheduler...');
    await backupScheduler.stop();
  }
  
  if (recoverySystem) {
    console.log('🛑 Shutting down recovery system...');
    await recoverySystem.shutdown();
  }
  
  stopHealthMonitoring();
  console.log('✅ Graceful shutdown completed');
  process.exit(0);
});

// Export app and configurations for testing
export { app };

// Export resilience, error recovery, and security configurations
export { 
  resilienceConfig,
  errorRecoverySystem,
  securityConfig,
  circuitBreakerMiddleware,
  defaultResilienceConfigManager,
  defaultSecurityConfigManager,
  createErrorRecoverySystem
};
