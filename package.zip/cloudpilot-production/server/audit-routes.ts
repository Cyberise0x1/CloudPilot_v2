import type { Express } from "express";
import { authenticateToken, requireAdmin } from "./auth";
import { storage } from "./storage";
import { createAuditLogSchema, createAuditEventSchema } from "@shared/schema";

export function registerAuditRoutes(app: Express): void {
  // Helper function to extract client info
  const getClientInfo = (req: any) => ({
    ipAddress: req.ip || req.connection.remoteAddress || req.headers['x-forwarded-for'],
    userAgent: req.headers['user-agent'] || req.get('user-agent')
  });

  // GET /api/audit/logs - Get filtered audit logs
  app.get("/api/audit/logs", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const {
        userId,
        action,
        resourceType,
        resourceId,
        success,
        startDate,
        endDate,
        limit,
        offset
      } = req.query;

      const filters: any = {};
      
      if (userId && typeof userId === 'string') filters.userId = userId;
      if (action && typeof action === 'string') filters.action = action;
      if (resourceType && typeof resourceType === 'string') filters.resourceType = resourceType;
      if (resourceId && typeof resourceId === 'string') filters.resourceId = resourceId;
      if (success === 'true' || success === 'false') filters.success = success === 'true';
      if (startDate && typeof startDate === 'string') filters.startDate = new Date(startDate);
      if (endDate && typeof endDate === 'string') filters.endDate = new Date(endDate);
      if (limit && typeof limit === 'string') filters.limit = parseInt(limit, 10);
      if (offset && typeof offset === 'string') filters.offset = parseInt(offset, 10);

      const logs = await storage.getAuditLogs(filters);
      
      res.json({
        success: true,
        data: logs,
        total: logs.length
      });
    } catch (error: any) {
      res.status(500).json({ 
        success: false, 
        message: error.message,
        error: 'AUDIT_LOGS_FETCH_ERROR'
      });
    }
  });

  // GET /api/audit/user/:userId - Get user-specific audit trail
  app.get("/api/audit/user/:userId", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { userId } = req.params;
      const { limit = '50', page = '1' } = req.query;
      
      const offset = (parseInt(page as string, 10) - 1) * parseInt(limit as string, 10);
      
      const logs = await storage.getAuditLogs({
        userId,
        limit: parseInt(limit as string, 10),
        offset
      });

      // Get user information
      const user = await storage.getUserById(userId);
      
      res.json({
        success: true,
        data: {
          user,
          logs,
          pagination: {
            page: parseInt(page as string, 10),
            limit: parseInt(limit as string, 10),
            total: logs.length
          }
        }
      });
    } catch (error: any) {
      res.status(500).json({ 
        success: false, 
        message: error.message,
        error: 'USER_AUDIT_FETCH_ERROR'
      });
    }
  });

  // GET /api/audit/resource/:type/:id - Get resource-specific audit trail
  app.get("/api/audit/resource/:type/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { type, id } = req.params;
      const { startDate, endDate, limit = '100' } = req.query;
      
      const filters: any = {
        resourceType: type,
        resourceId: id,
        limit: parseInt(limit as string, 10)
      };
      
      if (startDate && typeof startDate === 'string') {
        filters.startDate = new Date(startDate);
      }
      if (endDate && typeof endDate === 'string') {
        filters.endDate = new Date(endDate);
      }

      const logs = await storage.getAuditLogs(filters);
      
      // Get resource-specific events
      const events = await storage.getAuditEvents({
        resourceType: type,
        resourceId: id,
        limit: parseInt(limit as string, 10)
      });
      
      res.json({
        success: true,
        data: {
          resource: {
            type,
            id
          },
          logs,
          events,
          total: {
            logs: logs.length,
            events: events.length
          }
        }
      });
    } catch (error: any) {
      res.status(500).json({ 
        success: false, 
        message: error.message,
        error: 'RESOURCE_AUDIT_FETCH_ERROR'
      });
    }
  });

  // GET /api/audit/security - Get security events
  app.get("/api/audit/security", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { 
        severity, 
        eventType, 
        startDate, 
        endDate, 
        limit = '50', 
        offset = '0' 
      } = req.query;

      const filters: any = {
        eventCategory: 'SECURITY',
        limit: parseInt(limit as string, 10),
        offset: parseInt(offset as string, 10)
      };
      
      if (severity && typeof severity === 'string') filters.severity = severity;
      if (eventType && typeof eventType === 'string') filters.eventType = eventType;
      if (startDate && typeof startDate === 'string') filters.startDate = new Date(startDate);
      if (endDate && typeof endDate === 'string') filters.endDate = new Date(endDate);

      const events = await storage.getAuditEvents(filters);
      
      // Also get security-related audit logs
      const securityLogs = await storage.getAuditLogs({
        action: 'LOGIN',
        success: false,
        limit: parseInt(limit as string, 10)
      });

      res.json({
        success: true,
        data: {
          securityEvents: events,
          failedLogins: securityLogs,
          filters: {
            severity,
            eventType,
            startDate,
            endDate
          }
        }
      });
    } catch (error: any) {
      res.status(500).json({ 
        success: false, 
        message: error.message,
        error: 'SECURITY_EVENTS_FETCH_ERROR'
      });
    }
  });

  // GET /api/audit/export - Export audit data
  app.get("/api/audit/export", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { 
        format = 'json',
        startDate, 
        endDate,
        userId,
        action,
        resourceType
      } = req.query;

      const filters: any = {};
      
      if (startDate && typeof startDate === 'string') filters.startDate = new Date(startDate);
      if (endDate && typeof endDate === 'string') filters.endDate = new Date(endDate);
      if (userId && typeof userId === 'string') filters.userId = userId;
      if (action && typeof action === 'string') filters.action = action;
      if (resourceType && typeof resourceType === 'string') filters.resourceType = resourceType;

      const logs = await storage.getAuditLogs(filters);
      
      if (format === 'csv') {
        // Generate CSV format
        const csvHeaders = [
          'ID',
          'Timestamp',
          'User ID',
          'Action',
          'Resource Type',
          'Resource ID',
          'Success',
          'IP Address',
          'User Agent',
          'Error Message'
        ].join(',');

        const csvRows = logs.map(log => [
          log.id,
          log.timestamp?.toISOString() || '',
          log.userId || '',
          log.action,
          log.resourceType,
          log.resourceId || '',
          log.success,
          log.ipAddress || '',
          log.userAgent ? `"${log.userAgent.replace(/"/g, '""')}"` : '',
          log.errorMessage ? `"${log.errorMessage.replace(/"/g, '""')}"` : ''
        ].join(','));

        const csv = [csvHeaders, ...csvRows].join('\n');
        
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="audit-export-${Date.now()}.csv"`);
        res.send(csv);
      } else {
        // Return JSON format
        res.json({
          success: true,
          data: {
            exportDate: new Date().toISOString(),
            filters: {
              startDate,
              endDate,
              userId,
              action,
              resourceType
            },
            totalRecords: logs.length,
            logs
          }
        });
      }
    } catch (error: any) {
      res.status(500).json({ 
        success: false, 
        message: error.message,
        error: 'AUDIT_EXPORT_ERROR'
      });
    }
  });

  // GET /api/audit/analytics - Get audit statistics and trends
  app.get("/api/audit/analytics", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { startDate, endDate, userId } = req.query;
      
      const filters: any = {};
      if (startDate && typeof startDate === 'string') filters.startDate = new Date(startDate);
      if (endDate && typeof endDate === 'string') filters.endDate = new Date(endDate);
      if (userId && typeof userId === 'string') filters.userId = userId;

      // Get overall statistics
      const stats = await storage.getAuditStatistics(filters);
      
      // Get security events
      const securityEvents = await storage.getSecurityEvents(10);
      
      // Get recent activity (last 10 logs)
      const recentLogs = await storage.getAuditLogs({
        ...filters,
        limit: 10
      });

      // Calculate trends (compare with previous period if dates provided)
      let trends: any = {};
      if (filters.startDate && filters.endDate) {
        const periodLength = filters.endDate.getTime() - filters.startDate.getTime();
        const prevStartDate = new Date(filters.startDate.getTime() - periodLength);
        const prevEndDate = new Date(filters.startDate.getTime());
        
        const prevStats = await storage.getAuditStatistics({
          startDate: prevStartDate,
          endDate: prevEndDate,
          userId: filters.userId
        });

        trends = {
          totalChange: prevStats.total > 0 ? ((stats.total - prevStats.total) / prevStats.total * 100).toFixed(2) : '0',
          successRateChange: prevStats.total > 0 ? 
            (((stats.success / stats.total) - (prevStats.success / prevStats.total)) * 100).toFixed(2) : '0',
          failedChange: prevStats.total > 0 ? ((stats.failed - prevStats.failed) / prevStats.total * 100).toFixed(2) : '0'
        };
      }

      // Get activity by hour for charts
      const activityByHour: Record<string, number> = {};
      recentLogs.forEach(log => {
        if (log.timestamp) {
          const hour = new Date(log.timestamp).getHours();
          const hourKey = `${hour}:00`;
          activityByHour[hourKey] = (activityByHour[hourKey] || 0) + 1;
        }
      });

      res.json({
        success: true,
        data: {
          statistics: stats,
          securityEvents,
          recentLogs,
          trends,
          activityByHour,
          filters: {
            startDate,
            endDate,
            userId
          }
        }
      });
    } catch (error: any) {
      res.status(500).json({ 
        success: false, 
        message: error.message,
        error: 'AUDIT_ANALYTICS_ERROR'
      });
    }
  });

  // POST /api/audit/log - Create a new audit log entry (for manual logging)
  app.post("/api/audit/log", authenticateToken, async (req, res) => {
    try {
      const validatedData = createAuditLogSchema.parse(req.body);
      
      const clientInfo = getClientInfo(req);
      
      const auditLog = await storage.createAuditLog({
        ...validatedData,
        userId: validatedData.userId || req.user?.id,
        ...clientInfo
      });

      res.status(201).json({
        success: true,
        data: auditLog
      });
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ 
          success: false, 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      res.status(500).json({ 
        success: false, 
        message: error.message,
        error: 'AUDIT_LOG_CREATE_ERROR'
      });
    }
  });

  // POST /api/audit/event - Create a new audit event
  app.post("/api/audit/event", authenticateToken, async (req, res) => {
    try {
      const validatedData = createAuditEventSchema.parse(req.body);
      
      const clientInfo = getClientInfo(req);
      
      const auditEvent = await storage.createAuditEvent({
        ...validatedData,
        userId: validatedData.userId || req.user?.id,
        ...clientInfo
      });

      res.status(201).json({
        success: true,
        data: auditEvent
      });
    } catch (error: any) {
      if (error.name === "ZodError") {
        return res.status(400).json({ 
          success: false, 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      res.status(500).json({ 
        success: false, 
        message: error.message,
        error: 'AUDIT_EVENT_CREATE_ERROR'
      });
    }
  });

  // GET /api/audit/sessions - Get audit sessions
  app.get("/api/audit/sessions", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { userId, isActive, limit = '100', offset = '0' } = req.query;
      
      const filters: any = {
        limit: parseInt(limit as string, 10),
        offset: parseInt(offset as string, 10)
      };
      
      if (userId && typeof userId === 'string') filters.userId = userId;
      if (isActive === 'true' || isActive === 'false') filters.isActive = isActive === 'true';

      const sessions = await storage.getAuditSessions(filters);
      
      res.json({
        success: true,
        data: sessions
      });
    } catch (error: any) {
      res.status(500).json({ 
        success: false, 
        message: error.message,
        error: 'AUDIT_SESSIONS_FETCH_ERROR'
      });
    }
  });

  // DELETE /api/audit/log/:id - Delete an audit log
  app.delete("/api/audit/log/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      
      await storage.deleteAuditLog(id);
      
      res.json({
        success: true,
        message: 'Audit log deleted successfully'
      });
    } catch (error: any) {
      res.status(500).json({ 
        success: false, 
        message: error.message,
        error: 'AUDIT_LOG_DELETE_ERROR'
      });
    }
  });

  // DELETE /api/audit/event/:id - Delete an audit event
  app.delete("/api/audit/event/:id", authenticateToken, requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      
      await storage.deleteAuditEvent(id);
      
      res.json({
        success: true,
        message: 'Audit event deleted successfully'
      });
    } catch (error: any) {
      res.status(500).json({ 
        success: false, 
        message: error.message,
        error: 'AUDIT_EVENT_DELETE_ERROR'
      });
    }
  });
}
