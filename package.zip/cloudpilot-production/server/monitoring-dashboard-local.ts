/**
 * Monitoring Dashboard API
 * Comprehensive monitoring dashboard with metrics visualization, real-time status,
 * performance trends, error analysis, system health, alerts, and data retention
 */

import { Request, Response, Router } from 'express';

// Types and Interfaces
interface MetricData {
  id: string;
  name: string;
  value: number;
  timestamp: Date;
  labels?: Record<string, string>;
  unit?: string;
}

interface SystemHealth {
  status: 'healthy' | 'degraded' | 'critical' | 'unknown';
  uptime: number;
  cpu_usage: number;
  memory_usage: number;
  disk_usage: number;
  network_io: {
    inbound: number;
    outbound: number;
  };
  last_check: Date;
}

interface ErrorLog {
  id: string;
  timestamp: Date;
  level: 'error' | 'warning' | 'info' | 'debug';
  message: string;
  stack?: string;
  source: string;
  resolved: boolean;
}

interface Alert {
  id: string;
  name: string;
  description: string;
  condition: string;
  threshold: number;
  current_value: number;
  severity: 'low' | 'medium' | 'high' | 'critical';
  status: 'active' | 'resolved' | 'acknowledged';
  created_at: Date;
  triggered_at?: Date;
  resolved_at?: Date;
}

interface PerformanceTrend {
  timestamp: Date;
  response_time: number;
  throughput: number;
  error_rate: number;
  cpu_usage: number;
  memory_usage: number;
}

interface DashboardConfig {
  id: string;
  name: string;
  layout: DashboardLayout[];
  refresh_interval: number;
  theme: 'light' | 'dark';
  is_default: boolean;
}

interface DashboardLayout {
  widget_id: string;
  type: 'chart' | 'metric' | 'table' | 'status';
  position: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  config: Record<string, any>;
}

interface DataRetention {
  metric_name: string;
  retention_period: number; // in days
  aggregation_interval: number; // in minutes
  archive_location?: string;
}

// In-memory storage (replace with database in production)
const metricsStore: Map<string, MetricData[]> = new Map();
const errorLogs: ErrorLog[] = [];
const alertsStore: Map<string, Alert> = new Map();
const dashboardConfigs: Map<string, DashboardConfig> = new Map();
const dataRetentionRules: DataRetention[] = [];

// Dashboard API Class
export class MonitoringDashboardAPI {
  private router: Router;
  private cleanupInterval: NodeJS.Timeout;

  constructor() {
    this.router = Router();
    this.cleanupInterval = this.setupDataCleanup();
    this.setupRoutes();
  }

  private setupDataCleanup(): NodeJS.Timeout {
    // Clean up old data every hour
    return setInterval(() => {
      this.cleanupOldData();
    }, 60 * 60 * 1000);
  }

  private cleanupOldData(): void {
    const now = new Date();
    const retentionHours = 24 * 7; // Default 7 days

    // Cleanup metrics
    for (const [metricName, data] of metricsStore.entries()) {
      const cutoff = new Date(now.getTime() - retentionHours * 60 * 60 * 1000);
      metricsStore.set(
        metricName,
        data.filter(point => point.timestamp > cutoff)
      );
    }

    // Cleanup resolved alerts older than 30 days
    for (const [alertId, alert] of alertsStore.entries()) {
      if (alert.status === 'resolved' && 
          alert.resolved_at && 
          now.getTime() - alert.resolved_at.getTime() > 30 * 24 * 60 * 60 * 1000) {
        alertsStore.delete(alertId);
      }
    }

    // Cleanup error logs older than 7 days
    const errorCutoff = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    while (errorLogs.length > 0 && errorLogs[0].timestamp < errorCutoff) {
      errorLogs.shift();
    }
  }

  private setupRoutes(): void {
    // Metrics Visualization Endpoints
    this.router.get('/metrics', this.getMetrics.bind(this));
    this.router.get('/metrics/:name', this.getMetricByName.bind(this));
    this.router.post('/metrics', this.addMetric.bind(this));
    this.router.get('/metrics/:name/chart', this.getMetricChart.bind(this));

    // Real-time Status Overview
    this.router.get('/status', this.getSystemStatus.bind(this));
    this.router.get('/status/health', this.getSystemHealth.bind(this));
    this.router.get('/status/live', this.getLiveStatus.bind(this));

    // Performance Trends and Charts
    this.router.get('/performance/trends', this.getPerformanceTrends.bind(this));
    this.router.get('/performance/comparison', this.getPerformanceComparison.bind(this));
    this.router.get('/performance/summary', this.getPerformanceSummary.bind(this));

    // Error Analysis and Reporting
    this.router.get('/errors', this.getErrors.bind(this));
    this.router.get('/errors/analysis', this.getErrorAnalysis.bind(this));
    this.router.post('/errors/log', this.logError.bind(this));
    this.router.get('/errors/report', this.getErrorReport.bind(this));

    // System Health Overview
    this.router.get('/health/overview', this.getHealthOverview.bind(this));
    this.router.get('/health/metrics', this.getHealthMetrics.bind(this));
    this.router.get('/health/services', this.getServiceHealth.bind(this));

    // Alert Configuration and Management
    this.router.get('/alerts', this.getAlerts.bind(this));
    this.router.post('/alerts', this.createAlert.bind(this));
    this.router.put('/alerts/:id', this.updateAlert.bind(this));
    this.router.delete('/alerts/:id', this.deleteAlert.bind(this));
    this.router.post('/alerts/:id/acknowledge', this.acknowledgeAlert.bind(this));
    this.router.post('/alerts/:id/resolve', this.resolveAlert.bind(this));

    // Monitoring Data Retention
    this.router.get('/retention/config', this.getRetentionConfig.bind(this));
    this.router.post('/retention/config', this.setRetentionConfig.bind(this));
    this.router.delete('/retention/cleanup', this.triggerDataCleanup.bind(this));

    // Dashboard Configuration
    this.router.get('/dashboard/configs', this.getDashboardConfigs.bind(this));
    this.router.get('/dashboard/configs/:id', this.getDashboardConfig.bind(this));
    this.router.post('/dashboard/configs', this.createDashboardConfig.bind(this));
    this.router.put('/dashboard/configs/:id', this.updateDashboardConfig.bind(this));
    this.router.delete('/dashboard/configs/:id', this.deleteDashboardConfig.bind(this));

    // Utility Endpoints
    this.router.get('/export', this.exportData.bind(this));
    this.router.get('/health-check', this.healthCheck.bind(this));
  }

  // Metrics Visualization Endpoints
  private async getMetrics(req: Request, res: Response): Promise<void> {
    try {
      const { metric_name, start_time, end_time, limit } = req.query;
      let data: MetricData[] = [];

      if (metric_name && typeof metric_name === 'string') {
        data = metricsStore.get(metric_name) || [];
      } else {
        // Get all metrics
        for (const values of metricsStore.values()) {
          data.push(...values);
        }
        data.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
      }

      // Filter by time range
      if (start_time && typeof start_time === 'string') {
        const start = new Date(start_time);
        data = data.filter(point => point.timestamp >= start);
      }

      if (end_time && typeof end_time === 'string') {
        const end = new Date(end_time);
        data = data.filter(point => point.timestamp <= end);
      }

      // Apply limit
      const limitNum = limit ? parseInt(limit as string) : 1000;
      data = data.slice(0, limitNum);

      res.json({
        success: true,
        data,
        count: data.length,
        timestamp: new Date()
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to fetch metrics',
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  }

  private async getMetricByName(req: Request, res: Response): Promise<void> {
    try {
      const { name } = req.params;
      const data = metricsStore.get(name) || [];
      
      res.json({
        success: true,
        data,
        count: data.length
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to fetch metric'
      });
    }
  }

  private async addMetric(req: Request, res: Response): Promise<void> {
    try {
      const { name, value, labels, unit } = req.body;
      
      if (!name || value === undefined) {
        res.status(400).json({
          success: false,
          error: 'Name and value are required'
        });
        return;
      }

      const metric: MetricData = {
        id: `${name}-${Date.now()}`,
        name,
        value: Number(value),
        timestamp: new Date(),
        labels: labels || {},
        unit: unit || 'count'
      };

      if (!metricsStore.has(name)) {
        metricsStore.set(name, []);
      }
      
      metricsStore.get(name)!.push(metric);
      
      // Check alerts for this metric
      await this.checkAlerts(name, metric.value);

      res.json({
        success: true,
        data: metric
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to add metric'
      });
    }
  }

  private async getMetricChart(req: Request, res: Response): Promise<void> {
    try {
      const { name } = req.params;
      const { period = '1h', aggregation = 'avg' } = req.query;
      
      const data = metricsStore.get(name) || [];
      const now = new Date();
      const periodHours = this.parsePeriod(period as string);
      const start = new Date(now.getTime() - periodHours * 60 * 60 * 1000);
      
      const filteredData = data.filter(point => point.timestamp >= start);
      const aggregatedData = this.aggregateData(filteredData, aggregation as string);

      res.json({
        success: true,
        data: {
          name,
          period,
          aggregation,
          points: aggregatedData,
          summary: {
            min: Math.min(...filteredData.map(d => d.value)),
            max: Math.max(...filteredData.map(d => d.value)),
            avg: filteredData.reduce((sum, d) => sum + d.value, 0) / filteredData.length,
            count: filteredData.length
          }
        }
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to generate chart data'
      });
    }
  }

  // Real-time Status Overview
  private async getSystemStatus(req: Request, res: Response): Promise<void> {
    try {
      const health = await this.getCurrentSystemHealth();
      
      res.json({
        success: true,
        data: {
          status: health.status,
          uptime: health.uptime,
          last_check: health.last_check,
          services: await this.getServicesStatus()
        }
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to fetch system status'
      });
    }
  }

  private async getSystemHealth(req: Request, res: Response): Promise<void> {
    try {
      const health = await this.getCurrentSystemHealth();
      
      res.json({
        success: true,
        data: health
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to fetch system health'
      });
    }
  }

  private async getLiveStatus(req: Request, res: Response): Promise<void> {
    try {
      const health = await this.getCurrentSystemHealth();
      const activeAlerts = Array.from(alertsStore.values()).filter(a => a.status === 'active');
      const recentErrors = errorLogs.slice(-10);
      
      res.json({
        success: true,
        data: {
          system_health: health,
          active_alerts: activeAlerts.length,
          recent_errors: recentErrors.length,
          timestamp: new Date()
        }
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to fetch live status'
      });
    }
  }

  // Performance Trends and Charts
  private async getPerformanceTrends(req: Request, res: Response): Promise<void> {
    try {
      const { period = '24h', metrics = 'response_time,throughput,error_rate' } = req.query;
      const periodHours = this.parsePeriod(period as string);
      const requestedMetrics = (metrics as string).split(',');
      
      const trends: PerformanceTrend[] = [];
      const now = new Date();
      const start = new Date(now.getTime() - periodHours * 60 * 60 * 1000);
      
      // Generate synthetic trends (replace with actual data)
      for (let i = 0; i < periodHours; i++) {
        const timestamp = new Date(start.getTime() + i * 60 * 60 * 1000);
        trends.push({
          timestamp,
          response_time: Math.random() * 100 + 50, // 50-150ms
          throughput: Math.random() * 1000 + 500,  // 500-1500 req/min
          error_rate: Math.random() * 5,           // 0-5%
          cpu_usage: Math.random() * 80 + 10,      // 10-90%
          memory_usage: Math.random() * 60 + 30    // 30-90%
        });
      }

      res.json({
        success: true,
        data: {
          period,
          metrics: requestedMetrics,
          trends
        }
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to fetch performance trends'
      });
    }
  }

  private async getPerformanceComparison(req: Request, res: Response): Promise<void> {
    try {
      const { period1, period2, metric = 'response_time' } = req.query;
      
      // Generate comparison data (replace with actual data)
      const comparison = {
        metric,
        current_period: {
          avg: Math.random() * 100,
          min: Math.random() * 50,
          max: Math.random() * 200,
          trend: Math.random() > 0.5 ? 'up' : 'down'
        },
        previous_period: {
          avg: Math.random() * 100,
          min: Math.random() * 50,
          max: Math.random() * 200,
          trend: Math.random() > 0.5 ? 'up' : 'down'
        },
        change_percent: (Math.random() - 0.5) * 20 // -10% to +10%
      };

      res.json({
        success: true,
        data: comparison
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to fetch performance comparison'
      });
    }
  }

  private async getPerformanceSummary(req: Request, res: Response): Promise<void> {
    try {
      const summary = {
        overall_performance: Math.random() * 100, // 0-100 score
        key_metrics: {
          response_time: Math.random() * 100 + 50,
          throughput: Math.random() * 1000 + 500,
          error_rate: Math.random() * 5,
          availability: 99 + Math.random() // 99-100%
        },
        trends: {
          last_hour: Math.random() > 0.5 ? 'improving' : 'declining',
          last_day: Math.random() > 0.5 ? 'improving' : 'declining',
          last_week: Math.random() > 0.5 ? 'improving' : 'declining'
        },
        recommendations: [
          'Consider scaling up during peak hours',
          'Monitor memory usage patterns',
          'Optimize database queries'
        ]
      };

      res.json({
        success: true,
        data: summary
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to fetch performance summary'
      });
    }
  }

  // Error Analysis and Reporting
  private async getErrors(req: Request, res: Response): Promise<void> {
    try {
      const { level, start_time, end_time, limit = 100 } = req.query;
      let filteredErrors = [...errorLogs];

      if (level && typeof level === 'string') {
        filteredErrors = filteredErrors.filter(error => error.level === level);
      }

      if (start_time && typeof start_time === 'string') {
        const start = new Date(start_time);
        filteredErrors = filteredErrors.filter(error => error.timestamp >= start);
      }

      if (end_time && typeof end_time === 'string') {
        const end = new Date(end_time);
        filteredErrors = filteredErrors.filter(error => error.timestamp <= end);
      }

      filteredErrors.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
      filteredErrors = filteredErrors.slice(0, parseInt(limit as string));

      res.json({
        success: true,
        data: filteredErrors,
        count: filteredErrors.length
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to fetch errors'
      });
    }
  }

  private async getErrorAnalysis(req: Request, res: Response): Promise<void> {
    try {
      const analysis = {
        total_errors: errorLogs.length,
        errors_by_level: {
          error: errorLogs.filter(e => e.level === 'error').length,
          warning: errorLogs.filter(e => e.level === 'warning').length,
          info: errorLogs.filter(e => e.level === 'info').length,
          debug: errorLogs.filter(e => e.level === 'debug').length
        },
        errors_by_source: this.groupErrorsBySource(),
        recent_trend: this.calculateErrorTrend(),
        top_errors: this.getTopErrors(),
        resolution_rate: this.calculateResolutionRate()
      };

      res.json({
        success: true,
        data: analysis
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to fetch error analysis'
      });
    }
  }

  private async logError(req: Request, res: Response): Promise<void> {
    try {
      const { level, message, stack, source } = req.body;
      
      if (!level || !message) {
        res.status(400).json({
          success: false,
          error: 'Level and message are required'
        });
        return;
      }

      const errorLog: ErrorLog = {
        id: `error-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        timestamp: new Date(),
        level: level as 'error' | 'warning' | 'info' | 'debug',
        message,
        stack,
        source: source || 'unknown',
        resolved: false
      };

      errorLogs.push(errorLog);

      res.json({
        success: true,
        data: errorLog
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to log error'
      });
    }
  }

  private async getErrorReport(req: Request, res: Response): Promise<void> {
    try {
      const { format = 'json', period = '24h' } = req.query;
      
      const report = {
        generated_at: new Date(),
        period,
        summary: await this.generateErrorReportSummary(),
        details: await this.generateErrorReportDetails(),
        charts: await this.generateErrorReportCharts()
      };

      if (format === 'pdf') {
        // In a real implementation, you would generate a PDF here
        res.status(501).json({
          success: false,
          error: 'PDF generation not implemented'
        });
      } else {
        res.json({
          success: true,
          data: report
        });
      }
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to generate error report'
      });
    }
  }

  // System Health Overview
  private async getHealthOverview(req: Request, res: Response): Promise<void> {
    try {
      const overview = {
        overall_status: await this.calculateOverallStatus(),
        components: await this.getComponentHealth(),
        alerts: {
          active: Array.from(alertsStore.values()).filter(a => a.status === 'active').length,
          critical: Array.from(alertsStore.values()).filter(a => a.severity === 'critical').length,
          acknowledged: Array.from(alertsStore.values()).filter(a => a.status === 'acknowledged').length
        },
        uptime_percentage: 99.9 + Math.random() * 0.1,
        last_incident: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000)
      };

      res.json({
        success: true,
        data: overview
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to fetch health overview'
      });
    }
  }

  private async getHealthMetrics(req: Request, res: Response): Promise<void> {
    try {
      const metrics = {
        cpu: {
          current: Math.random() * 100,
          average: Math.random() * 100,
          trend: Math.random() > 0.5 ? 'up' : 'down'
        },
        memory: {
          current: Math.random() * 100,
          average: Math.random() * 100,
          trend: Math.random() > 0.5 ? 'up' : 'down',
          used_gb: Math.random() * 16 + 4,
          total_gb: 32
        },
        disk: {
          current: Math.random() * 100,
          average: Math.random() * 100,
          trend: Math.random() > 0.5 ? 'up' : 'down',
          used_gb: Math.random() * 500 + 100,
          total_gb: 1000
        },
        network: {
          inbound_mbps: Math.random() * 100,
          outbound_mbps: Math.random() * 100,
          latency_ms: Math.random() * 50 + 10
        }
      };

      res.json({
        success: true,
        data: metrics
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to fetch health metrics'
      });
    }
  }

  private async getServiceHealth(req: Request, res: Response): Promise<void> {
    try {
      const services = [
        { name: 'Web Server', status: Math.random() > 0.1 ? 'healthy' : 'degraded', response_time: Math.random() * 50 + 10 },
        { name: 'Database', status: Math.random() > 0.05 ? 'healthy' : 'critical', response_time: Math.random() * 100 + 20 },
        { name: 'Cache', status: Math.random() > 0.02 ? 'healthy' : 'degraded', response_time: Math.random() * 10 + 5 },
        { name: 'API Gateway', status: Math.random() > 0.08 ? 'healthy' : 'degraded', response_time: Math.random() * 30 + 15 },
        { name: 'Message Queue', status: Math.random() > 0.03 ? 'healthy' : 'degraded', response_time: Math.random() * 20 + 8 }
      ];

      res.json({
        success: true,
        data: services
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to fetch service health'
      });
    }
  }

  // Alert Configuration and Management
  private async getAlerts(req: Request, res: Response): Promise<void> {
    try {
      const { status, severity, limit = 100 } = req.query;
      let alerts = Array.from(alertsStore.values());

      if (status && typeof status === 'string') {
        alerts = alerts.filter(alert => alert.status === status);
      }

      if (severity && typeof severity === 'string') {
        alerts = alerts.filter(alert => alert.severity === severity);
      }

      alerts.sort((a, b) => b.created_at.getTime() - a.created_at.getTime());
      alerts = alerts.slice(0, parseInt(limit as string));

      res.json({
        success: true,
        data: alerts,
        count: alerts.length
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to fetch alerts'
      });
    }
  }

  private async createAlert(req: Request, res: Response): Promise<void> {
    try {
      const { name, description, condition, threshold, severity } = req.body;
      
      if (!name || !condition || threshold === undefined) {
        res.status(400).json({
          success: false,
          error: 'Name, condition, and threshold are required'
        });
        return;
      }

      const alert: Alert = {
        id: `alert-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        name,
        description: description || '',
        condition,
        threshold: Number(threshold),
        current_value: 0,
        severity: (severity as 'low' | 'medium' | 'high' | 'critical') || 'medium',
        status: 'active',
        created_at: new Date()
      };

      alertsStore.set(alert.id, alert);

      res.json({
        success: true,
        data: alert
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to create alert'
      });
    }
  }

  private async updateAlert(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const alert = alertsStore.get(id);
      if (!alert) {
        res.status(404).json({
          success: false,
          error: 'Alert not found'
        });
        return;
      }

      Object.assign(alert, updates);
      alertsStore.set(id, alert);

      res.json({
        success: true,
        data: alert
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to update alert'
      });
    }
  }

  private async deleteAlert(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      
      if (!alertsStore.has(id)) {
        res.status(404).json({
          success: false,
          error: 'Alert not found'
        });
        return;
      }

      alertsStore.delete(id);

      res.json({
        success: true,
        message: 'Alert deleted successfully'
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to delete alert'
      });
    }
  }

  private async acknowledgeAlert(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const alert = alertsStore.get(id);
      
      if (!alert) {
        res.status(404).json({
          success: false,
          error: 'Alert not found'
        });
        return;
      }

      alert.status = 'acknowledged';
      alertsStore.set(id, alert);

      res.json({
        success: true,
        data: alert
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to acknowledge alert'
      });
    }
  }

  private async resolveAlert(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const alert = alertsStore.get(id);
      
      if (!alert) {
        res.status(404).json({
          success: false,
          error: 'Alert not found'
        });
        return;
      }

      alert.status = 'resolved';
      alert.resolved_at = new Date();
      alertsStore.set(id, alert);

      res.json({
        success: true,
        data: alert
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to resolve alert'
      });
    }
  }

  // Monitoring Data Retention
  private async getRetentionConfig(req: Request, res: Response): Promise<void> {
    try {
      res.json({
        success: true,
        data: dataRetentionRules
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to fetch retention config'
      });
    }
  }

  private async setRetentionConfig(req: Request, res: Response): Promise<void> {
    try {
      const { rules } = req.body;
      
      if (!Array.isArray(rules)) {
        res.status(400).json({
          success: false,
          error: 'Rules must be an array'
        });
        return;
      }

      dataRetentionRules.splice(0, dataRetentionRules.length, ...rules);

      res.json({
        success: true,
        data: dataRetentionRules
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to set retention config'
      });
    }
  }

  private async triggerDataCleanup(req: Request, res: Response): Promise<void> {
    try {
      this.cleanupOldData();
      
      res.json({
        success: true,
        message: 'Data cleanup completed'
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to trigger data cleanup'
      });
    }
  }

  // Dashboard Configuration
  private async getDashboardConfigs(req: Request, res: Response): Promise<void> {
    try {
      const configs = Array.from(dashboardConfigs.values());
      
      res.json({
        success: true,
        data: configs,
        count: configs.length
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to fetch dashboard configs'
      });
    }
  }

  private async getDashboardConfig(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const config = dashboardConfigs.get(id);
      
      if (!config) {
        res.status(404).json({
          success: false,
          error: 'Dashboard config not found'
        });
        return;
      }

      res.json({
        success: true,
        data: config
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to fetch dashboard config'
      });
    }
  }

  private async createDashboardConfig(req: Request, res: Response): Promise<void> {
    try {
      const { name, layout, refresh_interval, theme, is_default } = req.body;
      
      if (!name || !layout) {
        res.status(400).json({
          success: false,
          error: 'Name and layout are required'
        });
        return;
      }

      const config: DashboardConfig = {
        id: `dashboard-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        name,
        layout,
        refresh_interval: refresh_interval || 30,
        theme: (theme as 'light' | 'dark') || 'light',
        is_default: is_default || false
      };

      dashboardConfigs.set(config.id, config);

      res.json({
        success: true,
        data: config
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to create dashboard config'
      });
    }
  }

  private async updateDashboardConfig(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const updates = req.body;
      
      const config = dashboardConfigs.get(id);
      if (!config) {
        res.status(404).json({
          success: false,
          error: 'Dashboard config not found'
        });
        return;
      }

      Object.assign(config, updates);
      dashboardConfigs.set(id, config);

      res.json({
        success: true,
        data: config
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to update dashboard config'
      });
    }
  }

  private async deleteDashboardConfig(req: Request, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      
      if (!dashboardConfigs.has(id)) {
        res.status(404).json({
          success: false,
          error: 'Dashboard config not found'
        });
        return;
      }

      dashboardConfigs.delete(id);

      res.json({
        success: true,
        message: 'Dashboard config deleted successfully'
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to delete dashboard config'
      });
    }
  }

  // Utility Endpoints
  private async exportData(req: Request, res: Response): Promise<void> {
    try {
      const { type = 'metrics', format = 'json', period = '24h' } = req.query;
      
      const exportData = {
        exported_at: new Date(),
        type,
        period,
        data: {} as any
      };

      switch (type) {
        case 'metrics':
          exportData.data = this.getAllMetricsData();
          break;
        case 'alerts':
          exportData.data = Array.from(alertsStore.values());
          break;
        case 'errors':
          exportData.data = errorLogs;
          break;
        default:
          exportData.data = {
            metrics: this.getAllMetricsData(),
            alerts: Array.from(alertsStore.values()),
            errors: errorLogs
          };
      }

      if (format === 'csv') {
        // Convert to CSV format
        const csv = this.convertToCSV(exportData.data);
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="export-${type}-${Date.now()}.csv"`);
        res.send(csv);
      } else {
        res.json({
          success: true,
          ...exportData
        });
      }
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to export data'
      });
    }
  }

  private async healthCheck(req: Request, res: Response): Promise<void> {
    try {
      const health = {
        status: 'healthy',
        timestamp: new Date(),
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        version: '1.0.0'
      };

      res.json({
        success: true,
        data: health
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Health check failed'
      });
    }
  }

  // Helper Methods
  private async getCurrentSystemHealth(): Promise<SystemHealth> {
    return {
      status: Math.random() > 0.9 ? 'degraded' : 'healthy',
      uptime: process.uptime(),
      cpu_usage: Math.random() * 100,
      memory_usage: Math.random() * 100,
      disk_usage: Math.random() * 100,
      network_io: {
        inbound: Math.random() * 1000,
        outbound: Math.random() * 1000
      },
      last_check: new Date()
    };
  }

  private async getServicesStatus(): Promise<any[]> {
    return [
      { name: 'API Service', status: 'healthy', response_time: 50 },
      { name: 'Database', status: 'healthy', response_time: 20 },
      { name: 'Cache', status: 'healthy', response_time: 5 },
      { name: 'WebSocket', status: 'healthy', response_time: 30 }
    ];
  }

  private parsePeriod(period: string): number {
    const unit = period.slice(-1);
    const value = parseInt(period.slice(0, -1));
    
    switch (unit) {
      case 'm': return value;
      case 'h': return value * 60;
      case 'd': return value * 24 * 60;
      default: return 60; // Default 1 hour
    }
  }

  private aggregateData(data: MetricData[], aggregation: string): any[] {
    // Simple aggregation - in production, use proper time-series aggregation
    return data.map(point => ({
      timestamp: point.timestamp,
      value: point.value
    }));
  }

  private groupErrorsBySource(): Record<string, number> {
    const grouped: Record<string, number> = {};
    errorLogs.forEach(error => {
      grouped[error.source] = (grouped[error.source] || 0) + 1;
    });
    return grouped;
  }

  private calculateErrorTrend(): 'up' | 'down' | 'stable' {
    const recent = errorLogs.filter(e => 
      e.timestamp > new Date(Date.now() - 60 * 60 * 1000)
    ).length;
    const older = errorLogs.filter(e => 
      e.timestamp <= new Date(Date.now() - 60 * 60 * 1000) &&
      e.timestamp > new Date(Date.now() - 120 * 60 * 1000)
    ).length;

    if (recent > older * 1.1) return 'up';
    if (recent < older * 0.9) return 'down';
    return 'stable';
  }

  private getTopErrors(): any[] {
    const errorCounts: Record<string, number> = {};
    errorLogs.forEach(error => {
      errorCounts[error.message] = (errorCounts[error.message] || 0) + 1;
    });

    return Object.entries(errorCounts)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 5)
      .map(([message, count]) => ({ message, count }));
  }

  private calculateResolutionRate(): number {
    const resolved = errorLogs.filter(e => e.resolved).length;
    return errorLogs.length > 0 ? (resolved / errorLogs.length) * 100 : 100;
  }

  private async calculateOverallStatus(): Promise<string> {
    const activeAlerts = Array.from(alertsStore.values()).filter(a => a.status === 'active');
    const criticalAlerts = activeAlerts.filter(a => a.severity === 'critical');
    
    if (criticalAlerts.length > 0) return 'critical';
    if (activeAlerts.length > 0) return 'warning';
    return 'healthy';
  }

  private async getComponentHealth(): Promise<any[]> {
    return [
      { name: 'Web Server', status: 'healthy', last_check: new Date() },
      { name: 'Database', status: 'healthy', last_check: new Date() },
      { name: 'Cache', status: 'healthy', last_check: new Date() },
      { name: 'API Gateway', status: 'degraded', last_check: new Date() }
    ];
  }

  private async generateErrorReportSummary(): Promise<any> {
    return {
      total_errors: errorLogs.length,
      critical_errors: errorLogs.filter(e => e.level === 'error').length,
      resolved_errors: errorLogs.filter(e => e.resolved).length,
      average_resolution_time: '2.5 hours'
    };
  }

  private async generateErrorReportDetails(): Promise<any> {
    return {
      errors_by_hour: this.generateHourlyErrorCounts(),
      top_error_sources: Object.entries(this.groupErrorsBySource())
        .sort(([, a], [, b]) => b - a)
        .slice(0, 5),
      resolution_metrics: {
        average_time: '2.5 hours',
        median_time: '1.2 hours',
        fastest_resolution: '15 minutes',
        slowest_resolution: '8 hours'
      }
    };
  }

  private async generateErrorReportCharts(): Promise<any> {
    return {
      error_trend_chart: 'chart_data_here',
      error_distribution_chart: 'chart_data_here',
      resolution_time_chart: 'chart_data_here'
    };
  }

  private generateHourlyErrorCounts(): Record<string, number> {
    const counts: Record<string, number> = {};
    const now = new Date();
    
    for (let i = 23; i >= 0; i--) {
      const hour = new Date(now.getTime() - i * 60 * 60 * 1000);
      const hourKey = hour.toISOString().slice(0, 13) + ':00:00.000Z';
      counts[hourKey] = Math.floor(Math.random() * 10);
    }
    
    return counts;
  }

  private getAllMetricsData(): Record<string, MetricData[]> {
    const allData: Record<string, MetricData[]> = {};
    for (const [name, data] of metricsStore.entries()) {
      allData[name] = data;
    }
    return allData;
  }

  private convertToCSV(data: any): string {
    // Simple CSV conversion - enhance as needed
    if (Array.isArray(data) && data.length > 0) {
      const headers = Object.keys(data[0]).join(',');
      const rows = data.map(row => Object.values(row).join(','));
      return [headers, ...rows].join('\n');
    }
    return 'No data to export';
  }

  private async checkAlerts(metricName: string, value: number): Promise<void> {
    for (const alert of alertsStore.values()) {
      if (alert.condition.includes(metricName) && value >= alert.threshold) {
        alert.current_value = value;
        alert.triggered_at = new Date();
        if (alert.status === 'active') {
          // Alert already active, update current value
          continue;
        }
        alert.status = 'active';
        alertsStore.set(alert.id, alert);
        
        // In a real implementation, send notification here
        console.log(`Alert triggered: ${alert.name} - ${metricName} = ${value}`);
      }
    }
  }

  // Public getter for router
  public getRouter(): Router {
    return this.router;
  }

  // Cleanup method
  public destroy(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }
  }
}

// Export factory function and utilities
export function createMonitoringDashboardAPI(): MonitoringDashboardAPI {
  return new MonitoringDashboardAPI();
}

export function getMonitoringRouter(): Router {
  const api = new MonitoringDashboardAPI();
  return api.getRouter();
}

// Export types for external use
export type {
  MetricData,
  SystemHealth,
  ErrorLog,
  Alert,
  PerformanceTrend,
  DashboardConfig,
  DashboardLayout,
  DataRetention
};

// Export utility functions
export const MonitoringUtils = {
  formatMetricValue: (value: number, unit?: string): string => {
    if (unit === 'percentage') {
      return `${value.toFixed(1)}%`;
    }
    if (unit === 'bytes') {
      const sizes = ['B', 'KB', 'MB', 'GB'];
      const i = Math.floor(Math.log(value) / Math.log(1024));
      return `${(value / Math.pow(1024, i)).toFixed(1)} ${sizes[i]}`;
    }
    return value.toString();
  },

  calculateTrend: (values: number[]): 'up' | 'down' | 'stable' => {
    if (values.length < 2) return 'stable';
    const recent = values.slice(-Math.min(values.length, 10));
    const older = values.slice(0, Math.min(values.length, 10));
    
    const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
    const olderAvg = older.reduce((a, b) => a + b, 0) / older.length;
    
    if (recentAvg > olderAvg * 1.1) return 'up';
    if (recentAvg < olderAvg * 0.9) return 'down';
    return 'stable';
  },

  validateMetricName: (name: string): boolean => {
    return /^[a-zA-Z_][a-zA-Z0-9_]*$/.test(name);
  },

  calculateUptimePercentage: (startTime: Date, endTime: Date): number => {
    const total = endTime.getTime() - startTime.getTime();
    const healthy = total * 0.999; // Assuming 99.9% uptime
    return (healthy / total) * 100;
  }
};

export default MonitoringDashboardAPI;