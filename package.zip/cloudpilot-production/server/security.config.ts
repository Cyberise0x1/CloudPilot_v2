/**
 * Comprehensive Security Configuration
 * Manages security settings, policies, threat detection, monitoring, and audit operations
 */

import { EventEmitter } from 'events';

// Security Configuration Types
export interface SecurityConfig {
  // Core Security Settings
  authentication: AuthenticationConfig;
  authorization: AuthorizationConfig;
  encryption: EncryptionConfig;
  
  // Security Policies
  policies: SecurityPolicies;
  
  // Threat Detection
  threatDetection: ThreatDetectionConfig;
  
  // Monitoring & Logging
  monitoring: SecurityMonitoringConfig;
  
  // Event Handling
  eventHandling: EventHandlingConfig;
  
  // Audit Configuration
  audit: AuditConfig;
  
  // Rate Limiting
  rateLimiting: RateLimitingConfig;
  
  // Headers Security
  headers: HeadersSecurityConfig;
}

export interface AuthenticationConfig {
  sessionTimeout: number; // in minutes
  maxLoginAttempts: number;
  lockoutDuration: number; // in minutes
  requireMFA: boolean;
  passwordPolicy: PasswordPolicy;
  jwtConfig: JWTConfig;
}

export interface AuthorizationConfig {
  defaultRole: string;
  roles: Record<string, RolePermissions>;
  permissions: PermissionConfig[];
}

export interface EncryptionConfig {
  algorithm: string;
  keyLength: number;
  saltRounds: number;
  enableAtRestEncryption: boolean;
  enableTransitEncryption: boolean;
}

export interface SecurityPolicies {
  corsPolicy: CORSPolicy;
  contentSecurityPolicy: ContentSecurityPolicy;
  inputValidationPolicy: InputValidationPolicy;
  passwordPolicy: PasswordPolicy;
}

export interface ThreatDetectionConfig {
  enabled: boolean;
  patterns: ThreatPattern[];
  behavioralAnalysis: BehavioralAnalysisConfig;
  anomalyDetection: AnomalyDetectionConfig;
  responseActions: ThreatResponseAction[];
}

export interface SecurityMonitoringConfig {
  enabled: boolean;
  logLevel: 'debug' | 'info' | 'warn' | 'error';
  metricsEnabled: boolean;
  alertingEnabled: boolean;
  dashboardEnabled: boolean;
  monitoringEndpoints: string[];
}

export interface EventHandlingConfig {
  bufferSize: number;
  batchSize: number;
  retryAttempts: number;
  eventTypes: string[];
  handlers: EventHandler[];
}

export interface AuditConfig {
  enabled: boolean;
  logLevel: 'minimal' | 'standard' | 'comprehensive';
  retentionPeriod: number; // in days
  realTimeAlerts: boolean;
  auditLogPaths: string[];
  complianceFrameworks: string[];
}

export interface RateLimitingConfig {
  enabled: boolean;
  windowMs: number;
  maxRequests: number;
  skipSuccessfulRequests: boolean;
  skipFailedRequests: boolean;
  customLimiters: Record<string, RateLimiterConfig>;
}

export interface HeadersSecurityConfig {
  enabled: boolean;
  strictTransportSecurity: boolean;
  contentTypeOptions: boolean;
  frameOptions: string;
  xssProtection: boolean;
  referrerPolicy: string;
}

// Supporting Interfaces
export interface PasswordPolicy {
  minLength: number;
  maxLength: number;
  requireUppercase: boolean;
  requireLowercase: boolean;
  requireNumbers: boolean;
  requireSpecialChars: boolean;
  preventCommonPasswords: boolean;
  preventReuse: number; // number of previous passwords to check
  expiryDays: number; // 0 for no expiry
}

export interface JWTConfig {
  secret: string;
  algorithm: string;
  expiresIn: string;
  refreshTokenExpiry: string;
  issuer: string;
  audience: string;
}

export interface RolePermissions {
  permissions: string[];
  resourceAccess: Record<string, string[]>;
  restrictions: string[];
}

export interface PermissionConfig {
  resource: string;
  action: string;
  conditions?: Record<string, any>;
}

// Security Policy Interfaces
export interface CORSPolicy {
  origin: string[];
  methods: string[];
  headers: string[];
  credentials: boolean;
  maxAge: number;
}

export interface ContentSecurityPolicy {
  defaultSrc: string[];
  scriptSrc: string[];
  styleSrc: string[];
  imgSrc: string[];
  connectSrc: string[];
  fontSrc: string[];
  objectSrc: string[];
  mediaSrc: string[];
  frameSrc: string[];
}

export interface InputValidationPolicy {
  maxLength: number;
  allowedCharacters: string[];
  blockedPatterns: string[];
  sanitizationRules: SanitizationRule[];
}

export interface SanitizationRule {
  field: string;
  type: 'string' | 'number' | 'email' | 'url';
  stripHtml: boolean;
  trimWhitespace: boolean;
  escapeHtml: boolean;
}

// Threat Detection Interfaces
export interface ThreatPattern {
  id: string;
  name: string;
  pattern: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  category: string;
  enabled: boolean;
}

export interface BehavioralAnalysisConfig {
  enabled: boolean;
  baselineWindow: number; // in hours
  deviationThreshold: number; // standard deviations
  metricsToTrack: string[];
}

export interface AnomalyDetectionConfig {
  enabled: boolean;
  algorithm: 'isolation-forest' | 'statistical' | 'ml-based';
  sensitivity: number; // 0-1
  updateFrequency: number; // in hours
}

export interface ThreatResponseAction {
  threatType: string;
  severity: string;
  actions: string[];
  autoBlock: boolean;
  alertAdmins: boolean;
}

// Event Handling Interfaces
export interface EventHandler {
  type: string;
  config: Record<string, any>;
  priority: number;
}

export interface RateLimiterConfig {
  windowMs: number;
  max: number;
  message: string;
  standardHeaders: boolean;
  legacyHeaders: boolean;
}

// Security Event Types
export enum SecurityEventType {
  AUTHENTICATION_FAILURE = 'authentication_failure',
  AUTHORIZATION_FAILURE = 'authorization_failure',
  THREAT_DETECTED = 'threat_detected',
  ANOMALY_DETECTED = 'anomaly_detected',
  RATE_LIMIT_EXCEEDED = 'rate_limit_exceeded',
  SUSPICIOUS_ACTIVITY = 'suspicious_activity',
  SECURITY_VIOLATION = 'security_violation',
  AUDIT_LOG_EVENT = 'audit_log_event',
  COMPLIANCE_VIOLATION = 'compliance_violation',
  DATA_BREACH_ATTEMPT = 'data_breach_attempt',
}

export interface SecurityEvent {
  id: string;
  type: SecurityEventType;
  timestamp: Date;
  severity: 'low' | 'medium' | 'high' | 'critical';
  source: string;
  description: string;
  metadata: Record<string, any>;
  resolved: boolean;
  actions?: string[];
}

// Default Security Configuration
const defaultSecurityConfig: SecurityConfig = {
  authentication: {
    sessionTimeout: 30,
    maxLoginAttempts: 5,
    lockoutDuration: 15,
    requireMFA: true,
    passwordPolicy: {
      minLength: 12,
      maxLength: 128,
      requireUppercase: true,
      requireLowercase: true,
      requireNumbers: true,
      requireSpecialChars: true,
      preventCommonPasswords: true,
      preventReuse: 5,
      expiryDays: 90,
    },
    jwtConfig: {
      secret: process.env.JWT_SECRET || 'default-secret-change-in-production',
      algorithm: 'HS256',
      expiresIn: '15m',
      refreshTokenExpiry: '7d',
      issuer: 'cloudpilot-app',
      audience: 'cloudpilot-users',
    },
  },
  authorization: {
    defaultRole: 'guest',
    roles: {
      admin: {
        permissions: ['*'],
        resourceAccess: {
          '*': ['read', 'write', 'delete', 'admin'],
        },
        restrictions: [],
      },
      user: {
        permissions: ['read', 'write'],
        resourceAccess: {
          'profile': ['read', 'write'],
          'data': ['read', 'write'],
        },
        restrictions: ['no_admin_access'],
      },
      guest: {
        permissions: ['read'],
        resourceAccess: {
          'public': ['read'],
        },
        restrictions: ['no_authenticated_access'],
      },
    },
    permissions: [
      { resource: 'users', action: 'read' },
      { resource: 'users', action: 'write' },
      { resource: 'users', action: 'delete' },
      { resource: 'admin', action: 'access' },
    ],
  },
  encryption: {
    algorithm: 'aes-256-gcm',
    keyLength: 256,
    saltRounds: 12,
    enableAtRestEncryption: true,
    enableTransitEncryption: true,
  },
  policies: {
    corsPolicy: {
      origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
      methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
      headers: ['Content-Type', 'Authorization', 'X-Requested-With'],
      credentials: true,
      maxAge: 86400,
    },
    contentSecurityPolicy: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'https:'],
      connectSrc: ["'self'"],
      fontSrc: ["'self'"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["'none'"],
    },
    inputValidationPolicy: {
      maxLength: 10000,
      allowedCharacters: /^[a-zA-Z0-9\s\-_@.]+$/,
      blockedPatterns: [
        /<script[^>]*>.*?<\/script>/gi,
        /javascript:/gi,
        /on\w+="[^"]*"/gi,
      ],
      sanitizationRules: [
        {
          field: 'email',
          type: 'email',
          stripHtml: true,
          trimWhitespace: true,
          escapeHtml: true,
        },
        {
          field: 'password',
          type: 'string',
          stripHtml: true,
          trimWhitespace: false,
          escapeHtml: true,
        },
      ],
    },
    passwordPolicy: {
      minLength: 12,
      maxLength: 128,
      requireUppercase: true,
      requireLowercase: true,
      requireNumbers: true,
      requireSpecialChars: true,
      preventCommonPasswords: true,
      preventReuse: 5,
      expiryDays: 90,
    },
  },
  threatDetection: {
    enabled: true,
    patterns: [
      {
        id: 'sql-injection-1',
        name: 'SQL Injection Attempt',
        pattern: /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER)\b.*\b(WHERE|FROM|TABLE)\b)/i,
        severity: 'high',
        category: 'injection',
        enabled: true,
      },
      {
        id: 'xss-1',
        name: 'Cross-Site Scripting',
        pattern: /<script[^>]*>.*?<\/script>/gi,
        severity: 'high',
        category: 'xss',
        enabled: true,
      },
      {
        id: 'path-traversal-1',
        name: 'Path Traversal',
        pattern: /(\.\.\/)+/g,
        severity: 'medium',
        category: 'traversal',
        enabled: true,
      },
      {
        id: 'command-injection-1',
        name: 'Command Injection',
        pattern: /[;&|`$]/,
        severity: 'high',
        category: 'injection',
        enabled: true,
      },
    ],
    behavioralAnalysis: {
      enabled: true,
      baselineWindow: 24,
      deviationThreshold: 2,
      metricsToTrack: ['login_attempts', 'requests_per_minute', 'data_access_volume'],
    },
    anomalyDetection: {
      enabled: true,
      algorithm: 'isolation-forest',
      sensitivity: 0.7,
      updateFrequency: 6,
    },
    responseActions: [
      {
        threatType: 'sql-injection',
        severity: 'high',
        actions: ['block_request', 'log_security_event', 'alert_admins'],
        autoBlock: true,
        alertAdmins: true,
      },
      {
        threatType: 'xss',
        severity: 'high',
        actions: ['sanitize_input', 'log_security_event'],
        autoBlock: false,
        alertAdmins: true,
      },
    ],
  },
  monitoring: {
    enabled: true,
    logLevel: 'info',
    metricsEnabled: true,
    alertingEnabled: true,
    dashboardEnabled: true,
    monitoringEndpoints: [
      '/health/security',
      '/health/metrics',
      '/health/audit',
    ],
  },
  eventHandling: {
    bufferSize: 1000,
    batchSize: 50,
    retryAttempts: 3,
    eventTypes: Object.values(SecurityEventType),
    handlers: [
      {
        type: 'console',
        config: { enabled: true },
        priority: 1,
      },
      {
        type: 'file',
        config: { 
          enabled: true,
          path: './logs/security-events.log',
          rotate: true,
        },
        priority: 2,
      },
      {
        type: 'database',
        config: { 
          enabled: false,
          table: 'security_events',
        },
        priority: 3,
      },
    ],
  },
  audit: {
    enabled: true,
    logLevel: 'comprehensive',
    retentionPeriod: 365,
    realTimeAlerts: true,
    auditLogPaths: ['./logs/audit.log'],
    complianceFrameworks: ['SOC2', 'ISO27001', 'GDPR'],
  },
  rateLimiting: {
    enabled: true,
    windowMs: 15 * 60 * 1000, // 15 minutes
    maxRequests: 100,
    skipSuccessfulRequests: false,
    skipFailedRequests: false,
    customLimiters: {
      login: {
        windowMs: 15 * 60 * 1000,
        max: 5,
        message: 'Too many login attempts',
        standardHeaders: true,
        legacyHeaders: false,
      },
      api: {
        windowMs: 60 * 1000,
        max: 1000,
        message: 'API rate limit exceeded',
        standardHeaders: true,
        legacyHeaders: false,
      },
    },
  },
  headers: {
    enabled: true,
    strictTransportSecurity: true,
    contentTypeOptions: true,
    frameOptions: 'DENY',
    xssProtection: true,
    referrerPolicy: 'strict-origin-when-cross-origin',
  },
};

// Security Configuration Manager
export class SecurityConfigManager extends EventEmitter {
  private config: SecurityConfig;
  private eventQueue: SecurityEvent[] = [];
  private threatPatterns: ThreatPattern[] = [];
  private behavioralBaseline: Map<string, any[]> = new Map();

  constructor(initialConfig?: Partial<SecurityConfig>) {
    super();
    this.config = { ...defaultSecurityConfig, ...initialConfig };
    this.threatPatterns = this.config.threatDetection.patterns;
    this.initializeMonitoring();
  }

  // Configuration Management
  getConfig(): SecurityConfig {
    return { ...this.config };
  }

  updateConfig(updates: Partial<SecurityConfig>): void {
    this.config = { ...this.config, ...updates };
    this.emit('configUpdated', this.config);
  }

  updateThreatDetection(updates: Partial<ThreatDetectionConfig>): void {
    this.config.threatDetection = { ...this.config.threatDetection, ...updates };
    this.threatPatterns = this.config.threatDetection.patterns;
    this.emit('threatDetectionUpdated', this.config.threatDetection);
  }

  updateMonitoring(updates: Partial<SecurityMonitoringConfig>): void {
    this.config.monitoring = { ...this.config.monitoring, ...updates };
    this.emit('monitoringUpdated', this.config.monitoring);
  }

  // Threat Detection
  analyzeThreats(input: string): ThreatDetectionResult[] {
    if (!this.config.threatDetection.enabled) {
      return [];
    }

    const results: ThreatDetectionResult[] = [];

    for (const pattern of this.threatPatterns) {
      if (!pattern.enabled) continue;

      const matches = this.matchPattern(input, pattern.pattern);
      if (matches.length > 0) {
        const result: ThreatDetectionResult = {
          patternId: pattern.id,
          patternName: pattern.name,
          severity: pattern.severity,
          category: pattern.category,
          matches,
          timestamp: new Date(),
        };
        results.push(result);
        this.handleThreatDetected(result);
      }
    }

    return results;
  }

  private matchPattern(input: string, pattern: string | RegExp): MatchResult[] {
    const regex = new RegExp(pattern, 'gi');
    const matches: MatchResult[] = [];
    let match;

    while ((match = regex.exec(input)) !== null) {
      matches.push({
        value: match[0],
        index: match.index,
        groups: match.slice(1),
      });
    }

    return matches;
  }

  private handleThreatDetected(result: ThreatDetectionResult): void {
    const responseAction = this.config.threatDetection.responseActions.find(
      action => action.threatType === result.category && action.severity === result.severity
    );

    if (responseAction) {
      this.executeResponseActions(result, responseAction);
    }

    this.createSecurityEvent({
      type: SecurityEventType.THREAT_DETECTED,
      severity: result.severity,
      source: 'threat-detection',
      description: `Threat detected: ${result.patternName}`,
      metadata: result,
    });
  }

  private executeResponseActions(result: ThreatDetectionResult, action: ThreatResponseAction): void {
    for (const actionType of action.actions) {
      switch (actionType) {
        case 'block_request':
          this.emit('requestBlocked', result);
          break;
        case 'log_security_event':
          this.logSecurityEvent(result);
          break;
        case 'alert_admins':
          this.alertAdmins(result);
          break;
        case 'sanitize_input':
          this.emit('inputSanitizationRequired', result);
          break;
      }
    }

    if (action.autoBlock) {
      this.emit('autoBlock', result);
    }
  }

  // Security Monitoring
  private initializeMonitoring(): void {
    if (this.config.monitoring.enabled) {
      setInterval(() => {
        this.performHealthCheck();
      }, 60000); // Every minute

      setInterval(() => {
        this.updateBehavioralBaseline();
      }, this.config.threatDetection.behavioralAnalysis.updateFrequency * 60 * 60 * 1000);
    }
  }

  private performHealthCheck(): void {
    const healthData = this.getSecurityHealthMetrics();
    
    if (this.config.monitoring.metricsEnabled) {
      this.emit('metrics', healthData);
    }

    // Check for anomalies
    if (this.config.threatDetection.anomalyDetection.enabled) {
      const anomalies = this.detectAnomalies(healthData);
      if (anomalies.length > 0) {
        this.handleAnomalyDetection(anomalies);
      }
    }
  }

  private getSecurityHealthMetrics(): SecurityHealthMetrics {
    return {
      timestamp: new Date(),
      activeSessions: this.getActiveSessionCount(),
      failedLoginAttempts: this.getFailedLoginAttempts(),
      threatsDetected: this.getThreatCount(),
      rateLimitHits: this.getRateLimitHits(),
      auditEvents: this.getAuditEventCount(),
      complianceScore: this.calculateComplianceScore(),
    };
  }

  private updateBehavioralBaseline(): void {
    // Update behavioral baseline with current metrics
    const currentMetrics = this.getSecurityHealthMetrics();
    
    for (const [metricName, value] of Object.entries(currentMetrics)) {
      if (!this.behavioralBaseline.has(metricName)) {
        this.behavioralBaseline.set(metricName, []);
      }
      
      const baseline = this.behavioralBaseline.get(metricName)!;
      baseline.push(value);
      
      // Keep only the last N values (baseline window)
      const windowSize = this.config.threatDetection.behavioralAnalysis.baselineWindow;
      if (baseline.length > windowSize) {
        baseline.shift();
      }
    }
  }

  private detectAnomalies(metrics: SecurityHealthMetrics): AnomalyResult[] {
    const anomalies: AnomalyResult[] = [];
    const threshold = this.config.threatDetection.behavioralAnalysis.deviationThreshold;
    const sensitivity = this.config.threatDetection.anomalyDetection.sensitivity;

    for (const [metricName, currentValue] of Object.entries(metrics)) {
      if (typeof currentValue !== 'number') continue;

      const baseline = this.behavioralBaseline.get(metricName);
      if (!baseline || baseline.length < 10) continue; // Need minimum baseline data

      const mean = baseline.reduce((a, b) => a + b, 0) / baseline.length;
      const variance = baseline.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / baseline.length;
      const stdDev = Math.sqrt(variance);
      const zScore = Math.abs(currentValue - mean) / stdDev;

      if (zScore > threshold * sensitivity) {
        anomalies.push({
          metricName,
          currentValue,
          expectedValue: mean,
          deviation: zScore,
          severity: zScore > threshold * 2 ? 'high' : 'medium',
          timestamp: new Date(),
        });
      }
    }

    return anomalies;
  }

  private handleAnomalyDetection(anomalies: AnomalyResult[]): void {
    for (const anomaly of anomalies) {
      this.createSecurityEvent({
        type: SecurityEventType.ANOMALY_DETECTED,
        severity: anomaly.severity,
        source: 'anomaly-detection',
        description: `Anomaly detected in ${anomaly.metricName}`,
        metadata: anomaly,
      });
    }
  }

  // Security Event Management
  createSecurityEvent(event: Omit<SecurityEvent, 'id' | 'timestamp' | 'resolved'>): SecurityEvent {
    const securityEvent: SecurityEvent = {
      id: this.generateEventId(),
      timestamp: new Date(),
      resolved: false,
      ...event,
    };

    this.eventQueue.push(securityEvent);
    
    // Process event queue
    if (this.eventQueue.length >= this.config.eventHandling.batchSize) {
      this.processEventQueue();
    }

    this.emit('securityEvent', securityEvent);
    return securityEvent;
  }

  private processEventQueue(): void {
    const events = this.eventQueue.splice(0, this.config.eventHandling.batchSize);
    
    for (const handler of this.config.eventHandling.handlers) {
      if (handler.config.enabled) {
        this.executeEventHandler(handler, events);
      }
    }
  }

  private executeEventHandler(handler: EventHandler, events: SecurityEvent[]): void {
    switch (handler.type) {
      case 'console':
        console.log('Security Events:', events);
        break;
      case 'file':
        this.writeEventsToFile(events, handler.config.path);
        break;
      case 'database':
        this.writeEventsToDatabase(events, handler.config.table);
        break;
    }
  }

  private writeEventsToFile(events: SecurityEvent[], filePath: string): void {
    // Implementation would write to file
    this.emit('eventsLogged', { events, filePath });
  }

  private writeEventsToDatabase(events: SecurityEvent[], table: string): void {
    // Implementation would write to database
    this.emit('eventsStored', { events, table });
  }

  private logSecurityEvent(data: any): void {
    if (this.config.monitoring.logLevel === 'debug') {
      console.log('Security Event:', data);
    }
  }

  private alertAdmins(threat: ThreatDetectionResult): void {
    if (this.config.monitoring.alertingEnabled) {
      this.emit('adminAlert', {
        type: 'security_threat',
        severity: threat.severity,
        message: `Security threat detected: ${threat.patternName}`,
        data: threat,
      });
    }
  }

  // Audit Functions
  auditAction(action: string, resource: string, user: string, result: 'success' | 'failure'): void {
    if (!this.config.audit.enabled) return;

    const auditEvent = this.createSecurityEvent({
      type: SecurityEventType.AUDIT_LOG_EVENT,
      severity: result === 'failure' ? 'medium' : 'low',
      source: 'audit-system',
      description: `User ${user} performed ${action} on ${resource}: ${result}`,
      metadata: { action, resource, user, result },
    });

    this.checkComplianceViolation(auditEvent);
  }

  private checkComplianceViolation(event: SecurityEvent): void {
    // Check if the event violates any compliance framework requirements
    const frameworks = this.config.audit.complianceFrameworks;
    
    for (const framework of frameworks) {
      const violations = this.evaluateCompliance(framework, event);
      if (violations.length > 0) {
        this.createSecurityEvent({
          type: SecurityEventType.COMPLIANCE_VIOLATION,
          severity: 'high',
          source: 'compliance-check',
          description: `Compliance violation in ${framework}`,
          metadata: { framework, violations, originalEvent: event },
        });
      }
    }
  }

  private evaluateCompliance(framework: string, event: SecurityEvent): string[] {
    // Framework-specific compliance checks
    const violations: string[] = [];
    
    switch (framework) {
      case 'SOC2':
        if (event.type === SecurityEventType.AUTHENTICATION_FAILURE && 
            event.metadata.attempts >= this.config.authentication.maxLoginAttempts) {
          violations.push('excessive_failed_authentication_attempts');
        }
        break;
      case 'GDPR':
        if (event.description.includes('personal_data') && event.metadata.access !== 'authorized') {
          violations.push('unauthorized_personal_data_access');
        }
        break;
      case 'ISO27001':
        if (event.type === SecurityEventType.THREAT_DETECTED && 
            event.severity === 'critical') {
          violations.push('critical_security_incident_not_reported');
        }
        break;
    }
    
    return violations;
  }

  // Rate Limiting
  checkRateLimit(key: string, type: string = 'default'): RateLimitResult {
    if (!this.config.rateLimiting.enabled) {
      return { allowed: true, remaining: Infinity };
    }

    const limiter = this.config.rateLimiting.customLimiters[type] || {
      windowMs: this.config.rateLimiting.windowMs,
      max: this.config.rateLimiting.maxRequests,
    };

    // Implementation would check rate limiting store
    const currentCount = this.getRateLimitCount(key, type);
    const remaining = Math.max(0, limiter.max - currentCount);
    
    if (currentCount >= limiter.max) {
      this.createSecurityEvent({
        type: SecurityEventType.RATE_LIMIT_EXCEEDED,
        severity: 'medium',
        source: 'rate-limiter',
        description: `Rate limit exceeded for key: ${key}`,
        metadata: { key, type, currentCount, limit: limiter.max },
      });
      
      return { allowed: false, remaining: 0, resetTime: Date.now() + limiter.windowMs };
    }

    return { allowed: true, remaining, resetTime: Date.now() + limiter.windowMs };
  }

  private getRateLimitCount(key: string, type: string): number {
    // Implementation would check rate limit store (Redis, memory, etc.)
    return 0; // Placeholder
  }

  // Security Headers
  getSecurityHeaders(): Record<string, string> {
    if (!this.config.headers.enabled) {
      return {};
    }

    const headers: Record<string, string> = {};

    if (this.config.headers.strictTransportSecurity) {
      headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains; preload';
    }

    if (this.config.headers.contentTypeOptions) {
      headers['X-Content-Type-Options'] = 'nosniff';
    }

    if (this.config.headers.frameOptions) {
      headers['X-Frame-Options'] = this.config.headers.frameOptions;
    }

    if (this.config.headers.xssProtection) {
      headers['X-XSS-Protection'] = '1; mode=block';
    }

    if (this.config.headers.referrerPolicy) {
      headers['Referrer-Policy'] = this.config.headers.referrerPolicy;
    }

    headers['Content-Security-Policy'] = this.buildCSPHeader();

    return headers;
  }

  private buildCSPHeader(): string {
    const csp = this.config.policies.contentSecurityPolicy;
    return [
      `default-src ${csp.defaultSrc.join(' ')}`,
      `script-src ${csp.scriptSrc.join(' ')}`,
      `style-src ${csp.styleSrc.join(' ')}`,
      `img-src ${csp.imgSrc.join(' ')}`,
      `connect-src ${csp.connectSrc.join(' ')}`,
      `font-src ${csp.fontSrc.join(' ')}`,
      `object-src ${csp.objectSrc.join(' ')}`,
      `media-src ${csp.mediaSrc.join(' ')}`,
      `frame-src ${csp.frameSrc.join(' ')}`,
    ].join('; ');
  }

  // Utility Methods
  private generateEventId(): string {
    return `sec_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private calculateComplianceScore(): number {
    // Calculate overall compliance score based on audit events and violations
    // This is a simplified implementation
    return 95; // Placeholder
  }

  private getActiveSessionCount(): number {
    return 0; // Placeholder
  }

  private getFailedLoginAttempts(): number {
    return 0; // Placeholder
  }

  private getThreatCount(): number {
    return 0; // Placeholder
  }

  private getRateLimitHits(): number {
    return 0; // Placeholder
  }

  private getAuditEventCount(): number {
    return this.eventQueue.filter(e => e.type === SecurityEventType.AUDIT_LOG_EVENT).length;
  }

  // Export security configuration utilities
  exportConfig(): string {
    return JSON.stringify(this.config, null, 2);
  }

  validateConfig(config: SecurityConfig): ValidationResult {
    const errors: string[] = [];

    // Validate authentication config
    if (config.authentication.sessionTimeout < 1 || config.authentication.sessionTimeout > 1440) {
      errors.push('Session timeout must be between 1 and 1440 minutes');
    }

    if (config.authentication.maxLoginAttempts < 1 || config.authentication.maxLoginAttempts > 10) {
      errors.push('Max login attempts must be between 1 and 10');
    }

    // Validate encryption config
    if (!['aes-256-gcm', 'aes-256-cbc'].includes(config.encryption.algorithm)) {
      errors.push('Invalid encryption algorithm');
    }

    // Validate rate limiting
    if (config.rateLimiting.maxRequests < 1) {
      errors.push('Rate limit max requests must be at least 1');
    }

    // Validate threat detection
    if (config.threatDetection.behavioralAnalysis.deviationThreshold < 1 || 
        config.threatDetection.behavioralAnalysis.deviationThreshold > 5) {
      errors.push('Deviation threshold must be between 1 and 5');
    }

    return {
      valid: errors.length === 0,
      errors,
    };
  }

  // Best Practices Enforcement
  enforceBestPractices(): BestPracticesReport {
    const report: BestPracticesReport = {
      score: 0,
      passedChecks: 0,
      totalChecks: 0,
      issues: [],
      recommendations: [],
    };

    // Check 1: Password Policy Strength
    const passwordCheck = this.checkPasswordPolicyStrength();
    report.totalChecks++;
    if (passwordCheck.passed) {
      report.passedChecks++;
    } else {
      report.issues.push(passwordCheck.issue!);
      report.recommendations.push(passwordCheck.recommendation!);
    }

    // Check 2: Session Timeout
    const sessionCheck = this.checkSessionTimeout();
    report.totalChecks++;
    if (sessionCheck.passed) {
      report.passedChecks++;
    } else {
      report.issues.push(sessionCheck.issue!);
      report.recommendations.push(sessionCheck.recommendation!);
    }

    // Check 3: MFA Requirement
    const mfaCheck = this.checkMFARequirement();
    report.totalChecks++;
    if (mfaCheck.passed) {
      report.passedChecks++;
    } else {
      report.issues.push(mfaCheck.issue!);
      report.recommendations.push(mfaCheck.recommendation!);
    }

    // Check 4: Encryption at Rest
    const encryptionCheck = this.checkEncryptionAtRest();
    report.totalChecks++;
    if (encryptionCheck.passed) {
      report.passedChecks++;
    } else {
      report.issues.push(encryptionCheck.issue!);
      report.recommendations.push(encryptionCheck.recommendation!);
    }

    // Check 5: Security Headers
    const headersCheck = this.checkSecurityHeaders();
    report.totalChecks++;
    if (headersCheck.passed) {
      report.passedChecks++;
    } else {
      report.issues.push(headersCheck.issue!);
      report.recommendations.push(headersCheck.recommendation!);
    }

    // Calculate overall score
    report.score = Math.round((report.passedChecks / report.totalChecks) * 100);

    return report;
  }

  private checkPasswordPolicyStrength(): CheckResult {
    const policy = this.config.authentication.passwordPolicy;
    let passed = true;
    let issue: string | undefined;
    let recommendation: string | undefined;

    if (policy.minLength < 12) {
      passed = false;
      issue = 'Minimum password length is too short';
      recommendation = 'Increase minimum password length to at least 12 characters';
    } else if (!policy.requireUppercase || !policy.requireLowercase || !policy.requireNumbers) {
      passed = false;
      issue = 'Password complexity requirements are insufficient';
      recommendation = 'Require uppercase, lowercase, and numbers in passwords';
    }

    return { passed, issue, recommendation };
  }

  private checkSessionTimeout(): CheckResult {
    const timeout = this.config.authentication.sessionTimeout;
    let passed = true;
    let issue: string | undefined;
    let recommendation: string | undefined;

    if (timeout > 60) {
      passed = false;
      issue = 'Session timeout is too long';
      recommendation = 'Reduce session timeout to 30 minutes or less';
    }

    return { passed, issue, recommendation };
  }

  private checkMFARequirement(): CheckResult {
    let passed = this.config.authentication.requireMFA;
    let issue: string | undefined;
    let recommendation: string | undefined;

    if (!passed) {
      issue = 'Multi-factor authentication is not required';
      recommendation = 'Enable multi-factor authentication for all users';
    }

    return { passed, issue, recommendation };
  }

  private checkEncryptionAtRest(): CheckResult {
    let passed = this.config.encryption.enableAtRestEncryption;
    let issue: string | undefined;
    let recommendation: string | undefined;

    if (!passed) {
      issue = 'Data encryption at rest is not enabled';
      recommendation = 'Enable encryption at rest for all sensitive data';
    }

    return { passed, issue, recommendation };
  }

  private checkSecurityHeaders(): CheckResult {
    let passed = this.config.headers.enabled;
    let issue: string | undefined;
    let recommendation: string | undefined;

    if (!passed) {
      issue = 'Security headers are not configured';
      recommendation = 'Enable security headers including CSP, HSTS, and X-Frame-Options';
    }

    return { passed, issue, recommendation };
  }

  // Cleanup and maintenance
  cleanup(): void {
    // Clear event queue
    this.eventQueue = [];
    
    // Clear behavioral baseline
    this.behavioralBaseline.clear();
    
    // Remove event listeners
    this.removeAllListeners();
  }
}

// Type definitions for return types
interface ThreatDetectionResult {
  patternId: string;
  patternName: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  category: string;
  matches: MatchResult[];
  timestamp: Date;
}

interface MatchResult {
  value: string;
  index: number;
  groups: string[];
}

interface SecurityHealthMetrics {
  timestamp: Date;
  activeSessions: number;
  failedLoginAttempts: number;
  threatsDetected: number;
  rateLimitHits: number;
  auditEvents: number;
  complianceScore: number;
}

interface AnomalyResult {
  metricName: string;
  currentValue: number;
  expectedValue: number;
  deviation: number;
  severity: 'low' | 'medium' | 'high';
  timestamp: Date;
}

interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  resetTime?: number;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

interface BestPracticesReport {
  score: number;
  passedChecks: number;
  totalChecks: number;
  issues: string[];
  recommendations: string[];
}

interface CheckResult {
  passed: boolean;
  issue?: string;
  recommendation?: string;
}

// Default security configuration manager instance
export const defaultSecurityConfigManager = new SecurityConfigManager();

// Export utilities
export const SecurityConfigUtils = {
  createCustomConfig: (overrides: Partial<SecurityConfig>) => new SecurityConfigManager(overrides),
  
  validatePassword: (password: string, policy?: PasswordPolicy): ValidationResult => {
    const activePolicy = policy || defaultSecurityConfig.authentication.passwordPolicy;
    const errors: string[] = [];

    if (password.length < activePolicy.minLength) {
      errors.push(`Password must be at least ${activePolicy.minLength} characters`);
    }

    if (password.length > activePolicy.maxLength) {
      errors.push(`Password must not exceed ${activePolicy.maxLength} characters`);
    }

    if (activePolicy.requireUppercase && !/[A-Z]/.test(password)) {
      errors.push('Password must contain at least one uppercase letter');
    }

    if (activePolicy.requireLowercase && !/[a-z]/.test(password)) {
      errors.push('Password must contain at least one lowercase letter');
    }

    if (activePolicy.requireNumbers && !/\d/.test(password)) {
      errors.push('Password must contain at least one number');
    }

    if (activePolicy.requireSpecialChars && !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
      errors.push('Password must contain at least one special character');
    }

    return { valid: errors.length === 0, errors };
  },

  sanitizeInput: (input: string, rules: SanitizationRule[]): string => {
    let sanitized = input;

    for (const rule of rules) {
      if (rule.trimWhitespace) {
        sanitized = sanitized.trim();
      }
      
      if (rule.stripHtml) {
        sanitized = sanitized.replace(/<[^>]*>/g, '');
      }
      
      if (rule.escapeHtml) {
        sanitized = sanitized
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;')
          .replace(/'/g, '&#x27;');
      }
    }

    return sanitized;
  },

  generateSecurityToken: (length: number = 32): string => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  },

  hashPassword: async (password: string, saltRounds: number = 12): Promise<string> => {
    // This would typically use bcrypt or similar
    const salt = await SecurityConfigUtils.generateSecurityToken(16);
    // Placeholder implementation
    return `${salt}:${password}:hashed`;
  },

  isSecureConnection: (protocol: string): boolean => {
    return protocol === 'https' || protocol === 'wss';
  },

  calculateEntropy: (password: string): number => {
    const charset = 0;
    if (/[a-z]/.test(password)) charset += 26;
    if (/[A-Z]/.test(password)) charset += 26;
    if (/[0-9]/.test(password)) charset += 10;
    if (/[^a-zA-Z0-9]/.test(password)) charset += 32;

    return Math.log2(Math.pow(charset, password.length));
  },
};

// Export security event types for external use
export { SecurityEventType };

// Default export
export default SecurityConfigManager;