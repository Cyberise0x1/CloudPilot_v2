/**
 * Centralized Secrets Management System
 * Provides secure secrets handling with caching, validation, and rotation
 */

import crypto from 'crypto';

export interface SecretConfig {
  key: string;
  required?: boolean;
  validation?: ValidationRule;
  refreshInterval?: number;
  fallback?: string;
  description?: string;
}

export interface ValidationRule {
  type: 'aws_access_key' | 'aws_secret_key' | 'database_url' | 'jwt_secret' | 'email' | 'url' | 'custom';
  pattern?: RegExp;
  customValidator?: (value: string) => boolean;
}

export interface SecretMetadata {
  lastLoaded: number;
  lastModified: number;
  rotationCount: number;
  isStale: boolean;
}

export interface CacheEntry {
  value: string;
  metadata: SecretMetadata;
  validationErrors?: string[];
}

export interface SecretsChangeEvent {
  key: string;
  oldValue?: string;
  newValue: string;
  timestamp: number;
}

/**
 * Validation rules for common secret types
 */
export const VALIDATION_RULES = {
  aws_access_key: {
    type: 'aws_access_key' as const,
    pattern: /^[A-Z0-9]{20}$/
  },
  aws_secret_key: {
    type: 'aws_secret_key' as const,
    pattern: /^[A-Za-z0-9/+=]{40}$/
  },
  database_url: {
    type: 'database_url' as const,
    pattern: /^(postgresql|mysql|mongodb|redis):\/\/[^:]+:[^@]+@[^:]+:\d+\/[^?]+(\?.*)?$/
  },
  jwt_secret: {
    type: 'jwt_secret' as const,
    pattern: /^[A-Za-z0-9._-]{32,}$/
  },
  email: {
    type: 'email' as const,
    pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  },
  url: {
    type: 'url' as const,
    pattern: /^https?:\/\/[^\s/$.?#].[^\s]*$/i
  }
};

/**
 * Default secret configurations
 */
export const DEFAULT_SECRETS: SecretConfig[] = [
  { key: 'NODE_ENV', required: true, description: 'Environment mode' },
  { key: 'PORT', required: false, validation: { type: 'custom', customValidator: (v) => !isNaN(Number(v)) }, fallback: '3000' },
  { key: 'DATABASE_URL', required: true, validation: VALIDATION_RULES.database_url },
  { key: 'AWS_ACCESS_KEY_ID', required: false, validation: VALIDATION_RULES.aws_access_key },
  { key: 'AWS_SECRET_ACCESS_KEY', required: false, validation: VALIDATION_RULES.aws_secret_key },
  { key: 'AWS_REGION', required: false, fallback: 'us-east-1' },
  { key: 'JWT_SECRET', required: true, validation: VALIDATION_RULES.jwt_secret },
  { key: 'JWT_EXPIRES_IN', required: false, fallback: '24h' },
  { key: 'REDIS_URL', required: false, validation: VALIDATION_RULES.url },
  { key: 'SMTP_HOST', required: false, validation: VALIDATION_RULES.email },
  { key: 'SMTP_PORT', required: false, validation: { type: 'custom', customValidator: (v) => !isNaN(Number(v)) && Number(v) > 0 }, fallback: '587' },
  { key: 'SMTP_USER', required: false },
  { key: 'SMTP_PASSWORD', required: false },
  { key: 'API_KEY', required: false },
  { key: 'ENCRYPTION_KEY', required: false, validation: VALIDATION_RULES.jwt_secret }
];

/**
 * Custom validation functions
 */
export const customValidators = {
  isBase64: (value: string): boolean => {
    try {
      return Buffer.from(value, 'base64').toString('base64') === value;
    } catch {
      return false;
    }
  },
  isHex: (value: string): boolean => {
    return /^[0-9a-fA-F]+$/.test(value);
  },
  isUUID: (value: string): boolean => {
    return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
  },
  minLength: (min: number) => (value: string): boolean => {
    return value.length >= min;
  },
  hasSpecialChar: (value: string): boolean => {
    return /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value);
  },
  hasNumber: (value: string): boolean => {
    return /\d/.test(value);
  },
  hasUpperCase: (value: string): boolean => {
    return /[A-Z]/.test(value);
  }
};

/**
 * Secrets Manager Class
 * Handles centralized secrets management with caching, validation, and rotation
 */
export class SecretsManager {
  private cache: Map<string, CacheEntry> = new Map();
  private config: Map<string, SecretConfig> = new Map();
  private refreshIntervals: Map<string, NodeJS.Timeout> = new Map();
  private changeListeners: Array<(event: SecretsChangeEvent) => void> = [];
  private hashCache: Map<string, string> = new Map();
  private isInitialized = false;

  constructor(configs?: SecretConfig[]) {
    const configsToUse = configs || DEFAULT_SECRETS;
    configsToUse.forEach(config => {
      this.config.set(config.key, config);
    });
  }

  /**
   * Initialize the secrets manager and load all secrets
   */
  async initialize(): Promise<void> {
    if (this.isInitialized) {
      return;
    }

    console.log('🔐 Initializing Secrets Manager...');
    
    // Load environment variables
    this.loadEnvironmentVariables();
    
    // Validate and cache secrets
    await this.refreshAllSecrets();
    
    // Start refresh intervals
    this.startRefreshIntervals();
    
    this.isInitialized = true;
    console.log(`✅ Secrets Manager initialized with ${this.cache.size} secrets`);
  }

  /**
   * Load environment variables into the system
   */
  private loadEnvironmentVariables(): void {
    for (const [key, config] of this.config) {
      const value = process.env[key];
      if (value !== undefined) {
        // Store in cache with metadata
        const metadata: SecretMetadata = {
          lastLoaded: Date.now(),
          lastModified: Date.now(),
          rotationCount: 0,
          isStale: false
        };
        
        this.cache.set(key, {
          value: this.sanitizeValue(value),
          metadata,
          validationErrors: []
        });
      }
    }
  }

  /**
   * Sanitize secret value for safe storage
   */
  private sanitizeValue(value: string): string {
    return value.trim();
  }

  /**
   * Validate a secret value against its configuration
   */
  private validateSecret(key: string, value: string): string[] {
    const config = this.config.get(key);
    if (!config?.validation) {
      return [];
    }

    const errors: string[] = [];
    const { validation } = config;

    // Pattern validation
    if (validation.pattern && !validation.pattern.test(value)) {
      errors.push(`Value does not match expected pattern for ${validation.type}`);
    }

    // Custom validation
    if (validation.customValidator && !validation.customValidator(value)) {
      errors.push(`Custom validation failed for ${key}`);
    }

    // Additional validations by type
    switch (validation.type) {
      case 'aws_access_key':
        if (!value.startsWith('AKIA') && !value.startsWith('ASIA')) {
          errors.push('AWS Access Key should start with AKIA or ASIA');
        }
        break;
      
      case 'aws_secret_key':
        if (value.length !== 40) {
          errors.push('AWS Secret Key should be exactly 40 characters');
        }
        break;
      
      case 'database_url':
        // Additional database URL validation
        try {
          new URL(value);
        } catch {
          errors.push('Invalid database URL format');
        }
        break;
      
      case 'jwt_secret':
        if (value.length < 32) {
          errors.push('JWT Secret should be at least 32 characters');
        }
        break;
    }

    return errors;
  }

  /**
   * Refresh all secrets from environment
   */
  async refreshAllSecrets(): Promise<void> {
    const events: SecretsChangeEvent[] = [];

    for (const [key, config] of this.config) {
      const event = await this.refreshSecret(key);
      if (event) {
        events.push(event);
      }
    }

    // Emit change events
    events.forEach(event => this.emitChangeEvent(event));
  }

  /**
   * Refresh a specific secret
   */
  async refreshSecret(key: string): Promise<SecretsChangeEvent | null> {
    const config = this.config.get(key);
    if (!config) {
      throw new Error(`Unknown secret key: ${key}`);
    }

    const newValue = process.env[key];
    const oldCacheEntry = this.cache.get(key);
    const oldValue = oldCacheEntry?.value;

    // Handle missing secrets
    if (newValue === undefined || newValue === null || newValue === '') {
      if (config.required) {
        console.warn(`⚠️  Required secret ${key} is missing`);
        return null;
      }
      
      if (config.fallback) {
        if (oldValue !== config.fallback) {
          const event: SecretsChangeEvent = {
            key,
            oldValue,
            newValue: config.fallback,
            timestamp: Date.now()
          };
          this.updateCache(key, config.fallback);
          return event;
        }
        return null;
      }
      
      console.warn(`⚠️  Secret ${key} not found in environment`);
      return null;
    }

    // Validate the new value
    const validationErrors = this.validateSecret(key, newValue);
    if (validationErrors.length > 0) {
      console.error(`❌ Validation failed for ${key}:`, validationErrors);
      
      // If we have a cached valid value and validation fails, keep the old one
      if (oldCacheEntry && oldCacheEntry.validationErrors?.length === 0) {
        console.warn(`⚠️  Keeping old value for ${key} due to validation failure`);
        return null;
      }
      
      if (config.required && !config.fallback) {
        throw new Error(`Required secret ${key} failed validation: ${validationErrors.join(', ')}`);
      }
    }

    // Check if value has changed
    const sanitizedValue = this.sanitizeValue(newValue);
    if (oldValue !== sanitizedValue) {
      const event: SecretsChangeEvent = {
        key,
        oldValue,
        newValue: sanitizedValue,
        timestamp: Date.now()
      };
      
      this.updateCache(key, sanitizedValue, validationErrors);
      return event;
    }

    return null;
  }

  /**
   * Update cache entry for a secret
   */
  private updateCache(key: string, value: string, validationErrors?: string[]): void {
    const existing = this.cache.get(key);
    const now = Date.now();
    
    const metadata: SecretMetadata = {
      lastLoaded: now,
      lastModified: now,
      rotationCount: existing ? existing.metadata.rotationCount + 1 : 0,
      isStale: false
    };

    this.cache.set(key, {
      value,
      metadata,
      validationErrors
    });

    // Update hash cache
    this.hashCache.set(key, crypto.createHash('sha256').update(value).digest('hex'));
  }

  /**
   * Get a secret value
   */
  getSecret(key: string): string | undefined {
    const entry = this.cache.get(key);
    if (!entry) {
      console.warn(`⚠️  Secret ${key} not found in cache`);
      return undefined;
    }

    // Check if secret is stale
    if (entry.metadata.isStale) {
      console.warn(`⚠️  Secret ${key} is marked as stale`);
    }

    return entry.value;
  }

  /**
   * Get secret with metadata
   */
  getSecretWithMetadata(key: string): CacheEntry | undefined {
    return this.cache.get(key);
  }

  /**
   * Check if secret is valid
   */
  isSecretValid(key: string): boolean {
    const entry = this.cache.get(key);
    return entry !== undefined && (!entry.validationErrors || entry.validationErrors.length === 0);
  }

  /**
   * Get all secrets as an object
   */
  getAllSecrets(): Record<string, string> {
    const secrets: Record<string, string> = {};
    for (const [key, entry] of this.cache) {
      secrets[key] = entry.value;
    }
    return secrets;
  }

  /**
   * Check if a secret has changed
   */
  hasSecretChanged(key: string): boolean {
    const entry = this.cache.get(key);
    if (!entry) {
      return false;
    }

    const currentValue = process.env[key];
    if (currentValue === undefined) {
      return false;
    }

    const sanitizedCurrent = this.sanitizeValue(currentValue);
    const hash = crypto.createHash('sha256').update(sanitizedCurrent).digest('hex');
    
    return this.hashCache.get(key) !== hash;
  }

  /**
   * Mark secret as stale (force refresh on next access)
   */
  markAsStale(key: string): void {
    const entry = this.cache.get(key);
    if (entry) {
      entry.metadata.isStale = true;
    }
  }

  /**
   * Start automatic refresh intervals
   */
  private startRefreshIntervals(): void {
    for (const [key, config] of this.config) {
      if (config.refreshInterval) {
        const interval = setInterval(async () => {
          try {
            const event = await this.refreshSecret(key);
            if (event) {
              console.log(`🔄 Secret ${key} refreshed automatically`);
              this.emitChangeEvent(event);
            }
          } catch (error) {
            console.error(`❌ Failed to refresh secret ${key}:`, error);
          }
        }, config.refreshInterval);

        this.refreshIntervals.set(key, interval);
      }
    }
  }

  /**
   * Stop all refresh intervals
   */
  stopRefreshIntervals(): void {
    for (const interval of this.refreshIntervals.values()) {
      clearInterval(interval);
    }
    this.refreshIntervals.clear();
  }

  /**
   * Add a listener for secret changes
   */
  onSecretChange(listener: (event: SecretsChangeEvent) => void): void {
    this.changeListeners.push(listener);
  }

  /**
   * Remove a change listener
   */
  removeSecretChangeListener(listener: (event: SecretsChangeEvent) => void): void {
    const index = this.changeListeners.indexOf(listener);
    if (index > -1) {
      this.changeListeners.splice(index, 1);
    }
  }

  /**
   * Emit change event to all listeners
   */
  private emitChangeEvent(event: SecretsChangeEvent): void {
    this.changeListeners.forEach(listener => {
      try {
        listener(event);
      } catch (error) {
        console.error('Error in secret change listener:', error);
      }
    });
  }

  /**
   * Validate all secrets
   */
  validateAllSecrets(): Record<string, string[]> {
    const results: Record<string, string[]> = {};
    
    for (const [key, entry] of this.cache) {
      const config = this.config.get(key);
      if (config?.validation) {
        const errors = this.validateSecret(key, entry.value);
        results[key] = errors;
      }
    }
    
    return results;
  }

  /**
   * Get secret configuration
   */
  getSecretConfig(key: string): SecretConfig | undefined {
    return this.config.get(key);
  }

  /**
   * Get all secret configurations
   */
  getAllSecretConfigs(): Record<string, SecretConfig> {
    const configs: Record<string, SecretConfig> = {};
    for (const [key, config] of this.config) {
      configs[key] = { ...config };
    }
    return configs;
  }

  /**
   * Reload secrets from environment
   */
  async reload(): Promise<void> {
    console.log('🔄 Reloading secrets...');
    
    // Stop existing intervals
    this.stopRefreshIntervals();
    
    // Clear cache
    this.cache.clear();
    this.hashCache.clear();
    
    // Reload
    this.isInitialized = false;
    await this.initialize();
  }

  /**
   * Get statistics about the secrets manager
   */
  getStatistics(): {
    totalSecrets: number;
    cachedSecrets: number;
    requiredSecrets: number;
    validatedSecrets: number;
    staleSecrets: number;
    rotationCount: number;
  } {
    let requiredSecrets = 0;
    let validatedSecrets = 0;
    let staleSecrets = 0;
    let totalRotationCount = 0;

    for (const [key, config] of this.config) {
      if (config.required) requiredSecrets++;
      
      const entry = this.cache.get(key);
      if (entry) {
        if (entry.metadata.isStale) staleSecrets++;
        if (!entry.validationErrors || entry.validationErrors.length === 0) {
          validatedSecrets++;
        }
        totalRotationCount += entry.metadata.rotationCount;
      }
    }

    return {
      totalSecrets: this.config.size,
      cachedSecrets: this.cache.size,
      requiredSecrets,
      validatedSecrets,
      staleSecrets,
      rotationCount: totalRotationCount
    };
  }

  /**
   * Cleanup and shutdown
   */
  shutdown(): void {
    console.log('🔐 Shutting down Secrets Manager...');
    this.stopRefreshIntervals();
    this.changeListeners.length = 0;
    this.cache.clear();
    this.hashCache.clear();
    this.isInitialized = false;
  }
}

/**
 * Utility Functions
 */

/**
 * Create a new Secrets Manager instance
 */
export function createSecretsManager(configs?: SecretConfig[]): SecretsManager {
  return new SecretsManager(configs);
}

/**
 * Get environment variable with fallback
 */
export function getEnvWithFallback(key: string, fallback?: string, required = false): string {
  const value = process.env[key];
  
  if (value !== undefined && value !== '') {
    return value;
  }
  
  if (required && !fallback) {
    throw new Error(`Required environment variable ${key} is not set`);
  }
  
  return fallback || '';
}

/**
 * Validate environment variable format
 */
export function validateEnvFormat(key: string, rule: ValidationRule): boolean {
  const value = process.env[key];
  
  if (!value) {
    return !rule; // No validation rule means any value (including empty) is ok
  }

  // Pattern validation
  if (rule.pattern && !rule.pattern.test(value)) {
    return false;
  }

  // Custom validation
  if (rule.customValidator && !rule.customValidator(value)) {
    return false;
  }

  return true;
}

/**
 * Check if environment is in production
 */
export function isProduction(): boolean {
  return process.env.NODE_ENV === 'production';
}

/**
 * Check if environment is in development
 */
export function isDevelopment(): boolean {
  return process.env.NODE_ENV === 'development';
}

/**
 * Get masked secret for logging (shows only first/last few characters)
 */
export function maskSecret(value: string, showStart = 4, showEnd = 4): string {
  if (value.length <= showStart + showEnd) {
    return '*'.repeat(value.length);
  }
  
  return `${value.substring(0, showStart)}${'*'.repeat(value.length - showStart - showEnd)}${value.substring(value.length - showEnd)}`;
}

/**
 * Check if all required secrets are present
 */
export function checkRequiredSecrets(configs: SecretConfig[]): string[] {
  const missing: string[] = [];
  
  for (const config of configs) {
    if (config.required) {
      const value = process.env[config.key];
      if (!value || value === '') {
        missing.push(config.key);
      }
    }
  }
  
  return missing;
}

/**
 * Generate a secure random secret
 */
export function generateSecureSecret(length = 32, charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*'): string {
  const randomBytes = crypto.randomBytes(length);
  let result = '';
  
  for (let i = 0; i < length; i++) {
    result += charset[randomBytes[i] % charset.length];
  }
  
  return result;
}

/**
 * Decrypt a secret (placeholder for actual encryption implementation)
 */
export function decryptSecret(encryptedValue: string, key: string): string {
  // This is a placeholder - implement actual decryption logic
  // For now, just return the value as-is
  return encryptedValue;
}

/**
 * Encrypt a secret (placeholder for actual encryption implementation)
 */
export function encryptSecret(value: string, key: string): string {
  // This is a placeholder - implement actual encryption logic
  // For now, just return the value as-is
  return value;
}

// Export singleton instance for easy access
export const secretsManager = new SecretsManager();

// Auto-initialize if running in Node.js environment
if (typeof window === 'undefined' && typeof process !== 'undefined') {
  // Don't auto-initialize to allow for custom configuration
  // Call secretsManager.initialize() manually or use createSecretsManager()
}