import { describe, it, expect, beforeEach } from "vitest";
import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import {
  requireAuth,
  requireRole,
  requireAdmin,
  requireManagerOrAdmin,
  requireOwnershipOrAdmin,
  optionalAuth,
  generateToken,
  generateRefreshToken,
  UserRole,
  type AuthenticatedUser
} from "./protected";

// Mock environment variables
process.env.JWT_SECRET = "test-secret-key-for-middleware";
process.env.JWT_REFRESH_TOKEN_SECRET = "test-refresh-secret";

// Helper to create mock request/response
function createMockRequest(user?: Partial<AuthenticatedUser>) {
  const req: Partial<Request> = {};
  
  if (user) {
    const token = generateToken({
      id: user.id || "user-123",
      email: user.email || "test@example.com",
      username: user.username || "testuser",
      role: user.role || UserRole.USER
    });
    
    req.headers = {
      authorization: `Bearer ${token}`
    };
  }
  
  return req as Request;
}

function createMockResponse() {
  const res: Partial<Response> = {
    status: jest.fn().mockReturnThis(),
    json: jest.fn().mockReturnThis()
  };
  return res as Response;
}

function createMockNext() {
  return jest.fn() as NextFunction;
}

describe("Protected Middleware", () => {
  describe("requireAuth", () => {
    it("should pass with valid token", async () => {
      const req = createMockRequest();
      const res = createMockResponse();
      const next = createMockNext();
      
      requireAuth(req, res, next);
      
      expect(next).toHaveBeenCalled();
      expect(req.user).toBeDefined();
      expect(req.user?.role).toBe(UserRole.USER);
    });
    
    it("should fail without authorization header", async () => {
      const req = createMockRequest();
      delete req.headers?.authorization;
      const res = createMockResponse();
      const next = createMockNext();
      
      requireAuth(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(401);
      expect(res.json).toHaveBeenCalledWith({
        message: "Authorization header is required"
      });
      expect(next).not.toHaveBeenCalled();
    });
    
    it("should fail with invalid token", async () => {
      const req = createMockRequest();
      req.headers!.authorization = "Bearer invalid-token";
      const res = createMockResponse();
      const next = createMockNext();
      
      requireAuth(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(401);
      expect(res.json).toHaveBeenCalledWith({
        message: "Invalid token"
      });
    });
  });
  
  describe("requireRole", () => {
    it("should pass with correct role", async () => {
      const req = createMockRequest({ role: UserRole.ADMIN });
      const res = createMockResponse();
      const next = createMockNext();
      const middleware = requireRole(UserRole.ADMIN);
      
      middleware(req, res, next);
      
      expect(next).toHaveBeenCalled();
    });
    
    it("should pass with admin role for any requirement", async () => {
      const req = createMockRequest({ role: UserRole.ADMIN });
      const res = createMockResponse();
      const next = createMockNext();
      const middleware = requireRole(UserRole.USER);
      
      middleware(req, res, next);
      
      expect(next).toHaveBeenCalled();
    });
    
    it("should fail with incorrect role", async () => {
      const req = createMockRequest({ role: UserRole.VIEWER });
      const res = createMockResponse();
      const next = createMockNext();
      const middleware = requireRole(UserRole.ADMIN);
      
      middleware(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(403);
      expect(res.json).toHaveBeenCalledWith(
        expect.objectContaining({
          message: "Insufficient permissions"
        })
      );
    });
    
    it("should pass with multiple allowed roles", async () => {
      const req = createMockRequest({ role: UserRole.MANAGER });
      const res = createMockResponse();
      const next = createMockNext();
      const middleware = requireRole([UserRole.ADMIN, UserRole.MANAGER]);
      
      middleware(req, res, next);
      
      expect(next).toHaveBeenCalled();
    });
  });
  
  describe("requireAdmin", () => {
    it("should pass with admin role", async () => {
      const req = createMockRequest({ role: UserRole.ADMIN });
      const res = createMockResponse();
      const next = createMockNext();
      
      requireAdmin(req, res, next);
      
      expect(next).toHaveBeenCalled();
    });
    
    it("should fail with non-admin role", async () => {
      const req = createMockRequest({ role: UserRole.USER });
      const res = createMockResponse();
      const next = createMockNext();
      
      requireAdmin(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(403);
    });
  });
  
  describe("requireManagerOrAdmin", () => {
    it("should pass with manager role", async () => {
      const req = createMockRequest({ role: UserRole.MANAGER });
      const res = createMockResponse();
      const next = createMockNext();
      
      requireManagerOrAdmin(req, res, next);
      
      expect(next).toHaveBeenCalled();
    });
    
    it("should pass with admin role", async () => {
      const req = createMockRequest({ role: UserRole.ADMIN });
      const res = createMockResponse();
      const next = createMockNext();
      
      requireManagerOrAdmin(req, res, next);
      
      expect(next).toHaveBeenCalled();
    });
    
    it("should fail with user role", async () => {
      const req = createMockRequest({ role: UserRole.USER });
      const res = createMockResponse();
      const next = createMockNext();
      
      requireManagerOrAdmin(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(403);
    });
  });
  
  describe("requireOwnershipOrAdmin", () => {
    it("should pass when user owns resource", async () => {
      const userId = "user-123";
      const req = createMockRequest({ id: userId, role: UserRole.USER });
      req.params = { userId };
      const res = createMockResponse();
      const next = createMockNext();
      
      requireOwnershipOrAdmin("userId")(req, res, next);
      
      expect(next).toHaveBeenCalled();
    });
    
    it("should pass for admin regardless of ownership", async () => {
      const userId = "admin-456";
      const req = createMockRequest({ id: "admin-456", role: UserRole.ADMIN });
      req.params = { userId: "user-123" }; // Different user
      const res = createMockResponse();
      const next = createMockNext();
      
      requireOwnershipOrAdmin("userId")(req, res, next);
      
      expect(next).toHaveBeenCalled();
    });
    
    it("should fail when user doesn't own resource", async () => {
      const req = createMockRequest({ id: "user-123", role: UserRole.USER });
      req.params = { userId: "different-user" };
      const res = createMockResponse();
      const next = createMockNext();
      
      requireOwnershipOrAdmin("userId")(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(403);
      expect(res.json).toHaveBeenCalledWith({
        message: "You can only access your own resources"
      });
    });
  });
  
  describe("optionalAuth", () => {
    it("should pass with valid token and set user", async () => {
      const req = createMockRequest({ role: UserRole.MANAGER });
      const res = createMockResponse();
      const next = createMockNext();
      
      optionalAuth(req, res, next);
      
      expect(next).toHaveBeenCalled();
      expect(req.user).toBeDefined();
      expect(req.user?.role).toBe(UserRole.MANAGER);
    });
    
    it("should pass without token and not set user", async () => {
      const req = createMockRequest();
      delete req.headers?.authorization;
      const res = createMockResponse();
      const next = createMockNext();
      
      optionalAuth(req, res, next);
      
      expect(next).toHaveBeenCalled();
      expect(req.user).toBeUndefined();
    });
    
    it("should pass with invalid token and not set user", async () => {
      const req = createMockRequest();
      req.headers!.authorization = "Bearer invalid-token";
      const res = createMockResponse();
      const next = createMockNext();
      
      optionalAuth(req, res, next);
      
      expect(next).toHaveBeenCalled();
      expect(req.user).toBeUndefined();
    });
  });
  
  describe("generateToken", () => {
    it("should generate valid JWT token", async () => {
      const userData = {
        id: "user-123",
        email: "test@example.com",
        username: "testuser",
        role: UserRole.ADMIN
      };
      
      const token = generateToken(userData);
      
      expect(token).toBeDefined();
      expect(typeof token).toBe("string");
      
      // Verify token can be decoded
      const decoded = jwt.verify(token, process.env.JWT_SECRET!);
      expect(decoded).toMatchObject(userData);
    });
    
    it("should include expiration", async () => {
      const userData = {
        id: "user-123",
        email: "test@example.com",
        username: "testuser",
        role: UserRole.USER
      };
      
      const token = generateToken(userData);
      const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any;
      
      expect(decoded.exp).toBeDefined();
      expect(decoded.iat).toBeDefined();
      expect(decoded.exp).toBeGreaterThan(decoded.iat);
    });
  });
  
  describe("generateRefreshToken", () => {
    it("should generate valid refresh token", async () => {
      const userData = {
        id: "user-123",
        email: "test@example.com",
        username: "testuser",
        role: UserRole.USER
      };
      
      const refreshToken = generateRefreshToken(userData);
      
      expect(refreshToken).toBeDefined();
      expect(typeof refreshToken).toBe("string");
      
      // Verify refresh token can be decoded
      const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_TOKEN_SECRET!);
      expect(decoded).toMatchObject({
        id: userData.id,
        type: "refresh"
      });
    });
  });
  
  describe("UserRole enum", () => {
    it("should have all expected roles", async () => {
      expect(UserRole.ADMIN).toBe("admin");
      expect(UserRole.MANAGER).toBe("manager");
      expect(UserRole.USER).toBe("user");
      expect(UserRole.VIEWER).toBe("viewer");
    });
  });
});

// Integration test example
describe("Integration Tests", () => {
  it("should protect route requiring auth and admin role", async () => {
    const req = createMockRequest({ role: UserRole.ADMIN });
    const res = createMockResponse();
    const next = createMockNext();
    
    // Chain middleware
    requireAuth(req, res, () => {
      requireAdmin(req, res, next);
    });
    
    expect(next).toHaveBeenCalled();
    expect(req.user?.role).toBe(UserRole.ADMIN);
  });
  
  it("should handle complete auth flow", async () => {
    // Generate token
    const userData = {
      id: "user-123",
      email: "test@example.com",
      username: "testuser",
      role: UserRole.MANAGER
    };
    
    const token = generateToken(userData);
    
    // Use token in request
    const req = createMockRequest();
    req.headers!.authorization = `Bearer ${token}`;
    const res = createMockResponse();
    const next = createMockNext();
    
    // Test middleware
    requireAuth(req, res, next);
    requireRole([UserRole.ADMIN, UserRole.MANAGER])(req, res, next);
    
    expect(next).toHaveBeenCalledTimes(2);
    expect(req.user).toMatchObject(userData);
  });
});