/**
 * Audit Routes
 * Provides API endpoints for audit log management and querying
 */

import { Router, Request, Response } from 'express';
import { auditService, AuditLogQueryOptions } from '../services/audit-service';
import { auditMiddleware } from '../middleware/audit';
import { logger } from '../middleware/logger';

export function registerAuditRoutes() {
  const router = Router();

  // Apply audit middleware to these routes with special configuration
  router.use(auditMiddleware({
    enabled: true,
    auditLevel: 'detailed',
    excludePaths: [], // Don't exclude any audit routes from audit
    captureBodies: true,
    sanitizeBodies: true
  }));

  /**
   * GET /api/audit/logs
   * Query audit logs with filters
   */
  router.get('/logs', async (req: Request, res: Response) => {
    try {
      const {
        userId,
        userEmail,
        action,
        resource,
        status,
        severity,
        category,
        startDate,
        endDate,
        limit = 50,
        offset = 0,
        sortBy = 'timestamp',
        sortOrder = 'desc'
      } = req.query;

      const queryOptions: AuditLogQueryOptions = {
        userId: userId as string,
        userEmail: userEmail as string,
        action: action as string,
        resource: resource as string,
        status: status as any,
        severity: severity as any,
        category: category as string,
        startDate: startDate ? new Date(startDate as string) : undefined,
        endDate: endDate ? new Date(endDate as string) : undefined,
        limit: limit ? parseInt(limit as string) : 50,
        offset: offset ? parseInt(offset as string) : 0,
        sortBy: sortBy as string,
        sortOrder: sortOrder as 'asc' | 'desc'
      };

      const logs = await auditService.queryAuditLogs(queryOptions);
      res.json({
        success: true,
        data: logs.logs,
        pagination: {
          total: logs.total,
          limit: queryOptions.limit,
          offset: queryOptions.offset,
          hasMore: logs.total > (queryOptions.offset + queryOptions.limit)
        }
      });
    } catch (error) {
      logger.error('Failed to query audit logs', {
        error: error instanceof Error ? error.message : 'Unknown error',
        query: req.query
      });

      res.status(500).json({
        success: false,
        error: 'Failed to query audit logs',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  /**
   * GET /api/audit/logs/:id
   * Get specific audit log by ID
   */
  router.get('/logs/:id', async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const log = await auditService.getAuditLog(id);

      if (!log) {
        return res.status(404).json({
          success: false,
          error: 'Audit log not found'
        });
      }

      res.json({
        success: true,
        data: log
      });
    } catch (error) {
      logger.error('Failed to get audit log', {
        error: error instanceof Error ? error.message : 'Unknown error',
        logId: req.params.id
      });

      res.status(500).json({
        success: false,
        error: 'Failed to retrieve audit log',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  /**
   * GET /api/audit/stats/summary
   * Get audit statistics summary
   */
  router.get('/stats/summary', async (req: Request, res: Response) => {
    try {
      const { startDate, endDate } = req.query;
      
      const queryOptions: AuditLogQueryOptions = {
        startDate: startDate ? new Date(startDate as string) : new Date(Date.now() - 24 * 60 * 60 * 1000), // Last 24 hours by default
        endDate: endDate ? new Date(endDate as string) : new Date(),
        limit: 1000
      };

      const stats = await auditService.getAuditStats(queryOptions);
      
      res.json({
        success: true,
        data: stats
      });
    } catch (error) {
      logger.error('Failed to get audit stats', {
        error: error instanceof Error ? error.message : 'Unknown error'
      });

      res.status(500).json({
        success: false,
        error: 'Failed to retrieve audit statistics',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  /**
   * GET /api/audit/stats/activity
   * Get audit activity statistics
   */
  router.get('/stats/activity', async (req: Request, res: Response) => {
    try {
      const { startDate, endDate, granularity = 'hour' } = req.query;
      
      const queryOptions: AuditLogQueryOptions = {
        startDate: startDate ? new Date(startDate as string) : new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // Last 7 days by default
        endDate: endDate ? new Date(endDate as string) : new Date(),
        limit: 10000
      };

      const activityStats = await auditService.getActivityStats(queryOptions, granularity as 'hour' | 'day' | 'week');
      
      res.json({
        success: true,
        data: activityStats
      });
    } catch (error) {
      logger.error('Failed to get audit activity stats', {
        error: error instanceof Error ? error.message : 'Unknown error'
      });

      res.status(500).json({
        success: false,
        error: 'Failed to retrieve audit activity statistics',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  /**
   * GET /api/audit/stats/security
   * Get security-related audit statistics
   */
  router.get('/stats/security', async (req: Request, res: Response) => {
    try {
      const { startDate, endDate } = req.query;
      
      const queryOptions: AuditLogQueryOptions = {
        startDate: startDate ? new Date(startDate as string) : new Date(Date.now() - 24 * 60 * 60 * 1000), // Last 24 hours by default
        endDate: endDate ? new Date(endDate as string) : new Date(),
        category: 'security',
        limit: 10000
      };

      const securityStats = await auditService.getSecurityStats(queryOptions);
      
      res.json({
        success: true,
        data: securityStats
      });
    } catch (error) {
      logger.error('Failed to get security stats', {
        error: error instanceof Error ? error.message : 'Unknown error'
      });

      res.status(500).json({
        success: false,
        error: 'Failed to retrieve security statistics',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  /**
   * GET /api/audit/export
   * Export audit logs to CSV format
   */
  router.get('/export', async (req: Request, res: Response) => {
    try {
      const {
        userId,
        userEmail,
        startDate,
        endDate,
        limit = 1000
      } = req.query;

      const queryOptions: AuditLogQueryOptions = {
        userId: userId as string,
        userEmail: userEmail as string,
        startDate: startDate ? new Date(startDate as string) : new Date(Date.now() - 24 * 60 * 60 * 1000),
        endDate: endDate ? new Date(endDate as string) : new Date(),
        limit: limit ? parseInt(limit as string) : 1000,
        sortBy: 'timestamp',
        sortOrder: 'desc'
      };

      const { logs } = await auditService.queryAuditLogs(queryOptions);
      
      // Convert to CSV
      const csvHeaders = 'Timestamp,User ID,User Email,Action,Resource,Status,Severity,Category,IP Address,User Agent,Execution Time\n';
      const csvRows = logs.map(log => {
        return [
          new Date(log.timestamp).toISOString(),
          log.userId || '',
          log.userEmail || '',
          log.action,
          log.resource,
          log.status,
          log.severity,
          log.category || '',
          log.ipAddress || '',
          log.userAgent || '',
          log.executionTime || 0
        ].map(field => `"${String(field).replace(/"/g, '""')}"`).join(',');
      }).join('\n');
      
      const csv = csvHeaders + csvRows;
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="audit-logs-${new Date().toISOString().split('T')[0]}.csv"`);
      res.send(csv);
      
      // Log the export action
      await (req as any).auditLog('audit.export', 'audit', {
        status: 'success',
        severity: 'medium',
        category: 'audit',
        details: {
          exportQuery: queryOptions,
          recordsExported: logs.length
        }
      });
    } catch (error) {
      logger.error('Failed to export audit logs', {
        error: error instanceof Error ? error.message : 'Unknown error'
      });

      res.status(500).json({
        success: false,
        error: 'Failed to export audit logs',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  /**
   * POST /api/audit/search
   * Advanced audit log search with full-text capabilities
   */
  router.post('/search', async (req: Request, res: Response) => {
    try {
      const {
        query,
        filters,
        startDate,
        endDate,
        limit = 50,
        offset = 0
      } = req.body;

      if (!query || typeof query !== 'string' || query.trim().length === 0) {
        return res.status(400).json({
          success: false,
          error: 'Search query is required'
        });
      }

      const searchOptions: AuditLogQueryOptions = {
        ...filters,
        startDate: startDate ? new Date(startDate) : undefined,
        endDate: endDate ? new Date(endDate) : undefined,
        limit: limit,
        offset: offset,
        searchQuery: query.trim()
      };

      const searchResults = await auditService.searchAuditLogs(searchOptions);
      
      res.json({
        success: true,
        data: searchResults.logs,
        pagination: {
          total: searchResults.total,
          limit: searchOptions.limit,
          offset: searchOptions.offset,
          hasMore: searchResults.total > (searchOptions.offset + searchOptions.limit)
        },
        searchQuery: query
      });
    } catch (error) {
      logger.error('Failed to search audit logs', {
        error: error instanceof Error ? error.message : 'Unknown error',
        searchQuery: req.body.query
      });

      res.status(500).json({
        success: false,
        error: 'Failed to search audit logs',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  /**
   * GET /api/audit/health
   * Health check for audit service
   */
  router.get('/health', async (req: Request, res: Response) => {
    try {
      const health = await auditService.getHealthStatus();
      
      res.json({
        success: true,
        data: health
      });
    } catch (error) {
      logger.error('Audit service health check failed', {
        error: error instanceof Error ? error.message : 'Unknown error'
      });

      res.status(500).json({
        success: false,
        error: 'Audit service health check failed',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  return router;
}
