import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";

// Define user roles enum
export enum UserRole {
  ADMIN = "admin",
  MANAGER = "manager",
  USER = "user",
  VIEWER = "viewer",
}

// Extend Express Request interface to include user
declare global {
  namespace Express {
    interface Request {
      user?: AuthenticatedUser;
    }
  }
}

// User interface for authenticated requests
export interface AuthenticatedUser {
  id: string;
  email: string;
  username: string;
  role: UserRole;
  iat?: number;
  exp?: number;
}

// JWT token payload interface
interface JwtPayload {
  id: string;
  email: string;
  username: string;
  role: UserRole;
  iat: number;
  exp: number;
}

// Middleware function to verify JWT token
export const requireAuth = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  try {
    // Get token from Authorization header
    const authHeader = req.headers.authorization;
    
    if (!authHeader) {
      res.status(401).json({ 
        message: "Authorization header is required" 
      });
      return;
    }

    // Check if header starts with "Bearer "
    const token = authHeader.startsWith("Bearer ") 
      ? authHeader.slice(7) 
      : authHeader;

    if (!token) {
      res.status(401).json({ 
        message: "Token is required" 
      });
      return;
    }

    // Get JWT secret from environment variables
    const jwtSecret = process.env.JWT_SECRET || process.env.JWT_ACCESS_TOKEN_SECRET;
    
    if (!jwtSecret) {
      console.error("JWT_SECRET environment variable is not set");
      res.status(500).json({ 
        message: "Server configuration error" 
      });
      return;
    }

    // Verify and decode the token
    const decoded = jwt.verify(token, jwtSecret) as JwtPayload;
    
    // Attach user information to request object
    req.user = {
      id: decoded.id,
      email: decoded.email,
      username: decoded.username,
      role: decoded.role,
      iat: decoded.iat,
      exp: decoded.exp,
    };

    next();
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      res.status(401).json({ 
        message: "Invalid token" 
      });
      return;
    }
    
    if (error instanceof jwt.TokenExpiredError) {
      res.status(401).json({ 
        message: "Token expired" 
      });
      return;
    }

    console.error("Auth middleware error:", error);
    res.status(500).json({ 
      message: "Internal server error" 
    });
  }
};

// Middleware function to require specific role(s)
export const requireRole = (
  allowedRoles: UserRole | UserRole[]
) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    // First check if user is authenticated
    if (!req.user) {
      res.status(401).json({ 
        message: "Authentication required" 
      });
      return;
    }

    // Convert single role to array for consistent handling
    const roles = Array.isArray(allowedRoles) ? allowedRoles : [allowedRoles];
    
    // Check if user has any of the required roles
    const hasRequiredRole = roles.some(role => {
      // Admin role has access to everything
      if (req.user!.role === UserRole.ADMIN) {
        return true;
      }
      return req.user!.role === role;
    });

    if (!hasRequiredRole) {
      res.status(403).json({ 
        message: "Insufficient permissions",
        requiredRoles: roles,
        userRole: req.user.role 
      });
      return;
    }

    next();
  };
};

// Middleware to require admin role only
export const requireAdmin = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  return requireRole(UserRole.ADMIN)(req, res, next);
};

// Middleware to require manager or admin role
export const requireManagerOrAdmin = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  return requireRole([UserRole.MANAGER, UserRole.ADMIN])(req, res, next);
};

// Wrapper function to apply multiple middleware easily
export const protect = (
  ...middlewares: Array<(req: Request, res: Response, next: NextFunction) => void>
) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    // Run middleware functions sequentially
    const runMiddleware = (index: number) => {
      if (index >= middlewares.length) {
        return next();
      }
      
      const middleware = middlewares[index];
      middleware(req, res, (err) => {
        if (err) {
          return next(err);
        }
        runMiddleware(index + 1);
      });
    };
    
    runMiddleware(0);
  };
};

// Helper function to generate JWT token (for login/authentication endpoints)
export const generateToken = (user: Omit<AuthenticatedUser, 'iat' | 'exp'>): string => {
  const jwtSecret = process.env.JWT_SECRET || process.env.JWT_ACCESS_TOKEN_SECRET;
  
  if (!jwtSecret) {
    throw new Error("JWT_SECRET environment variable is not set");
  }

  const payload: Omit<JwtPayload, 'iat' | 'exp'> = {
    id: user.id,
    email: user.email,
    username: user.username,
    role: user.role,
  };

  // Default expiration: 24 hours
  const expiresIn = process.env.JWT_EXPIRATION || "24h";
  
  return jwt.sign(payload, jwtSecret, { expiresIn });
};

// Helper function to generate refresh token
export const generateRefreshToken = (user: Omit<AuthenticatedUser, 'iat' | 'exp'>): string => {
  const refreshSecret = process.env.JWT_REFRESH_TOKEN_SECRET || process.env.JWT_SECRET;
  
  if (!refreshSecret) {
    throw new Error("JWT_REFRESH_TOKEN_SECRET environment variable is not set");
  }

  const payload = {
    id: user.id,
    type: "refresh",
  };

  // Refresh tokens typically last longer (7 days default)
  const expiresIn = process.env.JWT_REFRESH_EXPIRATION || "7d";
  
  return jwt.sign(payload, refreshSecret, { expiresIn });
};

// Middleware to check if user owns resource or is admin
export const requireOwnershipOrAdmin = (
  resourceUserIdField: string = "userId"
) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ 
        message: "Authentication required" 
      });
      return;
    }

    // Admin can access any resource
    if (req.user.role === UserRole.ADMIN) {
      return next();
    }

    // Get resource user ID from request params, body, or query
    const resourceUserId = 
      req.params[resourceUserIdField] ||
      req.body[resourceUserIdField] ||
      req.query[resourceUserIdField];

    if (!resourceUserId) {
      res.status(400).json({ 
        message: `Resource owner ID (${resourceUserIdField}) is required` 
      });
      return;
    }

    // Check if the authenticated user owns the resource
    if (req.user.id !== resourceUserId) {
      res.status(403).json({ 
        message: "You can only access your own resources" 
      });
      return;
    }

    next();
  };
};

// Optional authentication middleware (doesn't fail if no token)
export const optionalAuth = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  const authHeader = req.headers.authorization;
  
  if (!authHeader) {
    return next();
  }

  const token = authHeader.startsWith("Bearer ") 
    ? authHeader.slice(7) 
    : authHeader;

  if (!token) {
    return next();
  }

  try {
    const jwtSecret = process.env.JWT_SECRET || process.env.JWT_ACCESS_TOKEN_SECRET;
    
    if (!jwtSecret) {
      return next();
    }

    const decoded = jwt.verify(token, jwtSecret) as JwtPayload;
    
    req.user = {
      id: decoded.id,
      email: decoded.email,
      username: decoded.username,
      role: decoded.role,
      iat: decoded.iat,
      exp: decoded.exp,
    };
  } catch (error) {
    // Silently fail for optional auth
    console.debug("Optional auth failed:", error instanceof Error ? error.message : "Unknown error");
  }

  next();
};

// Rate limiting helper for auth endpoints
export const authRateLimit = {
  windowMs: parseInt(process.env.AUTH_RATE_LIMIT_WINDOW || "900000"), // 15 minutes default
  max: parseInt(process.env.AUTH_RATE_LIMIT_MAX || "5"), // 5 attempts default
  message: "Too many authentication attempts, please try again later",
};

// Middleware to validate API key for service-to-service authentication
export const requireApiKey = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  const apiKey = req.headers["x-api-key"];
  const validApiKey = process.env.API_KEY;

  if (!apiKey || !validApiKey || apiKey !== validApiKey) {
    res.status(401).json({ 
      message: "Invalid or missing API key" 
    });
    return;
  }

  next();
};

// Export all middleware functions and utilities
export default {
  requireAuth,
  requireRole,
  requireAdmin,
  requireManagerOrAdmin,
  requireOwnershipOrAdmin,
  optionalAuth,
  requireApiKey,
  protect,
  generateToken,
  generateRefreshToken,
  authRateLimit,
  UserRole,
  type AuthenticatedUser,
};