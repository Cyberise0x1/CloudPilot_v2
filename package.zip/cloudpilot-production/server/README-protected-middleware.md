# Protected Middleware Documentation

This middleware provides JWT-based authentication and role-based authorization for Express.js applications.

## Features

- ✅ JWT token verification
- ✅ Role-based access control
- ✅ Ownership validation
- ✅ Optional authentication
- ✅ API key authentication for service-to-service calls
- ✅ Token generation utilities
- ✅ Rate limiting helpers

## Installation

The middleware is already included in your project. Make sure you have the required dependencies:

```bash
npm install jsonwebtoken @types/jsonwebtoken
```

## Environment Variables

Add these variables to your `.env` file:

```env
# Required for JWT token signing and verification
JWT_SECRET=your-super-secret-jwt-key-here

# Optional: Separate secret for refresh tokens
JWT_REFRESH_TOKEN_SECRET=your-refresh-token-secret

# Optional: Token expiration (default: 24h)
JWT_EXPIRATION=24h

# Optional: Refresh token expiration (default: 7d)
JWT_REFRESH_EXPIRATION=7d

# Optional: Rate limiting for auth endpoints
AUTH_RATE_LIMIT_WINDOW=900000  # 15 minutes in ms
AUTH_RATE_LIMIT_MAX=5          # Max 5 attempts per window

# Optional: For API key authentication
API_KEY=your-api-key-for-service-auth
```

## Quick Start

### 1. Protect a Route with Authentication

```typescript
import { requireAuth } from "./protected";

app.get("/api/protected", requireAuth, (req, res) => {
  const user = req.user;
  res.json({ message: `Hello ${user.username}!` });
});
```

### 2. Protect a Route with Role-based Access

```typescript
import { requireAdmin, requireRole, UserRole } from "./protected";

// Admin only
app.get("/api/admin", requireAdmin, (req, res) => {
  res.json({ message: "Admin dashboard" });
});

// Multiple roles allowed
app.post("/api/manage", requireRole([UserRole.ADMIN, UserRole.MANAGER]), (req, res) => {
  res.json({ message: "Management endpoint" });
});
```

### 3. Generate JWT Tokens

```typescript
import { generateToken } from "./protected";

app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;
  
  // Validate user credentials...
  const user = await validateUser(email, password);
  
  if (user) {
    const token = generateToken({
      id: user.id,
      email: user.email,
      username: user.username,
      role: user.role
    });
    
    res.json({ token, user });
  }
});
```

## Available Middleware Functions

### Authentication Middleware

| Function | Description | Usage |
|----------|-------------|-------|
| `requireAuth` | Verifies JWT token | `requireAuth` |
| `optionalAuth` | Optional authentication (doesn't fail) | `optionalAuth` |
| `requireApiKey` | Validates API key header | `requireApiKey` |

### Role-based Authorization

| Function | Description | Usage |
|----------|-------------|-------|
| `requireRole(roles)` | Requires specific role(s) | `requireRole([UserRole.ADMIN, UserRole.MANAGER])` |
| `requireAdmin` | Admin only access | `requireAdmin` |
| `requireManagerOrAdmin` | Manager or Admin access | `requireManagerOrAdmin` |

### Resource Ownership

| Function | Description | Usage |
|----------|-------------|-------|
| `requireOwnershipOrAdmin(field)` | User owns resource or is admin | `requireOwnershipOrAdmin("userId")` |

### Utility Functions

| Function | Description | Usage |
|----------|-------------|-------|
| `generateToken(user)` | Creates JWT token | `generateToken(userData)` |
| `generateRefreshToken(user)` | Creates refresh token | `generateRefreshToken(userData)` |
| `protect(...middleware)` | Chain multiple middleware | `protect(requireAuth, requireAdmin)` |

## User Roles

```typescript
enum UserRole {
  ADMIN = "admin",    // Full access to everything
  MANAGER = "manager", // Can manage users and resources
  USER = "user",      // Regular user access
  VIEWER = "viewer"   // Read-only access
}
```

## Type Definitions

### AuthenticatedUser Interface

```typescript
interface AuthenticatedUser {
  id: string;           // User ID
  email: string;        // User email
  username: string;     // Username
  role: UserRole;       // User role
  iat?: number;         // Issued at (JWT)
  exp?: number;         // Expires at (JWT)
}
```

## Usage Examples

### Basic Authentication

```typescript
import { requireAuth } from "./protected";

app.get("/api/profile", requireAuth, (req, res) => {
  // User is authenticated, req.user is available
  res.json({ user: req.user });
});
```

### Role-based Access Control

```typescript
import { requireAdmin } from "./protected";

app.delete("/api/users/:id", requireAdmin, (req, res) => {
  // Only admins can delete users
  res.json({ message: "User deleted" });
});
```

### Multiple Role Support

```typescript
import { requireRole, UserRole } from "./protected";

app.post("/api/content", 
  requireRole([UserRole.ADMIN, UserRole.MANAGER]), 
  (req, res) => {
    // Admin or Manager can create content
    res.json({ message: "Content created" });
  }
);
```

### Ownership Validation

```typescript
import { requireOwnershipOrAdmin } from "./protected";

app.get("/api/users/:userId/files", 
  requireOwnershipOrAdmin("userId"), 
  (req, res) => {
    // User can only access their own files unless admin
    res.json({ files: [] });
  }
);
```

### Chaining Multiple Middleware

```typescript
import { protect, requireAuth, requireRole, UserRole } from "./protected";

app.put("/api/users/:id",
  protect(
    requireAuth,
    requireRole([UserRole.ADMIN, UserRole.MANAGER])
  ),
  (req, res) => {
    // Multiple middleware applied
    res.json({ message: "User updated" });
  }
);
```

### Optional Authentication

```typescript
import { optionalAuth } from "./protected";

app.get("/api/public", optionalAuth, (req, res) => {
  // Works with or without authentication
  const user = req.user;
  res.json({ 
    message: "Public endpoint",
    authenticated: !!user,
    user: user 
  });
});
```

## Integration with Existing Routes

To protect your existing AWS management routes:

```typescript
import { requireAuth, requireRole, UserRole } from "./protected";
import { registerRoutes } from "./routes";

// Protect AWS account routes
const awsRouter = express.Router();

awsRouter.get("/aws-accounts", requireAuth, async (req, res) => {
  // Existing logic...
});

// Protect admin functions
awsRouter.delete("/aws-accounts/:id", 
  requireAdmin, 
  async (req, res) => {
    // Existing logic...
  }
);

// Protect manager functions
awsRouter.post("/aws-accounts", 
  requireRole([UserRole.ADMIN, UserRole.MANAGER]), 
  async (req, res) => {
    // Existing logic...
  }
);

// Apply to main app
app.use("/api", awsRouter);
```

## Error Handling

The middleware returns standard HTTP status codes:

- `401 Unauthorized`: Missing or invalid token
- `403 Forbidden`: Insufficient permissions
- `500 Internal Server Error`: Server configuration issues

```typescript
// Example error responses
{ "message": "Authorization header is required" }
{ "message": "Invalid token" }
{ "message": "Insufficient permissions", "requiredRoles": ["admin"], "userRole": "user" }
```

## Security Best Practices

1. **Use strong JWT secrets**: Generate cryptographically secure keys
2. **Set appropriate expiration times**: Don't make tokens too long-lived
3. **Validate all inputs**: Always validate request data
4. **Use HTTPS in production**: Encrypt tokens in transit
5. **Implement rate limiting**: Prevent brute force attacks
6. **Monitor authentication**: Log auth events for security monitoring

## Troubleshooting

### Common Issues

1. **"JWT_SECRET environment variable is not set"**
   - Set the `JWT_SECRET` variable in your environment

2. **"Token expired"**
   - Generate a new token or refresh the existing one

3. **"Invalid token"**
   - Check token format: `Bearer <token>`
   - Verify JWT secret matches between signing and verification

4. **TypeScript errors**
   - Ensure `jsonwebtoken` and `@types/jsonwebtoken` are installed
   - Check that your TypeScript config includes proper type checking

## Migration from Existing Routes

To migrate existing unprotected routes:

1. Add authentication middleware: `requireAuth`
2. Add role requirements: `requireAdmin`, `requireRole()`, etc.
3. Update route handlers to use `req.user`
4. Test thoroughly with different user roles

See `protected-examples.ts` for complete examples.