# Audit Service Documentation

## Overview

The Audit Service provides comprehensive audit trail management for tracking and monitoring all system activities. This service offers robust logging, querying, analytics, and retention management capabilities.

## Features

### 1. Audit Log Creation and Storage
- Create detailed audit log entries with rich metadata
- Supports multiple status types: success, failure, pending
- Tracks severity levels: low, medium, high, critical
- Includes execution time tracking
- Captures user context, IP addresses, and user agents

### 2. Audit Log Querying and Filtering
- Advanced filtering by date ranges, users, actions, resources
- Full-text search across multiple fields
- Sortable results with pagination support
- Composite indexing for optimal query performance
- Support for multiple value arrays in filters

### 3. Audit Data Aggregation and Reporting
- Comprehensive analytics with success rates and user activity
- Top users, actions, and resources analysis
- Failure rate analysis by action
- Suspicious activity detection
- Custom breakdown calculations

### 4. Audit Retention Management
- Configurable retention policies per category
- Severity-based retention periods
- Automatic cleanup of expired logs
- Support for different retention policies by audit category
- Archive-ready architecture for long-term storage

### 5. Audit Export Functionality
- Export to JSON, CSV, and XML formats
- Configurable field inclusion (metadata, details)
- Timestamp-based filenames
- Large dataset support with pagination
- Properly escaped output for security

### 6. Audit Search Capabilities
- Full-text search across audit log fields
- Real-time search suggestions
- Search result ranking
- Index-optimized queries
- Support for complex search patterns

### 7. Audit Analytics and Trends
- Time-series trend analysis
- Daily and hourly activity patterns
- Success/failure trend tracking
- User behavior analysis
- Resource utilization patterns

## Database Schema

### audit_logs Table
```sql
- id: UUID (Primary Key)
- user_id: VARCHAR (Indexed)
- user_email: VARCHAR
- action: VARCHAR (Indexed)
- resource: VARCHAR (Indexed)
- resource_id: VARCHAR
- status: VARCHAR ('success' | 'failure' | 'pending') (Indexed)
- details: JSONB
- ip_address: VARCHAR
- user_agent: VARCHAR
- severity: VARCHAR ('low' | 'medium' | 'high' | 'critical') (Indexed)
- category: VARCHAR (Indexed)
- metadata: JSONB
- execution_time: INTEGER
- created_at: TIMESTAMP (Indexed)
- updated_at: TIMESTAMP
```

### audit_retention_config Table
```sql
- id: UUID (Primary Key)
- category: VARCHAR (Unique)
- retention_days: INTEGER
- severity_retention_days: JSONB
- is_active: BOOLEAN
- created_at: TIMESTAMP
- updated_at: TIMESTAMP
```

## Usage Examples

### Basic Usage

```typescript
import { auditService } from '../server/services/audit-service';

// Create audit log
await auditService.createAuditLog({
  userId: 'user-123',
  userEmail: 'user@example.com',
  action: 'user.login',
  resource: 'authentication',
  status: 'success',
  category: 'user',
  ipAddress: '192.168.1.1',
  userAgent: 'Mozilla/5.0...',
  details: { method: 'password', provider: 'local' }
});
```

### Querying Logs

```typescript
// Get recent login attempts
const loginLogs = await auditService.queryAuditLogs({
  action: 'user.login',
  startDate: new Date('2024-01-01'),
  endDate: new Date('2024-01-31'),
  sortBy: 'createdAt',
  sortOrder: 'desc',
  limit: 100
});

// Search logs
const searchResults = await auditService.searchAuditLogs('login failed', {
  startDate: new Date('2024-01-01'),
  limit: 50
});

// Complex filtering
const failedActions = await auditService.queryAuditLogs({
  status: 'failure',
  severity: ['high', 'critical'],
  userId: ['user-123', 'user-456'],
  limit: 1000
});
```

### Analytics and Reporting

```typescript
// Get comprehensive analytics
const analytics = await auditService.getAuditAnalytics({
  startDate: new Date('2024-01-01'),
  endDate: new Date('2024-01-31'),
  category: 'user'
});

console.log({
  totalEvents: analytics.totalEvents,
  successRate: analytics.successRate,
  topUsers: analytics.topUsers,
  suspiciousActivity: analytics.suspiciousActivity
});

// Get trends
const trends = await auditService.getAuditTrends({
  period: '7d',
  action: 'user.login'
});

console.log({
  dailyTrends: trends.dailyTrends,
  hourlyPatterns: trends.hourlyTrends,
  userActivity: trends.userActivity
});
```

### Exporting Data

```typescript
// Export to CSV
const csvExport = await auditService.exportAuditLogs({
  startDate: new Date('2024-01-01'),
  endDate: new Date('2024-01-31'),
  format: 'csv',
  includeDetails: false,
  includeMetadata: true
});

// Download the file
const blob = new Blob([csvExport.data], { type: csvExport.mimeType });
const url = URL.createObjectURL(blob);
const a = document.createElement('a');
a.href = url;
a.download = csvExport.filename;
a.click();

// Export to JSON
const jsonExport = await auditService.exportAuditLogs({
  format: 'json',
  status: 'failure'
});
```

### Retention Management

```typescript
// Configure retention policy
await auditService.configureRetentionPolicy({
  category: 'user',
  retentionDays: 90,
  severityRetentionDays: {
    critical: 365,
    high: 180,
    medium: 90,
    low: 30
  },
  isActive: true
});

// Get all retention policies
const policies = await auditService.getRetentionPolicies();

// Cleanup expired logs
const cleanupResult = await auditService.cleanupExpiredLogs();
console.log(`Deleted ${cleanupResult.deletedCount} expired audit logs`);
```

### Statistics Summary

```typescript
// Get quick statistics
const stats = await auditService.getAuditStatistics();

console.log({
  totalLogs: stats.totalLogs,
  todayLogs: stats.todayLogs,
  weekLogs: stats.weekLogs,
  successRate: stats.successRate,
  recentActivity: stats.recentActivity
});
```

## Best Practices

### 1. Log Creation
- Always include meaningful context in the `details` field
- Use consistent action naming conventions (e.g., 'resource.action')
- Set appropriate severity levels based on impact
- Include execution time for performance tracking

### 2. Query Performance
- Use date ranges to limit result sets
- Utilize indexes by filtering on indexed fields
- Implement pagination for large result sets
- Consider using search instead of multiple filters when appropriate

### 3. Data Retention
- Configure appropriate retention policies per category
- Set longer retention for critical/high severity events
- Regularly review and update retention policies
- Consider archiving rather than deleting for compliance

### 4. Security Considerations
- Sanitize sensitive data before logging
- Use appropriate access controls for audit data
- Implement audit log immutability for compliance
- Regular security reviews of audit access patterns

## Integration Points

### Middleware Integration
```typescript
// Express middleware example
const auditMiddleware = (req, res, next) => {
  const startTime = Date.now();
  
  res.on('finish', () => {
    auditService.createAuditLog({
      userId: req.user?.id || 'anonymous',
      userEmail: req.user?.email,
      action: `${req.method}.${req.route?.path || req.path}`,
      resource: 'api',
      status: res.statusCode < 400 ? 'success' : 'failure',
      category: 'api',
      ipAddress: req.ip,
      userAgent: req.get('User-Agent'),
      executionTime: Date.now() - startTime,
      details: {
        method: req.method,
        path: req.path,
        statusCode: res.statusCode,
        query: req.query,
        body: req.body
      }
    });
  });
  
  next();
};
```

### Database Integration
```typescript
// Register tables with database
import { auditLogs, auditRetentionConfig } from './audit-service';

// In your database initialization
await db.insert(auditLogs).values(/* ... */);
await db.insert(auditRetentionConfig).values(/* ... */);
```

## Monitoring and Alerting

### Key Metrics to Monitor
- Total audit logs per day/hour
- Success rate trends
- Failure rate by action
- User activity patterns
- Database query performance
- Storage usage trends

### Alerting Rules
- Sudden spikes in failure rates
- Unusual user activity patterns
- Suspicious IP address activity
- High database query times
- Storage usage approaching limits

## Performance Considerations

### Indexing Strategy
- Composite indexes for common query patterns
- Separate indexes for date ranges
- Index on status for filtering
- Full-text search optimization

### Query Optimization
- Limit result sets with pagination
- Use date range filters
- Leverage database query planning
- Consider materialized views for analytics

### Storage Management
- Implement automated cleanup
- Consider partitioning for large datasets
- Archive old data to cold storage
- Monitor storage growth trends

## Compliance and Auditing

### Data Protection
- Implement data encryption at rest
- Secure transmission of audit data
- Access logging for audit data itself
- Regular security assessments

### Regulatory Compliance
- Configure retention for compliance requirements
- Implement audit log immutability
- Regular audit of audit trail access
- Document data handling procedures

## Troubleshooting

### Common Issues
1. **Slow queries**: Check index usage and optimize filters
2. **High storage usage**: Review and adjust retention policies
3. **Missing logs**: Verify middleware integration and error handling
4. **Export timeouts**: Use pagination for large datasets

### Debug Mode
Enable debug logging for audit service:
```typescript
process.env.AUDIT_DEBUG = 'true';
```

## API Reference

### Core Methods

#### `createAuditLog(options)`
Creates a new audit log entry.

**Parameters:**
- `options: CreateAuditLogOptions`
  - `userId: string` (required)
  - `action: string` (required)
  - `resource: string` (required)
  - `status: 'success' | 'failure' | 'pending'` (required)
  - `category: string` (required)
  - `userEmail?: string`
  - `resourceId?: string`
  - `details?: Record<string, any>`
  - `ipAddress?: string`
  - `userAgent?: string`
  - `severity?: 'low' | 'medium' | 'high' | 'critical'`
  - `metadata?: Record<string, any>`
  - `executionTime?: number`

**Returns:** `Promise<AuditLog>`

#### `queryAuditLogs(options)`
Queries audit logs with filtering and pagination.

**Parameters:**
- `options: QueryAuditLogsOptions`
  - `startDate?: Date`
  - `endDate?: Date`
  - `userId?: string | string[]`
  - `action?: string | string[]`
  - `resource?: string | string[]`
  - `status?: 'success' | 'failure' | 'pending'`
  - `severity?: ('low' | 'medium' | 'high' | 'critical')[]`
  - `category?: string | string[]`
  - `ipAddress?: string`
  - `searchTerm?: string`
  - `limit?: number` (default: 100)
  - `offset?: number` (default: 0)
  - `sortBy?: 'createdAt' | 'userId' | 'action' | 'resource'` (default: 'createdAt')
  - `sortOrder?: 'asc' | 'desc'` (default: 'desc')

**Returns:** `Promise<AuditLog[]>`

#### `exportAuditLogs(options)`
Exports audit logs in various formats.

**Parameters:**
- `options: ExportAuditLogsOptions`
  - `format: 'json' | 'csv' | 'xml'` (required)
  - `startDate?: Date`
  - `endDate?: Date`
  - `userId?: string[]`
  - `action?: string[]`
  - `resource?: string[]`
  - `status?: 'success' | 'failure' | 'pending'`
  - `category?: string[]`
  - `includeMetadata?: boolean` (default: true)
  - `includeDetails?: boolean` (default: false)

**Returns:** `Promise<{ data: string; filename: string; mimeType: string; recordCount: number }>`

#### `getAuditAnalytics(options)`
Generates comprehensive audit analytics.

**Parameters:**
- `options: { startDate?: Date; endDate?: Date; category?: string }`

**Returns:** `Promise<AuditAnalytics>`

#### `getAuditTrends(options)`
Provides trend analysis for audit data.

**Parameters:**
- `options: { period: '1d' | '7d' | '30d' | '90d'; action?: string; resource?: string; category?: string }`

**Returns:** `Promise<AuditTrends>`

#### `cleanupExpiredLogs()`
Cleans up audit logs based on retention policies.

**Returns:** `Promise<{ deletedCount: number }>`

## Conclusion

The Audit Service provides a robust, scalable solution for comprehensive audit trail management. With its rich feature set, performance optimizations, and security considerations, it meets the requirements for enterprise-grade audit logging while maintaining flexibility for various use cases.

For questions or issues, please refer to the troubleshooting section or contact the development team.
