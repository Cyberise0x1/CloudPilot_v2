import { 
  EC2Client, 
  DescribeInstancesCommand,
  RunInstancesCommand,
  StartInstancesCommand,
  StopInstancesCommand,
  TerminateInstancesCommand,
  DescribeAccountAttributesCommand,
  DescribeRegionsCommand
} from "@aws-sdk/client-ec2";
import { 
  S3Client, 
  ListBucketsCommand,
  CreateBucketCommand,
  DeleteBucketCommand,
  PutObjectCommand,
  GetObjectCommand,
  ListObjectsV2Command,
  DeleteObjectCommand
} from "@aws-sdk/client-s3";
import { 
  RDSClient,
  DescribeDBInstancesCommand,
  CreateDBInstanceCommand,
  DeleteDBInstanceCommand,
  ModifyDBInstanceCommand,
  RebootDBInstanceCommand,
  StartDBInstanceCommand,
  StopDBInstanceCommand
} from "@aws-sdk/client-rds";
import { 
  CloudFrontClient,
  ListDistributionsCommand,
  CreateDistributionCommand,
  DeleteDistributionCommand,
  GetDistributionCommand,
  CreateInvalidationCommand,
  UpdateDistributionCommand
} from "@aws-sdk/client-cloudfront";
import {
  AllocateAddressCommand,
  ReleaseAddressCommand,
  AssociateAddressCommand,
  DisassociateAddressCommand,
  DescribeAddressesCommand,
  GetPasswordDataCommand,
  CreateTagsCommand,
  DescribeVolumesCommand,
  DescribeNetworkInterfacesCommand,
  DescribeSecurityGroupsCommand
} from "@aws-sdk/client-ec2";
import { ViewerProtocolPolicy } from "@aws-sdk/client-cloudfront";
import type { LaunchInstanceRequest, CreateS3BucketRequest, CreateRdsInstanceRequest, CreateCloudFrontDistributionRequest } from "@shared/schema";
import { secretsManager } from "../secrets-manager";

/**
 * AWS Service - Updated to use Environment Variables
 * 
 * This service now supports both environment variables and parameter-based credentials for maximum flexibility.
 * 
 * Environment Variables (Recommended):
 * - AWS_ACCESS_KEY_ID: Your AWS access key ID
 * - AWS_SECRET_ACCESS_KEY: Your AWS secret access key
 * - AWS_REGION: Your AWS region (default: us-east-1)
 * 
 * Usage Examples:
 * 
 * 1. Using environment variables (recommended):
 *    ```typescript
 *    process.env.AWS_ACCESS_KEY_ID = 'your-access-key';
 *    process.env.AWS_SECRET_ACCESS_KEY = 'your-secret-key';
 *    process.env.AWS_REGION = 'us-west-2';
 *    
 *    // Call methods without credentials parameter
 *    await awsService.listInstances();
 *    await awsService.listS3Buckets();
 *    ```
 * 
 * 2. Using credentials as parameters (backward compatibility):
 *    ```typescript
 *    await awsService.listInstances(
 *      'access-key',
 *      'secret-key',
 *      'us-west-2'
 *    );
 *    ```
 * 
 * 3. Mixed usage:
 *    ```typescript
 *    // Environment credentials with custom region
 *    await awsService.listInstances(undefined, undefined, 'eu-west-1');
 *    ```
 * 
 * 4. Check configuration status:
 *    ```typescript
 *    const status = AwsService.getConfigStatus();
 *    console.log(status);
 *    ```
 * 
 * Configuration Validation:
 * - The service validates credentials on instantiation
 * - Use AwsService.checkEnvironmentVariables() to check if env vars are set
 * - Use AwsService.getConfigStatus() for detailed configuration info
 * - The validateCredentials() method returns detailed validation results
 * 
 * Backward Compatibility:
 * - All existing code using parameter-based credentials continues to work
 * - Methods accept optional parameters (accessKeyId?, secretAccessKey?, region?)
 * - Environment variables are used as fallback when parameters are not provided
 * 
 * Security Best Practices:
 * - Never hardcode credentials in source code
 * - Use environment variables or AWS credential files
 * - Consider using AWS IAM roles for production environments
 * - Rotate credentials regularly
 */

class AwsService {
  // Static method to check if required environment variables are set
  static checkEnvironmentVariables() {
    const accessKey = secretsManager.getSecret('AWS_ACCESS_KEY_ID');
    const secretKey = secretsManager.getSecret('AWS_SECRET_ACCESS_KEY');
    
    const missingVars: string[] = [];
    if (!accessKey) missingVars.push('AWS_ACCESS_KEY_ID');
    if (!secretKey) missingVars.push('AWS_SECRET_ACCESS_KEY');
    
    if (missingVars.length > 0) {
      return {
        configured: false,
        missingVariables: missingVars,
        message: `Missing required environment variables: ${missingVars.join(', ')}`,
      };
    }
    
    return {
      configured: true,
      message: 'All required AWS environment variables are configured',
    };
  }
  
  // Static method to get a formatted configuration status
  static getConfigStatus() {
    const envStatus = this.checkEnvironmentVariables();
    return {
      environment: {
        hasCredentials: !!secretsManager.getSecret('AWS_ACCESS_KEY_ID') && !!secretsManager.getSecret('AWS_SECRET_ACCESS_KEY'),
        hasRegion: !!secretsManager.getSecret('AWS_REGION'),
        region: secretsManager.getSecret('AWS_REGION') || 'us-east-1',
        configured: envStatus.configured,
      },
      message: envStatus.message,
    };
  }

  constructor() {
    // Check environment variables on instantiation
    const status = AwsService.checkEnvironmentVariables();
    if (status.configured) {
      console.log('✓ AWS service initialized with secrets manager credentials');
    } else {
      console.warn(`⚠ ${status.message}`);
      console.warn('  Methods can still accept credentials as parameters for backward compatibility');
    }
  }

  private getCredentials(accessKeyId?: string, secretAccessKey?: string) {
    // Use provided credentials or fall back to secrets manager
    const accessKey = accessKeyId || secretsManager.getSecret('AWS_ACCESS_KEY_ID');
    const secretKey = secretAccessKey || secretsManager.getSecret('AWS_SECRET_ACCESS_KEY');
    
    if (!accessKey || !secretKey) {
      throw new Error(
        'AWS credentials not found. Please configure AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY in the secrets manager or provide credentials as parameters.'
      );
    }
    
    return {
      accessKeyId: accessKey,
      secretAccessKey: secretKey,
    };
  }
  
  private getRegion(region?: string): string {
    return region || secretsManager.getSecret('AWS_REGION') || 'us-east-1';
  }
  
  private ensureValidCredentials(credentials: { accessKeyId: string; secretAccessKey: string }) {
    if (!credentials.accessKeyId || !credentials.secretAccessKey) {
      throw new Error('Invalid AWS credentials: accessKeyId and secretAccessKey are required');
    }
  }

  private createEC2Client(accessKeyId?: string, secretAccessKey?: string, region?: string) {
    const credentials = this.getCredentials(accessKeyId, secretAccessKey);
    this.ensureValidCredentials(credentials);
    const resolvedRegion = this.getRegion(region);
    
    return new EC2Client({
      region: resolvedRegion,
      credentials: {
        accessKeyId: credentials.accessKeyId,
        secretAccessKey: credentials.secretAccessKey,
      },
    });
  }

  private createS3Client(accessKeyId?: string, secretAccessKey?: string, region?: string) {
    const credentials = this.getCredentials(accessKeyId, secretAccessKey);
    this.ensureValidCredentials(credentials);
    const resolvedRegion = this.getRegion(region);
    
    return new S3Client({
      region: resolvedRegion,
      credentials: {
        accessKeyId: credentials.accessKeyId,
        secretAccessKey: credentials.secretAccessKey,
      },
    });
  }

  private createRDSClient(accessKeyId?: string, secretAccessKey?: string, region?: string) {
    const credentials = this.getCredentials(accessKeyId, secretAccessKey);
    this.ensureValidCredentials(credentials);
    const resolvedRegion = this.getRegion(region);
    
    return new RDSClient({
      region: resolvedRegion,
      credentials: {
        accessKeyId: credentials.accessKeyId,
        secretAccessKey: credentials.secretAccessKey,
      },
    });
  }

  private createCloudFrontClient(accessKeyId?: string, secretAccessKey?: string) {
    // CloudFront is a global service, so no region is needed
    const credentials = this.getCredentials(accessKeyId, secretAccessKey);
    this.ensureValidCredentials(credentials);
    
    return new CloudFrontClient({
      region: "us-east-1", // Global service, region doesn't matter
      credentials: {
        accessKeyId: credentials.accessKeyId,
        secretAccessKey: credentials.secretAccessKey,
      },
    });
  }

  async validateCredentials(accessKeyId?: string, secretAccessKey?: string): Promise<{
    valid: boolean;
    source: string;
    hasEnvCredentials?: boolean;
    error?: string;
  }> {
    try {
      // Validate that secrets manager has credentials available
      const envAccessKey = secretsManager.getSecret('AWS_ACCESS_KEY_ID');
      const envSecretKey = secretsManager.getSecret('AWS_SECRET_ACCESS_KEY');
      
      // If credentials are provided, validate them
      // If not, validate environment variables via secrets manager
      const credentials = this.getCredentials(accessKeyId, secretAccessKey);
      
      const client = this.createEC2Client(credentials.accessKeyId, credentials.secretAccessKey, "us-east-1");
      await client.send(new DescribeRegionsCommand({}));
      
      return {
        valid: true,
        source: accessKeyId && secretAccessKey ? 'parameters' : 'secrets-manager',
        hasEnvCredentials: !!(envAccessKey && envSecretKey),
      };
    } catch (error) {
      console.error("AWS credentials validation failed:", error);
      return {
        valid: false,
        source: accessKeyId && secretAccessKey ? 'parameters' : 'secrets-manager',
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  }

  async listInstances(accessKeyId?: string, secretAccessKey?: string, region?: string) {
    const client = this.createEC2Client(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new DescribeInstancesCommand({});
      const response = await client.send(command);
      
      const instances: any[] = [];
      for (const reservation of response.Reservations || []) {
        for (const instance of reservation.Instances || []) {
          instances.push(instance);
        }
      }
      
      return instances;
    } catch (error) {
      console.error("Failed to list instances:", error);
      throw new Error(`Failed to list instances: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async launchInstance(
    accessKeyId: string | undefined, 
    secretAccessKey: string | undefined, 
    params: LaunchInstanceRequest
  ) {
    const client = this.createEC2Client(accessKeyId, secretAccessKey, params.region);
    
    try {
      const runParams: any = {
        ImageId: params.imageId,
        InstanceType: params.instanceType,
        MinCount: params.amount || 1,
        MaxCount: params.amount || 1,
      };

      // Add user data if provided
      if (params.userData) {
        runParams.UserData = Buffer.from(params.userData).toString('base64');
      }

      // Configure authentication
      if (params.authMode === 'key' && params.keyName) {
        runParams.KeyName = params.keyName;
      }

      // Add spot instance configuration if requested
      if (params.isSpotInstance) {
        runParams.InstanceMarketOptions = {
          MarketType: 'spot',
          SpotOptions: params.spotMaxPrice ? {
            MaxPrice: params.spotMaxPrice,
            SpotInstanceType: 'one-time',
            InstanceInterruptionBehavior: 'terminate'
          } : undefined
        };
      }

      // Configure storage
      if (params.diskSize) {
        runParams.BlockDeviceMappings = [{
          DeviceName: '/dev/sda1',
          Ebs: {
            VolumeSize: params.diskSize,
            VolumeType: 'gp3',
            DeleteOnTermination: true,
          },
        }];
      }

      // Configure network settings
      if (params.securityGroups && params.securityGroups.length > 0) {
        runParams.SecurityGroupIds = params.securityGroups;
      }

      if (params.subnetId) {
        runParams.SubnetId = params.subnetId;
      }

      if (params.publicIpAddress !== undefined) {
        runParams.NetworkInterfaces = [{
          DeviceIndex: 0,
          AssociatePublicIpAddress: params.publicIpAddress,
          SubnetId: params.subnetId,
          Groups: params.securityGroups,
        }];
      }

      // Enable monitoring if requested
      if (params.monitoring) {
        runParams.Monitoring = { Enabled: true };
      }

      // Enable EBS optimization if requested
      if (params.ebsOptimized) {
        runParams.EbsOptimized = true;
      }

      // Add tags
      const tags: any[] = [];
      if (params.instanceName) {
        tags.push({ Key: 'Name', Value: params.instanceName });
      }
      if (params.tags) {
        Object.entries(params.tags).forEach(([key, value]) => {
          tags.push({ Key: key, Value: value });
        });
      }
      if (tags.length > 0) {
        runParams.TagSpecifications = [{
          ResourceType: 'instance',
          Tags: tags,
        }];
      }

      // Handle IPv6 if requested
      if (params.enableIpv6) {
        runParams.Ipv6AddressCount = 1;
      }

      const command = new RunInstancesCommand(runParams);
      const response = await client.send(command);
      
      return {
        instanceIds: response.Instances?.map(instance => instance.InstanceId) || [],
        success: true,
      };
    } catch (error) {
      console.error("Failed to launch instance:", error);
      throw new Error(`Failed to launch instance: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async startInstance(
    accessKeyId: string | undefined, 
    secretAccessKey: string | undefined, 
    region: string | undefined, 
    instanceId: string
  ) {
    const client = this.createEC2Client(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new StartInstancesCommand({
        InstanceIds: [instanceId],
      });
      const response = await client.send(command);
      return response;
    } catch (error) {
      console.error("Failed to start instance:", error);
      throw new Error(`Failed to start instance: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async stopInstance(
    accessKeyId: string | undefined, 
    secretAccessKey: string | undefined, 
    region: string | undefined, 
    instanceId: string
  ) {
    const client = this.createEC2Client(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new StopInstancesCommand({
        InstanceIds: [instanceId],
      });
      const response = await client.send(command);
      return response;
    } catch (error) {
      console.error("Failed to stop instance:", error);
      throw new Error(`Failed to stop instance: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async terminateInstance(
    accessKeyId: string | undefined, 
    secretAccessKey: string | undefined, 
    region: string | undefined, 
    instanceId: string
  ) {
    const client = this.createEC2Client(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new TerminateInstancesCommand({
        InstanceIds: [instanceId],
      });
      const response = await client.send(command);
      return response;
    } catch (error) {
      console.error("Failed to terminate instance:", error);
      throw new Error(`Failed to terminate instance: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // Generate mock traffic data
  generateMockTrafficData() {
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    const inboundValue = Math.random() * 1000;
    const outboundValue = Math.random() * 1000;
    
    const formatTraffic = (value: number) => {
      let unitIndex = 0;
      while (value > 1024 && unitIndex < units.length - 1) {
        value /= 1024;
        unitIndex++;
      }
      return `${value.toFixed(1)} ${units[unitIndex]}`;
    };
    
    return {
      inbound: formatTraffic(inboundValue * 1024 * 1024), // Convert to bytes
      outbound: formatTraffic(outboundValue * 1024 * 1024),
    };
  }

  async allocateElasticIp(accessKeyId?: string, secretAccessKey?: string, region?: string) {
    const client = this.createEC2Client(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new AllocateAddressCommand({
        Domain: "vpc",
      });
      const response = await client.send(command);
      return response;
    } catch (error) {
      console.error("Failed to allocate Elastic IP:", error);
      throw new Error(`Failed to allocate Elastic IP: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async releaseElasticIp(allocationId: string, accessKeyId?: string, secretAccessKey?: string, region?: string) {
    const client = this.createEC2Client(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new ReleaseAddressCommand({
        AllocationId: allocationId,
      });
      const response = await client.send(command);
      return response;
    } catch (error) {
      console.error("Failed to release Elastic IP:", error);
      throw new Error(`Failed to release Elastic IP: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async associateElasticIp(instanceId: string, allocationId: string, accessKeyId?: string, secretAccessKey?: string, region?: string) {
    const client = this.createEC2Client(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new AssociateAddressCommand({
        InstanceId: instanceId,
        AllocationId: allocationId,
      });
      const response = await client.send(command);
      return response;
    } catch (error) {
      console.error("Failed to associate Elastic IP:", error);
      throw new Error(`Failed to associate Elastic IP: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async disassociateElasticIp(associationId: string, accessKeyId?: string, secretAccessKey?: string, region?: string) {
    const client = this.createEC2Client(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new DisassociateAddressCommand({
        AssociationId: associationId,
      });
      const response = await client.send(command);
      return response;
    } catch (error) {
      console.error("Failed to disassociate Elastic IP:", error);
      throw new Error(`Failed to disassociate Elastic IP: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async listElasticIps(accessKeyId?: string, secretAccessKey?: string, region?: string) {
    const client = this.createEC2Client(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new DescribeAddressesCommand({});
      const response = await client.send(command);
      return response.Addresses || [];
    } catch (error) {
      console.error("Failed to list Elastic IPs:", error);
      throw new Error(`Failed to list Elastic IPs: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getWindowsPassword(instanceId: string, accessKeyId?: string, secretAccessKey?: string, region?: string) {
    const client = this.createEC2Client(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new GetPasswordDataCommand({
        InstanceId: instanceId,
      });
      const response = await client.send(command);
      return {
        passwordData: response.PasswordData,
        timestamp: response.Timestamp,
      };
    } catch (error) {
      console.error("Failed to get Windows password:", error);
      throw new Error(`Failed to get Windows password: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async tagInstances(instanceIds: string[], tags: Record<string, string>, accessKeyId?: string, secretAccessKey?: string, region?: string) {
    const client = this.createEC2Client(accessKeyId, secretAccessKey, region);
    
    try {
      const tagsList = Object.entries(tags).map(([key, value]) => ({
        Key: key,
        Value: value,
      }));
      
      const command = new CreateTagsCommand({
        Resources: instanceIds,
        Tags: tagsList,
      });
      const response = await client.send(command);
      return response;
    } catch (error) {
      console.error("Failed to tag instances:", error);
      throw new Error(`Failed to tag instances: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async rotateInstanceIp(instanceId: string, accessKeyId?: string, secretAccessKey?: string, region?: string) {
    // For instances with elastic IPs, disassociate and release old IP, then allocate and associate new one
    // For instances with public IPs, this would require stopping and starting the instance
    const client = this.createEC2Client(accessKeyId, secretAccessKey, region);
    
    try {
      // First check if instance has an elastic IP
      const addressesCommand = new DescribeAddressesCommand({
        Filters: [
          {
            Name: "instance-id",
            Values: [instanceId],
          },
        ],
      });
      const addresses = await client.send(addressesCommand);
      
      if (addresses.Addresses && addresses.Addresses.length > 0) {
        // Has elastic IP, rotate it
        const oldAddress = addresses.Addresses[0];
        const associationId = oldAddress.AssociationId;
        const allocationId = oldAddress.AllocationId;
        
        // Disassociate old IP
        if (associationId) {
          await client.send(new DisassociateAddressCommand({ AssociationId: associationId }));
        }
        
        // Release old IP
        if (allocationId) {
          await client.send(new ReleaseAddressCommand({ AllocationId: allocationId }));
        }
        
        // Allocate new IP
        const newAddress = await client.send(new AllocateAddressCommand({ Domain: "vpc" }));
        
        // Associate new IP
        if (newAddress.AllocationId) {
          await client.send(new AssociateAddressCommand({
            InstanceId: instanceId,
            AllocationId: newAddress.AllocationId,
          }));
        }
        
        return {
          oldIp: oldAddress.PublicIp,
          newIp: newAddress.PublicIp,
        };
      } else {
        // No elastic IP, need to stop and start instance to get new public IP
        await this.stopInstance(accessKeyId, secretAccessKey, region, instanceId);
        
        // Wait a bit for instance to stop
        await new Promise(resolve => setTimeout(resolve, 5000));
        
        await this.startInstance(accessKeyId, secretAccessKey, region, instanceId);
        
        return {
          message: "Instance restarted to rotate IP. New IP will be assigned.",
        };
      }
    } catch (error) {
      console.error("Failed to rotate IP:", error);
      throw new Error(`Failed to rotate IP: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async getInstanceDetails(instanceId: string, accessKeyId?: string, secretAccessKey?: string, region?: string) {
    const client = this.createEC2Client(accessKeyId, secretAccessKey, region);
    
    try {
      // Get instance details
      const instanceCommand = new DescribeInstancesCommand({
        InstanceIds: [instanceId],
      });
      const instanceResponse = await client.send(instanceCommand);
      const instance = instanceResponse.Reservations?.[0]?.Instances?.[0];
      
      if (!instance) {
        throw new Error("Instance not found");
      }
      
      // Get volumes
      const volumeIds = instance.BlockDeviceMappings?.map(bdm => bdm.Ebs?.VolumeId).filter(Boolean) || [];
      let volumes: any[] = [];
      if (volumeIds.length > 0) {
        const volumesCommand = new DescribeVolumesCommand({
          VolumeIds: volumeIds as string[],
        });
        const volumesResponse = await client.send(volumesCommand);
        volumes = volumesResponse.Volumes || [];
      }
      
      // Get security groups details
      const sgIds = instance.SecurityGroups?.map(sg => sg.GroupId).filter(Boolean) || [];
      let securityGroups: any[] = [];
      if (sgIds.length > 0) {
        const sgCommand = new DescribeSecurityGroupsCommand({
          GroupIds: sgIds as string[],
        });
        const sgResponse = await client.send(sgCommand);
        securityGroups = sgResponse.SecurityGroups || [];
      }
      
      return {
        instance,
        volumes,
        securityGroups,
        networkInterfaces: instance.NetworkInterfaces || [],
      };
    } catch (error) {
      console.error("Failed to get instance details:", error);
      throw new Error(`Failed to get instance details: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async checkQuota(accessKeyId?: string, secretAccessKey?: string, region?: string) {
    const client = this.createEC2Client(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new DescribeAccountAttributesCommand({});
      const response = await client.send(command);
      
      // Extract relevant quota information
      const quotas: any = {};
      for (const attribute of response.AccountAttributes || []) {
        if (attribute.AttributeName?.includes('max-instances')) {
          quotas[attribute.AttributeName] = {
            values: attribute.AttributeValues?.map(v => v.AttributeValue) || [],
          };
        }
      }
      
      // Return simplified quota info
      return {
        ec2Instances: 0,
        ec2Limit: quotas['max-instances']?.values?.[0] || 20,
      };
    } catch (error) {
      console.error("Failed to check quota:", error);
      throw new Error(`Failed to check quota: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async checkRegionAccess(accessKeyId?: string, secretAccessKey?: string, region?: string) {
    try {
      const client = this.createEC2Client(accessKeyId, secretAccessKey, region);
      await client.send(new DescribeRegionsCommand({}));
      return { accessible: true, region: this.getRegion(region) };
    } catch (error) {
      console.error("Failed to access region:", error);
      return { 
        accessible: false, 
        region: this.getRegion(region), 
        error: error instanceof Error ? error.message : 'Unknown error' 
      };
    }
  }

  // S3 Methods
  async listS3Buckets(accessKeyId?: string, secretAccessKey?: string) {
    const client = this.createS3Client(accessKeyId, secretAccessKey, "us-east-1");
    
    try {
      const command = new ListBucketsCommand({});
      const response = await client.send(command);
      return response.Buckets || [];
    } catch (error) {
      console.error("Failed to list S3 buckets:", error);
      throw new Error(`Failed to list S3 buckets: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async createS3Bucket(accessKeyId: string | undefined, secretAccessKey: string | undefined, params: CreateS3BucketRequest) {
    const client = this.createS3Client(accessKeyId, secretAccessKey, params.region);
    
    try {
      const createParams: any = {
        Bucket: params.bucketName,
      };

      // Add location constraint if not us-east-1
      if (params.region !== "us-east-1") {
        createParams.CreateBucketConfiguration = {
          LocationConstraint: params.region,
        };
      }

      const command = new CreateBucketCommand(createParams);
      const response = await client.send(command);
      return {
        success: true,
        location: response.Location,
      };
    } catch (error) {
      console.error("Failed to create S3 bucket:", error);
      throw new Error(`Failed to create S3 bucket: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async deleteS3Bucket(bucketName: string, region?: string, accessKeyId?: string, secretAccessKey?: string) {
    const client = this.createS3Client(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new DeleteBucketCommand({
        Bucket: bucketName,
      });
      await client.send(command);
      return { success: true };
    } catch (error) {
      console.error("Failed to delete S3 bucket:", error);
      throw new Error(`Failed to delete S3 bucket: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async listS3Objects(bucketName: string, region?: string, accessKeyId?: string, secretAccessKey?: string) {
    const client = this.createS3Client(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new ListObjectsV2Command({
        Bucket: bucketName,
      });
      const response = await client.send(command);
      return response.Contents || [];
    } catch (error) {
      console.error("Failed to list S3 objects:", error);
      throw new Error(`Failed to list S3 objects: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async uploadS3Object(bucketName: string, key: string, body: Buffer, region?: string, accessKeyId?: string, secretAccessKey?: string) {
    const client = this.createS3Client(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new PutObjectCommand({
        Bucket: bucketName,
        Key: key,
        Body: body,
      });
      await client.send(command);
      return { success: true, key };
    } catch (error) {
      console.error("Failed to upload S3 object:", error);
      throw new Error(`Failed to upload S3 object: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async downloadS3Object(bucketName: string, key: string, region?: string, accessKeyId?: string, secretAccessKey?: string) {
    const client = this.createS3Client(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new GetObjectCommand({
        Bucket: bucketName,
        Key: key,
      });
      const response = await client.send(command);
      
      // Convert the stream to buffer and then to base64
      const chunks = [];
      const stream = response.Body as any;
      for await (const chunk of stream) {
        chunks.push(chunk);
      }
      const buffer = Buffer.concat(chunks);
      const base64Content = buffer.toString('base64');
      
      return { 
        success: true, 
        content: base64Content,
        contentType: response.ContentType,
        contentLength: response.ContentLength
      };
    } catch (error) {
      console.error("Failed to download S3 object:", error);
      throw new Error(`Failed to download S3 object: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async deleteS3Object(bucketName: string, key: string, region?: string, accessKeyId?: string, secretAccessKey?: string) {
    const client = this.createS3Client(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new DeleteObjectCommand({
        Bucket: bucketName,
        Key: key,
      });
      await client.send(command);
      return { success: true };
    } catch (error) {
      console.error("Failed to delete S3 object:", error);
      throw new Error(`Failed to delete S3 object: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // RDS methods
  async listRdsInstances(accessKeyId?: string, secretAccessKey?: string, region?: string) {
    const client = this.createRDSClient(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new DescribeDBInstancesCommand({});
      const response = await client.send(command);
      
      return response.DBInstances || [];
    } catch (error) {
      console.error("Failed to list RDS instances:", error);
      throw new Error(`Failed to list RDS instances: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async createRdsInstance(accessKeyId: string | undefined, secretAccessKey: string | undefined, request: CreateRdsInstanceRequest) {
    const client = this.createRDSClient(accessKeyId, secretAccessKey, request.region);
    
    try {
      const command = new CreateDBInstanceCommand({
        DBInstanceIdentifier: request.dbInstanceIdentifier,
        DBInstanceClass: request.dbInstanceClass,
        Engine: request.engine,
        EngineVersion: request.engineVersion,
        MasterUsername: request.masterUsername,
        MasterUserPassword: request.masterUserPassword,
        AllocatedStorage: request.allocatedStorage,
        StorageType: request.storageType,
        StorageEncrypted: request.storageEncrypted,
        VpcSecurityGroupIds: request.vpcSecurityGroupIds,
        DBSubnetGroupName: request.dbSubnetGroupName,
        MultiAZ: request.multiAz,
        PubliclyAccessible: request.publiclyAccessible,
      });
      
      const response = await client.send(command);
      return response.DBInstance;
    } catch (error) {
      console.error("Failed to create RDS instance:", error);
      throw new Error(`Failed to create RDS instance: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async deleteRdsInstance(dbInstanceIdentifier: string, region?: string, accessKeyId?: string, secretAccessKey?: string) {
    const client = this.createRDSClient(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new DeleteDBInstanceCommand({
        DBInstanceIdentifier: dbInstanceIdentifier,
        SkipFinalSnapshot: true, // For quick deletion - in production you may want a final snapshot
      });
      
      const response = await client.send(command);
      return response.DBInstance;
    } catch (error) {
      console.error("Failed to delete RDS instance:", error);
      throw new Error(`Failed to delete RDS instance: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async startRdsInstance(dbInstanceIdentifier: string, region?: string, accessKeyId?: string, secretAccessKey?: string) {
    const client = this.createRDSClient(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new StartDBInstanceCommand({
        DBInstanceIdentifier: dbInstanceIdentifier,
      });
      
      const response = await client.send(command);
      return response.DBInstance;
    } catch (error) {
      console.error("Failed to start RDS instance:", error);
      throw new Error(`Failed to start RDS instance: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async stopRdsInstance(dbInstanceIdentifier: string, region?: string, accessKeyId?: string, secretAccessKey?: string) {
    const client = this.createRDSClient(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new StopDBInstanceCommand({
        DBInstanceIdentifier: dbInstanceIdentifier,
      });
      
      const response = await client.send(command);
      return response.DBInstance;
    } catch (error) {
      console.error("Failed to stop RDS instance:", error);
      throw new Error(`Failed to stop RDS instance: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async rebootRdsInstance(dbInstanceIdentifier: string, region?: string, accessKeyId?: string, secretAccessKey?: string) {
    const client = this.createRDSClient(accessKeyId, secretAccessKey, region);
    
    try {
      const command = new RebootDBInstanceCommand({
        DBInstanceIdentifier: dbInstanceIdentifier,
      });
      
      const response = await client.send(command);
      return response.DBInstance;
    } catch (error) {
      console.error("Failed to reboot RDS instance:", error);
      throw new Error(`Failed to reboot RDS instance: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // CloudFront methods
  async listCloudFrontDistributions(accessKeyId?: string, secretAccessKey?: string) {
    const client = this.createCloudFrontClient(accessKeyId, secretAccessKey);
    
    try {
      const command = new ListDistributionsCommand({});
      const response = await client.send(command);
      
      return response.DistributionList?.Items || [];
    } catch (error) {
      console.error("Failed to list CloudFront distributions:", error);
      throw new Error(`Failed to list CloudFront distributions: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async createCloudFrontDistribution(accessKeyId: string | undefined, secretAccessKey: string | undefined, request: CreateCloudFrontDistributionRequest) {
    const client = this.createCloudFrontClient(accessKeyId, secretAccessKey);
    
    try {
      // Prepare distribution config
      const origins = request.origins.map(origin => ({
        Id: origin.id,
        DomainName: origin.domainName,
        OriginPath: origin.originPath || "",
        CustomOriginConfig: origin.customOriginConfig ? {
          HTTPPort: origin.customOriginConfig.httpPort,
          HTTPSPort: origin.customOriginConfig.httpsPort,
          OriginProtocolPolicy: origin.customOriginConfig.originProtocolPolicy,
          OriginSslProtocols: {
            Quantity: origin.customOriginConfig.originSslProtocols.length,
            Items: origin.customOriginConfig.originSslProtocols,
          },
        } : undefined,
      }));

      const distributionConfig = {
        CallerReference: request.callerReference,
        Comment: request.comment || "",
        Enabled: request.enabled,
        PriceClass: request.priceClass,
        DefaultRootObject: request.defaultRootObject || "",
        Origins: {
          Quantity: origins.length,
          Items: origins,
        },
        DefaultCacheBehavior: {
          TargetOriginId: origins[0].Id,
          ViewerProtocolPolicy: ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
          TrustedSigners: {
            Enabled: false,
            Quantity: 0,
            Items: [],
          },
          ForwardedValues: {
            QueryString: false,
            Cookies: {
              Forward: "none",
            },
            Headers: {
              Quantity: 0,
              Items: [],
            },
            QueryStringCacheKeys: {
              Quantity: 0,
              Items: [],
            },
          },
          MinTTL: 0,
          DefaultTTL: 86400,
          MaxTTL: 31536000,
        },
      };

      const command = new CreateDistributionCommand({
        DistributionConfig: distributionConfig,
      });
      
      const response = await client.send(command);
      return response.Distribution;
    } catch (error) {
      console.error("Failed to create CloudFront distribution:", error);
      throw new Error(`Failed to create CloudFront distribution: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async deleteCloudFrontDistribution(distributionId: string, accessKeyId?: string, secretAccessKey?: string) {
    const client = this.createCloudFrontClient(accessKeyId, secretAccessKey);
    
    try {
      // First get the distribution to get the ETag
      const getCommand = new GetDistributionCommand({
        Id: distributionId,
      });
      const getResponse = await client.send(getCommand);
      
      if (!getResponse.ETag) {
        throw new Error("Failed to get distribution ETag");
      }

      // First, disable the distribution if it's enabled
      if (getResponse.Distribution?.DistributionConfig?.Enabled) {
        const updateConfig = {
          ...getResponse.Distribution.DistributionConfig,
          Enabled: false,
        };

        const updateCommand = new UpdateDistributionCommand({
          Id: distributionId,
          DistributionConfig: updateConfig,
          IfMatch: getResponse.ETag,
        });

        const updateResponse = await client.send(updateCommand);
        
        // Wait for the distribution to be deployed before deletion
        // In a real implementation, you would poll the distribution status
        // For now, we'll return success and let AWS handle the eventual deletion
        return { message: "Distribution disabled. Wait for deployment to complete before deletion." };
      }

      // If already disabled, attempt to delete
      const deleteCommand = new DeleteDistributionCommand({
        Id: distributionId,
        IfMatch: getResponse.ETag,
      });
      
      await client.send(deleteCommand);
      return { message: "Distribution deletion initiated" };
    } catch (error) {
      console.error("Failed to delete CloudFront distribution:", error);
      throw new Error(`Failed to delete CloudFront distribution: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  async createCloudFrontInvalidation(distributionId: string, paths: string[], accessKeyId?: string, secretAccessKey?: string) {
    const client = this.createCloudFrontClient(accessKeyId, secretAccessKey);
    
    try {
      const command = new CreateInvalidationCommand({
        DistributionId: distributionId,
        InvalidationBatch: {
          CallerReference: Date.now().toString(),
          Paths: {
            Quantity: paths.length,
            Items: paths,
          },
        },
      });
      
      const response = await client.send(command);
      return response.Invalidation;
    } catch (error) {
      console.error("Failed to create CloudFront invalidation:", error);
      throw new Error(`Failed to create CloudFront invalidation: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }
}

export const awsService = new AwsService();
