import { pgTable, text, timestamp, json, varchar, integer, index, boolean } from "drizzle-orm/pg-core";
import { sql, desc, asc, and, gte, lte, ilike, inArray, eq } from "drizzle-orm";
import { db } from "../db";

/**
 * Audit Service - Comprehensive Audit Trail Management
 * 
 * This service provides comprehensive audit trail management including:
 * - Audit log creation and storage
 * - Audit log querying and filtering
 * - Audit data aggregation and reporting
 * - Audit retention management
 * - Audit export functionality
 * - Audit search capabilities
 * - Audit analytics and trends
 * 
 * Usage Examples:
 * 
 * 1. Creating audit logs:
 *    ```typescript
 *    await auditService.createAuditLog({
 *      userId: 'user-123',
 *      action: 'user.login',
 *      resource: 'authentication',
 *      details: { ip: '192.168.1.1', userAgent: 'Chrome' }
 *    });
 *    ```
 * 
 * 2. Querying audit logs:
 *    ```typescript
 *    const logs = await auditService.queryAuditLogs({
 *      startDate: new Date('2024-01-01'),
 *      endDate: new Date('2024-01-31'),
 *      userId: 'user-123',
 *      action: 'user.login'
 *    });
 *    ```
 * 
 * 3. Exporting audit logs:
 *    ```typescript
 *    const exportData = await auditService.exportAuditLogs({
 *      startDate: new Date('2024-01-01'),
 *      endDate: new Date('2024-01-31'),
 *      format: 'csv'
 *    });
 *    ```
 * 
 * 4. Getting analytics and trends:
 *    ```typescript
 *    const trends = await auditService.getAuditTrends({
 *      period: '7d',
 *      action: 'user.login'
 *    });
 *    ```
 */

// Define audit table schema
export const auditLogs = pgTable("audit_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull(),
  userEmail: varchar("user_email"),
  action: varchar("action").notNull(),
  resource: varchar("resource").notNull(),
  resourceId: varchar("resource_id"),
  status: varchar("status").notNull().$type<'success' | 'failure' | 'pending'>(),
  details: json("details").$type<Record<string, any>>(),
  ipAddress: varchar("ip_address"),
  userAgent: varchar("user_agent"),
  severity: varchar("severity").notNull().$type<'low' | 'medium' | 'high' | 'critical'>().default('medium'),
  category: varchar("category").notNull(),
  metadata: json("metadata").$type<Record<string, any>>(),
  executionTime: integer("execution_time"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => ({
  userIdIdx: index("audit_user_id_idx").on(table.userId),
  actionIdx: index("audit_action_idx").on(table.action),
  resourceIdx: index("audit_resource_idx").on(table.resource),
  statusIdx: index("audit_status_idx").on(table.status),
  severityIdx: index("audit_severity_idx").on(table.severity),
  createdAtIdx: index("audit_created_at_idx").on(table.createdAt),
  userActionIdx: index("audit_user_action_idx").on(table.userId, table.action),
  resourceActionIdx: index("audit_resource_action_idx").on(table.resource, table.action),
  compositeIdx: index("audit_composite_idx").on(table.userId, table.action, table.createdAt),
}));

// Audit retention configuration
export const auditRetentionConfig = pgTable("audit_retention_config", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  category: varchar("category").notNull().unique(),
  retentionDays: integer("retention_days").notNull(),
  severityRetentionDays: json("severity_retention_days").$type<Record<string, number>>(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Define interfaces for audit operations
export interface CreateAuditLogOptions {
  userId: string;
  userEmail?: string;
  action: string;
  resource: string;
  resourceId?: string;
  status: 'success' | 'failure' | 'pending';
  details?: Record<string, any>;
  ipAddress?: string;
  userAgent?: string;
  severity?: 'low' | 'medium' | 'high' | 'critical';
  category: string;
  metadata?: Record<string, any>;
  executionTime?: number;
}

export interface QueryAuditLogsOptions {
  startDate?: Date;
  endDate?: Date;
  userId?: string | string[];
  action?: string | string[];
  resource?: string | string[];
  status?: 'success' | 'failure' | 'pending';
  severity?: ('low' | 'medium' | 'high' | 'critical')[];
  category?: string | string[];
  ipAddress?: string;
  searchTerm?: string;
  limit?: number;
  offset?: number;
  sortBy?: 'createdAt' | 'userId' | 'action' | 'resource';
  sortOrder?: 'asc' | 'desc';
}

export interface AuditLog {
  id: string;
  userId: string;
  userEmail?: string;
  action: string;
  resource: string;
  resourceId?: string;
  status: 'success' | 'failure' | 'pending';
  details?: Record<string, any>;
  ipAddress?: string;
  userAgent?: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  category: string;
  metadata?: Record<string, any>;
  executionTime?: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface ExportAuditLogsOptions {
  startDate?: Date;
  endDate?: Date;
  userId?: string[];
  action?: string[];
  resource?: string[];
  status?: 'success' | 'failure' | 'pending';
  category?: string[];
  format: 'json' | 'csv' | 'xml';
  includeMetadata?: boolean;
  includeDetails?: boolean;
}

export interface RetentionConfig {
  id: string;
  category: string;
  retentionDays: number;
  severityRetentionDays?: Record<string, number>;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface AuditTrends {
  period: string;
  totalLogs: number;
  successRate: number;
  actionBreakdown: Array<{ action: string; count: number; percentage: number }>;
  resourceBreakdown: Array<{ resource: string; count: number; percentage: number }>;
  statusBreakdown: Array<{ status: string; count: number; percentage: number }>;
  severityBreakdown: Array<{ severity: string; count: number; percentage: number }>;
  userActivity: Array<{ userId: string; userEmail?: string; count: number }>;
  dailyTrends: Array<{ date: string; count: number; successCount: number; failureCount: number }>;
  hourlyTrends: Array<{ hour: number; count: number }>;
}

export interface AuditAnalytics {
  totalEvents: number;
  uniqueUsers: number;
  uniqueResources: number;
  successRate: number;
  averageExecutionTime: number;
  topActions: Array<{ action: string; count: number }>;
  topUsers: Array<{ userId: string; userEmail?: string; count: number }>;
  topResources: Array<{ resource: string; count: number }>;
  failuresByAction: Array<{ action: string; failureCount: number; failureRate: number }>;
  suspiciousActivity: Array<{
    userId: string;
    userEmail?: string;
    reason: string;
    details: Record<string, any>;
  }>;
}

class AuditService {
  /**
   * Create a new audit log entry
   */
  async createAuditLog(options: CreateAuditLogOptions): Promise<AuditLog> {
    try {
      const [result] = await db.insert(auditLogs).values({
        userId: options.userId,
        userEmail: options.userEmail,
        action: options.action,
        resource: options.resource,
        resourceId: options.resourceId,
        status: options.status,
        details: options.details,
        ipAddress: options.ipAddress,
        userAgent: options.userAgent,
        severity: options.severity || 'medium',
        category: options.category,
        metadata: options.metadata,
        executionTime: options.executionTime,
      }).returning();

      return result as AuditLog;
    } catch (error) {
      console.error("Failed to create audit log:", error);
      throw new Error(`Failed to create audit log: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Query audit logs with advanced filtering
   */
  async queryAuditLogs(options: QueryAuditLogsOptions = {}): Promise<AuditLog[]> {
    try {
      const {
        startDate,
        endDate,
        userId,
        action,
        resource,
        status,
        severity,
        category,
        ipAddress,
        searchTerm,
        limit = 100,
        offset = 0,
        sortBy = 'createdAt',
        sortOrder = 'desc',
      } = options;

      let query = db.select().from(auditLogs);

      // Build conditions
      const conditions = [];

      if (startDate && endDate) {
        conditions.push(and(gte(auditLogs.createdAt, startDate), lte(auditLogs.createdAt, endDate)));
      } else if (startDate) {
        conditions.push(gte(auditLogs.createdAt, startDate));
      } else if (endDate) {
        conditions.push(lte(auditLogs.createdAt, endDate));
      }

      if (userId) {
        if (Array.isArray(userId)) {
          conditions.push(inArray(auditLogs.userId, userId));
        } else {
          conditions.push(eq(auditLogs.userId, userId));
        }
      }

      if (action) {
        if (Array.isArray(action)) {
          conditions.push(inArray(auditLogs.action, action));
        } else {
          conditions.push(eq(auditLogs.action, action));
        }
      }

      if (resource) {
        if (Array.isArray(resource)) {
          conditions.push(inArray(auditLogs.resource, resource));
        } else {
          conditions.push(eq(auditLogs.resource, resource));
        }
      }

      if (status) {
        conditions.push(eq(auditLogs.status, status));
      }

      if (severity && Array.isArray(severity)) {
        conditions.push(inArray(auditLogs.severity, severity));
      }

      if (category) {
        if (Array.isArray(category)) {
          conditions.push(inArray(auditLogs.category, category));
        } else {
          conditions.push(eq(auditLogs.category, category));
        }
      }

      if (ipAddress) {
        conditions.push(eq(auditLogs.ipAddress, ipAddress));
      }

      if (searchTerm) {
        // Search across multiple fields
        conditions.push(
          sql`(
            ${auditLogs.action} ILIKE ${'%' + searchTerm + '%'} OR
            ${auditLogs.resource} ILIKE ${'%' + searchTerm + '%'} OR
            ${auditLogs.userEmail} ILIKE ${'%' + searchTerm + '%'} OR
            ${auditLogs.details}::text ILIKE ${'%' + searchTerm + '%'}
          )`
        );
      }

      // Apply conditions
      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }

      // Apply sorting
      if (sortOrder === 'asc') {
        query = query.orderBy(asc(auditLogs[sortBy]));
      } else {
        query = query.orderBy(desc(auditLogs[sortBy]));
      }

      // Apply pagination
      query = query.limit(limit).offset(offset);

      const results = await query;
      return results as AuditLog[];
    } catch (error) {
      console.error("Failed to query audit logs:", error);
      throw new Error(`Failed to query audit logs: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Get audit logs count with filtering
   */
  async getAuditLogsCount(options: Omit<QueryAuditLogsOptions, 'limit' | 'offset' | 'sortBy' | 'sortOrder'> = {}): Promise<number> {
    try {
      const { startDate, endDate, userId, action, resource, status, severity, category, ipAddress, searchTerm } = options;

      let query = db.select({ count: sql<number>`count(*)` }).from(auditLogs);
      const conditions = [];

      if (startDate && endDate) {
        conditions.push(and(gte(auditLogs.createdAt, startDate), lte(auditLogs.createdAt, endDate)));
      } else if (startDate) {
        conditions.push(gte(auditLogs.createdAt, startDate));
      } else if (endDate) {
        conditions.push(lte(auditLogs.createdAt, endDate));
      }

      if (userId) {
        if (Array.isArray(userId)) {
          conditions.push(inArray(auditLogs.userId, userId));
        } else {
          conditions.push(eq(auditLogs.userId, userId));
        }
      }

      if (action) {
        if (Array.isArray(action)) {
          conditions.push(inArray(auditLogs.action, action));
        } else {
          conditions.push(eq(auditLogs.action, action));
        }
      }

      if (resource) {
        if (Array.isArray(resource)) {
          conditions.push(inArray(auditLogs.resource, resource));
        } else {
          conditions.push(eq(auditLogs.resource, resource));
        }
      }

      if (status) {
        conditions.push(eq(auditLogs.status, status));
      }

      if (severity && Array.isArray(severity)) {
        conditions.push(inArray(auditLogs.severity, severity));
      }

      if (category) {
        if (Array.isArray(category)) {
          conditions.push(inArray(auditLogs.category, category));
        } else {
          conditions.push(eq(auditLogs.category, category));
        }
      }

      if (ipAddress) {
        conditions.push(eq(auditLogs.ipAddress, ipAddress));
      }

      if (searchTerm) {
        conditions.push(
          sql`(
            ${auditLogs.action} ILIKE ${'%' + searchTerm + '%'} OR
            ${auditLogs.resource} ILIKE ${'%' + searchTerm + '%'} OR
            ${auditLogs.userEmail} ILIKE ${'%' + searchTerm + '%'} OR
            ${auditLogs.details}::text ILIKE ${'%' + searchTerm + '%'}
          )`
        );
      }

      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }

      const result = await query;
      return result[0]?.count || 0;
    } catch (error) {
      console.error("Failed to get audit logs count:", error);
      throw new Error(`Failed to get audit logs count: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Export audit logs in various formats
   */
  async exportAuditLogs(options: ExportAuditLogsOptions): Promise<{
    data: string;
    filename: string;
    mimeType: string;
    recordCount: number;
  }> {
    try {
      const {
        startDate,
        endDate,
        userId,
        action,
        resource,
        status,
        category,
        format,
        includeMetadata = true,
        includeDetails = false,
      } = options;

      const logs = await this.queryAuditLogs({
        startDate,
        endDate,
        userId,
        action,
        resource,
        status,
        category,
        limit: 10000, // Maximum export limit
        sortBy: 'createdAt',
        sortOrder: 'asc',
      });

      let data: string;
      let mimeType: string;
      let filename: string;

      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      
      switch (format) {
        case 'json':
          data = JSON.stringify(logs, null, 2);
          mimeType = 'application/json';
          filename = `audit-logs-${timestamp}.json`;
          break;

        case 'csv':
          const headers = [
            'ID', 'User ID', 'User Email', 'Action', 'Resource', 'Resource ID',
            'Status', 'IP Address', 'User Agent', 'Severity', 'Category',
            'Execution Time', 'Created At', 'Details', 'Metadata'
          ];

          const csvRows = [headers.join(',')];

          for (const log of logs) {
            const row = [
              log.id,
              log.userId,
              log.userEmail || '',
              log.action,
              log.resource,
              log.resourceId || '',
              log.status,
              log.ipAddress || '',
              log.userAgent || '',
              log.severity,
              log.category,
              log.executionTime?.toString() || '',
              log.createdAt.toISOString(),
              includeDetails ? JSON.stringify(log.details || {}) : '',
              includeMetadata ? JSON.stringify(log.metadata || {}) : '',
            ];

            // Escape CSV values
            const escapedRow = row.map(value => {
              if (value.includes(',') || value.includes('"') || value.includes('\n')) {
                return `"${value.replace(/"/g, '""')}"`;
              }
              return value;
            });

            csvRows.push(escapedRow.join(','));
          }

          data = csvRows.join('\n');
          mimeType = 'text/csv';
          filename = `audit-logs-${timestamp}.csv`;
          break;

        case 'xml':
          let xml = '<?xml version="1.0" encoding="UTF-8"?>\n<auditLogs>\n';
          
          for (const log of logs) {
            xml += '  <log>\n';
            xml += `    <id>${this.escapeXml(log.id)}</id>\n`;
            xml += `    <userId>${this.escapeXml(log.userId)}</userId>\n`;
            if (log.userEmail) xml += `    <userEmail>${this.escapeXml(log.userEmail)}</userEmail>\n`;
            xml += `    <action>${this.escapeXml(log.action)}</action>\n`;
            xml += `    <resource>${this.escapeXml(log.resource)}</resource>\n`;
            if (log.resourceId) xml += `    <resourceId>${this.escapeXml(log.resourceId)}</resourceId>\n`;
            xml += `    <status>${this.escapeXml(log.status)}</status>\n`;
            if (log.ipAddress) xml += `    <ipAddress>${this.escapeXml(log.ipAddress)}</ipAddress>\n`;
            if (log.userAgent) xml += `    <userAgent>${this.escapeXml(log.userAgent)}</userAgent>\n`;
            xml += `    <severity>${this.escapeXml(log.severity)}</severity>\n`;
            xml += `    <category>${this.escapeXml(log.category)}</category>\n`;
            if (log.executionTime) xml += `    <executionTime>${log.executionTime}</executionTime>\n`;
            xml += `    <createdAt>${log.createdAt.toISOString()}</createdAt>\n`;
            if (includeDetails && log.details) {
              xml += `    <details>${this.escapeXml(JSON.stringify(log.details))}</details>\n`;
            }
            if (includeMetadata && log.metadata) {
              xml += `    <metadata>${this.escapeXml(JSON.stringify(log.metadata))}</metadata>\n`;
            }
            xml += '  </log>\n';
          }
          
          xml += '</auditLogs>';
          data = xml;
          mimeType = 'application/xml';
          filename = `audit-logs-${timestamp}.xml`;
          break;

        default:
          throw new Error(`Unsupported export format: ${format}`);
      }

      return {
        data,
        filename,
        mimeType,
        recordCount: logs.length,
      };
    } catch (error) {
      console.error("Failed to export audit logs:", error);
      throw new Error(`Failed to export audit logs: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Get audit analytics and insights
   */
  async getAuditAnalytics(options: {
    startDate?: Date;
    endDate?: Date;
    category?: string;
  } = {}): Promise<AuditAnalytics> {
    try {
      const { startDate, endDate, category } = options;

      let query = db.select().from(auditLogs);
      const conditions = [];

      if (startDate && endDate) {
        conditions.push(and(gte(auditLogs.createdAt, startDate), lte(auditLogs.createdAt, endDate)));
      } else if (startDate) {
        conditions.push(gte(auditLogs.createdAt, startDate));
      } else if (endDate) {
        conditions.push(lte(auditLogs.createdAt, endDate));
      }

      if (category) {
        conditions.push(eq(auditLogs.category, category));
      }

      if (conditions.length > 0) {
        query = query.where(and(...conditions));
      }

      const logs = await query;
      const totalEvents = logs.length;

      // Calculate unique counts
      const uniqueUsers = new Set(logs.map(log => log.userId)).size;
      const uniqueResources = new Set(logs.map(log => log.resource)).size;

      // Calculate success rate
      const successEvents = logs.filter(log => log.status === 'success').length;
      const successRate = totalEvents > 0 ? (successEvents / totalEvents) * 100 : 0;

      // Calculate average execution time
      const executionTimes = logs.filter(log => log.executionTime).map(log => log.executionTime!);
      const averageExecutionTime = executionTimes.length > 0 
        ? executionTimes.reduce((a, b) => a + b, 0) / executionTimes.length 
        : 0;

      // Top actions
      const actionCounts = new Map<string, number>();
      logs.forEach(log => {
        actionCounts.set(log.action, (actionCounts.get(log.action) || 0) + 1);
      });
      const topActions = Array.from(actionCounts.entries())
        .map(([action, count]) => ({ action, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10);

      // Top users
      const userCounts = new Map<string, { count: number; userEmail?: string }>();
      logs.forEach(log => {
        const existing = userCounts.get(log.userId) || { count: 0 };
        userCounts.set(log.userId, {
          count: existing.count + 1,
          userEmail: log.userEmail || existing.userEmail,
        });
      });
      const topUsers = Array.from(userCounts.entries())
        .map(([userId, data]) => ({ userId, userEmail: data.userEmail, count: data.count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10);

      // Top resources
      const resourceCounts = new Map<string, number>();
      logs.forEach(log => {
        resourceCounts.set(log.resource, (resourceCounts.get(log.resource) || 0) + 1);
      });
      const topResources = Array.from(resourceCounts.entries())
        .map(([resource, count]) => ({ resource, count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10);

      // Failures by action
      const failureCounts = new Map<string, { total: number; failures: number }>();
      logs.forEach(log => {
        const existing = failureCounts.get(log.action) || { total: 0, failures: 0 };
        failureCounts.set(log.action, {
          total: existing.total + 1,
          failures: existing.failures + (log.status === 'failure' ? 1 : 0),
        });
      });
      const failuresByAction = Array.from(failureCounts.entries())
        .map(([action, data]) => ({
          action,
          failureCount: data.failures,
          failureRate: data.total > 0 ? (data.failures / data.total) * 100 : 0,
        }))
        .filter(item => item.failureCount > 0)
        .sort((a, b) => b.failureCount - a.failureCount)
        .slice(0, 10);

      // Suspicious activity detection
      const suspiciousActivity = this.detectSuspiciousActivity(logs);

      return {
        totalEvents,
        uniqueUsers,
        uniqueResources,
        successRate,
        averageExecutionTime,
        topActions,
        topUsers,
        topResources,
        failuresByAction,
        suspiciousActivity,
      };
    } catch (error) {
      console.error("Failed to get audit analytics:", error);
      throw new Error(`Failed to get audit analytics: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Get audit trends and patterns
   */
  async getAuditTrends(options: {
    period: '1d' | '7d' | '30d' | '90d';
    action?: string;
    resource?: string;
    category?: string;
  }): Promise<AuditTrends> {
    try {
      const { period, action, resource, category } = options;

      const now = new Date();
      let startDate: Date;

      switch (period) {
        case '1d':
          startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
          break;
        case '7d':
          startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
          break;
        case '30d':
          startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
          break;
        case '90d':
          startDate = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
          break;
      }

      const logs = await this.queryAuditLogs({
        startDate,
        endDate: now,
        action,
        resource,
        category,
        sortBy: 'createdAt',
        sortOrder: 'asc',
      });

      const totalLogs = logs.length;
      const successLogs = logs.filter(log => log.status === 'success').length;
      const successRate = totalLogs > 0 ? (successLogs / totalLogs) * 100 : 0;

      // Calculate breakdowns
      const actionBreakdown = this.calculateBreakdown(logs, 'action', 10);
      const resourceBreakdown = this.calculateBreakdown(logs, 'resource', 10);
      const statusBreakdown = this.calculateBreakdown(logs, 'status', 3);
      const severityBreakdown = this.calculateBreakdown(logs, 'severity', 4);

      // User activity
      const userCounts = new Map<string, { count: number; userEmail?: string }>();
      logs.forEach(log => {
        const existing = userCounts.get(log.userId) || { count: 0 };
        userCounts.set(log.userId, {
          count: existing.count + 1,
          userEmail: log.userEmail || existing.userEmail,
        });
      });
      const userActivity = Array.from(userCounts.entries())
        .map(([userId, data]) => ({ userId, userEmail: data.userEmail, count: data.count }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10);

      // Daily trends
      const dailyTrends = this.calculateDailyTrends(logs, startDate, now);

      // Hourly trends
      const hourlyTrends = this.calculateHourlyTrends(logs);

      return {
        period,
        totalLogs,
        successRate,
        actionBreakdown,
        resourceBreakdown,
        statusBreakdown,
        severityBreakdown,
        userActivity,
        dailyTrends,
        hourlyTrends,
      };
    } catch (error) {
      console.error("Failed to get audit trends:", error);
      throw new Error(`Failed to get audit trends: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Configure audit retention policies
   */
  async configureRetentionPolicy(config: Omit<RetentionConfig, 'id' | 'createdAt' | 'updatedAt'>): Promise<RetentionConfig> {
    try {
      const [result] = await db.insert(auditRetentionConfig)
        .values(config)
        .onConflictDoUpdate({
          target: auditRetentionConfig.category,
          set: {
            retentionDays: config.retentionDays,
            severityRetentionDays: config.severityRetentionDays,
            isActive: config.isActive,
            updatedAt: new Date(),
          },
        })
        .returning();

      return result as RetentionConfig;
    } catch (error) {
      console.error("Failed to configure retention policy:", error);
      throw new Error(`Failed to configure retention policy: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Get retention policies
   */
  async getRetentionPolicies(): Promise<RetentionConfig[]> {
    try {
      const results = await db.select().from(auditRetentionConfig);
      return results as RetentionConfig[];
    } catch (error) {
      console.error("Failed to get retention policies:", error);
      throw new Error(`Failed to get retention policies: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Clean up expired audit logs based on retention policies
   */
  async cleanupExpiredLogs(): Promise<{ deletedCount: number }> {
    try {
      const policies = await this.getRetentionPolicies();
      let totalDeleted = 0;

      for (const policy of policies) {
        if (!policy.isActive) continue;

        let cutoffDate = new Date();
        const daysToSubtract = policy.retentionDays;
        cutoffDate.setDate(cutoffDate.getDate() - daysToSubtract);

        // If there are severity-specific retention days, handle critical/high priority logs first
        if (policy.severityRetentionDays) {
          const severityDays = policy.severityRetentionDays;

          // Delete low severity logs first
          if (severityDays.low !== undefined) {
            const lowCutoff = new Date();
            lowCutoff.setDate(lowCutoff.getDate() - severityDays.low);
            
            const { count } = await db.delete(auditLogs)
              .where(and(
                eq(auditLogs.category, policy.category),
                eq(auditLogs.severity, 'low'),
                lte(auditLogs.createdAt, lowCutoff)
              ))
              .returning({ deletedCount: sql<number>`count(*)` });
            
            totalDeleted += count;
          }

          // Keep medium/high/critical logs longer if needed
          // This is a simplified approach - in production, you might want to archive instead of delete
        }

        // Delete logs for this category older than the general cutoff
        const { count } = await db.delete(auditLogs)
          .where(and(
            eq(auditLogs.category, policy.category),
            lte(auditLogs.createdAt, cutoffDate)
          ))
          .returning({ deletedCount: sql<number>`count(*)` });

        totalDeleted += count;
      }

      return { deletedCount: totalDeleted };
    } catch (error) {
      console.error("Failed to cleanup expired logs:", error);
      throw new Error(`Failed to cleanup expired logs: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  /**
   * Search audit logs with full-text search
   */
  async searchAuditLogs(query: string, options: {
    startDate?: Date;
    endDate?: Date;
    userId?: string;
    limit?: number;
    offset?: number;
  } = {}): Promise<AuditLog[]> {
    return this.queryAuditLogs({
      searchTerm: query,
      startDate: options.startDate,
      endDate: options.endDate,
      userId: options.userId,
      limit: options.limit || 100,
      offset: options.offset || 0,
      sortBy: 'createdAt',
      sortOrder: 'desc',
    });
  }

  /**
   * Get audit statistics summary
   */
  async getAuditStatistics(): Promise<{
    totalLogs: number;
    todayLogs: number;
    weekLogs: number;
    monthLogs: number;
    uniqueUsers: number;
    successRate: number;
    categories: Array<{ category: string; count: number }>;
    recentActivity: AuditLog[];
  }> {
    try {
      const now = new Date();
      const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const weekStart = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      const monthStart = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

      const [totalLogs, todayLogs, weekLogs, monthLogs] = await Promise.all([
        this.getAuditLogsCount(),
        this.getAuditLogsCount({ startDate: todayStart }),
        this.getAuditLogsCount({ startDate: weekStart }),
        this.getAuditLogsCount({ startDate: monthStart }),
      ]);

      const recentLogs = await this.queryAuditLogs({
        limit: 10,
        sortBy: 'createdAt',
        sortOrder: 'desc',
      });

      // Get unique users in the last month
      const monthLogsData = await this.queryAuditLogs({
        startDate: monthStart,
        endDate: now,
        limit: 10000,
      });
      const uniqueUsers = new Set(monthLogsData.map(log => log.userId)).size;

      // Calculate success rate for the last month
      const successCount = monthLogsData.filter(log => log.status === 'success').length;
      const successRate = monthLogs > 0 ? (successCount / monthLogs) * 100 : 0;

      // Get category breakdown
      const categoryCounts = new Map<string, number>();
      monthLogsData.forEach(log => {
        categoryCounts.set(log.category, (categoryCounts.get(log.category) || 0) + 1);
      });
      const categories = Array.from(categoryCounts.entries())
        .map(([category, count]) => ({ category, count }))
        .sort((a, b) => b.count - a.count);

      return {
        totalLogs,
        todayLogs,
        weekLogs,
        monthLogs,
        uniqueUsers,
        successRate,
        categories,
        recentActivity: recentLogs,
      };
    } catch (error) {
      console.error("Failed to get audit statistics:", error);
      throw new Error(`Failed to get audit statistics: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  // Helper methods
  private escapeXml(unsafe: string): string {
    return unsafe.replace(/[<>&'"]/g, (c) => {
      switch (c) {
        case '<': return '&lt;';
        case '>': return '&gt;';
        case '&': return '&amp;';
        case '\'': return '&apos;';
        case '"': return '&quot;';
        default: return c;
      }
    });
  }

  private calculateBreakdown(logs: AuditLog[], field: keyof AuditLog, limit: number): Array<{ key: string; count: number; percentage: number }> {
    const counts = new Map<string, number>();
    logs.forEach(log => {
      const key = String(log[field] || 'unknown');
      counts.set(key, (counts.get(key) || 0) + 1);
    });

    const total = logs.length;
    return Array.from(counts.entries())
      .map(([key, count]) => ({
        key,
        count,
        percentage: total > 0 ? (count / total) * 100 : 0,
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, limit);
  }

  private calculateDailyTrends(logs: AuditLog[], startDate: Date, endDate: Date): Array<{ date: string; count: number; successCount: number; failureCount: number }> {
    const trends = new Map<string, { count: number; successCount: number; failureCount: number }>();
    
    // Initialize all dates in the range
    const current = new Date(startDate);
    while (current <= endDate) {
      const dateStr = current.toISOString().split('T')[0];
      trends.set(dateStr, { count: 0, successCount: 0, failureCount: 0 });
      current.setDate(current.getDate() + 1);
    }

    // Fill in actual data
    logs.forEach(log => {
      const dateStr = log.createdAt.toISOString().split('T')[0];
      const existing = trends.get(dateStr) || { count: 0, successCount: 0, failureCount: 0 };
      existing.count++;
      if (log.status === 'success') existing.successCount++;
      else if (log.status === 'failure') existing.failureCount++;
      trends.set(dateStr, existing);
    });

    return Array.from(trends.entries())
      .map(([date, data]) => ({ date, ...data }))
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  private calculateHourlyTrends(logs: AuditLog[]): Array<{ hour: number; count: number }> {
    const trends = new Array(24).fill(0).map((_, hour) => ({ hour, count: 0 }));
    
    logs.forEach(log => {
      const hour = log.createdAt.getHours();
      trends[hour].count++;
    });

    return trends;
  }

  private detectSuspiciousActivity(logs: AuditLog[]): Array<{
    userId: string;
    userEmail?: string;
    reason: string;
    details: Record<string, any>;
  }> {
    const suspicious: Array<{
      userId: string;
      userEmail?: string;
      reason: string;
      details: Record<string, any>;
    }> = [];

    // Group logs by user
    const userLogs = new Map<string, AuditLog[]>();
    logs.forEach(log => {
      const userList = userLogs.get(log.userId) || [];
      userList.push(log);
      userLogs.set(log.userId, userList);
    });

    userLogs.forEach((userAuditLogs, userId) => {
      const userEmail = userAuditLogs[0]?.userEmail;
      
      // Check for multiple failures
      const failures = userAuditLogs.filter(log => log.status === 'failure');
      if (failures.length > 10) {
        suspicious.push({
          userId,
          userEmail,
          reason: 'High number of failures',
          details: { failureCount: failures.length, totalLogs: userAuditLogs.length },
        });
      }

      // Check for rapid successive actions
      const sortedLogs = userAuditLogs.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
      for (let i = 1; i < sortedLogs.length; i++) {
        const timeDiff = sortedLogs[i].createdAt.getTime() - sortedLogs[i - 1].createdAt.getTime();
        if (timeDiff < 1000) { // Less than 1 second between actions
          suspicious.push({
            userId,
            userEmail,
            reason: 'Rapid successive actions',
            details: { timeDiff, suspiciousPair: [sortedLogs[i - 1].action, sortedLogs[i].action] },
          });
          break;
        }
      }

      // Check for unusual IP addresses
      const ipAddresses = new Set(userAuditLogs.map(log => log.ipAddress).filter(Boolean) as string[]);
      if (ipAddresses.size > 5) {
        suspicious.push({
          userId,
          userEmail,
          reason: 'Multiple IP addresses',
          details: { ipCount: ipAddresses.size, ipAddresses: Array.from(ipAddresses) },
        });
      }
    });

    return suspicious;
  }
}

export const auditService = new AuditService();
