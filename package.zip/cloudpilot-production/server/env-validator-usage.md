# Environment Validator Usage Guide

## Overview

The `env-validator.ts` module provides comprehensive validation for all environment variables used in the CloudPilot application. It ensures type safety, format validation, and provides helpful error messages with setup instructions.

## Quick Start

### 1. Basic Usage

```typescript
import { validateConfig, validateConfigForEnvironment } from './env-validator';

// Validate all environment variables
const config = validateConfig();

// Use the validated config
console.log(config.database.url);
console.log(config.jwt.secret);
```

### 2. Environment-Specific Validation

```typescript
import { validateConfigForEnvironment } from './env-validator';

// Validate for production environment
const config = validateConfigForEnvironment('production');

// Validate for development environment
const config = validateConfigForEnvironment('development');
```

### 3. Individual Configuration Validation

```typescript
import { 
  validateDatabaseConfig,
  validateJWTConfig,
  validateAWSConfig,
  validateServerConfig,
  validateAuthConfig
} from './env-validator';

// Validate individual configs
const dbConfig = validateDatabaseConfig();
const jwtConfig = validateJWTConfig();
const awsConfig = validateAWSConfig();
```

### 4. Using in Main Application

```typescript
import express from 'express';
import { validateConfig, printConfigSummary } from './env-validator';

const app = express();

// Validate environment on startup
const config = validateConfig();

// Print configuration summary (optional, masks sensitive data)
if (config.server.nodeEnv === 'development') {
  printConfigSummary(config);
}

// Use config in your application
const port = config.server.port;
const dbUrl = config.database.url;

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
```

## Environment Variables

### Required Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | `postgresql://user:pass@localhost:5432/db` |
| `JWT_SECRET` | JWT signing secret (min 32 chars) | `a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0` |

### Optional Variables

| Variable | Description | Default | Example |
|----------|-------------|---------|---------|
| `JWT_EXPIRES_IN` | Access token expiration | `24h` | `12h`, `30m` |
| `JWT_REFRESH_EXPIRES_IN` | Refresh token expiration | `7d` | `30d`, `2w` |
| `JWT_ACCESS_TOKEN_SECRET` | Alternative access token secret | - | `access-secret-key` |
| `JWT_REFRESH_TOKEN_SECRET` | Alternative refresh token secret | - | `refresh-secret-key` |
| `JWT_REFRESH_EXPIRATION` | Alternative refresh expiration | - | `14d` |
| `PORT` | Server port | `5000` | `3000`, `8080` |
| `NODE_ENV` | Environment mode | `development` | `production`, `test` |
| `AWS_ACCESS_KEY_ID` | AWS access key | - | `AKIAIOSFODNN7EXAMPLE` |
| `AWS_SECRET_ACCESS_KEY` | AWS secret key | - | `wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY` |
| `AWS_DEFAULT_REGION` | AWS region | `us-east-1` | `us-west-2`, `eu-central-1` |
| `API_KEY` | API key for protected endpoints | - | `your-api-key-123` |
| `AUTH_RATE_LIMIT_WINDOW` | Rate limit window (ms) | `900000` (15min) | `600000` |
| `AUTH_RATE_LIMIT_MAX` | Max attempts per window | `5` | `10` |

## Setup Instructions

### 1. Database Setup

**Neon (Recommended)**
```bash
# Visit https://neon.tech
# Create a new project
# Copy the connection string
DATABASE_URL="postgresql://user:password@ep-xxx.neon.tech/neondb?sslmode=require"
```

**Supabase**
```bash
# Visit https://supabase.com
# Create a new project
# Go to Settings > Database
# Copy the connection string
DATABASE_URL="postgresql://postgres:[password]@db.[project-ref].supabase.co:5432/postgres"
```

**Railway**
```bash
# Visit https://railway.app
# Create a new project
# Add PostgreSQL service
# Copy the connection string from Variables tab
DATABASE_URL="postgresql://postgres:[password]@localhost:5432/railway"
```

**Local PostgreSQL**
```bash
# Start PostgreSQL locally
DATABASE_URL="postgresql://username:password@localhost:5432/mydatabase"
```

### 2. JWT Secret Generation

**Using Node.js**
```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

**Using OpenSSL**
```bash
openssl rand -hex 32
```

**Online Generator**
```bash
# Visit https://generate-secret.vercel.app/32
# Copy the generated secret
```

**Add to .env**
```env
JWT_SECRET="your-generated-secret-key-minimum-32-characters-long"
```

### 3. AWS Configuration (Optional)

```env
AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE
AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
AWS_DEFAULT_REGION=us-east-1
```

### 4. Complete .env Example

```env
# Database
DATABASE_URL="postgresql://user:password@localhost:5432/cloudpilot"

# Authentication
JWT_SECRET="your-very-long-and-secure-secret-key-minimum-32-chars"
JWT_EXPIRES_IN="24h"
JWT_REFRESH_EXPIRES_IN="7d"

# Server
PORT=5000
NODE_ENV=development

# AWS (Optional)
AWS_ACCESS_KEY_ID=your-access-key
AWS_SECRET_ACCESS_KEY=your-secret-key
AWS_DEFAULT_REGION=us-east-1

# Auth Rate Limiting
AUTH_RATE_LIMIT_WINDOW=900000
AUTH_RATE_LIMIT_MAX=5

# API Key (Optional)
API_KEY=your-api-key-if-needed
```

## Validation Functions

### Individual Validators

```typescript
import { validateDatabaseUrl, validateJWTSecret } from './env-validator';

// Validate database URL
try {
  const dbConfig = validateDatabaseUrl(process.env.DATABASE_URL!);
  console.log('Database config:', dbConfig);
} catch (error) {
  console.error('Invalid database URL:', error.message);
}

// Validate JWT secret
try {
  validateJWTSecret(process.env.JWT_SECRET!);
  console.log('JWT secret is valid');
} catch (error) {
  console.error('Invalid JWT secret:', error.message);
}
```

### Base Validators

```typescript
import { isString, isValidURL, isNonEmptyString } from './env-validator';

// Use base validators for custom validation
const value = 'some-value';
if (isString(value) && isNonEmptyString(value)) {
  console.log('Valid string');
}

const url = 'https://example.com';
if (isValidURL(url)) {
  console.log('Valid URL');
}
```

## Error Handling

The module provides detailed error messages with setup instructions:

```typescript
try {
  const config = validateConfig();
} catch (error) {
  if (error instanceof EnvValidationError) {
    console.error(`Variable: ${error.variable}`);
    console.error(`Error: ${error.message}`);
    
    // Follow the setup instructions provided
  }
}
```

### Common Error Messages

**Missing DATABASE_URL**
```
DATABASE_URL is required. Set it in your .env file or environment variables.

Setup Instructions:
1. Create a PostgreSQL database (e.g., Neon, Supabase, Railway, or local PostgreSQL)
2. Get the connection string in format: postgresql://user:password@host:port/database
3. Add to .env: DATABASE_URL="your-connection-string"
4. For Neon/Supabase, use the provided connection string
```

**Invalid JWT_SECRET**
```
JWT_SECRET must be at least 32 characters long for security
```

**Default JWT_SECRET**
```
JWT_SECRET cannot be the default development value. Please set a secure secret.
```

## TypeScript Interfaces

```typescript
interface DatabaseConfig {
  url: string;
  host?: string;
  port?: number;
  database?: string;
  username?: string;
  password?: string;
  ssl?: boolean;
}

interface JWTConfig {
  secret: string;
  expiresIn: string;
  refreshExpiresIn: string;
  accessTokenSecret?: string;
  refreshTokenSecret?: string;
  refreshExpiration?: string;
}

interface AWSConfig {
  accessKeyId?: string;
  secretAccessKey?: string;
  defaultRegion?: string;
}

interface ServerConfig {
  port: number;
  nodeEnv: 'development' | 'production' | 'test';
}

interface AuthConfig {
  rateLimitWindow: number;
  rateLimitMax: number;
  apiKey?: string;
}

interface EnvConfig {
  database: DatabaseConfig;
  jwt: JWTConfig;
  aws: AWSConfig;
  server: ServerConfig;
  auth: AuthConfig;
}
```

## Best Practices

### 1. Fail Fast
```typescript
// Always validate at application startup
const config = validateConfig();
```

### 2. Environment-Specific Validation
```typescript
const config = validateConfigForEnvironment(process.env.NODE_ENV as 'development' | 'production' | 'test');
```

### 3. Development vs Production
```typescript
const config = validateConfig();

if (config.server.nodeEnv === 'development') {
  printConfigSummary(config);
  // Development-only logging
}

if (config.server.nodeEnv === 'production') {
  // Production-specific checks
  if (!config.jwt.secret || config.jwt.secret.length < 32) {
    throw new Error('Production requires strong JWT secret');
  }
}
```

### 4. Mask Sensitive Data
```typescript
// Always mask sensitive data in logs
const maskedSecret = config.jwt.secret.substring(0, 8) + '****' + 
                    config.jwt.secret.substring(config.jwt.secret.length - 4);
console.log(`JWT Secret: ${maskedSecret}`);
```

### 5. Never Commit Secrets
```env
# .env (add to .gitignore)
JWT_SECRET=your-secret-key
DATABASE_URL=your-db-url

# .env.example (safe to commit)
JWT_SECRET=your-secret-key-here
DATABASE_URL=postgresql://user:password@host:port/db
```

## Integration with Existing Code

### Express.js Integration

```typescript
import express from 'express';
import { validateConfig } from './env-validator';

const app = express();

// Validate environment at startup
const config = validateConfig();

// Use validated config throughout your app
app.get('/config', (req, res) => {
  res.json({
    port: config.server.port,
    environment: config.server.nodeEnv,
    // Don't expose secrets!
  });
});
```

### Database Integration

```typescript
import { Pool } from '@neondatabase/serverless';
import { validateDatabaseConfig } from './env-validator';

const dbConfig = validateDatabaseConfig();
export const pool = new Pool({ 
  connectionString: dbConfig.url,
  ssl: dbConfig.ssl ? { rejectUnauthorized: false } : undefined
});
```

### JWT Integration

```typescript
import jwt from 'jsonwebtoken';
import { validateJWTConfig } from './env-validator';

const jwtConfig = validateJWTConfig();

export const generateToken = (payload: any) => {
  return jwt.sign(payload, jwtConfig.secret, {
    expiresIn: jwtConfig.expiresIn
  });
};

export const verifyToken = (token: string) => {
  return jwt.verify(token, jwtConfig.secret);
};
```

## Testing

### Unit Tests

```typescript
import { validateDatabaseUrl, validateJWTSecret } from './env-validator';

describe('Environment Validation', () => {
  test('validates correct database URL', () => {
    const url = 'postgresql://user:pass@localhost:5432/mydb';
    const config = validateDatabaseUrl(url);
    expect(config.host).toBe('localhost');
    expect(config.port).toBe(5432);
  });

  test('validates strong JWT secret', () => {
    const secret = 'a-very-long-secret-key-that-is-secure-and-more-than-32-chars';
    expect(() => validateJWTSecret(secret)).not.toThrow();
  });

  test('rejects weak JWT secret', () => {
    expect(() => validateJWTSecret('weak')).toThrow();
  });
});
```

### Integration Tests

```typescript
import { validateConfig } from './env-validator';

describe('Configuration Integration', () => {
  test('validates all environment variables', () => {
    process.env.DATABASE_URL = 'postgresql://test:test@localhost:5432/test';
    process.env.JWT_SECRET = 'test-secret-key-that-is-long-enough-for-testing-purposes';

    expect(() => validateConfig()).not.toThrow();
  });
});
```

## Troubleshooting

### Common Issues

1. **"DATABASE_URL must be set"**
   - Ensure you have created a PostgreSQL database
   - Add the connection string to your `.env` file
   - Check the format: `postgresql://user:password@host:port/database`

2. **"JWT_SECRET must be at least 32 characters"**
   - Generate a longer secret: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`
   - Ensure it's set in your environment

3. **"PORT must be a valid number"**
   - Set PORT in your `.env` or ensure it's a valid number
   - PORT must be between 1 and 65535

4. **AWS credentials validation**
   - Ensure both `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` are set
   - Or leave both unset if not using AWS features

### Debug Mode

```typescript
import { validateConfig, printConfigSummary } from './env-validator';

const config = validateConfig();

// Print summary with masked sensitive data
printConfigSummary(config);
```

This will output:
```
📋 Environment Configuration Summary:
==================================================
Database: postgresql://user:****@localhost:5432/mydb
  - Host: localhost
  - Port: 5432
  - SSL: Disabled
JWT: a1b2c3d4****8s9t
  - Access Token Expires: 24h
  - Refresh Token Expires: 7d
AWS:
  - Region: us-east-1
  - Access Key: AKIA****
Server:
  - Port: 5000
  - Environment: development
Auth:
  - Rate Limit Window: 900000ms
  - Rate Limit Max: 5 attempts
  - API Key: Not configured
==================================================
```

## Advanced Usage

### Custom Validators

```typescript
import { isString, EnvValidationError } from './env-validator';

export const validateCustomVariable = (value: string): string => {
  if (!isString(value)) {
    throw new EnvValidationError(
      'CUSTOM_VAR must be a string',
      'CUSTOM_VAR'
    );
  }
  
  if (!value.includes('required-prefix')) {
    throw new EnvValidationError(
      'CUSTOM_VAR must include "required-prefix"',
      'CUSTOM_VAR'
    );
  }
  
  return value;
};
```

### Conditional Validation

```typescript
import { validateConfig } from './env-validator';

const config = validateConfig();

// Conditional based on environment
if (config.server.nodeEnv === 'production') {
  if (!config.aws.accessKeyId) {
    throw new EnvValidationError(
      'AWS credentials required in production',
      'AWS_ACCESS_KEY_ID'
    );
  }
}
```

This comprehensive environment validator ensures your application fails fast with clear error messages, making it easier to debug configuration issues and maintain security best practices.
