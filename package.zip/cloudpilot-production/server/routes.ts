import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { awsService } from "./services/aws-service";
import { registerAuthRoutes } from "./auth-routes";
import { registerAuditRoutes } from "./audit-routes";
import { authenticateToken } from "./auth";
import { insertAwsAccountSchema, launchInstanceSchema, createS3BucketSchema, createRdsInstanceSchema, createCloudFrontDistributionSchema, type SafeAwsAccount } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Register auth routes
  registerAuthRoutes(app);

  // Register audit routes
  registerAuditRoutes(app);

  // AWS Accounts routes
  app.get("/api/aws-accounts", authenticateToken, async (req, res) => {
    try {
      const accounts = await storage.getSafeAwsAccounts();
      res.json(accounts);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/aws-accounts", authenticateToken, async (req, res) => {
    try {
      const validatedData = insertAwsAccountSchema.parse(req.body);
      
      // Validate AWS credentials
      const isValid = await awsService.validateCredentials(
        validatedData.accessKeyId, 
        validatedData.secretAccessKey
      );
      
      if (!isValid) {
        return res.status(400).json({ message: "Invalid AWS credentials" });
      }

      const account = await storage.createAwsAccount(validatedData);
      res.json(account);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/aws-accounts/:id/activate", authenticateToken, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.activateAwsAccount(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // AWS EC2 routes
  app.get("/api/aws/instances/:region/:accountId", authenticateToken, async (req, res) => {
    try {
      const { region, accountId } = req.params;
      const account = await storage.getAwsAccount(accountId);
      
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const instances = await awsService.listInstances(
        account.accessKeyId,
        account.secretAccessKey,
        region
      );

      // Store/update instances in storage with enhanced data
      for (const instance of instances) {
        // Generate mock traffic data
        const traffic = awsService.generateMockTrafficData();
        
        // Extract instance name from tags
        const nameTag = instance.Tags?.find((tag: any) => tag.Key === 'Name');
        const instanceName = nameTag?.Value || null;
        
        // Get elastic IP if any
        const elasticIps = await awsService.listElasticIps(
          account.accessKeyId,
          account.secretAccessKey,
          region
        );
        const elasticIp = elasticIps.find((eip: any) => eip.InstanceId === instance.InstanceId);
        
        await storage.upsertEc2Instance({
          instanceId: instance.InstanceId!,
          name: instanceName,
          region,
          state: instance.State?.Name || "unknown",
          instanceType: instance.InstanceType || "unknown",
          publicIpAddress: instance.PublicIpAddress || null,
          privateIpAddress: instance.PrivateIpAddress || null,
          elasticIpAddress: elasticIp?.PublicIp || null,
          trafficInbound: traffic.inbound,
          trafficOutbound: traffic.outbound,
          launchTime: instance.LaunchTime || null,
          platformDetails: instance.PlatformDetails || null,
          availabilityZone: instance.Placement?.AvailabilityZone || null,
          monitoring: instance.Monitoring?.State || null,
          volumes: instance.BlockDeviceMappings || [],
          networkInterfaces: instance.NetworkInterfaces || [],
          securityGroups: instance.SecurityGroups || [],
          tags: instance.Tags ? Object.fromEntries(instance.Tags.map((tag: any) => [tag.Key, tag.Value])) : {},
          accountId,
        });
      }

      const storedInstances = await storage.getEc2InstancesByRegion(region, accountId);
      res.json(storedInstances);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/aws/instances/launch", authenticateToken, async (req, res) => {
    try {
      const validatedData = launchInstanceSchema.parse(req.body);
      const { accountId, ...launchParams } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const result = await awsService.launchInstance(
        account.accessKeyId,
        account.secretAccessKey,
        launchParams
      );

      res.json(result);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/aws/instances/start", authenticateToken, async (req, res) => {
    try {
      const { instanceId, region, accountId } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const result = await awsService.startInstance(
        account.accessKeyId,
        account.secretAccessKey,
        region,
        instanceId
      );

      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/aws/instances/stop", authenticateToken, async (req, res) => {
    try {
      const { instanceId, region, accountId } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const result = await awsService.stopInstance(
        account.accessKeyId,
        account.secretAccessKey,
        region,
        instanceId
      );

      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/aws/instances/terminate", authenticateToken, async (req, res) => {
    try {
      const { instanceId, region, accountId } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const result = await awsService.terminateInstance(
        account.accessKeyId,
        account.secretAccessKey,
        region,
        instanceId
      );

      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/aws/check-quota", authenticateToken, async (req, res) => {
    try {
      const { region, accountId } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const quota = await awsService.checkQuota(
        account.accessKeyId,
        account.secretAccessKey,
        region
      );

      res.json(quota);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/aws/enable-region", authenticateToken, async (req, res) => {
    try {
      const { region, accountId } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      // For Hong Kong region enablement - this is typically automatic
      // but we can check if the region is accessible
      const result = await awsService.checkRegionAccess(
        account.accessKeyId,
        account.secretAccessKey,
        region
      );

      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Bulk operations endpoints
  app.post("/api/aws/instances/bulk-action", authenticateToken, async (req, res) => {
    try {
      const { instanceIds, action, region, accountId } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const results = [];
      for (const instanceId of instanceIds) {
        try {
          let result;
          switch (action) {
            case 'start':
              result = await awsService.startInstance(
                account.accessKeyId,
                account.secretAccessKey,
                region,
                instanceId
              );
              break;
            case 'stop':
              result = await awsService.stopInstance(
                account.accessKeyId,
                account.secretAccessKey,
                region,
                instanceId
              );
              break;
            case 'terminate':
              result = await awsService.terminateInstance(
                account.accessKeyId,
                account.secretAccessKey,
                region,
                instanceId
              );
              break;
            case 'rotate-ip':
              result = await awsService.rotateInstanceIp(
                account.accessKeyId,
                account.secretAccessKey,
                region,
                instanceId
              );
              break;
            default:
              throw new Error(`Unknown action: ${action}`);
          }
          results.push({ instanceId, success: true, result });
        } catch (error) {
          results.push({ instanceId, success: false, error: error instanceof Error ? error.message : 'Unknown error' });
        }
      }

      res.json({ results });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Instance naming/tagging endpoint
  app.post("/api/aws/instances/update-name", authenticateToken, async (req, res) => {
    try {
      const { instanceId, name, region, accountId } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const result = await awsService.tagInstances(
        account.accessKeyId,
        account.secretAccessKey,
        region,
        [instanceId],
        { Name: name }
      );

      // Update in storage
      await storage.updateInstanceName(instanceId, name);

      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Windows password retrieval endpoint
  app.post("/api/aws/instances/windows-password", authenticateToken, async (req, res) => {
    try {
      const { instanceId, region, accountId } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const result = await awsService.getWindowsPassword(
        account.accessKeyId,
        account.secretAccessKey,
        region,
        instanceId
      );

      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // IP rotation endpoint
  app.post("/api/aws/instances/rotate-ip", authenticateToken, async (req, res) => {
    try {
      const { instanceId, region, accountId } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const result = await awsService.rotateInstanceIp(
        account.accessKeyId,
        account.secretAccessKey,
        region,
        instanceId
      );

      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Elastic IP management endpoints
  app.get("/api/aws/elastic-ips/:region/:accountId", authenticateToken, async (req, res) => {
    try {
      const { region, accountId } = req.params;
      const account = await storage.getAwsAccount(accountId);
      
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const elasticIps = await awsService.listElasticIps(
        account.accessKeyId,
        account.secretAccessKey,
        region
      );

      res.json(elasticIps);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/aws/elastic-ips/allocate", authenticateToken, async (req, res) => {
    try {
      const { region, accountId } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const result = await awsService.allocateElasticIp(
        account.accessKeyId,
        account.secretAccessKey,
        region
      );

      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/aws/elastic-ips/release", authenticateToken, async (req, res) => {
    try {
      const { allocationId, region, accountId } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const result = await awsService.releaseElasticIp(
        account.accessKeyId,
        account.secretAccessKey,
        region,
        allocationId
      );

      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/aws/elastic-ips/associate", authenticateToken, async (req, res) => {
    try {
      const { instanceId, allocationId, region, accountId } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const result = await awsService.associateElasticIp(
        account.accessKeyId,
        account.secretAccessKey,
        region,
        instanceId,
        allocationId
      );

      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/aws/elastic-ips/disassociate", authenticateToken, async (req, res) => {
    try {
      const { associationId, region, accountId } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const result = await awsService.disassociateElasticIp(
        account.accessKeyId,
        account.secretAccessKey,
        region,
        associationId
      );

      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Instance details endpoint
  app.get("/api/aws/instances/:instanceId/details/:region/:accountId", authenticateToken, async (req, res) => {
    try {
      const { instanceId, region, accountId } = req.params;
      const account = await storage.getAwsAccount(accountId);
      
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const details = await awsService.getInstanceDetails(
        account.accessKeyId,
        account.secretAccessKey,
        region,
        instanceId
      );

      res.json(details);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Export instances endpoint
  app.get("/api/aws/instances/export/:format/:region/:accountId", authenticateToken, async (req, res) => {
    try {
      const { format, region, accountId } = req.params;
      const instances = await storage.getEc2InstancesByRegion(region, accountId);
      
      if (format === 'csv') {
        const csv = [
          ['Instance ID', 'Name', 'State', 'Type', 'Public IP', 'Private IP', 'Traffic In', 'Traffic Out', 'Launch Time'].join(','),
          ...instances.map(i => [
            i.instanceId,
            i.name || '',
            i.state,
            i.instanceType,
            i.publicIpAddress || '',
            i.privateIpAddress || '',
            i.trafficInbound || '',
            i.trafficOutbound || '',
            i.launchTime?.toString() || ''
          ].join(','))
        ].join('\n');
        
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename="instances.csv"');
        res.send(csv);
      } else {
        res.json(instances);
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // S3 routes
  app.get("/api/aws/s3/buckets/:accountId", authenticateToken, async (req, res) => {
    try {
      const { accountId } = req.params;
      const account = await storage.getAwsAccount(accountId);
      
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const buckets = await awsService.listS3Buckets(
        account.accessKeyId,
        account.secretAccessKey
      );

      // Store/update buckets in storage
      for (const bucket of buckets) {
        await storage.upsertS3Bucket({
          name: bucket.Name!,
          region: "us-east-1", // Default region, real region detection would require additional API calls
          creationDate: bucket.CreationDate || null,
          accountId,
        });
      }

      const storedBuckets = await storage.getS3BucketsByAccount(accountId);
      res.json(storedBuckets);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/aws/s3/buckets", authenticateToken, async (req, res) => {
    try {
      const validatedData = createS3BucketSchema.parse(req.body);
      
      const account = await storage.getAwsAccount(validatedData.accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const result = await awsService.createS3Bucket(
        account.accessKeyId,
        account.secretAccessKey,
        validatedData
      );

      // Store bucket in database
      await storage.upsertS3Bucket({
        name: validatedData.bucketName,
        region: validatedData.region,
        creationDate: new Date(),
        accountId: validatedData.accountId,
      });

      res.json(result);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/aws/s3/buckets/:bucketName/:accountId", authenticateToken, async (req, res) => {
    try {
      const { bucketName, accountId } = req.params;
      const { region } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const result = await awsService.deleteS3Bucket(
        account.accessKeyId,
        account.secretAccessKey,
        bucketName,
        region
      );

      // Remove from database
      await storage.deleteS3Bucket(bucketName, accountId);

      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/aws/s3/objects/:bucketName/:accountId", authenticateToken, async (req, res) => {
    try {
      const { bucketName, accountId } = req.params;
      const { region } = req.query;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const objects = await awsService.listS3Objects(
        account.accessKeyId,
        account.secretAccessKey,
        bucketName,
        region as string
      );

      res.json(objects);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/aws/s3/upload", authenticateToken, async (req, res) => {
    try {
      const { bucketName, fileName, fileContent, region, accountId } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      // Convert base64 string to buffer
      const buffer = Buffer.from(fileContent, 'base64');

      const result = await awsService.uploadS3Object(
        account.accessKeyId,
        account.secretAccessKey,
        bucketName,
        region,
        fileName,
        buffer
      );

      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/aws/s3/download/:bucketName/:accountId/:fileName", authenticateToken, async (req, res) => {
    try {
      const { bucketName, accountId, fileName } = req.params;
      const { region } = req.query;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const result = await awsService.downloadS3Object(
        account.accessKeyId,
        account.secretAccessKey,
        bucketName,
        region as string,
        fileName
      );

      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/aws/s3/objects/:bucketName/:accountId/:fileName", authenticateToken, async (req, res) => {
    try {
      const { bucketName, accountId, fileName } = req.params;
      const { region } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const result = await awsService.deleteS3Object(
        account.accessKeyId,
        account.secretAccessKey,
        bucketName,
        region,
        fileName
      );

      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // AWS RDS routes
  app.get("/api/aws/rds/:region/:accountId", authenticateToken, async (req, res) => {
    try {
      const { region, accountId } = req.params;
      const account = await storage.getAwsAccount(accountId);
      
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const instances = await awsService.listRdsInstances(
        account.accessKeyId,
        account.secretAccessKey,
        region
      );

      // Store/update RDS instances in storage
      for (const instance of instances) {
        await storage.upsertRdsInstance({
          dbInstanceIdentifier: instance.DBInstanceIdentifier!,
          region,
          dbInstanceClass: instance.DBInstanceClass!,
          engine: instance.Engine!,
          engineVersion: instance.EngineVersion || null,
          dbInstanceStatus: instance.DBInstanceStatus!,
          masterUsername: instance.MasterUsername || null,
          endpoint: instance.Endpoint?.Address || null,
          port: instance.Endpoint?.Port?.toString() || null,
          availabilityZone: instance.AvailabilityZone || null,
          allocatedStorage: instance.AllocatedStorage?.toString() || null,
          storageType: instance.StorageType || null,
          storageEncrypted: instance.StorageEncrypted || false,
          vpcSecurityGroups: instance.VpcSecurityGroups?.map(vsg => vsg.VpcSecurityGroupId || '') || null,
          dbSubnetGroupName: instance.DBSubnetGroup?.DBSubnetGroupName || null,
          multiAz: instance.MultiAZ || false,
          publiclyAccessible: instance.PubliclyAccessible || false,
          instanceCreateTime: instance.InstanceCreateTime || null,
          accountId,
        });
      }

      const storedInstances = await storage.getRdsInstancesByRegion(region, accountId);
      res.json(storedInstances);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/aws/rds", authenticateToken, async (req, res) => {
    try {
      const validatedData = createRdsInstanceSchema.parse(req.body);
      const account = await storage.getAwsAccount(validatedData.accountId);
      
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const instance = await awsService.createRdsInstance(
        account.accessKeyId,
        account.secretAccessKey,
        validatedData
      );

      // Store the new instance
      if (instance) {
        await storage.upsertRdsInstance({
          dbInstanceIdentifier: instance.DBInstanceIdentifier!,
          region: validatedData.region,
          dbInstanceClass: instance.DBInstanceClass!,
          engine: instance.Engine!,
          engineVersion: instance.EngineVersion || null,
          dbInstanceStatus: instance.DBInstanceStatus!,
          masterUsername: instance.MasterUsername || null,
          endpoint: instance.Endpoint?.Address || null,
          port: instance.Endpoint?.Port?.toString() || null,
          availabilityZone: instance.AvailabilityZone || null,
          allocatedStorage: instance.AllocatedStorage?.toString() || null,
          storageType: instance.StorageType || null,
          storageEncrypted: instance.StorageEncrypted || false,
          vpcSecurityGroups: instance.VpcSecurityGroups?.map(vsg => vsg.VpcSecurityGroupId || '') || null,
          dbSubnetGroupName: instance.DBSubnetGroup?.DBSubnetGroupName || null,
          multiAz: instance.MultiAZ || false,
          publiclyAccessible: instance.PubliclyAccessible || false,
          instanceCreateTime: instance.InstanceCreateTime || null,
          accountId: validatedData.accountId,
        });
      }

      res.json({ success: true, instance });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/aws/rds/:dbInstanceIdentifier/:accountId", authenticateToken, async (req, res) => {
    try {
      const { dbInstanceIdentifier, accountId } = req.params;
      const { region } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const instance = await awsService.deleteRdsInstance(
        account.accessKeyId,
        account.secretAccessKey,
        dbInstanceIdentifier,
        region
      );

      // Remove from storage
      await storage.deleteRdsInstance(dbInstanceIdentifier, accountId);

      res.json({ success: true, instance });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/aws/rds/:dbInstanceIdentifier/:accountId/start", authenticateToken, async (req, res) => {
    try {
      const { dbInstanceIdentifier, accountId } = req.params;
      const { region } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const instance = await awsService.startRdsInstance(
        account.accessKeyId,
        account.secretAccessKey,
        dbInstanceIdentifier,
        region
      );

      res.json({ success: true, instance });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/aws/rds/:dbInstanceIdentifier/:accountId/stop", authenticateToken, async (req, res) => {
    try {
      const { dbInstanceIdentifier, accountId } = req.params;
      const { region } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const instance = await awsService.stopRdsInstance(
        account.accessKeyId,
        account.secretAccessKey,
        dbInstanceIdentifier,
        region
      );

      res.json({ success: true, instance });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/aws/rds/:dbInstanceIdentifier/:accountId/reboot", authenticateToken, async (req, res) => {
    try {
      const { dbInstanceIdentifier, accountId } = req.params;
      const { region } = req.body;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const instance = await awsService.rebootRdsInstance(
        account.accessKeyId,
        account.secretAccessKey,
        dbInstanceIdentifier,
        region
      );

      res.json({ success: true, instance });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // AWS CloudFront routes
  app.get("/api/aws/cloudfront/:accountId", authenticateToken, async (req, res) => {
    try {
      const { accountId } = req.params;
      const account = await storage.getAwsAccount(accountId);
      
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const distributions = await awsService.listCloudFrontDistributions(
        account.accessKeyId,
        account.secretAccessKey
      );

      // Store/update CloudFront distributions in storage
      for (const distribution of distributions) {
        await storage.upsertCloudFrontDistribution({
          distributionId: distribution.Id!,
          arn: distribution.ARN || null,
          status: distribution.Status!,
          domainName: distribution.DomainName!,
          enabled: distribution.Enabled!,
          comment: distribution.Comment || null,
          origins: distribution.Origins?.Items || [],
          defaultRootObject: distribution.DefaultRootObject || null,
          customErrorResponses: distribution.CustomErrorResponses?.Items || [],
          lastModifiedTime: distribution.LastModifiedTime || null,
          priceClass: distribution.PriceClass || null,
          webAclId: distribution.WebACLId || null,
          httpVersion: distribution.HttpVersion || null,
          isIPV6Enabled: distribution.IsIPV6Enabled || false,
          distributionConfig: distribution.DistributionConfig || {},
          accountId,
        });
      }

      const storedDistributions = await storage.getCloudFrontDistributionsByAccount(accountId);
      res.json(storedDistributions);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/aws/cloudfront", authenticateToken, async (req, res) => {
    try {
      const validatedData = createCloudFrontDistributionSchema.parse(req.body);
      const account = await storage.getAwsAccount(validatedData.accountId);
      
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const distribution = await awsService.createCloudFrontDistribution(
        account.accessKeyId,
        account.secretAccessKey,
        validatedData
      );

      // Store the new distribution
      if (distribution) {
        await storage.upsertCloudFrontDistribution({
          distributionId: distribution.Id!,
          arn: distribution.ARN || null,
          status: distribution.Status!,
          domainName: distribution.DomainName!,
          enabled: distribution.Enabled!,
          comment: distribution.Comment || null,
          origins: distribution.Origins?.Items || [],
          defaultRootObject: distribution.DefaultRootObject || null,
          customErrorResponses: distribution.CustomErrorResponses?.Items || [],
          lastModifiedTime: distribution.LastModifiedTime || null,
          priceClass: distribution.PriceClass || null,
          webAclId: distribution.WebACLId || null,
          httpVersion: distribution.HttpVersion || null,
          isIPV6Enabled: distribution.IsIPV6Enabled || false,
          distributionConfig: distribution.DistributionConfig || {},
          accountId: validatedData.accountId,
        });
      }

      res.json({ success: true, distribution });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/aws/cloudfront/:distributionId/:accountId", authenticateToken, async (req, res) => {
    try {
      const { distributionId, accountId } = req.params;
      
      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const result = await awsService.deleteCloudFrontDistribution(
        account.accessKeyId,
        account.secretAccessKey,
        distributionId
      );

      // Remove from storage
      await storage.deleteCloudFrontDistribution(distributionId, accountId);

      res.json({ success: true, ...result });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/aws/cloudfront/:distributionId/:accountId/invalidate", authenticateToken, async (req, res) => {
    try {
      const { distributionId, accountId } = req.params;
      const { paths } = req.body;
      
      if (!paths || !Array.isArray(paths) || paths.length === 0) {
        return res.status(400).json({ message: "Invalid paths array" });
      }

      const account = await storage.getAwsAccount(accountId);
      if (!account) {
        return res.status(404).json({ message: "AWS account not found" });
      }

      const invalidation = await awsService.createCloudFrontInvalidation(
        account.accessKeyId,
        account.secretAccessKey,
        distributionId,
        paths
      );

      res.json({ success: true, invalidation });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Instance Templates routes
  app.get("/api/instance-templates/:accountId", authenticateToken, async (req, res) => {
    try {
      const { accountId } = req.params;
      const templates = await storage.getInstanceTemplatesByAccount(accountId);
      res.json(templates);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/instance-templates", authenticateToken, async (req, res) => {
    try {
      const template = await storage.createInstanceTemplate(req.body);
      res.json(template);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/instance-templates/:id", authenticateToken, async (req, res) => {
    try {
      const { id } = req.params;
      const template = await storage.updateInstanceTemplate(id, req.body);
      res.json(template);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/instance-templates/:id", authenticateToken, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteInstanceTemplate(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
