import express from "express";
import { 
  requireAuth, 
  requireRole, 
  requireAdmin, 
  requireManagerOrAdmin,
  requireOwnershipOrAdmin,
  optionalAuth,
  protect,
  generateToken,
  UserRole,
  type AuthenticatedUser 
} from "./protected";

const router = express.Router();

// Example: Route that requires authentication
router.get("/profile", requireAuth, (req, res) => {
  // req.user is now available with authenticated user info
  const user = req.user as AuthenticatedUser;
  
  res.json({
    message: "This is a protected route",
    user: {
      id: user.id,
      email: user.email,
      username: user.username,
      role: user.role,
    }
  });
});

// Example: Route that requires specific role
router.get("/admin/dashboard", requireAdmin, (req, res) => {
  res.json({
    message: "Admin only dashboard",
    user: req.user
  });
});

// Example: Route that allows multiple roles
router.post("/manage-users", requireManagerOrAdmin, (req, res) => {
  res.json({
    message: "Manager or Admin can manage users",
    user: req.user
  });
});

// Example: Route with custom role requirement
router.post("/create-resource", 
  requireRole([UserRole.ADMIN, UserRole.MANAGER]), 
  (req, res) => {
    res.json({
      message: "Admin or Manager can create resources",
      user: req.user
    });
  }
);

// Example: Route checking ownership or admin
router.get("/users/:userId/resources", 
  requireOwnershipOrAdmin("userId"), 
  (req, res) => {
    res.json({
      message: "User can only access their own resources unless admin",
      user: req.user,
      requestedUserId: req.params.userId
    });
  }
);

// Example: Using multiple middleware with protect wrapper
router.put("/update-profile",
  protect(
    requireAuth,
    requireRole([UserRole.USER, UserRole.MANAGER, UserRole.ADMIN])
  ),
  (req, res) => {
    res.json({
      message: "Profile updated successfully",
      user: req.user,
      updates: req.body
    });
  }
);

// Example: Optional authentication (doesn't fail if no token)
router.get("/public-data", optionalAuth, (req, res) => {
  const user = req.user;
  
  res.json({
    message: "Public data endpoint",
    hasAuth: !!user,
    user: user ? {
      id: user.id,
      role: user.role
    } : null
  });
});

// Example: Login endpoint that generates JWT token
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Validate credentials (implement your own logic)
    const user = await validateUserCredentials(email, password);
    
    if (!user) {
      return res.status(401).json({ 
        message: "Invalid credentials" 
      });
    }

    // Generate JWT token
    const token = generateToken({
      id: user.id,
      email: user.email,
      username: user.username,
      role: user.role
    });

    res.json({
      message: "Login successful",
      token,
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        role: user.role
      }
    });
  } catch (error) {
    res.status(500).json({ 
      message: "Login failed" 
    });
  }
});

// Example: Refresh token endpoint
router.post("/refresh", requireAuth, (req, res) => {
  const user = req.user as AuthenticatedUser;
  
  // Generate new tokens
  const token = generateToken({
    id: user.id,
    email: user.email,
    username: user.username,
    role: user.role
  });

  res.json({
    message: "Token refreshed",
    token
  });
});

// Example: Protected AWS resource endpoint
router.get("/aws/instances/:accountId", 
  requireAuth,
  requireRole([UserRole.MANAGER, UserRole.ADMIN]),
  async (req, res) => {
    const { accountId } = req.params;
    const user = req.user as AuthenticatedUser;
    
    // Check if user owns this AWS account or is admin
    const hasAccess = await checkAwsAccountAccess(user.id, accountId);
    
    if (!hasAccess) {
      return res.status(403).json({ 
        message: "You don't have access to this AWS account" 
      });
    }

    // Fetch instances logic here...
    res.json({
      message: "AWS instances retrieved successfully",
      accountId,
      user: user.username
    });
  }
);

// Example: Bulk operation endpoint with admin requirement
router.post("/aws/instances/bulk-action",
  requireAuth,
  requireAdmin, // Only admins can perform bulk operations
  async (req, res) => {
    const { instanceIds, action } = req.body;
    const user = req.user as AuthenticatedUser;
    
    res.json({
      message: `Bulk ${action} initiated by ${user.username}`,
      instanceIds,
      status: "initiated"
    });
  }
);

// Helper functions (implement according to your needs)
async function validateUserCredentials(email: string, password: string) {
  // Implement your user validation logic
  // This is just a placeholder
  return {
    id: "user-123",
    email,
    username: "testuser",
    role: UserRole.USER
  };
}

async function checkAwsAccountAccess(userId: string, accountId: string): Promise<boolean> {
  // Implement your access control logic
  // Check if user has permission to access this AWS account
  return true;
}

export default router;