import { Request, Response, NextFunction } from 'express';
import winston from 'winston';
import { v4 as uuidv4 } from 'uuid';

// Log levels
export enum LogLevel {
  ERROR = 'error',
  WARN = 'warn',
  INFO = 'info',
  DEBUG = 'debug'
}

// Log entry interface
interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  correlationId?: string;
  userId?: string;
  requestId?: string;
  method?: string;
  url?: string;
  statusCode?: number;
  responseTime?: number;
  awsOperation?: string;
  awsService?: string;
  awsResource?: string;
  error?: any;
  metadata?: Record<string, any>;
}

// User context interface
interface UserContext {
  id?: string;
  email?: string;
  role?: string;
  permissions?: string[];
}

// Sensitive data patterns
const SENSITIVE_PATTERNS = [
  /password/i,
  /passwd/i,
  /pwd/i,
  /secret/i,
  /token/i,
  /key/i,
  /ssn/i,
  /social.*security/i,
  /credit.*card/i,
  /card.*number/i,
  /cvv/i,
  /authorization/i,
  /bearer/i,
  /apikey/i,
  /api_key/i
];

// Logger class with all logging functionality
export class Logger {
  private winston: winston.Logger;
  private correlationIdMap: Map<string, number> = new Map();
  private maxCorrelationEntries = 10000;

  constructor() {
    this.winston = winston.createLogger({
      level: process.env.LOG_LEVEL || LogLevel.INFO,
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.errors({ stack: true }),
        winston.format.json()
      ),
      transports: [
        new winston.transports.File({
          filename: 'logs/error.log',
          level: LogLevel.ERROR,
          maxsize: 5242880, // 5MB
          maxFiles: 5
        }),
        new winston.transports.File({
          filename: 'logs/combined.log',
          maxsize: 5242880, // 5MB
          maxFiles: 5
        }),
        new winston.transports.File({
          filename: 'logs/requests.log',
          level: LogLevel.INFO,
          maxsize: 10485760, // 10MB
          maxFiles: 10
        })
      ]
    });

    // Add console transport in development
    if (process.env.NODE_ENV !== 'production') {
      this.winston.add(
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.colorize(),
            winston.format.simple()
          )
        })
      );
    }
  }

  // Filter sensitive data from objects
  private filterSensitiveData(obj: any): any {
    if (!obj || typeof obj !== 'object') {
      return obj;
    }

    if (Array.isArray(obj)) {
      return obj.map(item => this.filterSensitiveData(item));
    }

    const filtered: any = {};
    
    for (const [key, value] of Object.entries(obj)) {
      // Check if the key contains sensitive patterns
      const isSensitiveKey = SENSITIVE_PATTERNS.some(pattern => pattern.test(key));
      
      if (isSensitiveKey) {
        filtered[key] = '[FILTERED]';
      } else if (typeof value === 'string') {
        // Check if the value contains sensitive patterns
        const isSensitiveValue = SENSITIVE_PATTERNS.some(pattern => pattern.test(value));
        if (isSensitiveValue) {
          filtered[key] = '[FILTERED]';
        } else {
          filtered[key] = value;
        }
      } else if (typeof value === 'object') {
        filtered[key] = this.filterSensitiveData(value);
      } else {
        filtered[key] = value;
      }
    }

    return filtered;
  }

  // Generate correlation ID
  generateCorrelationId(): string {
    const id = uuidv4();
    this.correlationIdMap.set(id, Date.now());
    
    // Clean up old entries
    if (this.correlationIdMap.size > this.maxCorrelationEntries) {
      const firstKey = this.correlationIdMap.keys().next().value;
      this.correlationIdMap.delete(firstKey);
    }
    
    return id;
  }

  // Validate correlation ID
  validateCorrelationId(id: string): boolean {
    return this.correlationIdMap.has(id);
  }

  // Create log entry
  private createLogEntry(
    level: LogLevel,
    message: string,
    metadata: Partial<LogEntry> = {}
  ): LogEntry {
    return {
      timestamp: new Date().toISOString(),
      level,
      message,
      ...metadata
    };
  }

  // Core logging methods
  error(message: string, metadata: Partial<LogEntry> = {}): void {
    const logEntry = this.createLogEntry(LogLevel.ERROR, message, metadata);
    this.winston.error(this.filterSensitiveData(logEntry));
  }

  warn(message: string, metadata: Partial<LogEntry> = {}): void {
    const logEntry = this.createLogEntry(LogLevel.WARN, message, metadata);
    this.winston.warn(this.filterSensitiveData(logEntry));
  }

  info(message: string, metadata: Partial<LogEntry> = {}): void {
    const logEntry = this.createLogEntry(LogLevel.INFO, message, metadata);
    this.winston.info(this.filterSensitiveData(logEntry));
  }

  debug(message: string, metadata: Partial<LogEntry> = {}): void {
    const logEntry = this.createLogEntry(LogLevel.DEBUG, message, metadata);
    this.winston.debug(this.filterSensitiveData(logEntry));
  }

  // Request logging
  logRequest(req: Request, res: Response, responseTime: number): void {
    const logEntry: Partial<LogEntry> = {
      correlationId: (req as any).correlationId,
      userId: (req as any).user?.id,
      method: req.method,
      url: req.originalUrl,
      statusCode: res.statusCode,
      responseTime
    };

    this.info('Request processed', logEntry);
  }

  // AWS operation logging
  logAWSOperation(
    service: string,
    operation: string,
    resource: string,
    metadata: Partial<LogEntry> = {},
    level: LogLevel = LogLevel.INFO
  ): void {
    const logEntry: Partial<LogEntry> = {
      ...metadata,
      awsService: service,
      awsOperation: operation,
      awsResource: resource
    };

    this[level](`AWS ${service}: ${operation}`, logEntry);
  }

  // User context logging
  logUserAction(
    userId: string,
    action: string,
    context: UserContext = {},
    metadata: Partial<LogEntry> = {}
  ): void {
    const logEntry: Partial<LogEntry> = {
      ...metadata,
      userId,
      metadata: {
        ...context,
        ...metadata.metadata
      }
    };

    this.info(`User action: ${action}`, logEntry);
  }

  // Performance logging
  logPerformance(operation: string, duration: number, metadata: Partial<LogEntry> = {}): void {
    const level = duration > 5000 ? LogLevel.WARN : duration > 1000 ? LogLevel.INFO : LogLevel.DEBUG;
    
    const logEntry: Partial<LogEntry> = {
      ...metadata,
      responseTime: duration,
      metadata: {
        ...metadata.metadata,
        operation,
        performanceThreshold: duration > 5000 ? 'high' : duration > 1000 ? 'medium' : 'low'
      }
    };

    this[level](`Performance: ${operation}`, logEntry);
  }

  // Security event logging
  logSecurityEvent(event: string, severity: LogLevel, metadata: Partial<LogEntry> = {}): void {
    const logEntry: Partial<LogEntry> = {
      ...metadata,
      metadata: {
        ...metadata.metadata,
        securityEvent: true
      }
    };

    this[level](`Security: ${event}`, logEntry);
  }

  // Error logging with stack trace
  logError(error: Error, metadata: Partial<LogEntry> = {}): void {
    const logEntry: Partial<LogEntry> = {
      ...metadata,
      error: {
        message: error.message,
        stack: error.stack,
        name: error.name
      }
    };

    this.error('Error occurred', logEntry);
  }
}

// Request context interface
interface RequestContext {
  correlationId: string;
  userId?: string;
  startTime: number;
}

// Global logger instance
export const logger = new Logger();

// Request logging middleware
export const requestLoggingMiddleware = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  const startTime = Date.now();
  
  // Generate or extract correlation ID
  const correlationId = 
    req.headers['x-correlation-id'] as string || 
    req.headers['x-request-id'] as string || 
    logger.generateCorrelationId();

  // Attach correlation ID to request
  (req as any).correlationId = correlationId;
  
  // Store request context
  (req as any).context = {
    correlationId,
    startTime,
    userId: (req as any).user?.id
  };

  // Log incoming request
  logger.info('Request received', {
    correlationId,
    method: req.method,
    url: req.originalUrl,
    userAgent: req.headers['user-agent'],
    ip: req.ip,
    userId: (req as any).user?.id
  });

  // Override res.json to capture response
  const originalJson = res.json;
  res.json = function(body: any) {
    const responseTime = Date.now() - startTime;
    
    // Log the response
    logger.logRequest(req, res, responseTime);
    
    // Check for slow responses
    if (responseTime > 1000) {
      logger.warn('Slow response detected', {
        correlationId,
        responseTime,
        method: req.method,
        url: req.originalUrl
      });
    }
    
    return originalJson.call(this, body);
  };

  next();
};

// AWS operation logging middleware
export const awsOperationLogger = (service: string) => {
  return {
    before: (operation: string, resource: string, metadata: any = {}) => {
      logger.logAWSOperation(service, operation, resource, {
        ...metadata,
        phase: 'before'
      }, LogLevel.DEBUG);
    },
    after: (operation: string, resource: string, metadata: any = {}) => {
      logger.logAWSOperation(service, operation, resource, {
        ...metadata,
        phase: 'after'
      });
    },
    error: (operation: string, resource: string, error: Error, metadata: any = {}) => {
      logger.logAWSOperation(service, operation, resource, {
        ...metadata,
        phase: 'error',
        error: error.message
      }, LogLevel.ERROR);
    }
  };
};

// Performance monitoring middleware
export const performanceMiddleware = (threshold: number = 1000) => {
  return (req: Request, res: Response, next: NextFunction) => {
    const startTime = process.hrtime.bigint();
    
    res.on('finish', () => {
      const endTime = process.hrtime.bigint();
      const duration = Number(endTime - startTime) / 1000000; // Convert to milliseconds
      
      if (duration > threshold) {
        logger.logPerformance(`${req.method} ${req.originalUrl}`, duration, {
          correlationId: (req as any).correlationId,
          statusCode: res.statusCode
        });
      }
    });
    
    next();
  };
};

// User context middleware
export const userContextMiddleware = (req: Request, res: Response, next: NextFunction): void => {
  const user = (req as any).user;
  
  if (user) {
    logger.logUserAction(user.id, 'Request with user context', {
      email: user.email,
      role: user.role,
      permissions: user.permissions
    }, {
      correlationId: (req as any).correlationId,
      method: req.method,
      url: req.originalUrl
    });
  }
  
  next();
};

// Security logging middleware
export const securityMiddleware = (req: Request, res: Response, next: NextFunction): void => {
  const userAgent = req.headers['user-agent'];
  const origin = req.headers.origin;
  
  // Log suspicious requests
  const suspiciousPatterns = [
    /bot|crawler|spider/i,
    /admin|login|wp-admin/i,
    /\.\./,
    /script|javascript/i
  ];
  
  const isSuspicious = suspiciousPatterns.some(pattern => 
    pattern.test(req.originalUrl) || 
    pattern.test(userAgent || '') ||
    pattern.test(origin || '')
  );
  
  if (isSuspicious) {
    logger.logSecurityEvent('Suspicious request detected', LogLevel.WARN, {
      correlationId: (req as any).correlationId,
      method: req.method,
      url: req.originalUrl,
      userAgent,
      origin,
      ip: req.ip
    });
  }
  
  // Log authentication attempts
  if (req.originalUrl.includes('/auth/') || req.originalUrl.includes('/login')) {
    logger.logSecurityEvent('Authentication attempt', LogLevel.INFO, {
      correlationId: (req as any).correlationId,
      method: req.method,
      url: req.originalUrl,
      ip: req.ip,
      userAgent
    });
  }
  
  next();
};

// Error logging middleware
export const errorLoggingMiddleware = (
  error: Error,
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  logger.logError(error, {
    correlationId: (req as any).correlationId,
    method: req.method,
    url: req.originalUrl,
    userId: (req as any).user?.id,
    stack: error.stack
  });
  
  next(error);
};

// Log rotation utility
export const setupLogRotation = (): void => {
  const fs = require('fs');
  const path = require('path');
  
  // Ensure logs directory exists
  const logsDir = path.join(process.cwd(), 'logs');
  if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir, { recursive: true });
  }
  
  // Compress old log files daily
  setInterval(() => {
    const logFiles = ['error.log', 'combined.log', 'requests.log'];
    const today = new Date().toISOString().split('T')[0];
    
    logFiles.forEach(file => {
      const filePath = path.join(logsDir, file);
      if (fs.existsSync(filePath)) {
        // Check if file was modified more than 24 hours ago
        const stats = fs.statSync(filePath);
        const hoursSinceModified = (Date.now() - stats.mtime.getTime()) / (1000 * 60 * 60);
        
        if (hoursSinceModified > 24) {
          const newPath = path.join(logsDir, `${today}-${file}.gz`);
          // In a real implementation, you would use gzip here
          logger.info('Log rotation initiated', { file, newPath });
        }
      }
    });
  }, 24 * 60 * 60 * 1000); // Check daily
};

// Utility functions
export const createLogger = (context: string): Logger => {
  return {
    ...logger,
    info: (message: string, metadata?: Partial<LogEntry>) => {
      logger.info(`[${context}] ${message}`, metadata);
    },
    warn: (message: string, metadata?: Partial<LogEntry>) => {
      logger.warn(`[${context}] ${message}`, metadata);
    },
    error: (message: string, metadata?: Partial<LogEntry>) => {
      logger.error(`[${context}] ${message}`, metadata);
    },
    debug: (message: string, metadata?: Partial<LogEntry>) => {
      logger.debug(`[${context}] ${message}`, metadata);
    }
  } as Logger;
};

export const getCorrelationId = (req: Request): string | undefined => {
  return (req as any).correlationId;
};

export const setUserContext = (req: Request, context: UserContext): void => {
  (req as any).userContext = context;
};

// Export default logger configuration
export const defaultLogger = logger;