/**
 * Health Check System Usage Examples
 * Demonstrates how to use the health check system programmatically
 */

import { 
  runHealthCheck, 
  getCurrentHealthStatus, 
  getHealthCheckConfig,
  clearHealthHistory,
  checkDatabase,
  checkSystemResources
} from './health.js';

/**
 * Example 1: Run a complete health check and check overall status
 */
async function example1_CompleteHealthCheck() {
  console.log('🔍 Running complete health check...\n');
  
  try {
    const report = await runHealthCheck('all');
    
    console.log(`Overall Status: ${report.status.toUpperCase()}`);
    console.log(`Environment: ${report.environment}`);
    console.log(`Uptime: ${Math.round(report.uptime / 60)} minutes`);
    console.log(`Total Checks: ${report.summary.total}`);
    console.log(`Healthy: ${report.summary.healthy}`);
    console.log(`Degraded: ${report.summary.degraded}`);
    console.log(`Unhealthy: ${report.summary.unhealthy}`);
    console.log(`Average Response Time: ${Math.round(report.summary.avgResponseTime)}ms\n`);
    
    if (report.status === 'unhealthy') {
      console.log('❌ System has critical issues that need attention!');
      const unhealthyChecks = report.checks.database.status === 'unhealthy' ? 
        ['Database'] : [];
      if (unhealthyChecks.length > 0) {
        console.log(`Critical services affected: ${unhealthyChecks.join(', ')}`);
      }
    } else if (report.status === 'degraded') {
      console.log('⚠️  System is experiencing some issues but is still operational');
    } else {
      console.log('✅ System is healthy and operational');
    }
  } catch (error) {
    console.error('❌ Health check failed:', error);
  }
}

/**
 * Example 2: Check specific service health
 */
async function example2_SpecificServiceCheck() {
  console.log('🔍 Checking database health specifically...\n');
  
  try {
    const dbHealth = await runHealthCheck('database');
    
    console.log(`Database Status: ${dbHealth.status}`);
    console.log(`Response Time: ${dbHealth.responseTime}ms`);
    console.log(`Message: ${dbHealth.message}`);
    
    if (dbHealth.metadata) {
      console.log('Database Info:');
      console.log(`  Version: ${dbHealth.metadata.version}`);
      console.log(`  Current Time: ${dbHealth.metadata.currentTime}`);
      console.log(`  Retries: ${dbHealth.metadata.retries}`);
    }
    
    if (dbHealth.error) {
      console.log(`Error: ${dbHealth.error}`);
    }
  } catch (error) {
    console.error('❌ Database health check failed:', error);
  }
}

/**
 * Example 3: Monitor system resources
 */
async function example3_SystemResourceMonitoring() {
  console.log('🔍 Monitoring system resources...\n');
  
  try {
    const systemHealth = await runHealthCheck('system');
    const metrics = systemHealth.metadata;
    
    console.log('System Resource Usage:');
    console.log(`  CPU Usage: ${metrics.cpu.usage}%`);
    console.log(`  Load Average: ${metrics.cpu.loadAverage.join(', ')}`);
    console.log(`  CPU Cores: ${metrics.cpu.cores}`);
    console.log(`  Memory Usage: ${metrics.memory.percentage}%`);
    console.log(`  Memory Used: ${Math.round(metrics.memory.used / 1024 / 1024)}MB`);
    console.log(`  Memory Total: ${Math.round(metrics.memory.total / 1024 / 1024)}MB`);
    console.log(`  Disk Usage: ${metrics.disk.percentage}%`);
    console.log(`  Disk Used: ${Math.round(metrics.disk.used / 1024 / 1024 / 1024)}GB`);
    console.log(`  Uptime: ${Math.round(metrics.uptime / 60)} minutes`);
    console.log(`  Platform: ${metrics.platform}`);
    console.log(`  Node Version: ${metrics.nodeVersion}`);
    
    // Check if resources are within acceptable limits
    const issues = [];
    if (metrics.cpu.usage > 80) issues.push('High CPU usage');
    if (metrics.memory.percentage > 85) issues.push('High memory usage');
    if (metrics.disk.percentage > 90) issues.push('High disk usage');
    
    if (issues.length > 0) {
      console.log(`\n⚠️  Resource Issues: ${issues.join(', ')}`);
    } else {
      console.log('\n✅ All resources within acceptable limits');
    }
  } catch (error) {
    console.error('❌ System resource check failed:', error);
  }
}

/**
 * Example 4: Health check before critical operations
 */
async function example4_PreOperationHealthCheck() {
  console.log('🔍 Pre-operation health check...\n');
  
  try {
    const health = await getCurrentHealthStatus();
    
    // Only proceed with critical operation if system is healthy
    if (health.status === 'unhealthy') {
      console.log('❌ Cannot proceed: System is unhealthy');
      console.log('Affected services:', Object.entries(health.checks)
        .filter(([_, check]) => check.status === 'unhealthy')
        .map(([service, _]) => service)
        .join(', '));
      return false;
    }
    
    // Proceed with operation
    console.log('✅ System is healthy enough to proceed with operation');
    
    if (health.status === 'degraded') {
      console.log('⚠️  Warning: System is degraded but operation can continue');
    }
    
    return true;
  } catch (error) {
    console.error('❌ Pre-operation health check failed:', error);
    return false;
  }
}

/**
 * Example 5: Monitor health trends
 */
async function example5_HealthTrends() {
  console.log('🔍 Analyzing health trends...\n');
  
  try {
    const report = await getCurrentHealthStatus();
    
    if (report.trends) {
      console.log('Health Trends:');
      console.log('Last 24 Hours:');
      console.log(`  Uptime: ${report.trends.last24Hours.uptime}%`);
      console.log(`  Availability: ${report.trends.last24Hours.availability}%`);
      console.log(`  Average Response Time: ${report.trends.last24Hours.avgResponseTime}ms`);
      console.log(`  Critical Incidents: ${report.trends.last24Hours.criticalIncidents}`);
      
      console.log('\nLast 7 Days:');
      console.log(`  Uptime: ${report.trends.last7Days.uptime}%`);
      console.log(`  Availability: ${report.trends.last7Days.availability}%`);
      console.log(`  Average Response Time: ${report.trends.last7Days.avgResponseTime}ms`);
      console.log(`  Critical Incidents: ${report.trends.last7Days.criticalIncidents}`);
      
      // Trend analysis
      const uptime24h = report.trends.last24Hours.uptime;
      const uptime7d = report.trends.last7Days.uptime;
      
      if (uptime24h > uptime7d) {
        console.log('\n📈 Uptime trend: Improving');
      } else if (uptime24h < uptime7d) {
        console.log('\n📉 Uptime trend: Declining');
      } else {
        console.log('\n➡️ Uptime trend: Stable');
      }
    } else {
      console.log('No historical data available yet');
    }
  } catch (error) {
    console.error('❌ Health trends analysis failed:', error);
  }
}

/**
 * Example 6: Health check configuration
 */
async function example6_HealthCheckConfiguration() {
  console.log('🔍 Health check configuration...\n');
  
  try {
    const config = getHealthCheckConfig();
    
    console.log('Health Check Configuration:');
    console.log(`Database Timeout: ${config.database.timeout}ms`);
    console.log(`Database Retries: ${config.database.retries}`);
    console.log(`AWS Timeout: ${config.aws.timeout}ms`);
    console.log(`System Check Interval: ${config.system.interval}ms`);
    console.log(`External Dependencies Timeout: ${config.external.timeout}ms`);
    console.log(`Max History Entries: ${config.history.maxEntries}`);
    console.log(`History Retention: ${config.history.retentionPeriod / (24 * 60 * 60 * 1000)} days`);
    
    console.log('\nConfigured External Dependencies:');
    config.externalDependencies.forEach((dep, index) => {
      console.log(`${index + 1}. ${dep.name}`);
      console.log(`   URL: ${dep.url}`);
      console.log(`   Timeout: ${dep.timeout}ms`);
      console.log(`   Critical: ${dep.critical ? 'Yes' : 'No'}`);
    });
    
    console.log(`\nCurrent History Size: ${config.historySize} entries`);
  } catch (error) {
    console.error('❌ Health check configuration retrieval failed:', error);
  }
}

/**
 * Example 7: Continuous monitoring with alerts
 */
async function example7_ContinuousMonitoring() {
  console.log('🔍 Starting continuous monitoring (will run 3 checks)...\n');
  
  let checksCompleted = 0;
  const maxChecks = 3;
  
  const monitoringInterval = setInterval(async () => {
    try {
      checksCompleted++;
      const health = await getCurrentHealthStatus();
      
      console.log(`Check ${checksCompleted}/${maxChecks} - Status: ${health.status.toUpperCase()}`);
      console.log(`  Time: ${new Date(health.timestamp).toLocaleTimeString()}`);
      console.log(`  Uptime: ${Math.round(health.uptime / 60)}min`);
      console.log(`  Services: ${health.summary.healthy}/${health.summary.total} healthy`);
      
      if (health.status === 'unhealthy') {
        console.log('  ⚠️  ALERT: System is unhealthy!');
        const unhealthyServices = [];
        if (health.checks.database.status === 'unhealthy') unhealthyServices.push('Database');
        if (health.checks.system.status === 'unhealthy') unhealthyServices.push('System');
        console.log(`  Unhealthy services: ${unhealthyServices.join(', ')}`);
      }
      
      if (checksCompleted >= maxChecks) {
        clearInterval(monitoringInterval);
        console.log('\n✅ Continuous monitoring completed');
      }
    } catch (error) {
      console.error('❌ Monitoring check failed:', error);
      clearInterval(monitoringInterval);
    }
  }, 5000); // Check every 5 seconds
}

/**
 * Example 8: Health check integration with application logic
 */
async function example8_ApplicationIntegration() {
  console.log('🔍 Demonstrating application integration...\n');
  
  try {
    // Example: Check if system is healthy before starting a scheduled task
    async function scheduledTask() {
      const health = await getCurrentHealthStatus();
      
      if (health.status === 'unhealthy') {
        console.log('❌ Skipping scheduled task: System unhealthy');
        return;
      }
      
      if (health.status === 'degraded') {
        console.log('⚠️  Proceeding with scheduled task: System degraded but operational');
      } else {
        console.log('✅ Proceeding with scheduled task: System healthy');
      }
      
      // Simulate task execution
      console.log('📋 Executing scheduled task...');
      console.log(`   Database: ${health.checks.database.status}`);
      console.log(`   System: ${health.checks.system.status}`);
      console.log(`   AWS: ${Object.values(health.checks.aws).map(s => s.status).join(', ')}`);
    }
    
    // Execute the task
    await scheduledTask();
    
    // Example: Health check after task completion
    const postTaskHealth = await getCurrentHealthStatus();
    console.log(`\nPost-task health status: ${postTaskHealth.status}`);
  } catch (error) {
    console.error('❌ Application integration example failed:', error);
  }
}

/**
 * Main function to run all examples
 */
async function runAllExamples() {
  console.log '='.repeat(60);
  console.log('🏥 HEALTH CHECK SYSTEM - USAGE EXAMPLES');
  console.log('='.repeat(60));
  
  const examples = [
    { name: 'Complete Health Check', func: example1_CompleteHealthCheck },
    { name: 'Specific Service Check', func: example2_SpecificServiceCheck },
    { name: 'System Resource Monitoring', func: example3_SystemResourceMonitoring },
    { name: 'Pre-Operation Health Check', func: example4_PreOperationHealthCheck },
    { name: 'Health Trends Analysis', func: example5_HealthTrends },
    { name: 'Configuration Overview', func: example6_HealthCheckConfiguration },
    { name: 'Continuous Monitoring', func: example7_ContinuousMonitoring },
    { name: 'Application Integration', func: example8_ApplicationIntegration }
  ];
  
  for (const example of examples) {
    console.log(`\n${'='.repeat(60)}`);
    console.log(`EXAMPLE: ${example.name}`);
    console.log('='.repeat(60));
    
    try {
      await example.func();
    } catch (error) {
      console.error(`❌ Example failed:`, error);
    }
    
    // Add delay between examples
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
  
  console.log(`\n${'='.repeat(60)}`);
  console.log('✅ All examples completed!');
  console.log('='.repeat(60));
}

// Export functions for individual use
export {
  example1_CompleteHealthCheck,
  example2_SpecificServiceCheck,
  example3_SystemResourceMonitoring,
  example4_PreOperationHealthCheck,
  example5_HealthTrends,
  example6_HealthCheckConfiguration,
  example7_ContinuousMonitoring,
  example8_ApplicationIntegration,
  runAllExamples
};

// Run examples if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runAllExamples().catch(console.error);
}