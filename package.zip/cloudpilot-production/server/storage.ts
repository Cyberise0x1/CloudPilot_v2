import { 
  type AwsAccount, 
  type SafeAwsAccount,
  type InsertAwsAccount,
  type User,
  type InsertUser,
  type Ec2Instance,
  type InsertEc2Instance,
  type S3Bucket,
  type InsertS3Bucket,
  type RdsInstance,
  type InsertRdsInstance,
  type CloudFrontDistribution,
  type InsertCloudFrontDistribution,
  type InstanceTemplate,
  type InsertInstanceTemplate,
  type AuditLog,
  type InsertAuditLog,
  type UpdateAuditLog,
  type AuditEvent,
  type InsertAuditEvent,
  type UpdateAuditEvent,
  type AuditSession,
  type InsertAuditSession,
  type UpdateAuditSession,
  users,
  refreshTokens,
  awsAccounts,
  ec2Instances,
  s3Buckets,
  rdsInstances,
  cloudFrontDistributions,
  instanceTemplates,
  auditLogs,
  auditEvents,
  auditSessions
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql, gte, lte, like, inArray } from "drizzle-orm";

// Audit context interface for preserving context across operations
export interface AuditContext {
  userId?: string;
  sessionId?: string;
  ipAddress?: string;
  userAgent?: string;
  correlationId?: string;
  metadata?: Record<string, any>;
  reason?: string;
  endpoint?: string;
  method?: string;
}

// Performance-optimized audit queue for batching audit logs
class AuditQueue {
  private queue: any[] = [];
  private flushing = false;
  private flushInterval: NodeJS.Timeout | null = null;
  private readonly flushSize = 50;
  private readonly flushIntervalMs = 5000; // 5 seconds

  constructor() {
    this.startFlushTimer();
  }

  addEntry(entry: any): void {
    this.queue.push(entry);
    
    // Auto-flush if queue reaches threshold
    if (this.queue.length >= this.flushSize) {
      this.flush();
    }
  }

  private startFlushTimer(): void {
    this.flushInterval = setInterval(() => {
      if (this.queue.length > 0) {
        this.flush();
      }
    }, this.flushIntervalMs);
  }

  async flush(): Promise<void> {
    if (this.flushing || this.queue.length === 0) {
      return;
    }

    this.flushing = true;
    const entriesToFlush = [...this.queue];
    this.queue = [];

    try {
      // Separate audit logs and events
      const auditLogsToInsert = entriesToFlush.filter(entry => entry.table === 'audit_logs');
      const auditEventsToInsert = entriesToFlush.filter(entry => entry.table === 'audit_events');

      // Batch insert audit logs
      if (auditLogsToInsert.length > 0) {
        await db.insert(auditLogs).values(
          auditLogsToInsert.map(entry => ({
            userId: entry.userId || null,
            action: entry.action,
            resourceType: entry.resourceType,
            resourceId: entry.resourceId,
            details: {
              oldValues: this.sanitizeSensitiveData(entry.oldValues),
              newValues: this.sanitizeSensitiveData(entry.newValues),
              metadata: entry.metadata,
              correlationId: entry.correlationId,
              reason: entry.reason
            },
            ipAddress: entry.ipAddress,
            userAgent: entry.userAgent,
            timestamp: new Date(),
            success: entry.success,
            errorMessage: entry.errorMessage
          }))
        );
      }

      // Batch insert audit events for critical operations
      if (auditEventsToInsert.length > 0) {
        await db.insert(auditEvents).values(
          auditEventsToInsert.map(entry => ({
            userId: entry.userId || null,
            sessionId: entry.sessionId || null,
            eventType: entry.action,
            eventCategory: entry.eventCategory || 'DATA_OPERATION',
            description: entry.description,
            severity: entry.severity || (entry.action === 'DELETE' ? 'warning' : 'info'),
            resourceType: entry.resourceType,
            resourceId: entry.resourceId,
            oldValues: this.sanitizeSensitiveData(entry.oldValues),
            newValues: this.sanitizeSensitiveData(entry.newValues),
            ipAddress: entry.ipAddress,
            userAgent: entry.userAgent,
            timestamp: new Date(),
            metadata: {
              correlationId: entry.correlationId,
              reason: entry.reason,
              ...entry.metadata
            }
          }))
        );
      }
    } catch (error) {
      console.error('Failed to flush audit logs:', error);
      // Put entries back in queue for retry (limit to prevent memory issues)
      if (this.queue.length < 1000) {
        this.queue.unshift(...entriesToFlush);
      }
    } finally {
      this.flushing = false;
    }
  }

  private sanitizeSensitiveData(data: any): any {
    if (!data) return data;
    
    const sanitized = { ...data };
    
    // Remove or mask sensitive fields
    const sensitiveFields = ['passwordHash', 'secretAccessKey', 'password', 'keyName', 'token'];
    for (const field of sensitiveFields) {
      if (sanitized[field]) {
        sanitized[field] = '[REDACTED]';
      }
    }
    
    return sanitized;
  }

  async shutdown(): Promise<void> {
    if (this.flushInterval) {
      clearInterval(this.flushInterval);
    }
    await this.flush();
  }
}

// Audit utility functions with performance optimization
export class AuditLogger {
  private static auditQueue = new AuditQueue();

  static setContext(context: AuditContext): void {
    // Store context in global state for the current operation
    (global as any).__auditContext = context;
  }

  static getContext(): AuditContext {
    return (global as any).__auditContext || {};
  }

  static generateCorrelationId(): string {
    return `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private static createAuditEntry(
    action: string,
    resourceType: string,
    resourceId: string,
    oldValues: any,
    newValues: any,
    context: AuditContext,
    success: boolean,
    errorMessage?: string,
    eventCategory?: string
  ): any {
    return {
      table: eventCategory ? 'audit_events' : 'audit_logs',
      action,
      resourceType,
      resourceId,
      oldValues,
      newValues,
      userId: context.userId,
      sessionId: context.sessionId,
      ipAddress: context.ipAddress,
      userAgent: context.userAgent,
      correlationId: context.correlationId || this.generateCorrelationId(),
      metadata: context.metadata,
      reason: context.reason,
      success,
      errorMessage,
      eventCategory,
      severity: action === 'DELETE' ? 'warning' : 'info',
      description: `${action} operation on ${resourceType}`,
      endpoint: context.endpoint,
      method: context.method
    };
  }

  static logOperation(
    action: string,
    resourceType: string,
    resourceId: string,
    oldValues?: any,
    newValues?: any,
    context?: AuditContext,
    success: boolean = true,
    errorMessage?: string
  ): void {
    const auditEntry = this.createAuditEntry(
      action,
      resourceType,
      resourceId,
      oldValues,
      newValues,
      context || this.getContext(),
      success,
      errorMessage
    );

    this.auditQueue.addEntry(auditEntry);
  }

  static async logCreate(
    resourceType: string,
    resourceId: string,
    newValues: any,
    context?: AuditContext
  ): Promise<void> {
    this.logOperation('CREATE', resourceType, resourceId, undefined, newValues, context);
  }

  static async logUpdate(
    resourceType: string,
    resourceId: string,
    oldValues: any,
    newValues: any,
    context?: AuditContext
  ): Promise<void> {
    this.logOperation('UPDATE', resourceType, resourceId, oldValues, newValues, context);
  }

  static async logDelete(
    resourceType: string,
    resourceId: string,
    oldValues: any,
    context?: AuditContext
  ): Promise<void> {
    this.logOperation('DELETE', resourceType, resourceId, oldValues, undefined, context);
  }

  static async logView(
    resourceType: string,
    resourceId: string,
    context?: AuditContext
  ): Promise<void> {
    this.logOperation('VIEW', resourceType, resourceId, undefined, undefined, context);
  }

  static async logError(
    resourceType: string,
    resourceId: string,
    error: Error,
    context?: AuditContext
  ): Promise<void> {
    this.logOperation('ERROR', resourceType, resourceId, undefined, undefined, context, false, error.message);
  }

  static async logSecurityEvent(
    action: string,
    resourceType: string,
    resourceId: string,
    description: string,
    severity: 'info' | 'warning' | 'error' | 'critical' = 'warning',
    context?: AuditContext
  ): Promise<void> {
    const auditEntry = this.createAuditEntry(
      action,
      resourceType,
      resourceId,
      undefined,
      undefined,
      context || this.getContext(),
      false,
      undefined,
      'SECURITY'
    );

    auditEntry.severity = severity;
    auditEntry.description = description;
    auditEntry.eventCategory = 'SECURITY';

    this.auditQueue.addEntry(auditEntry);
  }

  static async flush(): Promise<void> {
    await this.auditQueue.flush();
  }

  static async shutdown(): Promise<void> {
    await this.auditQueue.shutdown();
  }
}

export interface IStorage {
  // Audit context management
  setAuditContext(context: AuditContext): void;
  getAuditContext(): AuditContext;
  clearAuditContext(): void;
  
  // Audit operations
  flushAuditLogs(): Promise<void>;
  createSecurityAuditEvent(
    eventType: string,
    description: string,
    severity: 'info' | 'warning' | 'error' | 'critical',
    resourceType?: string,
    resourceId?: string
  ): Promise<void>;
  // Users
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserById(id: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, userData: Partial<InsertUser>): Promise<User>;
  deleteUser(id: string): Promise<void>;
  
  // Refresh Tokens
  createRefreshToken(userId: string, token: string, expiresAt: Date): Promise<void>;
  getRefreshToken(token: string): Promise<{ id: string; userId: string; token: string; expiresAt: Date } | undefined>;
  deleteRefreshToken(token: string): Promise<void>;
  deleteRefreshTokensByUserId(userId: string): Promise<void>;
  
  // AWS Accounts
  getAwsAccounts(): Promise<AwsAccount[]>;
  getSafeAwsAccounts(): Promise<SafeAwsAccount[]>;
  getAwsAccount(id: string): Promise<AwsAccount | undefined>;
  createAwsAccount(account: InsertAwsAccount): Promise<SafeAwsAccount>;
  activateAwsAccount(id: string): Promise<void>;
  
  // EC2 Instances
  getEc2Instances(): Promise<Ec2Instance[]>;
  getEc2InstancesByRegion(region: string, accountId: string): Promise<Ec2Instance[]>;
  upsertEc2Instance(instance: InsertEc2Instance): Promise<Ec2Instance>;
  updateInstanceName(instanceId: string, name: string): Promise<void>;
  
  // S3 Buckets
  getS3Buckets(): Promise<S3Bucket[]>;
  getS3BucketsByAccount(accountId: string): Promise<S3Bucket[]>;
  upsertS3Bucket(bucket: InsertS3Bucket): Promise<S3Bucket>;
  deleteS3Bucket(bucketName: string, accountId: string): Promise<void>;
  
  // RDS Instances
  getRdsInstances(): Promise<RdsInstance[]>;
  getRdsInstancesByAccount(accountId: string): Promise<RdsInstance[]>;
  getRdsInstancesByRegion(region: string, accountId: string): Promise<RdsInstance[]>;
  upsertRdsInstance(instance: InsertRdsInstance): Promise<RdsInstance>;
  deleteRdsInstance(dbInstanceIdentifier: string, accountId: string): Promise<void>;
  
  // CloudFront Distributions
  getCloudFrontDistributions(): Promise<CloudFrontDistribution[]>;
  getCloudFrontDistributionsByAccount(accountId: string): Promise<CloudFrontDistribution[]>;
  upsertCloudFrontDistribution(distribution: InsertCloudFrontDistribution): Promise<CloudFrontDistribution>;
  deleteCloudFrontDistribution(distributionId: string, accountId: string): Promise<void>;
  
  // Instance Templates
  getInstanceTemplates(): Promise<InstanceTemplate[]>;
  getInstanceTemplatesByAccount(accountId: string): Promise<InstanceTemplate[]>;
  getInstanceTemplate(id: string): Promise<InstanceTemplate | undefined>;
  createInstanceTemplate(template: InsertInstanceTemplate): Promise<InstanceTemplate>;
  updateInstanceTemplate(id: string, template: Partial<InsertInstanceTemplate>): Promise<InstanceTemplate>;
  deleteInstanceTemplate(id: string): Promise<void>;
  
  // Audit Logs
  getAuditLogs(filters?: {
    userId?: string;
    action?: string;
    resourceType?: string;
    resourceId?: string;
    success?: boolean;
    startDate?: Date;
    endDate?: Date;
    limit?: number;
    offset?: number;
  }): Promise<AuditLog[]>;
  getAuditLogById(id: string): Promise<AuditLog | undefined>;
  createAuditLog(log: InsertAuditLog): Promise<AuditLog>;
  updateAuditLog(id: string, updateData: Partial<UpdateAuditLog>): Promise<AuditLog>;
  deleteAuditLog(id: string): Promise<void>;
  getAuditLogsByUserId(userId: string, limit?: number): Promise<AuditLog[]>;
  getAuditLogsByResource(resourceType: string, resourceId: string): Promise<AuditLog[]>;
  getAuditLogsByDateRange(startDate: Date, endDate: Date): Promise<AuditLog[]>;
  getAuditStatistics(filters?: {
    startDate?: Date;
    endDate?: Date;
    userId?: string;
  }): Promise<{
    total: number;
    success: number;
    failed: number;
    byAction: Record<string, number>;
    byResource: Record<string, number>;
    byUser: Record<string, number>;
  }>;
  
  // Audit Events
  getAuditEvents(filters?: {
    userId?: string;
    eventType?: string;
    eventCategory?: string;
    severity?: string;
    resourceType?: string;
    resourceId?: string;
    startDate?: Date;
    endDate?: Date;
    limit?: number;
    offset?: number;
  }): Promise<AuditEvent[]>;
  getAuditEventById(id: string): Promise<AuditEvent | undefined>;
  createAuditEvent(event: InsertAuditEvent): Promise<AuditEvent>;
  updateAuditEvent(id: string, updateData: Partial<UpdateAuditEvent>): Promise<AuditEvent>;
  deleteAuditEvent(id: string): Promise<void>;
  getSecurityEvents(limit?: number): Promise<AuditEvent[]>;
  
  // Audit Sessions
  getAuditSessions(filters?: {
    userId?: string;
    isActive?: boolean;
    limit?: number;
    offset?: number;
  }): Promise<AuditSession[]>;
  getAuditSessionById(id: string): Promise<AuditSession | undefined>;
  getAuditSessionBySessionId(sessionId: string): Promise<AuditSession | undefined>;
  createAuditSession(session: InsertAuditSession): Promise<AuditSession>;
  updateAuditSession(id: string, updateData: Partial<UpdateAuditSession>): Promise<AuditSession>;
  deleteAuditSession(id: string): Promise<void>;
  endAuditSession(sessionId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  private currentAuditContext: AuditContext = {};

  // Audit context management
  setAuditContext(context: AuditContext): void {
    this.currentAuditContext = context;
    AuditLogger.setContext(context);
  }

  getAuditContext(): AuditContext {
    return this.currentAuditContext;
  }

  clearAuditContext(): void {
    this.currentAuditContext = {};
    AuditLogger.setContext({});
  }

  async flushAuditLogs(): Promise<void> {
    await AuditLogger.flush();
  }

  async createSecurityAuditEvent(
    eventType: string,
    description: string,
    severity: 'info' | 'warning' | 'error' | 'critical',
    resourceType?: string,
    resourceId?: string
  ): Promise<void> {
    await AuditLogger.logSecurityEvent(
      eventType,
      resourceType || 'system',
      resourceId || 'unknown',
      description,
      severity,
      this.currentAuditContext
    );
  }

  // Users
  async getUserByEmail(email: string): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.email, email));
      
      // Log successful read operation
      if (user) {
        await AuditLogger.logView('users', user.id, this.currentAuditContext);
      }
      
      return user || undefined;
    } catch (error) {
      await AuditLogger.logError('users', `email:${email}`, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async getUserById(id: string): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.id, id));
      
      if (user) {
        await AuditLogger.logView('users', user.id, this.currentAuditContext);
      }
      
      return user || undefined;
    } catch (error) {
      await AuditLogger.logError('users', id, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    try {
      const [user] = await db.insert(users)
        .values(insertUser)
        .returning();

      // Log successful creation
      await AuditLogger.logCreate('users', user.id, user, this.currentAuditContext);

      return user;
    } catch (error) {
      await AuditLogger.logError('users', 'new', error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async updateUser(id: string, updateData: Partial<InsertUser>): Promise<User> {
    try {
      // Get old values for audit trail
      const [oldUser] = await db.select().from(users).where(eq(users.id, id));
      
      if (!oldUser) {
        throw new Error(`User with id ${id} not found`);
      }

      const [updatedUser] = await db.update(users)
        .set({
          ...updateData,
          updatedAt: new Date(),
        })
        .where(eq(users.id, id))
        .returning();

      // Log successful update
      await AuditLogger.logUpdate('users', id, oldUser, updatedUser, this.currentAuditContext);

      return updatedUser;
    } catch (error) {
      await AuditLogger.logError('users', id, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async deleteUser(id: string): Promise<void> {
    try {
      // Get old values for audit trail
      const [oldUser] = await db.select().from(users).where(eq(users.id, id));
      
      if (!oldUser) {
        throw new Error(`User with id ${id} not found`);
      }

      await db.delete(users).where(eq(users.id, id));

      // Log successful deletion
      await AuditLogger.logDelete('users', id, oldUser, this.currentAuditContext);
    } catch (error) {
      await AuditLogger.logError('users', id, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  // Refresh Tokens
  async createRefreshToken(userId: string, token: string, expiresAt: Date): Promise<void> {
    try {
      await db.insert(refreshTokens)
        .values({
          userId,
          token,
          expiresAt,
        });

      // Log refresh token creation
      await AuditLogger.logOperation(
        'CREATE',
        'refresh_tokens',
        userId,
        undefined,
        { token: '[REDACTED]', expiresAt },
        this.currentAuditContext,
        true
      );
    } catch (error) {
      await AuditLogger.logError('refresh_tokens', userId, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async getRefreshToken(token: string): Promise<{ id: string; userId: string; token: string; expiresAt: Date } | undefined> {
    try {
      const [refreshToken] = await db.select()
        .from(refreshTokens)
        .where(eq(refreshTokens.token, token));

      if (refreshToken) {
        await AuditLogger.logView('refresh_tokens', refreshToken.id, this.currentAuditContext);
      }

      return refreshToken || undefined;
    } catch (error) {
      await AuditLogger.logError('refresh_tokens', `token:${token}`, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async deleteRefreshToken(token: string): Promise<void> {
    try {
      // Get old values for audit trail
      const [oldToken] = await db.select()
        .from(refreshTokens)
        .where(eq(refreshTokens.token, token));

      await db.delete(refreshTokens).where(eq(refreshTokens.token, token));

      if (oldToken) {
        await AuditLogger.logOperation(
          'DELETE',
          'refresh_tokens',
          oldToken.id,
          { token: '[REDACTED]' },
          undefined,
          this.currentAuditContext,
          true
        );
      }
    } catch (error) {
      await AuditLogger.logError('refresh_tokens', `token:${token}`, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async deleteRefreshTokensByUserId(userId: string): Promise<void> {
    try {
      const tokens = await db.select()
        .from(refreshTokens)
        .where(eq(refreshTokens.userId, userId));

      await db.delete(refreshTokens).where(eq(refreshTokens.userId, userId));

      // Log bulk deletion
      await AuditLogger.logOperation(
        'DELETE',
        'refresh_tokens',
        userId,
        { count: tokens.length, tokens: tokens.map(t => ({ id: t.id, token: '[REDACTED]' })) },
        undefined,
        this.currentAuditContext,
        true
      );
    } catch (error) {
      await AuditLogger.logError('refresh_tokens', `user:${userId}`, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  // AWS Accounts
  async getAwsAccounts(): Promise<AwsAccount[]> {
    try {
      const accounts = await db.select().from(awsAccounts);
      
      await AuditLogger.logOperation(
        'VIEW',
        'aws_accounts',
        'all',
        undefined,
        undefined,
        this.currentAuditContext,
        true
      );

      return accounts;
    } catch (error) {
      await AuditLogger.logError('aws_accounts', 'all', error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async getSafeAwsAccounts(): Promise<SafeAwsAccount[]> {
    try {
      const accounts = await db.select({
        id: awsAccounts.id,
        name: awsAccounts.name,
        isActive: awsAccounts.isActive,
        createdAt: awsAccounts.createdAt
      }).from(awsAccounts);

      await AuditLogger.logOperation(
        'VIEW',
        'aws_accounts',
        'safe',
        undefined,
        undefined,
        this.currentAuditContext,
        true
      );

      return accounts;
    } catch (error) {
      await AuditLogger.logError('aws_accounts', 'safe', error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async getAwsAccount(id: string): Promise<AwsAccount | undefined> {
    try {
      const [account] = await db.select().from(awsAccounts).where(eq(awsAccounts.id, id));
      
      if (account) {
        await AuditLogger.logView('aws_accounts', id, this.currentAuditContext);
      }

      return account || undefined;
    } catch (error) {
      await AuditLogger.logError('aws_accounts', id, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async createAwsAccount(insertAccount: InsertAwsAccount): Promise<SafeAwsAccount> {
    try {
      const [account] = await db
        .insert(awsAccounts)
        .values(insertAccount)
        .returning({
          id: awsAccounts.id,
          name: awsAccounts.name,
          isActive: awsAccounts.isActive,
          createdAt: awsAccounts.createdAt
        });

      // Log successful creation
      await AuditLogger.logCreate('aws_accounts', account.id, account, this.currentAuditContext);

      return account;
    } catch (error) {
      await AuditLogger.logError('aws_accounts', 'new', error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async activateAwsAccount(id: string): Promise<void> {
    try {
      // Get old values for audit trail
      const oldAccounts = await db.select().from(awsAccounts);
      const oldAccount = oldAccounts.find(acc => acc.id === id);

      // Deactivate all accounts first
      await db.update(awsAccounts).set({ isActive: false });
      
      // Activate the selected account
      const [updatedAccount] = await db.update(awsAccounts)
        .set({ isActive: true })
        .where(eq(awsAccounts.id, id))
        .returning();

      // Log activation
      await AuditLogger.logOperation(
        'UPDATE',
        'aws_accounts',
        id,
        { ...oldAccount, isActive: false },
        { ...updatedAccount, isActive: true },
        this.currentAuditContext,
        true
      );
    } catch (error) {
      await AuditLogger.logError('aws_accounts', `activate:${id}`, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  // EC2 Instances
  async getEc2Instances(): Promise<Ec2Instance[]> {
    try {
      const instances = await db.select().from(ec2Instances);
      
      await AuditLogger.logOperation(
        'VIEW',
        'ec2_instances',
        'all',
        undefined,
        undefined,
        this.currentAuditContext,
        true
      );

      return instances;
    } catch (error) {
      await AuditLogger.logError('ec2_instances', 'all', error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async getEc2InstancesByRegion(region: string, accountId: string): Promise<Ec2Instance[]> {
    try {
      const instances = await db.select()
        .from(ec2Instances)
        .where(and(
          eq(ec2Instances.region, region),
          eq(ec2Instances.accountId, accountId)
        ));

      await AuditLogger.logOperation(
        'VIEW',
        'ec2_instances',
        `${region}:${accountId}`,
        undefined,
        undefined,
        this.currentAuditContext,
        true
      );

      return instances;
    } catch (error) {
      await AuditLogger.logError('ec2_instances', `${region}:${accountId}`, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async upsertEc2Instance(insertInstance: InsertEc2Instance): Promise<Ec2Instance> {
    try {
      const existingInstances = await db.select()
        .from(ec2Instances)
        .where(eq(ec2Instances.instanceId, insertInstance.instanceId));

      if (existingInstances.length > 0) {
        // Update existing instance
        const [updatedInstance] = await db.update(ec2Instances)
          .set({
            ...insertInstance,
            lastUpdated: new Date(),
          })
          .where(eq(ec2Instances.instanceId, insertInstance.instanceId))
          .returning();

        // Log successful update
        await AuditLogger.logUpdate(
          'ec2_instances', 
          updatedInstance.id, 
          existingInstances[0], 
          updatedInstance, 
          this.currentAuditContext
        );

        return updatedInstance;
      } else {
        // Insert new instance
        const [newInstance] = await db.insert(ec2Instances)
          .values({
            ...insertInstance,
            id: insertInstance.instanceId,
            lastUpdated: new Date(),
          })
          .returning();

        // Log successful creation
        await AuditLogger.logCreate('ec2_instances', newInstance.id, newInstance, this.currentAuditContext);

        return newInstance;
      }
    } catch (error) {
      await AuditLogger.logError('ec2_instances', insertInstance.instanceId, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async updateInstanceName(instanceId: string, name: string): Promise<void> {
    try {
      // Get old values for audit trail
      const [oldInstance] = await db.select()
        .from(ec2Instances)
        .where(eq(ec2Instances.instanceId, instanceId));

      await db.update(ec2Instances)
        .set({ 
          name: name,
          lastUpdated: new Date()
        })
        .where(eq(ec2Instances.instanceId, instanceId));

      // Get updated instance for audit trail
      const [updatedInstance] = await db.select()
        .from(ec2Instances)
        .where(eq(ec2Instances.instanceId, instanceId));

      // Log successful update
      await AuditLogger.logUpdate(
        'ec2_instances', 
        instanceId, 
        oldInstance, 
        updatedInstance, 
        this.currentAuditContext
      );
    } catch (error) {
      await AuditLogger.logError('ec2_instances', `name:${instanceId}`, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  // S3 Buckets
  async getS3Buckets(): Promise<S3Bucket[]> {
    try {
      const buckets = await db.select().from(s3Buckets);
      
      await AuditLogger.logOperation(
        'VIEW',
        's3_buckets',
        'all',
        undefined,
        undefined,
        this.currentAuditContext,
        true
      );

      return buckets;
    } catch (error) {
      await AuditLogger.logError('s3_buckets', 'all', error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async getS3BucketsByAccount(accountId: string): Promise<S3Bucket[]> {
    try {
      const buckets = await db.select()
        .from(s3Buckets)
        .where(eq(s3Buckets.accountId, accountId));

      await AuditLogger.logOperation(
        'VIEW',
        's3_buckets',
        `account:${accountId}`,
        undefined,
        undefined,
        this.currentAuditContext,
        true
      );

      return buckets;
    } catch (error) {
      await AuditLogger.logError('s3_buckets', `account:${accountId}`, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async upsertS3Bucket(insertBucket: InsertS3Bucket): Promise<S3Bucket> {
    try {
      const existingBuckets = await db.select()
        .from(s3Buckets)
        .where(and(
          eq(s3Buckets.name, insertBucket.name),
          eq(s3Buckets.accountId, insertBucket.accountId || "")
        ));

      if (existingBuckets.length > 0) {
        // Update existing bucket
        const [updatedBucket] = await db.update(s3Buckets)
          .set({
            ...insertBucket,
            lastUpdated: new Date(),
          })
          .where(and(
            eq(s3Buckets.name, insertBucket.name),
            eq(s3Buckets.accountId, insertBucket.accountId || "")
          ))
          .returning();

        // Log successful update
        await AuditLogger.logUpdate(
          's3_buckets', 
          updatedBucket.id, 
          existingBuckets[0], 
          updatedBucket, 
          this.currentAuditContext
        );

        return updatedBucket;
      } else {
        // Insert new bucket
        const [newBucket] = await db.insert(s3Buckets)
          .values({
            ...insertBucket,
            lastUpdated: new Date(),
          })
          .returning();

        // Log successful creation
        await AuditLogger.logCreate('s3_buckets', newBucket.id, newBucket, this.currentAuditContext);

        return newBucket;
      }
    } catch (error) {
      await AuditLogger.logError('s3_buckets', insertBucket.name, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async deleteS3Bucket(bucketName: string, accountId: string): Promise<void> {
    try {
      // Get old values for audit trail
      const [oldBucket] = await db.select()
        .from(s3Buckets)
        .where(and(
          eq(s3Buckets.name, bucketName),
          eq(s3Buckets.accountId, accountId)
        ));

      await db.delete(s3Buckets)
        .where(and(
          eq(s3Buckets.name, bucketName),
          eq(s3Buckets.accountId, accountId)
        ));

      // Log successful deletion
      if (oldBucket) {
        await AuditLogger.logDelete('s3_buckets', oldBucket.id, oldBucket, this.currentAuditContext);
      }
    } catch (error) {
      await AuditLogger.logError('s3_buckets', `${bucketName}:${accountId}`, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  // RDS Instances
  async getRdsInstances(): Promise<RdsInstance[]> {
    try {
      const instances = await db.select().from(rdsInstances);
      
      await AuditLogger.logOperation(
        'VIEW',
        'rds_instances',
        'all',
        undefined,
        undefined,
        this.currentAuditContext,
        true
      );

      return instances;
    } catch (error) {
      await AuditLogger.logError('rds_instances', 'all', error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async getRdsInstancesByAccount(accountId: string): Promise<RdsInstance[]> {
    try {
      const instances = await db.select()
        .from(rdsInstances)
        .where(eq(rdsInstances.accountId, accountId));

      await AuditLogger.logOperation(
        'VIEW',
        'rds_instances',
        `account:${accountId}`,
        undefined,
        undefined,
        this.currentAuditContext,
        true
      );

      return instances;
    } catch (error) {
      await AuditLogger.logError('rds_instances', `account:${accountId}`, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async getRdsInstancesByRegion(region: string, accountId: string): Promise<RdsInstance[]> {
    try {
      const instances = await db.select()
        .from(rdsInstances)
        .where(and(
          eq(rdsInstances.region, region),
          eq(rdsInstances.accountId, accountId)
        ));

      await AuditLogger.logOperation(
        'VIEW',
        'rds_instances',
        `${region}:${accountId}`,
        undefined,
        undefined,
        this.currentAuditContext,
        true
      );

      return instances;
    } catch (error) {
      await AuditLogger.logError('rds_instances', `${region}:${accountId}`, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async upsertRdsInstance(insertInstance: InsertRdsInstance): Promise<RdsInstance> {
    try {
      const existingInstances = await db.select()
        .from(rdsInstances)
        .where(and(
          eq(rdsInstances.dbInstanceIdentifier, insertInstance.dbInstanceIdentifier),
          eq(rdsInstances.region, insertInstance.region),
          eq(rdsInstances.accountId, insertInstance.accountId || "")
        ));

      if (existingInstances.length > 0) {
        // Update existing instance
        const [updatedInstance] = await db.update(rdsInstances)
          .set({
            ...insertInstance,
            lastUpdated: new Date(),
          })
          .where(and(
            eq(rdsInstances.dbInstanceIdentifier, insertInstance.dbInstanceIdentifier),
            eq(rdsInstances.region, insertInstance.region),
            eq(rdsInstances.accountId, insertInstance.accountId || "")
          ))
          .returning();

        // Log successful update
        await AuditLogger.logUpdate(
          'rds_instances', 
          updatedInstance.id, 
          existingInstances[0], 
          updatedInstance, 
          this.currentAuditContext
        );

        return updatedInstance;
      } else {
        // Insert new instance
        const [newInstance] = await db.insert(rdsInstances)
          .values({
            ...insertInstance,
            lastUpdated: new Date(),
          })
          .returning();

        // Log successful creation
        await AuditLogger.logCreate('rds_instances', newInstance.id, newInstance, this.currentAuditContext);

        return newInstance;
      }
    } catch (error) {
      await AuditLogger.logError('rds_instances', insertInstance.dbInstanceIdentifier, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async deleteRdsInstance(dbInstanceIdentifier: string, accountId: string): Promise<void> {
    try {
      // Get old values for audit trail
      const [oldInstance] = await db.select()
        .from(rdsInstances)
        .where(and(
          eq(rdsInstances.dbInstanceIdentifier, dbInstanceIdentifier),
          eq(rdsInstances.accountId, accountId)
        ));

      await db.delete(rdsInstances)
        .where(and(
          eq(rdsInstances.dbInstanceIdentifier, dbInstanceIdentifier),
          eq(rdsInstances.accountId, accountId)
        ));

      // Log successful deletion
      if (oldInstance) {
        await AuditLogger.logDelete('rds_instances', oldInstance.id, oldInstance, this.currentAuditContext);
      }
    } catch (error) {
      await AuditLogger.logError('rds_instances', `${dbInstanceIdentifier}:${accountId}`, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  // CloudFront Distributions
  async getCloudFrontDistributions(): Promise<CloudFrontDistribution[]> {
    try {
      const distributions = await db.select().from(cloudFrontDistributions);
      
      await AuditLogger.logOperation(
        'VIEW',
        'cloudfront_distributions',
        'all',
        undefined,
        undefined,
        this.currentAuditContext,
        true
      );

      return distributions;
    } catch (error) {
      await AuditLogger.logError('cloudfront_distributions', 'all', error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async getCloudFrontDistributionsByAccount(accountId: string): Promise<CloudFrontDistribution[]> {
    try {
      const distributions = await db.select()
        .from(cloudFrontDistributions)
        .where(eq(cloudFrontDistributions.accountId, accountId));

      await AuditLogger.logOperation(
        'VIEW',
        'cloudfront_distributions',
        `account:${accountId}`,
        undefined,
        undefined,
        this.currentAuditContext,
        true
      );

      return distributions;
    } catch (error) {
      await AuditLogger.logError('cloudfront_distributions', `account:${accountId}`, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async upsertCloudFrontDistribution(insertDistribution: InsertCloudFrontDistribution): Promise<CloudFrontDistribution> {
    try {
      const existingDistributions = await db.select()
        .from(cloudFrontDistributions)
        .where(and(
          eq(cloudFrontDistributions.distributionId, insertDistribution.distributionId),
          eq(cloudFrontDistributions.accountId, insertDistribution.accountId || "")
        ));

      if (existingDistributions.length > 0) {
        // Update existing distribution
        const [updatedDistribution] = await db.update(cloudFrontDistributions)
          .set({
            ...insertDistribution,
            lastUpdated: new Date(),
          })
          .where(and(
            eq(cloudFrontDistributions.distributionId, insertDistribution.distributionId),
            eq(cloudFrontDistributions.accountId, insertDistribution.accountId || "")
          ))
          .returning();

        // Log successful update
        await AuditLogger.logUpdate(
          'cloudfront_distributions', 
          updatedDistribution.id, 
          existingDistributions[0], 
          updatedDistribution, 
          this.currentAuditContext
        );

        return updatedDistribution;
      } else {
        // Insert new distribution
        const [newDistribution] = await db.insert(cloudFrontDistributions)
          .values({
            ...insertDistribution,
            lastUpdated: new Date(),
          })
          .returning();

        // Log successful creation
        await AuditLogger.logCreate('cloudfront_distributions', newDistribution.id, newDistribution, this.currentAuditContext);

        return newDistribution;
      }
    } catch (error) {
      await AuditLogger.logError('cloudfront_distributions', insertDistribution.distributionId, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async deleteCloudFrontDistribution(distributionId: string, accountId: string): Promise<void> {
    try {
      // Get old values for audit trail
      const [oldDistribution] = await db.select()
        .from(cloudFrontDistributions)
        .where(and(
          eq(cloudFrontDistributions.distributionId, distributionId),
          eq(cloudFrontDistributions.accountId, accountId)
        ));

      await db.delete(cloudFrontDistributions)
        .where(and(
          eq(cloudFrontDistributions.distributionId, distributionId),
          eq(cloudFrontDistributions.accountId, accountId)
        ));

      // Log successful deletion
      if (oldDistribution) {
        await AuditLogger.logDelete('cloudfront_distributions', oldDistribution.id, oldDistribution, this.currentAuditContext);
      }
    } catch (error) {
      await AuditLogger.logError('cloudfront_distributions', `${distributionId}:${accountId}`, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  // Instance Templates
  async getInstanceTemplates(): Promise<InstanceTemplate[]> {
    try {
      const templates = await db.select().from(instanceTemplates);
      
      await AuditLogger.logOperation(
        'VIEW',
        'instance_templates',
        'all',
        undefined,
        undefined,
        this.currentAuditContext,
        true
      );

      return templates;
    } catch (error) {
      await AuditLogger.logError('instance_templates', 'all', error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async getInstanceTemplatesByAccount(accountId: string): Promise<InstanceTemplate[]> {
    try {
      const templates = await db.select()
        .from(instanceTemplates)
        .where(eq(instanceTemplates.accountId, accountId));

      await AuditLogger.logOperation(
        'VIEW',
        'instance_templates',
        `account:${accountId}`,
        undefined,
        undefined,
        this.currentAuditContext,
        true
      );

      return templates;
    } catch (error) {
      await AuditLogger.logError('instance_templates', `account:${accountId}`, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async getInstanceTemplate(id: string): Promise<InstanceTemplate | undefined> {
    try {
      const [template] = await db.select()
        .from(instanceTemplates)
        .where(eq(instanceTemplates.id, id));
        
      if (template) {
        await AuditLogger.logView('instance_templates', id, this.currentAuditContext);
      }

      return template || undefined;
    } catch (error) {
      await AuditLogger.logError('instance_templates', id, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async createInstanceTemplate(insertTemplate: InsertInstanceTemplate): Promise<InstanceTemplate> {
    try {
      const [template] = await db.insert(instanceTemplates)
        .values(insertTemplate)
        .returning();

      // Log successful creation
      await AuditLogger.logCreate('instance_templates', template.id, template, this.currentAuditContext);

      return template;
    } catch (error) {
      await AuditLogger.logError('instance_templates', 'new', error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async updateInstanceTemplate(id: string, updateData: Partial<InsertInstanceTemplate>): Promise<InstanceTemplate> {
    try {
      // Get old values for audit trail
      const [oldTemplate] = await db.select()
        .from(instanceTemplates)
        .where(eq(instanceTemplates.id, id));

      if (!oldTemplate) {
        throw new Error(`Template with id ${id} not found`);
      }

      const [updatedTemplate] = await db.update(instanceTemplates)
        .set(updateData)
        .where(eq(instanceTemplates.id, id))
        .returning();

      // Log successful update
      await AuditLogger.logUpdate(
        'instance_templates', 
        id, 
        oldTemplate, 
        updatedTemplate, 
        this.currentAuditContext
      );

      return updatedTemplate;
    } catch (error) {
      await AuditLogger.logError('instance_templates', id, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  async deleteInstanceTemplate(id: string): Promise<void> {
    try {
      // Get old values for audit trail
      const [oldTemplate] = await db.select()
        .from(instanceTemplates)
        .where(eq(instanceTemplates.id, id));

      if (!oldTemplate) {
        throw new Error(`Template with id ${id} not found`);
      }

      await db.delete(instanceTemplates)
        .where(eq(instanceTemplates.id, id));

      // Log successful deletion
      await AuditLogger.logDelete('instance_templates', id, oldTemplate, this.currentAuditContext);
    } catch (error) {
      await AuditLogger.logError('instance_templates', id, error as Error, this.currentAuditContext);
      throw error;
    }
  }

  // Audit Logs
  async getAuditLogs(filters?: {
    userId?: string;
    action?: string;
    resourceType?: string;
    resourceId?: string;
    success?: boolean;
    startDate?: Date;
    endDate?: Date;
    limit?: number;
    offset?: number;
  }): Promise<AuditLog[]> {
    const conditions = [];
    
    if (filters?.userId) {
      conditions.push(eq(auditLogs.userId, filters.userId));
    }
    if (filters?.action) {
      conditions.push(eq(auditLogs.action, filters.action));
    }
    if (filters?.resourceType) {
      conditions.push(eq(auditLogs.resourceType, filters.resourceType));
    }
    if (filters?.resourceId) {
      conditions.push(eq(auditLogs.resourceId, filters.resourceId));
    }
    if (filters?.success !== undefined) {
      conditions.push(eq(auditLogs.success, filters.success));
    }
    if (filters?.startDate) {
      conditions.push(gte(auditLogs.timestamp, filters.startDate));
    }
    if (filters?.endDate) {
      conditions.push(lte(auditLogs.timestamp, filters.endDate));
    }

    const query = db.select()
      .from(auditLogs)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(auditLogs.timestamp))
      .limit(filters?.limit || 100)
      .offset(filters?.offset || 0);

    return await query;
  }

  async getAuditLogById(id: string): Promise<AuditLog | undefined> {
    const [log] = await db.select().from(auditLogs).where(eq(auditLogs.id, id));
    return log || undefined;
  }

  async createAuditLog(log: InsertAuditLog): Promise<AuditLog> {
    const [newLog] = await db.insert(auditLogs)
      .values(log)
      .returning();
    return newLog;
  }

  async updateAuditLog(id: string, updateData: Partial<UpdateAuditLog>): Promise<AuditLog> {
    const [updatedLog] = await db.update(auditLogs)
      .set(updateData)
      .where(eq(auditLogs.id, id))
      .returning();
    return updatedLog;
  }

  async deleteAuditLog(id: string): Promise<void> {
    await db.delete(auditLogs).where(eq(auditLogs.id, id));
  }

  async getAuditLogsByUserId(userId: string, limit: number = 50): Promise<AuditLog[]> {
    return await db.select()
      .from(auditLogs)
      .where(eq(auditLogs.userId, userId))
      .orderBy(desc(auditLogs.timestamp))
      .limit(limit);
  }

  async getAuditLogsByResource(resourceType: string, resourceId: string): Promise<AuditLog[]> {
    return await db.select()
      .from(auditLogs)
      .where(and(
        eq(auditLogs.resourceType, resourceType),
        eq(auditLogs.resourceId, resourceId)
      ))
      .orderBy(desc(auditLogs.timestamp));
  }

  async getAuditLogsByDateRange(startDate: Date, endDate: Date): Promise<AuditLog[]> {
    return await db.select()
      .from(auditLogs)
      .where(and(
        gte(auditLogs.timestamp, startDate),
        lte(auditLogs.timestamp, endDate)
      ))
      .orderBy(desc(auditLogs.timestamp));
  }

  async getAuditStatistics(filters?: {
    startDate?: Date;
    endDate?: Date;
    userId?: string;
  }): Promise<{
    total: number;
    success: number;
    failed: number;
    byAction: Record<string, number>;
    byResource: Record<string, number>;
    byUser: Record<string, number>;
  }> {
    const conditions = [];
    
    if (filters?.startDate) {
      conditions.push(gte(auditLogs.timestamp, filters.startDate));
    }
    if (filters?.endDate) {
      conditions.push(lte(auditLogs.timestamp, filters.endDate));
    }
    if (filters?.userId) {
      conditions.push(eq(auditLogs.userId, filters.userId));
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    // Get total count
    const totalResult = await db.select({ count: sql<number>`count(*)` })
      .from(auditLogs)
      .where(whereClause);
    const total = totalResult[0].count;

    // Get success/failed counts
    const successResult = await db.select({ count: sql<number>`count(*)` })
      .from(auditLogs)
      .where(and(whereClause, eq(auditLogs.success, true)));
    const success = successResult[0].count;

    const failedResult = await db.select({ count: sql<number>`count(*)` })
      .from(auditLogs)
      .where(and(whereClause, eq(auditLogs.success, false)));
    const failed = failedResult[0].count;

    // Get counts by action
    const byActionResult = await db.select({
      action: auditLogs.action,
      count: sql<number>`count(*)`
    })
      .from(auditLogs)
      .where(whereClause)
      .groupBy(auditLogs.action);

    const byAction: Record<string, number> = {};
    byActionResult.forEach(row => {
      byAction[row.action] = Number(row.count);
    });

    // Get counts by resource
    const byResourceResult = await db.select({
      resourceType: auditLogs.resourceType,
      count: sql<number>`count(*)`
    })
      .from(auditLogs)
      .where(whereClause)
      .groupBy(auditLogs.resourceType);

    const byResource: Record<string, number> = {};
    byResourceResult.forEach(row => {
      byResource[row.resourceType] = Number(row.count);
    });

    // Get counts by user
    const byUserResult = await db.select({
      userId: auditLogs.userId,
      count: sql<number>`count(*)`
    })
      .from(auditLogs)
      .where(whereClause)
      .groupBy(auditLogs.userId);

    const byUser: Record<string, number> = {};
    byUserResult.forEach(row => {
      if (row.userId) {
        byUser[row.userId] = Number(row.count);
      }
    });

    return {
      total,
      success,
      failed,
      byAction,
      byResource,
      byUser
    };
  }

  // Audit Events
  async getAuditEvents(filters?: {
    userId?: string;
    eventType?: string;
    eventCategory?: string;
    severity?: string;
    resourceType?: string;
    resourceId?: string;
    startDate?: Date;
    endDate?: Date;
    limit?: number;
    offset?: number;
  }): Promise<AuditEvent[]> {
    const conditions = [];
    
    if (filters?.userId) {
      conditions.push(eq(auditEvents.userId, filters.userId));
    }
    if (filters?.eventType) {
      conditions.push(eq(auditEvents.eventType, filters.eventType));
    }
    if (filters?.eventCategory) {
      conditions.push(eq(auditEvents.eventCategory, filters.eventCategory));
    }
    if (filters?.severity) {
      conditions.push(eq(auditEvents.severity, filters.severity as any));
    }
    if (filters?.resourceType) {
      conditions.push(eq(auditEvents.resourceType, filters.resourceType));
    }
    if (filters?.resourceId) {
      conditions.push(eq(auditEvents.resourceId, filters.resourceId));
    }
    if (filters?.startDate) {
      conditions.push(gte(auditEvents.timestamp, filters.startDate));
    }
    if (filters?.endDate) {
      conditions.push(lte(auditEvents.timestamp, filters.endDate));
    }

    const query = db.select()
      .from(auditEvents)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(auditEvents.timestamp))
      .limit(filters?.limit || 100)
      .offset(filters?.offset || 0);

    return await query;
  }

  async getAuditEventById(id: string): Promise<AuditEvent | undefined> {
    const [event] = await db.select().from(auditEvents).where(eq(auditEvents.id, id));
    return event || undefined;
  }

  async createAuditEvent(event: InsertAuditEvent): Promise<AuditEvent> {
    const [newEvent] = await db.insert(auditEvents)
      .values(event)
      .returning();
    return newEvent;
  }

  async updateAuditEvent(id: string, updateData: Partial<UpdateAuditEvent>): Promise<AuditEvent> {
    const [updatedEvent] = await db.update(auditEvents)
      .set(updateData)
      .where(eq(auditEvents.id, id))
      .returning();
    return updatedEvent;
  }

  async deleteAuditEvent(id: string): Promise<void> {
    await db.delete(auditEvents).where(eq(auditEvents.id, id));
  }

  async getSecurityEvents(limit: number = 50): Promise<AuditEvent[]> {
    return await db.select()
      .from(auditEvents)
      .where(eq(auditEvents.eventCategory, 'SECURITY'))
      .orderBy(desc(auditEvents.timestamp))
      .limit(limit);
  }

  // Audit Sessions
  async getAuditSessions(filters?: {
    userId?: string;
    isActive?: boolean;
    limit?: number;
    offset?: number;
  }): Promise<AuditSession[]> {
    const conditions = [];
    
    if (filters?.userId) {
      conditions.push(eq(auditSessions.userId, filters.userId));
    }
    if (filters?.isActive !== undefined) {
      conditions.push(eq(auditSessions.isActive, filters.isActive));
    }

    const query = db.select()
      .from(auditSessions)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(auditSessions.lastActivity))
      .limit(filters?.limit || 100)
      .offset(filters?.offset || 0);

    return await query;
  }

  async getAuditSessionById(id: string): Promise<AuditSession | undefined> {
    const [session] = await db.select().from(auditSessions).where(eq(auditSessions.id, id));
    return session || undefined;
  }

  async getAuditSessionBySessionId(sessionId: string): Promise<AuditSession | undefined> {
    const [session] = await db.select().from(auditSessions).where(eq(auditSessions.sessionId, sessionId));
    return session || undefined;
  }

  async createAuditSession(session: InsertAuditSession): Promise<AuditSession> {
    const [newSession] = await db.insert(auditSessions)
      .values(session)
      .returning();
    return newSession;
  }

  async updateAuditSession(id: string, updateData: Partial<UpdateAuditSession>): Promise<AuditSession> {
    const [updatedSession] = await db.update(auditSessions)
      .set(updateData)
      .where(eq(auditSessions.id, id))
      .returning();
    return updatedSession;
  }

  async deleteAuditSession(id: string): Promise<void> {
    await db.delete(auditSessions).where(eq(auditSessions.id, id));
  }

  async endAuditSession(sessionId: string): Promise<void> {
    await db.update(auditSessions)
      .set({ 
        isActive: false,
        logoutTime: new Date(),
        lastActivity: new Date()
      })
      .where(eq(auditSessions.sessionId, sessionId));
  }
}

export const storage = new DatabaseStorage();

// Graceful shutdown handler for audit logs
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, flushing audit logs before shutdown...');
  await AuditLogger.shutdown();
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, flushing audit logs before shutdown...');
  await AuditLogger.shutdown();
});

// Handle uncaught exceptions and unhandled promise rejections
process.on('uncaughtException', async (error) => {
  console.error('Uncaught exception:', error);
  await AuditLogger.shutdown();
  process.exit(1);
});

process.on('unhandledRejection', async (reason, promise) => {
  console.error('Unhandled rejection at:', promise, 'reason:', reason);
  await AuditLogger.shutdown();
  process.exit(1);
});
