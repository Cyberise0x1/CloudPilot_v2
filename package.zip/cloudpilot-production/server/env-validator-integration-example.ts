/**
 * Example: How to integrate env-validator with your CloudPilot application
 * 
 * This file demonstrates how to replace the current environment variable
 * handling with the comprehensive env-validator module.
 */

import { validateConfig, printConfigSummary } from './env-validator';
import { Pool } from '@neondatabase/serverless';
import { drizzle } from 'drizzle-orm/neon-serverless';
import ws from "ws";
import * as schema from "@shared/schema";
import express, { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

// ========================
// BEFORE: Current approach (scattered validation)
// ========================
//
// Issues with current approach:
// - Validation is scattered across multiple files
// - No comprehensive checking
// - Poor error messages
// - No type safety
// - Difficult to maintain

/*
if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  console.error("ERROR: JWT_SECRET environment variable is required but not set");
  console.error("Please set JWT_SECRET in your .env file or environment variables");
  process.exit(1);
}

const port = parseInt(process.env.PORT || '5000', 10);
*/

// ========================
// AFTER: Using env-validator
// ========================

// Step 1: Validate all environment variables at startup
const config = validateConfig();

// Step 2: Use the validated configuration throughout your app
// This provides type safety and guarantees the values are valid

// Database setup with validated config
neonConfig.webSocketConstructor = ws;

export const pool = new Pool({ 
  connectionString: config.database.url,
  ssl: config.database.ssl ? { rejectUnauthorized: false } : undefined
});

export const db = drizzle({ client: pool, schema });

// JWT configuration with validated values
const JWT_SECRET = config.jwt.secret;
const JWT_EXPIRES_IN = config.jwt.expiresIn;
const JWT_REFRESH_EXPIRES_IN = config.jwt.refreshExpiresIn;

// Server configuration
const PORT = config.server.port;
const NODE_ENV = config.server.nodeEnv;

// AWS configuration (if provided)
const AWS_ACCESS_KEY_ID = config.aws.accessKeyId;
const AWS_SECRET_ACCESS_KEY = config.aws.secretAccessKey;
const AWS_DEFAULT_REGION = config.aws.defaultRegion;

// Auth rate limiting configuration
const AUTH_RATE_LIMIT_WINDOW = config.auth.rateLimitWindow;
const AUTH_RATE_LIMIT_MAX = config.auth.rateLimitMax;

// Example: Generate JWT tokens using validated configuration
export const generateAccessToken = (user: { id: string; email: string; username: string }): string => {
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      username: user.username,
    },
    JWT_SECRET,
    {
      expiresIn: JWT_EXPIRES_IN,
      issuer: 'cloudpilot',
      audience: 'cloudpilot-api',
    }
  );
};

// Example: Express app setup using validated config
export const createApp = () => {
  const app = express();
  
  app.use(express.json());
  app.use(express.urlencoded({ extended: false }));

  // Use the validated port
  app.set('port', PORT);
  app.set('env', NODE_ENV);

  // Add your routes here using the validated configuration
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({
      status: 'healthy',
      environment: NODE_ENV,
      port: PORT,
      timestamp: new Date().toISOString()
    });
  });

  return app;
};

// Example: Environment-specific initialization
export const initializeApp = async () => {
  // In development, print configuration summary (with masked sensitive data)
  if (NODE_ENV === 'development') {
    printConfigSummary(config);
  }

  // Additional environment-specific setup
  if (NODE_ENV === 'production') {
    // Production-specific validations
    console.log('🚀 Starting in production mode');
    
    if (!AWS_ACCESS_KEY_ID) {
      console.warn('⚠️  AWS credentials not configured');
    }
  }

  if (NODE_ENV === 'development') {
    console.log('🔧 Starting in development mode');
  }

  // Initialize your application here
  const app = createApp();
  
  return app;
};

// Example: AWS service integration with validated config
export const createAwsService = () => {
  if (AWS_ACCESS_KEY_ID && AWS_SECRET_ACCESS_KEY) {
    return {
      accessKeyId: AWS_ACCESS_KEY_ID,
      secretAccessKey: AWS_SECRET_ACCESS_KEY,
      region: AWS_DEFAULT_REGION
    };
  }
  
  return null; // AWS not configured
};

// Example: Middleware that uses validated config
export const createRateLimitingMiddleware = () => {
  return (req: Request, res: Response, next: NextFunction) => {
    // Use the validated rate limiting configuration
    const windowMs = AUTH_RATE_LIMIT_WINDOW;
    const maxAttempts = AUTH_RATE_LIMIT_MAX;
    
    // Your rate limiting logic here
    console.log(`Rate limit: ${maxAttempts} attempts per ${windowMs}ms window`);
    
    next();
  };
};

// Example: Main server initialization
export const startServer = async () => {
  try {
    const app = await initializeApp();
    
    const server = app.listen(PORT, "0.0.0.0", () => {
      console.log(`✅ Server started successfully on port ${PORT}`);
      console.log(`🌍 Environment: ${NODE_ENV}`);
      console.log(`🔐 JWT Token Expiry: ${JWT_EXPIRES_IN}`);
      console.log(`🔄 JWT Refresh Expiry: ${JWT_REFRESH_EXPIRES_IN}`);
      
      if (NODE_ENV === 'development') {
        console.log('\n💡 Development Tips:');
        console.log('  - Check /api/health for server status');
        console.log('  - Use env-validator-usage.md for configuration help');
      }
    });

    return server;
  } catch (error) {
    console.error('❌ Failed to start server:', error);
    process.exit(1);
  }
};

// Example: Migration script using validated config
export const runMigrations = async () => {
  console.log('🔄 Running database migrations...');
  
  try {
    // Your migration logic here
    // Use config.database.url for the connection
    console.log('✅ Migrations completed successfully');
  } catch (error) {
    console.error('❌ Migration failed:', error);
    process.exit(1);
  }
};

// Example: Testing with validated config
export const createTestConfig = () => {
  return {
    ...config,
    server: {
      ...config.server,
      nodeEnv: 'test' as const
    }
  };
};

// Export the validated config for use in other modules
export { config };

// Default export with all utilities
export default {
  // Configuration
  config,
  
  // Functions
  validateConfig,
  printConfigSummary,
  
  // Setup functions
  createApp,
  initializeApp,
  startServer,
  
  // Service creators
  createAwsService,
  createRateLimitingMiddleware,
  
  // Utilities
  createTestConfig
};

/*
Migration Guide:

1. Replace scattered env var checks with:
   import { validateConfig } from './env-validator';
   const config = validateConfig();

2. Replace hardcoded values with validated config:
   const port = config.server.port;  // instead of parseInt(process.env.PORT || '5000')
   const jwtSecret = config.jwt.secret;  // instead of process.env.JWT_SECRET

3. Add startup validation to your main file (e.g., index.ts):
   import { validateConfig, printConfigSummary } from './env-validator';
   
   // At the top of your main function
   const config = validateConfig();
   
   if (config.server.nodeEnv === 'development') {
     printConfigSummary(config);
   }

4. Update your database connection:
   const pool = new Pool({ 
     connectionString: config.database.url,
     ssl: config.database.ssl ? { rejectUnauthorized: false } : undefined
   });

Benefits:
✅ Fail fast with clear error messages
✅ Type safety throughout your application
✅ Consistent configuration management
✅ Easy debugging with masked sensitive data
✅ Environment-specific validation
✅ Comprehensive setup instructions in error messages
✅ No more scattered env var checks
✅ Self-documenting configuration
*/
