/**
 * Comprehensive Error Tracking and Alerting System
 * Features: Error classification, aggregation, alerts, notifications, recovery suggestions
 */

import { EventEmitter } from 'events';
import { createHash } from 'crypto';

// ========================================
// Types and Interfaces
// ========================================

export type ErrorCategory = 
  | 'validation' 
  | 'authentication' 
  | 'authorization' 
  | 'aws' 
  | 'database' 
  | 'network' 
  | 'system' 
  | 'application' 
  | 'third_party';

export type ErrorSeverity = 'critical' | 'high' | 'medium' | 'low' | 'info';

export type AlertChannel = 'webhook' | 'email' | 'slack' | 'sms';

export interface ErrorMetadata {
  category: ErrorCategory;
  severity: ErrorSeverity;
  timestamp: Date;
  requestId?: string;
  userId?: string;
  endpoint?: string;
  method?: string;
  userAgent?: string;
  ip?: string;
  duration?: number;
  memoryUsage?: number;
  cpuUsage?: number;
  [key: string]: any;
}

export interface ErrorInstance {
  id: string;
  message: string;
  stack?: string;
  metadata: ErrorMetadata;
  fingerprint: string;
  count: number;
  firstOccurrence: Date;
  lastOccurrence: Date;
  status: 'active' | 'resolved' | 'ignored';
  recoverySuggestions?: string[];
}

export interface AlertRule {
  id: string;
  name: string;
  category?: ErrorCategory;
  severity?: ErrorSeverity;
  threshold: {
    count?: number;
    timeWindow: number; // in minutes
    occurrences?: number;
  };
  enabled: boolean;
  channels: AlertChannel[];
  cooldown: number; // in minutes
  lastTriggered?: Date;
}

export interface NotificationConfig {
  webhook?: {
    url: string;
    headers?: Record<string, string>;
    method?: 'POST' | 'GET';
  };
  email?: {
    to: string[];
    from?: string;
    subject?: string;
    template?: string;
  };
  slack?: {
    webhookUrl: string;
    channel?: string;
    username?: string;
    icon?: string;
  };
  sms?: {
    to: string[];
    provider: 'twilio' | 'aws_sns';
  };
}

export interface PerformanceImpact {
  avgResponseTime?: number;
  errorRate?: number;
  throughput?: number;
  availability?: number;
  affectedUsers?: number;
}

export interface ErrorCorrelation {
  requestId: string;
  errorIds: string[];
  timeline: {
    timestamp: Date;
    event: string;
    details?: any;
  }[];
}

// ========================================
// Error Classification
// ========================================

export class ErrorClassifier {
  private static patterns = {
    validation: [
      /validation/i,
      /invalid/i,
      /required/i,
      /format/i,
      /constraint/i
    ],
    authentication: [
      /unauthorized/i,
      /401/i,
      /auth/i,
      /login/i,
      /token/i
    ],
    authorization: [
      /forbidden/i,
      /403/i,
      /permission/i,
      /access.*denied/i
    ],
    aws: [
      /aws/i,
      /amazon/i,
      /ec2/i,
      /s3/i,
      /rds/i,
      /lambda/i,
      /dynamodb/i
    ],
    database: [
      /database/i,
      /sql/i,
      /mysql/i,
      /postgresql/i,
      /mongodb/i,
      /query/i,
      /connection/i
    ],
    network: [
      /timeout/i,
      /connection/i,
      /network/i,
      /econnrefused/i,
      /dns/i
    ],
    system: [
      /memory/i,
      /disk/i,
      /out of space/i,
      /heap/i,
      /stack/i
    ]
  };

  static classifyError(error: Error | string): { category: ErrorCategory; severity: ErrorSeverity } {
    const errorMessage = typeof error === 'string' ? error : error.message;
    const stack = typeof error === 'string' ? '' : error.stack || '';

    // Classify category
    let category: ErrorCategory = 'application';
    for (const [cat, patterns] of Object.entries(this.patterns)) {
      if (patterns.some(pattern => pattern.test(errorMessage) || pattern.test(stack))) {
        category = cat as ErrorCategory;
        break;
      }
    }

    // Determine severity based on category and content
    let severity: ErrorSeverity = 'medium';
    
    if (category === 'authentication' || category === 'authorization') {
      severity = 'high';
    } else if (category === 'aws' || category === 'database') {
      severity = 'critical';
    } else if (errorMessage.includes('fatal') || errorMessage.includes('crash')) {
      severity = 'critical';
    } else if (errorMessage.includes('timeout') || errorMessage.includes('retry')) {
      severity = 'medium';
    }

    return { category, severity };
  }

  static generateRecoverySuggestions(error: Error | string, category: ErrorCategory): string[] {
    const errorMessage = typeof error === 'string' ? error : error.message;
    const suggestions: string[] = [];

    switch (category) {
      case 'validation':
        suggestions.push(
          'Check input data format and required fields',
          'Validate data against schema before processing',
          'Implement client-side validation to catch errors early'
        );
        break;
      
      case 'authentication':
        suggestions.push(
          'Verify API keys and credentials',
          'Check token expiration and refresh if needed',
          'Ensure proper authentication middleware is configured'
        );
        break;
      
      case 'authorization':
        suggestions.push(
          'Review user permissions and roles',
          'Check resource access policies',
          'Verify RBAC configuration'
        );
        break;
      
      case 'aws':
        suggestions.push(
          'Check AWS service limits and quotas',
          'Verify IAM permissions for the service',
          'Review AWS CloudWatch logs for detailed errors',
          'Check AWS service status page for outages'
        );
        break;
      
      case 'database':
        suggestions.push(
          'Check database connection pool configuration',
          'Verify database server availability',
          'Review query performance and add indexes if needed',
          'Check for database locks or deadlocks'
        );
        break;
      
      case 'network':
        suggestions.push(
          'Implement retry logic with exponential backoff',
          'Check network connectivity and firewalls',
          'Increase timeout values for slow connections'
        );
        break;
      
      case 'system':
        suggestions.push(
          'Monitor system resources (CPU, memory, disk)',
          'Scale up resources if necessary',
          'Check for memory leaks in the application',
          'Review system logs for hardware issues'
        );
        break;
      
      default:
        suggestions.push(
          'Check application logs for detailed error information',
          'Review recent code changes that might have introduced the issue',
          'Test the functionality in a development environment'
        );
    }

    return suggestions;
  }
}

// ========================================
// Error Aggregation and Deduplication
// ========================================

export class ErrorAggregator {
  private errors: Map<string, ErrorInstance> = new Map();
  private timeWindow: number = 60; // minutes

  generateFingerprint(error: Error, metadata: ErrorMetadata): string {
    const content = `${error.message}|${metadata.category}|${metadata.endpoint || 'unknown'}`;
    return createHash('md5').update(content).digest('hex');
  }

  addError(error: Error, metadata: ErrorMetadata): ErrorInstance {
    const { category, severity } = ErrorClassifier.classifyError(error);
    metadata.category = category;
    metadata.severity = severity;

    const fingerprint = this.generateFingerprint(error, metadata);
    
    const existingError = this.errors.get(fingerprint);
    
    if (existingError) {
      // Update existing error
      existingError.count++;
      existingError.lastOccurrence = new Date();
      
      if (!existingError.recoverySuggestions) {
        existingError.recoverySuggestions = ErrorClassifier.generateRecoverySuggestions(error, category);
      }
      
      return existingError;
    } else {
      // Create new error instance
      const newError: ErrorInstance = {
        id: this.generateId(),
        message: error.message,
        stack: error.stack,
        metadata,
        fingerprint,
        count: 1,
        firstOccurrence: new Date(),
        lastOccurrence: new Date(),
        status: 'active',
        recoverySuggestions: ErrorClassifier.generateRecoverySuggestions(error, category)
      };
      
      this.errors.set(fingerprint, newError);
      return newError;
    }
  }

  private generateId(): string {
    return createHash('md5').update(Date.now().toString() + Math.random().toString()).digest('hex');
  }

  getErrors(filter?: {
    category?: ErrorCategory;
    severity?: ErrorSeverity;
    status?: ErrorInstance['status'];
    since?: Date;
  }): ErrorInstance[] {
    let errors = Array.from(this.errors.values());
    
    if (filter) {
      if (filter.category) {
        errors = errors.filter(e => e.metadata.category === filter.category);
      }
      if (filter.severity) {
        errors = errors.filter(e => e.metadata.severity === filter.severity);
      }
      if (filter.status) {
        errors = errors.filter(e => e.status === filter.status);
      }
      if (filter.since) {
        errors = errors.filter(e => e.lastOccurrence >= filter.since!);
      }
    }
    
    return errors.sort((a, b) => b.lastOccurrence.getTime() - a.lastOccurrence.getTime());
  }

  getErrorByFingerprint(fingerprint: string): ErrorInstance | undefined {
    return this.errors.get(fingerprint);
  }

  resolveError(fingerprint: string): boolean {
    const error = this.errors.get(fingerprint);
    if (error) {
      error.status = 'resolved';
      return true;
    }
    return false;
  }

  ignoreError(fingerprint: string): boolean {
    const error = this.errors.get(fingerprint);
    if (error) {
      error.status = 'ignored';
      return true;
    }
    return false;
  }

  cleanupOldErrors(maxAge: number = 24 * 60): number { // default 24 hours
    const cutoff = new Date(Date.now() - maxAge * 60 * 1000);
    let cleaned = 0;
    
    for (const [fingerprint, error] of this.errors.entries()) {
      if (error.lastOccurrence < cutoff && error.status === 'resolved') {
        this.errors.delete(fingerprint);
        cleaned++;
      }
    }
    
    return cleaned;
  }
}

// ========================================
// Alert Management
// ========================================

export class AlertManager extends EventEmitter {
  private rules: Map<string, AlertRule> = new Map();
  private notificationConfigs: Map<AlertChannel, any> = new Map();
  private triggeredAlerts: Map<string, Date> = new Map();

  constructor() {
    super();
    this.setupDefaultRules();
  }

  private setupDefaultRules() {
    // Critical errors - immediate alert
    this.addRule({
      id: 'critical-errors',
      name: 'Critical Error Alert',
      severity: 'critical',
      threshold: { count: 1, timeWindow: 5, occurrences: 1 },
      enabled: true,
      channels: ['webhook', 'slack'],
      cooldown: 5
    });

    // High error rate
    this.addRule({
      id: 'high-error-rate',
      name: 'High Error Rate',
      threshold: { count: 10, timeWindow: 10, occurrences: 1 },
      enabled: true,
      channels: ['webhook', 'email'],
      cooldown: 15
    });

    // AWS errors
    this.addRule({
      id: 'aws-errors',
      name: 'AWS Service Errors',
      category: 'aws',
      threshold: { count: 3, timeWindow: 15, occurrences: 1 },
      enabled: true,
      channels: ['webhook', 'slack'],
      cooldown: 10
    });
  }

  addRule(rule: AlertRule): void {
    this.rules.set(rule.id, rule);
  }

  removeRule(ruleId: string): boolean {
    return this.rules.delete(ruleId);
  }

  getRule(ruleId: string): AlertRule | undefined {
    return this.rules.get(ruleId);
  }

  getAllRules(): AlertRule[] {
    return Array.from(this.rules.values());
  }

  configureNotification(channel: AlertChannel, config: any): void {
    this.notificationConfigs.set(channel, config);
  }

  async checkAlerts(errorInstance: ErrorInstance): Promise<void> {
    for (const rule of this.rules.values()) {
      if (!rule.enabled) continue;
      
      if (this.shouldTriggerAlert(rule, errorInstance)) {
        await this.triggerAlert(rule, errorInstance);
      }
    }
  }

  private shouldTriggerAlert(rule: AlertRule, errorInstance: ErrorInstance): boolean {
    // Check category filter
    if (rule.category && errorInstance.metadata.category !== rule.category) {
      return false;
    }

    // Check severity filter
    if (rule.severity && errorInstance.metadata.severity !== rule.severity) {
      return false;
    }

    // Check cooldown
    if (rule.lastTriggered) {
      const timeSinceLastTrigger = Date.now() - rule.lastTriggered.getTime();
      if (timeSinceLastTrigger < rule.cooldown * 60 * 1000) {
        return false;
      }
    }

    return true;
  }

  private async triggerAlert(rule: AlertRule, errorInstance: ErrorInstance): Promise<void> {
    const alertKey = `${rule.id}:${errorInstance.fingerprint}`;
    this.triggeredAlerts.set(alertKey, new Date());
    rule.lastTriggered = new Date();

    this.emit('alert', { rule, errorInstance });

    // Send notifications through configured channels
    for (const channel of rule.channels) {
      try {
        await this.sendNotification(channel, rule, errorInstance);
      } catch (error) {
        console.error(`Failed to send ${channel} notification:`, error);
      }
    }
  }

  private async sendNotification(
    channel: AlertChannel, 
    rule: AlertRule, 
    errorInstance: ErrorInstance
  ): Promise<void> {
    const config = this.notificationConfigs.get(channel);
    if (!config) {
      console.warn(`No configuration found for ${channel} channel`);
      return;
    }

    switch (channel) {
      case 'webhook':
        await this.sendWebhookNotification(config, rule, errorInstance);
        break;
      case 'email':
        await this.sendEmailNotification(config, rule, errorInstance);
        break;
      case 'slack':
        await this.sendSlackNotification(config, rule, errorInstance);
        break;
      case 'sms':
        await this.sendSMSNotification(config, rule, errorInstance);
        break;
    }
  }

  private async sendWebhookNotification(config: any, rule: AlertRule, errorInstance: ErrorInstance): Promise<void> {
    const payload = {
      alert: {
        id: rule.id,
        name: rule.name,
        severity: errorInstance.metadata.severity,
        category: errorInstance.metadata.category,
        timestamp: new Date().toISOString()
      },
      error: {
        id: errorInstance.id,
        message: errorInstance.message,
        stack: errorInstance.stack,
        count: errorInstance.count,
        fingerprint: errorInstance.fingerprint,
        metadata: errorInstance.metadata,
        recoverySuggestions: errorInstance.recoverySuggestions
      }
    };

    const response = await fetch(config.url, {
      method: config.method || 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...config.headers
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`Webhook notification failed: ${response.status}`);
    }
  }

  private async sendEmailNotification(config: any, rule: AlertRule, errorInstance: ErrorInstance): Promise<void> {
    const subject = config.subject || `Alert: ${rule.name}`;
    
    const body = this.generateEmailTemplate(config.template, rule, errorInstance);
    
    // In a real implementation, you would integrate with an email service
    // like SendGrid, AWS SES, or NodeMailer
    console.log('Email notification:', {
      to: config.to,
      from: config.from,
      subject,
      body
    });
  }

  private async sendSlackNotification(config: any, rule: AlertRule, errorInstance: ErrorInstance): Promise<void> {
    const emoji = this.getSeverityEmoji(errorInstance.metadata.severity);
    
    const payload = {
      channel: config.channel,
      username: config.username || 'ErrorAlert',
      icon_emoji: config.icon || ':warning:',
      attachments: [
        {
          color: this.getSeverityColor(errorInstance.metadata.severity),
          title: `${emoji} ${rule.name}`,
          fields: [
            {
              title: 'Error Message',
              value: errorInstance.message,
              short: false
            },
            {
              title: 'Category',
              value: errorInstance.metadata.category,
              short: true
            },
            {
              title: 'Severity',
              value: errorInstance.metadata.severity,
              short: true
            },
            {
              title: 'Occurrences',
              value: errorInstance.count.toString(),
              short: true
            },
            {
              title: 'Endpoint',
              value: errorInstance.metadata.endpoint || 'N/A',
              short: true
            }
          ],
          actions: [
            {
              type: 'button',
              text: 'View Details',
              url: `${this.getDashboardUrl()}/errors/${errorInstance.fingerprint}`
            }
          ],
          footer: 'Error Tracking System',
          ts: Math.floor(Date.now() / 1000)
        }
      ]
    };

    const response = await fetch(config.webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`Slack notification failed: ${response.status}`);
    }
  }

  private async sendSMSNotification(config: any, rule: AlertRule, errorInstance: ErrorInstance): Promise<void> {
    const message = `ALERT: ${rule.name} - ${errorInstance.message} (${errorInstance.count} occurrences)`;
    
    // In a real implementation, you would integrate with SMS service
    console.log('SMS notification:', {
      to: config.to,
      provider: config.provider,
      message
    });
  }

  private generateEmailTemplate(template: string | undefined, rule: AlertRule, errorInstance: ErrorInstance): string {
    if (template) {
      // Simple template replacement
      return template
        .replace('{{ruleName}}', rule.name)
        .replace('{{errorMessage}}', errorInstance.message)
        .replace('{{category}}', errorInstance.metadata.category)
        .replace('{{severity}}', errorInstance.metadata.severity)
        .replace('{{count}}', errorInstance.count.toString())
        .replace('{{recoverySuggestions}}', errorInstance.recoverySuggestions?.join('\n') || 'None available');
    }

    return `
      Alert: ${rule.name}
      
      Error: ${errorInstance.message}
      Category: ${errorInstance.metadata.category}
      Severity: ${errorInstance.metadata.severity}
      Occurrences: ${errorInstance.count}
      First Occurrence: ${errorInstance.firstOccurrence}
      Last Occurrence: ${errorInstance.lastOccurrence}
      
      Recovery Suggestions:
      ${errorInstance.recoverySuggestions?.map(s => `- ${s}`).join('\n') || 'None available'}
      
      View details: ${this.getDashboardUrl()}/errors/${errorInstance.fingerprint}
    `;
  }

  private getSeverityEmoji(severity: ErrorSeverity): string {
    const emojis = {
      critical: '🚨',
      high: '⚠️',
      medium: '⚡',
      low: 'ℹ️',
      info: '📝'
    };
    return emojis[severity] || '❓';
  }

  private getSeverityColor(severity: ErrorSeverity): string {
    const colors = {
      critical: 'danger',
      high: 'warning',
      medium: '#ffeb3b',
      low: 'good',
      info: '#2196f3'
    };
    return colors[severity] || '#gray';
  }

  private getDashboardUrl(): string {
    return process.env.ERROR_DASHBOARD_URL || 'http://localhost:3000/dashboard';
  }
}

// ========================================
// Performance Impact Tracking
// ========================================

export class PerformanceTracker {
  private metrics: Map<string, {
    timestamps: number[];
    responseTimes: number[];
    errorCount: number;
    totalRequests: number;
  }> = new Map();

  recordRequest(endpoint: string, duration: number, isError: boolean = false): void {
    if (!this.metrics.has(endpoint)) {
      this.metrics.set(endpoint, {
        timestamps: [],
        responseTimes: [],
        errorCount: 0,
        totalRequests: 0
      });
    }

    const metric = this.metrics.get(endpoint)!;
    const now = Date.now();

    metric.timestamps.push(now);
    metric.responseTimes.push(duration);
    metric.totalRequests++;
    
    if (isError) {
      metric.errorCount++;
    }

    // Keep only last 1000 requests per endpoint
    if (metric.timestamps.length > 1000) {
      metric.timestamps.shift();
      metric.responseTimes.shift();
    }
  }

  getPerformanceMetrics(endpoint?: string): Map<string, PerformanceImpact> {
    const result = new Map<string, PerformanceImpact>();
    
    const endpoints = endpoint ? [endpoint] : Array.from(this.metrics.keys());
    
    for (const ep of endpoints) {
      const metric = this.metrics.get(ep);
      if (!metric) continue;

      const now = Date.now();
      const recentMetrics = metric.timestamps
        .map((timestamp, index) => ({
          timestamp,
          responseTime: metric.responseTimes[index],
          isError: false // This would need to be tracked separately
        }))
        .filter(m => now - m.timestamp <= 60 * 60 * 1000); // Last hour

      const avgResponseTime = recentMetrics.length > 0
        ? recentMetrics.reduce((sum, m) => sum + m.responseTime, 0) / recentMetrics.length
        : 0;

      const errorRate = metric.totalRequests > 0
        ? (metric.errorCount / metric.totalRequests) * 100
        : 0;

      const throughput = recentMetrics.length > 0
        ? recentMetrics.length / (60 * 60) // requests per hour
        : 0;

      result.set(ep, {
        avgResponseTime,
        errorRate,
        throughput
      });
    }

    return result;
  }

  getErrorCorrelation(endpoint: string, timeframe: number = 60): ErrorCorrelation[] {
    const correlations: ErrorCorrelation[] = [];
    const metric = this.metrics.get(endpoint);
    
    if (!metric) return correlations;

    const now = Date.now();
    const cutoff = now - timeframe * 60 * 1000;

    for (let i = 0; i < metric.timestamps.length; i++) {
      const timestamp = metric.timestamps[i];
      
      if (timestamp >= cutoff) {
        correlations.push({
          requestId: `req_${timestamp}_${i}`,
          errorIds: [], // This would be populated with actual error correlation logic
          timeline: [
            {
              timestamp: new Date(timestamp),
              event: 'request_received',
              details: { endpoint, duration: metric.responseTimes[i] }
            }
          ]
        });
      }
    }

    return correlations;
  }
}

// ========================================
// Error History and Analysis
// ========================================

export class ErrorAnalytics {
  private history: Map<string, ErrorInstance[]> = new Map();

  recordErrorInstance(errorInstance: ErrorInstance): void {
    const category = errorInstance.metadata.category;
    
    if (!this.history.has(category)) {
      this.history.set(category, []);
    }

    const categoryHistory = this.history.get(category)!;
    categoryHistory.push(errorInstance);

    // Keep only last 10000 errors per category
    if (categoryHistory.length > 10000) {
      categoryHistory.shift();
    }
  }

  getErrorTrends(timeframe: number = 24): {
    byCategory: Map<ErrorCategory, number>;
    bySeverity: Map<ErrorSeverity, number>;
    hourlyDistribution: number[];
  } {
    const cutoff = new Date(Date.now() - timeframe * 60 * 60 * 1000);
    
    const byCategory = new Map<ErrorCategory, number>();
    const bySeverity = new Map<ErrorSeverity, number>();
    const hourlyDistribution = new Array(24).fill(0);

    for (const errors of this.history.values()) {
      for (const error of errors) {
        if (error.lastOccurrence >= cutoff) {
          // Count by category
          const categoryCount = byCategory.get(error.metadata.category) || 0;
          byCategory.set(error.metadata.category, categoryCount + 1);

          // Count by severity
          const severityCount = bySeverity.get(error.metadata.severity) || 0;
          bySeverity.set(error.metadata.severity, severityCount + 1);

          // Hourly distribution
          const hour = error.lastOccurrence.getHours();
          hourlyDistribution[hour]++;
        }
      }
    }

    return { byCategory, bySeverity, hourlyDistribution };
  }

  getTopErrors(limit: number = 10): ErrorInstance[] {
    const allErrors: ErrorInstance[] = [];
    
    for (const errors of this.history.values()) {
      allErrors.push(...errors);
    }

    return allErrors
      .sort((a, b) => b.count - a.count)
      .slice(0, limit);
  }

  getErrorPatterns(): {
    frequentCombinations: Array<{
      patterns: string[];
      count: number;
      errors: ErrorInstance[];
    }>;
    timeBasedPatterns: Array<{
      hour: number;
      categories: ErrorCategory[];
      count: number;
    }>;
  } {
    // Simple pattern analysis
    const patterns: Map<string, { count: number; errors: ErrorInstance[] }> = new Map();

    for (const errors of this.history.values()) {
      for (const error of errors) {
        const pattern = `${error.metadata.endpoint || 'unknown'}:${error.metadata.method || 'unknown'}:${error.metadata.category}`;
        
        if (!patterns.has(pattern)) {
          patterns.set(pattern, { count: 0, errors: [] });
        }
        
        const patternData = patterns.get(pattern)!;
        patternData.count++;
        patternData.errors.push(error);
      }
    }

    const frequentCombinations = Array.from(patterns.entries())
      .filter(([_, data]) => data.count > 1)
      .map(([pattern, data]) => ({
        patterns: pattern.split(':'),
        count: data.count,
        errors: data.errors
      }))
      .sort((a, b) => b.count - a.count);

    // Time-based patterns
    const timePatterns: Map<number, { count: number; categories: Set<ErrorCategory> }> = new Map();
    
    for (const errors of this.history.values()) {
      for (const error of errors) {
        const hour = error.lastOccurrence.getHours();
        
        if (!timePatterns.has(hour)) {
          timePatterns.set(hour, { count: 0, categories: new Set() });
        }
        
        const pattern = timePatterns.get(hour)!;
        pattern.count++;
        pattern.categories.add(error.metadata.category);
      }
    }

    const timeBasedPatterns = Array.from(timePatterns.entries())
      .map(([hour, data]) => ({
        hour,
        categories: Array.from(data.categories),
        count: data.count
      }))
      .sort((a, b) => b.count - a.count);

    return { frequentCombinations, timeBasedPatterns };
  }
}

// ========================================
// Main Error Tracking System
// ========================================

export class ErrorTrackingSystem extends EventEmitter {
  private aggregator: ErrorAggregator;
  private alertManager: AlertManager;
  private performanceTracker: PerformanceTracker;
  private analytics: ErrorAnalytics;

  constructor() {
    super();
    this.aggregator = new ErrorAggregator();
    this.alertManager = new AlertManager();
    this.performanceTracker = new PerformanceTracker();
    this.analytics = new ErrorAnalytics();

    // Listen to alerts
    this.alertManager.on('alert', (data: { rule: AlertRule; errorInstance: ErrorInstance }) => {
      this.emit('alert', data);
    });

    // Periodic cleanup
    setInterval(() => {
      this.aggregator.cleanupOldErrors();
    }, 60 * 60 * 1000); // Every hour
  }

  /**
   * Track an error occurrence
   */
  async trackError(
    error: Error | string,
    metadata: Partial<ErrorMetadata> = {}
  ): Promise<ErrorInstance> {
    const errorMetadata: ErrorMetadata = {
      category: 'application',
      severity: 'medium',
      timestamp: new Date(),
      ...metadata
    };

    // Add error to aggregator
    const errorInstance = this.aggregator.addError(error, errorMetadata);
    
    // Record performance impact
    if (metadata.duration) {
      this.performanceTracker.recordRequest(
        metadata.endpoint || 'unknown',
        metadata.duration,
        true
      );
    }

    // Record for analytics
    this.analytics.recordErrorInstance(errorInstance);

    // Check alerts
    await this.alertManager.checkAlerts(errorInstance);

    // Emit error event
    this.emit('error', errorInstance);

    return errorInstance;
  }

  /**
   * Track a successful request for performance monitoring
   */
  trackRequest(
    endpoint: string,
    duration: number,
    metadata: Partial<ErrorMetadata> = {}
  ): void {
    this.performanceTracker.recordRequest(endpoint, duration, false);
    
    this.emit('request', {
      endpoint,
      duration,
      metadata: {
        timestamp: new Date(),
        endpoint,
        ...metadata
      }
    });
  }

  /**
   * Get active errors
   */
  getActiveErrors(filter?: Parameters<ErrorAggregator['getErrors']>[0]): ErrorInstance[] {
    return this.aggregator.getErrors({ ...filter, status: 'active' });
  }

  /**
   * Get all errors with optional filtering
   */
  getErrors(filter?: Parameters<ErrorAggregator['getErrors']>[0]): ErrorInstance[] {
    return this.aggregator.getErrors(filter);
  }

  /**
   * Resolve an error
   */
  resolveError(fingerprint: string): boolean {
    return this.aggregator.resolveError(fingerprint);
  }

  /**
   * Ignore an error
   */
  ignoreError(fingerprint: string): boolean {
    return this.aggregator.ignoreError(fingerprint);
  }

  /**
   * Get performance metrics
   */
  getPerformanceMetrics(endpoint?: string): Map<string, PerformanceImpact> {
    return this.performanceTracker.getPerformanceMetrics(endpoint);
  }

  /**
   * Get error trends and analytics
   */
  getErrorTrends(timeframe?: number) {
    return this.analytics.getErrorTrends(timeframe);
  }

  /**
   * Get top errors
   */
  getTopErrors(limit?: number): ErrorInstance[] {
    return this.analytics.getTopErrors(limit);
  }

  /**
   * Get error patterns
   */
  getErrorPatterns() {
    return this.analytics.getErrorPatterns();
  }

  /**
   * Configure alert rules
   */
  addAlertRule(rule: AlertRule): void {
    this.alertManager.addRule(rule);
  }

  /**
   * Configure notifications
   */
  configureNotifications(channel: AlertChannel, config: any): void {
    this.alertManager.configureNotification(channel, config);
  }

  /**
   * Get all alert rules
   */
  getAlertRules(): AlertRule[] {
    return this.alertManager.getAllRules();
  }

  /**
   * Get system statistics
   */
  getSystemStats(): {
    totalErrors: number;
    activeErrors: number;
    resolvedErrors: number;
    ignoredErrors: number;
    avgErrorRate: number;
    topCategories: Array<{ category: ErrorCategory; count: number }>;
  } {
    const allErrors = this.aggregator.getErrors();
    const activeErrors = allErrors.filter(e => e.status === 'active');
    const resolvedErrors = allErrors.filter(e => e.status === 'resolved');
    const ignoredErrors = allErrors.filter(e => e.status === 'ignored');

    const categoryCounts = new Map<ErrorCategory, number>();
    for (const error of allErrors) {
      const count = categoryCounts.get(error.metadata.category) || 0;
      categoryCounts.set(error.metadata.category, count + 1);
    }

    const topCategories = Array.from(categoryCounts.entries())
      .map(([category, count]) => ({ category, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    return {
      totalErrors: allErrors.length,
      activeErrors: activeErrors.length,
      resolvedErrors: resolvedErrors.length,
      ignoredErrors: ignoredErrors.length,
      avgErrorRate: allErrors.length > 0 ? (activeErrors.length / allErrors.length) * 100 : 0,
      topCategories
    };
  }
}

// ========================================
// Factory Function and Singleton
// ========================================

let errorTrackingInstance: ErrorTrackingSystem | null = null;

export function createErrorTracking(): ErrorTrackingSystem {
  if (!errorTrackingInstance) {
    errorTrackingInstance = new ErrorTrackingSystem();
  }
  return errorTrackingInstance;
}

export function getErrorTracking(): ErrorTrackingSystem {
  if (!errorTrackingInstance) {
    throw new Error('Error tracking system not initialized. Call createErrorTracking() first.');
  }
  return errorTrackingInstance;
}

// ========================================
// Express.js Middleware Integration
// ========================================

export function errorTrackingMiddleware(options: {
  includeStack?: boolean;
  excludePaths?: string[];
  customMetadata?: (req: any, res: any) => Partial<ErrorMetadata>;
} = {}) {
  const {
    includeStack = false,
    excludePaths = ['/health', '/metrics'],
    customMetadata
  } = options;

  return (error: Error, req: any, res: any, next: any) => {
    // Skip excluded paths
    if (excludePaths.includes(req.path)) {
      return next(error);
    }

    const metadata: Partial<ErrorMetadata> = {
      requestId: req.id || req.headers['x-request-id'],
      userId: req.user?.id,
      endpoint: req.path,
      method: req.method,
      userAgent: req.headers['user-agent'],
      ip: req.ip || req.connection.remoteAddress,
      duration: Date.now() - (req.startTime || Date.now())
    };

    if (customMetadata) {
      Object.assign(metadata, customMetadata(req, res));
    }

    getErrorTracking().trackError(error, metadata);

    next(error);
  };
}

// ========================================
// Export everything
// ========================================

export default ErrorTrackingSystem;