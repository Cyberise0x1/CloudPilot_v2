/**
 * Comprehensive Health Check System
 * Provides monitoring for database, AWS services, system resources, and application health
 */

import { Request, Response, Router } from 'express';
import { pool, db } from './db';
import { secretsManager } from './secrets-manager';
import { S3Client, HeadBucketCommand } from '@aws-sdk/client-s3';
import { EC2Client, DescribeInstancesCommand } from '@aws-sdk/client-ec2';
import { CloudFrontClient, GetDistributionCommand } from '@aws-sdk/client-cloudfront';
import { RDSClient, DescribeDBClustersCommand } from '@aws-sdk/client-rds';
import { createHash } from 'crypto';
import { promises as fs } from 'fs';

// Health check types and interfaces
export interface HealthCheckResult {
  service: string;
  status: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: number;
  responseTime: number;
  message: string;
  metadata?: Record<string, any>;
  error?: string;
  retries?: number;
}

export interface SystemMetrics {
  cpu: {
    usage: number;
    loadAverage: number[];
    cores: number;
  };
  memory: {
    used: number;
    total: number;
    percentage: number;
    free: number;
  };
  disk: {
    used: number;
    total: number;
    percentage: number;
    available: number;
  };
  uptime: number;
  pid: number;
  platform: string;
  nodeVersion: string;
}

export interface HealthHistoryEntry {
  timestamp: number;
  overallStatus: 'healthy' | 'degraded' | 'unhealthy';
  checks: HealthCheckResult[];
  systemMetrics: SystemMetrics;
  summary: {
    total: number;
    healthy: number;
    degraded: number;
    unhealthy: number;
    avgResponseTime: number;
  };
}

export interface HealthReport {
  timestamp: number;
  status: 'healthy' | 'degraded' | 'unhealthy';
  version: string;
  environment: string;
  uptime: number;
  checks: {
    database: HealthCheckResult;
    aws: {
      s3?: HealthCheckResult;
      cloudfront?: HealthCheckResult;
      ec2?: HealthCheckResult;
      rds?: HealthCheckResult;
    };
    external: HealthCheckResult[];
    system: HealthCheckResult;
    application: HealthCheckResult;
  };
  systemMetrics: SystemMetrics;
  summary: {
    total: number;
    healthy: number;
    degraded: number;
    unhealthy: number;
    avgResponseTime: number;
  };
  history?: HealthHistoryEntry[];
  trends?: {
    last24Hours: {
      uptime: number;
      avgResponseTime: number;
      availability: number;
      criticalIncidents: number;
    };
    last7Days: {
      uptime: number;
      avgResponseTime: number;
      availability: number;
      criticalIncidents: number;
    };
  };
}

export interface ExternalDependencyConfig {
  name: string;
  url: string;
  timeout: number;
  expectedStatus?: number;
  headers?: Record<string, string>;
  critical?: boolean;
  method?: 'GET' | 'HEAD' | 'POST';
  body?: any;
}

// Health check configuration
const HEALTH_CHECK_CONFIG = {
  database: {
    timeout: 5000,
    retries: 2,
    critical: true
  },
  aws: {
    timeout: 3000,
    retries: 1,
    critical: true
  },
  system: {
    interval: 30000, // 30 seconds
    threshold: {
      cpu: 80, // percentage
      memory: 85, // percentage
      disk: 90 // percentage
    }
  },
  external: {
    timeout: 10000,
    retries: 1
  },
  history: {
    maxEntries: 1000,
    retentionPeriod: 7 * 24 * 60 * 60 * 1000 // 7 days in milliseconds
  }
};

// External dependencies configuration
const EXTERNAL_DEPENDENCIES: ExternalDependencyConfig[] = [
  {
    name: 'GitHub API',
    url: 'https://api.github.com/zen',
    timeout: 5000,
    method: 'GET',
    critical: false
  },
  {
    name: 'NPM Registry',
    url: 'https://registry.npmjs.org/',
    timeout: 5000,
    method: 'GET',
    critical: false
  }
];

// Health check history storage
let healthHistory: HealthHistoryEntry[] = [];
let isShuttingDown = false;

// AWS clients cache
let cachedClients: {
  s3?: S3Client;
  cloudfront?: CloudFrontClient;
  ec2?: EC2Client;
  rds?: RDSClient;
} = {};

// Utility functions
function now(): number {
  return Date.now();
}

function getOverallStatus(results: HealthCheckResult[]): 'healthy' | 'degraded' | 'unhealthy' {
  if (results.some(r => r.status === 'unhealthy')) {
    return 'unhealthy';
  }
  if (results.some(r => r.status === 'degraded')) {
    return 'degraded';
  }
  return 'healthy';
}

function calculateSummary(results: HealthCheckResult[]) {
  const total = results.length;
  const healthy = results.filter(r => r.status === 'healthy').length;
  const degraded = results.filter(r => r.status === 'degraded').length;
  const unhealthy = results.filter(r => r.status === 'unhealthy').length;
  const avgResponseTime = results.reduce((sum, r) => sum + r.responseTime, 0) / total;

  return { total, healthy, degraded, unhealthy, avgResponseTime };
}

async function makeRequest(
  url: string, 
  options: { 
    timeout?: number; 
    method?: string; 
    headers?: Record<string, string>; 
    body?: any;
  } = {}
): Promise<{ status: number; responseTime: number; data?: any; error?: string }> {
  const startTime = Date.now();
  
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), options.timeout || 5000);

    const fetchOptions: RequestInit = {
      signal: controller.signal,
      method: options.method || 'GET',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'CloudPilot-HealthCheck/1.0',
        ...options.headers
      }
    };

    if (options.body && options.method !== 'GET') {
      fetchOptions.body = typeof options.body === 'string' ? options.body : JSON.stringify(options.body);
    }

    const response = await fetch(url, fetchOptions);
    const responseTime = Date.now() - startTime;
    clearTimeout(timeoutId);

    let data: any;
    const contentType = response.headers.get('content-type');
    if (contentType?.includes('application/json')) {
      try {
        data = await response.json();
      } catch {
        data = await response.text();
      }
    } else {
      data = await response.text();
    }

    return {
      status: response.status,
      responseTime,
      data,
      error: response.ok ? undefined : `HTTP ${response.status}`
    };
  } catch (error) {
    const responseTime = Date.now() - startTime;
    return {
      status: 0,
      responseTime,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}

// Health check implementations

/**
 * Database connectivity check
 */
async function checkDatabase(): Promise<HealthCheckResult> {
  const startTime = now();
  let retries = 0;
  const maxRetries = HEALTH_CHECK_CONFIG.database.retries;

  while (retries <= maxRetries) {
    try {
      const query = 'SELECT NOW() as current_time, version() as db_version';
      const result = await db.execute(query);
      const responseTime = now() - startTime;

      if (result && result.rows && result.rows.length > 0) {
        const row = result.rows[0] as any;
        return {
          service: 'database',
          status: 'healthy',
          timestamp: now(),
          responseTime,
          message: 'Database connection successful',
          metadata: {
            currentTime: row.current_time,
            version: row.db_version,
            retries
          }
        };
      }

      throw new Error('No results returned from database query');
    } catch (error) {
      retries++;
      if (retries > maxRetries) {
        const responseTime = now() - startTime;
        return {
          service: 'database',
          status: 'unhealthy',
          timestamp: now(),
          responseTime,
          message: 'Database connection failed',
          error: error instanceof Error ? error.message : 'Unknown error',
          retries
        };
      }
      
      // Wait before retry
      await new Promise(resolve => setTimeout(resolve, 100 * retries));
    }
  }

  // Should not reach here, but just in case
  const responseTime = now() - startTime;
  return {
    service: 'database',
    status: 'unhealthy',
    timestamp: now(),
    responseTime,
    message: 'Database connection failed after retries',
    retries: maxRetries + 1
  };
}

/**
 * AWS services health checks
 */
async function checkAWSServices(): Promise<{
  s3?: HealthCheckResult;
  cloudfront?: HealthCheckResult;
  ec2?: HealthCheckResult;
  rds?: HealthCheckResult;
}> {
  const awsAccessKey = secretsManager.getSecret('AWS_ACCESS_KEY_ID');
  const awsSecretKey = secretsManager.getSecret('AWS_SECRET_ACCESS_KEY');
  const awsRegion = secretsManager.getSecret('AWS_REGION') || 'us-east-1';

  if (!awsAccessKey || !awsSecretKey) {
    return {
      s3: {
        service: 'aws-s3',
        status: 'degraded',
        timestamp: now(),
        responseTime: 0,
        message: 'AWS credentials not configured'
      },
      cloudfront: {
        service: 'aws-cloudfront',
        status: 'degraded',
        timestamp: now(),
        responseTime: 0,
        message: 'AWS credentials not configured'
      },
      ec2: {
        service: 'aws-ec2',
        status: 'degraded',
        timestamp: now(),
        responseTime: 0,
        message: 'AWS credentials not configured'
      },
      rds: {
        service: 'aws-rds',
        status: 'degraded',
        timestamp: now(),
        responseTime: 0,
        message: 'AWS credentials not configured'
      }
    };
  }

  // Initialize AWS clients
  const awsConfig = {
    region: awsRegion,
    credentials: {
      accessKeyId: awsAccessKey,
      secretAccessKey: awsSecretKey
    }
  };

  try {
    // Check S3
    if (!cachedClients.s3) {
      cachedClients.s3 = new S3Client(awsConfig);
    }
    
    const s3StartTime = now();
    try {
      // Try to list buckets (this validates credentials and connectivity)
      await cachedClients.s3.send(new HeadBucketCommand({ 
        Bucket: 'health-check-bucket-test' 
      }));
    } catch (s3Error: any) {
      // S3 bucket doesn't exist, but we can still check if the service is reachable
      if (s3Error.name !== 'NoSuchBucket') {
        throw s3Error;
      }
    }
    
    const s3Result: HealthCheckResult = {
      service: 'aws-s3',
      status: 'healthy',
      timestamp: now(),
      responseTime: now() - s3StartTime,
      message: 'AWS S3 service is accessible',
      metadata: {
        region: awsRegion,
        credentialsConfigured: true
      }
    };

    // Check CloudFront
    let cloudfrontResult: HealthCheckResult;
    try {
      if (!cachedClients.cloudfront) {
        cachedClients.cloudfront = new CloudFrontClient(awsConfig);
      }
      
      const cloudfrontStartTime = now();
      // CloudFront API calls require a distribution ID, so we'll just check if the client can be created
      cloudfrontResult = {
        service: 'aws-cloudfront',
        status: 'healthy',
        timestamp: now(),
        responseTime: now() - cloudfrontStartTime,
        message: 'AWS CloudFront client initialized successfully',
        metadata: {
          region: awsRegion
        }
      };
    } catch (error) {
      cloudfrontResult = {
        service: 'aws-cloudfront',
        status: 'degraded',
        timestamp: now(),
        responseTime: 0,
        message: 'AWS CloudFront client initialization failed',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }

    // Check EC2
    let ec2Result: HealthCheckResult;
    try {
      if (!cachedClients.ec2) {
        cachedClients.ec2 = new EC2Client(awsConfig);
      }
      
      const ec2StartTime = now();
      // Try to describe instances (limited to avoid heavy API calls)
      await cachedClients.ec2.send(new DescribeInstancesCommand({ 
        MaxResults: 1 
      }));
      
      ec2Result = {
        service: 'aws-ec2',
        status: 'healthy',
        timestamp: now(),
        responseTime: now() - ec2StartTime,
        message: 'AWS EC2 service is accessible',
        metadata: {
          region: awsRegion
        }
      };
    } catch (error) {
      ec2Result = {
        service: 'aws-ec2',
        status: 'degraded',
        timestamp: now(),
        responseTime: 0,
        message: 'AWS EC2 service check failed',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }

    // Check RDS
    let rdsResult: HealthCheckResult;
    try {
      if (!cachedClients.rds) {
        cachedClients.rds = new RDSClient(awsConfig);
      }
      
      const rdsStartTime = now();
      // Try to describe DB clusters (limited to avoid heavy API calls)
      await cachedClients.rds.send(new DescribeDBClustersCommand({ 
        MaxRecords: 1 
      }));
      
      rdsResult = {
        service: 'aws-rds',
        status: 'healthy',
        timestamp: now(),
        responseTime: now() - rdsStartTime,
        message: 'AWS RDS service is accessible',
        metadata: {
          region: awsRegion
        }
      };
    } catch (error) {
      rdsResult = {
        service: 'aws-rds',
        status: 'degraded',
        timestamp: now(),
        responseTime: 0,
        message: 'AWS RDS service check failed',
        error: error instanceof Error ? error.message : 'Unknown error'
      };
    }

    return {
      s3: s3Result,
      cloudfront: cloudfrontResult,
      ec2: ec2Result,
      rds: rdsResult
    };
  } catch (error) {
    // Overall AWS configuration error
    return {
      s3: {
        service: 'aws-s3',
        status: 'unhealthy',
        timestamp: now(),
        responseTime: 0,
        message: 'AWS service initialization failed',
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      cloudfront: {
        service: 'aws-cloudfront',
        status: 'unhealthy',
        timestamp: now(),
        responseTime: 0,
        message: 'AWS service initialization failed',
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      ec2: {
        service: 'aws-ec2',
        status: 'unhealthy',
        timestamp: now(),
        responseTime: 0,
        message: 'AWS service initialization failed',
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      rds: {
        service: 'aws-rds',
        status: 'unhealthy',
        timestamp: now(),
        responseTime: 0,
        message: 'AWS service initialization failed',
        error: error instanceof Error ? error.message : 'Unknown error'
      }
    };
  }
}

/**
 * External dependencies health checks
 */
async function checkExternalDependencies(): Promise<HealthCheckResult[]> {
  const results: HealthCheckResult[] = [];

  for (const dependency of EXTERNAL_DEPENDENCIES) {
    const startTime = now();
    
    try {
      const response = await makeRequest(dependency.url, {
        timeout: dependency.timeout,
        method: dependency.method,
        headers: dependency.headers
      });

      const isHealthy = dependency.expectedStatus 
        ? response.status === dependency.expectedStatus
        : response.status >= 200 && response.status < 300;

      const status = isHealthy ? 'healthy' : 
                    (dependency.critical ? 'unhealthy' : 'degraded');

      results.push({
        service: `external-${dependency.name.toLowerCase().replace(/\s+/g, '-')}`,
        status,
        timestamp: now(),
        responseTime: response.responseTime,
        message: isHealthy ? 
          `${dependency.name} is accessible` : 
          `${dependency.name} returned status ${response.status}`,
        metadata: {
          url: dependency.url,
          expectedStatus: dependency.expectedStatus,
          actualStatus: response.status,
          critical: dependency.critical
        },
        error: response.error
      });
    } catch (error) {
      results.push({
        service: `external-${dependency.name.toLowerCase().replace(/\s+/g, '-')}`,
        status: dependency.critical ? 'unhealthy' : 'degraded',
        timestamp: now(),
        responseTime: now() - startTime,
        message: `${dependency.name} is not accessible`,
        error: error instanceof Error ? error.message : 'Unknown error',
        metadata: {
          url: dependency.url,
          critical: dependency.critical
        }
      });
    }
  }

  return results;
}

/**
 * System resource monitoring
 */
async function checkSystemResources(): Promise<HealthCheckResult> {
  const startTime = now();
  
  try {
    const systemMetrics = await getSystemMetrics();
    
    const thresholds = HEALTH_CHECK_CONFIG.system.threshold;
    const issues: string[] = [];
    
    if (systemMetrics.cpu.usage > thresholds.cpu) {
      issues.push(`CPU usage (${systemMetrics.cpu.usage}%) exceeds threshold (${thresholds.cpu}%)`);
    }
    
    if (systemMetrics.memory.percentage > thresholds.memory) {
      issues.push(`Memory usage (${systemMetrics.memory.percentage}%) exceeds threshold (${thresholds.memory}%)`);
    }
    
    if (systemMetrics.disk.percentage > thresholds.disk) {
      issues.push(`Disk usage (${systemMetrics.disk.percentage}%) exceeds threshold (${thresholds.disk}%)`);
    }

    const status = issues.length > 2 ? 'unhealthy' : 
                  issues.length > 0 ? 'degraded' : 'healthy';

    return {
      service: 'system',
      status,
      timestamp: now(),
      responseTime: now() - startTime,
      message: issues.length > 0 ? 
        `System resource issues detected: ${issues.join(', ')}` : 
        'System resources are within acceptable limits',
      metadata: {
        cpu: systemMetrics.cpu,
        memory: systemMetrics.memory,
        disk: systemMetrics.disk,
        uptime: systemMetrics.uptime,
        platform: systemMetrics.platform,
        nodeVersion: systemMetrics.nodeVersion
      }
    };
  } catch (error) {
    return {
      service: 'system',
      status: 'unhealthy',
      timestamp: now(),
      responseTime: now() - startTime,
      message: 'Failed to collect system metrics',
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}

/**
 * Get detailed system metrics
 */
async function getSystemMetrics(): Promise<SystemMetrics> {
  const memUsage = process.memoryUsage();
  const cpuUsage = process.cpuUsage();
  const loadAvg = require('os').loadavg();
  
  // Get disk usage (Unix-like systems)
  let diskUsage = { used: 0, total: 0, free: 0 };
  try {
    const stats = await fs.stat('/');
    const statvfs = require('os').statvfs;
    const diskStats = statvfs('/');
    const total = diskStats.blocks * diskStats.frsize;
    const free = diskStats.bavail * diskStats.frsize;
    const used = total - free;
    
    diskUsage = {
      used,
      total,
      free,
      percentage: Math.round((used / total) * 100)
    };
  } catch {
    // Fallback for systems without statvfs
    diskUsage = { used: 0, total: 0, free: 0, percentage: 0 };
  }

  return {
    cpu: {
      usage: Math.round(cpuUsage.user / 1000000), // Convert to percentage
      loadAverage: loadAvg,
      cores: require('os').cpus().length
    },
    memory: {
      used: memUsage.heapUsed,
      total: memUsage.heapTotal,
      percentage: Math.round((memUsage.heapUsed / memUsage.heapTotal) * 100),
      free: memUsage.heapTotal - memUsage.heapUsed
    },
    disk: diskUsage,
    uptime: process.uptime(),
    pid: process.pid,
    platform: process.platform,
    nodeVersion: process.version
  };
}

/**
 * Custom application health indicators
 */
async function checkApplicationHealth(): Promise<HealthCheckResult> {
  const startTime = now();
  
  try {
    // Check secrets manager health
    const secretsStats = secretsManager.getStatistics();
    const secretsValid = secretsStats.requiredSecrets === secretsStats.validatedSecrets;
    
    // Check if application can create hashes (indicates crypto is working)
    const testHash = createHash('sha256').update('test').digest('hex');
    const cryptoWorking = testHash.length === 64;
    
    const issues: string[] = [];
    
    if (!secretsValid) {
      issues.push(`Secrets validation failed: ${secretsStats.requiredSecrets - secretsStats.validatedSecrets} invalid secrets`);
    }
    
    if (!cryptoWorking) {
      issues.push('Cryptographic functions are not working properly');
    }

    const status = issues.length > 0 ? 'degraded' : 'healthy';

    return {
      service: 'application',
      status,
      timestamp: now(),
      responseTime: now() - startTime,
      message: issues.length > 0 ? 
        `Application health issues: ${issues.join(', ')}` : 
        'Application health checks passed',
      metadata: {
        secretsManager: secretsStats,
        cryptoWorking,
        environment: process.env.NODE_ENV || 'development',
        version: process.env.npm_package_version || 'unknown'
      }
    };
  } catch (error) {
    return {
      service: 'application',
      status: 'unhealthy',
      timestamp: now(),
      responseTime: now() - startTime,
      message: 'Application health check failed',
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}

/**
 * Run all health checks and aggregate results
 */
async function runAllHealthChecks(): Promise<HealthReport> {
  const startTime = now();
  
  // Run all checks in parallel
  const [
    databaseResult,
    awsResults,
    externalResults,
    systemResult,
    applicationResult,
    systemMetrics
  ] = await Promise.allSettled([
    checkDatabase(),
    checkAWSServices(),
    checkExternalDependencies(),
    checkSystemResources(),
    checkApplicationHealth(),
    getSystemMetrics()
  ]);

  // Extract results, handling any rejected promises
  const database = databaseResult.status === 'fulfilled' ? databaseResult.value : {
    service: 'database',
    status: 'unhealthy' as const,
    timestamp: now(),
    responseTime: 0,
    message: 'Health check failed',
    error: databaseResult.reason?.message || 'Unknown error'
  };

  const aws = awsResults.status === 'fulfilled' ? awsResults.value : {
    s3: {
      service: 'aws-s3',
      status: 'unhealthy' as const,
      timestamp: now(),
      responseTime: 0,
      message: 'AWS health check failed',
      error: awsResults.reason?.message || 'Unknown error'
    },
    cloudfront: {
      service: 'aws-cloudfront',
      status: 'unhealthy' as const,
      timestamp: now(),
      responseTime: 0,
      message: 'AWS health check failed',
      error: awsResults.reason?.message || 'Unknown error'
    },
    ec2: {
      service: 'aws-ec2',
      status: 'unhealthy' as const,
      timestamp: now(),
      responseTime: 0,
      message: 'AWS health check failed',
      error: awsResults.reason?.message || 'Unknown error'
    },
    rds: {
      service: 'aws-rds',
      status: 'unhealthy' as const,
      timestamp: now(),
      responseTime: 0,
      message: 'AWS health check failed',
      error: awsResults.reason?.message || 'Unknown error'
    }
  };

  const external = externalResults.status === 'fulfilled' ? externalResults.value : [{
    service: 'external-dependencies',
    status: 'unhealthy' as const,
    timestamp: now(),
    responseTime: 0,
    message: 'External dependencies check failed',
    error: externalResults.reason?.message || 'Unknown error'
  }];

  const system = systemResults.status === 'fulfilled' ? systemResult : {
    service: 'system',
    status: 'unhealthy' as const,
    timestamp: now(),
    responseTime: 0,
    message: 'System health check failed',
    error: systemResults.reason?.message || 'Unknown error'
  };

  const application = applicationResults.status === 'fulfilled' ? applicationResult : {
    service: 'application',
    status: 'unhealthy' as const,
    timestamp: now(),
    responseTime: 0,
    message: 'Application health check failed',
    error: applicationResults.reason?.message || 'Unknown error'
  };

  const metrics = systemMetrics.status === 'fulfilled' ? systemMetrics.value : await getSystemMetrics();

  // Collect all results for summary
  const allResults: HealthCheckResult[] = [
    database,
    system,
    application,
    ...Object.values(aws),
    ...external
  ].filter(Boolean);

  const summary = calculateSummary(allResults);
  const overallStatus = getOverallStatus(allResults);

  // Create health history entry
  const historyEntry: HealthHistoryEntry = {
    timestamp: now(),
    overallStatus,
    checks: allResults,
    systemMetrics: metrics,
    summary
  };

  // Add to history
  addToHistory(historyEntry);

  return {
    timestamp: now(),
    status: overallStatus,
    version: process.env.npm_package_version || '1.0.0',
    environment: process.env.NODE_ENV || 'development',
    uptime: process.uptime(),
    checks: {
      database,
      aws,
      external,
      system,
      application
    },
    systemMetrics: metrics,
    summary,
    history: healthHistory.slice(-10), // Last 10 entries
    trends: calculateTrends()
  };
}

/**
 * Add entry to health history with retention management
 */
function addToHistory(entry: HealthHistoryEntry): void {
  healthHistory.push(entry);
  
  // Remove old entries based on retention policy
  const cutoffTime = now() - HEALTH_CHECK_CONFIG.history.retentionPeriod;
  healthHistory = healthHistory.filter(h => h.timestamp > cutoffTime);
  
  // Limit total entries
  if (healthHistory.length > HEALTH_CHECK_CONFIG.history.maxEntries) {
    healthHistory = healthHistory.slice(-HEALTH_CHECK_CONFIG.history.maxEntries);
  }
}

/**
 * Calculate trends from health history
 */
function calculateTrends() {
  if (healthHistory.length === 0) {
    return {
      last24Hours: {
        uptime: 100,
        avgResponseTime: 0,
        availability: 100,
        criticalIncidents: 0
      },
      last7Days: {
        uptime: 100,
        avgResponseTime: 0,
        availability: 100,
        criticalIncidents: 0
      }
    };
  }

  const now_ = now();
  const last24h = healthHistory.filter(h => h.timestamp > now_ - 24 * 60 * 60 * 1000);
  const last7d = healthHistory.filter(h => h.timestamp > now_ - 7 * 24 * 60 * 60 * 1000);

  const calculatePeriodStats = (entries: HealthHistoryEntry[]) => {
    if (entries.length === 0) {
      return {
        uptime: 100,
        avgResponseTime: 0,
        availability: 100,
        criticalIncidents: 0
      };
    }

    const healthyEntries = entries.filter(e => e.overallStatus === 'healthy' || e.overallStatus === 'degraded');
    const uptime = (healthyEntries.length / entries.length) * 100;
    
    const avgResponseTime = entries.reduce((sum, e) => sum + e.summary.avgResponseTime, 0) / entries.length;
    
    const criticalEntries = entries.filter(e => e.overallStatus === 'unhealthy');
    const criticalIncidents = criticalEntries.length;

    // Calculate availability (percentage of time when system was not unhealthy)
    const availability = uptime;

    return {
      uptime: Math.round(uptime * 100) / 100,
      avgResponseTime: Math.round(avgResponseTime * 100) / 100,
      availability: Math.round(availability * 100) / 100,
      criticalIncidents
    };
  };

  return {
    last24Hours: calculatePeriodStats(last24h),
    last7Days: calculatePeriodStats(last7d)
  };
}

/**
 * Get specific health check by service name
 */
async function getHealthCheck(serviceName: string): Promise<HealthCheckResult | HealthReport> {
  switch (serviceName.toLowerCase()) {
    case 'database':
      return await checkDatabase();
    
    case 'aws':
    case 'aws-services':
      const awsResults = await checkAWSServices();
      return {
        timestamp: now(),
        status: getOverallStatus(Object.values(awsResults)),
        checks: {
          database: {
            service: 'database',
            status: 'healthy' as const,
            timestamp: now(),
            responseTime: 0,
            message: 'Database check not included in AWS results'
          },
          aws: awsResults,
          external: [],
          system: {
            service: 'system',
            status: 'healthy' as const,
            timestamp: now(),
            responseTime: 0,
            message: 'System check not included in AWS results'
          },
          application: {
            service: 'application',
            status: 'healthy' as const,
            timestamp: now(),
            responseTime: 0,
            message: 'Application check not included in AWS results'
          }
        },
        systemMetrics: await getSystemMetrics(),
        summary: calculateSummary(Object.values(awsResults)),
        version: process.env.npm_package_version || '1.0.0',
        environment: process.env.NODE_ENV || 'development',
        uptime: process.uptime()
      };
    
    case 'external':
    case 'external-dependencies':
      const externalResults = await checkExternalDependencies();
      return {
        service: 'external-dependencies',
        status: getOverallStatus(externalResults),
        timestamp: now(),
        responseTime: 0,
        message: 'External dependencies check',
        metadata: { count: externalResults.length }
      };
    
    case 'system':
      return await checkSystemResources();
    
    case 'application':
      return await checkApplicationHealth();
    
    case 'full':
    case 'all':
    default:
      return await runAllHealthChecks();
  }
}

/**
 * Express router for health check endpoints
 */
export function createHealthRouter(): Router {
  const router = Router();

  // Basic health check endpoint
  router.get('/health', async (req: Request, res: Response) => {
    try {
      const service = req.query.service as string;
      
      if (service) {
        const result = await getHealthCheck(service);
        res.json(result);
      } else {
        const report = await runAllHealthChecks();
        res.json(report);
      }
    } catch (error) {
      res.status(500).json({
        error: 'Health check failed',
        message: error instanceof Error ? error.message : 'Unknown error',
        timestamp: now()
      });
    }
  });

  // Detailed health check with specific service
  router.get('/health/:service', async (req: Request, res: Response) => {
    try {
      const { service } = req.params;
      const result = await getHealthCheck(service);
      res.json(result);
    } catch (error) {
      res.status(500).json({
        error: 'Health check failed',
        message: error instanceof Error ? error.message : 'Unknown error',
        timestamp: now()
      });
    }
  });

  // Health history endpoint
  router.get('/health/history', (req: Request, res: Response) => {
    const limit = parseInt(req.query.limit as string) || 100;
    const period = req.query.period as string;
    
    let filteredHistory = healthHistory;
    
    if (period) {
      const now_ = now();
      const periodMs = {
        '1h': 60 * 60 * 1000,
        '24h': 24 * 60 * 60 * 1000,
        '7d': 7 * 24 * 60 * 60 * 1000,
        '30d': 30 * 24 * 60 * 60 * 1000
      }[period.toLowerCase()];
      
      if (periodMs) {
        filteredHistory = healthHistory.filter(h => h.timestamp > now_ - periodMs);
      }
    }
    
    res.json({
      history: filteredHistory.slice(-limit),
      trends: calculateTrends(),
      totalEntries: healthHistory.length
    });
  });

  // Health metrics endpoint (returns just the system metrics)
  router.get('/health/metrics', async (req: Request, res: Response) => {
    try {
      const metrics = await getSystemMetrics();
      res.json({
        timestamp: now(),
        metrics
      });
    } catch (error) {
      res.status(500).json({
        error: 'Failed to get metrics',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Health status endpoint (simple uptime check)
  router.get('/status', (req: Request, res: Response) => {
    res.json({
      status: 'ok',
      timestamp: now(),
      uptime: process.uptime(),
      environment: process.env.NODE_ENV || 'development',
      version: process.env.npm_package_version || '1.0.0'
    });
  });

  // Readiness probe (database connectivity)
  router.get('/ready', async (req: Request, res: Response) => {
    try {
      const result = await checkDatabase();
      
      if (result.status === 'healthy') {
        res.json({
          status: 'ready',
          timestamp: now()
        });
      } else {
        res.status(503).json({
          status: 'not_ready',
          timestamp: now(),
          error: result.message,
          details: result
        });
      }
    } catch (error) {
      res.status(503).json({
        status: 'not_ready',
        timestamp: now(),
        error: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Liveness probe (basic application health)
  router.get('/live', (req: Request, res: Response) => {
    res.json({
      status: 'alive',
      timestamp: now(),
      uptime: process.uptime()
    });
  });

  return router;
}

// Health check management functions

/**
 * Start automated health monitoring
 */
export function startHealthMonitoring(): void {
  console.log('🏥 Starting health monitoring...');
  
  const healthCheckInterval = setInterval(async () => {
    if (isShuttingDown) {
      clearInterval(healthCheckInterval);
      return;
    }
    
    try {
      await runAllHealthChecks();
    } catch (error) {
      console.error('❌ Scheduled health check failed:', error);
    }
  }, HEALTH_CHECK_CONFIG.system.interval);
  
  // Store interval ID for cleanup
  (global as any).healthCheckInterval = healthCheckInterval;
}

/**
 * Stop health monitoring
 */
export function stopHealthMonitoring(): void {
  console.log('🛑 Stopping health monitoring...');
  isShuttingDown = true;
  
  const interval = (global as any).healthCheckInterval;
  if (interval) {
    clearInterval(interval);
  }
}

/**
 * Run a single health check
 */
export async function runHealthCheck(service?: string): Promise<HealthCheckResult | HealthReport> {
  if (service) {
    return await getHealthCheck(service);
  }
  return await runAllHealthChecks();
}

/**
 * Get health check configuration
 */
export function getHealthCheckConfig() {
  return {
    ...HEALTH_CHECK_CONFIG,
    externalDependencies: EXTERNAL_DEPENDENCIES,
    historySize: healthHistory.length
  };
}

/**
 * Clear health check history
 */
export function clearHealthHistory(): void {
  healthHistory = [];
  console.log('🗑️  Health check history cleared');
}

/**
 * Get current health status
 */
export async function getCurrentHealthStatus(): Promise<HealthReport> {
  return await runAllHealthChecks();
}

// Export all functions and types
export {
  checkDatabase,
  checkAWSServices,
  checkExternalDependencies,
  checkSystemResources,
  checkApplicationHealth,
  getSystemMetrics,
  getHealthCheck,
  runAllHealthChecks,
  addToHistory,
  calculateTrends
};

export default {
  createHealthRouter,
  startHealthMonitoring,
  stopHealthMonitoring,
  runHealthCheck,
  getHealthCheckConfig,
  clearHealthHistory,
  getCurrentHealthStatus,
  getHealthCheck
};