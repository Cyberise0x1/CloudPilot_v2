import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { Request, Response, NextFunction } from 'express';

export interface User {
  id: string;
  email: string;
  username: string;
  password: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    username: string;
  };
}

// JWT Configuration
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '24h';
const JWT_REFRESH_EXPIRES_IN = process.env.JWT_REFRESH_EXPIRES_IN || '7d';

// Session configuration
const SESSION_TIMEOUT = 24 * 60 * 60 * 1000; // 24 hours in milliseconds

interface Session {
  userId: string;
  token: string;
  createdAt: Date;
  lastAccessed: Date;
  expiresAt: Date;
}

class SessionManager {
  private sessions: Map<string, Session> = new Map();

  createSession(userId: string, token: string): Session {
    const session: Session = {
      userId,
      token,
      createdAt: new Date(),
      lastAccessed: new Date(),
      expiresAt: new Date(Date.now() + SESSION_TIMEOUT),
    };
    
    this.sessions.set(token, session);
    return session;
  }

  getSession(token: string): Session | null {
    const session = this.sessions.get(token);
    if (!session) return null;

    // Check if session is expired
    if (session.expiresAt < new Date()) {
      this.sessions.delete(token);
      return null;
    }

    // Update last accessed time
    session.lastAccessed = new Date();
    return session;
  }

  removeSession(token: string): boolean {
    return this.sessions.delete(token);
  }

  removeUserSessions(userId: string): void {
    for (const [token, session] of this.sessions.entries()) {
      if (session.userId === userId) {
        this.sessions.delete(token);
      }
    }
  }

  cleanupExpiredSessions(): void {
    const now = new Date();
    for (const [token, session] of this.sessions.entries()) {
      if (session.expiresAt < now) {
        this.sessions.delete(token);
      }
    }
  }
}

export const sessionManager = new SessionManager();

// Password hashing functions
export const hashPassword = async (password: string): Promise<string> => {
  const saltRounds = 12;
  return await bcrypt.hash(password, saltRounds);
};

export const verifyPassword = async (password: string, hashedPassword: string): Promise<boolean> => {
  return await bcrypt.compare(password, hashedPassword);
};

// JWT token generation
export const generateAccessToken = (user: { id: string; email: string; username: string }): string => {
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      username: user.username,
    },
    JWT_SECRET,
    {
      expiresIn: JWT_EXPIRES_IN,
      issuer: 'cloudpilot',
      audience: 'cloudpilot-api',
    }
  );
};

export const generateRefreshToken = (user: { id: string; email: string; username: string }): string => {
  return jwt.sign(
    {
      id: user.id,
      type: 'refresh',
    },
    JWT_SECRET,
    {
      expiresIn: JWT_REFRESH_EXPIRES_IN,
      issuer: 'cloudpilot',
      audience: 'cloudpilot-api',
    }
  );
};

export const generateTokens = (user: { id: string; email: string; username: string }) => {
  const accessToken = generateAccessToken(user);
  const refreshToken = generateRefreshToken(user);
  
  // Create session
  const session = sessionManager.createSession(user.id, refreshToken);
  
  return {
    accessToken,
    refreshToken,
    expiresIn: JWT_EXPIRES_IN,
    sessionCreated: session.createdAt,
  };
};

// JWT token verification middleware
export const authenticateToken = async (
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (!token) {
      res.status(401).json({
        success: false,
        message: 'Access token is required',
        error: 'TOKEN_MISSING',
      });
      return;
    }

    // Verify the JWT token
    const decoded = jwt.verify(token, JWT_SECRET) as {
      id: string;
      email: string;
      username: string;
      iat: number;
      exp: number;
      iss: string;
      aud: string;
    };

    // Check token issuer and audience
    if (decoded.iss !== 'cloudpilot' || decoded.aud !== 'cloudpilot-api') {
      res.status(401).json({
        success: false,
        message: 'Invalid token',
        error: 'TOKEN_INVALID',
      });
      return;
    }

    // Attach user info to request
    req.user = {
      id: decoded.id,
      email: decoded.email,
      username: decoded.username,
    };

    next();
  } catch (error) {
    if (error instanceof jwt.TokenExpiredError) {
      res.status(401).json({
        success: false,
        message: 'Token has expired',
        error: 'TOKEN_EXPIRED',
      });
      return;
    }

    if (error instanceof jwt.JsonWebTokenError) {
      res.status(401).json({
        success: false,
        message: 'Invalid token',
        error: 'TOKEN_INVALID',
      });
      return;
    }

    res.status(500).json({
      success: false,
      message: 'Token verification failed',
      error: 'TOKEN_VERIFICATION_ERROR',
    });
  }
};

// Optional authentication middleware (doesn't fail if no token)
export const optionalAuth = async (
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (token) {
      const decoded = jwt.verify(token, JWT_SECRET) as {
        id: string;
        email: string;
        username: string;
        iat: number;
        exp: number;
        iss: string;
        aud: string;
      };

      if (decoded.iss === 'cloudpilot' && decoded.aud === 'cloudpilot-api') {
        req.user = {
          id: decoded.id,
          email: decoded.email,
          username: decoded.username,
        };
      }
    }

    next();
  } catch (error) {
    // Silently continue without authentication
    next();
  }
};

// Refresh token verification
export const verifyRefreshToken = (refreshToken: string): { id: string; email: string; username: string } | null => {
  try {
    const decoded = jwt.verify(refreshToken, JWT_SECRET) as {
      id: string;
      type: string;
      iat: number;
      exp: number;
      iss: string;
      aud: string;
    };

    // Check if it's a refresh token
    if (decoded.type !== 'refresh') {
      return null;
    }

    // Check issuer and audience
    if (decoded.iss !== 'cloudpilot' || decoded.aud !== 'cloudpilot-api') {
      return null;
    }

    // Check if session exists
    const session = sessionManager.getSession(refreshToken);
    if (!session) {
      return null;
    }

    // Return user info
    return {
      id: decoded.id,
      email: '', // We would need to fetch this from database
      username: '', // We would need to fetch this from database
    };
  } catch (error) {
    return null;
  }
};

// Session management functions
export const refreshSession = (refreshToken: string): { accessToken: string; refreshToken: string } | null => {
  const userInfo = verifyRefreshToken(refreshToken);
  
  if (!userInfo) {
    return null;
  }

  // Remove old session
  sessionManager.removeSession(refreshToken);

  // Generate new tokens
  return generateTokens(userInfo);
};

export const logout = (refreshToken: string): boolean => {
  return sessionManager.removeSession(refreshToken);
};

export const logoutAllSessions = (userId: string): void => {
  sessionManager.removeUserSessions(userId);
};

// Admin check middleware
export const requireAdmin = (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
  if (!req.user) {
    res.status(401).json({
      success: false,
      message: 'Authentication required',
      error: 'AUTHENTICATION_REQUIRED',
    });
    return;
  }

  // Add admin role check logic here (e.g., check from database)
  // For now, assuming all authenticated users are admins
  // In a real implementation, you'd check req.user.role === 'admin'
  
  next();
};

// Rate limiting for auth endpoints
const authAttempts: Map<string, { count: number; lastAttempt: number }> = new Map();

export const rateLimitAuth = (maxAttempts: number = 5, windowMs: number = 15 * 60 * 1000): (req: Request, res: Response, next: NextFunction) => void => {
  return (req: Request, res: Response, next: NextFunction): void => {
    const key = req.ip || req.connection.remoteAddress || 'unknown';
    const now = Date.now();
    const attempts = authAttempts.get(key);

    if (!attempts) {
      authAttempts.set(key, { count: 1, lastAttempt: now });
      next();
      return;
    }

    // Reset if window has passed
    if (now - attempts.lastAttempt > windowMs) {
      authAttempts.set(key, { count: 1, lastAttempt: now });
      next();
      return;
    }

    // Check if max attempts exceeded
    if (attempts.count >= maxAttempts) {
      const retryAfter = Math.ceil((windowMs - (now - attempts.lastAttempt)) / 1000);
      res.status(429).json({
        success: false,
        message: 'Too many authentication attempts. Please try again later.',
        error: 'RATE_LIMIT_EXCEEDED',
        retryAfter,
      });
      return;
    }

    // Increment attempts
    attempts.count++;
    attempts.lastAttempt = now;
    next();
  };
};

// Utility functions
export const generateSecureId = (): string => {
  return Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
};

export const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

export const isValidPassword = (password: string): { valid: boolean; message?: string } => {
  if (password.length < 8) {
    return { valid: false, message: 'Password must be at least 8 characters long' };
  }
  
  if (!/(?=.*[a-z])/.test(password)) {
    return { valid: false, message: 'Password must contain at least one lowercase letter' };
  }
  
  if (!/(?=.*[A-Z])/.test(password)) {
    return { valid: false, message: 'Password must contain at least one uppercase letter' };
  }
  
  if (!/(?=.*\d)/.test(password)) {
    return { valid: false, message: 'Password must contain at least one number' };
  }
  
  if (!/(?=.*[@$!%*?&])/.test(password)) {
    return { valid: false, message: 'Password must contain at least one special character' };
  }
  
  return { valid: true };
};

// Cleanup expired sessions periodically
setInterval(() => {
  sessionManager.cleanupExpiredSessions();
}, 60 * 60 * 1000); // Run every hour

// Export all functions
export default {
  // Password functions
  hashPassword,
  verifyPassword,
  
  // Token functions
  generateAccessToken,
  generateRefreshToken,
  generateTokens,
  verifyRefreshToken,
  refreshSession,
  
  // Middleware
  authenticateToken,
  optionalAuth,
  requireAdmin,
  rateLimitAuth,
  
  // Session management
  logout,
  logoutAllSessions,
  sessionManager,
  
  // Utilities
  generateSecureId,
  isValidEmail,
  isValidPassword,
};