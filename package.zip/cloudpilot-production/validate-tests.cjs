#!/usr/bin/env node
/**
 * Integration Test Validator
 * Validates the structure and syntax of integration tests
 */

const fs = require('fs');
const path = require('path');

// Test files to validate
const testFiles = [
  '__tests__/auth.integration.test.ts',
  '__tests__/aws-endpoints.integration.test.ts',
  '__tests__/health.integration.test.ts',
  '__tests__/monitoring.integration.test.ts',
  '__tests__/error-handling.integration.test.ts'
];

// Setup files to validate
const setupFiles = [
  '__tests__/setup/test-server.ts',
  '__tests__/setup/setup.ts',
  '__tests__/setup/global-teardown.ts'
];

console.log('🧪 Integration Test Validator\n');
console.log('=' .repeat(60));

let totalTests = 0;
let totalLines = 0;
let validationErrors = [];

// Validate test files
testFiles.forEach((file, index) => {
  const filePath = path.join(__dirname, file);
  
  if (fs.existsSync(filePath)) {
    const content = fs.readFileSync(filePath, 'utf8');
    const lines = content.split('\n').length;
    const testCount = (content.match(/it\s*\(/g) || []).length;
    
    console.log(`\n✅ ${file}`);
    console.log(`   Lines: ${lines}`);
    console.log(`   Test Cases: ${testCount}`);
    
    totalTests += testCount;
    totalLines += lines;
    
    // Check for key patterns
    const hasVitestImports = content.includes("from 'vitest'");
    const hasSupertest = content.includes("from 'supertest'");
    const hasDescribe = content.includes('describe(');
    const hasIt = content.includes('it(');
    
    if (!hasVitestImports) {
      validationErrors.push(`${file}: Missing vitest imports`);
    }
    if (!hasSupertest) {
      validationErrors.push(`${file}: Missing supertest imports`);
    }
    if (!hasDescribe) {
      validationErrors.push(`${file}: Missing describe blocks`);
    }
    if (!hasIt) {
      validationErrors.push(`${file}: Missing test cases`);
    }
  } else {
    console.log(`\n❌ ${file} - NOT FOUND`);
    validationErrors.push(`${file}: File not found`);
  }
});

console.log('\n' + '=' .repeat(60));

// Validate setup files
console.log('\n📦 Setup Files:');
setupFiles.forEach(file => {
  const filePath = path.join(__dirname, file);
  if (fs.existsSync(filePath)) {
    console.log(`   ✅ ${file}`);
  } else {
    console.log(`   ⚠️  ${file} - Optional file`);
  }
});

// Summary
console.log('\n' + '=' .repeat(60));
console.log('\n📊 Summary:');
console.log(`   Total Test Files: ${testFiles.length}`);
console.log(`   Total Test Cases: ${totalTests}`);
console.log(`   Total Lines of Code: ${totalLines}`);
console.log(`   Average Tests per File: ${Math.round(totalTests / testFiles.length)}`);

if (validationErrors.length === 0) {
  console.log('\n🎉 All validation checks passed!');
  console.log('\n✅ Integration test suite is properly structured');
  console.log('✅ Ready for execution with: npm run test:integration');
} else {
  console.log('\n⚠️  Validation Issues Found:');
  validationErrors.forEach(error => {
    console.log(`   - ${error}`);
  });
}

console.log('\n📝 Test Coverage Areas:');
console.log('   🔐 Authentication (register, login, logout, refresh)');
console.log('   ☁️  AWS Services (EC2, S3, RDS, CloudFront)');
console.log('   ❤️  Health Checks (basic, detailed, metrics)');
console.log('   📊 Monitoring (metrics, alerts, performance)');
console.log('   ❌ Error Handling (validation, auth, server errors)');

console.log('\n🚀 Next Steps:');
console.log('   1. Run: npm install (if dependencies not installed)');
console.log('   2. Run: npm run test:integration');
console.log('   3. Review: INTEGRATION_TESTS_EXECUTIVE_REPORT.md');

console.log('\n' + '=' .repeat(60));
console.log('✨ Integration Test Suite Validation Complete\n');