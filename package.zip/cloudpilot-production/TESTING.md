# Testing Guide

This document provides information about the comprehensive testing setup for the CloudPilot application.

## Overview

The testing suite includes:
- **Service Layer Tests**: Unit tests for all core services (Auth, AWS, Storage, Health, Metrics, Error Tracking)
- **Integration Tests**: End-to-end service integration testing
- **Test Framework**: Vitest for fast, modern testing
- **Code Coverage**: Comprehensive coverage reporting

## Test Structure

```
tests/
├── auth.service.test.ts           # Authentication service tests
├── secrets-manager.test.ts        # Secrets management tests
├── aws-service.test.ts            # AWS SDK integration tests
├── storage.test.ts                # Database storage tests
├── health.test.ts                 # Health monitoring tests
├── metrics.test.ts                # Metrics collection tests
└── error-tracking.test.ts         # Error tracking and alerting tests
```

## Running Tests

### All Tests
```bash
# Run all tests
npm run test

# Run services tests only
npm run test:services
```

### Specific Service Tests
```bash
# Individual service tests
npm run test:auth
npm run test:secrets
npm run test:aws
npm run test:storage
npm run test:health
npm run test:metrics
npm run test:error-tracking

# Run all service tests
npm run test:all-services
```

### Watch Mode
```bash
# Watch all tests
npm run test:watch

# Watch specific services
npm run test:watch:auth
npm run test:watch:aws
npm run test:watch:metrics
```

### Coverage Reports
```bash
# Generate coverage report
npm run test:coverage

# Service-specific coverage
npm run test:coverage:services

# View HTML coverage report (creates coverage/index.html)
```

## Test Features

### 1. Auth Service Tests (`auth.service.test.ts`)
- User registration and authentication
- JWT token generation and validation
- Session management
- Password hashing with bcrypt
- Middleware protection
- Role-based access control
- Edge cases and error scenarios

### 2. Secrets Manager Tests (`secrets-manager.test.ts`)
- Secret validation and loading
- Environment variable handling
- Secret caching mechanisms
- Error handling for missing secrets
- Statistics and monitoring

### 3. AWS Service Tests (`aws-service.test.ts`)
- AWS SDK client initialization
- EC2, S3, RDS, CloudFront operations
- Credential management
- Error handling and retries
- Mock AWS responses for testing
- Service availability checks

### 4. Storage Tests (`storage.test.ts`)
- Database CRUD operations
- User management
- AWS account integration
- EC2 instance management
- Error handling and transactions
- Data validation

### 5. Health Check Tests (`health.test.ts`)
- Database connectivity checks
- AWS services health monitoring
- External dependencies testing
- System resource monitoring
- Application health indicators
- Health history and trends

### 6. Metrics Tests (`metrics.test.ts`)
- Counter, Gauge, and Histogram metrics
- Request tracking and aggregation
- AWS operations monitoring
- Business metrics collection
- System metrics gathering
- Prometheus format export
- Dashboard data generation

### 7. Error Tracking Tests (`error-tracking.test.ts`)
- Error classification and deduplication
- Alert rule management
- Performance impact tracking
- Error analytics and trends
- Notification channels (webhook, email, Slack, SMS)
- Express middleware integration

## Testing Utilities

### Mocking
The test setup includes comprehensive mocks for:
- AWS SDK clients
- Database operations
- External services
- File system operations
- Network requests

### Test Helpers
```typescript
// Create mock requests/responses
createMockRequest()
createMockResponse()
createMockNext()

// Test data factories
createTestUser()
createTestAWSAccount()
createTestEC2Instance()

// Async testing
waitFor()
```

### Mock Services
```typescript
// Pre-configured mocks
mockAWSService
mockDatabase
mockSecretsManager
mockMetrics
mockErrorTracking
```

## Configuration

### Vitest Configuration (`vitest.config.ts`)
- Global test setup
- Coverage thresholds (70%)
- Test environment setup
- Include/exclude patterns
- Reporter configuration

### Test Setup (`test-setup.ts`)
- Global before/after hooks
- Environment variables
- Mock configurations
- Helper functions
- Test data factories

## Coverage Requirements

The test suite maintains these coverage thresholds:
- **Branches**: 70%
- **Functions**: 70%
- **Lines**: 70%
- **Statements**: 70%

## Best Practices

### Test Structure
1. **Arrange-Act-Assert** pattern
2. Descriptive test names
3. Single responsibility per test
4. Proper cleanup after tests

### Mocking Guidelines
1. Mock external dependencies
2. Use real implementations for core logic
3. Clean up mocks after tests
4. Avoid over-mocking

### Error Testing
1. Test happy paths first
2. Test error conditions
3. Test edge cases
4. Verify error messages

## Continuous Integration

### CI Commands
```bash
# Run tests in CI environment
npm run test:ci

# Generate JUnit XML report
npm run test:junit

# Generate JSON report
npm run test:json
```

### Pre-commit Hooks
- Run linting on test files
- Format test code
- Validate test coverage

## Debugging Tests

### Debug Mode
```bash
# Run tests in debug mode
npm run test:debug

# Inspect specific test
npm run test -- --inspect-brk tests/auth.service.test.ts
```

### Verbose Output
```bash
# Detailed test output
npm run test:verbose

# Silent mode (less output)
npm run test:silent
```

### Failed Test Investigation
1. Check test output for error details
2. Use debug mode to step through
3. Verify mock configurations
4. Check test data setup

## Adding New Tests

### Service Test Template
```typescript
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { YourService } from '../server/your-service';

// Mock dependencies
vi.mock('../server/dependency', () => ({
  dependency: {
    method: vi.fn()
  }
}));

describe('YourService', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('methodName', () => {
    it('should handle success case', async () => {
      // Arrange
      const input = 'test input';
      
      // Act
      const result = await YourService.methodName(input);
      
      // Assert
      expect(result).toBe('expected output');
    });

    it('should handle error case', async () => {
      // Test error scenarios
    });
  });
});
```

### Test Checklist
- [ ] Mock external dependencies
- [ ] Test all public methods
- [ ] Test error conditions
- [ ] Test edge cases
- [ ] Verify cleanup
- [ ] Check coverage impact

## Troubleshooting

### Common Issues

1. **Tests timing out**
   - Check for unhandled promises
   - Verify mock cleanup
   - Increase test timeout

2. **Mock not working**
   - Verify mock setup
   - Check module paths
   - Ensure proper cleanup

3. **Coverage too low**
   - Identify uncovered code
   - Add missing test cases
   - Check coverage thresholds

4. **Memory leaks in tests**
   - Clean up timers
   - Clear mocks properly
   - Reset global state

### Performance Optimization
- Run tests in parallel (`npm run test`)
- Use watch mode for development
- Run specific tests during development
- Optimize mock setups

## Resources

- [Vitest Documentation](https://vitest.dev/)
- [Testing Best Practices](./docs/testing-best-practices.md)
- [Mocking Guidelines](./docs/mocking-guidelines.md)
- [Coverage Reports](./coverage/index.html)
