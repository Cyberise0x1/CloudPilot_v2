# Jest Testing Framework Setup

## Overview

This repository includes a comprehensive Jest testing framework for the CloudPilot Production application. The setup includes TypeScript support, coverage reporting, mock configurations, and utilities for testing Express.js applications with AWS services and database integrations.

## 📁 Test Directory Structure

```
tests/
├── setup/                    # Global test setup and configuration
│   ├── setup.ts             # Main setup file (runs before each test)
│   ├── global-teardown.ts   # Global cleanup (runs after all tests)
│   ├── global-test-utils.ts # Global test utilities and custom matchers
│   ├── database-setup.ts    # Database mocking and test data utilities
│   ├── database-cleanup.ts  # Database cleanup functions
│   ├── aws-mocks.ts         # AWS services mocking
│   ├── env-mocks.ts         # Environment variable mocking
│   ├── express-test-utils.ts # Express.js testing utilities
│   ├── environment-cleanup.ts # Environment cleanup
│   └── database-cleanup-utils.ts # Database cleanup utilities
├── unit/                    # Unit tests
│   └── protected.test.ts   # Example unit tests for protected middleware
├── integration/            # Integration tests
│   └── auth-integration.test.ts # Example integration tests
├── e2e/                    # End-to-end tests
│   └── auth-e2e.test.ts   # Example E2E tests
├── mocks/                  # Test mocks and fixtures
│   └── test-mocks.ts      # Mock data for testing
├── fixtures/              # Test fixtures and static data
│   └── test-fixtures.ts   # Fixed test data
├── utils/                 # Test utilities and helpers
│   └── test-utils.ts      # Common test utilities
└── helpers/               # Test helper functions
```

## 🚀 Quick Start

### 1. Install Dependencies

```bash
npm install
```

The Jest framework dependencies are already included in the `devDependencies`:

- `jest` - Testing framework
- `ts-jest` - TypeScript support for Jest
- `jest-environment-node` - Node.js test environment
- `@jest/globals` - Jest globals
- `jest-mock-extended` - Extended mocking utilities
- `jest-extended` - Additional Jest matchers
- `supertest` - HTTP testing utilities

### 2. Run Tests

#### Using NPM Scripts

```bash
# Run all tests
npm test

# Run specific test types
npm run test:unit           # Unit tests only
npm run test:integration    # Integration tests only
npm run test:e2e           # E2E tests only

# Run tests with coverage
npm run test:coverage

# Run tests in watch mode
npm run test:watch

# Run specific test files
npm run test:auth           # Tests matching 'auth'
npm run test:protected      # Tests matching 'protected'
```

#### Using the Test Runner Script

```bash
# Make script executable (if permissions allow)
chmod +x run-tests.sh

# Run tests using the script
./run-tests.sh unit unit --coverage
./run-tests.sh integration integration --verbose
./run-tests.sh watch unit
./run-tests.sh coverage all
```

### 3. Coverage Reports

Coverage reports are generated in the `coverage/` directory:

```bash
# Generate coverage report
npm run test:coverage

# Generate HTML coverage report
npm run test:report:html

# Generate LCOV coverage report (for CI/CD)
npm run test:report:lcov
```

## 📊 Configuration

### Jest Configuration (jest.config.js)

The framework includes a comprehensive Jest configuration with:

- **TypeScript Support**: Using `ts-jest` with ES2020 target
- **Coverage Thresholds**: 80% for branches, functions, lines, and statements
- **Coverage Reports**: HTML, LCOV, JSON, text, and text-summary formats
- **Test Patterns**: Flexible patterns for different test types
- **Environment Variables**: Automatic loading of test environment variables
- **Mocking**: Built-in mocks for AWS services, databases, and Express

### Environment Variables

Test environment variables are automatically loaded from `tests/setup/env-mocks.ts`:

```typescript
const defaultTestEnv = {
  NODE_ENV: 'test',
  PORT: '3001',
  DATABASE_URL: 'postgresql://test:test@localhost:5432/test_db',
  JWT_SECRET: 'test-jwt-secret-key-for-testing-only',
  AWS_REGION: 'us-east-1',
  // ... more defaults
};
```

## 🧪 Testing Patterns

### Unit Testing

Unit tests focus on individual functions and components:

```typescript
describe('requireAuth Middleware', () => {
  test('should authenticate valid JWT token', async () => {
    // Test implementation
    const mockReq = expressTestUtils.createMockRequest({
      headers: { authorization: 'Bearer valid-token' }
    });
    
    await requireAuth(mockReq as Request, mockRes as Response, mockNext);
    
    expect(mockNext).toHaveBeenCalled();
    expect(mockReq.user).toBeDefined();
  });
});
```

### Integration Testing

Integration tests verify interactions between components:

```typescript
describe('User Registration Workflow', () => {
  test('should register new user successfully', async () => {
    const userData = testDataGenerators.generateUser({
      email: 'newuser@example.com',
      password: 'securePassword123'
    });
    
    // Test complete workflow
    const response = await request(app)
      .post('/api/auth/register')
      .send(userData)
      .expect(201);
      
    expect(response.body.success).toBe(true);
  });
});
```

### End-to-End Testing

E2E tests verify complete user workflows:

```typescript
describe('Complete User Journey', () => {
  test('should complete full user registration and authentication flow', async () => {
    // 1. User Registration
    // 2. User Login
    // 3. Access Protected Route
    // 4. Update Profile
    // 5. Refresh Token
    // 6. Logout
  });
});
```

## 🔧 Testing Utilities

### Express Testing Utilities

```typescript
// Create mock request
const mockReq = expressTestUtils.createMockRequest({
  method: 'POST',
  url: '/api/auth/login',
  body: { email: 'test@example.com', password: 'password123' }
});

// Create mock response
const mockRes = expressTestUtils.createMockResponse();

// Create mock next function
const mockNext = expressTestUtils.createMockNext();
```

### Authentication Testing

```typescript
// Create authenticated request
const authReq = authTestUtils.createAuthenticatedRequest('user-123', 'test@example.com');

// Create admin request
const adminReq = authTestUtils.createAdminRequest();
```

### Data Generation

```typescript
// Generate test user
const user = testDataGenerators.generateUser({
  email: 'newuser@example.com'
});

// Generate session
const session = testDataGenerators.generateSession({
  user_id: 'user-123'
});
```

### Custom Matchers

```typescript
// Date range validation
expect(testDate).toBeWithinRange(startDate, endDate);

// Email validation
expect('test@example.com').toBeValidEmail();

// UUID validation
expect('550e8400-e29b-41d4-a716-446655440000').toBeValidUUID();
```

## 🛠 Mock Configuration

### Database Mocks

The framework includes comprehensive database mocking:

```typescript
// Mock successful query
databaseTestHelpers.mockDbQuery({
  rows: [mockUser],
  rowCount: 1
});

// Mock database error
databaseTestHelpers.mockDbError(new Error('Connection failed'));

// Reset mocks
databaseTestHelpers.resetDbMocks();
```

### AWS Service Mocks

Mock AWS services for testing:

```typescript
// S3 operations
awsTestUtils.s3.uploadObject.mockResolvedValue({
  ETag: '"test-etag"',
  Location: 'https://test-bucket.s3.amazonaws.com/test-file.txt'
});

// Secrets Manager
awsTestUtils.secretsManager.getSecret.mockResolvedValue({
  SecretString: JSON.stringify({
    username: 'test',
    password: 'test123'
  })
});
```

### Environment Variables

```typescript
// Set test environment
envTestUtils.setTestEnv({
  JWT_SECRET: 'custom-test-secret',
  DATABASE_URL: 'custom-test-db-url'
});

// Reset environment
envTestUtils.reset();
```

## 📝 Writing Tests

### Test File Naming

- **Unit tests**: `*.test.ts` or `*.spec.ts` in `tests/unit/`
- **Integration tests**: `*.test.ts` or `*.spec.ts` in `tests/integration/`
- **E2E tests**: `*.test.ts` or `*.spec.ts` in `tests/e2e/`

### Test Structure

```typescript
describe('Feature/Module Name', () => {
  let testSetup: any;
  
  beforeAll(async () => {
    // Setup once before all tests
  });
  
  beforeEach(async () => {
    // Setup before each test
  });
  
  afterEach(() => {
    // Cleanup after each test
  });
  
  afterAll(async () => {
    // Cleanup after all tests
  });
  
  test('should perform expected behavior', async () => {
    // Arrange
    // Act
    // Assert
  });
  
  test('should handle edge cases', () => {
    // Test implementation
  });
});
```

### Test Organization

1. **Arrange-Act-Assert** pattern
2. **Descriptive test names** that explain expected behavior
3. **Proper setup and teardown** in beforeEach/afterEach
4. **Mock external dependencies**
5. **Test both success and error scenarios**

## 📊 Coverage Reports

### Coverage Configuration

```javascript
// Coverage thresholds
coverageThreshold: {
  global: {
    branches: 80,
    functions: 80,
    lines: 80,
    statements: 80
  }
}
```

### Coverage Reports

- **Text**: Console output
- **HTML**: Interactive report in `coverage/lcov-report/index.html`
- **LCOV**: For CI/CD integration
- **JSON**: Machine-readable format

### Improving Coverage

1. Test all code paths (success, error, edge cases)
2. Test boundary conditions
3. Test error handling
4. Mock external dependencies
5. Include integration points

## 🚦 CI/CD Integration

### GitHub Actions Example

```yaml
name: Tests
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    
    services:
      postgres:
        image: postgres:14
        env:
          POSTGRES_PASSWORD: test
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
    
    - name: Install dependencies
      run: npm install
    
    - name: Run tests
      run: npm run test:ci
      env:
        DATABASE_URL: postgresql://postgres:test@localhost:5432/test
    
    - name: Upload coverage
      uses: codecov/codecov-action@v3
      with:
        file: ./coverage/lcov.info
```

## 🔍 Debugging Tests

### Debug Mode

```bash
# Run tests in debug mode
npm run test:debug

# Run specific test in debug mode
npm test -- --testNamePattern="should authenticate valid token"
```

### Verbose Output

```bash
# Run tests with verbose output
npm run test:verbose
```

### Clear Cache

```bash
# Clear Jest cache
npm run test:clear
```

## 🎯 Best Practices

### 1. Test Isolation

- Each test should be independent
- Use `beforeEach` and `afterEach` for setup/teardown
- Reset mocks between tests

### 2. Mock External Dependencies

- Mock AWS services
- Mock database operations
- Mock third-party APIs
- Mock file system operations

### 3. Test Data Management

- Use factories for consistent test data
- Avoid hardcoded values
- Generate random data when appropriate
- Use fixtures for static data

### 4. Performance

- Run unit tests frequently (watch mode)
- Run integration tests before commits
- Run full test suite in CI/CD
- Use test parallelization (`maxWorkers`)

### 5. Maintainability

- Keep tests simple and readable
- Use descriptive test names
- Group related tests with `describe` blocks
- Extract common setup into helper functions

## 📚 Additional Resources

- [Jest Documentation](https://jestjs.io/docs)
- [TypeScript and Jest](https://jestjs.io/docs/getting-started#using-typescript)
- [Testing Express.js with Jest](https://jestjs.io/docs/tutorial-async)
- [Mocking with Jest](https://jestjs.io/docs/mock-functions)
- [Coverage Reports](https://jestjs.io/docs/configuration#collectcoveragefrom)

## 🔧 Troubleshooting

### Common Issues

1. **Test timeout errors**
   - Increase timeout with `testTimeout` in jest.config.js
   - Check for hanging promises

2. **Module resolution errors**
   - Ensure `tsconfig.json` paths are correct
   - Check Jest module mapping configuration

3. **Database connection errors**
   - Verify test database is running
   - Check DATABASE_URL environment variable

4. **AWS service errors**
   - Verify AWS credentials are mocked
   - Check AWS service region configuration

### Getting Help

- Check Jest configuration in `jest.config.js`
- Review test setup in `tests/setup/`
- Check mock implementations in `tests/mocks/`
- Run tests with `--verbose` flag for detailed output

---

This comprehensive Jest testing framework provides everything needed to write robust, maintainable tests for the CloudPilot Production application. The framework supports unit testing, integration testing, and end-to-end testing with comprehensive mocking and utilities.
