# 🔐 Authentication System - CloudPilot Production

## Overview

CloudPilot now includes a comprehensive JWT-based authentication system to secure all AWS management endpoints. This system provides user registration, login, role-based access control, and session management.

## 🚀 Features

- **JWT Authentication**: Secure token-based authentication
- **Role-Based Access Control**: Admin, Manager, User, Viewer roles
- **Session Management**: Automatic session cleanup and multi-session support
- **Password Security**: bcrypt hashing with configurable salt rounds
- **Protected Routes**: All AWS endpoints now require authentication
- **Refresh Tokens**: Long-lived refresh tokens for seamless user experience
- **Rate Limiting**: Protection against brute force attacks

## 📁 New Files Added

```
cloudpilot-production/
├── server/auth.ts              # Core authentication middleware
├── server/auth-routes.ts       # Authentication API endpoints
├── server/protected.ts         # Route protection middleware
├── server/.env                 # Environment configuration
├── server/.env.example         # Environment template
└── shared/schema.ts           # Updated with users table
```

## 🔑 Environment Variables

Create `server/.env` with the following variables:

```bash
# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key-min-32-chars
JWT_EXPIRES_IN=15m
JWT_REFRESH_SECRET=your-refresh-secret-key-min-32-chars
JWT_REFRESH_EXPIRES_IN=7d

# Session Configuration
SESSION_SECRET=your-session-secret-key

# Database
DATABASE_URL=your-database-connection-string
```

## 🛠 API Endpoints

### Authentication Endpoints

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| POST | `/api/auth/register` | Register new user | ❌ |
| POST | `/api/auth/login` | User login | ❌ |
| POST | `/api/auth/logout` | User logout | ❌ |
| GET | `/api/auth/me` | Get current user info | ✅ |
| POST | `/api/auth/refresh` | Refresh access token | ❌ |

### AWS Management Endpoints (Now Protected)

All AWS management endpoints now require authentication:

| Resource | Endpoints | Auth Required |
|----------|-----------|---------------|
| **AWS Accounts** | GET/POST `/api/aws-accounts` | ✅ |
| **EC2 Instances** | All EC2 endpoints | ✅ |
| **S3 Buckets** | All S3 endpoints | ✅ |
| **RDS Instances** | All RDS endpoints | ✅ |
| **CloudFront** | All CloudFront endpoints | ✅ |
| **Instance Templates** | All template endpoints | ✅ |

## 🔐 Usage Examples

### 1. User Registration

```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@company.com",
    "password": "SecurePassword123!",
    "fullName": "Admin User",
    "role": "admin"
  }'
```

### 2. User Login

```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@company.com",
    "password": "SecurePassword123!"
  }'
```

**Response:**
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": "uuid",
    "email": "admin@company.com",
    "fullName": "Admin User",
    "role": "admin"
  }
}
```

### 3. Access Protected Endpoints

```bash
curl -X GET http://localhost:5000/api/aws-accounts \
  -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIs..."
```

### 4. Refresh Token

```bash
curl -X POST http://localhost:5000/api/auth/refresh \
  -H "Content-Type: application/json" \
  -d '{
    "refreshToken": "eyJhbGciOiJIUzI1NiIs..."
  }'
```

## 🛡 Security Features

### Password Requirements
- Minimum 8 characters
- At least one uppercase letter
- At least one lowercase letter
- At least one number
- At least one special character

### Token Security
- **Access Tokens**: 15-minute expiration
- **Refresh Tokens**: 7-day expiration
- **Automatic Cleanup**: Expired sessions are automatically cleaned up
- **Rate Limiting**: 5 login attempts per 15-minute window

### Role-Based Access Control

| Role | Permissions |
|------|-------------|
| **ADMIN** | Full access to all AWS resources and user management |
| **MANAGER** | Can manage AWS resources and view all data |
| **USER** | Can manage assigned AWS resources |
| **VIEWER** | Read-only access to AWS resources |

## 🔧 Implementation Details

### Database Schema

The authentication system adds these new tables:

```sql
-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR UNIQUE NOT NULL,
    passwordHash VARCHAR NOT NULL,
    fullName VARCHAR NOT NULL,
    role TEXT CHECK (role IN ('admin', 'manager', 'user', 'viewer')) NOT NULL,
    isActive BOOLEAN DEFAULT true,
    createdAt TIMESTAMP DEFAULT NOW(),
    updatedAt TIMESTAMP DEFAULT NOW()
);

-- Refresh tokens table
CREATE TABLE refreshTokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    userId UUID REFERENCES users(id),
    tokenHash VARCHAR NOT NULL,
    expiresAt TIMESTAMP NOT NULL,
    createdAt TIMESTAMP DEFAULT NOW()
);
```

### Middleware Integration

All existing AWS endpoints are now protected:

```typescript
// Before: Open access
app.get("/api/aws/instances/:accountId", async (req, res) => {
  // AWS logic here
});

// After: Protected access
app.get("/api/aws/instances/:accountId", 
  requireAuth,  // JWT verification
  async (req, res) => {
    // AWS logic here - req.user contains user info
  }
);
```

## 🚀 Deployment

1. **Install Dependencies**: `npm install`
2. **Set Environment Variables**: Copy `.env.example` to `.env` and configure
3. **Run Database Migrations**: `npm run db:push`
4. **Start Server**: `npm run dev` (development) or `npm start` (production)

## 🧪 Testing

### Test Authentication Flow

```bash
# 1. Register user
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email": "test@test.com", "password": "Test123!", "fullName": "Test User"}'

# 2. Login to get tokens
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "test@test.com", "password": "Test123!"}'

# 3. Access protected endpoint
curl -X GET http://localhost:5000/api/aws-accounts \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

## 🔍 Troubleshooting

### Common Issues

1. **"JWT_SECRET not found"**
   - Ensure `.env` file exists with `JWT_SECRET` variable

2. **"Unauthorized" on protected endpoints**
   - Include `Authorization: Bearer <token>` header

3. **"Token expired"**
   - Use refresh endpoint to get new access token

4. **Database connection errors**
   - Verify `DATABASE_URL` is correct and database is accessible

## 🛠 Development

### Adding New Protected Endpoints

```typescript
import { requireAuth, requireRole } from './protected.ts';

app.get('/api/your-endpoint', 
  requireAuth,
  requireRole(['manager', 'admin']),
  async (req, res) => {
    // Your endpoint logic
    console.log('User:', req.user);
  }
);
```

### Custom Role Checks

```typescript
import { requireRole } from './protected.ts';
import { UserRole } from '../shared/schema.ts';

// Require admin only
app.delete('/api/admin/endpoint', requireRole([UserRole.ADMIN]), handler);

// Require manager or admin
app.get('/api/manage/endpoint', requireRole([UserRole.MANAGER, UserRole.ADMIN]), handler);
```

## 🔄 Migration from Open System

All existing functionality is preserved - authentication is simply added as a security layer. Users must:

1. Register or be created by an admin
2. Login to receive JWT tokens
3. Use tokens to access any AWS management endpoint

This maintains backward compatibility for frontend applications while adding enterprise-grade security.

---

**Security Notice**: Change all default environment variables before deploying to production! The provided defaults are for development only.
