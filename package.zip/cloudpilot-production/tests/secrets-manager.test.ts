/**
 * Comprehensive Unit Tests for Secrets Manager
 */

import { describe, test, expect, beforeEach, afterEach, jest } from '@jest/globals';
import crypto from 'crypto';

// Import the secrets manager
import {
  SecretsManager,
  createSecretsManager,
  secretsManager,
  getEnvWithFallback,
  validateEnvFormat,
  isProduction,
  isDevelopment,
  maskSecret,
  checkRequiredSecrets,
  generateSecureSecret,
  encryptSecret,
  decryptSecret,
  VALIDATION_RULES,
  customValidators,
  SecretConfig,
  ValidationRule
} from '../server/secrets-manager';

jest.mock('crypto');

describe('Secrets Manager', () => {
  const originalEnv = process.env;

  beforeEach(() => {
    jest.clearAllMocks();
    process.env = { ...originalEnv };
    // Clear any existing secrets
    Object.keys(process.env).forEach(key => {
      if (key.includes('SECRET') || key.includes('KEY') || key.includes('TOKEN') || 
          key.includes('PASSWORD') || key.includes('DATABASE_URL') || 
          key.includes('JWT') || key.includes('AWS')) {
        delete process.env[key];
      }
    });
  });

  afterEach(() => {
    process.env = originalEnv;
    jest.restoreAllMocks();
  });

  describe('SecretsManager Class', () => {
    test('should create a new SecretsManager instance', () => {
      const manager = new SecretsManager();
      expect(manager).toBeInstanceOf(SecretsManager);
    });

    test('should initialize with custom configs', () => {
      const customConfigs: SecretConfig[] = [
        { key: 'CUSTOM_SECRET', required: true }
      ];
      const manager = new SecretsManager(customConfigs);
      expect(manager).toBeInstanceOf(SecretsManager);
    });

    test('should initialize and load environment variables', async () => {
      process.env.TEST_SECRET = 'test-value';
      process.env.ANOTHER_SECRET = 'another-value';
      
      const manager = new SecretsManager();
      await manager.initialize();
      
      expect(manager.getSecret('TEST_SECRET')).toBe('test-value');
      expect(manager.getSecret('ANOTHER_SECRET')).toBe('another-value');
    });

    test('should handle initialization multiple times', async () => {
      process.env.TEST_SECRET = 'test-value';
      const manager = new SecretsManager();
      
      await manager.initialize();
      const firstResult = manager.getSecret('TEST_SECRET');
      
      await manager.initialize(); // Should not throw
      const secondResult = manager.getSecret('TEST_SECRET');
      
      expect(firstResult).toBe(secondResult);
    });
  });

  describe('Secret Retrieval', () => {
    test('getSecret should return undefined for non-existent secret', async () => {
      const manager = new SecretsManager();
      await manager.initialize();
      
      expect(manager.getSecret('NON_EXISTENT')).toBeUndefined();
    });

    test('getSecret should return secret value when exists', async () => {
      process.env.TEST_SECRET = 'test-value';
      const manager = new SecretsManager();
      await manager.initialize();
      
      expect(manager.getSecret('TEST_SECRET')).toBe('test-value');
    });

    test('getSecretWithMetadata should return secret with metadata', async () => {
      process.env.TEST_SECRET = 'test-value';
      const manager = new SecretsManager();
      await manager.initialize();
      
      const result = manager.getSecretWithMetadata('TEST_SECRET');
      
      expect(result).toBeDefined();
      expect(result?.value).toBe('test-value');
      expect(result?.metadata).toBeDefined();
      expect(result?.metadata.lastLoaded).toBeDefined();
    });
  });

  describe('Secret Validation', () => {
    test('isSecretValid should validate secrets correctly', async () => {
      const manager = new SecretsManager();
      await manager.initialize();
      
      expect(manager.isSecretValid('NODE_ENV')).toBe(true);
    });

    test('should validate AWS access key format', () => {
      const rule: ValidationRule = VALIDATION_RULES.aws_access_key;
      
      expect(rule.pattern?.test('AKIAIOSFODNN7EXAMPLE')).toBe(true);
      expect(rule.pattern?.test('ASIAIOSFODNN7EXAMPLE')).toBe(true);
      expect(rule.pattern?.test('INVALID')).toBe(false);
    });

    test('should validate AWS secret key format', () => {
      const rule: ValidationRule = VALIDATION_RULES.aws_secret_key;
      
      expect(rule.pattern?.test('wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY')).toBe(true);
      expect(rule.pattern?.test('shortkey')).toBe(false);
    });

    test('should validate database URL format', () => {
      const rule: ValidationRule = VALIDATION_RULES.database_url;
      
      expect(rule.pattern?.test('postgresql://user:pass@localhost:5432/db')).toBe(true);
      expect(rule.pattern?.test('mysql://user:pass@localhost:3306/db')).toBe(true);
      expect(rule.pattern?.test('invalid-url')).toBe(false);
    });

    test('should validate JWT secret format', () => {
      const rule: ValidationRule = VALIDATION_RULES.jwt_secret;
      
      expect(rule.pattern?.test('a-very-long-secret-key-that-is-secure')).toBe(true);
      expect(rule.pattern?.test('short')).toBe(false);
    });

    test('should validate email format', () => {
      const rule: ValidationRule = VALIDATION_RULES.email;
      
      expect(rule.pattern?.test('user@example.com')).toBe(true);
      expect(rule.pattern?.test('invalid-email')).toBe(false);
    });

    test('should validate URL format', () => {
      const rule: ValidationRule = VALIDATION_RULES.url;
      
      expect(rule.pattern?.test('https://example.com')).toBe(true);
      expect(rule.pattern?.test('http://localhost:3000')).toBe(true);
      expect(rule.pattern?.test('not-a-url')).toBe(false);
    });
  });

  describe('Custom Validators', () => {
    test('isBase64 should validate base64 strings', () => {
      expect(customValidators.isBase64('SGVsbG8gV29ybGQ=')).toBe(true);
      expect(customValidators.isBase64('invalid-base64')).toBe(false);
      expect(customValidators.isBase64('')).toBe(true);
    });

    test('isHex should validate hexadecimal strings', () => {
      expect(customValidators.isHex('deadbeef')).toBe(true);
      expect(customValidators.isHex('1234567890abcdef')).toBe(true);
      expect(customValidators.isHex('nothex')).toBe(false);
    });

    test('isUUID should validate UUID format', () => {
      expect(customValidators.isUUID('550e8400-e29b-41d4-a716-446655440000')).toBe(true);
      expect(customValidators.isUUID('not-a-uuid')).toBe(false);
    });

    test('minLength should validate minimum length', () => {
      const validator = customValidators.minLength(5);
      expect(validator('hello')).toBe(true);
      expect(validator('hi')).toBe(false);
    });

    test('hasSpecialChar should validate special characters', () => {
      expect(customValidators.hasSpecialChar('password!')).toBe(true);
      expect(customValidators.hasSpecialChar('password')).toBe(false);
    });

    test('hasNumber should validate numbers', () => {
      expect(customValidators.hasNumber('password1')).toBe(true);
      expect(customValidators.hasNumber('password')).toBe(false);
    });

    test('hasUpperCase should validate uppercase letters', () => {
      expect(customValidators.hasUpperCase('Password')).toBe(true);
      expect(customValidators.hasUpperCase('password')).toBe(false);
    });
  });

  describe('Secret Management', () => {
    test('hasSecretChanged should detect changes', async () => {
      const manager = new SecretsManager();
      await manager.initialize();
      
      process.env.TEST_SECRET = 'original-value';
      
      expect(manager.hasSecretChanged('TEST_SECRET')).toBe(false);
      
      process.env.TEST_SECRET = 'changed-value';
      
      expect(manager.hasSecretChanged('TEST_SECRET')).toBe(true);
    });

    test('markAsStale should mark secret as stale', async () => {
      process.env.TEST_SECRET = 'test-value';
      const manager = new SecretsManager();
      await manager.initialize();
      
      manager.markAsStale('TEST_SECRET');
      
      const result = manager.getSecretWithMetadata('TEST_SECRET');
      expect(result?.metadata.isStale).toBe(true);
    });
  });

  describe('Secret Refresh', () => {
    test('refreshAllSecrets should refresh all secrets', async () => {
      process.env.TEST_SECRET = 'original';
      const manager = new SecretsManager();
      await manager.initialize();
      
      const onChange = jest.fn();
      manager.onSecretChange(onChange);
      
      process.env.TEST_SECRET = 'updated';
      await manager.refreshAllSecrets();
      
      expect(manager.getSecret('TEST_SECRET')).toBe('updated');
    });

    test('refreshSecret should refresh specific secret', async () => {
      process.env.TEST_SECRET = 'original';
      const manager = new SecretsManager();
      await manager.initialize();
      
      const event = await manager.refreshSecret('TEST_SECRET');
      expect(event).toBeNull(); // No change yet
      
      process.env.TEST_SECRET = 'updated';
      const changeEvent = await manager.refreshSecret('TEST_SECRET');
      
      expect(changeEvent).toBeDefined();
      expect(changeEvent?.newValue).toBe('updated');
      expect(manager.getSecret('TEST_SECRET')).toBe('updated');
    });

    test('should handle missing required secrets', async () => {
      process.env.NODE_ENV = 'production';
      const manager = new SecretsManager();
      await manager.initialize();
      
      // Required secrets like DATABASE_URL that aren't set
      const event = await manager.refreshSecret('DATABASE_URL');
      expect(event).toBeNull();
    });

    test('should use fallback values for missing secrets', async () => {
      process.env.NODE_ENV = 'production';
      const manager = new SecretsManager();
      await manager.initialize();
      
      // PORT has a fallback value
      const port = manager.getSecret('PORT');
      expect(port).toBe('3000');
    });
  });

  describe('Event System', () => {
    test('onSecretChange should register change listeners', async () => {
      const manager = new SecretsManager();
      await manager.initialize();
      
      const listener = jest.fn();
      manager.onSecretChange(listener);
      
      process.env.TEST_SECRET = 'value';
      await manager.refreshSecret('TEST_SECRET');
      
      expect(listener).not.toHaveBeenCalled(); // No change event yet
      
      process.env.TEST_SECRET = 'changed';
      await manager.refreshSecret('TEST_SECRET');
      
      expect(listener).toHaveBeenCalledWith(expect.objectContaining({
        key: 'TEST_SECRET',
        newValue: 'changed'
      }));
    });

    test('removeSecretChangeListener should remove listeners', async () => {
      const manager = new SecretsManager();
      await manager.initialize();
      
      const listener = jest.fn();
      manager.onSecretChange(listener);
      
      manager.removeSecretChangeListener(listener);
      
      process.env.TEST_SECRET = 'changed';
      await manager.refreshSecret('TEST_SECRET');
      
      expect(listener).not.toHaveBeenCalled();
    });
  });

  describe('Validation', () => {
    test('validateAllSecrets should validate all secrets', async () => {
      process.env.NODE_ENV = 'production';
      const manager = new SecretsManager();
      await manager.initialize();
      
      const results = manager.validateAllSecrets();
      expect(results).toBeDefined();
      expect(typeof results).toBe('object');
    });
  });

  describe('Configuration', () => {
    test('getSecretConfig should return secret configuration', async () => {
      const manager = new SecretsManager();
      await manager.initialize();
      
      const config = manager.getSecretConfig('NODE_ENV');
      expect(config).toBeDefined();
      expect(config?.key).toBe('NODE_ENV');
    });

    test('getAllSecretConfigs should return all configurations', async () => {
      const manager = new SecretsManager();
      await manager.initialize();
      
      const configs = manager.getAllSecretConfigs();
      expect(configs).toBeDefined();
      expect(configs.NODE_ENV).toBeDefined();
    });
  });

  describe('Reload and Shutdown', () => {
    test('reload should reload all secrets', async () => {
      const manager = new SecretsManager();
      await manager.initialize();
      
      const reloadSpy = jest.spyOn(manager, 'initialize');
      
      await manager.reload();
      
      expect(reloadSpy).toHaveBeenCalled();
    });

    test('shutdown should cleanup resources', async () => {
      const manager = new SecretsManager();
      await manager.initialize();
      
      const shutdownSpy = jest.spyOn(manager, 'stopRefreshIntervals');
      
      manager.shutdown();
      
      expect(shutdownSpy).toHaveBeenCalled();
    });
  });

  describe('Statistics', () => {
    test('getStatistics should return manager statistics', async () => {
      const manager = new SecretsManager();
      await manager.initialize();
      
      const stats = manager.getStatistics();
      
      expect(stats).toBeDefined();
      expect(stats).toHaveProperty('totalSecrets');
      expect(stats).toHaveProperty('cachedSecrets');
      expect(stats).toHaveProperty('requiredSecrets');
      expect(stats).toHaveProperty('validatedSecrets');
      expect(stats).toHaveProperty('staleSecrets');
      expect(stats).toHaveProperty('rotationCount');
    });
  });

  describe('Utility Functions', () => {
    test('getEnvWithFallback should return environment variable or fallback', () => {
      process.env.EXISTING_VAR = 'value';
      
      expect(getEnvWithFallback('EXISTING_VAR', 'fallback')).toBe('value');
      expect(getEnvWithFallback('NON_EXISTENT', 'fallback')).toBe('fallback');
      expect(getEnvWithFallback('REQUIRED_VAR', undefined, true)).toBe('');
    });

    test('validateEnvFormat should validate environment variable format', () => {
      process.env.VALID_EMAIL = 'test@example.com';
      process.env.INVALID_EMAIL = 'not-an-email';
      
      expect(validateEnvFormat('VALID_EMAIL', VALIDATION_RULES.email)).toBe(true);
      expect(validateEnvFormat('INVALID_EMAIL', VALIDATION_RULES.email)).toBe(false);
    });

    test('isProduction should detect production environment', () => {
      process.env.NODE_ENV = 'production';
      expect(isProduction()).toBe(true);
      
      process.env.NODE_ENV = 'development';
      expect(isProduction()).toBe(false);
    });

    test('isDevelopment should detect development environment', () => {
      process.env.NODE_ENV = 'development';
      expect(isDevelopment()).toBe(true);
      
      process.env.NODE_ENV = 'production';
      expect(isDevelopment()).toBe(false);
    });

    test('maskSecret should mask secret values', () => {
      expect(maskSecret('short')).toBe('*****');
      expect(maskSecret('long-secret-value')).toBe('long**********lue');
      expect(maskSecret('test123', 2, 2)).toBe('te****23');
    });

    test('checkRequiredSecrets should check for missing required secrets', () => {
      process.env.REQUIRED_SECRET = 'value';
      
      const configs: SecretConfig[] = [
        { key: 'REQUIRED_SECRET', required: true },
        { key: 'OPTIONAL_SECRET', required: false },
        { key: 'MISSING_SECRET', required: true }
      ];
      
      const missing = checkRequiredSecrets(configs);
      expect(missing).toContain('MISSING_SECRET');
      expect(missing).not.toContain('REQUIRED_SECRET');
    });

    test('generateSecureSecret should generate random secrets', () => {
      const secret1 = generateSecureSecret(32);
      const secret2 = generateSecureSecret(32);
      
      expect(secret1).toHaveLength(32);
      expect(secret2).toHaveLength(32);
      expect(secret1).not.toBe(secret2);
    });

    test('encryptSecret and decryptSecret should handle encryption', () => {
      const original = 'sensitive-data';
      const encrypted = encryptSecret(original, 'key');
      const decrypted = decryptSecret(encrypted, 'key');
      
      // Currently they return the same value as placeholder implementation
      expect(decrypted).toBe(encrypted);
    });
  });

  describe('Edge Cases', () => {
    test('should handle empty environment variables', async () => {
      process.env.EMPTY_VAR = '';
      const manager = new SecretsManager();
      await manager.initialize();
      
      expect(manager.getSecret('EMPTY_VAR')).toBeUndefined();
    });

    test('should handle whitespace in secret values', async () => {
      process.env.WHITESPACE_VAR = '  value with spaces  ';
      const manager = new SecretsManager();
      await manager.initialize();
      
      expect(manager.getSecret('WHITESPACE_VAR')).toBe('value with spaces');
    });

    test('should handle null and undefined values', async () => {
      process.env.NULL_VAR = null as any;
      process.env.UNDEFINED_VAR = undefined as any;
      const manager = new SecretsManager();
      await manager.initialize();
      
      expect(manager.getSecret('NULL_VAR')).toBeUndefined();
      expect(manager.getSecret('UNDEFINED_VAR')).toBeUndefined();
    });

    test('should handle refresh interval cleanup', async () => {
      const manager = new SecretsManager();
      await manager.initialize();
      
      manager.stopRefreshIntervals();
      // Should not throw
      manager.stopRefreshIntervals(); // Can be called multiple times
    });
  });

  describe('Factory Function', () => {
    test('createSecretsManager should create new instances', () => {
      const customConfigs: SecretConfig[] = [
        { key: 'CUSTOM_SECRET', required: true }
      ];
      
      const manager1 = createSecretsManager(customConfigs);
      const manager2 = createSecretsManager(customConfigs);
      
      expect(manager1).toBeInstanceOf(SecretsManager);
      expect(manager2).toBeInstanceOf(SecretsManager);
      expect(manager1).not.toBe(manager2);
    });
  });

  describe('Singleton Instance', () => {
    test('should export singleton instance', () => {
      expect(secretsManager).toBeInstanceOf(SecretsManager);
    });
  });
});
