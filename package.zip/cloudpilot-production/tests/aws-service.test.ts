/**
 * Comprehensive Unit Tests for AWS Service
 */

import { describe, test, expect, beforeEach, afterEach, jest } from '@jest/globals';

// Mock AWS SDK
jest.mock('@aws-sdk/client-ec2', () => ({
  EC2Client: jest.fn(),
  DescribeInstancesCommand: jest.fn(),
  RunInstancesCommand: jest.fn(),
  StartInstancesCommand: jest.fn(),
  StopInstancesCommand: jest.fn(),
  TerminateInstancesCommand: jest.fn(),
  DescribeAccountAttributesCommand: jest.fn(),
  DescribeRegionsCommand: jest.fn(),
  AllocateAddressCommand: jest.fn(),
  ReleaseAddressCommand: jest.fn(),
  AssociateAddressCommand: jest.fn(),
  DisassociateAddressCommand: jest.fn(),
  DescribeAddressesCommand: jest.fn(),
  GetPasswordDataCommand: jest.fn(),
  CreateTagsCommand: jest.fn(),
  DescribeVolumesCommand: jest.fn(),
  DescribeNetworkInterfacesCommand: jest.fn(),
  DescribeSecurityGroupsCommand: jest.fn()
}));

jest.mock('@aws-sdk/client-s3', () => ({
  S3Client: jest.fn(),
  ListBucketsCommand: jest.fn(),
  CreateBucketCommand: jest.fn(),
  DeleteBucketCommand: jest.fn(),
  PutObjectCommand: jest.fn(),
  GetObjectCommand: jest.fn(),
  ListObjectsV2Command: jest.fn(),
  DeleteObjectCommand: jest.fn()
}));

jest.mock('@aws-sdk/client-rds', () => ({
  RDSClient: jest.fn(),
  DescribeDBInstancesCommand: jest.fn(),
  CreateDBInstanceCommand: jest.fn(),
  DeleteDBInstanceCommand: jest.fn(),
  ModifyDBInstanceCommand: jest.fn(),
  RebootDBInstanceCommand: jest.fn(),
  StartDBInstanceCommand: jest.fn(),
  StopDBInstanceCommand: jest.fn()
}));

jest.mock('@aws-sdk/client-cloudfront', () => ({
  CloudFrontClient: jest.fn(),
  ListDistributionsCommand: jest.fn(),
  CreateDistributionCommand: jest.fn(),
  DeleteDistributionCommand: jest.fn(),
  GetDistributionCommand: jest.fn(),
  CreateInvalidationCommand: jest.fn(),
  UpdateDistributionCommand: jest.fn()
}));

// Mock secrets manager
jest.mock('../server/secrets-manager', () => ({
  secretsManager: {
    getSecret: jest.fn()
  }
}));

// Import after mocking
import { awsService } from '../server/services/aws-service';
import { secretsManager } from '../server/secrets-manager';
import {
  EC2Client,
  S3Client,
  RDSClient,
  CloudFrontClient
} from '@aws-sdk/client-ec2';

describe('AWS Service', () => {
  const mockCredentials = {
    accessKeyId: 'test-access-key',
    secretAccessKey: 'test-secret-key'
  };

  beforeEach(() => {
    jest.clearAllMocks();
    
    // Default secrets manager behavior
    (secretsManager.getSecret as jest.Mock)
      .mockReturnValue('test-value')
      .mockImplementation((key: string) => {
        switch (key) {
          case 'AWS_ACCESS_KEY_ID':
            return mockCredentials.accessKeyId;
          case 'AWS_SECRET_ACCESS_KEY':
            return mockCredentials.secretAccessKey;
          case 'AWS_REGION':
            return 'us-east-1';
          default:
            return undefined;
        }
      });
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('Configuration', () => {
    test('checkEnvironmentVariables should detect missing credentials', () => {
      (secretsManager.getSecret as jest.Mock)
        .mockReturnValueOnce(undefined) // AWS_ACCESS_KEY_ID
        .mockReturnValueOnce('secret'); // AWS_SECRET_ACCESS_KEY

      const result = awsService.checkEnvironmentVariables();
      
      expect(result.configured).toBe(false);
      expect(result.missingVariables).toContain('AWS_ACCESS_KEY_ID');
    });

    test('checkEnvironmentVariables should detect all credentials', () => {
      (secretsManager.getSecret as jest.Mock)
        .mockReturnValue('test-value');

      const result = awsService.checkEnvironmentVariables();
      
      expect(result.configured).toBe(true);
      expect(result.message).toBe('All required AWS environment variables are configured');
    });

    test('getConfigStatus should return configuration details', () => {
      const result = awsService.getConfigStatus();
      
      expect(result).toHaveProperty('environment');
      expect(result.environment).toHaveProperty('hasCredentials');
      expect(result.environment).toHaveProperty('hasRegion');
      expect(result.environment).toHaveProperty('configured');
    });

    test('validateCredentials should validate AWS credentials', async () => {
      const mockSend = jest.fn().mockResolvedValue({});
      
      // Mock the client creation and send method
      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.validateCredentials();
      
      expect(result.valid).toBe(true);
      expect(result.source).toBe('secrets-manager');
    });

    test('validateCredentials should handle invalid credentials', async () => {
      const mockSend = jest.fn().mockRejectedValue(new Error('Invalid credentials'));
      
      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.validateCredentials();
      
      expect(result.valid).toBe(false);
      expect(result.error).toBeDefined();
    });
  });

  describe('EC2 Instance Management', () => {
    test('listInstances should list EC2 instances', async () => {
      const mockResponse = {
        Reservations: [
          {
            Instances: [
              { InstanceId: 'i-1234567890abcdef0', State: { Name: 'running' } },
              { InstanceId: 'i-0987654321fedcba9', State: { Name: 'stopped' } }
            ]
          }
        ]
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const instances = await awsService.listInstances();
      
      expect(instances).toHaveLength(2);
      expect(instances[0].InstanceId).toBe('i-1234567890abcdef0');
      expect(mockSend).toHaveBeenCalled();
    });

    test('launchInstance should launch EC2 instances', async () => {
      const mockResponse = {
        Instances: [
          { InstanceId: 'i-newinstance' }
        ]
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const params = {
        imageId: 'ami-12345678',
        instanceType: 't2.micro',
        region: 'us-east-1'
      };

      const result = await awsService.launchInstance(
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey,
        params
      );
      
      expect(result.success).toBe(true);
      expect(result.instanceIds).toContain('i-newinstance');
    });

    test('launchInstance should handle spot instances', async () => {
      const mockResponse = {
        Instances: [
          { InstanceId: 'i-spotinstance' }
        ]
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const params = {
        imageId: 'ami-12345678',
        instanceType: 't2.micro',
        region: 'us-east-1',
        isSpotInstance: true,
        spotMaxPrice: '0.50'
      };

      const result = await awsService.launchInstance(
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey,
        params
      );
      
      expect(result.success).toBe(true);
    });

    test('startInstance should start EC2 instance', async () => {
      const mockResponse = {
        StartingInstances: [
          { InstanceId: 'i-1234567890abcdef0', CurrentState: { Name: 'pending' } }
        ]
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.startInstance(
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey,
        'us-east-1',
        'i-1234567890abcdef0'
      );
      
      expect(result).toEqual(mockResponse);
    });

    test('stopInstance should stop EC2 instance', async () => {
      const mockResponse = {
        StoppingInstances: [
          { InstanceId: 'i-1234567890abcdef0', CurrentState: { Name: 'stopping' } }
        ]
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.stopInstance(
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey,
        'us-east-1',
        'i-1234567890abcdef0'
      );
      
      expect(result).toEqual(mockResponse);
    });

    test('terminateInstance should terminate EC2 instance', async () => {
      const mockResponse = {
        TerminatingInstances: [
          { InstanceId: 'i-1234567890abcdef0', CurrentState: { Name: 'terminating' } }
        ]
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.terminateInstance(
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey,
        'us-east-1',
        'i-1234567890abcdef0'
      );
      
      expect(result).toEqual(mockResponse);
    });
  });

  describe('Elastic IP Management', () => {
    test('allocateElasticIp should allocate Elastic IP', async () => {
      const mockResponse = {
        AllocationId: 'eipalloc-12345678',
        PublicIp: '203.0.113.0'
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.allocateElasticIp(
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(result).toEqual(mockResponse);
    });

    test('releaseElasticIp should release Elastic IP', async () => {
      const mockResponse = {};

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.releaseElasticIp(
        'eipalloc-12345678',
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(result).toEqual(mockResponse);
    });

    test('associateElasticIp should associate Elastic IP', async () => {
      const mockResponse = {
        AssociationId: 'eipassoc-12345678'
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.associateElasticIp(
        'i-1234567890abcdef0',
        'eipalloc-12345678',
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(result).toEqual(mockResponse);
    });

    test('disassociateElasticIp should disassociate Elastic IP', async () => {
      const mockResponse = {};

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.disassociateElasticIp(
        'eipassoc-12345678',
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(result).toEqual(mockResponse);
    });

    test('listElasticIps should list Elastic IPs', async () => {
      const mockResponse = {
        Addresses: [
          {
            PublicIp: '203.0.113.0',
            AllocationId: 'eipalloc-12345678',
            InstanceId: 'i-1234567890abcdef0'
          }
        ]
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const addresses = await awsService.listElasticIps(
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(addresses).toHaveLength(1);
      expect(addresses[0].PublicIp).toBe('203.0.113.0');
    });

    test('getWindowsPassword should retrieve Windows password', async () => {
      const mockResponse = {
        PasswordData: 'encrypted-password',
        Timestamp: new Date()
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.getWindowsPassword(
        'i-1234567890abcdef0',
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(result.passwordData).toBe('encrypted-password');
      expect(result.timestamp).toBeDefined();
    });

    test('tagInstances should tag instances', async () => {
      const mockResponse = {};

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const instanceIds = ['i-1234567890abcdef0'];
      const tags = { Environment: 'test', Project: 'unit-test' };

      const result = await awsService.tagInstances(
        instanceIds,
        tags,
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(result).toEqual(mockResponse);
    });
  });

  describe('Instance Details', () => {
    test('getInstanceDetails should return detailed instance information', async () => {
      const mockInstance = {
        InstanceId: 'i-1234567890abcdef0',
        State: { Name: 'running' },
        BlockDeviceMappings: [{ Ebs: { VolumeId: 'vol-12345678' } }],
        SecurityGroups: [{ GroupId: 'sg-12345678' }],
        NetworkInterfaces: []
      };

      const mockVolumes = {
        Volumes: [
          { VolumeId: 'vol-12345678', Size: 100 }
        ]
      };

      const mockSecurityGroups = {
        SecurityGroups: [
          { GroupId: 'sg-12345678', GroupName: 'default' }
        ]
      };

      const mockSend = jest.fn()
        .mockResolvedValueOnce({ Reservations: [{ Instances: [mockInstance] }] })
        .mockResolvedValueOnce(mockVolumes)
        .mockResolvedValueOnce(mockSecurityGroups);

      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.getInstanceDetails(
        'i-1234567890abcdef0',
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(result.instance.InstanceId).toBe('i-1234567890abcdef0');
      expect(result.volumes).toHaveLength(1);
      expect(result.securityGroups).toHaveLength(1);
    });
  });

  describe('S3 Operations', () => {
    test('listS3Buckets should list S3 buckets', async () => {
      const mockResponse = {
        Buckets: [
          { Name: 'bucket-1', CreationDate: new Date() },
          { Name: 'bucket-2', CreationDate: new Date() }
        ]
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const S3ClientMock = S3Client as jest.Mock;
      S3ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const buckets = await awsService.listS3Buckets(
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(buckets).toHaveLength(2);
      expect(buckets[0].Name).toBe('bucket-1');
    });

    test('createS3Bucket should create S3 bucket', async () => {
      const mockResponse = {
        Location: 'https://mybucket.s3.amazonaws.com/'
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const S3ClientMock = S3Client as jest.Mock;
      S3ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const params = {
        bucketName: 'my-new-bucket',
        region: 'us-east-1'
      };

      const result = await awsService.createS3Bucket(
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey,
        params
      );
      
      expect(result.success).toBe(true);
      expect(result.location).toBeDefined();
    });

    test('deleteS3Bucket should delete S3 bucket', async () => {
      const mockResponse = {};

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const S3ClientMock = S3Client as jest.Mock;
      S3ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.deleteS3Bucket(
        'my-bucket',
        'us-east-1',
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(result.success).toBe(true);
    });

    test('listS3Objects should list S3 objects', async () => {
      const mockResponse = {
        Contents: [
          { Key: 'file1.txt', Size: 1024 },
          { Key: 'file2.txt', Size: 2048 }
        ]
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const S3ClientMock = S3Client as jest.Mock;
      S3ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const objects = await awsService.listS3Objects(
        'my-bucket',
        'us-east-1',
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(objects).toHaveLength(2);
      expect(objects[0].Key).toBe('file1.txt');
    });

    test('uploadS3Object should upload object to S3', async () => {
      const mockResponse = {};

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const S3ClientMock = S3Client as jest.Mock;
      S3ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const buffer = Buffer.from('test content');
      const result = await awsService.uploadS3Object(
        'my-bucket',
        'path/to/file.txt',
        buffer,
        'us-east-1',
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(result.success).toBe(true);
      expect(result.key).toBe('path/to/file.txt');
    });

    test('downloadS3Object should download object from S3', async () => {
      const mockResponse = {
        Body: {
          [Symbol.asyncIterator]: async function*() {
            yield Buffer.from('test content');
          }
        },
        ContentType: 'text/plain',
        ContentLength: 12
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const S3ClientMock = S3Client as jest.Mock;
      S3ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.downloadS3Object(
        'my-bucket',
        'path/to/file.txt',
        'us-east-1',
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(result.success).toBe(true);
      expect(result.content).toBeDefined();
    });

    test('deleteS3Object should delete object from S3', async () => {
      const mockResponse = {};

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const S3ClientMock = S3Client as jest.Mock;
      S3ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.deleteS3Object(
        'my-bucket',
        'path/to/file.txt',
        'us-east-1',
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(result.success).toBe(true);
    });
  });

  describe('RDS Operations', () => {
    test('listRdsInstances should list RDS instances', async () => {
      const mockResponse = {
        DBInstances: [
          {
            DBInstanceIdentifier: 'mydb-instance-1',
            DBInstanceClass: 'db.t2.micro',
            Engine: 'mysql'
          },
          {
            DBInstanceIdentifier: 'mydb-instance-2',
            DBInstanceClass: 'db.t3.small',
            Engine: 'postgres'
          }
        ]
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const RDSClientMock = RDSClient as jest.Mock;
      RDSClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const instances = await awsService.listRdsInstances(
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(instances).toHaveLength(2);
      expect(instances[0].DBInstanceIdentifier).toBe('mydb-instance-1');
    });

    test('createRdsInstance should create RDS instance', async () => {
      const mockResponse = {
        DBInstance: {
          DBInstanceIdentifier: 'mydb-instance-new',
          DBInstanceClass: 'db.t2.micro',
          Engine: 'mysql'
        }
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const RDSClientMock = RDSClient as jest.Mock;
      RDSClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const request = {
        dbInstanceIdentifier: 'mydb-instance-new',
        dbInstanceClass: 'db.t2.micro',
        engine: 'mysql',
        engineVersion: '8.0.32',
        masterUsername: 'admin',
        masterUserPassword: 'password123',
        allocatedStorage: 20,
        storageType: 'gp2',
        storageEncrypted: true,
        vpcSecurityGroupIds: ['sg-12345678'],
        dbSubnetGroupName: 'default',
        multiAz: false,
        publiclyAccessible: false,
        region: 'us-east-1'
      };

      const result = await awsService.createRdsInstance(
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey,
        request
      );
      
      expect(result.DBInstanceIdentifier).toBe('mydb-instance-new');
    });

    test('deleteRdsInstance should delete RDS instance', async () => {
      const mockResponse = {
        DBInstance: {
          DBInstanceIdentifier: 'mydb-instance-old',
          Status: 'deleting'
        }
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const RDSClientMock = RDSClient as jest.Mock;
      RDSClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.deleteRdsInstance(
        'mydb-instance-old',
        'us-east-1',
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(result.DBInstanceIdentifier).toBe('mydb-instance-old');
    });

    test('startRdsInstance should start RDS instance', async () => {
      const mockResponse = {
        DBInstance: {
          DBInstanceIdentifier: 'mydb-instance-1',
          Status: 'starting'
        }
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const RDSClientMock = RDSClient as jest.Mock;
      RDSClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.startRdsInstance(
        'mydb-instance-1',
        'us-east-1',
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(result.DBInstanceIdentifier).toBe('mydb-instance-1');
    });

    test('stopRdsInstance should stop RDS instance', async () => {
      const mockResponse = {
        DBInstance: {
          DBInstanceIdentifier: 'mydb-instance-1',
          Status: 'stopping'
        }
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const RDSClientMock = RDSClient as jest.Mock;
      RDSClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.stopRdsInstance(
        'mydb-instance-1',
        'us-east-1',
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(result.DBInstanceIdentifier).toBe('mydb-instance-1');
    });

    test('rebootRdsInstance should reboot RDS instance', async () => {
      const mockResponse = {
        DBInstance: {
          DBInstanceIdentifier: 'mydb-instance-1',
          Status: 'rebooting'
        }
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const RDSClientMock = RDSClient as jest.Mock;
      RDSClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.rebootRdsInstance(
        'mydb-instance-1',
        'us-east-1',
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(result.DBInstanceIdentifier).toBe('mydb-instance-1');
    });
  });

  describe('CloudFront Operations', () => {
    test('listCloudFrontDistributions should list distributions', async () => {
      const mockResponse = {
        DistributionList: {
          Items: [
            {
              Id: 'E123456789ABC',
              Status: 'Deployed',
              DomainName: 'd123456789abc.cloudfront.net'
            }
          ]
        }
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const CloudFrontClientMock = CloudFrontClient as jest.Mock;
      CloudFrontClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const distributions = await awsService.listCloudFrontDistributions(
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(distributions).toHaveLength(1);
      expect(distributions[0].Id).toBe('E123456789ABC');
    });

    test('createCloudFrontDistribution should create distribution', async () => {
      const mockResponse = {
        Distribution: {
          Id: 'E123456789ABC',
          Status: 'Deployed',
          DomainName: 'd123456789abc.cloudfront.net'
        }
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const CloudFrontClientMock = CloudFrontClient as jest.Mock;
      CloudFrontClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const request = {
        callerReference: 'ref-123',
        comment: 'Test distribution',
        enabled: true,
        priceClass: 'PriceClass_100',
        defaultRootObject: 'index.html',
        origins: [
          {
            id: 'origin-1',
            domainName: 'example.com',
            customOriginConfig: {
              httpPort: 80,
              httpsPort: 443,
              originProtocolPolicy: 'https-only',
              originSslProtocols: ['TLSv1.2']
            }
          }
        ]
      };

      const result = await awsService.createCloudFrontDistribution(
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey,
        request
      );
      
      expect(result.Id).toBe('E123456789ABC');
    });

    test('deleteCloudFrontDistribution should delete distribution', async () => {
      const mockGetResponse = {
        ETag: 'etag123',
        Distribution: {
          DistributionConfig: {
            Enabled: false
          }
        }
      };

      const mockDeleteResponse = {};

      const mockSend = jest.fn()
        .mockResolvedValueOnce(mockGetResponse)
        .mockResolvedValueOnce(mockDeleteResponse);

      const CloudFrontClientMock = CloudFrontClient as jest.Mock;
      CloudFrontClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.deleteCloudFrontDistribution(
        'E123456789ABC',
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(result.message).toBeDefined();
    });

    test('createCloudFrontInvalidation should create invalidation', async () => {
      const mockResponse = {
        Invalidation: {
          Id: 'I123456789ABC',
          Status: 'InProgress'
        }
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const CloudFrontClientMock = CloudFrontClient as jest.Mock;
      CloudFrontClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const paths = ['/index.html', '/css/*.css'];
      const result = await awsService.createCloudFrontInvalidation(
        'E123456789ABC',
        paths,
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(result.Id).toBe('I123456789ABC');
    });
  });

  describe('Utility Methods', () => {
    test('generateMockTrafficData should generate random traffic data', () => {
      const result = awsService.generateMockTrafficData();
      
      expect(result).toHaveProperty('inbound');
      expect(result).toHaveProperty('outbound');
      expect(typeof result.inbound).toBe('string');
      expect(typeof result.outbound).toBe('string');
      
      // Test that it generates different values each time
      const result2 = awsService.generateMockTrafficData();
      expect(result.inbound).not.toBe(result2.inbound);
      expect(result.outbound).not.toBe(result2.outbound);
    });

    test('checkQuota should check account quotas', async () => {
      const mockResponse = {
        AccountAttributes: [
          {
            AttributeName: 'max-instances',
            AttributeValues: [
              { AttributeValue: '20' }
            ]
          }
        ]
      };

      const mockSend = jest.fn().mockResolvedValue(mockResponse);
      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const quota = await awsService.checkQuota(
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(quota.ec2Limit).toBe(20);
    });

    test('checkRegionAccess should verify region accessibility', async () => {
      const mockSend = jest.fn().mockResolvedValue({ Regions: [] });
      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      const result = await awsService.checkRegionAccess(
        mockCredentials.accessKeyId,
        mockCredentials.secretAccessKey
      );
      
      expect(result.accessible).toBe(true);
      expect(result.region).toBe('us-east-1');
    });
  });

  describe('Error Handling', () => {
    test('should handle missing credentials', async () => {
      (secretsManager.getSecret as jest.Mock)
        .mockReturnValueOnce(undefined) // AWS_ACCESS_KEY_ID
        .mockReturnValueOnce(undefined); // AWS_SECRET_ACCESS_KEY

      await expect(awsService.listInstances()).rejects.toThrow(
        'AWS credentials not found'
      );
    });

    test('should handle AWS API errors', async () => {
      const mockSend = jest.fn().mockRejectedValue(new Error('AWS API Error'));
      const EC2ClientMock = EC2Client as jest.Mock;
      EC2ClientMock.mockImplementation(() => ({
        send: mockSend
      }));

      await expect(awsService.listInstances()).rejects.toThrow('AWS API Error');
    });

    test('should handle incomplete credentials', async () => {
      await expect(awsService.validateCredentials('partial', undefined)).rejects.toThrow(
        'Invalid AWS credentials'
      );
    });
  });

  describe('Client Creation', () => {
    test('createEC2Client should create EC2 client with correct config', () => {
      const client = awsService['createEC2Client']('key', 'secret', 'us-west-2');
      
      expect(EC2Client).toHaveBeenCalledWith({
        region: 'us-west-2',
        credentials: {
          accessKeyId: 'key',
          secretAccessKey: 'secret'
        }
      });
    });

    test('createS3Client should create S3 client with correct config', () => {
      const client = awsService['createS3Client']('key', 'secret', 'us-west-2');
      
      expect(S3Client).toHaveBeenCalledWith({
        region: 'us-west-2',
        credentials: {
          accessKeyId: 'key',
          secretAccessKey: 'secret'
        }
      });
    });

    test('createRDSClient should create RDS client with correct config', () => {
      const client = awsService['createRDSClient']('key', 'secret', 'us-west-2');
      
      expect(RDSClient).toHaveBeenCalledWith({
        region: 'us-west-2',
        credentials: {
          accessKeyId: 'key',
          secretAccessKey: 'secret'
        }
      });
    });

    test('createCloudFrontClient should create CloudFront client', () => {
      const client = awsService['createCloudFrontClient']('key', 'secret');
      
      expect(CloudFrontClient).toHaveBeenCalledWith({
        region: 'us-east-1',
        credentials: {
          accessKeyId: 'key',
          secretAccessKey: 'secret'
        }
      });
    });
  });
});
