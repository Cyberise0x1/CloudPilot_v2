/**
 * Comprehensive Unit Tests for Storage Service (Database Operations)
 */

import { describe, test, expect, beforeEach, afterEach, jest } from '@jest/globals';

// Mock database
jest.mock('../server/db', () => ({
  db: {
    select: jest.fn(),
    insert: jest.fn(),
    update: jest.fn(),
    delete: jest.fn(),
    execute: jest.fn()
  },
  pool: {
    query: jest.fn(),
    end: jest.fn()
  }
}));

// Mock schema
jest.mock('@shared/schema', () => ({
  users: {
    id: 'users.id',
    email: 'users.email',
    username: 'users.username',
    password: 'users.password',
    createdAt: 'users.createdAt',
    updatedAt: 'users.updatedAt'
  },
  refreshTokens: {
    id: 'refreshTokens.id',
    userId: 'refreshTokens.userId',
    token: 'refreshTokens.token',
    expiresAt: 'refreshTokens.expiresAt'
  },
  awsAccounts: {
    id: 'awsAccounts.id',
    name: 'awsAccounts.name',
    accessKeyId: 'awsAccounts.accessKeyId',
    secretAccessKey: 'awsAccounts.secretAccessKey',
    region: 'awsAccounts.region',
    isActive: 'awsAccounts.isActive',
    createdAt: 'awsAccounts.createdAt'
  },
  ec2Instances: {
    id: 'ec2Instances.id',
    instanceId: 'ec2Instances.instanceId',
    name: 'ec2Instances.name',
    accountId: 'ec2Instances.accountId',
    region: 'ec2Instances.region',
    state: 'ec2Instances.state',
    instanceType: 'ec2Instances.instanceType',
    lastUpdated: 'ec2Instances.lastUpdated'
  },
  s3Buckets: {
    id: 's3Buckets.id',
    name: 's3Buckets.name',
    accountId: 's3Buckets.accountId',
    region: 's3Buckets.region',
    lastUpdated: 's3Buckets.lastUpdated'
  },
  rdsInstances: {
    id: 'rdsInstances.id',
    dbInstanceIdentifier: 'rdsInstances.dbInstanceIdentifier',
    accountId: 'rdsInstances.accountId',
    region: 'rdsInstances.region',
    engine: 'rdsInstances.engine',
    status: 'rdsInstances.status',
    lastUpdated: 'rdsInstances.lastUpdated'
  },
  cloudFrontDistributions: {
    id: 'cloudFrontDistributions.id',
    distributionId: 'cloudFrontDistributions.distributionId',
    accountId: 'cloudFrontDistributions.accountId',
    domainName: 'cloudFrontDistributions.domainName',
    status: 'cloudFrontDistributions.status',
    lastUpdated: 'cloudFrontDistributions.lastUpdated'
  },
  instanceTemplates: {
    id: 'instanceTemplates.id',
    name: 'instanceTemplates.name',
    accountId: 'instanceTemplates.accountId',
    templateData: 'instanceTemplates.templateData',
    createdAt: 'instanceTemplates.createdAt'
  },
  eq: jest.fn(),
  and: jest.fn()
}));

// Import after mocking
import { storage } from '../server/storage';
import { db } from '../server/db';
import { eq, and } from 'drizzle-orm';
import {
  users,
  refreshTokens,
  awsAccounts,
  ec2Instances,
  s3Buckets,
  rdsInstances,
  cloudFrontDistributions,
  instanceTemplates
} from '@shared/schema';

describe('Storage Service (Database Operations)', () => {
  const mockUser = {
    id: 'user-123',
    email: 'test@example.com',
    username: 'testuser',
    password: 'hashedpassword',
    createdAt: new Date(),
    updatedAt: new Date()
  };

  const mockAwsAccount = {
    id: 'account-123',
    name: 'Test AWS Account',
    accessKeyId: 'AKIAIOSFODNN7EXAMPLE',
    secretAccessKey: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
    region: 'us-east-1',
    isActive: true,
    createdAt: new Date()
  };

  const mockEc2Instance = {
    id: 'instance-123',
    instanceId: 'i-1234567890abcdef0',
    name: 'Test Instance',
    accountId: 'account-123',
    region: 'us-east-1',
    state: 'running',
    instanceType: 't2.micro',
    lastUpdated: new Date()
  };

  const mockS3Bucket = {
    id: 'bucket-123',
    name: 'test-bucket',
    accountId: 'account-123',
    region: 'us-east-1',
    lastUpdated: new Date()
  };

  const mockRdsInstance = {
    id: 'rds-123',
    dbInstanceIdentifier: 'mydb-instance',
    accountId: 'account-123',
    region: 'us-east-1',
    engine: 'mysql',
    status: 'available',
    lastUpdated: new Date()
  };

  const mockCloudFrontDistribution = {
    id: 'cf-123',
    distributionId: 'E123456789ABC',
    accountId: 'account-123',
    domainName: 'd123456789abc.cloudfront.net',
    status: 'Deployed',
    lastUpdated: new Date()
  };

  const mockInstanceTemplate = {
    id: 'template-123',
    name: 'Test Template',
    accountId: 'account-123',
    templateData: { instanceType: 't2.micro' },
    createdAt: new Date()
  };

  beforeEach(() => {
    jest.clearAllMocks();
    
    // Default database operations
    (db.select as jest.Mock).mockReturnValue({
      from: jest.fn().mockReturnValue({
        where: jest.fn().mockReturnValue({
          returning: jest.fn().mockResolvedValue([mockUser])
        })
      })
    });

    (db.insert as jest.Mock).mockReturnValue({
      values: jest.fn().mockReturnValue({
        returning: jest.fn().mockResolvedValue([mockUser])
      })
    });

    (db.update as jest.Mock).mockReturnValue({
      set: jest.fn().mockReturnValue({
        where: jest.fn().mockReturnValue({
          returning: jest.fn().mockResolvedValue([mockUser])
        })
      })
    });

    (db.delete as jest.Mock).mockReturnValue({
      where: jest.fn().mockResolvedValue(undefined)
    });
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  describe('User Operations', () => {
    test('getUserByEmail should return user by email', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([mockUser])
        })
      });

      const result = await storage.getUserByEmail('test@example.com');
      
      expect(db.select).toHaveBeenCalledWith();
      expect(result).toEqual(mockUser);
    });

    test('getUserByEmail should return undefined when user not found', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([])
        })
      });

      const result = await storage.getUserByEmail('none@example.com');
      
      expect(result).toBeUndefined();
    });

    test('getUserById should return user by ID', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([mockUser])
        })
      });

      const result = await storage.getUserById('user-123');
      
      expect(db.select).toHaveBeenCalledWith();
      expect(eq).toHaveBeenCalledWith(users.id, 'user-123');
      expect(result).toEqual(mockUser);
    });

    test('createUser should create new user', async () => {
      (db.insert as jest.Mock).mockReturnValue({
        values: jest.fn().mockReturnValue({
          returning: jest.fn().mockResolvedValue([mockUser])
        })
      });

      const result = await storage.createUser({
        email: 'test@example.com',
        username: 'testuser',
        password: 'hashedpassword'
      });
      
      expect(db.insert).toHaveBeenCalledWith(users);
      expect(result).toEqual(mockUser);
    });

    test('updateUser should update user information', async () => {
      (db.update as jest.Mock).mockReturnValue({
        set: jest.fn().mockReturnValue({
          where: jest.fn().mockReturnValue({
            returning: jest.fn().mockResolvedValue([{
              ...mockUser,
              username: 'updateduser'
            }])
          })
        })
      });

      const result = await storage.updateUser('user-123', {
        username: 'updateduser'
      });
      
      expect(db.update).toHaveBeenCalledWith(users);
      expect(eq).toHaveBeenCalledWith(users.id, 'user-123');
      expect(result.username).toBe('updateduser');
    });

    test('deleteUser should delete user', async () => {
      await storage.deleteUser('user-123');
      
      expect(db.delete).toHaveBeenCalledWith(users);
      expect(eq).toHaveBeenCalledWith(users.id, 'user-123');
    });
  });

  describe('Refresh Token Operations', () => {
    test('createRefreshToken should create refresh token', async () => {
      await storage.createRefreshToken('user-123', 'refresh-token', new Date());
      
      expect(db.insert).toHaveBeenCalledWith(refreshTokens);
    });

    test('getRefreshToken should retrieve refresh token', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([{
            id: 'token-123',
            userId: 'user-123',
            token: 'refresh-token',
            expiresAt: new Date()
          }])
        })
      });

      const result = await storage.getRefreshToken('refresh-token');
      
      expect(eq).toHaveBeenCalledWith(refreshTokens.token, 'refresh-token');
      expect(result).toBeDefined();
      expect(result?.token).toBe('refresh-token');
    });

    test('deleteRefreshToken should delete refresh token', async () => {
      await storage.deleteRefreshToken('refresh-token');
      
      expect(db.delete).toHaveBeenCalledWith(refreshTokens);
      expect(eq).toHaveBeenCalledWith(refreshTokens.token, 'refresh-token');
    });

    test('deleteRefreshTokensByUserId should delete all user tokens', async () => {
      await storage.deleteRefreshTokensByUserId('user-123');
      
      expect(db.delete).toHaveBeenCalledWith(refreshTokens);
      expect(eq).toHaveBeenCalledWith(refreshTokens.userId, 'user-123');
    });
  });

  describe('AWS Account Operations', () => {
    test('getAwsAccounts should return all accounts', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockResolvedValue([mockAwsAccount])
      });

      const result = await storage.getAwsAccounts();
      
      expect(result).toHaveLength(1);
      expect(result[0]).toEqual(mockAwsAccount);
    });

    test('getSafeAwsAccounts should return accounts without credentials', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockResolvedValue([{
          id: 'account-123',
          name: 'Test AWS Account',
          isActive: true,
          createdAt: new Date()
        }])
      });

      const result = await storage.getSafeAwsAccounts();
      
      expect(result).toHaveLength(1);
      expect(result[0]).not.toHaveProperty('accessKeyId');
      expect(result[0]).not.toHaveProperty('secretAccessKey');
    });

    test('getAwsAccount should return specific account', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([mockAwsAccount])
        })
      });

      const result = await storage.getAwsAccount('account-123');
      
      expect(eq).toHaveBeenCalledWith(awsAccounts.id, 'account-123');
      expect(result).toEqual(mockAwsAccount);
    });

    test('createAwsAccount should create new account', async () => {
      (db.insert as jest.Mock).mockReturnValue({
        values: jest.fn().mockReturnValue({
          returning: jest.fn().mockResolvedValue([{
            id: 'account-123',
            name: 'Test AWS Account',
            isActive: true,
            createdAt: new Date()
          }])
        })
      });

      const result = await storage.createAwsAccount({
        name: 'Test AWS Account',
        accessKeyId: 'AKIAIOSFODNN7EXAMPLE',
        secretAccessKey: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
        region: 'us-east-1',
        isActive: true
      });
      
      expect(db.insert).toHaveBeenCalledWith(awsAccounts);
      expect(result).not.toHaveProperty('accessKeyId');
      expect(result.name).toBe('Test AWS Account');
    });

    test('activateAwsAccount should activate account and deactivate others', async () => {
      // Mock update for deactivation
      (db.update as jest.Mock)
        .mockReturnValue({
          set: jest.fn().mockReturnValue({}) // First call for deactivation
        })
        .mockReturnValue({
          set: jest.fn().mockReturnValue({
            where: jest.fn().mockReturnValue({}) // Second call for activation
          })
        });

      await storage.activateAwsAccount('account-123');
      
      expect(db.update).toHaveBeenCalledTimes(2);
    });
  });

  describe('EC2 Instance Operations', () => {
    test('getEc2Instances should return all instances', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockResolvedValue([mockEc2Instance])
      });

      const result = await storage.getEc2Instances();
      
      expect(result).toHaveLength(1);
      expect(result[0]).toEqual(mockEc2Instance);
    });

    test('getEc2InstancesByRegion should return instances filtered by region and account', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([mockEc2Instance])
        })
      });

      const result = await storage.getEc2InstancesByRegion('us-east-1', 'account-123');
      
      expect(db.select).toHaveBeenCalledWith();
      expect(and).toHaveBeenCalledWith(
        eq(ec2Instances.region, 'us-east-1'),
        eq(ec2Instances.accountId, 'account-123')
      );
      expect(result).toHaveLength(1);
    });

    test('upsertEc2Instance should update existing instance', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([mockEc2Instance]) // Existing instance
        })
      });

      (db.update as jest.Mock).mockReturnValue({
        set: jest.fn().mockReturnValue({
          where: jest.fn().mockReturnValue({
            returning: jest.fn().mockResolvedValue([{
              ...mockEc2Instance,
              state: 'stopped'
            }])
          })
        })
      });

      const result = await storage.upsertEc2Instance({
        instanceId: 'i-1234567890abcdef0',
        name: 'Test Instance',
        accountId: 'account-123',
        region: 'us-east-1',
        state: 'stopped',
        instanceType: 't2.micro'
      });

      expect(db.update).toHaveBeenCalled();
      expect(result.state).toBe('stopped');
    });

    test('upsertEc2Instance should insert new instance if not exists', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([]) // No existing instance
        })
      });

      (db.insert as jest.Mock).mockReturnValue({
        values: jest.fn().mockReturnValue({
          returning: jest.fn().mockResolvedValue([mockEc2Instance])
        })
      });

      const result = await storage.upsertEc2Instance({
        instanceId: 'i-new1234567890abcdef0',
        name: 'New Instance',
        accountId: 'account-123',
        region: 'us-east-1',
        state: 'pending',
        instanceType: 't2.micro'
      });

      expect(db.insert).toHaveBeenCalled();
      expect(result.instanceId).toBe('i-new1234567890abcdef0');
    });

    test('updateInstanceName should update instance name', async () => {
      (db.update as jest.Mock).mockReturnValue({
        set: jest.fn().mockReturnValue({
          where: jest.fn().mockReturnValue({})
        })
      });

      await storage.updateInstanceName('i-1234567890abcdef0', 'Updated Name');
      
      expect(db.update).toHaveBeenCalledWith(ec2Instances);
      expect(eq).toHaveBeenCalledWith(ec2Instances.instanceId, 'i-1234567890abcdef0');
    });
  });

  describe('S3 Bucket Operations', () => {
    test('getS3Buckets should return all buckets', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockResolvedValue([mockS3Bucket])
      });

      const result = await storage.getS3Buckets();
      
      expect(result).toHaveLength(1);
      expect(result[0]).toEqual(mockS3Bucket);
    });

    test('getS3BucketsByAccount should return buckets for specific account', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([mockS3Bucket])
        })
      });

      const result = await storage.getS3BucketsByAccount('account-123');
      
      expect(eq).toHaveBeenCalledWith(s3Buckets.accountId, 'account-123');
      expect(result).toHaveLength(1);
    });

    test('upsertS3Bucket should update existing bucket', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([mockS3Bucket])
        })
      });

      (db.update as jest.Mock).mockReturnValue({
        set: jest.fn().mockReturnValue({
          where: jest.fn().mockReturnValue({
            returning: jest.fn().mockResolvedValue([{
              ...mockS3Bucket,
              region: 'us-west-2'
            }])
          })
        })
      });

      const result = await storage.upsertS3Bucket({
        name: 'test-bucket',
        accountId: 'account-123',
        region: 'us-west-2'
      });

      expect(db.update).toHaveBeenCalled();
      expect(result.region).toBe('us-west-2');
    });

    test('deleteS3Bucket should delete bucket', async () => {
      await storage.deleteS3Bucket('test-bucket', 'account-123');
      
      expect(db.delete).toHaveBeenCalledWith(s3Buckets);
      expect(and).toHaveBeenCalledWith(
        eq(s3Buckets.name, 'test-bucket'),
        eq(s3Buckets.accountId, 'account-123')
      );
    });
  });

  describe('RDS Instance Operations', () => {
    test('getRdsInstances should return all RDS instances', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockResolvedValue([mockRdsInstance])
      });

      const result = await storage.getRdsInstances();
      
      expect(result).toHaveLength(1);
      expect(result[0]).toEqual(mockRdsInstance);
    });

    test('getRdsInstancesByAccount should return instances for specific account', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([mockRdsInstance])
        })
      });

      const result = await storage.getRdsInstancesByAccount('account-123');
      
      expect(eq).toHaveBeenCalledWith(rdsInstances.accountId, 'account-123');
      expect(result).toHaveLength(1);
    });

    test('getRdsInstancesByRegion should return instances for region and account', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([mockRdsInstance])
        })
      });

      const result = await storage.getRdsInstancesByRegion('us-east-1', 'account-123');
      
      expect(and).toHaveBeenCalledWith(
        eq(rdsInstances.region, 'us-east-1'),
        eq(rdsInstances.accountId, 'account-123')
      );
      expect(result).toHaveLength(1);
    });

    test('upsertRdsInstance should update existing instance', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([mockRdsInstance])
        })
      });

      (db.update as jest.Mock).mockReturnValue({
        set: jest.fn().mockReturnValue({
          where: jest.fn().mockReturnValue({
            returning: jest.fn().mockResolvedValue([{
              ...mockRdsInstance,
              status: 'stopped'
            }])
          })
        })
      });

      const result = await storage.upsertRdsInstance({
        dbInstanceIdentifier: 'mydb-instance',
        accountId: 'account-123',
        region: 'us-east-1',
        engine: 'mysql',
        status: 'stopped'
      });

      expect(db.update).toHaveBeenCalled();
      expect(result.status).toBe('stopped');
    });

    test('deleteRdsInstance should delete instance', async () => {
      await storage.deleteRdsInstance('mydb-instance', 'account-123');
      
      expect(db.delete).toHaveBeenCalledWith(rdsInstances);
      expect(and).toHaveBeenCalledWith(
        eq(rdsInstances.dbInstanceIdentifier, 'mydb-instance'),
        eq(rdsInstances.accountId, 'account-123')
      );
    });
  });

  describe('CloudFront Distribution Operations', () => {
    test('getCloudFrontDistributions should return all distributions', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockResolvedValue([mockCloudFrontDistribution])
      });

      const result = await storage.getCloudFrontDistributions();
      
      expect(result).toHaveLength(1);
      expect(result[0]).toEqual(mockCloudFrontDistribution);
    });

    test('getCloudFrontDistributionsByAccount should return distributions for account', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([mockCloudFrontDistribution])
        })
      });

      const result = await storage.getCloudFrontDistributionsByAccount('account-123');
      
      expect(eq).toHaveBeenCalledWith(cloudFrontDistributions.accountId, 'account-123');
      expect(result).toHaveLength(1);
    });

    test('upsertCloudFrontDistribution should update existing distribution', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([mockCloudFrontDistribution])
        })
      });

      (db.update as jest.Mock).mockReturnValue({
        set: jest.fn().mockReturnValue({
          where: jest.fn().mockReturnValue({
            returning: jest.fn().mockResolvedValue([{
              ...mockCloudFrontDistribution,
              status: 'InProgress'
            }])
          })
        })
      });

      const result = await storage.upsertCloudFrontDistribution({
        distributionId: 'E123456789ABC',
        accountId: 'account-123',
        domainName: 'd123456789abc.cloudfront.net',
        status: 'InProgress'
      });

      expect(db.update).toHaveBeenCalled();
      expect(result.status).toBe('InProgress');
    });

    test('deleteCloudFrontDistribution should delete distribution', async () => {
      await storage.deleteCloudFrontDistribution('E123456789ABC', 'account-123');
      
      expect(db.delete).toHaveBeenCalledWith(cloudFrontDistributions);
      expect(and).toHaveBeenCalledWith(
        eq(cloudFrontDistributions.distributionId, 'E123456789ABC'),
        eq(cloudFrontDistributions.accountId, 'account-123')
      );
    });
  });

  describe('Instance Template Operations', () => {
    test('getInstanceTemplates should return all templates', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockResolvedValue([mockInstanceTemplate])
      });

      const result = await storage.getInstanceTemplates();
      
      expect(result).toHaveLength(1);
      expect(result[0]).toEqual(mockInstanceTemplate);
    });

    test('getInstanceTemplatesByAccount should return templates for account', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([mockInstanceTemplate])
        })
      });

      const result = await storage.getInstanceTemplatesByAccount('account-123');
      
      expect(eq).toHaveBeenCalledWith(instanceTemplates.accountId, 'account-123');
      expect(result).toHaveLength(1);
    });

    test('getInstanceTemplate should return specific template', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([mockInstanceTemplate])
        })
      });

      const result = await storage.getInstanceTemplate('template-123');
      
      expect(eq).toHaveBeenCalledWith(instanceTemplates.id, 'template-123');
      expect(result).toEqual(mockInstanceTemplate);
    });

    test('createInstanceTemplate should create new template', async () => {
      (db.insert as jest.Mock).mockReturnValue({
        values: jest.fn().mockReturnValue({
          returning: jest.fn().mockResolvedValue([mockInstanceTemplate])
        })
      });

      const result = await storage.createInstanceTemplate({
        name: 'Test Template',
        accountId: 'account-123',
        templateData: { instanceType: 't2.micro' }
      });
      
      expect(db.insert).toHaveBeenCalledWith(instanceTemplates);
      expect(result.name).toBe('Test Template');
    });

    test('updateInstanceTemplate should update existing template', async () => {
      (db.update as jest.Mock).mockReturnValue({
        set: jest.fn().mockReturnValue({
          where: jest.fn().mockReturnValue({
            returning: jest.fn().mockResolvedValue([{
              ...mockInstanceTemplate,
              name: 'Updated Template'
            }])
          })
        })
      });

      const result = await storage.updateInstanceTemplate('template-123', {
        name: 'Updated Template'
      });
      
      expect(db.update).toHaveBeenCalledWith(instanceTemplates);
      expect(eq).toHaveBeenCalledWith(instanceTemplates.id, 'template-123');
      expect(result.name).toBe('Updated Template');
    });

    test('deleteInstanceTemplate should delete template', async () => {
      await storage.deleteInstanceTemplate('template-123');
      
      expect(db.delete).toHaveBeenCalledWith(instanceTemplates);
      expect(eq).toHaveBeenCalledWith(instanceTemplates.id, 'template-123');
    });
  });

  describe('Error Handling', () => {
    test('should handle database errors gracefully', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockRejectedValue(new Error('Database error'))
        })
      });

      await expect(storage.getUserByEmail('test@example.com')).rejects.toThrow('Database error');
    });

    test('should handle empty results', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([])
        })
      });

      const result = await storage.getUserByEmail('none@example.com');
      
      expect(result).toBeUndefined();
    });
  });

  describe('Complex Queries', () => {
    test('should handle complex where conditions with and', async () => {
      (db.select as jest.Mock).mockReturnValue({
        from: jest.fn().mockReturnValue({
          where: jest.fn().mockResolvedValue([mockEc2Instance])
        })
      });

      await storage.getEc2InstancesByRegion('us-east-1', 'account-123');
      
      expect(and).toHaveBeenCalled();
    });

    test('should handle multiple update operations', async () => {
      (db.update as jest.Mock)
        .mockReturnValue({
          set: jest.fn().mockReturnValue({}) // First update call
        })
        .mockReturnValue({
          set: jest.fn().mockReturnValue({
            where: jest.fn().mockReturnValue({}) // Second update call
          })
        });

      await storage.activateAwsAccount('account-123');
      
      expect(db.update).toHaveBeenCalledTimes(2);
    });
  });
});
