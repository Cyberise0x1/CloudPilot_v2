/**
 * Comprehensive tests for Metrics Tracking System
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { 
  MetricsCollector, 
  Counter, 
  Gauge, 
  Histogram,
  metrics,
  trackRequest,
  trackAwsOperation,
  trackBusinessEvent,
  metricsMiddleware,
  getHealthMetrics,
  type MetricLabels,
  type CounterMetric,
  type GaugeMetric,
  type HistogramMetric,
  type RequestMetrics,
  type SystemMetrics,
  type DashboardData
} from '../server/metrics-local';

// Mock dependencies
vi.mock('perf_hooks', () => ({
  performance: {
    now: vi.fn(() => 1000)
  }
}));

vi.mock('os', () => ({
  loadavg: vi.fn(() => [1, 2, 3]),
  freemem: vi.fn(() => 8000000000),
  totalmem: vi.fn(() => 16000000000)
}));

// Mock process functions
vi.spyOn(process, 'memoryUsage').mockReturnValue({
  heapUsed: 1000000000,
  heapTotal: 2000000000,
  external: 100000000,
  rss: 2100000000
});

vi.spyOn(process, 'uptime').mockReturnValue(3600);
vi.spyOn(process, 'pid').mockReturnValue(1234);

describe('Metrics System', () => {
  let collector: MetricsCollector;

  beforeEach(() => {
    vi.clearAllMocks();
    collector = new MetricsCollector();
  });

  afterEach(() => {
    collector.destroy();
  });

  describe('Counter Metric', () => {
    let counter: Counter;

    beforeEach(() => {
      counter = new Counter('test_counter', 'Test counter help text');
    });

    it('should initialize with correct values', () => {
      expect(counter.name).toBe('test_counter');
      expect(counter.help).toBe('Test counter help text');
      expect(counter.getValue()).toBe(0);
    });

    it('should increment value', () => {
      counter.inc();
      expect(counter.getValue()).toBe(1);

      counter.inc(5);
      expect(counter.getValue()).toBe(6);
    });

    it('should reset value', () => {
      counter.inc(10);
      counter.reset();
      expect(counter.getValue()).toBe(0);
    });

    it('should generate metric object', () => {
      counter.inc(3);
      const metric = counter.getMetrics();

      expect(metric).toEqual({
        name: 'test_counter',
        help: 'Test counter help text',
        value: 3,
        labels: {},
        timestamp: expect.any(Number)
      });
    });

    it('should generate Prometheus format', () => {
      counter.inc(2);
      const prometheus = counter.toPrometheus();

      expect(prometheus).toContain('# HELP test_counter Test counter help text');
      expect(prometheus).toContain('# TYPE test_counter counter');
      expect(prometheus).toContain('test_counter{} 2');
    });

    it('should work with labels', () => {
      const labeledCounter = new Counter('test_counter', 'Test', { env: 'prod' });
      labeledCounter.inc(1);
      
      const prometheus = labeledCounter.toPrometheus();
      expect(prometheus).toContain('env="prod"');
    });
  });

  describe('Gauge Metric', () => {
    let gauge: Gauge;

    beforeEach(() => {
      gauge = new Gauge('test_gauge', 'Test gauge help text', 10);
    });

    it('should initialize with correct values', () => {
      expect(gauge.name).toBe('test_gauge');
      expect(gauge.help).toBe('Test gauge help text');
      expect(gauge.getValue()).toBe(10);
    });

    it('should set value', () => {
      gauge.set(50);
      expect(gauge.getValue()).toBe(50);
    });

    it('should increment and decrement', () => {
      gauge.inc(5);
      expect(gauge.getValue()).toBe(15);

      gauge.dec(3);
      expect(gauge.getValue()).toBe(12);
    });

    it('should generate metric object', () => {
      gauge.set(25);
      const metric = gauge.getMetrics();

      expect(metric).toEqual({
        name: 'test_gauge',
        help: 'Test gauge help text',
        value: 25,
        labels: {},
        timestamp: expect.any(Number)
      });
    });

    it('should generate Prometheus format', () => {
      gauge.set(42);
      const prometheus = gauge.toPrometheus();

      expect(prometheus).toContain('# HELP test_gauge Test gauge help text');
      expect(prometheus).toContain('# TYPE test_gauge gauge');
      expect(prometheus).toContain('test_gauge{} 42');
    });
  });

  describe('Histogram Metric', () => {
    let histogram: Histogram;

    beforeEach(() => {
      histogram = new Histogram('test_histogram', 'Test histogram help', [0.1, 0.5, 1, 5]);
    });

    it('should initialize with correct values', () => {
      expect(histogram.name).toBe('test_histogram');
      expect(histogram.help).toBe('Test histogram help');
      expect(histogram.buckets).toEqual([0.1, 0.5, 1, 5, Infinity]);
    });

    it('should observe values and update buckets', () => {
      histogram.observe(0.3);
      histogram.observe(0.7);
      histogram.observe(2);
      histogram.observe(10);

      const metric = histogram.getMetrics();
      
      expect(metric.count).toBe(4);
      expect(metric.sum).toBe(13);
      expect(metric.buckets['0.1']).toBe(1); // 0.3 <= 0.1? No, so 1
      expect(metric.buckets['0.5']).toBe(2); // 0.3, 0.7 <= 0.5? Yes, but order matters
    });

    it('should calculate quantiles correctly', () => {
      // Add 10 values from 1 to 10
      for (let i = 1; i <= 10; i++) {
        histogram.observe(i);
      }

      // 50th percentile should be around 5.5 (median)
      expect(histogram.getQuantile(0.5)).toBeGreaterThanOrEqual(5);
      expect(histogram.getQuantile(0.5)).toBeLessThanOrEqual(6);

      // 95th percentile should be around 9.5
      expect(histogram.getQuantile(0.95)).toBeGreaterThanOrEqual(9);
      expect(histogram.getQuantile(0.95)).toBeLessThanOrEqual(10);
    });

    it('should handle empty histogram', () => {
      expect(histogram.getQuantile(0.5)).toBe(0);
      expect(histogram.getQuantile(0.95)).toBe(0);
    });

    it('should generate Prometheus format with buckets', () => {
      histogram.observe(0.3);
      histogram.observe(0.7);

      const prometheus = histogram.toPrometheus();
      
      expect(prometheus).toContain('# HELP test_histogram Test histogram help');
      expect(prometheus).toContain('# TYPE test_histogram histogram');
      expect(prometheus).toContain('test_histogram_bucket{');
      expect(prometheus).toContain('le="0.1"');
      expect(prometheus).toContain('test_histogram_count{} 2');
      expect(prometheus).toContain('test_histogram_sum{} 1');
    });
  });

  describe('Metrics Collector', () => {
    beforeEach(() => {
      collector = new MetricsCollector();
    });

    it('should initialize with default metrics', () => {
      expect(collector.getMetric('http_requests_total')).toBeDefined();
      expect(collector.getMetric('http_request_duration_seconds')).toBeDefined();
      expect(collector.getMetric('memory_usage_bytes')).toBeDefined();
      expect(collector.getMetric('active_connections')).toBeDefined();
    });

    describe('Request Tracking', () => {
      it('should track HTTP requests', () => {
        collector.trackRequest('GET', '/api/users', 200, 0.5);

        const requestCounter = collector.getMetric('http_requests_total') as Counter;
        expect(requestCounter.getValue()).toBe(1);

        const durationHistogram = collector.getMetric('http_request_duration_seconds') as Histogram;
        expect(durationHistogram.getMetrics().count).toBe(1);
      });

      it('should track requests with labels', () => {
        collector.trackRequest('POST', '/api/users', 201, 0.3, 'Chrome', '192.168.1.1', 'user123');

        const requestCounter = collector.getMetric('http_requests_total') as Counter;
        expect(requestCounter.getValue()).toBe(1);
      });

      it('should track error requests', () => {
        collector.trackRequest('GET', '/api/error', 500, 1.2);

        const errorCounter = collector.getMetric('http_errors_total') as Counter;
        expect(errorCounter.getValue()).toBe(1);
      });

      it('should update active connections', () => {
        collector.trackRequest('GET', '/api/test', 200, 0.1);

        const activeConnections = collector.getMetric('active_connections') as Gauge;
        expect(activeConnections.getValue()).toBeGreaterThanOrEqual(0);
      });
    });

    describe('AWS Operations Tracking', () => {
      it('should track successful AWS operations', () => {
        collector.trackAwsOperation('S3', 'PutObject', 0.5, 'success');

        const awsCounter = collector.getMetric('aws_operations_total') as Counter;
        expect(awsCounter.getValue()).toBe(1);

        const awsHistogram = collector.getMetric('aws_operation_duration_seconds') as Histogram;
        expect(awsHistogram.getMetrics().count).toBe(1);
      });

      it('should track failed AWS operations', () => {
        collector.trackAwsOperation('EC2', 'RunInstances', 2.0, 'error');

        const awsCounter = collector.getMetric('aws_operations_total') as Counter;
        expect(awsCounter.getValue()).toBe(1);
      });
    });

    describe('Business Metrics', () => {
      it('should track user registrations', () => {
        collector.trackUserRegistration();

        const userRegCounter = collector.getMetric('user_registrations_total') as Counter;
        expect(userRegCounter.getValue()).toBe(1);
      });

      it('should track user logins', () => {
        collector.trackUserLogin();

        const userLoginCounter = collector.getMetric('user_logins_total') as Counter;
        expect(userLoginCounter.getValue()).toBe(1);
      });

      it('should track API calls', () => {
        collector.trackApiCall();

        const apiCallsCounter = collector.getMetric('api_calls_total') as Counter;
        expect(apiCallsCounter.getValue()).toBe(1);
      });

      it('should track database queries', () => {
        collector.trackDbQuery();

        const dbQueriesCounter = collector.getMetric('db_queries_total') as Counter;
        expect(dbQueriesCounter.getValue()).toBe(1);
      });

      it('should track cache hits and misses', () => {
        collector.trackCacheHit();
        collector.trackCacheMiss();

        const cacheHitsCounter = collector.getMetric('cache_hits_total') as Counter;
        const cacheMissesCounter = collector.getMetric('cache_misses_total') as Counter;
        
        expect(cacheHitsCounter.getValue()).toBe(1);
        expect(cacheMissesCounter.getValue()).toBe(1);
      });
    });

    describe('System Monitoring', () => {
      it('should collect system metrics', async () => {
        // Mock the system metrics collection
        vi.advanceTimersByTime(100);

        await new Promise(resolve => setTimeout(resolve, 200));

        const memoryGauge = collector.getMetric('memory_usage_bytes') as Gauge;
        const uptimeGauge = collector.getMetric('uptime_seconds') as Gauge;
        
        expect(memoryGauge.getValue()).toBeGreaterThan(0);
        expect(uptimeGauge.getValue()).toBe(3600);
      });

      it('should measure event loop lag', () => {
        const lag = collector.measureEventLoopLag?.();
        expect(lag).toBeDefined();
      });

      it('should get active connections', () => {
        const connections = collector.getActiveConnections?.();
        expect(typeof connections).toBe('number');
      });
    });

    describe('Metrics Aggregation', () => {
      beforeEach(() => {
        // Add some sample request metrics
        for (let i = 0; i < 100; i++) {
          collector.trackRequest('GET', '/api/users', 200, Math.random() * 2);
        }
        for (let i = 0; i < 10; i++) {
          collector.trackRequest('GET', '/api/error', 500, Math.random() * 3);
        }
      });

      it('should aggregate metrics for time windows', () => {
        collector.aggregateMetrics(60);

        const aggregated = collector.getDashboardData();
        expect(aggregated.aggregatedMetrics.totalRequests).toBeGreaterThan(0);
        expect(aggregated.aggregatedMetrics.totalErrors).toBeGreaterThanOrEqual(0);
      });

      it('should calculate percentiles correctly', () => {
        const values = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
        
        // This is a private method test, but we can test the behavior indirectly
        collector.aggregateMetrics(60);
        const dashboard = collector.getDashboardData();
        
        expect(dashboard.aggregatedMetrics.p95ResponseTime).toBeDefined();
        expect(dashboard.aggregatedMetrics.p99ResponseTime).toBeDefined();
      });

      it('should aggregate by endpoint', () => {
        collector.aggregateMetrics(60);
        const dashboard = collector.getDashboardData();
        
        expect(dashboard.aggregatedMetrics.requestRateByEndpoint).toBeDefined();
        expect(Object.keys(dashboard.aggregatedMetrics.requestRateByEndpoint).length).toBeGreaterThan(0);
      });
    });

    describe('Dashboard Data', () => {
      beforeEach(() => {
        // Add sample data
        collector.trackRequest('GET', '/api/users', 200, 0.5);
        collector.trackRequest('POST', '/api/users', 201, 0.3);
        collector.trackRequest('GET', '/api/error', 500, 1.0);
      });

      it('should provide real-time metrics', () => {
        const dashboard = collector.getDashboardData();
        
        expect(dashboard.realTimeMetrics).toEqual({
          requestsPerSecond: expect.any(Number),
          averageResponseTime: expect.any(Number),
          errorRate: expect.any(Number),
          activeConnections: expect.any(Number),
          memoryUsage: expect.any(Number)
        });
      });

      it('should provide aggregated metrics', () => {
        collector.aggregateMetrics(60);
        const dashboard = collector.getDashboardData();
        
        expect(dashboard.aggregatedMetrics).toEqual({
          totalRequests: expect.any(Number),
          totalErrors: expect.any(Number),
          averageResponseTime: expect.any(Number),
          p95ResponseTime: expect.any(Number),
          p99ResponseTime: expect.any(Number),
          requestRateByEndpoint: expect.any(Object),
          errorRateByEndpoint: expect.any(Object),
          topErrors: expect.any(Array)
        });
      });

      it('should provide system metrics', () => {
        const dashboard = collector.getDashboardData();
        
        expect(dashboard.systemMetrics).toEqual({
          memory: {
            used: expect.any(Number),
            total: expect.any(Number),
            percentage: expect.any(Number),
            heapUsed: expect.any(Number),
            heapTotal: expect.any(Number),
            external: expect.any(Number)
          },
          cpu: {
            usage: expect.any(Number),
            loadAverage: [1, 2, 3]
          },
          activeConnections: expect.any(Number),
          uptime: expect.any(Number),
          eventLoopLag: expect.any(Number)
        });
      });

      it('should provide business metrics', () => {
        const dashboard = collector.getDashboardData();
        
        expect(dashboard.businessMetrics).toEqual({
          user_registrations: expect.any(Number),
          user_logins: expect.any(Number),
          api_calls: expect.any(Number),
          db_queries: expect.any(Number),
          cache_hits: expect.any(Number),
          cache_misses: expect.any(Number),
          file_uploads: 0,
          emails_sent: 0,
          errors_total: expect.any(Number),
          successful_operations: expect.any(Number)
        });
      });
    });

    describe('Prometheus Export', () => {
      it('should generate Prometheus format', () => {
        collector.trackRequest('GET', '/api/test', 200, 0.5);
        collector.trackUserRegistration();

        const prometheus = collector.toPrometheus();
        
        expect(prometheus).toContain('# Generated at');
        expect(prometheus).toContain('# HELP http_requests_total');
        expect(prometheus).toContain('# TYPE http_requests_total counter');
        expect(prometheus).toContain('http_requests_total{');
        expect(prometheus).toContain('# HELP user_registrations_total');
        expect(prometheus).toContain('# TYPE user_registrations_total counter');
      });

      it('should include all metric types', () => {
        collector.trackRequest('GET', '/api/test', 200, 0.5);
        
        const prometheus = collector.toPrometheus();
        
        expect(prometheus).toContain('counter');
        expect(prometheus).toContain('gauge');
        expect(prometheus).toContain('histogram');
      });
    });

    describe('Metrics Management', () => {
      it('should get specific metric', () => {
        const counter = collector.getMetric('http_requests_total');
        expect(counter).toBeDefined();
        expect(counter).toBeInstanceOf(Counter);
      });

      it('should return undefined for non-existent metric', () => {
        const metric = collector.getMetric('non_existent_metric');
        expect(metric).toBeUndefined();
      });

      it('should reset all metrics', () => {
        collector.trackRequest('GET', '/api/test', 200, 0.5);
        collector.trackUserRegistration();

        collector.resetAllMetrics();

        const counter = collector.getMetric('http_requests_total') as Counter;
        expect(counter.getValue()).toBe(0);
      });

      it('should destroy collector and cleanup', () => {
        collector.destroy();
        // Should clean up intervals and listeners
      });
    });
  });

  describe('Global Metrics Instance', () => {
    it('should export global metrics instance', () => {
      expect(metrics).toBeDefined();
      expect(metrics).toBeInstanceOf(MetricsCollector);
    });

    it('should provide utility functions', () => {
      trackRequest('GET', '/api/test', 200, 0.5);

      const counter = metrics.getMetric('http_requests_total') as Counter;
      expect(counter.getValue()).toBe(1);
    });

    it('should provide AWS operation tracking', () => {
      trackAwsOperation('S3', 'GetObject', 0.3);

      const counter = metrics.getMetric('aws_operations_total') as Counter;
      expect(counter.getValue()).toBe(1);
    });

    it('should provide business event tracking', () => {
      trackBusinessEvent.userRegistration();

      const counter = metrics.getMetric('user_registrations_total') as Counter;
      expect(counter.getValue()).toBe(1);
    });

    it('should provide health metrics', () => {
      const healthMetrics = getHealthMetrics();

      expect(healthMetrics).toEqual({
        status: 'healthy',
        uptime: expect.any(Number),
        memoryUsage: expect.any(Number),
        activeConnections: expect.any(Number),
        errorRate: expect.any(Number),
        timestamp: expect.any(Number)
      });
    });
  });

  describe('Express Middleware', () => {
    let mockReq: any;
    let mockRes: any;
    let mockNext: any;

    beforeEach(() => {
      mockReq = {
        method: 'GET',
        path: '/api/test',
        get: vi.fn((header: string) => {
          if (header === 'user-agent') return 'test-agent';
          return undefined;
        }),
        ip: '192.168.1.1'
      };
      mockRes = {
        statusCode: 200,
        on: vi.fn((event: string, callback: Function) => {
          if (event === 'finish') {
            setTimeout(callback, 10);
          }
        })
      };
      mockNext = vi.fn();
    });

    it('should track requests automatically', async () => {
      const startSpy = vi.spyOn(Date, 'now').mockReturnValueOnce(1000);
      vi.spyOn(Date, 'now').mockReturnValueOnce(1050); // 50ms duration

      metricsMiddleware(mockReq, mockRes, mockNext);

      await new Promise(resolve => setTimeout(resolve, 20));

      const counter = metrics.getMetric('http_requests_total') as Counter;
      expect(counter.getValue()).toBe(1);

      startSpy.mockRestore();
    });

    it('should track errors from response status', async () => {
      mockRes.statusCode = 500;

      const startSpy = vi.spyOn(Date, 'now').mockReturnValueOnce(1000);
      vi.spyOn(Date, 'now').mockReturnValueOnce(1100);

      metricsMiddleware(mockReq, mockRes, mockNext);

      await new Promise(resolve => setTimeout(resolve, 20));

      const errorCounter = metrics.getMetric('http_errors_total') as Counter;
      expect(errorCounter.getValue()).toBe(1);

      startSpy.mockRestore();
    });

    it('should call next function', () => {
      metricsMiddleware(mockReq, mockRes, mockNext);
      expect(mockNext).toHaveBeenCalled();
    });
  });

  describe('EventEmitter Integration', () => {
    it('should emit request events', () => {
      const eventSpy = vi.fn();
      collector.on('request', eventSpy);

      collector.trackRequest('GET', '/api/test', 200, 0.5);

      expect(eventSpy).toHaveBeenCalledWith(expect.objectContaining({
        method: 'GET',
        path: '/api/test',
        statusCode: 200,
        duration: 0.5
      }));
    });

    it('should emit AWS operation events', () => {
      const eventSpy = vi.fn();
      collector.on('aws_operation', eventSpy);

      collector.trackAwsOperation('S3', 'PutObject', 0.3, 'success');

      expect(eventSpy).toHaveBeenCalledWith({
        service: 'S3',
        operation: 'PutObject',
        duration: 0.3,
        status: 'success'
      });
    });

    it('should emit business events', () => {
      const eventSpy = vi.fn();
      collector.on('business_event', eventSpy);

      collector.trackUserRegistration();

      expect(eventSpy).toHaveBeenCalledWith({
        type: 'user_registration'
      });
    });

    it('should emit system metrics events', (done) => {
      collector.on('system_metrics', (metrics) => {
        expect(metrics).toBeDefined();
        done();
      });

      // Trigger system metrics collection
      vi.advanceTimersByTime(10000);
    });
  });

  describe('Edge Cases', () => {
    it('should handle very small response times', () => {
      collector.trackRequest('GET', '/api/fast', 200, 0.001);
      
      const histogram = collector.getMetric('http_request_duration_seconds') as Histogram;
      expect(histogram.getMetrics().count).toBe(1);
    });

    it('should handle very large response times', () => {
      collector.trackRequest('GET', '/api/slow', 200, 60.0);
      
      const histogram = collector.getMetric('http_request_duration_seconds') as Histogram;
      expect(histogram.getMetrics().count).toBe(1);
    });

    it('should handle concurrent metric updates', () => {
      const promises: Promise<void>[] = [];
      
      for (let i = 0; i < 100; i++) {
        promises.push(Promise.resolve().then(() => {
          collector.trackRequest('GET', '/api/test', 200, Math.random());
        }));
      }

      return Promise.all(promises).then(() => {
        const counter = collector.getMetric('http_requests_total') as Counter;
        expect(counter.getValue()).toBe(100);
      });
    });

    it('should handle undefined labels gracefully', () => {
      const counter = new Counter('test', 'Test', undefined);
      counter.inc();
      
      const metric = counter.getMetrics();
      expect(metric.labels).toEqual({});
    });

    it('should handle empty paths and methods', () => {
      collector.trackRequest('', '', 200, 0.5);
      
      const counter = collector.getMetric('http_requests_total') as Counter;
      expect(counter.getValue()).toBe(1);
    });
  });
});
