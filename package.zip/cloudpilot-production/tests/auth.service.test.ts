/**
 * Comprehensive Unit Tests for Authentication Service
 */

import { describe, test, expect, beforeEach, afterEach, jest } from '@jest/globals';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

// Import the auth service
import {
  hashPassword,
  verifyPassword,
  generateAccessToken,
  generateRefreshToken,
  generateTokens,
  authenticateToken,
  optionalAuth,
  verifyRefreshToken,
  refreshSession,
  logout,
  logoutAllSessions,
  requireAdmin,
  rateLimitAuth,
  generateSecureId,
  isValidEmail,
  isValidPassword,
  sessionManager,
  AuthenticatedRequest
} from '../server/auth';

jest.mock('bcryptjs');
jest.mock('jsonwebtoken');

describe('Authentication Service', () => {
  const JWT_SECRET = 'test-secret-key';
  const mockUser = {
    id: 'user-123',
    email: 'test@example.com',
    username: 'testuser'
  };

  beforeEach(() => {
    jest.clearAllMocks();
    process.env.JWT_SECRET = JWT_SECRET;
  });

  afterEach(() => {
    jest.restoreAllMocks();
    sessionManager.sessions.clear();
  });

  describe('Password Hashing', () => {
    test('hashPassword should hash a password with bcrypt', async () => {
      const password = 'TestPassword123!';
      const hashedPassword = 'hashed_password';
      
      (bcrypt.hash as jest.Mock).mockResolvedValue(hashedPassword);
      
      const result = await hashPassword(password);
      
      expect(bcrypt.hash).toHaveBeenCalledWith(password, 12);
      expect(result).toBe(hashedPassword);
    });

    test('hashPassword should handle errors', async () => {
      const password = 'TestPassword123!';
      (bcrypt.hash as jest.Mock).mockRejectedValue(new Error('Hashing failed'));
      
      await expect(hashPassword(password)).rejects.toThrow('Hashing failed');
    });

    test('verifyPassword should verify a password against hash', async () => {
      const password = 'TestPassword123!';
      const hashedPassword = 'hashed_password';
      
      (bcrypt.compare as jest.Mock).mockResolvedValue(true);
      
      const result = await verifyPassword(password, hashedPassword);
      
      expect(bcrypt.compare).toHaveBeenCalledWith(password, hashedPassword);
      expect(result).toBe(true);
    });

    test('verifyPassword should return false for incorrect password', async () => {
      const password = 'WrongPassword123!';
      const hashedPassword = 'hashed_password';
      
      (bcrypt.compare as jest.Mock).mockResolvedValue(false);
      
      const result = await verifyPassword(password, hashedPassword);
      
      expect(result).toBe(false);
    });
  });

  describe('JWT Token Generation', () => {
    test('generateAccessToken should create a valid JWT token', () => {
      const token = generateAccessToken(mockUser);
      
      expect(jwt.sign).toHaveBeenCalledWith(
        {
          id: mockUser.id,
          email: mockUser.email,
          username: mockUser.username,
        },
        JWT_SECRET,
        {
          expiresIn: '24h',
          issuer: 'cloudpilot',
          audience: 'cloudpilot-api',
        }
      );
      expect(token).toBe('mocked-jwt-token');
    });

    test('generateRefreshToken should create a refresh token', () => {
      const token = generateRefreshToken(mockUser);
      
      expect(jwt.sign).toHaveBeenCalledWith(
        {
          id: mockUser.id,
          type: 'refresh',
        },
        JWT_SECRET,
        {
          expiresIn: '7d',
          issuer: 'cloudpilot',
          audience: 'cloudpilot-api',
        }
      );
      expect(token).toBe('mocked-jwt-token');
    });

    test('generateTokens should create both access and refresh tokens', () => {
      (jwt.sign as jest.Mock)
        .mockReturnValueOnce('mocked-access-token')
        .mockReturnValueOnce('mocked-refresh-token');
      
      const result = generateTokens(mockUser);
      
      expect(result).toEqual({
        accessToken: 'mocked-access-token',
        refreshToken: 'mocked-refresh-token',
        expiresIn: '24h',
        sessionCreated: expect.any(Date)
      });
    });
  });

  describe('JWT Token Verification', () => {
    test('authenticateToken should verify valid token and attach user', async () => {
      const mockDecoded = {
        id: mockUser.id,
        email: mockUser.email,
        username: mockUser.username,
        iat: 1234567890,
        exp: 1234567890,
        iss: 'cloudpilot',
        aud: 'cloudpilot-api'
      };
      
      (jwt.verify as jest.Mock).mockReturnValue(mockDecoded);
      
      const req = {
        headers: { authorization: 'Bearer valid-token' }
      } as any as AuthenticatedRequest;
      
      const res = {
        status: jest.fn().mockReturnThis(),
        json: jest.fn()
      } as any;
      
      const next = jest.fn();
      
      await authenticateToken(req, res, next);
      
      expect(jwt.verify).toHaveBeenCalledWith('valid-token', JWT_SECRET);
      expect(req.user).toEqual({
        id: mockUser.id,
        email: mockUser.email,
        username: mockUser.username
      });
      expect(next).toHaveBeenCalled();
    });

    test('authenticateToken should reject request without token', async () => {
      const req = { headers: {} } as any as AuthenticatedRequest;
      const res = {
        status: jest.fn().mockReturnThis(),
        json: jest.fn()
      } as any;
      const next = jest.fn();
      
      await authenticateToken(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(401);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Access token is required',
        error: 'TOKEN_MISSING'
      });
      expect(next).not.toHaveBeenCalled();
    });

    test('authenticateToken should reject invalid token issuer', async () => {
      const mockDecoded = {
        id: mockUser.id,
        email: mockUser.email,
        username: mockUser.username,
        iat: 1234567890,
        exp: 1234567890,
        iss: 'wrong-issuer',
        aud: 'cloudpilot-api'
      };
      
      (jwt.verify as jest.Mock).mockReturnValue(mockDecoded);
      
      const req = {
        headers: { authorization: 'Bearer valid-token' }
      } as any as AuthenticatedRequest;
      
      const res = {
        status: jest.fn().mockReturnThis(),
        json: jest.fn()
      } as any;
      
      const next = jest.fn();
      
      await authenticateToken(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(401);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Invalid token',
        error: 'TOKEN_INVALID'
      });
    });

    test('authenticateToken should handle expired tokens', async () => {
      (jwt.verify as jest.Mock).mockImplementation(() => {
        throw new jwt.TokenExpiredError('Token expired', new Date());
      });
      
      const req = {
        headers: { authorization: 'Bearer expired-token' }
      } as any as AuthenticatedRequest;
      
      const res = {
        status: jest.fn().mockReturnThis(),
        json: jest.fn()
      } as any;
      
      const next = jest.fn();
      
      await authenticateToken(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(401);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Token has expired',
        error: 'TOKEN_EXPIRED'
      });
    });

    test('optionalAuth should continue without authentication if token invalid', async () => {
      (jwt.verify as jest.Mock).mockImplementation(() => {
        throw new Error('Invalid token');
      });
      
      const req = {
        headers: { authorization: 'Bearer invalid-token' }
      } as any as AuthenticatedRequest;
      
      const res = {} as any;
      const next = jest.fn();
      
      await optionalAuth(req, res, next);
      
      expect(req.user).toBeUndefined();
      expect(next).toHaveBeenCalled();
    });

    test('verifyRefreshToken should validate refresh token and return user info', () => {
      const mockDecoded = {
        id: mockUser.id,
        type: 'refresh',
        iat: 1234567890,
        exp: 1234567890,
        iss: 'cloudpilot',
        aud: 'cloudpilot-api'
      };
      
      (jwt.verify as jest.Mock).mockReturnValue(mockDecoded);
      (sessionManager.getSession as jest.Mock).mockReturnValue({
        userId: mockUser.id,
        token: 'refresh-token'
      });
      
      const result = verifyRefreshToken('valid-refresh-token');
      
      expect(result).toEqual({
        id: mockUser.id,
        email: '',
        username: ''
      });
    });

    test('verifyRefreshToken should reject non-refresh tokens', () => {
      const mockDecoded = {
        id: mockUser.id,
        type: 'access',
        iat: 1234567890,
        exp: 1234567890,
        iss: 'cloudpilot',
        aud: 'cloudpilot-api'
      };
      
      (jwt.verify as jest.Mock).mockReturnValue(mockDecoded);
      
      const result = verifyRefreshToken('access-token');
      
      expect(result).toBeNull();
    });

    test('refreshSession should generate new tokens', () => {
      (verifyRefreshToken as jest.Mock).mockReturnValue(mockUser);
      (jwt.sign as jest.Mock)
        .mockReturnValueOnce('new-access-token')
        .mockReturnValueOnce('new-refresh-token');
      
      (sessionManager.removeSession as jest.Mock).mockReturnValue(true);
      (sessionManager.createSession as jest.Mock).mockReturnValue({
        userId: mockUser.id,
        createdAt: new Date()
      });
      
      const result = refreshSession('valid-refresh-token');
      
      expect(result).toEqual({
        accessToken: 'new-access-token',
        refreshToken: 'new-refresh-token'
      });
    });

    test('refreshSession should return null for invalid refresh token', () => {
      (verifyRefreshToken as jest.Mock).mockReturnValue(null);
      
      const result = refreshSession('invalid-refresh-token');
      
      expect(result).toBeNull();
    });
  });

  describe('Session Management', () => {
    test('logout should remove session', () => {
      (sessionManager.removeSession as jest.Mock).mockReturnValue(true);
      
      const result = logout('valid-token');
      
      expect(sessionManager.removeSession).toHaveBeenCalledWith('valid-token');
      expect(result).toBe(true);
    });

    test('logoutAllSessions should remove all user sessions', () => {
      const removeSessionSpy = jest.spyOn(sessionManager, 'removeUserSessions');
      
      logoutAllSessions(mockUser.id);
      
      expect(removeSessionSpy).toHaveBeenCalledWith(mockUser.id);
    });
  });

  describe('Authorization Middleware', () => {
    test('requireAdmin should reject unauthenticated requests', () => {
      const req = {} as any as AuthenticatedRequest;
      const res = {
        status: jest.fn().mockReturnThis(),
        json: jest.fn()
      } as any;
      const next = jest.fn();
      
      requireAdmin(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(401);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Authentication required',
        error: 'AUTHENTICATION_REQUIRED'
      });
      expect(next).not.toHaveBeenCalled();
    });

    test('requireAdmin should allow authenticated users', () => {
      const req = {
        user: mockUser
      } as any as AuthenticatedRequest;
      const res = {} as any;
      const next = jest.fn();
      
      requireAdmin(req, res, next);
      
      expect(next).toHaveBeenCalled();
    });
  });

  describe('Rate Limiting', () => {
    test('rateLimitAuth should allow requests within limit', () => {
      const middleware = rateLimitAuth(5, 15 * 60 * 1000);
      const req = { ip: '192.168.1.1' } as any;
      const res = {
        status: jest.fn().mockReturnThis(),
        json: jest.fn()
      } as any;
      const next = jest.fn();
      
      middleware(req, res, next);
      
      expect(next).toHaveBeenCalled();
    });

    test('rateLimitAuth should block requests exceeding limit', () => {
      const middleware = rateLimitAuth(2, 15 * 60 * 1000);
      const req = { ip: '192.168.1.2' } as any;
      const res = {
        status: jest.fn().mockReturnThis(),
        json: jest.fn()
      } as any;
      const next = jest.fn();
      
      // First request
      middleware(req, res, next);
      // Second request
      middleware(req, res, next);
      // Third request should be blocked
      middleware(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(429);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Too many authentication attempts. Please try again later.',
        error: 'RATE_LIMIT_EXCEEDED',
        retryAfter: expect.any(Number)
      });
    });
  });

  describe('Utility Functions', () => {
    test('generateSecureId should generate random ID', () => {
      const id = generateSecureId();
      expect(id).toHaveLength(18);
      expect(typeof id).toBe('string');
    });

    test('isValidEmail should validate email addresses', () => {
      expect(isValidEmail('test@example.com')).toBe(true);
      expect(isValidEmail('user.name@subdomain.example.com')).toBe(true);
      expect(isValidEmail('invalid-email')).toBe(false);
      expect(isValidEmail('@example.com')).toBe(false);
      expect(isValidEmail('test@')).toBe(false);
    });

    test('isValidPassword should validate password requirements', () => {
      // Valid password
      expect(isValidPassword('StrongPass123!')).toEqual({ valid: true });
      
      // Invalid passwords
      expect(isValidPassword('weak')).toEqual({
        valid: false,
        message: 'Password must be at least 8 characters long'
      });
      
      expect(isValidPassword('nouppercase123!')).toEqual({
        valid: false,
        message: 'Password must contain at least one uppercase letter'
      });
      
      expect(isValidPassword('NOLOWERCASE123!')).toEqual({
        valid: false,
        message: 'Password must contain at least one lowercase letter'
      });
      
      expect(isValidPassword('NoNumbers!')).toEqual({
        valid: false,
        message: 'Password must contain at least one number'
      });
      
      expect(isValidPassword('NoSpecialChars123')).toEqual({
        valid: false,
        message: 'Password must contain at least one special character'
      });
    });
  });

  describe('Session Manager', () => {
    test('createSession should create and store session', () => {
      const token = 'test-token';
      const session = sessionManager.createSession(mockUser.id, token);
      
      expect(session.userId).toBe(mockUser.id);
      expect(session.token).toBe(token);
      expect(session.expiresAt).toBeInstanceOf(Date);
    });

    test('getSession should retrieve existing session', () => {
      const token = 'test-token';
      sessionManager.createSession(mockUser.id, token);
      
      const session = sessionManager.getSession(token);
      
      expect(session).toBeDefined();
      expect(session?.userId).toBe(mockUser.id);
      expect(session?.token).toBe(token);
    });

    test('getSession should return null for expired session', () => {
      const token = 'test-token';
      const session = sessionManager.createSession(mockUser.id, token);
      
      // Simulate expiration by modifying the expiresAt
      session.expiresAt = new Date(Date.now() - 1000);
      
      const retrieved = sessionManager.getSession(token);
      
      expect(retrieved).toBeNull();
    });

    test('removeSession should delete session', () => {
      const token = 'test-token';
      sessionManager.createSession(mockUser.id, token);
      
      const result = sessionManager.removeSession(token);
      
      expect(result).toBe(true);
      expect(sessionManager.getSession(token)).toBeNull();
    });

    test('cleanupExpiredSessions should remove expired sessions', () => {
      // Create expired session
      const expiredToken = 'expired-token';
      const expiredSession = sessionManager.createSession(mockUser.id, expiredToken);
      expiredSession.expiresAt = new Date(Date.now() - 1000);
      
      // Create valid session
      const validToken = 'valid-token';
      sessionManager.createSession(mockUser.id, validToken);
      
      sessionManager.cleanupExpiredSessions();
      
      expect(sessionManager.getSession(expiredToken)).toBeNull();
      expect(sessionManager.getSession(validToken)).toBeDefined();
    });
  });

  describe('Edge Cases and Error Handling', () => {
    test('should handle JWT verification errors', async () => {
      (jwt.verify as jest.Mock).mockImplementation(() => {
        throw new Error('Unknown verification error');
      });
      
      const req = {
        headers: { authorization: 'Bearer error-token' }
      } as any as AuthenticatedRequest;
      
      const res = {
        status: jest.fn().mockReturnThis(),
        json: jest.fn()
      } as any;
      
      const next = jest.fn();
      
      await authenticateToken(req, res, next);
      
      expect(res.status).toHaveBeenCalledWith(500);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Token verification failed',
        error: 'TOKEN_VERIFICATION_ERROR'
      });
    });

    test('should handle missing JWT secret', () => {
      delete process.env.JWT_SECRET;
      
      expect(() => generateAccessToken(mockUser)).not.toThrow();
      expect(jwt.sign).toHaveBeenCalledWith(
        expect.any(Object),
        'your-secret-key-change-in-production', // fallback secret
        expect.any(Object)
      );
    });
  });
});
