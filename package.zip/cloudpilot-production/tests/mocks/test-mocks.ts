/**
 * Mock Data for Testing
 * Common mock data used across tests
 */

// User mocks
export const mockUsers = {
  valid: {
    id: 'user-123',
    email: 'test@example.com',
    password_hash: '$2b$10$mock_hash_for_testing',
    role: 'user',
    created_at: new Date('2024-01-01'),
    updated_at: new Date('2024-01-01')
  },
  
  admin: {
    id: 'admin-123',
    email: 'admin@example.com',
    password_hash: '$2b$10$mock_admin_hash',
    role: 'admin',
    permissions: ['read', 'write', 'delete'],
    created_at: new Date('2024-01-01'),
    updated_at: new Date('2024-01-01')
  },
  
  invalid: {
    id: '',
    email: 'invalid-email',
    password_hash: '',
    role: '',
    created_at: new Date('invalid-date'),
    updated_at: new Date('invalid-date')
  }
};

// Session mocks
export const mockSessions = {
  valid: {
    id: 'session-123',
    user_id: 'user-123',
    expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
    created_at: new Date('2024-01-01'),
    updated_at: new Date('2024-01-01')
  },
  
  expired: {
    id: 'session-expired',
    user_id: 'user-123',
    expires_at: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
    created_at: new Date('2024-01-01'),
    updated_at: new Date('2024-01-01')
  }
};

// Token mocks
export const mockTokens = {
  jwt: {
    valid: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.valid.jwt.token',
    invalid: 'invalid.jwt.token',
    expired: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.expired.jwt.token',
    admin: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.admin.jwt.token'
  },
  
  refresh: {
    valid: 'refresh-token-123',
    invalid: 'invalid-refresh-token',
    expired: 'expired-refresh-token'
  }
};

// API response mocks
export const mockApiResponses = {
  success: {
    success: true,
    data: {},
    message: 'Request successful',
    timestamp: new Date().toISOString()
  },
  
  error: {
    success: false,
    error: 'Bad Request',
    message: 'Invalid request data',
    timestamp: new Date().toISOString()
  },
  
  validationError: {
    success: false,
    error: 'ValidationError',
    message: 'Request validation failed',
    details: [
      { field: 'email', message: 'Email is required' },
      { field: 'password', message: 'Password must be at least 8 characters' }
    ],
    timestamp: new Date().toISOString()
  },
  
  unauthorized: {
    success: false,
    error: 'Unauthorized',
    message: 'Authentication required',
    timestamp: new Date().toISOString()
  },
  
  forbidden: {
    success: false,
    error: 'Forbidden',
    message: 'Insufficient permissions',
    timestamp: new Date().toISOString()
  },
  
  notFound: {
    success: false,
    error: 'NotFound',
    message: 'Resource not found',
    timestamp: new Date().toISOString()
  },
  
  serverError: {
    success: false,
    error: 'InternalServerError',
    message: 'An unexpected error occurred',
    timestamp: new Date().toISOString()
  }
};

// AWS service mocks
export const mockAWS = {
  s3: {
    uploadSuccess: {
      ETag: '"test-etag"',
      Location: 'https://test-bucket.s3.amazonaws.com/test-file.txt',
      Key: 'test-file.txt'
    },
    
    downloadSuccess: {
      Body: {
        transformToString: () => 'file content'
      }
    },
    
    deleteSuccess: {}
  },
  
  secrets: {
    getSecretSuccess: {
      ARN: 'arn:aws:secretsmanager:us-east-1:123456789012:secret:test-secret',
      Name: 'test-secret',
      SecretString: JSON.stringify({
        username: 'test',
        password: 'test123'
      }),
      VersionId: 'test-version'
    }
  }
};

// Database query mocks
export const mockDbQueries = {
  // User queries
  findUserById: {
    rows: [mockUsers.valid],
    rowCount: 1
  },
  
  findUserByEmail: {
    rows: [mockUsers.valid],
    rowCount: 1
  },
  
  createUser: {
    rows: [mockUsers.valid],
    rowCount: 1
  },
  
  updateUser: {
    rows: [mockUsers.valid],
    rowCount: 1
  },
  
  deleteUser: {
    rows: [],
    rowCount: 1
  },
  
  // Session queries
  createSession: {
    rows: [mockSessions.valid],
    rowCount: 1
  },
  
  findSessionById: {
    rows: [mockSessions.valid],
    rowCount: 1
  },
  
  deleteSession: {
    rows: [],
    rowCount: 1
  },
  
  // Error queries
  noResults: {
    rows: [],
    rowCount: 0
  },
  
  dbError: () => {
    throw new Error('Database connection failed');
  }
};

// HTTP request mocks
export const mockHttpRequests = {
  // Valid requests
  validUserCreate: {
    method: 'POST',
    url: '/api/users',
    headers: {
      'content-type': 'application/json',
      'authorization': 'Bearer valid-jwt-token'
    },
    body: {
      email: 'newuser@example.com',
      password: 'password123'
    }
  },
  
  validUserLogin: {
    method: 'POST',
    url: '/api/auth/login',
    headers: {
      'content-type': 'application/json'
    },
    body: {
      email: 'test@example.com',
      password: 'password123'
    }
  },
  
  // Invalid requests
  invalidUserCreate: {
    method: 'POST',
    url: '/api/users',
    headers: {
      'content-type': 'application/json'
    },
    body: {
      email: 'invalid-email',
      password: '123'
    }
  },
  
  missingBody: {
    method: 'POST',
    url: '/api/users',
    headers: {
      'content-type': 'application/json'
    },
    body: {}
  },
  
  // Unauthorized requests
  missingAuth: {
    method: 'GET',
    url: '/api/users/profile',
    headers: {
      'content-type': 'application/json'
    }
  },
  
  invalidAuth: {
    method: 'GET',
    url: '/api/users/profile',
    headers: {
      'content-type': 'application/json',
      'authorization': 'Bearer invalid-token'
    }
  }
};

// Middleware mocks
export const mockMiddleware = {
  // Authentication middleware
  authMiddleware: {
    pass: (req: any, res: any, next: any) => {
      req.user = mockUsers.valid;
      next();
    },
    
    fail: (req: any, res: any, next: any) => {
      res.status(401).json(mockApiResponses.unauthorized);
    }
  },
  
  // Authorization middleware
  adminMiddleware: {
    pass: (req: any, res: any, next: any) => {
      req.user = mockUsers.admin;
      next();
    },
    
    fail: (req: any, res: any, next: any) => {
      res.status(403).json(mockApiResponses.forbidden);
    }
  },
  
  // Validation middleware
  validationMiddleware: {
    pass: (req: any, res: any, next: any) => {
      next();
    },
    
    fail: (req: any, res: any, next: any) => {
      res.status(400).json(mockApiResponses.validationError);
    }
  }
};

// Utility function to get specific mock
export const getMock = (category: string, key: string) => {
  const mocks: Record<string, any> = {
    users: mockUsers,
    sessions: mockSessions,
    tokens: mockTokens,
    apiResponses: mockApiResponses,
    aws: mockAWS,
    dbQueries: mockDbQueries,
    httpRequests: mockHttpRequests,
    middleware: mockMiddleware
  };
  
  if (mocks[category] && mocks[category][key]) {
    return mocks[category][key];
  }
  
  throw new Error(`Mock not found: ${category}.${key}`);
};

// Export all mocks for easy access
export default {
  users: mockUsers,
  sessions: mockSessions,
  tokens: mockTokens,
  apiResponses: mockApiResponses,
  aws: mockAWS,
  dbQueries: mockDbQueries,
  httpRequests: mockHttpRequests,
  middleware: mockMiddleware,
  getMock
};
