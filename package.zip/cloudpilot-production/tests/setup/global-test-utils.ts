/**
 * Global Test Utilities
 * Reusable utilities for all tests
 */

// Extend expect for additional matchers
declare global {
  namespace jest {
    interface Matchers<R> {
      toBeWithinRange(floor: number, ceiling: number): R;
      toHaveBeenCalledWithIsoDate(): R;
      toBeValidEmail(): R;
      toBeValidUUID(): R;
    }
  }
}

// Custom matchers
expect.extend({
  toBeWithinRange(received: number, floor: number, ceiling: number) {
    const pass = received >= floor && received <= ceiling;
    if (pass) {
      return {
        message: () => `expected ${received} not to be within range ${floor} - ${ceiling}`,
        pass: true,
      };
    } else {
      return {
        message: () => `expected ${received} to be within range ${floor} - ${ceiling}`,
        pass: false,
      };
    }
  },

  toHaveBeenCalledWithIsoDate() {
    const pass = this.equals(
      this.actual.mock.calls[this.actual.mock.calls.length - 1],
      expect.arrayContaining([expect.any(String)])
    );
    
    return {
      pass,
      message: () => pass 
        ? 'Expected function not to have been called with ISO date string'
        : 'Expected function to have been called with ISO date string'
    };
  },

  toBeValidEmail() {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const pass = emailRegex.test(this.actual);
    
    return {
      pass,
      message: () => pass 
        ? `Expected ${this.actual} not to be a valid email`
        : `Expected ${this.actual} to be a valid email`
    };
  },

  toBeValidUUID() {
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const pass = uuidRegex.test(this.actual);
    
    return {
      pass,
      message: () => pass 
        ? `Expected ${this.actual} not to be a valid UUID`
        : `Expected ${this.actual} to be a valid UUID`
    };
  }
});

// Export global test utilities
export const testHelpers = {
  // Random data generators
  generateId: () => Math.random().toString(36).substr(2, 9),
  generateEmail: () => `test-${Math.random().toString(36).substr(2, 9)}@example.com`,
  generateUUID: () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  }),
  
  // Time utilities
  sleep: (ms: number) => new Promise(resolve => setTimeout(resolve, ms)),
  waitFor: async (condition: () => boolean, timeout = 5000) => {
    const start = Date.now();
    while (!condition() && Date.now() - start < timeout) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    return condition();
  },
  
  // Object utilities
  deepClone: <T>(obj: T): T => JSON.parse(JSON.stringify(obj)),
  omit: <T extends object, K extends keyof T>(obj: T, keys: K[]): Omit<T, K> => {
    const result = { ...obj };
    keys.forEach(key => delete result[key]);
    return result;
  },
  
  // String utilities
  truncate: (str: string, length: number) => str.length > length ? str.substring(0, length) + '...' : str,
  
  // Array utilities
  shuffle: <T>(array: T[]) => array.sort(() => Math.random() - 0.5),
  unique: <T>(array: T[]) => [...new Set(array)],
  
  // Validation utilities
  isValidEmail: (email: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email),
  isValidUUID: (uuid: string) => /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(uuid)
};

// Make utilities available globally
(global as any).testHelpers = testHelpers;
