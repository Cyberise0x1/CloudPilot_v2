/**
 * AWS Services Mocking
 * Mock AWS SDK clients for testing
 */

import { jest } from '@jest/globals';

// Mock AWS S3
jest.mock('@aws-sdk/client-s3', () => ({
  S3Client: jest.fn().mockImplementation(() => ({
    send: jest.fn()
  })),
  PutObjectCommand: jest.fn(),
  GetObjectCommand: jest.fn(),
  DeleteObjectCommand: jest.fn(),
  ListObjectsV2Command: jest.fn(),
  CopyObjectCommand: jest.fn(),
  HeadObjectCommand: jest.fn()
}));

// Mock AWS EC2
jest.mock('@aws-sdk/client-ec2', () => ({
  EC2Client: jest.fn().mockImplementation(() => ({
    send: jest.fn()
  })),
  RunInstancesCommand: jest.fn(),
  TerminateInstancesCommand: jest.fn(),
  DescribeInstancesCommand: jest.fn(),
  StartInstancesCommand: jest.fn(),
  StopInstancesCommand: jest.fn(),
  CreateKeyPairCommand: jest.fn(),
  DeleteKeyPairCommand: jest.fn()
}));

// Mock AWS RDS
jest.mock('@aws-sdk/client-rds', () => ({
  RDSClient: jest.fn().mockImplementation(() => ({
    send: jest.fn()
  })),
  CreateDBInstanceCommand: jest.fn(),
  DeleteDBInstanceCommand: jest.fn(),
  DescribeDBInstancesCommand: jest.fn(),
  ModifyDBInstanceCommand: jest.fn(),
  StartDBInstanceCommand: jest.fn(),
  StopDBInstanceCommand: jest.fn()
}));

// Mock AWS CloudFront
jest.mock('@aws-sdk/client-cloudfront', () => ({
  CloudFrontClient: jest.fn().mockImplementation(() => ({
    send: jest.fn()
  })),
  CreateDistributionCommand: jest.fn(),
  DeleteDistributionCommand: jest.fn(),
  GetDistributionCommand: jest.fn(),
  UpdateDistributionCommand: jest.fn(),
  CreateInvalidationCommand: jest.fn(),
  GetInvalidationCommand: jest.fn()
}));

// Mock AWS Secrets Manager (common in backend applications)
jest.mock('@aws-sdk/client-secrets-manager', () => ({
  SecretsManagerClient: jest.fn().mockImplementation(() => ({
    send: jest.fn()
  })),
  CreateSecretCommand: jest.fn(),
  GetSecretValueCommand: jest.fn(),
  UpdateSecretCommand: jest.fn(),
  DeleteSecretCommand: jest.fn(),
  DescribeSecretCommand: jest.fn()
}));

// Mock AWS Systems Manager (for parameter store)
jest.mock('@aws-sdk/client-ssm', () => ({
  SSMClient: jest.fn().mockImplementation(() => ({
    send: jest.fn()
  })),
  GetParameterCommand: jest.fn(),
  GetParametersCommand: jest.fn(),
  PutParameterCommand: jest.fn(),
  DeleteParameterCommand: jest.fn(),
  DescribeParametersCommand: jest.fn()
}));

// AWS service test utilities
export const awsTestUtils = {
  // S3 utilities
  s3: {
    createBucket: jest.fn().mockResolvedValue({}),
    uploadObject: jest.fn().mockResolvedValue({ 
      ETag: '"mock-etag"',
      Location: 'https://mock-bucket.s3.amazonaws.com/mock-key'
    }),
    downloadObject: jest.fn().mockResolvedValue({
      Body: {
        transformToString: jest.fn().mockResolvedValue('mock-content')
      }
    }),
    deleteObject: jest.fn().mockResolvedValue({}),
    listObjects: jest.fn().mockResolvedValue({
      Contents: [
        { Key: 'test-file.txt', Size: 1024, LastModified: new Date() }
      ]
    })
  },
  
  // EC2 utilities
  ec2: {
    launchInstance: jest.fn().mockResolvedValue({
      Instances: [{
        InstanceId: 'i-mock12345',
        State: { Name: 'pending' },
        PublicIpAddress: '192.168.1.1'
      }]
    }),
    terminateInstance: jest.fn().mockResolvedValue({
      TerminatingInstances: [{
        InstanceId: 'i-mock12345',
        CurrentState: { Name: 'shutting-down' },
        PreviousState: { Name: 'running' }
      }]
    }),
    describeInstances: jest.fn().mockResolvedValue({
      Reservations: [{
        Instances: [{
          InstanceId: 'i-mock12345',
          State: { Name: 'running' },
          PublicIpAddress: '192.168.1.1'
        }]
      }]
    })
  },
  
  // RDS utilities
  rds: {
    createDatabase: jest.fn().mockResolvedValue({
      DBInstance: {
        DBInstanceIdentifier: 'mock-db-instance',
        DBInstanceStatus: 'creating',
        Engine: 'postgresql'
      }
    }),
    deleteDatabase: jest.fn().mockResolvedValue({
      DBInstance: {
        DBInstanceIdentifier: 'mock-db-instance',
        DBInstanceStatus: 'deleting'
      }
    }),
    describeDatabases: jest.fn().mockResolvedValue({
      DBInstances: [{
        DBInstanceIdentifier: 'mock-db-instance',
        DBInstanceStatus: 'available',
        Engine: 'postgresql'
      }]
    })
  },
  
  // CloudFront utilities
  cloudfront: {
    createDistribution: jest.fn().mockResolvedValue({
      Distribution: {
        Id: 'EMOCK123456789',
        Status: 'InProgress'
      }
    }),
    invalidateFiles: jest.fn().mockResolvedValue({
      Invalidation: {
        Id: 'I-MOCK123456789',
        Status: 'InProgress'
      }
    })
  },
  
  // Secrets Manager utilities
  secretsManager: {
    createSecret: jest.fn().mockResolvedValue({
      ARN: 'arn:aws:secretsmanager:us-east-1:123456789012:secret:mock-secret',
      Name: 'mock-secret',
      VersionId: 'mock-version-id'
    }),
    getSecret: jest.fn().mockResolvedValue({
      ARN: 'arn:aws:secretsmanager:us-east-1:123456789012:secret:mock-secret',
      SecretString: '{"username": "test", "password": "test123"}',
      VersionId: 'mock-version-id'
    })
  },
  
  // SSM utilities
  ssm: {
    getParameter: jest.fn().mockResolvedValue({
      Parameter: {
        Name: '/test/parameter',
        Value: 'test-value',
        Type: 'String'
      }
    }),
    getParameters: jest.fn().mockResolvedValue({
      Parameters: [
        { Name: '/test/param1', Value: 'value1', Type: 'String' },
        { Name: '/test/param2', Value: 'value2', Type: 'String' }
      ]
    })
  },
  
  // Reset all mocks
  resetAll: () => {
    Object.values(awsTestUtils).forEach(service => {
      if (typeof service === 'object') {
        Object.values(service).forEach(method => {
          if (typeof method === 'function') {
            method.mockReset();
          }
        });
      }
    });
  },
  
  // Setup common responses
  setupSuccessResponses: () => {
    awsTestUtils.s3.uploadObject.mockResolvedValue({
      ETag: '"test-etag"',
      Location: 'https://test-bucket.s3.amazonaws.com/test-key'
    });
    
    awsTestUtils.secretsManager.getSecret.mockResolvedValue({
      SecretString: JSON.stringify({
        username: 'test',
        password: 'test123',
        database_url: 'postgresql://test:test@localhost:5432/test'
      })
    });
  },
  
  // Setup error responses
  setupErrorResponses: (errorType: 'network' | 'auth' | 'notFound' = 'network') => {
    const errors = {
      network: new Error('AWS network error'),
      auth: new Error('AWS authentication failed'),
      notFound: new Error('AWS resource not found')
    };
    
    Object.values(awsTestUtils).forEach(service => {
      if (typeof service === 'object') {
        Object.values(service).forEach(method => {
          if (typeof method === 'function') {
            method.mockRejectedValue(errors[errorType]);
          }
        });
      }
    });
  }
};

// Make AWS test utilities globally available
(global as any).awsTestUtils = awsTestUtils;

console.log('✅ AWS services test environment configured');
