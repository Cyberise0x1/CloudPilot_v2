/**
 * Global Teardown Configuration
 * Cleanup after all tests complete
 */

import { cleanupTestDatabase } from './database-cleanup';
import { cleanupTestEnvironment } from './environment-cleanup';

export default async function globalTeardown() {
  console.log('🧹 Running global teardown...');
  
  try {
    // Cleanup database connections
    await cleanupTestDatabase();
    
    // Cleanup environment variables
    await cleanupTestEnvironment();
    
    // Close any remaining connections or resources
    console.log('✅ Global teardown completed');
  } catch (error) {
    console.error('❌ Error during global teardown:', error);
    throw error;
  }
}
