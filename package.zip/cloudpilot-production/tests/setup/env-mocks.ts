/**
 * Environment Variable Mocking
 * Mock environment variables for testing
 */

import { jest } from '@jest/globals';

// Store original environment
const originalEnv = { ...process.env };

// Default test environment variables
const defaultTestEnv = {
  NODE_ENV: 'test',
  PORT: '3001',
  DATABASE_URL: 'postgresql://test:test@localhost:5432/test_db',
  JWT_SECRET: 'test-jwt-secret-key-for-testing-only',
  JWT_EXPIRES_IN: '15m',
  REFRESH_TOKEN_SECRET: 'test-refresh-token-secret-for-testing',
  REFRESH_TOKEN_EXPIRES_IN: '7d',
  AWS_REGION: 'us-east-1',
  AWS_ACCESS_KEY_ID: 'test-access-key',
  AWS_SECRET_ACCESS_KEY: 'test-secret-key',
  S3_BUCKET_NAME: 'test-bucket',
  S3_REGION: 'us-east-1',
  CLOUD_FRONT_DOMAIN: 'test.cloudfront.net',
  LOG_LEVEL: 'error',
  SESSION_SECRET: 'test-session-secret',
  BCrypt_ROUNDS: '10',
  RATE_LIMIT_WINDOW: '15',
  RATE_LIMIT_MAX: '100',
  CORS_ORIGIN: 'http://localhost:3000',
  SSL_ENABLED: 'false',
  COOKIE_SECURE: 'false',
  REDIS_URL: 'redis://localhost:6379',
  EMAIL_FROM: 'noreply@test.com',
  EMAIL_SERVICE: 'test',
  STRIPE_PUBLIC_KEY: 'pk_test_mock',
  STRIPE_SECRET_KEY: 'sk_test_mock',
  STRIPE_WEBHOOK_SECRET: 'whsec_mock',
  MONITORING_ENABLED: 'false',
  METRICS_ENABLED: 'false',
  HEALTH_CHECK_ENABLED: 'true'
};

// Environment variable utilities
export const envTestUtils = {
  // Set test environment variables
  setTestEnv: (customEnv: Record<string, string> = {}) => {
    // Reset to defaults first
    Object.keys(process.env).forEach(key => {
      if (key.startsWith('NODE_') || 
          key.startsWith('PORT') ||
          key.startsWith('DATABASE') ||
          key.startsWith('JWT') ||
          key.startsWith('AWS') ||
          key.startsWith('S3_') ||
          key.startsWith('CLOUD') ||
          key.startsWith('SESSION') ||
          key.startsWith('RATE_') ||
          key.startsWith('CORS') ||
          key.startsWith('SSL') ||
          key.startsWith('COOKIE') ||
          key.startsWith('REDIS') ||
          key.startsWith('EMAIL') ||
          key.startsWith('STRIPE') ||
          key.startsWith('MONITORING') ||
          key.startsWith('METRICS') ||
          key.startsWith('HEALTH') ||
          key === 'LOG_LEVEL' ||
          key === 'BCRYPT_ROUNDS') {
        delete process.env[key];
      }
    });
    
    // Set default values
    Object.entries(defaultTestEnv).forEach(([key, value]) => {
      process.env[key] = value;
    });
    
    // Set custom values
    Object.entries(customEnv).forEach(([key, value]) => {
      process.env[key] = value;
    });
  },
  
  // Get environment variable with default
  get: (key: string, defaultValue?: string): string => {
    return process.env[key] || defaultValue || '';
  },
  
  // Check if environment variable is set
  isSet: (key: string): boolean => {
    return process.env[key] !== undefined;
  },
  
  // Set individual environment variable
  set: (key: string, value: string) => {
    process.env[key] = value;
  },
  
  // Unset environment variable
  unset: (key: string) => {
    delete process.env[key];
  },
  
  // Reset to original environment
  reset: () => {
    Object.keys(process.env).forEach(key => {
      delete process.env[key];
    });
    Object.entries(originalEnv).forEach(([key, value]) => {
      process.env[key] = value;
    });
  },
  
  // Get all environment variables (excluding sensitive ones)
  getSafeEnv: () => {
    const safeEnv: Record<string, string> = {};
    Object.entries(process.env).forEach(([key, value]) => {
      if (!key.includes('SECRET') && 
          !key.includes('PASSWORD') && 
          !key.includes('KEY') &&
          !key.includes('TOKEN')) {
        safeEnv[key] = value || '';
      } else {
        safeEnv[key] = '[REDACTED]';
      }
    });
    return safeEnv;
  },
  
  // Validate required environment variables
  validateRequired: (requiredVars: string[]): { valid: boolean; missing: string[] } => {
    const missing = requiredVars.filter(varName => !process.env[varName]);
    return {
      valid: missing.length === 0,
      missing
    };
  }
};

// Configuration validation utilities
export const configValidation = {
  // Validate database configuration
  validateDatabaseConfig: () => {
    const required = ['DATABASE_URL'];
    const result = envTestUtils.validateRequired(required);
    if (!result.valid) {
      throw new Error(`Missing required database environment variables: ${result.missing.join(', ')}`);
    }
    return true;
  },
  
  // Validate AWS configuration
  validateAWSConfig: () => {
    const required = ['AWS_REGION', 'AWS_ACCESS_KEY_ID', 'AWS_SECRET_ACCESS_KEY'];
    const result = envTestUtils.validateRequired(required);
    if (!result.valid) {
      throw new Error(`Missing required AWS environment variables: ${result.missing.join(', ')}`);
    }
    return true;
  },
  
  // Validate JWT configuration
  validateJWTConfig: () => {
    const required = ['JWT_SECRET'];
    const result = envTestUtils.validateRequired(required);
    if (!result.valid) {
      throw new Error(`Missing required JWT environment variables: ${result.missing.join(', ')}`);
    }
    return true;
  }
};

// Make environment utilities globally available
(global as any).envTestUtils = envTestUtils;
(global as any).configValidation = configValidation;

console.log('✅ Environment variable test environment configured');
