/**
 * Jest Setup Configuration
 * Global test environment setup with mocks and utilities
 */

// Load environment variables for testing
process.env.NODE_ENV = 'test';
process.env.JEST_WORKER_ID = '1';

// Import global test utilities
import './global-test-utils';

// Setup database mocks
import './setup/database-setup';

// Setup AWS service mocks
import './setup/aws-mocks';

// Setup environment variable mocks
import './setup/env-mocks';

// Setup Express app testing utilities
import './setup/express-test-utils';

// Global test timeout configuration
jest.setTimeout(30000);

// Suppress console logs during tests unless in debug mode
if (!process.env.DEBUG_TESTS) {
  global.console = {
    ...console,
    log: jest.fn(),
    debug: jest.fn(),
    info: jest.fn(),
    warn: jest.fn(),
    error: jest.fn()
  };
}

// Extend Jest matchers
import '@jest/globals';

// Global error handler for unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

// Global error handler for uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
});

// Setup global test utilities
global.testUtils = {
  generateId: () => Math.random().toString(36).substr(2, 9),
  sleep: (ms: number) => new Promise(resolve => setTimeout(resolve, ms)),
  waitFor: async (condition: () => boolean, timeout = 5000) => {
    const start = Date.now();
    while (!condition() && Date.now() - start < timeout) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    return condition();
  }
};

console.log('✅ Jest test environment initialized');
