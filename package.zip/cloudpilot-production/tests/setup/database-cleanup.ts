/**
 * Database Cleanup
 * Clean up database connections and data after tests
 */

import { cleanupTestConnections } from '../database-cleanup-utils';

export async function cleanupTestDatabase() {
  console.log('🧹 Cleaning up test database...');
  
  try {
    // Clean up database connections
    await cleanupTestConnections();
    
    console.log('✅ Database cleanup completed');
  } catch (error) {
    console.error('❌ Error during database cleanup:', error);
    throw error;
  }
}
