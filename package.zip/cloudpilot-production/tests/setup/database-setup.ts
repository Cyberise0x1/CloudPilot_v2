/**
 * Database Setup and Mocking
 * Test database configuration and connection mocking
 */

import { jest } from '@jest/globals';
import { Pool } from 'pg';

// Mock the database connection
jest.mock('@neondatabase/serverless', () => ({
  neon: jest.fn(() => ({
    query: jest.fn(),
    get: jest.fn(),
    all: jest.fn(),
    run: jest.fn(),
    execute: jest.fn(),
    transaction: jest.fn()
  })),
  Pool: jest.fn().mockImplementation(() => ({
    query: jest.fn(),
    end: jest.fn(),
    connect: jest.fn(() => ({
      query: jest.fn(),
      release: jest.fn()
    }))
  }))
}));

// Mock Drizzle ORM
jest.mock('drizzle-orm', () => ({
  drizzle: jest.fn(),
  eq: jest.fn(),
  and: jest.fn(),
  or: jest.fn(),
  inArray: jest.fn(),
  not: jest.fn(),
  isNull: jest.fn(),
  isNotNull: jest.fn(),
  gt: jest.fn(),
  gte: jest.fn(),
  lt: jest.fn(),
  lte: jest.fn(),
  like: jest.fn(),
  ilike: jest.fn(),
  between: jest.fn(),
  sql: jest.fn(),
  desc: jest.fn(),
  asc: jest.fn(),
  count: jest.fn(),
  sum: jest.fn(),
  avg: jest.fn(),
  max: jest.fn(),
  min: jest.fn()
}));

// Test database utilities
export const mockDb = {
  // Mock query result
  query: jest.fn(),
  
  // Mock connection
  connection: {
    query: jest.fn(),
    end: jest.fn()
  },
  
  // Reset mocks
  reset: () => {
    mockDb.query.mockReset();
    mockDb.connection.query.mockReset();
  }
};

// Test database factory
export const createTestDb = () => ({
  query: mockDb.query,
  transaction: jest.fn((callback) => callback(mockDb)),
  execute: jest.fn(),
  get: jest.fn(),
  all: jest.fn(),
  run: jest.fn()
});

// Initialize test database with sample data
export const initializeTestData = async () => {
  const mockUsers = [
    {
      id: '550e8400-e29b-41d4-a716-446655440000',
      email: 'test@example.com',
      password_hash: '$2b$10$mock_hash_for_testing',
      created_at: new Date(),
      updated_at: new Date()
    }
  ];
  
  mockDb.query.mockResolvedValue({
    rows: mockUsers,
    rowCount: mockUsers.length
  });
  
  return mockUsers;
};

// Setup in-memory test database
export const setupInMemoryDb = () => {
  const inMemoryDb = {
    users: [] as any[],
    sessions: [] as any[],
    refresh_tokens: [] as any[],
    
    // User operations
    async createUser(userData: any) {
      const user = {
        id: `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        ...userData,
        created_at: new Date(),
        updated_at: new Date()
      };
      this.users.push(user);
      return user;
    },
    
    async findUserByEmail(email: string) {
      return this.users.find(u => u.email === email);
    },
    
    async findUserById(id: string) {
      return this.users.find(u => u.id === id);
    },
    
    // Session operations
    async createSession(sessionData: any) {
      const session = {
        id: `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        ...sessionData,
        created_at: new Date()
      };
      this.sessions.push(session);
      return session;
    },
    
    async findSessionById(id: string) {
      return this.sessions.find(s => s.id === id);
    },
    
    // Reset all data
    async reset() {
      this.users = [];
      this.sessions = [];
      this.refresh_tokens = [];
    }
  };
  
  return inMemoryDb;
};

// Make test database globally available
(global as any).setupInMemoryDb = setupInMemoryDb;
(global as any).mockDb = mockDb;

console.log('✅ Database test environment configured');
