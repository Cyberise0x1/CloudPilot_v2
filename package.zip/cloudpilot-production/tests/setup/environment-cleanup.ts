/**
 * Environment Cleanup
 * Clean up environment variables after tests
 */

import { envTestUtils } from './env-mocks';

export async function cleanupTestEnvironment() {
  console.log('🧹 Cleaning up test environment...');
  
  try {
    // Reset environment variables
    envTestUtils.reset();
    
    console.log('✅ Environment cleanup completed');
  } catch (error) {
    console.error('❌ Error during environment cleanup:', error);
    throw error;
  }
}
