/**
 * Database Cleanup Utilities
 * Helper functions for cleaning up database resources
 */

import { jest } from '@jest/globals';

// Mock connection cleanup
export async function cleanupTestConnections() {
  // Clear all mock functions
  const mockModules = [
    '@neondatabase/serverless',
    'drizzle-orm'
  ];
  
  mockModules.forEach(modulePath => {
    const module = jest.requireMock(modulePath);
    Object.keys(module).forEach(key => {
      if (typeof module[key] === 'function') {
        module[key].mockClear();
      }
    });
  });
  
  // Reset any global database instances
  if ((global as any).testDb) {
    (global as any).testDb = null;
  }
}
