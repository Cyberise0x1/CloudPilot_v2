/**
 * Express Testing Utilities
 * Helper utilities for testing Express applications
 */

import { Request, Response, NextFunction } from 'express';
import { jest } from '@jest/globals';

// Mock Express request/response utilities
export const expressTestUtils = {
  // Create mock request object
  createMockRequest: (options: Partial<Request> = {}): Partial<Request> => {
    return {
      method: options.method || 'GET',
      url: options.url || '/',
      path: options.path || '/',
      headers: {
        'content-type': 'application/json',
        'user-agent': 'Jest Test Client',
        ...options.headers
      },
      body: options.body || {},
      query: options.query || {},
      params: options.params || {},
      cookies: options.cookies || {},
      ip: options.ip || '127.0.0.1',
      hostname: options.hostname || 'localhost',
      protocol: options.protocol || 'http',
      secure: options.secure || false,
      ...options
    } as Partial<Request>;
  },
  
  // Create mock response object
  createMockResponse: (): Partial<Response> => {
    let responseData: any = {};
    const mockRes = {
      status: jest.fn().mockReturnThis(),
      json: jest.fn().mockReturnThis(),
      send: jest.fn().mockReturnThis(),
      sendFile: jest.fn().mockReturnThis(),
      redirect: jest.fn().mockReturnThis(),
      cookie: jest.fn().mockReturnThis(),
      clearCookie: jest.fn().mockReturnThis(),
      set: jest.fn().mockReturnThis(),
      type: jest.fn().mockReturnThis(),
      format: jest.fn().mockReturnThis(),
      locals: {},
      get: jest.fn(),
      getHeader: jest.fn(),
      setHeader: jest.fn(),
      append: jest.fn().mockReturnThis(),
      end: jest.fn(),
      write: jest.fn(),
      ...responseData
    };
    return mockRes as Partial<Response>;
  },
  
  // Create mock next function
  createMockNext: () => jest.fn(),
  
  // Create middleware test wrapper
  testMiddleware: (middleware: (req: Request, res: Response, next: NextFunction) => void) => {
    return async (reqOptions: any = {}, resOptions: any = {}, nextOptions: any = {}) => {
      const req = expressTestUtils.createMockRequest(reqOptions);
      const res = expressTestUtils.createMockResponse();
      const next = expressTestUtils.createMockNext();
      
      await middleware(req as Request, res as Response, next);
      
      return { req, res, next };
    };
  },
  
  // Test controller function
  testController: (controller: (req: Request, res: Response, next?: NextFunction) => Promise<any> | any) => {
    return async (reqOptions: any = {}, resOptions: any = {}) => {
      const req = expressTestUtils.createMockRequest(reqOptions);
      const res = expressTestUtils.createMockResponse();
      const next = expressTestUtils.createMockNext();
      
      let result;
      let error;
      
      try {
        result = await controller(req as Request, res as Response, next);
      } catch (err) {
        error = err;
      }
      
      return { 
        req, 
        res, 
        next, 
        result, 
        error,
        response: res
      };
    };
  }
};

// Authentication utilities for testing
export const authTestUtils = {
  // Create mock authenticated request
  createAuthenticatedRequest: (userId: string = 'user-123', userEmail: string = 'test@example.com') => {
    return {
      headers: {
        ...expressTestUtils.createMockRequest().headers,
        'authorization': `Bearer mock-jwt-token-${userId}`,
        'x-user-id': userId
      },
      user: {
        id: userId,
        email: userEmail
      },
      session: {
        userId,
        email: userEmail
      }
    };
  },
  
  // Create mock unauthorized request
  createUnauthorizedRequest: () => {
    return {
      headers: {
        ...expressTestUtils.createMockRequest().headers
      },
      user: undefined,
      session: undefined
    };
  },
  
  // Create admin request
  createAdminRequest: () => {
    return {
      headers: {
        ...expressTestUtils.createMockRequest().headers,
        'authorization': 'Bearer mock-admin-jwt-token',
        'x-user-id': 'admin-123'
      },
      user: {
        id: 'admin-123',
        email: 'admin@example.com',
        role: 'admin'
      },
      session: {
        userId: 'admin-123',
        email: 'admin@example.com',
        role: 'admin'
      }
    };
  }
};

// Route testing utilities
export const routeTestUtils = {
  // Test GET route
  testGetRoute: (route: any, path: string = '/', options: any = {}) => {
    return expressTestUtils.testController(async (req, res, next) => {
      return route.get ? route.get(req, res, next) : route(req, res, next);
    })({
      method: 'GET',
      path,
      ...options
    });
  },
  
  // Test POST route
  testPostRoute: (route: any, path: string = '/', data: any = {}, options: any = {}) => {
    return expressTestUtils.testController(async (req, res, next) => {
      return route.post ? route.post(req, res, next) : route(req, res, next);
    })({
      method: 'POST',
      path,
      body: data,
      ...options
    });
  },
  
  // Test PUT route
  testPutRoute: (route: any, path: string = '/', data: any = {}, options: any = {}) => {
    return expressTestUtils.testController(async (req, res, next) => {
      return route.put ? route.put(req, res, next) : route(req, res, next);
    })({
      method: 'PUT',
      path,
      body: data,
      ...options
    });
  },
  
  // Test DELETE route
  testDeleteRoute: (route: any, path: string = '/', options: any = {}) => {
    return expressTestUtils.testController(async (req, res, next) => {
      return route.delete ? route.delete(req, res, next) : route(req, res, next);
    })({
      method: 'DELETE',
      path,
      ...options
    });
  }
};

// Response validation utilities
export const responseValidation = {
  // Validate successful response
  validateSuccess: (res: any, expectedStatus: number = 200) => {
    expect(res.status).toHaveBeenCalledWith(expectedStatus);
    expect(res.json).toHaveBeenCalled();
  },
  
  // Validate error response
  validateError: (res: any, expectedStatus: number = 400) => {
    expect(res.status).toHaveBeenCalledWith(expectedStatus);
    expect(res.json).toHaveBeenCalled();
    const callArgs = res.json.mock.calls[0][0];
    expect(callArgs).toHaveProperty('error');
    expect(callArgs).toHaveProperty('message');
  },
  
  // Validate response structure
  validateStructure: (res: any, expectedStructure: Record<string, any>) => {
    const callArgs = res.json.mock.calls[0][0];
    Object.entries(expectedStructure).forEach(([key, expectedType]) => {
      expect(callArgs).toHaveProperty(key);
      if (expectedType !== 'any') {
        expect(typeof callArgs[key]).toBe(expectedType);
      }
    });
  }
};

// Make Express testing utilities globally available
(global as any).expressTestUtils = expressTestUtils;
(global as any).authTestUtils = authTestUtils;
(global as any).routeTestUtils = routeTestUtils;
(global as any).responseValidation = responseValidation;

console.log('✅ Express testing utilities configured');
