/**
 * Test Utilities and Helpers
 * Common utilities for writing tests
 */

import { jest } from '@jest/globals';

// File: tests/utils/test-data-generators.ts
export const testDataGenerators = {
  // Generate random user data
  generateUser: (overrides: any = {}) => ({
    id: `user-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    email: `test-${Math.random().toString(36).substr(2, 9)}@example.com`,
    password_hash: '$2b$10$mock_hash_for_testing',
    role: 'user',
    created_at: new Date(),
    updated_at: new Date(),
    ...overrides
  }),
  
  // Generate random session data
  generateSession: (overrides: any = {}) => ({
    id: `session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    user_id: 'user-123',
    expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
    created_at: new Date(),
    ...overrides
  }),
  
  // Generate random token data
  generateToken: (overrides: any = {}) => ({
    id: `token-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    user_id: 'user-123',
    token_hash: 'mock-hash',
    expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000), // 1 day
    created_at: new Date(),
    ...overrides
  }),
  
  // Generate random file data
  generateFile: (overrides: any = {}) => ({
    id: `file-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    filename: `test-file-${Date.now()}.txt`,
    mime_type: 'text/plain',
    size: Math.floor(Math.random() * 1000000), // Random size up to 1MB
    url: `https://test-bucket.s3.amazonaws.com/test-file-${Date.now()}.txt`,
    created_at: new Date(),
    ...overrides
  }),
  
  // Generate random API response
  generateApiResponse: (overrides: any = {}) => ({
    success: true,
    data: {},
    message: 'Request successful',
    timestamp: new Date().toISOString(),
    ...overrides
  }),
  
  // Generate pagination data
  generatePaginatedResponse: (items: any[], total: number = items.length, page: number = 1, limit: number = 10) => ({
    data: items,
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit),
      hasNext: page < Math.ceil(total / limit),
      hasPrev: page > 1
    }
  })
};

// File: tests/utils/test-factory.ts
export class TestFactory {
  private counter = 0;
  
  private generateId(prefix: string = 'test'): string {
    this.counter++;
    return `${prefix}-${this.counter}-${Date.now()}`;
  }
  
  createUser(overrides: any = {}) {
    return {
      id: this.generateId('user'),
      email: `test-${this.counter}@example.com`,
      password_hash: '$2b$10$mock_hash_for_testing',
      role: 'user',
      created_at: new Date(),
      updated_at: new Date(),
      ...overrides
    };
  }
  
  createAdmin(overrides: any = {}) {
    return this.createUser({
      role: 'admin',
      permissions: ['read', 'write', 'delete'],
      ...overrides
    });
  }
  
  createSession(userId: string = 'user-123', overrides: any = {}) {
    return {
      id: this.generateId('session'),
      user_id: userId,
      expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      created_at: new Date(),
      ...overrides
    };
  }
  
  createRefreshToken(userId: string = 'user-123', overrides: any = {}) {
    return {
      id: this.generateId('token'),
      user_id: userId,
      token_hash: 'mock-hash',
      expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000),
      created_at: new Date(),
      ...overrides
    };
  }
  
  reset() {
    this.counter = 0;
  }
}

// File: tests/utils/async-test-helpers.ts
export const asyncTestHelpers = {
  // Wait for async condition
  waitFor: async (condition: () => boolean | Promise<boolean>, timeout = 5000, interval = 100) => {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const result = await condition();
      if (result) return true;
      await new Promise(resolve => setTimeout(resolve, interval));
    }
    throw new Error(`Timeout after ${timeout}ms waiting for condition`);
  },
  
  // Retry async operation
  retry: async <T>(
    operation: () => Promise<T>,
    maxAttempts = 3,
    delay = 1000,
    backoff = 2
  ): Promise<T> => {
    let attempt = 1;
    let currentDelay = delay;
    
    while (attempt <= maxAttempts) {
      try {
        return await operation();
      } catch (error) {
        if (attempt === maxAttempts) {
          throw error;
        }
        console.log(`Attempt ${attempt} failed, retrying in ${currentDelay}ms...`);
        await new Promise(resolve => setTimeout(resolve, currentDelay));
        currentDelay *= backoff;
        attempt++;
      }
    }
    throw new Error(`Max attempts (${maxAttempts}) exceeded`);
  },
  
  // Timeout wrapper for promises
  withTimeout: <T>(promise: Promise<T>, timeoutMs: number): Promise<T> => {
    return Promise.race([
      promise,
      new Promise<never>((_, reject) => 
        setTimeout(() => reject(new Error(`Timeout after ${timeoutMs}ms`)), timeoutMs)
      )
    ]);
  }
};

// File: tests/utils/assertion-helpers.ts
export const assertionHelpers = {
  // Assert object has required properties
  hasProperties: (obj: any, properties: string[]) => {
    properties.forEach(prop => {
      expect(obj).toHaveProperty(prop);
    });
  },
  
  // Assert object has no extra properties
  hasOnlyProperties: (obj: any, properties: string[]) => {
    const actualProps = Object.keys(obj);
    const unexpected = actualProps.filter(prop => !properties.includes(prop));
    expect(unexpected).toHaveLength(0);
  },
  
  // Assert date is within range
  isDateInRange: (date: Date, start: Date, end: Date) => {
    expect(date.getTime()).toBeGreaterThanOrEqual(start.getTime());
    expect(date.getTime()).toBeLessThanOrEqual(end.getTime());
  },
  
  // Assert arrays are equal (ignoring order)
  arraysEqualIgnoreOrder: (arr1: any[], arr2: any[]) => {
    expect(arr1.sort()).toEqual(arr2.sort());
  },
  
  // Assert object is deeply equal (with custom comparison)
  deepEqualWith: (actual: any, expected: any, customComparisons: Array<{ path: string; compare: (a: any, b: any) => boolean }>) => {
    customComparisons.forEach(({ path, compare }) => {
      const actualValue = path.split('.').reduce((obj, key) => obj?.[key], actual);
      const expectedValue = path.split('.').reduce((obj, key) => obj?.[key], expected);
      expect(compare(actualValue, expectedValue)).toBe(true);
    });
  }
};

// File: tests/utils/database-test-helpers.ts
export const databaseTestHelpers = {
  // Mock database query
  mockDbQuery: (mockResult: any) => {
    const { mockDb } = global as any;
    mockDb.query.mockResolvedValue(mockResult);
  },
  
  // Mock database error
  mockDbError: (error: Error) => {
    const { mockDb } = global as any;
    mockDb.query.mockRejectedValue(error);
  },
  
  // Reset database mocks
  resetDbMocks: () => {
    const { mockDb } = global as any;
    mockDb.query.mockReset();
    mockDb.connection.query.mockReset();
  }
};

// File: tests/utils/http-test-helpers.ts
export const httpTestHelpers = {
  // Create mock HTTP response
  createHttpResponse: (statusCode: number = 200, data: any = {}) => ({
    statusCode,
    headers: {
      'content-type': 'application/json'
    },
    body: JSON.stringify(data)
  }),
  
  // Parse HTTP response
  parseResponse: (response: any) => {
    if (typeof response.body === 'string') {
      return JSON.parse(response.body);
    }
    return response.body;
  },
  
  // Extract headers from response
  extractHeaders: (response: any) => response.headers || {},
  
  // Check if response has CORS headers
  hasCorsHeaders: (response: any) => {
    const headers = httpTestHelpers.extractHeaders(response);
    return headers['access-control-allow-origin'] || headers['Access-Control-Allow-Origin'];
  }
};

// Make all utilities globally available
(global as any).testDataGenerators = testDataGenerators;
(global as any).TestFactory = TestFactory;
(global as any).asyncTestHelpers = asyncTestHelpers;
(global as any).assertionHelpers = assertionHelpers;
(global as any).databaseTestHelpers = databaseTestHelpers;
(global as any).httpTestHelpers = httpTestHelpers;

console.log('✅ Test utilities and helpers configured');
