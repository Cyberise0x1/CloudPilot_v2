/**
 * Test Fixtures
 * Static test data and configurations
 */

import { getMock } from '../mocks/test-mocks';

// Sample user fixtures
export const userFixtures = {
  standard: getMock('users', 'valid'),
  admin: getMock('users', 'admin'),
  
  list: [
    getMock('users', 'valid'),
    {
      ...getMock('users', 'valid'),
      id: 'user-456',
      email: 'user2@example.com'
    },
    {
      ...getMock('users', 'valid'),
      id: 'user-789',
      email: 'user3@example.com'
    }
  ]
};

// Sample session fixtures
export const sessionFixtures = {
  valid: getMock('sessions', 'valid'),
  expired: getMock('sessions', 'expired'),
  
  list: [
    getMock('sessions', 'valid'),
    {
      ...getMock('sessions', 'valid'),
      id: 'session-456',
      user_id: 'user-456'
    }
  ]
};

// API request fixtures
export const requestFixtures = {
  userCreation: {
    valid: {
      email: 'newuser@example.com',
      password: 'securePassword123',
      firstName: 'John',
      lastName: 'Doe'
    },
    
    invalid: {
      email: 'invalid-email',
      password: '123',
      firstName: '',
      lastName: ''
    },
    
    missingFields: {
      email: 'user@example.com'
    }
  },
  
  userLogin: {
    valid: {
      email: 'test@example.com',
      password: 'password123'
    },
    
    invalid: {
      email: 'test@example.com',
      password: 'wrongpassword'
    },
    
    missingFields: {
      email: 'test@example.com'
    }
  },
  
  passwordReset: {
    valid: {
      email: 'test@example.com'
    },
    
    invalid: {
      email: 'nonexistent@example.com'
    }
  },
  
  profileUpdate: {
    valid: {
      firstName: 'Jane',
      lastName: 'Smith',
      bio: 'Updated bio'
    },
    
    invalid: {
      firstName: '',
      lastName: 'Smith',
      bio: 'x'.repeat(1000) // Too long
    }
  }
};

// Database query fixtures
export const queryFixtures = {
  userQueries: {
    selectById: getMock('dbQueries', 'findUserById'),
    selectByEmail: getMock('dbQueries', 'findUserByEmail'),
    insert: getMock('dbQueries', 'createUser'),
    update: getMock('dbQueries', 'updateUser'),
    delete: getMock('dbQueries', 'deleteUser')
  },
  
  sessionQueries: {
    insert: getMock('dbQueries', 'createSession'),
    selectById: getMock('dbQueries', 'findSessionById'),
    delete: getMock('dbQueries', 'deleteSession')
  }
};

// Error fixtures for testing error scenarios
export const errorFixtures = {
  validation: [
    {
      field: 'email',
      message: 'Email is required',
      code: 'REQUIRED'
    },
    {
      field: 'email',
      message: 'Invalid email format',
      code: 'INVALID_FORMAT'
    },
    {
      field: 'password',
      message: 'Password must be at least 8 characters',
      code: 'MIN_LENGTH'
    },
    {
      field: 'password',
      message: 'Password must contain at least one uppercase letter',
      code: 'UPPERCASE_REQUIRED'
    }
  ],
  
  auth: [
    {
      message: 'Invalid credentials',
      code: 'INVALID_CREDENTIALS'
    },
    {
      message: 'Token expired',
      code: 'TOKEN_EXPIRED'
    },
    {
      message: 'Invalid token format',
      code: 'INVALID_TOKEN'
    },
    {
      message: 'User not found',
      code: 'USER_NOT_FOUND'
    }
  ],
  
  database: [
    {
      message: 'Connection failed',
      code: 'DB_CONNECTION_ERROR'
    },
    {
      message: 'Query timeout',
      code: 'DB_TIMEOUT'
    },
    {
      message: 'Constraint violation',
      code: 'DB_CONSTRAINT'
    }
  ],
  
  aws: [
    {
      message: 'S3 upload failed',
      code: 'S3_UPLOAD_ERROR'
    },
    {
      message: 'Secrets not found',
      code: 'SECRETS_NOT_FOUND'
    },
    {
      message: 'AWS credentials invalid',
      code: 'AWS_CREDENTIALS_ERROR'
    }
  ]
};

// Configuration fixtures
export const configFixtures = {
  server: {
    development: {
      port: 3001,
      env: 'development',
      logLevel: 'debug'
    },
    
    test: {
      port: 3001,
      env: 'test',
      logLevel: 'error'
    },
    
    production: {
      port: 3000,
      env: 'production',
      logLevel: 'info'
    }
  },
  
  database: {
    test: {
      url: 'postgresql://test:test@localhost:5432/test_db',
      pool: {
        min: 2,
        max: 10
      }
    }
  },
  
  jwt: {
    test: {
      secret: 'test-jwt-secret',
      expiresIn: '15m',
      algorithm: 'HS256'
    }
  },
  
  aws: {
    test: {
      region: 'us-east-1',
      accessKeyId: 'test-access-key',
      secretAccessKey: 'test-secret-key'
    }
  }
};

// Performance test fixtures
export const performanceFixtures = {
  largeUserList: Array.from({ length: 1000 }, (_, i) => ({
    id: `user-${i}`,
    email: `user${i}@example.com`,
    role: 'user',
    created_at: new Date(2024, 0, 1),
    updated_at: new Date(2024, 0, 1)
  })),
  
  heavyPayload: {
    data: Array.from({ length: 100 }, (_, i) => ({
      id: i,
      name: `Item ${i}`,
      description: 'x'.repeat(1000) // 1KB description
    }))
  }
};

// Utility function to load fixtures
export const loadFixtures = (fixtureName: string) => {
  const fixtures: Record<string, any> = {
    user: userFixtures,
    session: sessionFixtures,
    request: requestFixtures,
    query: queryFixtures,
    error: errorFixtures,
    config: configFixtures,
    performance: performanceFixtures
  };
  
  const [category, name] = fixtureName.split('.');
  
  if (fixtures[category] && fixtures[category][name]) {
    return fixtures[category][name];
  }
  
  if (fixtures[category]) {
    return fixtures[category];
  }
  
  throw new Error(`Fixture not found: ${fixtureName}`);
};

// Export all fixtures
export default {
  user: userFixtures,
  session: sessionFixtures,
  request: requestFixtures,
  query: queryFixtures,
  error: errorFixtures,
  config: configFixtures,
  performance: performanceFixtures,
  loadFixtures
};
