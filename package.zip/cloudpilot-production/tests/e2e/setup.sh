#!/bin/bash

# E2E Test Environment Setup Script
# This script sets up the Playwright E2E testing environment

set -e

echo "🚀 Setting up E2E Testing Environment"
echo "======================================"

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: package.json not found. Please run this script from the project root."
    exit 1
fi

# Install Playwright if not already installed
if ! npm list @playwright/test &> /dev/null; then
    echo "📦 Installing Playwright..."
    npm install --save-dev @playwright/test
else
    echo "✅ Playwright is already installed"
fi

# Install Playwright browsers
echo "🌐 Installing Playwright browsers..."
npx playwright install

# Create test directories
echo "📁 Creating test directories..."
mkdir -p tests/e2e/screenshots
mkdir -p tests/e2e/videos
mkdir -p tests/e2e/traces

# Check if application is running
echo ""
echo "🔍 Checking if application is running..."

if curl -s http://localhost:5173 > /dev/null; then
    echo "✅ Application is running on http://localhost:5173"
else
    echo "⚠️  Application is not running. Please start it with:"
    echo "   npm run dev"
    echo ""
fi

# Run a quick test to verify setup
echo ""
echo "🧪 Running a quick setup verification..."

# Create a simple test file for verification
cat > tests/e2e/setup-verification.spec.ts << 'EOF'
import { test, expect } from '@playwright/test';

test('setup verification - page loads', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('h1, h2, title')).toBeVisible();
});
EOF

# Run the verification test
npx playwright test tests/e2e/setup-verification.spec.ts --project=chromium --reporter=list

# Remove the verification test file
rm tests/e2e/setup-verification.spec.ts

echo ""
echo "✅ E2E Testing Environment Setup Complete!"
echo ""
echo "📋 Next Steps:"
echo "  1. Make sure your application is running: npm run dev"
echo "  2. Run all E2E tests: npm run test:e2e"
echo "  3. Run tests with UI: npm run test:e2e:ui"
echo "  4. View test report: npx playwright show-report"
echo ""
echo "📚 Documentation: tests/e2e/README.md"
echo ""
