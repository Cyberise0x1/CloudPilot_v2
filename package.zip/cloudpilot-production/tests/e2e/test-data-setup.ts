/**
 * Test Data Setup and Cleanup Utilities
 * Handles database operations and test environment preparation
 */

import { request } from '@playwright/test';

/**
 * Test environment configuration
 */
export const testConfig = {
  baseURL: process.env.BASE_URL || 'http://localhost:5173',
  apiURL: process.env.API_URL || 'http://localhost:5173/api',
  timeout: 30000,
};

/**
 * Database test data manager
 */
export class TestDataManager {
  private createdUsers: string[] = [];
  private createdAWSAccounts: string[] = [];
  private createdInstances: string[] = [];
  private createdBuckets: string[] = [];
  private createdDBInstances: string[] = [];
  private createdAlerts: string[] = [];

  /**
   * Clean up all test data
   */
  async cleanupAll(): Promise<void> {
    console.log('🧹 Cleaning up test data...');

    // Clean up in reverse order of dependencies
    await this.cleanupAlerts();
    await this.cleanupDBInstances();
    await this.cleanupInstances();
    await this.cleanupBuckets();
    await this.cleanupAWSAccounts();
    await this.cleanupUsers();

    console.log('✅ Test data cleanup completed');
  }

  /**
   * Register test user
   */
  async createTestUser(email?: string, password?: string): Promise<any> {
    const userEmail = email || `test_${Date.now()}@example.com`;
    const userPassword = password || 'TestPassword123!';
    
    try {
      const response = await request.newContext({
        baseURL: testConfig.apiURL,
      }).post('/auth/register', {
        data: {
          email: userEmail,
          password: userPassword,
          fullName: 'Test User',
        },
      });

      if (response.ok()) {
        const data = await response.json();
        this.createdUsers.push(userEmail);
        console.log(`✅ Created test user: ${userEmail}`);
        return data;
      } else {
        // User might already exist, try to login
        console.log(`⚠️ User ${userEmail} might already exist`);
        const loginResponse = await request.newContext({
          baseURL: testConfig.apiURL,
        }).post('/auth/login', {
          data: {
            email: userEmail,
            password: userPassword,
          },
        });
        
        if (loginResponse.ok()) {
          this.createdUsers.push(userEmail);
          return await loginResponse.json();
        }
      }
    } catch (error) {
      console.error('❌ Failed to create test user:', error);
      throw error;
    }
  }

  /**
   * Clean up test users
   */
  private async cleanupUsers(): Promise<void> {
    for (const email of this.createdUsers) {
      try {
        // Note: This would require a DELETE /auth/user endpoint
        // For now, we just log the cleanup
        console.log(`🗑️ Would clean up user: ${email}`);
      } catch (error) {
        console.error(`❌ Failed to cleanup user ${email}:`, error);
      }
    }
    this.createdUsers = [];
  }

  /**
   * Create test AWS account
   */
  async createTestAWSAccount(accessToken?: string): Promise<any> {
    const testAccount = {
      accountName: `Test AWS Account ${Date.now()}`,
      accessKeyId: 'AKIAIOSFODNN7EXAMPLE',
      secretAccessKey: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
      region: 'us-east-1',
    };

    try {
      const response = await request.newContext({
        baseURL: testConfig.apiURL,
        extraHTTPHeaders: {
          'Authorization': `Bearer ${accessToken}`,
        },
      }).post('/aws-accounts', {
        data: testAccount,
      });

      if (response.ok()) {
        const data = await response.json();
        this.createdAWSAccounts.push(data.id);
        console.log(`✅ Created test AWS account: ${data.id}`);
        return data;
      } else {
        console.log('⚠️ Failed to create AWS account');
        return null;
      }
    } catch (error) {
      console.error('❌ Failed to create test AWS account:', error);
      throw error;
    }
  }

  /**
   * Clean up AWS accounts
   */
  private async cleanupAWSAccounts(): Promise<void> {
    for (const accountId of this.createdAWSAccounts) {
      try {
        console.log(`🗑️ Would clean up AWS account: ${accountId}`);
        // Note: This would require DELETE /aws-accounts/:id endpoint
      } catch (error) {
        console.error(`❌ Failed to cleanup AWS account ${accountId}:`, error);
      }
    }
    this.createdAWSAccounts = [];
  }

  /**
   * Create test EC2 instance
   */
  async createTestEC2Instance(accountId: string, accessToken?: string): Promise<any> {
    const testInstance = {
      accountId,
      name: `Test Instance ${Date.now()}`,
      imageId: 'ami-0c55b159cbfafe1d0',
      instanceType: 't2.micro',
      region: 'us-east-1',
    };

    try {
      const response = await request.newContext({
        baseURL: testConfig.apiURL,
        extraHTTPHeaders: {
          'Authorization': `Bearer ${accessToken}`,
        },
      }).post('/aws/instances/launch', {
        data: testInstance,
      });

      if (response.ok()) {
        const data = await response.json();
        this.createdInstances.push(data.instanceId);
        console.log(`✅ Created test EC2 instance: ${data.instanceId}`);
        return data;
      } else {
        console.log('⚠️ Failed to create EC2 instance');
        return null;
      }
    } catch (error) {
      console.error('❌ Failed to create test EC2 instance:', error);
      throw error;
    }
  }

  /**
   * Clean up EC2 instances
   */
  private async cleanupInstances(): Promise<void> {
    for (const instanceId of this.createdInstances) {
      try {
        console.log(`🗑️ Would clean up EC2 instance: ${instanceId}`);
        // Note: This would require POST /aws/instances/terminate
      } catch (error) {
        console.error(`❌ Failed to cleanup EC2 instance ${instanceId}:`, error);
      }
    }
    this.createdInstances = [];
  }

  /**
   * Create test S3 bucket
   */
  async createTestS3Bucket(accountId: string, accessToken?: string): Promise<any> {
    const testBucket = {
      accountId,
      bucketName: `test-bucket-${Date.now()}`,
      region: 'us-east-1',
    };

    try {
      const response = await request.newContext({
        baseURL: testConfig.apiURL,
        extraHTTPHeaders: {
          'Authorization': `Bearer ${accessToken}`,
        },
      }).post('/aws/s3/buckets', {
        data: testBucket,
      });

      if (response.ok()) {
        const data = await response.json();
        this.createdBuckets.push(testBucket.bucketName);
        console.log(`✅ Created test S3 bucket: ${testBucket.bucketName}`);
        return data;
      } else {
        console.log('⚠️ Failed to create S3 bucket');
        return null;
      }
    } catch (error) {
      console.error('❌ Failed to create test S3 bucket:', error);
      throw error;
    }
  }

  /**
   * Clean up S3 buckets
   */
  private async cleanupBuckets(): Promise<void> {
    for (const bucketName of this.createdBuckets) {
      try {
        console.log(`🗑️ Would clean up S3 bucket: ${bucketName}`);
        // Note: This would require DELETE /aws/s3/buckets/:name
      } catch (error) {
        console.error(`❌ Failed to cleanup S3 bucket ${bucketName}:`, error);
      }
    }
    this.createdBuckets = [];
  }

  /**
   * Create test RDS instance
   */
  async createTestRDSInstance(accountId: string, accessToken?: string): Promise<any> {
    const testDB = {
      accountId,
      dbInstanceIdentifier: `test-db-${Date.now()}`,
      dbInstanceClass: 'db.t3.micro',
      engine: 'mysql',
      engineVersion: '8.0.35',
      masterUsername: 'admin',
      masterPassword: 'TestPassword123!',
      allocatedStorage: 20,
      region: 'us-east-1',
    };

    try {
      const response = await request.newContext({
        baseURL: testConfig.apiURL,
        extraHTTPHeaders: {
          'Authorization': `Bearer ${accessToken}`,
        },
      }).post('/aws/rds', {
        data: testDB,
      });

      if (response.ok()) {
        const data = await response.json();
        this.createdDBInstances.push(testDB.dbInstanceIdentifier);
        console.log(`✅ Created test RDS instance: ${testDB.dbInstanceIdentifier}`);
        return data;
      } else {
        console.log('⚠️ Failed to create RDS instance');
        return null;
      }
    } catch (error) {
      console.error('❌ Failed to create test RDS instance:', error);
      throw error;
    }
  }

  /**
   * Clean up RDS instances
   */
  private async cleanupDBInstances(): Promise<void> {
    for (const dbInstanceId of this.createdDBInstances) {
      try {
        console.log(`🗑️ Would clean up RDS instance: ${dbInstanceId}`);
        // Note: This would require DELETE /aws/rds/:id
      } catch (error) {
        console.error(`❌ Failed to cleanup RDS instance ${dbInstanceId}:`, error);
      }
    }
    this.createdDBInstances = [];
  }

  /**
   * Create test alert
   */
  async createTestAlert(accessToken?: string): Promise<any> {
    const testAlert = {
      name: `Test Alert ${Date.now()}`,
      description: 'Test alert for E2E testing',
      condition: 'cpu_usage',
      threshold: 80,
      severity: 'high',
    };

    try {
      const response = await request.newContext({
        baseURL: testConfig.apiURL,
        extraHTTPHeaders: {
          'Authorization': `Bearer ${accessToken}`,
        },
      }).post('/monitoring/alerts', {
        data: testAlert,
      });

      if (response.ok()) {
        const data = await response.json();
        this.createdAlerts.push(data.id);
        console.log(`✅ Created test alert: ${data.id}`);
        return data;
      } else {
        console.log('⚠️ Failed to create alert');
        return null;
      }
    } catch (error) {
      console.error('❌ Failed to create test alert:', error);
      throw error;
    }
  }

  /**
   * Clean up alerts
   */
  private async cleanupAlerts(): Promise<void> {
    for (const alertId of this.createdAlerts) {
      try {
        console.log(`🗑️ Would clean up alert: ${alertId}`);
        // Note: This would require DELETE /monitoring/alerts/:id
      } catch (error) {
        console.error(`❌ Failed to cleanup alert ${alertId}:`, error);
      }
    }
    this.createdAlerts = [];
  }

  /**
   * Get summary of created test data
   */
  getTestDataSummary(): object {
    return {
      users: this.createdUsers.length,
      awsAccounts: this.createdAWSAccounts.length,
      instances: this.createdInstances.length,
      buckets: this.createdBuckets.length,
      dbInstances: this.createdDBInstances.length,
      alerts: this.createdAlerts.length,
    };
  }
}

/**
 * Global test data manager instance
 */
export const testDataManager = new TestDataManager();

/**
 * Environment setup functions
 */
export const testEnvironment = {
  /**
   * Set up test environment before all tests
   */
  async setup(): Promise<void> {
    console.log('🚀 Setting up test environment...');
    
    // Wait for services to be ready
    await this.waitForServices();
    
    console.log('✅ Test environment setup completed');
  },

  /**
   * Clean up test environment after all tests
   */
  async teardown(): Promise<void> {
    console.log('🧹 Tearing down test environment...');
    
    // Clean up all test data
    await testDataManager.cleanupAll();
    
    console.log('✅ Test environment teardown completed');
  },

  /**
   * Wait for services to be ready
   */
  async waitForServices(): Promise<void> {
    const maxRetries = 30;
    const retryDelay = 2000;

    for (let i = 0; i < maxRetries; i++) {
      try {
        const response = await request.newContext().get(testConfig.baseURL);
        if (response.ok()) {
          console.log('✅ Services are ready');
          return;
        }
      } catch (error) {
        // Service not ready yet
      }

      console.log(`⏳ Waiting for services... (${i + 1}/${maxRetries})`);
      await new Promise(resolve => setTimeout(resolve, retryDelay));
    }

    throw new Error('Services did not become ready in time');
  },

  /**
   * Reset test database (if applicable)
   */
  async resetDatabase(): Promise<void> {
    console.log('🗄️ Resetting test database...');
    
    try {
      // This would typically call a test-only endpoint to reset the database
      const response = await request.newContext({
        baseURL: testConfig.apiURL,
      }).post('/test/reset-database');

      if (response.ok()) {
        console.log('✅ Database reset completed');
      } else {
        console.log('⚠️ Database reset endpoint not available');
      }
    } catch (error) {
      console.log('⚠️ Database reset failed or not available:', error);
    }
  },

  /**
   * Seed test data
   */
  async seedTestData(): Promise<void> {
    console.log('🌱 Seeding test data...');
    
    try {
      // This would typically call a test-only endpoint to seed data
      const response = await request.newContext({
        baseURL: testConfig.apiURL,
      }).post('/test/seed-data');

      if (response.ok()) {
        console.log('✅ Test data seeded');
      } else {
        console.log('⚠️ Test data seeding endpoint not available');
      }
    } catch (error) {
      console.log('⚠️ Test data seeding failed or not available:', error);
    }
  },
};
