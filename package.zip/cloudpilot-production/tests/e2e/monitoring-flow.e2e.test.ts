import { test, expect } from '@playwright/test';
import { 
  login, 
  logout, 
  testData, 
  generateUniqueTestData,
  waitForLoading,
  checkForJSErrors,
  takeScreenshot,
  setupTestEnvironment,
  teardownTestEnvironment,
  navigateToMonitoring,
  registerUser
} from './test-utils';

test.describe('Monitoring Dashboard Flow', () => {
  let testUserEmail: string;
  let testUserPassword: string;

  test.beforeEach(async ({ page }) => {
    await setupTestEnvironment(page);
    
    // Create unique test user
    const uniqueData = generateUniqueTestData('monitoring');
    testUserEmail = uniqueData.email;
    testUserPassword = testData.user.password;
    
    // Login before each test
    try {
      await registerUser(page, testUserEmail, testUserPassword, 'Monitoring Test User');
    } catch (e) {
      await login(page, testUserEmail, testUserPassword);
    }
    
    // Check for JavaScript errors
    const errors = await checkForJSErrors(page);
    expect(errors).toHaveLength(0);
  });

  test.afterEach(async ({ page }) => {
    await teardownTestEnvironment(page);
  });

  test.describe('Monitoring Dashboard Access', () => {
    test('should access monitoring dashboard successfully', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'MON001 - Access monitoring dashboard',
      });

      await test.step('Navigate to monitoring dashboard', async () => {
        await navigateToMonitoring(page);
        await takeScreenshot(page, 'monitoring-dashboard-landing');
      });

      await test.step('Verify dashboard components are visible', async () => {
        // Check for main dashboard elements
        const dashboardElements = [
          'h1, h2',
          '[data-testid="dashboard"], .dashboard',
          '[data-testid="metrics"], .metrics',
          '[data-testid="charts"], .charts',
        ];
        
        for (const element of dashboardElements) {
          await expect(page.locator(element)).toBeVisible({ timeout: 5000 });
        }
        
        await takeScreenshot(page, 'monitoring-dashboard-components');
      });

      await test.step('Verify system status overview', async () => {
        const statusOverview = page.locator('[data-testid="system-status"], .status-overview, .health-status');
        await expect(statusOverview).toBeVisible({ timeout: 5000 });
        
        await takeScreenshot(page, 'monitoring-status-overview');
        
        // Check for status indicators
        const statusIndicators = page.locator('.status-indicator, .health-indicator, [data-testid="status"]');
        await expect(statusIndicators.first()).toBeVisible();
      });
    });

    test('should display real-time system metrics', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'MON002 - Real-time system metrics',
      });

      await test.step('Navigate to monitoring dashboard', async () => {
        await navigateToMonitoring(page);
        await waitForLoading(page);
      });

      await test.step('Verify CPU usage metrics', async () => {
        const cpuMetrics = page.locator('[data-testid="cpu"], .cpu-metrics, .cpu-usage');
        await expect(cpuMetrics).toBeVisible({ timeout: 10000 });
        
        await takeScreenshot(page, 'monitoring-cpu-metrics');
        
        // Check for numerical values or charts
        const cpuValues = page.locator('.metric-value, .cpu-value, [data-value]');
        if (await cpuValues.first().isVisible()) {
          const hasValues = await cpuValues.first().textContent();
          expect(hasValues).toBeTruthy();
        }
      });

      await test.step('Verify memory usage metrics', async () => {
        const memoryMetrics = page.locator('[data-testid="memory"], .memory-metrics, .memory-usage');
        await expect(memoryMetrics).toBeVisible({ timeout: 5000 });
        
        await takeScreenshot(page, 'monitoring-memory-metrics');
      });

      await test.step('Verify network metrics', async () => {
        const networkMetrics = page.locator('[data-testid="network"], .network-metrics, .network-usage');
        await expect(networkMetrics).toBeVisible({ timeout: 5000 });
        
        await takeScreenshot(page, 'monitoring-network-metrics');
      });

      await test.step('Verify disk usage metrics', async () => {
        const diskMetrics = page.locator('[data-testid="disk"], .disk-metrics, .disk-usage');
        await expect(diskMetrics).toBeVisible({ timeout: 5000 });
        
        await takeScreenshot(page, 'monitoring-disk-metrics');
      });
    });

    test('should display performance trends and charts', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'MON003 - Performance trends and charts',
      });

      await test.step('Navigate to monitoring dashboard', async () => {
        await navigateToMonitoring(page);
        await waitForLoading(page);
      });

      await test.step('Verify performance trends section', async () => {
        const trendsSection = page.locator('[data-testid="trends"], .trends, .performance-trends');
        await expect(trendsSection).toBeVisible({ timeout: 10000 });
        
        await takeScreenshot(page, 'monitoring-trends-section');
      });

      await test.step('Verify response time charts', async () => {
        const responseTimeChart = page.locator('[data-testid="response-time"], .response-time-chart');
        await expect(responseTimeChart).toBeVisible({ timeout: 5000 });
        
        await takeScreenshot(page, 'monitoring-response-time-chart');
      });

      await test.step('Verify throughput metrics', async () => {
        const throughputChart = page.locator('[data-testid="throughput"], .throughput-chart');
        await expect(throughputChart).toBeVisible({ timeout: 5000 });
        
        await takeScreenshot(page, 'monitoring-throughput-chart');
      });

      await test.step('Verify error rate tracking', async () => {
        const errorRateChart = page.locator('[data-testid="error-rate"], .error-rate-chart');
        await expect(errorRateChart).toBeVisible({ timeout: 5000 });
        
        await takeScreenshot(page, 'monitoring-error-rate-chart');
      });
    });
  });

  test.describe('Alert Management', () => {
    test('should view active alerts', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'MON004 - View active alerts',
      });

      await test.step('Navigate to monitoring dashboard', async () => {
        await navigateToMonitoring(page);
        await waitForLoading(page);
      });

      await test.step('Find alerts section', async () => {
        const alertsSection = page.locator('[data-testid="alerts"], .alerts, .alert-panel');
        await expect(alertsSection).toBeVisible({ timeout: 10000 });
        
        await takeScreenshot(page, 'monitoring-alerts-section');
      });

      await test.step('Verify active alerts display', async () => {
        const activeAlerts = page.locator('.alert-item, [data-testid="alert"], .active-alert');
        
        // Check if alerts are visible (may be empty)
        const hasAlerts = await activeAlerts.first().isVisible().catch(() => false);
        
        if (hasAlerts) {
          await takeScreenshot(page, 'monitoring-active-alerts');
          
          // Verify alert structure
          const alertSeverity = page.locator('.alert-severity, .severity');
          if (await alertSeverity.first().isVisible()) {
            const severity = await alertSeverity.first().textContent();
            expect(severity).toMatch(/low|medium|high|critical/i);
          }
        } else {
          await takeScreenshot(page, 'monitoring-no-alerts');
          // It's acceptable to have no alerts
        }
      });
    });

    test('should create new alert', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'MON005 - Create new alert',
      });

      await test.step('Navigate to alerts management', async () => {
        await navigateToMonitoring(page);
        
        // Look for alert management section
        const alertsLink = page.locator('a:has-text("Alerts"), [data-testid="alerts-tab"]');
        if (await alertsLink.isVisible()) {
          await alertsLink.click();
          await waitForLoading(page);
        }
      });

      await test.step('Click Create Alert button', async () => {
        const createAlertButton = page.locator('button:has-text("Create Alert"), button:has-text("New Alert")');
        await createAlertButton.waitFor({ state: 'visible', timeout: 10000 });
        await createAlertButton.click();
        
        await waitForLoading(page);
        await takeScreenshot(page, 'create-alert-modal');
      });

      await test.step('Fill alert creation form', async () => {
        const formFields = {
          name: testData.alert.name,
          description: testData.alert.description,
          threshold: testData.alert.threshold.toString(),
        };

        // Fill form fields (adapt based on actual implementation)
        const nameInput = page.locator('input[name="name"], input[id="name"]');
        const descriptionInput = page.locator('input[name="description"], textarea[name="description"]');
        const thresholdInput = page.locator('input[name="threshold"], input[id="threshold"]');
        
        await nameInput.fill(formFields.name);
        await descriptionInput.fill(formFields.description);
        await thresholdInput.fill(formFields.threshold);
        
        // Select severity
        const severitySelect = page.locator('select[name="severity"], select[id="severity"]');
        await severitySelect.selectOption(testData.alert.severity);
        
        await takeScreenshot(page, 'alert-form-filled');
      });

      await test.step('Submit alert creation', async () => {
        const submitButton = page.locator('button[type="submit"], button:has-text("Create"), button:has-text("Save")');
        await submitButton.click();
        
        await waitForLoading(page);
      });

      await test.step('Verify alert created successfully', async () => {
        await takeScreenshot(page, 'alert-created-success');
        
        // Check for success message
        const successMessage = page.locator('.success, .alert-success, [role="status"]');
        if (await successMessage.isVisible()) {
          await expect(successMessage).toContainText(/created|alert/i);
        }
        
        // Verify alert appears in list
        const alertsList = page.locator('.alerts-list, [data-testid="alerts-list"]');
        await expect(alertsList).toBeVisible();
      });
    });

    test('should acknowledge active alert', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'MON006 - Acknowledge alert',
      });

      await test.step('Navigate to alerts section', async () => {
        await navigateToMonitoring(page);
        
        const alertsLink = page.locator('a:has-text("Alerts")');
        if (await alertsLink.isVisible()) {
          await alertsLink.click();
          await waitForLoading(page);
        }
        
        await takeScreenshot(page, 'alerts-list-before-ack');
      });

      await test.step('Find alert to acknowledge', async () => {
        const alerts = page.locator('.alert-item, [data-testid="alert"]');
        if (await alerts.first().isVisible()) {
          // Find acknowledge button
          const ackButton = alerts.first().locator('button:has-text("Acknowledge"), button:has-text("Ack")');
          if (await ackButton.isVisible()) {
            await ackButton.click();
            await waitForLoading(page);
            
            await takeScreenshot(page, 'alert-acknowledged');
            
            // Verify alert status changed
            const acknowledgedStatus = alerts.first().locator('.status, [data-status="acknowledged"]');
            if (await acknowledgedStatus.isVisible()) {
              const status = await acknowledgedStatus.textContent();
              expect(status).toMatch(/acknowledge|acknowledged/i);
            }
          }
        }
      });
    });

    test('should resolve alert', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'MON007 - Resolve alert',
      });

      await test.step('Navigate to alerts section', async () => {
        await navigateToMonitoring(page);
        
        const alertsLink = page.locator('a:has-text("Alerts")');
        if (await alertsLink.isVisible()) {
          await alertsLink.click();
          await waitForLoading(page);
        }
        
        await takeScreenshot(page, 'alerts-list-before-resolve');
      });

      await test.step('Find alert to resolve', async () => {
        const alerts = page.locator('.alert-item, [data-testid="alert"]');
        if (await alerts.first().isVisible()) {
          // Find resolve button
          const resolveButton = alerts.first().locator('button:has-text("Resolve"), button:has-text("Close")');
          if (await resolveButton.isVisible()) {
            await resolveButton.click();
            await waitForLoading(page);
            
            // Handle confirmation if present
            page.on('dialog', dialog => dialog.accept());
            
            await takeScreenshot(page, 'alert-resolved');
            
            // Verify alert is removed or status changed
            const resolvedAlerts = page.locator('.alert-item.resolved, [data-status="resolved"]');
            const hasResolvedAlerts = await resolvedAlerts.isVisible().catch(() => false);
            
            if (!hasResolvedAlerts) {
              // Alert might be removed from active list
              console.log('Alert resolved - removed from active list');
            }
          }
        }
      });
    });
  });

  test.describe('System Health Overview', () => {
    test('should display system health status', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'MON008 - System health status',
      });

      await test.step('Navigate to monitoring dashboard', async () => {
        await navigateToMonitoring(page);
        await waitForLoading(page);
      });

      await test.step('Verify health overview section', async () => {
        const healthOverview = page.locator('[data-testid="health-overview"], .health-overview, .system-health');
        await expect(healthOverview).toBeVisible({ timeout: 10000 });
        
        await takeScreenshot(page, 'monitoring-health-overview');
      });

      await test.step('Verify overall system status', async () => {
        const systemStatus = page.locator('[data-testid="system-status"], .system-status, .overall-status');
        await expect(systemStatus).toBeVisible({ timeout: 5000 });
        
        await takeScreenshot(page, 'monitoring-system-status');
        
        // Check for status indicators (healthy/degraded/critical)
        const statusText = await systemStatus.textContent();
        if (statusText) {
          expect(statusText).toMatch(/healthy|degraded|critical|unknown/i);
        }
      });

      await test.step('Verify component health status', async () => {
        const componentsHealth = page.locator('[data-testid="components"], .components, .component-health');
        await expect(componentsHealth).toBeVisible({ timeout: 5000 });
        
        await takeScreenshot(page, 'monitoring-components-health');
        
        // Verify individual components are listed
        const componentItems = page.locator('.component-item, .service-item');
        const hasComponents = await componentItems.first().isVisible().catch(() => false);
        
        if (hasComponents) {
          const componentStatus = componentItems.first().locator('.status, .health');
          if (await componentStatus.isVisible()) {
            const status = await componentStatus.textContent();
            expect(status).toMatch(/healthy|degraded|critical/i);
          }
        }
      });
    });

    test('should display uptime metrics', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'MON009 - Uptime metrics',
      });

      await test.step('Navigate to monitoring dashboard', async () => {
        await navigateToMonitoring(page);
        await waitForLoading(page);
      });

      await test.step('Verify uptime display', async () => {
        const uptimeSection = page.locator('[data-testid="uptime"], .uptime, .availability');
        await expect(uptimeSection).toBeVisible({ timeout: 10000 });
        
        await takeScreenshot(page, 'monitoring-uptime-metrics');
        
        // Check for percentage or time value
        const uptimeValue = page.locator('.uptime-value, .availability-percentage, [data-value]');
        if (await uptimeValue.first().isVisible()) {
          const value = await uptimeValue.first().textContent();
          expect(value).toBeTruthy();
          
          // Should contain percentage or time format
          expect(value).toMatch(/\d+%|\d+[dhm]/i);
        }
      });
    });
  });

  test.describe('Error Tracking and Analysis', () => {
    test('should display error logs', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'MON010 - Error logs display',
      });

      await test.step('Navigate to monitoring dashboard', async () => {
        await navigateToMonitoring(page);
        await waitForLoading(page);
      });

      await test.step('Find error logs section', async () => {
        const errorLogsLink = page.locator('a:has-text("Errors"), [data-testid="errors-tab"]');
        if (await errorLogsLink.isVisible()) {
          await errorLogsLink.click();
          await waitForLoading(page);
        }
        
        const errorLogsSection = page.locator('[data-testid="error-logs"], .error-logs, .logs');
        await expect(errorLogsSection).toBeVisible({ timeout: 10000 });
        
        await takeScreenshot(page, 'monitoring-error-logs');
      });

      await test.step('Verify error log entries', async () => {
        const errorEntries = page.locator('.log-entry, .error-entry, .log-item');
        
        const hasErrorEntries = await errorEntries.first().isVisible().catch(() => false);
        
        if (hasErrorEntries) {
          await takeScreenshot(page, 'monitoring-error-entries');
          
          // Verify error structure
          const errorLevel = errorEntries.first().locator('.level, .severity');
          if (await errorLevel.first().isVisible()) {
            const level = await errorLevel.first().textContent();
            expect(level).toMatch(/error|warning|info|debug/i);
          }
        } else {
          await takeScreenshot(page, 'monitoring-no-errors');
          // It's acceptable to have no errors
        }
      });
    });

    test('should analyze error patterns', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'MON011 - Error pattern analysis',
      });

      await test.step('Navigate to error analysis section', async () => {
        await navigateToMonitoring(page);
        
        const analysisLink = page.locator('a:has-text("Error Analysis"), [data-testid="analysis-tab"]');
        if (await analysisLink.isVisible()) {
          await analysisLink.click();
          await waitForLoading(page);
        }
        
        await takeScreenshot(page, 'monitoring-error-analysis');
      });

      await test.step('Verify error analysis charts', async () => {
        const errorCharts = page.locator('.chart, [data-testid="chart"], .error-chart');
        
        const hasCharts = await errorCharts.first().isVisible().catch(() => false);
        
        if (hasCharts) {
          await takeScreenshot(page, 'monitoring-error-charts');
          
          // Verify chart has data or placeholder
          const chartTitle = errorCharts.first().locator('h3, .title');
          if (await chartTitle.first().isVisible()) {
            const title = await chartTitle.first().textContent();
            expect(title).toBeTruthy();
          }
        } else {
          await takeScreenshot(page, 'monitoring-no-error-analysis');
        }
      });
    });
  });

  test.describe('Monitoring Dashboard Usage', () => {
    test('should refresh dashboard data', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'MON012 - Dashboard data refresh',
      });

      await test.step('Navigate to monitoring dashboard', async () => {
        await navigateToMonitoring(page);
        await waitForLoading(page);
        await takeScreenshot(page, 'monitoring-before-refresh');
      });

      await test.step('Click refresh button', async () => {
        const refreshButton = page.locator('button:has-text("Refresh"), button:has-text("Sync"), [data-testid="refresh"]');
        await refreshButton.waitFor({ state: 'visible', timeout: 10000 });
        await refreshButton.click();
        
        await waitForLoading(page);
      });

      await test.step('Verify dashboard updated', async () => {
        await takeScreenshot(page, 'monitoring-after-refresh');
        
        // Verify loading state or updated timestamps
        const lastUpdated = page.locator('.last-updated, .updated-at, [data-updated]');
        if (await lastUpdated.first().isVisible()) {
          const timestamp = await lastUpdated.first().textContent();
          expect(timestamp).toBeTruthy();
        }
      });
    });

    test('should filter monitoring data by time range', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'MON013 - Time range filtering',
      });

      await test.step('Navigate to monitoring dashboard', async () => {
        await navigateToMonitoring(page);
        await waitForLoading(page);
      });

      await test.step('Find time range selector', async () => {
        const timeRangeSelector = page.locator('select[name="timeRange"], .time-range-selector, [data-testid="time-range"]');
        await timeRangeSelector.waitFor({ state: 'visible', timeout: 10000 });
        
        await takeScreenshot(page, 'monitoring-time-selector');
      });

      await test.step('Select different time range', async () => {
        // Select different time range option
        const options = page.locator('select[name="timeRange"] option');
        const optionCount = await options.count();
        
        if (optionCount > 1) {
          await options.last().click();
          await waitForLoading(page);
          
          await takeScreenshot(page, 'monitoring-time-range-changed');
          
          // Verify data updated based on time range
          const chartData = page.locator('.chart, .metrics-data');
          await expect(chartData.first()).toBeVisible();
        }
      });
    });

    test('should export monitoring data', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'MON014 - Export monitoring data',
      });

      await test.step('Navigate to monitoring dashboard', async () => {
        await navigateToMonitoring(page);
        await waitForLoading(page);
      });

      await test.step('Find export functionality', async () => {
        const exportButton = page.locator('button:has-text("Export"), [data-testid="export"]');
        await exportButton.waitFor({ state: 'visible', timeout: 10000 });
        
        await takeScreenshot(page, 'monitoring-export-button');
      });

      await test.step('Click export button', async () => {
        await exportButton.click();
        await waitForLoading(page);
        
        await takeScreenshot(page, 'monitoring-export-dialog');
        
        // Check if export dialog/modal appears
        const exportDialog = page.locator('.export-dialog, .modal, [data-testid="export-modal"]');
        await expect(exportDialog).toBeVisible({ timeout: 5000 });
        
        // Select export format if options are available
        const formatSelect = exportDialog.locator('select[name="format"]');
        if (await formatSelect.isVisible()) {
          await formatSelect.selectOption('json');
        }
        
        // Click export/submit
        const exportSubmit = exportDialog.locator('button[type="submit"], button:has-text("Export")');
        await exportSubmit.click();
        
        await waitForLoading(page);
        await takeScreenshot(page, 'monitoring-export-completed');
      });
    });

    test('should navigate between monitoring sections', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'MON015 - Monitoring sections navigation',
      });

      await test.step('Navigate to monitoring dashboard', async () => {
        await navigateToMonitoring(page);
        await waitForLoading(page);
        await takeScreenshot(page, 'monitoring-nav-start');
      });

      await test.step('Navigate to metrics section', async () => {
        const metricsLink = page.locator('a:has-text("Metrics"), [data-testid="metrics-tab"]');
        if (await metricsLink.isVisible()) {
          await metricsLink.click();
          await waitForLoading(page);
          await takeScreenshot(page, 'monitoring-metrics-section');
        }
      });

      await test.step('Navigate to alerts section', async () => {
        const alertsLink = page.locator('a:has-text("Alerts"), [data-testid="alerts-tab"]');
        if (await alertsLink.isVisible()) {
          await alertsLink.click();
          await waitForLoading(page);
          await takeScreenshot(page, 'monitoring-alerts-section-nav');
        }
      });

      await test.step('Navigate to system health section', async () => {
        const healthLink = page.locator('a:has-text("Health"), [data-testid="health-tab"]');
        if (await healthLink.isVisible()) {
          await healthLink.click();
          await waitForLoading(page);
          await takeScreenshot(page, 'monitoring-health-section-nav');
        }
      });

      await test.step('Navigate to logs section', async () => {
        const logsLink = page.locator('a:has-text("Logs"), [data-testid="logs-tab"]');
        if (await logsLink.isVisible()) {
          await logsLink.click();
          await waitForLoading(page);
          await takeScreenshot(page, 'monitoring-logs-section-nav');
        }
      });

      await test.step('Return to main dashboard', async () => {
        const dashboardLink = page.locator('a:has-text("Dashboard"), [data-testid="dashboard-tab"]');
        if (await dashboardLink.isVisible()) {
          await dashboardLink.click();
          await waitForLoading(page);
          await takeScreenshot(page, 'monitoring-back-to-dashboard');
        }
      });
    });
  });
});
