import { Page, BrowserContext, expect } from '@playwright/test';

/**
 * Test data for E2E tests
 */
export const testData = {
  user: {
    email: 'testuser@example.com',
    password: 'TestPassword123!',
    fullName: 'Test User',
  },
  awsAccount: {
    accountName: 'Test AWS Account',
    accessKeyId: 'AKIAIOSFODNN7EXAMPLE',
    secretAccessKey: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
    region: 'us-east-1',
  },
  instance: {
    name: 'Test Instance',
    imageId: 'ami-0c55b159cbfafe1d0',
    instanceType: 't2.micro',
    keyName: 'test-key-pair',
    region: 'us-east-1',
  },
  s3Bucket: {
    name: `test-bucket-${Date.now()}`,
    region: 'us-east-1',
  },
  rdsInstance: {
    dbInstanceIdentifier: `test-db-${Date.now()}`,
    dbInstanceClass: 'db.t3.micro',
    engine: 'mysql',
    engineVersion: '8.0.35',
    masterUsername: 'admin',
    masterPassword: 'TestPassword123!',
    allocatedStorage: 20,
    region: 'us-east-1',
  },
  alert: {
    name: 'High CPU Usage Alert',
    description: 'Alert when CPU usage exceeds 80%',
    condition: 'cpu_usage',
    threshold: 80,
    severity: 'high' as const,
  },
};

/**
 * Generate unique test data
 */
export function generateUniqueTestData(prefix: string = 'test'): any {
  const timestamp = Date.now();
  return {
    email: `${prefix}.${timestamp}@example.com`,
    bucketName: `${prefix}-bucket-${timestamp}`,
    instanceName: `${prefix}-instance-${timestamp}`,
    dbIdentifier: `${prefix}-db-${timestamp}`,
  };
}

/**
 * Authentication utilities
 */
export async function login(
  page: Page,
  email: string = testData.user.email,
  password: string = testData.user.password
): Promise<void> {
  await page.goto('/login');
  
  await page.waitForSelector('input[type="email"]', { state: 'visible' });
  await page.fill('input[type="email"]', email);
  await page.fill('input[type="password"]', password);
  
  await page.click('button[type="submit"], button:has-text("Login"), button:has-text("Sign In")');
  
  // Wait for successful login
  await page.waitForURL('**/dashboard', { timeout: 10000 }).catch(() => {
    // If we're still on login page, check for error messages
    const errorVisible = page.locator('.error, .alert-error, [role="alert"]').isVisible();
    if (errorVisible) {
      throw new Error('Login failed - invalid credentials');
    }
  });
}

/**
 * Logout utility
 */
export async function logout(page: Page): Promise<void> {
  // Try to find logout button in various locations
  const logoutSelectors = [
    'button:has-text("Logout")',
    'button:has-text("Sign Out")',
    '[data-testid="logout"]',
    'a:has-text("Logout")',
    '.dropdown-menu button:has-text("Logout")',
    'button[aria-label="Logout"]',
  ];

  for (const selector of logoutSelectors) {
    try {
      if (await page.locator(selector).isVisible()) {
        await page.click(selector);
        break;
      }
    } catch (e) {
      // Continue to next selector
    }
  }

  // Wait for logout to complete
  await page.waitForURL('**/login', { timeout: 5000 }).catch(() => {
    // Check if we're redirected to home or login
    const currentUrl = page.url();
    if (!currentUrl.includes('/login') && !currentUrl.includes('/')) {
      throw new Error('Logout failed - not redirected to login page');
    }
  });
}

/**
 * Register a new user
 */
export async function registerUser(
  page: Page,
  email: string = testData.user.email,
  password: string = testData.user.password,
  fullName: string = testData.user.fullName
): Promise<void> {
  await page.goto('/register');
  
  await page.waitForSelector('input[name="email"]', { state: 'visible' });
  await page.fill('input[name="email"]', email);
  await page.fill('input[name="password"]', password);
  await page.fill('input[name="fullName"]', fullName);
  
  await page.click('button[type="submit"], button:has-text("Register")');
  
  // Wait for successful registration
  await page.waitForURL('**/dashboard', { timeout: 10000 }).catch(() => {
    const errorVisible = page.locator('.error, .alert-error, [role="alert"]').isVisible();
    if (errorVisible) {
      throw new Error('Registration failed');
    }
  });
}

/**
 * Navigate to AWS management section
 */
export async function navigateToAWSManagement(page: Page): Promise<void> {
  // Look for AWS management link
  const awsLinks = [
    'a:has-text("AWS")',
    'a:has-text("Cloud Management")',
    '[data-testid="aws-management"]',
    'nav a:has-text("AWS")',
  ];

  for (const link of awsLinks) {
    try {
      if (await page.locator(link).isVisible()) {
        await page.click(link);
        break;
      }
    } catch (e) {
      // Continue to next link
    }
  }

  await page.waitForSelector('h1, h2', { timeout: 5000 }).catch(() => {
    throw new Error('Failed to navigate to AWS management');
  });
}

/**
 * Navigate to monitoring dashboard
 */
export async function navigateToMonitoring(page: Page): Promise<void> {
  // Look for monitoring dashboard link
  const monitoringLinks = [
    'a:has-text("Monitoring")',
    'a:has-text("Dashboard")',
    '[data-testid="monitoring"]',
    'nav a:has-text("Monitoring")',
  ];

  for (const link of monitoringLinks) {
    try {
      if (await page.locator(link).isVisible()) {
        await page.click(link);
        break;
      }
    } catch (e) {
      // Continue to next link
    }
  }

  await page.waitForSelector('h1, h2', { timeout: 5000 }).catch(() => {
    throw new Error('Failed to navigate to monitoring dashboard');
  });
}

/**
 * Wait for loading to complete
 */
export async function waitForLoading(page: Page): Promise<void> {
  // Wait for loading spinners to disappear
  await page.waitForFunction(
    () => {
      const spinners = document.querySelectorAll('.spinner, .loading, [data-testid="loading"]');
      return spinners.length === 0 || Array.from(spinners).every(s => (s as HTMLElement).style.display === 'none');
    },
    { timeout: 10000 }
  );
}

/**
 * Check if element exists and is visible
 */
export async function checkElementVisible(page: Page, selector: string): Promise<boolean> {
  try {
    await page.waitForSelector(selector, { timeout: 5000 });
    return await page.locator(selector).isVisible();
  } catch (e) {
    return false;
  }
}

/**
 * Take a screenshot with descriptive name
 */
export async function takeScreenshot(
  page: Page,
  name: string,
  fullPage: boolean = true
): Promise<void> {
  await page.screenshot({
    path: `test-results/screenshots/${name}-${Date.now()}.png`,
    fullPage,
  });
}

/**
 * Fill form fields
 */
export async function fillForm(page: Page, formData: Record<string, string>): Promise<void> {
  for (const [field, value] of Object.entries(formData)) {
    const selector = `input[name="${field}"], input[id="${field}"], #${field}`;
    await page.fill(selector, value);
  }
}

/**
 * Click button by text
 */
export async function clickButtonByText(page: Page, text: string): Promise<void> {
  const button = page.locator(`button:has-text("${text}")`);
  await button.waitFor({ state: 'visible' });
  await button.click();
}

/**
 * Handle alerts
 */
export async function handleAlert(page: Page, accept: boolean = true): Promise<void> {
  page.on('dialog', async dialog => {
    if (accept) {
      await dialog.accept();
    } else {
      await dialog.dismiss();
    }
  });
}

/**
 * Check for JavaScript errors
 */
export async function checkForJSErrors(page: Page): Promise<string[]> {
  const errors: string[] = [];
  
  page.on('console', msg => {
    if (msg.type() === 'error') {
      errors.push(msg.text());
    }
  });

  page.on('pageerror', error => {
    errors.push(error.message);
  });

  // Wait a moment to capture any errors
  await page.waitForTimeout(1000);
  
  return errors;
}

/**
 * Wait for network requests to complete
 */
export async function waitForNetworkIdle(page: Page, timeout: number = 5000): Promise<void> {
  await page.waitForLoadState('networkidle', { timeout });
}

/**
 * Validate response status
 */
export async function validateResponse(
  page: Page,
  urlPattern: string | RegExp,
  expectedStatus: number
): Promise<boolean> {
  const response = await page.waitForResponse(response => {
    const url = response.url();
    const matches = typeof urlPattern === 'string' ? url.includes(urlPattern) : urlPattern.test(url);
    return matches;
  }, { timeout: 10000 });

  return response.status() === expectedStatus;
}

/**
 * Clean up test data
 */
export async function cleanupTestData(page: Page): Promise<void> {
  // This would typically make API calls to clean up test data
  // For now, just log out
  try {
    await logout(page);
  } catch (e) {
    // Ignore logout errors during cleanup
  }
}

/**
 * Retry helper for flaky operations
 */
export async function retryOperation<T>(
  operation: () => Promise<T>,
  maxRetries: number = 3,
  delay: number = 1000
): Promise<T> {
  let lastError: Error;
  
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await operation();
    } catch (e) {
      lastError = e as Error;
      if (i < maxRetries - 1) {
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }
  
  throw lastError!;
}

/**
 * Setup test environment
 */
export async function setupTestEnvironment(page: Page): Promise<void> {
  // Set up common test configurations
  await page.addInitScript(() => {
    // Disable animations for consistent testing
    const style = document.createElement('style');
    style.textContent = `
      *, *::before, *::after {
        animation-duration: 0s !important;
        animation-delay: 0s !important;
        transition-duration: 0s !important;
        transition-delay: 0s !important;
      }
    `;
    document.head.appendChild(style);
  });
}

/**
 * Teardown test environment
 */
export async function teardownTestEnvironment(page: Page): Promise<void> {
  // Clean up any test-specific data
  await page.evaluate(() => {
    // Clear localStorage
    localStorage.clear();
    // Clear sessionStorage
    sessionStorage.clear();
  });
}
