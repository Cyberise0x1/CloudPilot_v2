import { test, expect } from '@playwright/test';
import { 
  login, 
  logout, 
  testData, 
  generateUniqueTestData,
  waitForLoading,
  checkForJSErrors,
  takeScreenshot,
  setupTestEnvironment,
  teardownTestEnvironment,
  navigateToAWSManagement,
  registerUser
} from './test-utils';

test.describe('AWS Management Flow', () => {
  let testUserEmail: string;
  let testUserPassword: string;

  test.beforeEach(async ({ page }) => {
    await setupTestEnvironment(page);
    
    // Create unique test user
    const uniqueData = generateUniqueTestData('aws');
    testUserEmail = uniqueData.email;
    testUserPassword = testData.user.password;
    
    // Login before each test
    try {
      await registerUser(page, testUserEmail, testUserPassword, 'AWS Test User');
    } catch (e) {
      await login(page, testUserEmail, testUserPassword);
    }
    
    // Check for JavaScript errors
    const errors = await checkForJSErrors(page);
    expect(errors).toHaveLength(0);
  });

  test.afterEach(async ({ page }) => {
    await teardownTestEnvironment(page);
  });

  test.describe('AWS Account Management', () => {
    test('should connect AWS account successfully', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AWS001 - Connect AWS account',
      });

      await test.step('Navigate to AWS management', async () => {
        await navigateToAWSManagement(page);
        await takeScreenshot(page, 'aws-management-landing');
      });

      await test.step('Find and click Add AWS Account button', async () => {
        const addAccountButton = page.locator(
          'button:has-text("Add Account"), button:has-text("Connect AWS"), button:has-text("Add AWS Account")'
        );
        await addAccountButton.waitFor({ state: 'visible', timeout: 10000 });
        await addAccountButton.click();
        
        await waitForLoading(page);
        await takeScreenshot(page, 'add-aws-account-modal');
      });

      await test.step('Fill AWS account connection form', async () => {
        const formFields = {
          accountName: testData.awsAccount.accountName,
          accessKeyId: testData.awsAccount.accessKeyId,
          secretAccessKey: testData.awsAccount.secretAccessKey,
        };

        // Fill form fields (adapt selectors based on actual implementation)
        const accountNameInput = page.locator('input[name="accountName"], input[id="accountName"]');
        const accessKeyInput = page.locator('input[name="accessKeyId"], input[id="accessKeyId"]');
        const secretKeyInput = page.locator('input[name="secretAccessKey"], input[id="secretAccessKey"]');
        
        await accountNameInput.fill(formFields.accountName);
        await accessKeyInput.fill(formFields.accessKeyId);
        await secretKeyInput.fill(formFields.secretAccessKey);
        
        await takeScreenshot(page, 'aws-account-form-filled');
      });

      await test.step('Submit AWS account connection', async () => {
        const submitButton = page.locator('button[type="submit"], button:has-text("Connect"), button:has-text("Save")');
        await submitButton.click();
        
        await waitForLoading(page);
      });

      await test.step('Verify AWS account connected successfully', async () => {
        await takeScreenshot(page, 'aws-account-connected');
        
        // Check for success message or account in list
        const accountList = page.locator('[data-testid="aws-accounts"], .accounts-list, .aws-accounts');
        await expect(accountList).toBeVisible({ timeout: 5000 });
        
        const successMessage = page.locator('.success, .alert-success, [role="status"]');
        if (await successMessage.isVisible()) {
          await expect(successMessage).toContainText(/success|connected|added/i);
        }
      });
    });

    test('should show validation errors for invalid AWS credentials', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AWS002 - Invalid AWS credentials validation',
      });

      await test.step('Navigate to AWS management', async () => {
        await navigateToAWSManagement(page);
      });

      await test.step('Open Add AWS Account modal', async () => {
        const addAccountButton = page.locator('button:has-text("Add Account")');
        await addAccountButton.click();
        await waitForLoading(page);
      });

      await test.step('Enter invalid AWS credentials', async () => {
        await page.fill('input[name="accessKeyId"]', 'INVALID_KEY_ID');
        await page.fill('input[name="secretAccessKey"]', 'invalid_secret_key');
        
        const submitButton = page.locator('button[type="submit"]');
        await submitButton.click();
        
        await waitForLoading(page);
        await takeScreenshot(page, 'invalid-aws-credentials-error');
        
        // Check for error message
        const errorMessage = page.locator('.error, .alert-error, [role="alert"]');
        await expect(errorMessage).toContainText(/invalid|error|failed/i);
      });
    });
  });

  test.describe('EC2 Instance Management', () => {
    test('should list EC2 instances', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AWS003 - List EC2 instances',
      });

      await test.step('Navigate to EC2 instances section', async () => {
        await navigateToAWSManagement(page);
        
        // Look for EC2 instances link
        const ec2Link = page.locator('a:has-text("EC2"), a:has-text("Instances"), [data-testid="ec2-instances"]');
        if (await ec2Link.isVisible()) {
          await ec2Link.click();
          await waitForLoading(page);
        }
        
        await takeScreenshot(page, 'ec2-instances-page');
      });

      await test.step('Verify instances table is displayed', async () => {
        const instancesTable = page.locator('table, .instances-table, [data-testid="instances-table"]');
        await expect(instancesTable).toBeVisible({ timeout: 10000 });
        
        await takeScreenshot(page, 'ec2-instances-table');
        
        // Check for table headers
        const tableHeaders = page.locator('th, .table-header');
        await expect(tableHeaders.first()).toBeVisible();
      });

      await test.step('Refresh instances list', async () => {
        const refreshButton = page.locator('button:has-text("Refresh"), button:has-text("Sync")');
        if (await refreshButton.isVisible()) {
          await refreshButton.click();
          await waitForLoading(page);
          await takeScreenshot(page, 'ec2-instances-refreshed');
        }
      });
    });

    test('should launch new EC2 instance', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AWS004 - Launch EC2 instance',
      });

      await test.step('Navigate to EC2 instances', async () => {
        await navigateToAWSManagement(page);
        
        const ec2Link = page.locator('a:has-text("EC2"), a:has-text("Instances")');
        await ec2Link.click();
        await waitForLoading(page);
      });

      await test.step('Click Launch Instance button', async () => {
        const launchButton = page.locator('button:has-text("Launch Instance"), button:has-text("New Instance")');
        await launchButton.waitFor({ state: 'visible', timeout: 10000 });
        await launchButton.click();
        
        await waitForLoading(page);
        await takeScreenshot(page, 'launch-instance-modal');
      });

      await test.step('Fill instance launch form', async () => {
        const formFields = {
          name: testData.instance.name,
          imageId: testData.instance.imageId,
          instanceType: testData.instance.instanceType,
        };

        // Fill form fields (adapt based on actual implementation)
        const nameInput = page.locator('input[name="name"], input[id="name"]');
        const imageInput = page.locator('input[name="imageId"], input[id="imageId"]');
        const typeInput = page.locator('input[name="instanceType"], select[name="instanceType"]');
        
        await nameInput.fill(formFields.name);
        await imageInput.fill(formFields.imageId);
        await typeInput.fill(formFields.instanceType);
        
        await takeScreenshot(page, 'instance-launch-form-filled');
      });

      await test.step('Submit instance launch', async () => {
        const submitButton = page.locator('button[type="submit"], button:has-text("Launch")');
        await submitButton.click();
        
        await waitForLoading(page);
      });

      await test.step('Verify instance launch initiated', async () => {
        await takeScreenshot(page, 'instance-launch-initiated');
        
        // Check for success message or new instance in list
        const successMessage = page.locator('.success, .alert-success, [role="status"]');
        if (await successMessage.isVisible()) {
          await expect(successMessage).toContainText(/launch|started|created/i);
        }
        
        // Verify instances list is updated
        const instancesTable = page.locator('table, .instances-table');
        await expect(instancesTable).toBeVisible();
      });
    });

    test('should manage instance lifecycle (start/stop/terminate)', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AWS005 - Instance lifecycle management',
      });

      await test.step('Navigate to EC2 instances with existing instances', async () => {
        await navigateToAWSManagement(page);
        
        const ec2Link = page.locator('a:has-text("EC2"), a:has-text("Instances")');
        await ec2Link.click();
        await waitForLoading(page);
        
        await takeScreenshot(page, 'ec2-instances-for-lifecycle');
      });

      await test.step('Select an instance for lifecycle operations', async () => {
        // Look for instance rows or checkboxes
        const instanceRows = page.locator('tbody tr, .instance-row');
        if (await instanceRows.first().isVisible()) {
          // Select first instance
          const selectCheckbox = instanceRows.first().locator('input[type="checkbox"]');
          if (await selectCheckbox.isVisible()) {
            await selectCheckbox.check();
            await takeScreenshot(page, 'instance-selected');
          }
        }
      });

      await test.step('Perform start operation', async () => {
        const startButton = page.locator('button:has-text("Start"), button:has-text("Power On")');
        if (await startButton.isVisible()) {
          await startButton.click();
          
          // Handle confirmation dialog if present
          page.on('dialog', dialog => dialog.accept());
          
          await waitForLoading(page);
          await takeScreenshot(page, 'instance-start-operation');
          
          // Verify operation success
          const successMessage = page.locator('.success, .alert-success');
          if (await successMessage.isVisible()) {
            await expect(successMessage).toContainText(/start|power on/i);
          }
        }
      });

      await test.step('Perform stop operation', async () => {
        const stopButton = page.locator('button:has-text("Stop"), button:has-text("Power Off")');
        if (await stopButton.isVisible()) {
          await stopButton.click();
          
          page.on('dialog', dialog => dialog.accept());
          
          await waitForLoading(page);
          await takeScreenshot(page, 'instance-stop-operation');
          
          const successMessage = page.locator('.success, .alert-success');
          if (await successMessage.isVisible()) {
            await expect(successMessage).toContainText(/stop|power off/i);
          }
        }
      });
    });
  });

  test.describe('S3 Bucket Management', () => {
    test('should list S3 buckets', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AWS006 - List S3 buckets',
      });

      await test.step('Navigate to S3 section', async () => {
        await navigateToAWSManagement(page);
        
        const s3Link = page.locator('a:has-text("S3"), a:has-text("Storage"), [data-testid="s3-buckets"]');
        if (await s3Link.isVisible()) {
          await s3Link.click();
          await waitForLoading(page);
        }
        
        await takeScreenshot(page, 's3-buckets-page');
      });

      await test.step('Verify buckets table is displayed', async () => {
        const bucketsTable = page.locator('table, .buckets-table, [data-testid="buckets-table"]');
        await expect(bucketsTable).toBeVisible({ timeout: 10000 });
        
        await takeScreenshot(page, 's3-buckets-table');
        
        // Check for table structure
        const tableHeaders = page.locator('th, .table-header');
        await expect(tableHeaders.first()).toBeVisible();
      });
    });

    test('should create new S3 bucket', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AWS007 - Create S3 bucket',
      });

      await test.step('Navigate to S3 section', async () => {
        await navigateToAWSManagement(page);
        
        const s3Link = page.locator('a:has-text("S3")');
        await s3Link.click();
        await waitForLoading(page);
      });

      await test.step('Click Create Bucket button', async () => {
        const createButton = page.locator('button:has-text("Create Bucket"), button:has-text("New Bucket")');
        await createButton.waitFor({ state: 'visible', timeout: 10000 });
        await createButton.click();
        
        await waitForLoading(page);
        await takeScreenshot(page, 'create-bucket-modal');
      });

      await test.step('Fill bucket creation form', async () => {
        const uniqueBucketName = testData.s3Bucket.name;
        
        const bucketNameInput = page.locator('input[name="bucketName"], input[id="bucketName"]');
        await bucketNameInput.fill(uniqueBucketName);
        
        await takeScreenshot(page, 'bucket-creation-form-filled');
      });

      await test.step('Submit bucket creation', async () => {
        const submitButton = page.locator('button[type="submit"], button:has-text("Create")');
        await submitButton.click();
        
        await waitForLoading(page);
      });

      await test.step('Verify bucket created successfully', async () => {
        await takeScreenshot(page, 'bucket-created-success');
        
        // Check for success message
        const successMessage = page.locator('.success, .alert-success, [role="status"]');
        if (await successMessage.isVisible()) {
          await expect(successMessage).toContainText(/created|bucket/i);
        }
        
        // Verify bucket appears in list
        const bucketsTable = page.locator('table, .buckets-table');
        await expect(bucketsTable).toBeVisible();
      });
    });

    test('should delete S3 bucket', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AWS008 - Delete S3 bucket',
      });

      await test.step('Navigate to S3 section', async () => {
        await navigateToAWSManagement(page);
        
        const s3Link = page.locator('a:has-text("S3")');
        await s3Link.click();
        await waitForLoading(page);
      });

      await test.step('Select a bucket for deletion', async () => {
        const bucketRows = page.locator('tbody tr, .bucket-row');
        if (await bucketRows.first().isVisible()) {
          // Select first bucket
          const selectCheckbox = bucketRows.first().locator('input[type="checkbox"]');
          if (await selectCheckbox.isVisible()) {
            await selectCheckbox.check();
            await takeScreenshot(page, 'bucket-selected-for-deletion');
          }
        }
      });

      await test.step('Click delete button', async () => {
        const deleteButton = page.locator('button:has-text("Delete"), button:has-text("Remove")');
        if (await deleteButton.isVisible()) {
          await deleteButton.click();
          
          // Handle confirmation dialog
          page.on('dialog', dialog => {
            dialog.accept();
          });
          
          await waitForLoading(page);
          await takeScreenshot(page, 'bucket-delete-operation');
        }
      });

      await test.step('Verify bucket deletion', async () => {
        // Check for success message
        const successMessage = page.locator('.success, .alert-success, [role="status"]');
        if (await successMessage.isVisible()) {
          await expect(successMessage).toContainText(/deleted|removed/i);
        }
      });
    });
  });

  test.describe('RDS Instance Management', () => {
    test('should list RDS instances', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AWS009 - List RDS instances',
      });

      await test.step('Navigate to RDS section', async () => {
        await navigateToAWSManagement(page);
        
        const rdsLink = page.locator('a:has-text("RDS"), a:has-text("Database"), [data-testid="rds-instances"]');
        if (await rdsLink.isVisible()) {
          await rdsLink.click();
          await waitForLoading(page);
        }
        
        await takeScreenshot(page, 'rds-instances-page');
      });

      await test.step('Verify RDS instances table is displayed', async () => {
        const rdsTable = page.locator('table, .rds-table, [data-testid="rds-table"]');
        await expect(rdsTable).toBeVisible({ timeout: 10000 });
        
        await takeScreenshot(page, 'rds-instances-table');
      });
    });

    test('should create new RDS instance', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AWS010 - Create RDS instance',
      });

      await test.step('Navigate to RDS section', async () => {
        await navigateToAWSManagement(page);
        
        const rdsLink = page.locator('a:has-text("RDS")');
        await rdsLink.click();
        await waitForLoading(page);
      });

      await test.step('Click Create Database button', async () => {
        const createButton = page.locator('button:has-text("Create Database"), button:has-text("New Database")');
        await createButton.waitFor({ state: 'visible', timeout: 10000 });
        await createButton.click();
        
        await waitForLoading(page);
        await takeScreenshot(page, 'create-rds-modal');
      });

      await test.step('Fill RDS creation form', async () => {
        const formFields = {
          dbInstanceIdentifier: testData.rdsInstance.dbInstanceIdentifier,
          dbInstanceClass: testData.rdsInstance.dbInstanceClass,
          engine: testData.rdsInstance.engine,
          masterUsername: testData.rdsInstance.masterUsername,
          masterPassword: testData.rdsInstance.masterPassword,
        };

        // Fill form fields (adapt based on actual implementation)
        const dbIdInput = page.locator('input[name="dbInstanceIdentifier"], input[id="dbInstanceIdentifier"]');
        const dbClassInput = page.locator('input[name="dbInstanceClass"], select[name="dbInstanceClass"]');
        const engineInput = page.locator('input[name="engine"], select[name="engine"]');
        const usernameInput = page.locator('input[name="masterUsername"], input[id="masterUsername"]');
        const passwordInput = page.locator('input[name="masterPassword"], input[id="masterPassword"]');
        
        await dbIdInput.fill(formFields.dbInstanceIdentifier);
        await dbClassInput.fill(formFields.dbInstanceClass);
        await engineInput.fill(formFields.engine);
        await usernameInput.fill(formFields.masterUsername);
        await passwordInput.fill(formFields.masterPassword);
        
        await takeScreenshot(page, 'rds-creation-form-filled');
      });

      await test.step('Submit RDS creation', async () => {
        const submitButton = page.locator('button[type="submit"], button:has-text("Create")');
        await submitButton.click();
        
        await waitForLoading(page);
      });

      await test.step('Verify RDS instance creation initiated', async () => {
        await takeScreenshot(page, 'rds-creation-initiated');
        
        // Check for success message
        const successMessage = page.locator('.success, .alert-success, [role="status"]');
        if (await successMessage.isVisible()) {
          await expect(successMessage).toContainText(/created|database/i);
        }
      });
    });
  });

  test.describe('CloudFront Distribution Management', () => {
    test('should list CloudFront distributions', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AWS011 - List CloudFront distributions',
      });

      await test.step('Navigate to CloudFront section', async () => {
        await navigateToAWSManagement(page);
        
        const cloudfrontLink = page.locator('a:has-text("CloudFront"), a:has-text("CDN"), [data-testid="cloudfront"]');
        if (await cloudfrontLink.isVisible()) {
          await cloudfrontLink.click();
          await waitForLoading(page);
        }
        
        await takeScreenshot(page, 'cloudfront-page');
      });

      await test.step('Verify CloudFront distributions table', async () => {
        const cfTable = page.locator('table, .cloudfront-table, [data-testid="cloudfront-table"]');
        await expect(cfTable).toBeVisible({ timeout: 10000 });
        
        await takeScreenshot(page, 'cloudfront-table');
      });
    });
  });

  test.describe('AWS Resource Lifecycle Integration', () => {
    test('should complete full AWS resource lifecycle', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AWS012 - Complete AWS resource lifecycle',
      });

      const uniqueData = generateUniqueTestData('lifecycle');

      await test.step('Navigate to AWS management dashboard', async () => {
        await navigateToAWSManagement(page);
        await waitForLoading(page);
        await takeScreenshot(page, 'aws-lifecycle-start');
      });

      await test.step('Create S3 bucket', async () => {
        // Navigate to S3
        const s3Link = page.locator('a:has-text("S3")');
        await s3Link.click();
        await waitForLoading(page);
        
        // Create bucket
        const createButton = page.locator('button:has-text("Create Bucket")');
        await createButton.click();
        await waitForLoading(page);
        
        await page.fill('input[name="bucketName"]', uniqueData.bucketName);
        await page.click('button[type="submit"]');
        await waitForLoading(page);
        
        await takeScreenshot(page, 'aws-lifecycle-bucket-created');
      });

      await test.step('Create RDS instance', async () => {
        // Navigate to RDS
        const rdsLink = page.locator('a:has-text("RDS")');
        await rdsLink.click();
        await waitForLoading(page);
        
        // Create RDS
        const createButton = page.locator('button:has-text("Create Database")');
        await createButton.click();
        await waitForLoading(page);
        
        await page.fill('input[name="dbInstanceIdentifier"]', uniqueData.dbIdentifier);
        await page.fill('input[name="masterUsername"]', 'admin');
        await page.fill('input[name="masterPassword"]', 'TestPassword123!');
        
        await page.click('button[type="submit"]');
        await waitForLoading(page);
        
        await takeScreenshot(page, 'aws-lifecycle-rds-created');
      });

      await test.step('Launch EC2 instance', async () => {
        // Navigate to EC2
        const ec2Link = page.locator('a:has-text("EC2"), a:has-text("Instances")');
        await ec2Link.click();
        await waitForLoading(page);
        
        // Launch instance
        const launchButton = page.locator('button:has-text("Launch Instance")');
        await launchButton.click();
        await waitForLoading(page);
        
        await page.fill('input[name="name"]', uniqueData.instanceName);
        
        await page.click('button[type="submit"]');
        await waitForLoading(page);
        
        await takeScreenshot(page, 'aws-lifecycle-instance-launched');
      });

      await test.step('Manage instance lifecycle', async () => {
        // Select instance and perform lifecycle operations
        const instanceRows = page.locator('tbody tr, .instance-row');
        if (await instanceRows.first().isVisible()) {
          const selectCheckbox = instanceRows.first().locator('input[type="checkbox"]');
          await selectCheckbox.check();
          
          // Start instance
          const startButton = page.locator('button:has-text("Start")');
          if (await startButton.isVisible()) {
            await startButton.click();
            page.on('dialog', dialog => dialog.accept());
            await waitForLoading(page);
          }
          
          await takeScreenshot(page, 'aws-lifecycle-instance-managed');
        }
      });

      await test.step('Navigate between different AWS services', async () => {
        // Navigate to CloudFront
        const cloudfrontLink = page.locator('a:has-text("CloudFront"), a:has-text("CDN")');
        if (await cloudfrontLink.isVisible()) {
          await cloudfrontLink.click();
          await waitForLoading(page);
          await takeScreenshot(page, 'aws-lifecycle-cloudfront');
        }
        
        // Navigate back to S3
        const s3Link = page.locator('a:has-text("S3")');
        if (await s3Link.isVisible()) {
          await s3Link.click();
          await waitForLoading(page);
          await takeScreenshot(page, 'aws-lifecycle-back-to-s3');
        }
      });

      await test.step('Verify all resources are manageable', async () => {
        await takeScreenshot(page, 'aws-lifecycle-complete');
        
        // Verify that all created resources appear in their respective lists
        const s3Buckets = page.locator('table, .buckets-table');
        await expect(s3Buckets).toBeVisible();
        
        // Navigation should work between different AWS services
        const navigationWorking = await page.locator('nav, .sidebar, [data-testid="navigation"]').isVisible();
        expect(navigationWorking).toBeTruthy();
      });
    });
  });
});
