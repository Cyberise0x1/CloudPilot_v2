import { test, expect } from '@playwright/test';
import { 
  login, 
  logout, 
  testData, 
  generateUniqueTestData,
  waitForLoading,
  checkForJSErrors,
  takeScreenshot,
  setupTestEnvironment,
  teardownTestEnvironment,
  registerUser
} from './test-utils';

test.describe('Authentication Flow', () => {
  let testUserEmail: string;
  let testUserPassword: string;

  test.beforeEach(async ({ page }) => {
    await setupTestEnvironment(page);
    
    // Create unique test user for each test
    const uniqueData = generateUniqueTestData('auth');
    testUserEmail = uniqueData.email;
    testUserPassword = testData.user.password;
    
    // Check for JavaScript errors
    const errors = await checkForJSErrors(page);
    expect(errors).toHaveLength(0);
  });

  test.afterEach(async ({ page }) => {
    await teardownTestEnvironment(page);
  });

  test.describe('Login Flow', () => {
    test('should login with valid credentials', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AUTH001 - Successful login',
      });

      await test.step('Register test user if not exists', async () => {
        // First, ensure we have a registered user
        try {
          await registerUser(page, testUserEmail, testUserPassword, 'Auth Test User');
        } catch (e) {
          // User might already exist, proceed to login
          console.log('User might already exist, proceeding to login');
        }
      });

      await test.step('Navigate to login page', async () => {
        await page.goto('/login');
        await waitForLoading(page);
        
        // Verify we're on the login page
        await expect(page.locator('h1, h2')).toContainText(/login|sign in/i);
        await takeScreenshot(page, 'login-page');
      });

      await test.step('Fill login form with valid credentials', async () => {
        const emailInput = page.locator('input[type="email"], input[name="email"]');
        const passwordInput = page.locator('input[type="password"], input[name="password"]');
        
        await emailInput.waitFor({ state: 'visible' });
        await passwordInput.waitFor({ state: 'visible' });
        
        await emailInput.fill(testUserEmail);
        await passwordInput.fill(testUserPassword);
        
        await takeScreenshot(page, 'login-form-filled');
      });

      await test.step('Submit login form', async () => {
        const submitButton = page.locator('button[type="submit"], button:has-text("Login"), button:has-text("Sign In")');
        await submitButton.click();
        
        // Wait for authentication
        await waitForLoading(page);
      });

      await test.step('Verify successful login', async () => {
        // Should redirect to dashboard
        await page.waitForURL('**/dashboard', { timeout: 10000 });
        
        await takeScreenshot(page, 'login-success-dashboard');
        
        // Verify user is authenticated
        const userMenu = page.locator('[data-testid="user-menu"], .user-menu, button:has-text("User")');
        await expect(userMenu).toBeVisible({ timeout: 5000 });
      });
    });

    test('should show error for invalid credentials', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AUTH002 - Invalid credentials error',
      });

      await test.step('Navigate to login page', async () => {
        await page.goto('/login');
        await waitForLoading(page);
      });

      await test.step('Enter invalid credentials', async () => {
        await page.fill('input[type="email"]', 'nonexistent@example.com');
        await page.fill('input[type="password"]', 'wrongpassword');
        
        await takeScreenshot(page, 'invalid-credentials-filled');
      });

      await test.step('Submit and verify error message', async () => {
        await page.click('button[type="submit"]');
        await waitForLoading(page);
        
        await takeScreenshot(page, 'login-error-message');
        
        // Check for error message
        const errorMessage = page.locator('.error, .alert-error, [role="alert"], .text-red-500');
        await expect(errorMessage).toBeVisible();
        await expect(errorMessage).toContainText(/invalid|incorrect|wrong/i);
      });

      await test.step('Verify user remains on login page', async () => {
        // Should not redirect to dashboard
        await page.waitForTimeout(2000);
        const currentUrl = page.url();
        expect(currentUrl).toContain('/login');
      });
    });

    test('should validate form fields before submission', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AUTH003 - Form validation',
      });

      await test.step('Navigate to login page', async () => {
        await page.goto('/login');
        await waitForLoading(page);
      });

      await test.step('Try to submit empty form', async () => {
        const submitButton = page.locator('button[type="submit"]');
        await submitButton.click();
        
        // Check for validation messages
        await waitForLoading(page);
        await takeScreenshot(page, 'empty-login-validation');
        
        // Verify validation messages are shown
        const emailError = page.locator('input[type="email"] ~ .error, .error:has-text("email")');
        const passwordError = page.locator('input[type="password"] ~ .error, .error:has-text("password")');
        
        // At least one validation error should be visible
        const hasValidationErrors = await Promise.all([
          emailError.isVisible().catch(() => false),
          passwordError.isVisible().catch(() => false),
        ]);
        
        expect(hasValidationErrors.some(Boolean)).toBeTruthy();
      });

      await test.step('Try invalid email format', async () => {
        await page.fill('input[type="email"]', 'invalid-email-format');
        await page.fill('input[type="password"]', testUserPassword);
        
        await page.click('button[type="submit"]');
        await waitForLoading(page);
        
        await takeScreenshot(page, 'invalid-email-format-validation');
        
        // Check for email format validation
        const emailError = page.locator('.error:has-text("email"), .error:has-text("valid")');
        await expect(emailError).toBeVisible();
      });
    });

    test('should remember user session after login', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AUTH004 - Session persistence',
      });

      await test.step('Login and navigate to protected page', async () => {
        await login(page, testUserEmail, testUserPassword);
        await page.goto('/dashboard');
        await waitForLoading(page);
        await takeScreenshot(page, 'protected-page-after-login');
      });

      await test.step('Refresh page and verify session persists', async () => {
        await page.reload();
        await waitForLoading(page);
        
        // Should still be authenticated
        const userMenu = page.locator('[data-testid="user-menu"], .user-menu');
        await expect(userMenu).toBeVisible({ timeout: 5000 });
        
        await takeScreenshot(page, 'session-persisted-after-refresh');
      });

      await test.step('Navigate to another protected page', async () => {
        await page.goto('/aws-management');
        await waitForLoading(page);
        
        // Should still be authenticated
        const userMenu = page.locator('[data-testid="user-menu"], .user-menu');
        await expect(userMenu).toBeVisible({ timeout: 5000 });
        
        await takeScreenshot(page, 'session-persisted-different-page');
      });
    });
  });

  test.describe('Logout Flow', () => {
    test('should logout successfully', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AUTH005 - Successful logout',
      });

      await test.step('Login first', async () => {
        await login(page, testUserEmail, testUserPassword);
        await takeScreenshot(page, 'logged-in-state');
      });

      await test.step('Navigate to logout', async () => {
        // Look for logout button in various locations
        const logoutSelectors = [
          'button:has-text("Logout")',
          'button:has-text("Sign Out")',
          '[data-testid="logout"]',
          'a:has-text("Logout")',
          '.dropdown-menu button:has-text("Logout")',
        ];

        let logoutClicked = false;
        for (const selector of logoutSelectors) {
          try {
            if (await page.locator(selector).isVisible()) {
              await page.click(selector);
              logoutClicked = true;
              break;
            }
          } catch (e) {
            continue;
          }
        }

        if (!logoutClicked) {
          // Try to find user menu first
          const userMenu = page.locator('[data-testid="user-menu"], button:has-text("User")');
          if (await userMenu.isVisible()) {
            await userMenu.click();
            await page.waitForSelector(logoutSelectors[0], { timeout: 2000 });
            await page.click(logoutSelectors[0]);
          }
        }
        
        await waitForLoading(page);
      });

      await test.step('Verify logout and redirect', async () => {
        // Should redirect to login or home page
        await page.waitForURL('**/login', { timeout: 10000 });
        
        await takeScreenshot(page, 'logout-success-redirect');
        
        // Verify not authenticated
        const userMenu = page.locator('[data-testid="user-menu"], .user-menu');
        await expect(userMenu).not.toBeVisible();
      });

      await test.step('Verify protected pages require authentication', async () => {
        await page.goto('/dashboard');
        await waitForLoading(page);
        
        // Should redirect to login or show unauthorized message
        const currentUrl = page.url();
        expect(currentUrl).toMatch(/login|unauthorized|forbidden/i);
        
        await takeScreenshot(page, 'protected-page-requires-auth');
      });
    });

    test('should clear session data on logout', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AUTH006 - Session cleanup on logout',
      });

      await test.step('Login and verify session data exists', async () => {
        await login(page, testUserEmail, testUserPassword);
        
        // Check if session data exists
        const hasSessionData = await page.evaluate(() => {
          return localStorage.getItem('auth_token') !== null || 
                 sessionStorage.getItem('auth_token') !== null;
        });
        
        expect(hasSessionData).toBeTruthy();
        await takeScreenshot(page, 'session-data-exists');
      });

      await test.step('Logout and verify session data is cleared', async () => {
        await logout(page);
        
        // Check if session data is cleared
        const sessionDataCleared = await page.evaluate(() => {
          const localStorageEmpty = Object.keys(localStorage).length === 0;
          const sessionStorageEmpty = Object.keys(sessionStorage).length === 0;
          return localStorageEmpty && sessionStorageEmpty;
        });
        
        expect(sessionDataCleared).toBeTruthy();
        await takeScreenshot(page, 'session-data-cleared');
      });
    });
  });

  test.describe('Authentication State Management', () => {
    test('should handle token expiration', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AUTH007 - Token expiration handling',
      });

      await test.step('Login successfully', async () => {
        await login(page, testUserEmail, testUserPassword);
        await takeScreenshot(page, 'authenticated-state');
      });

      await test.step('Simulate token expiration', async () => {
        // Clear authentication token to simulate expiration
        await page.evaluate(() => {
          localStorage.clear();
          sessionStorage.clear();
        });
      });

      await test.step('Navigate to protected page and verify redirect', async () => {
        await page.goto('/dashboard');
        await waitForLoading(page);
        
        // Should redirect to login or show unauthorized
        await page.waitForURL('**/login', { timeout: 5000 });
        
        await takeScreenshot(page, 'token-expired-redirect');
        
        // Verify error message about session expiry
        const errorMessage = page.locator('.error, .alert-info, .alert-warning');
        if (await errorMessage.isVisible()) {
          await expect(errorMessage).toContainText(/expired|session|login/i);
        }
      });
    });

    test('should redirect unauthenticated users to login', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AUTH008 - Unauthenticated access redirect',
      });

      await test.step('Try to access protected page without login', async () => {
        await page.goto('/dashboard');
        await waitForLoading(page);
        
        // Should redirect to login
        await page.waitForURL('**/login', { timeout: 5000 });
        
        await takeScreenshot(page, 'unauthenticated-redirect');
      });

      await test.step('Try to access AWS management without login', async () => {
        await page.goto('/aws-management');
        await waitForLoading(page);
        
        // Should redirect to login
        await page.waitForURL('**/login', { timeout: 5000 });
        
        await takeScreenshot(page, 'aws-unauthenticated-redirect');
      });

      await test.step('Try to access monitoring without login', async () => {
        await page.goto('/monitoring');
        await waitForLoading(page);
        
        // Should redirect to login
        await page.waitForURL('**/login', { timeout: 5000 });
        
        await takeScreenshot(page, 'monitoring-unauthenticated-redirect');
      });
    });

    test('should allow access to public pages without authentication', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AUTH009 - Public page access',
      });

      await test.step('Access home page without login', async () => {
        await page.goto('/');
        await waitForLoading(page);
        
        await takeScreenshot(page, 'home-page-unauthenticated');
        
        // Should be able to see home page
        const homeContent = page.locator('h1, h2, .hero, .welcome');
        await expect(homeContent).toBeVisible({ timeout: 5000 });
      });

      await test.step('Access login page without authentication', async () => {
        await page.goto('/login');
        await waitForLoading(page);
        
        await takeScreenshot(page, 'login-page-direct-access');
        
        // Should show login form
        const loginForm = page.locator('form, input[type="email"]');
        await expect(loginForm).toBeVisible();
      });

      await test.step('Access registration page without authentication', async () => {
        await page.goto('/register');
        await waitForLoading(page);
        
        await takeScreenshot(page, 'register-page-direct-access');
        
        // Should show registration form
        const registerForm = page.locator('form, input[name="email"]');
        await expect(registerForm).toBeVisible();
      });
    });
  });

  test.describe('Full Authentication Cycle', () => {
    test('should complete full login to logout cycle', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AUTH010 - Complete login/logout cycle',
      });

      await test.step('Register new user', async () => {
        const uniqueData = generateUniqueTestData('fullcycle');
        await registerUser(page, uniqueData.email, testData.user.password, 'Full Cycle User');
        await takeScreenshot(page, 'fullcycle-registered');
      });

      await test.step('Verify login and access protected resources', async () => {
        // Already logged in from registration, verify access
        await page.goto('/dashboard');
        await waitForLoading(page);
        
        await takeScreenshot(page, 'fullcycle-dashboard-access');
        
        // Navigate to AWS management
        const awsLink = page.locator('a:has-text("AWS")');
        if (await awsLink.isVisible()) {
          await awsLink.click();
          await waitForLoading(page);
          await takeScreenshot(page, 'fullcycle-aws-access');
        }
        
        // Navigate to monitoring
        const monitoringLink = page.locator('a:has-text("Monitoring"), a:has-text("Dashboard")');
        if (await monitoringLink.isVisible()) {
          await monitoringLink.click();
          await waitForLoading(page);
          await takeScreenshot(page, 'fullcycle-monitoring-access');
        }
      });

      await test.step('Perform logout', async () => {
        await logout(page);
        await takeScreenshot(page, 'fullcycle-logout');
      });

      await test.step('Verify session cleared and cannot access protected resources', async () => {
        await page.goto('/dashboard');
        await waitForLoading(page);
        
        // Should redirect to login
        await page.waitForURL('**/login', { timeout: 5000 });
        
        await takeScreenshot(page, 'fullcycle-logout-verification');
        
        // Verify login form is visible
        const loginForm = page.locator('form, input[type="email"]');
        await expect(loginForm).toBeVisible();
      });
    });

    test('should maintain authentication across browser tabs', async ({ page, context }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'AUTH011 - Cross-tab authentication',
      });

      await test.step('Login in main tab', async () => {
        await login(page, testUserEmail, testUserPassword);
        await takeScreenshot(page, 'cross-tab-login');
      });

      await test.step('Open new tab and verify authentication', async () => {
        const newTab = await context.newPage();
        await newTab.goto('/dashboard');
        await waitForLoading(newTab);
        
        // Should be authenticated in new tab
        const userMenu = newTab.locator('[data-testid="user-menu"], .user-menu');
        await expect(userMenu).toBeVisible({ timeout: 5000 });
        
        await takeScreenshot(newTab, 'cross-tab-authenticated');
        await newTab.close();
      });

      await test.step('Logout from main tab', async () => {
        await logout(page);
        await takeScreenshot(page, 'cross-tab-logout');
      });
    });
  });
});
