# End-to-End Testing with Playwright

This directory contains comprehensive end-to-end (E2E) tests for the CloudPilot production application using Playwright.

## 📋 Overview

The E2E tests validate the complete user journey from registration through AWS management and monitoring dashboard usage. Tests are organized by functional areas and cover critical user workflows.

## 🗂️ Test Structure

```
tests/e2e/
├── test-utils.ts              # Shared utilities and helpers
├── test-data-setup.ts         # Test data setup and cleanup
├── user-registration-flow.e2e.test.ts    # User registration tests
├── authentication-flow.e2e.test.ts       # Login/logout tests  
├── aws-management-flow.e2e.test.ts       # AWS resource management tests
└── monitoring-flow.e2e.test.ts           # Monitoring dashboard tests
```

## 🚀 Getting Started

### Prerequisites

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Install Playwright Browsers**
   ```bash
   npx playwright install
   ```

3. **Ensure Application is Running**
   ```bash
   npm run dev
   ```

### Running Tests

#### Run All Tests
```bash
npm run test:e2e
```

#### Run Specific Test File
```bash
npx playwright test user-registration-flow.e2e.test.ts
```

#### Run Tests with UI
```bash
npm run test:e2e:ui
```

#### Run Tests in Headed Mode
```bash
npm run test:e2e:headed
```

#### Debug Tests
```bash
npm run test:e2e:debug
```

#### Run Tests for Specific Browser
```bash
npx playwright test --project=chromium
npx playwright test --project=firefox
npx playwright test --project=webkit
```

#### Run Tests in Parallel
```bash
npx playwright test --workers=4
```

## 📊 Test Coverage

### 1. User Registration Flow (`user-registration-flow.e2e.test.ts`)

**Test Cases:**
- ✅ REG001 - New user registration success
- ✅ REG002 - Registration form validation
- ✅ REG003 - Duplicate email prevention
- ✅ REG004 - Post-registration navigation
- ✅ REG005 - User role assignment
- ✅ REG006 - Full registration to AWS management flow

**Validates:**
- User registration form functionality
- Form validation and error handling
- Duplicate account prevention
- Successful registration flow
- AWS management access after registration

### 2. Authentication Flow (`authentication-flow.e2e.test.ts`)

**Test Cases:**
- ✅ AUTH001 - Successful login
- ✅ AUTH002 - Invalid credentials error handling
- ✅ AUTH003 - Form validation
- ✅ AUTH004 - Session persistence
- ✅ AUTH005 - Successful logout
- ✅ AUTH006 - Session cleanup on logout
- ✅ AUTH007 - Token expiration handling
- ✅ AUTH008 - Unauthenticated access redirect
- ✅ AUTH009 - Public page access
- ✅ AUTH010 - Complete login/logout cycle
- ✅ AUTH011 - Cross-tab authentication

**Validates:**
- Login/logout functionality
- Session management and persistence
- Token expiration handling
- Protected route access control
- Authentication state management

### 3. AWS Management Flow (`aws-management-flow.e2e.test.ts`)

**Test Cases:**
- ✅ AWS001 - Connect AWS account
- ✅ AWS002 - Invalid AWS credentials validation
- ✅ AWS003 - List EC2 instances
- ✅ AWS004 - Launch EC2 instance
- ✅ AWS005 - Instance lifecycle management (start/stop/terminate)
- ✅ AWS006 - List S3 buckets
- ✅ AWS007 - Create S3 bucket
- ✅ AWS008 - Delete S3 bucket
- ✅ AWS009 - List RDS instances
- ✅ AWS010 - Create RDS instance
- ✅ AWS011 - List CloudFront distributions
- ✅ AWS012 - Complete AWS resource lifecycle

**Validates:**
- AWS account connection and management
- EC2 instance operations (CRUD)
- S3 bucket management
- RDS instance management
- CloudFront distribution management
- Resource lifecycle operations

### 4. Monitoring Dashboard Flow (`monitoring-flow.e2e.test.ts`)

**Test Cases:**
- ✅ MON001 - Access monitoring dashboard
- ✅ MON002 - Real-time system metrics
- ✅ MON003 - Performance trends and charts
- ✅ MON004 - View active alerts
- ✅ MON005 - Create new alert
- ✅ MON006 - Acknowledge alert
- ✅ MON007 - Resolve alert
- ✅ MON008 - System health status
- ✅ MON009 - Uptime metrics
- ✅ MON010 - Error logs display
- ✅ MON011 - Error pattern analysis
- ✅ MON012 - Dashboard data refresh
- ✅ MON013 - Time range filtering
- ✅ MON014 - Export monitoring data
- ✅ MON015 - Monitoring sections navigation

**Validates:**
- Dashboard accessibility and layout
- Real-time metrics display
- Alert management (create, acknowledge, resolve)
- System health overview
- Error tracking and analysis
- Data filtering and export functionality

## 🔧 Configuration

### Playwright Configuration (`playwright.config.ts`)

- **Base URL**: `http://localhost:5173`
- **Parallel Execution**: Enabled
- **Retries**: 2 on CI, 0 locally
- **Screenshots**: On failure only
- **Videos**: On failure only
- **Trace**: On first retry

### Supported Browsers

- ✅ Chromium (Chrome)
- ✅ Firefox
- ✅ WebKit (Safari)
- ✅ Mobile Chrome (Pixel 5)
- ✅ Mobile Safari (iPhone 12)

### Test Data Management

The test suite includes comprehensive test data setup and cleanup:

```typescript
import { testDataManager, testEnvironment } from './test-data-setup';

// Setup before all tests
testEnvironment.setup();

// Cleanup after all tests  
testEnvironment.teardown();

// Create test data
const user = await testDataManager.createTestUser();
const awsAccount = await testDataManager.createTestAWSAccount(accessToken);
```

## 🛠️ Test Utilities

### Common Helper Functions

- `login(page, email, password)` - Authenticate user
- `logout(page)` - Sign out user
- `registerUser(page, email, password, fullName)` - Register new user
- `navigateToAWSManagement(page)` - Navigate to AWS section
- `navigateToMonitoring(page)` - Navigate to monitoring dashboard
- `waitForLoading(page)` - Wait for loading states
- `takeScreenshot(page, name)` - Capture screenshots
- `generateUniqueTestData(prefix)` - Generate unique test data

### Test Data

- **Test User**: `testuser@example.com` / `TestPassword123!`
- **Test AWS Account**: Mock AWS credentials
- **Test Resources**: Dynamically generated names with timestamps

## 📸 Screenshots and Reports

### Test Results

After running tests, you can find:

- **HTML Report**: `playwright-report/`
- **Screenshots**: `test-results/screenshots/`
- **Videos**: `test-results/videos/`
- **Traces**: `test-results/trace/`

### Viewing Reports

```bash
# Open HTML report
npx playwright show-report

# View trace
npx playwright trace view test-results/trace/trace.zip
```

## 🔍 Best Practices

### Writing Tests

1. **Use Descriptive Names**: Test cases should clearly describe what's being tested
2. **Follow AAA Pattern**: Arrange, Act, Assert
3. **Take Screenshots**: Capture key states for debugging
4. **Handle Loading States**: Always wait for async operations
5. **Clean Up Resources**: Use test data manager for cleanup

### Example Test Structure

```typescript
test('should complete user registration', async ({ page }) => {
  // Arrange
  const uniqueData = generateUniqueTestData('registration');
  
  // Act
  await page.goto('/register');
  await page.fill('input[name="email"]', uniqueData.email);
  await page.click('button[type="submit"]');
  
  // Assert
  await expect(page).toHaveURL('**/dashboard');
  await takeScreenshot(page, 'registration-success');
});
```

## 🚨 Troubleshooting

### Common Issues

1. **Application Not Starting**
   - Ensure `npm run dev` is running
   - Check port 5173 is available
   - Verify all dependencies are installed

2. **Tests Timing Out**
   - Increase timeout in playwright.config.ts
   - Check application performance
   - Verify network connectivity

3. **Element Not Found**
   - Update selectors in test-utils.ts
   - Check for dynamic content loading
   - Verify element visibility

4. **Authentication Failures**
   - Clear browser storage
   - Check JWT token configuration
   - Verify test user creation

### Debug Mode

Run tests in debug mode for detailed step-by-step execution:

```bash
npm run test:e2e:debug
```

## 📈 Continuous Integration

### GitHub Actions Example

```yaml
name: E2E Tests
on: [push, pull_request]

jobs:
  e2e-tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: 18
      - run: npm ci
      - run: npx playwright install --with-deps
      - run: npm run build
      - run: npm start &
      - run: npx wait-on http://localhost:3000
      - run: npm run test:e2e
      - uses: actions/upload-artifact@v3
        if: always()
        with:
          name: playwright-report
          path: playwright-report/
```

## 🤝 Contributing

1. Write tests for new features
2. Update existing tests when changing functionality
3. Follow the established naming conventions
4. Include screenshots for visual validation
5. Ensure proper cleanup of test data

## 📝 License

This test suite is part of the CloudPilot production application.

---

For more information about Playwright, visit the [official documentation](https://playwright.dev/).
