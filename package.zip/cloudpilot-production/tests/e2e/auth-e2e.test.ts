/**
 * End-to-End (E2E) Tests
 * Complete application workflow testing from user perspective
 */

import { describe, test, expect, beforeAll, afterAll, beforeEach, afterEach, jest } from '@jest/globals';
import { spawn } from 'child_process';
import { createTestAccount } from '@playwright/test';

// Import test utilities
import { testDataGenerators, asyncTestHelpers, httpTestHelpers } from '../utils/test-utils';
import { envTestUtils } from '../setup/env-mocks';

// E2E test configuration
const E2E_CONFIG = {
  baseUrl: process.env.E2E_BASE_URL || 'http://localhost:3001',
  timeout: 30000,
  retryCount: 3,
  maxConcurrency: 5
};

describe('CloudPilot Production - E2E Tests', () => {
  let testServer: any;
  let baseUrl: string;
  let userSession: { accessToken: string; refreshToken: string; userId: string };
  
  beforeAll(async () => {
    // Setup E2E test environment
    envTestUtils.setTestEnv({
      NODE_ENV: 'test',
      PORT: '3001',
      DATABASE_URL: 'postgresql://test:test@localhost:5432/test_e2e',
      JWT_SECRET: 'e2e-test-jwt-secret',
      E2E_TEST_MODE: 'true'
    });
    
    // Start test server
    console.log('🚀 Starting E2E test server...');
    baseUrl = E2E_CONFIG.baseUrl;
    
    // In a real E2E setup, you would:
    // 1. Start the actual application server
    // 2. Wait for it to be ready
    // 3. Verify health check endpoint
    
    // For demo purposes, simulate server startup
    await asyncTestHelpers.waitFor(
      () => new Promise(resolve => {
        // Simulate server health check
        resolve(true);
      }),
      10000
    );
    
    console.log('✅ E2E test server ready');
  });
  
  afterAll(async () => {
    // Cleanup E2E test environment
    envTestUtils.reset();
    
    // Stop test server if it was started
    if (testServer) {
      testServer.kill('SIGTERM');
    }
    
    console.log('✅ E2E test environment cleaned up');
  });
  
  beforeEach(async () => {
    // Reset database and create fresh test data
    userSession = await createTestUserSession();
  });
  
  afterEach(async () => {
    // Cleanup test data
    await cleanupTestData();
  });
  
  describe('Complete User Journey', () => {
    test('should complete full user registration and authentication flow', async () => {
      // Step 1: User Registration
      const newUser = testDataGenerators.generateUser({
        email: 'e2e-test@example.com',
        password: 'E2eTest123!'
      });
      
      const registerResponse = await simulateHttpRequest({
        method: 'POST',
        url: '/api/auth/register',
        data: newUser,
        expectedStatus: 201
      });
      
      expect(registerResponse.success).toBe(true);
      expect(registerResponse.data.user.email).toBe(newUser.email);
      expect(registerResponse.data).toHaveProperty('accessToken');
      expect(registerResponse.data).toHaveProperty('refreshToken');
      
      // Step 2: User Login
      const loginResponse = await simulateHttpRequest({
        method: 'POST',
        url: '/api/auth/login',
        data: {
          email: newUser.email,
          password: newUser.password
        },
        expectedStatus: 200
      });
      
      expect(loginResponse.success).toBe(true);
      expect(loginResponse.data.user.email).toBe(newUser.email);
      expect(loginResponse.data.accessToken).toBeTruthy();
      
      // Step 3: Access Protected Route
      const protectedResponse = await simulateHttpRequest({
        method: 'GET',
        url: '/api/users/profile',
        headers: {
          'authorization': `Bearer ${loginResponse.data.accessToken}`
        },
        expectedStatus: 200
      });
      
      expect(protectedResponse.success).toBe(true);
      expect(protectedResponse.data.user.email).toBe(newUser.email);
      
      // Step 4: Update Profile
      const updateResponse = await simulateHttpRequest({
        method: 'PUT',
        url: '/api/users/profile',
        headers: {
          'authorization': `Bearer ${loginResponse.data.accessToken}`
        },
        data: {
          firstName: 'John',
          lastName: 'Doe',
          bio: 'E2E Test User'
        },
        expectedStatus: 200
      });
      
      expect(updateResponse.success).toBe(true);
      expect(updateResponse.data.user.firstName).toBe('John');
      expect(updateResponse.data.user.lastName).toBe('Doe');
      
      // Step 5: Refresh Token
      const refreshResponse = await simulateHttpRequest({
        method: 'POST',
        url: '/api/auth/refresh',
        data: {
          refreshToken: loginResponse.data.refreshToken
        },
        expectedStatus: 200
      });
      
      expect(refreshResponse.success).toBe(true);
      expect(refreshResponse.data.accessToken).toBeTruthy();
      
      // Step 6: Logout
      const logoutResponse = await simulateHttpRequest({
        method: 'POST',
        url: '/api/auth/logout',
        headers: {
          'authorization': `Bearer ${refreshResponse.data.accessToken}`
        },
        expectedStatus: 200
      });
      
      expect(logoutResponse.success).toBe(true);
      expect(logoutResponse.message).toContain('logged out');
      
      // Step 7: Verify logout (should fail)
      const verifyLogoutResponse = await simulateHttpRequest({
        method: 'GET',
        url: '/api/users/profile',
        headers: {
          'authorization': `Bearer ${refreshResponse.data.accessToken}`
        },
        expectedStatus: 401
      });
      
      expect(verifyLogoutResponse.success).toBe(false);
      expect(verifyLogoutResponse.message).toContain('invalid');
    });
    
    test('should handle password reset workflow', async () => {
      // Step 1: Request password reset
      const resetRequestResponse = await simulateHttpRequest({
        method: 'POST',
        url: '/api/auth/forgot-password',
        data: {
          email: userSession.email
        },
        expectedStatus: 200
      });
      
      expect(resetRequestResponse.success).toBe(true);
      expect(resetRequestResponse.message).toContain('sent to your email');
      
      // Step 2: Simulate email with reset token (in real E2E, this would come via email)
      const resetToken = await getResetTokenFromEmail();
      
      // Step 3: Reset password with token
      const resetPasswordResponse = await simulateHttpRequest({
        method: 'POST',
        url: '/api/auth/reset-password',
        data: {
          token: resetToken,
          newPassword: 'NewPassword123!'
        },
        expectedStatus: 200
      });
      
      expect(resetPasswordResponse.success).toBe(true);
      expect(resetPasswordResponse.message).toContain('password reset successful');
      
      // Step 4: Login with new password
      const loginWithNewPasswordResponse = await simulateHttpRequest({
        method: 'POST',
        url: '/api/auth/login',
        data: {
          email: userSession.email,
          password: 'NewPassword123!'
        },
        expectedStatus: 200
      });
      
      expect(loginWithNewPasswordResponse.success).toBe(true);
    });
  });
  
  describe('Admin User Workflow', () => {
    test('should complete admin user creation and management flow', async () => {
      // Setup admin user
      const adminUser = await createAdminUser();
      
      // Step 1: Admin Login
      const adminLoginResponse = await simulateHttpRequest({
        method: 'POST',
        url: '/api/auth/login',
        data: adminUser.credentials,
        expectedStatus: 200
      });
      
      expect(adminLoginResponse.success).toBe(true);
      expect(adminLoginResponse.data.user.role).toBe('admin');
      
      // Step 2: Create regular user
      const newUserData = testDataGenerators.generateUser({
        email: 'admin-created-user@example.com'
      });
      
      const createUserResponse = await simulateHttpRequest({
        method: 'POST',
        url: '/api/admin/users',
        headers: {
          'authorization': `Bearer ${adminLoginResponse.data.accessToken}`
        },
        data: newUserData,
        expectedStatus: 201
      });
      
      expect(createUserResponse.success).toBe(true);
      expect(createUserResponse.data.user.email).toBe(newUserData.email);
      
      // Step 3: List users (admin only)
      const listUsersResponse = await simulateHttpRequest({
        method: 'GET',
        url: '/api/admin/users',
        headers: {
          'authorization': `Bearer ${adminLoginResponse.data.accessToken}`
        },
        expectedStatus: 200
      });
      
      expect(listUsersResponse.success).toBe(true);
      expect(Array.isArray(listUsersResponse.data.users)).toBe(true);
      expect(listUsersResponse.data.users.length).toBeGreaterThan(0);
      
      // Step 4: Update user role
      const updateUserResponse = await simulateHttpRequest({
        method: 'PUT',
        url: `/api/admin/users/${createUserResponse.data.user.id}`,
        headers: {
          'authorization': `Bearer ${adminLoginResponse.data.accessToken}`
        },
        data: {
          role: 'manager'
        },
        expectedStatus: 200
      });
      
      expect(updateUserResponse.success).toBe(true);
      expect(updateUserResponse.data.user.role).toBe('manager');
      
      // Step 5: Deactivate user
      const deactivateUserResponse = await simulateHttpRequest({
        method: 'DELETE',
        url: `/api/admin/users/${createUserResponse.data.user.id}`,
        headers: {
          'authorization': `Bearer ${adminLoginResponse.data.accessToken}`
        },
        expectedStatus: 200
      });
      
      expect(deactivateUserResponse.success).toBe(true);
      expect(deactivateUserResponse.data.user.active).toBe(false);
    });
  });
  
  describe('Security and Validation E2E Tests', () => {
    test('should prevent unauthorized access attempts', async () => {
      // Test 1: Access protected route without token
      const noAuthResponse = await simulateHttpRequest({
        method: 'GET',
        url: '/api/users/profile',
        expectedStatus: 401
      });
      
      expect(noAuthResponse.success).toBe(false);
      
      // Test 2: Access admin route with regular user token
      const userToken = userSession.accessToken;
      const adminRouteResponse = await simulateHttpRequest({
        method: 'GET',
        url: '/api/admin/users',
        headers: {
          'authorization': `Bearer ${userToken}`
        },
        expectedStatus: 403
      });
      
      expect(adminRouteResponse.success).toBe(false);
      expect(adminRouteResponse.message).toContain('insufficient');
      
      // Test 3: Access route with expired token
      const expiredToken = await getExpiredToken();
      const expiredTokenResponse = await simulateHttpRequest({
        method: 'GET',
        url: '/api/users/profile',
        headers: {
          'authorization': `Bearer ${expiredToken}`
        },
        expectedStatus: 401
      });
      
      expect(expiredTokenResponse.success).toBe(false);
    });
    
    test('should handle various attack vectors', async () => {
      // SQL Injection attempt
      const sqlInjectionResponse = await simulateHttpRequest({
        method: 'POST',
        url: '/api/auth/login',
        data: {
          email: "admin'; DROP TABLE users; --",
          password: 'password'
        },
        expectedStatus: 400
      });
      
      expect(sqlInjectionResponse.success).toBe(false);
      
      // XSS attempt
      const xssResponse = await simulateHttpRequest({
        method: 'POST',
        url: '/api/auth/register',
        data: {
          email: '<script>alert("xss")</script>@test.com',
          password: 'Password123!'
        },
        expectedStatus: 400
      });
      
      expect(xssResponse.success).toBe(false);
      
      // Path traversal attempt
      const pathTraversalResponse = await simulateHttpRequest({
        method: 'GET',
        url: '../../../etc/passwd',
        headers: {
          'authorization': `Bearer ${userSession.accessToken}`
        },
        expectedStatus: 404
      });
      
      expect(pathTraversalResponse.success).toBe(false);
    });
  });
  
  describe('Performance E2E Tests', () => {
    test('should handle concurrent user registrations', async () => {
      const concurrentRegistrations = 50;
      const registrationPromises = Array.from({ length: concurrentRegistrations }, (_, i) =>
        simulateHttpRequest({
          method: 'POST',
          url: '/api/auth/register',
          data: testDataGenerators.generateUser({
            email: `concurrent-${i}-${Date.now()}@test.com`
          }),
          expectedStatus: 201,
          timeout: E2E_CONFIG.timeout
        })
      );
      
      const startTime = Date.now();
      const results = await Promise.allSettled(registrationPromises);
      const endTime = Date.now();
      
      const successful = results.filter(r => r.status === 'fulfilled' && r.value.success);
      const failed = results.filter(r => r.status === 'rejected' || !r.value.success);
      
      console.log(`Concurrent registrations: ${successful.length} successful, ${failed.length} failed in ${endTime - startTime}ms`);
      
      expect(successful.length).toBeGreaterThan(0);
      expect(successful.length + failed.length).toBe(concurrentRegistrations);
    });
    
    test('should maintain response times under load', async () => {
      const requestCount = 100;
      const requests = Array.from({ length: requestCount }, (_, i) =>
        simulateHttpRequest({
          method: 'GET',
          url: '/api/health',
          expectedStatus: 200,
          timeout: 5000 // Shorter timeout for health checks
        })
      );
      
      const startTime = Date.now();
      const results = await Promise.all(requests);
      const endTime = Date.now();
      
      const avgResponseTime = (endTime - startTime) / requestCount;
      const successful = results.filter(r => r.success);
      
      console.log(`Average response time: ${avgResponseTime.toFixed(2)}ms for ${requestCount} requests`);
      
      expect(successful.length).toBeGreaterThan(requestCount * 0.95); // 95% success rate
      expect(avgResponseTime).toBeLessThan(1000); // Under 1 second average
    });
  });
  
  describe('Data Consistency E2E Tests', () => {
    test('should maintain data integrity during concurrent updates', async () => {
      const userId = userSession.userId;
      const updatePromises = Array.from({ length: 10 }, (_, i) =>
        simulateHttpRequest({
          method: 'PUT',
          url: '/api/users/profile',
          headers: {
            'authorization': `Bearer ${userSession.accessToken}`
          },
          data: {
            firstName: `Update${i}`,
            lastName: 'TestUser'
          },
          expectedStatus: 200
        })
      );
      
      const results = await Promise.all(updatePromises);
      const successful = results.filter(r => r.success);
      
      // Get final state
      const finalState = await simulateHttpRequest({
        method: 'GET',
        url: '/api/users/profile',
        headers: {
          'authorization': `Bearer ${userSession.accessToken}`
        },
        expectedStatus: 200
      });
      
      expect(finalState.success).toBe(true);
      expect(successful.length).toBeGreaterThan(0);
    });
  });
});

// Helper functions for E2E testing

async function simulateHttpRequest(options: {
  method: string;
  url: string;
  data?: any;
  headers?: Record<string, string>;
  expectedStatus: number;
  timeout?: number;
}) {
  // In a real E2E test, this would make actual HTTP requests
  // For demo purposes, simulate responses
  
  const { method, url, data, headers, expectedStatus } = options;
  
  // Simulate various response scenarios
  if (url.includes('/api/health')) {
    return {
      success: true,
      status: 200,
      message: 'OK',
      data: { status: 'healthy', uptime: process.uptime() }
    };
  }
  
  if (url.includes('/api/auth/register') && method === 'POST') {
    return {
      success: expectedStatus === 201,
      status: expectedStatus,
      data: {
        user: {
          id: testDataGenerators.generateId(),
          email: data?.email || 'user@test.com',
          role: 'user'
        },
        accessToken: 'mock-access-token',
        refreshToken: 'mock-refresh-token'
      },
      message: 'User registered successfully'
    };
  }
  
  if (url.includes('/api/auth/login') && method === 'POST') {
    return {
      success: expectedStatus === 200,
      status: expectedStatus,
      data: {
        user: {
          id: 'user-123',
          email: data?.email || 'user@test.com',
          role: 'user'
        },
        accessToken: 'mock-access-token',
        refreshToken: 'mock-refresh-token'
      },
      message: 'Login successful'
    };
  }
  
  if (url.includes('/api/users/profile')) {
    if (method === 'GET') {
      return {
        success: expectedStatus === 200,
        status: expectedStatus,
        data: {
          user: {
            id: 'user-123',
            email: 'user@test.com',
            firstName: 'Test',
            lastName: 'User',
            role: 'user'
          }
        }
      };
    }
    
    if (method === 'PUT') {
      return {
        success: expectedStatus === 200,
        status: expectedStatus,
        data: {
          user: {
            id: 'user-123',
            email: 'user@test.com',
            firstName: data?.firstName || 'Updated',
            lastName: data?.lastName || 'User',
            role: 'user'
          }
        }
      };
    }
  }
  
  if (url.includes('/api/auth/forgot-password')) {
    return {
      success: true,
      status: 200,
      message: 'Password reset instructions sent to your email'
    };
  }
  
  // Default unauthorized response
  return {
    success: false,
    status: expectedStatus,
    error: expectedStatus === 401 ? 'Unauthorized' : 'Forbidden',
    message: expectedStatus === 401 ? 'Authorization header is required' : 'Insufficient permissions'
  };
}

async function createTestUserSession() {
  // Create a test user session
  return {
    email: 'e2e-test-user@example.com',
    userId: testDataGenerators.generateId(),
    accessToken: 'test-access-token',
    refreshToken: 'test-refresh-token'
  };
}

async function createAdminUser() {
  return {
    credentials: {
      email: 'admin@example.com',
      password: 'AdminPassword123!'
    },
    user: {
      id: testDataGenerators.generateId(),
      email: 'admin@example.com',
      role: 'admin'
    }
  };
}

async function getResetTokenFromEmail() {
  // Simulate getting reset token from email
  return 'mock-reset-token-' + Date.now();
}

async function getExpiredToken() {
  // Simulate expired token
  return 'expired-token-' + Date.now();
}

async function cleanupTestData() {
  // Cleanup any test data created during tests
  // In real implementation, this would clean up database records
  console.log('🧹 E2E test data cleaned up');
}
