import { test, expect } from '@playwright/test';
import { 
  registerUser, 
  login, 
  logout, 
  testData, 
  generateUniqueTestData,
  waitForLoading,
  checkForJSErrors,
  takeScreenshot,
  setupTestEnvironment,
  teardownTestEnvironment
} from './test-utils';

test.describe('User Registration Flow', () => {
  test.beforeEach(async ({ page }) => {
    await setupTestEnvironment(page);
    
    // Check for any JavaScript errors
    const errors = await checkForJSErrors(page);
    expect(errors).toHaveLength(0);
  });

  test.afterEach(async ({ page }) => {
    await teardownTestEnvironment(page);
  });

  test.describe('User Registration', () => {
    test('should register a new user successfully', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'REG001 - New user registration',
      });

      const uniqueData = generateUniqueTestData('registration');
      
      await test.step('Navigate to registration page', async () => {
        await page.goto('/register');
        await waitForLoading(page);
        
        // Verify we're on the registration page
        await expect(page.locator('h1, h2')).toContainText(/register|sign up/i);
        await takeScreenshot(page, 'registration-page');
      });

      await test.step('Fill registration form', async () => {
        // Fill form fields
        const emailInput = page.locator('input[name="email"], input[type="email"], input[id="email"]');
        const passwordInput = page.locator('input[name="password"], input[type="password"], input[id="password"]');
        const fullNameInput = page.locator('input[name="fullName"], input[id="fullName"]');
        
        await emailInput.waitFor({ state: 'visible' });
        await fullNameInput.waitFor({ state: 'visible' });
        
        await emailInput.fill(uniqueData.email);
        await passwordInput.fill(testData.user.password);
        await fullNameInput.fill('New Test User');
        
        await takeScreenshot(page, 'registration-form-filled');
      });

      await test.step('Submit registration form', async () => {
        // Click submit button
        const submitButton = page.locator('button[type="submit"], button:has-text("Register"), button:has-text("Sign Up")');
        await submitButton.click();
        
        // Wait for processing
        await waitForLoading(page);
      });

      await test.step('Verify successful registration', async () => {
        // Check if redirected to dashboard or login page
        await page.waitForURL('**/dashboard', { timeout: 10000 });
        
        // Take screenshot of dashboard
        await takeScreenshot(page, 'registration-success-dashboard');
        
        // Verify user is logged in
        const userMenu = page.locator('[data-testid="user-menu"], .user-menu, button:has-text("User")');
        await expect(userMenu).toBeVisible({ timeout: 5000 });
      });

      await test.step('Verify user can access AWS management', async () => {
        // Navigate to AWS management
        const awsLink = page.locator('a:has-text("AWS"), a:has-text("Cloud")');
        await awsLink.click();
        
        await waitForLoading(page);
        await takeScreenshot(page, 'aws-management-after-registration');
        
        // Verify AWS management page is accessible
        await expect(page.locator('h1, h2')).toBeVisible();
      });
    });

    test('should show validation errors for invalid input', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'REG002 - Registration form validation',
      });

      await test.step('Navigate to registration page', async () => {
        await page.goto('/register');
        await waitForLoading(page);
      });

      await test.step('Try to submit empty form', async () => {
        const submitButton = page.locator('button[type="submit"], button:has-text("Register")');
        await submitButton.click();
        
        // Check for validation messages
        await waitForLoading(page);
        await takeScreenshot(page, 'empty-form-validation');
        
        // Verify validation messages are shown
        const emailError = page.locator('input[name="email"] ~ .error, .error:has-text("email")');
        const passwordError = page.locator('input[name="password"] ~ .error, .error:has-text("password")');
        
        // At least one validation error should be visible
        const hasValidationErrors = await Promise.all([
          emailError.isVisible().catch(() => false),
          passwordError.isVisible().catch(() => false),
        ]);
        
        expect(hasValidationErrors.some(Boolean)).toBeTruthy();
      });

      await test.step('Try invalid email format', async () => {
        await page.fill('input[name="email"], input[type="email"]', 'invalid-email');
        await page.fill('input[name="password"]', testData.user.password);
        
        const submitButton = page.locator('button[type="submit"]');
        await submitButton.click();
        
        await waitForLoading(page);
        await takeScreenshot(page, 'invalid-email-validation');
        
        // Check for email format validation
        const emailError = page.locator('.error:has-text("email"), .error:has-text("valid")');
        await expect(emailError).toBeVisible();
      });
    });

    test('should prevent duplicate email registration', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'REG003 - Duplicate email prevention',
      });

      const duplicateEmail = 'duplicate@example.com';

      await test.step('Register first user', async () => {
        await page.goto('/register');
        await waitForLoading(page);
        
        await page.fill('input[name="email"]', duplicateEmail);
        await page.fill('input[name="password"]', testData.user.password);
        await page.fill('input[name="fullName"]', 'First User');
        
        await page.click('button[type="submit"]');
        await page.waitForURL('**/dashboard', { timeout: 10000 });
      });

      await test.step('Logout and try to register with same email', async () => {
        // Logout
        await logout(page);
        
        // Try to register with same email
        await page.goto('/register');
        await waitForLoading(page);
        
        await page.fill('input[name="email"]', duplicateEmail);
        await page.fill('input[name="password"]', 'DifferentPassword123!');
        await page.fill('input[name="fullName"]', 'Second User');
        
        await page.click('button[type="submit"]');
        await waitForLoading(page);
        await takeScreenshot(page, 'duplicate-email-error');
        
        // Check for duplicate email error
        const errorMessage = page.locator('.error, .alert-error, [role="alert"]');
        await expect(errorMessage).toContainText(/already exists|duplicate|exists/i);
      });
    });

    test('should navigate to login page after successful registration', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'REG004 - Post-registration navigation',
      });

      const uniqueData = generateUniqueTestData('navtest');
      
      await test.step('Navigate to registration page', async () => {
        await page.goto('/register');
        await waitForLoading(page);
      });

      await test.step('Fill and submit registration form', async () => {
        await page.fill('input[name="email"]', uniqueData.email);
        await page.fill('input[name="password"]', testData.user.password);
        await page.fill('input[name="fullName"]', 'Navigation Test User');
        
        await page.click('button[type="submit"]');
        
        // Wait for either dashboard or login redirect
        await Promise.race([
          page.waitForURL('**/dashboard', { timeout: 10000 }),
          page.waitForURL('**/login', { timeout: 10000 }),
        ]);
      });

      await test.step('Verify user can login with new credentials', async () => {
        // If redirected to login, try to login
        if (page.url().includes('/login')) {
          await login(page, uniqueData.email, testData.user.password);
        }
        
        // Should end up on dashboard
        await page.waitForURL('**/dashboard', { timeout: 5000 });
        await takeScreenshot(page, 'post-registration-dashboard');
        
        // Verify user menu shows correct info
        const userMenu = page.locator('[data-testid="user-menu"], .user-menu');
        await expect(userMenu).toBeVisible();
      });
    });

    test('should handle registration with different user roles', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'REG005 - User role assignment',
      });

      const uniqueData = generateUniqueTestData('roletest');

      await test.step('Register admin user', async () => {
        await page.goto('/register');
        await waitForLoading(page);
        
        await page.fill('input[name="email"]', uniqueData.email);
        await page.fill('input[name="password"]', testData.user.password);
        await page.fill('input[name="fullName"]', 'Admin User');
        
        await page.click('button[type="submit"]');
        await page.waitForURL('**/dashboard', { timeout: 10000 });
        
        await takeScreenshot(page, 'admin-registration-dashboard');
      });

      await test.step('Verify access to management features', async () => {
        // Check if admin features are accessible
        const adminLinks = [
          'a:has-text("User Management")',
          'a:has-text("Admin")',
          'a:has-text("Settings")',
        ];
        
        let adminAccessFound = false;
        for (const link of adminLinks) {
          if (await page.locator(link).isVisible()) {
            adminAccessFound = true;
            await takeScreenshot(page, 'admin-features-visible');
            break;
          }
        }
        
        // Note: This test verifies that admin users can see admin features
        // Actual visibility depends on the application's role-based access control
        console.log('Admin access features visible:', adminAccessFound);
      });
    });
  });

  test.describe('Registration Flow Integration', () => {
    test('should complete full registration to AWS management flow', async ({ page }) => {
      test.info().annotations.push({
        type: 'testcase',
        description: 'REG006 - Full registration to AWS management',
      });

      const uniqueData = generateUniqueTestData('fullflow');

      await test.step('Register new user', async () => {
        await registerUser(page, uniqueData.email, testData.user.password, 'Full Flow Test User');
        await takeScreenshot(page, 'full-flow-registered');
      });

      await test.step('Navigate to AWS management section', async () => {
        // Look for AWS management link
        const awsLinks = [
          'a:has-text("AWS")',
          'a:has-text("Cloud Management")',
          'nav a:has-text("AWS")',
        ];
        
        let clicked = false;
        for (const link of awsLinks) {
          try {
            if (await page.locator(link).isVisible()) {
              await page.click(link);
              clicked = true;
              break;
            }
          } catch (e) {
            continue;
          }
        }
        
        if (!clicked) {
          // If no AWS link found, try direct navigation
          await page.goto('/aws-management');
        }
        
        await waitForLoading(page);
        await takeScreenshot(page, 'aws-management-landing');
      });

      await test.step('Verify AWS management dashboard', async () => {
        // Verify AWS management features are accessible
        const awsFeatures = [
          'h1, h2',
          '[data-testid="aws-accounts"], .aws-accounts',
          'button:has-text("Add Account"), button:has-text("Connect AWS")',
        ];
        
        for (const feature of awsFeatures) {
          await expect(page.locator(feature)).toBeVisible({ timeout: 5000 });
        }
        
        await takeScreenshot(page, 'aws-management-dashboard');
      });

      await test.step('Verify user can add AWS account', async () => {
        // Try to add AWS account
        const addAccountButton = page.locator('button:has-text("Add Account"), button:has-text("Connect AWS")');
        await addAccountButton.click();
        
        await waitForLoading(page);
        await takeScreenshot(page, 'add-aws-account-modal');
        
        // Verify modal or form is opened
        const modal = page.locator('form, .modal, .dialog');
        await expect(modal).toBeVisible();
      });
    });
  });
});
