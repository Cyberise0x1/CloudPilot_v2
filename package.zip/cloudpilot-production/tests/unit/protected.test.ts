/**
 * Unit Tests for Protected Middleware
 * Comprehensive tests for authentication and authorization middleware
 */

import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { describe, test, expect, beforeEach, afterEach, jest } from '@jest/globals';

// Import the middleware and types
import { requireAuth, requireRole, UserRole, AuthenticatedUser } from '../../server/protected';

// Import test utilities and mocks
import { expressTestUtils, authTestUtils, responseValidation } from '../setup/express-test-utils';
import { getMock } from '../mocks/test-mocks';
import { envTestUtils } from '../setup/env-mocks';

// Mock JWT module
jest.mock('jsonwebtoken');

describe('Protected Middleware Unit Tests', () => {
  let mockReq: Partial<Request>;
  let mockRes: Partial<Response>;
  let mockNext: NextFunction;
  
  // Setup test environment
  beforeEach(() => {
    // Reset all mocks
    jest.clearAllMocks();
    
    // Setup test environment variables
    envTestUtils.setTestEnv({
      JWT_SECRET: 'test-jwt-secret-for-testing'
    });
    
    // Create fresh mock objects
    mockReq = expressTestUtils.createMockRequest();
    mockRes = expressTestUtils.createMockResponse();
    mockNext = expressTestUtils.createMockNext();
    
    // Mock JWT verify function
    (jwt.verify as jest.Mock).mockImplementation((token: string, secret: string) => {
      // Simulate JWT verification
      if (token === 'valid-token') {
        return {
          id: 'user-123',
          email: 'test@example.com',
          username: 'testuser',
          role: UserRole.USER,
          iat: Math.floor(Date.now() / 1000),
          exp: Math.floor(Date.now() / 1000) + 3600 // 1 hour from now
        };
      }
      throw new jwt.JsonWebTokenError('Invalid token');
    });
  });
  
  afterEach(() => {
    // Clean up
    envTestUtils.reset();
  });
  
  describe('requireAuth Middleware', () => {
    test('should authenticate valid JWT token', async () => {
      // Arrange
      mockReq.headers = {
        ...mockReq.headers,
        authorization: 'Bearer valid-token'
      };
      
      // Act
      await requireAuth(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert
      expect(mockNext).toHaveBeenCalledTimes(1);
      expect(mockReq.user).toBeDefined();
      expect(mockReq.user?.id).toBe('user-123');
      expect(mockReq.user?.email).toBe('test@example.com');
      expect(mockReq.user?.role).toBe(UserRole.USER);
    });
    
    test('should reject request without authorization header', async () => {
      // Arrange
      mockReq.headers = {
        ...mockReq.headers,
        // No authorization header
      };
      
      // Act
      await requireAuth(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert
      expect(mockNext).not.toHaveBeenCalled();
      expect(mockRes.status).toHaveBeenCalledWith(401);
      expect(mockRes.json).toHaveBeenCalledWith({
        message: 'Authorization header is required'
      });
    });
    
    test('should reject request with invalid token format', async () => {
      // Arrange
      mockReq.headers = {
        ...mockReq.headers,
        authorization: 'InvalidTokenFormat'
      };
      
      // Act
      await requireAuth(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert
      expect(mockNext).not.toHaveBeenCalled();
      expect(mockRes.status).toHaveBeenCalledWith(401);
      expect(mockRes.json).toHaveBeenCalledWith({
        message: 'Token is required'
      });
    });
    
    test('should reject invalid JWT token', async () => {
      // Arrange
      mockReq.headers = {
        ...mockReq.headers,
        authorization: 'Bearer invalid-token'
      };
      
      // Act
      await requireAuth(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert
      expect(mockNext).not.toHaveBeenCalled();
      expect(mockRes.status).toHaveBeenCalledWith(401);
      expect(mockRes.json).toHaveBeenCalledWith({
        message: 'Invalid token'
      });
    });
    
    test('should handle expired JWT token', async () => {
      // Arrange
      (jwt.verify as jest.Mock).mockImplementation(() => {
        throw new jwt.TokenExpiredError('Token expired', new Date());
      });
      
      mockReq.headers = {
        ...mockReq.headers,
        authorization: 'Bearer expired-token'
      };
      
      // Act
      await requireAuth(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert
      expect(mockNext).not.toHaveBeenCalled();
      expect(mockRes.status).toHaveBeenCalledWith(401);
      expect(mockRes.json).toHaveBeenCalledWith({
        message: 'Token expired'
      });
    });
    
    test('should reject request when JWT_SECRET is not set', async () => {
      // Arrange
      envTestUtils.unset('JWT_SECRET');
      
      mockReq.headers = {
        ...mockReq.headers,
        authorization: 'Bearer valid-token'
      };
      
      // Act
      await requireAuth(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert
      expect(mockNext).not.toHaveBeenCalled();
      expect(mockRes.status).toHaveBeenCalledWith(500);
      expect(mockRes.json).toHaveBeenCalledWith({
        message: 'Server configuration error'
      });
    });
    
    test('should handle unexpected errors gracefully', async () => {
      // Arrange
      (jwt.verify as jest.Mock).mockImplementation(() => {
        throw new Error('Unexpected error');
      });
      
      mockReq.headers = {
        ...mockReq.headers,
        authorization: 'Bearer valid-token'
      };
      
      // Act
      await requireAuth(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert
      expect(mockNext).not.toHaveBeenCalled();
      expect(mockRes.status).toHaveBeenCalledWith(500);
      expect(mockRes.json).toHaveBeenCalledWith({
        message: 'Internal server error'
      });
    });
    
    test('should work with Bearer token with space', async () => {
      // Arrange
      mockReq.headers = {
        ...mockReq.headers,
        authorization: 'Bearer valid-token'
      };
      
      // Act
      await requireAuth(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert
      expect(mockNext).toHaveBeenCalledTimes(1);
      expect(mockReq.user).toBeDefined();
    });
  });
  
  describe('requireRole Middleware', () => {
    beforeEach(() => {
      // Setup authenticated user for role tests
      mockReq.user = {
        id: 'user-123',
        email: 'test@example.com',
        username: 'testuser',
        role: UserRole.USER
      };
    });
    
    test('should allow user with required role', async () => {
      // Arrange
      const requireUserRole = requireRole(UserRole.USER);
      
      // Act
      await requireUserRole(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert
      expect(mockNext).toHaveBeenCalledTimes(1);
    });
    
    test('should allow admin user for any role', async () => {
      // Arrange
      mockReq.user = {
        ...mockReq.user!,
        role: UserRole.ADMIN
      };
      
      const requireUserRole = requireRole(UserRole.USER);
      
      // Act
      await requireUserRole(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert
      expect(mockNext).toHaveBeenCalledTimes(1);
    });
    
    test('should reject user without required role', async () => {
      // Arrange
      const requireManagerRole = requireRole(UserRole.MANAGER);
      
      // Act
      await requireManagerRole(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert
      expect(mockNext).not.toHaveBeenCalled();
      expect(mockRes.status).toHaveBeenCalledWith(403);
      const response = mockRes.json!.mock.calls[0][0];
      expect(response.message).toBe('Insufficient permissions');
      expect(response.requiredRoles).toContain(UserRole.MANAGER);
      expect(response.userRole).toBe(UserRole.USER);
    });
    
    test('should allow user with any of multiple roles', async () => {
      // Arrange
      const requireManagerOrAdmin = requireRole([UserRole.MANAGER, UserRole.ADMIN]);
      mockReq.user = {
        ...mockReq.user!,
        role: UserRole.ADMIN
      };
      
      // Act
      await requireManagerOrAdmin(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert
      expect(mockNext).toHaveBeenCalledTimes(1);
    });
    
    test('should reject user without any of multiple roles', async () => {
      // Arrange
      const requireManagerOrAdmin = requireRole([UserRole.MANAGER, UserRole.ADMIN]);
      
      // Act
      await requireManagerOrAdmin(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert
      expect(mockNext).not.toHaveBeenCalled();
      expect(mockRes.status).toHaveBeenCalledWith(403);
    });
    
    test('should reject unauthenticated request', async () => {
      // Arrange
      mockReq.user = undefined;
      const requireUserRole = requireRole(UserRole.USER);
      
      // Act
      await requireUserRole(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert
      expect(mockNext).not.toHaveBeenCalled();
      expect(mockRes.status).toHaveBeenCalledWith(401);
      expect(mockRes.json).toHaveBeenCalledWith({
        message: 'Authentication required'
      });
    });
  });
  
  describe('Integration Tests - Combined Middleware', () => {
    test('should handle complete authentication flow', async () => {
      // Arrange
      mockReq.headers = {
        ...mockReq.headers,
        authorization: 'Bearer valid-token'
      };
      
      // Act - First requireAuth
      await requireAuth(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert - User should be authenticated
      expect(mockNext).toHaveBeenCalledTimes(1);
      expect(mockReq.user).toBeDefined();
      
      // Reset mocks for next middleware test
      jest.clearAllMocks();
      mockRes.json = jest.fn().mockReturnThis();
      
      // Act - Then requireRole
      await requireRole(UserRole.USER)(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert - Should pass both middleware
      expect(mockNext).toHaveBeenCalledTimes(1);
    });
    
    test('should fail at authentication stage', async () => {
      // Arrange
      mockReq.headers = {
        ...mockReq.headers,
        // No authorization header
      };
      
      // Act
      await requireAuth(mockReq as Request, mockRes as Response, mockNext);
      await requireRole(UserRole.USER)(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert - Should fail at first middleware
      expect(mockNext).not.toHaveBeenCalled();
      expect(mockRes.status).toHaveBeenCalledWith(401);
    });
    
    test('should fail at authorization stage', async () => {
      // Arrange
      mockReq.headers = {
        ...mockReq.headers,
        authorization: 'Bearer valid-token'
      };
      
      // Act - Pass authentication
      await requireAuth(mockReq as Request, mockRes as Response, mockNext);
      
      // Reset mocks for authorization test
      jest.clearAllMocks();
      mockRes.json = jest.fn().mockReturnThis();
      
      // Act - Fail authorization (user role doesn't match)
      await requireRole(UserRole.ADMIN)(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert - Should fail at authorization
      expect(mockNext).not.toHaveBeenCalled();
      expect(mockRes.status).toHaveBeenCalledWith(403);
    });
  });
  
  describe('Edge Cases and Error Handling', () => {
    test('should handle malformed authorization header', async () => {
      // Arrange
      mockReq.headers = {
        ...mockReq.headers,
        authorization: 'Bearer ' // Bearer with space but no token
      };
      
      // Act
      await requireAuth(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert
      expect(mockNext).not.toHaveBeenCalled();
      expect(mockRes.status).toHaveBeenCalledWith(401);
      expect(mockRes.json).toHaveBeenCalledWith({
        message: 'Token is required'
      });
    });
    
    test('should handle empty authorization header', async () => {
      // Arrange
      mockReq.headers = {
        ...mockReq.headers,
        authorization: ''
      };
      
      // Act
      await requireAuth(mockReq as Request, mockRes as Response, mockNext);
      
      // Assert
      expect(mockNext).not.toHaveBeenCalled();
      expect(mockRes.status).toHaveBeenCalledWith(401);
      expect(mockRes.json).toHaveBeenCalledWith({
        message: 'Authorization header is required'
      });
    });
    
    test('should work with custom UserRole enum values', async () => {
      // Test all enum values work correctly
      const roleValues = [UserRole.ADMIN, UserRole.MANAGER, UserRole.USER, UserRole.VIEWER];
      
      for (const role of roleValues) {
        mockReq.user = {
          ...mockReq.user!,
          role: role
        };
        
        const requireSpecificRole = requireRole(role);
        await requireSpecificRole(mockReq as Request, mockRes as Response, mockNext);
        
        expect(mockNext).toHaveBeenCalled();
        
        // Reset for next iteration
        jest.clearAllMocks();
        mockRes.json = jest.fn().mockReturnThis();
      }
    });
  });
  
  describe('Performance Tests', () => {
    test('should handle high volume of requests', async () => {
      // Arrange
      const requestCount = 1000;
      const startTime = Date.now();
      
      // Act
      for (let i = 0; i < requestCount; i++) {
        mockReq.headers = {
          ...mockReq.headers,
          authorization: 'Bearer valid-token'
        };
        await requireAuth(mockReq as Request, mockRes as Response, mockNext);
        jest.clearAllMocks();
      }
      
      const endTime = Date.now();
      const duration = endTime - startTime;
      
      // Assert - Should complete within reasonable time (less than 10 seconds)
      expect(duration).toBeLessThan(10000);
      console.log(`Processed ${requestCount} requests in ${duration}ms`);
    });
  });
});

// Test with custom matchers
describe('Custom Matchers Demo', () => {
  test('demonstrate custom test utilities', () => {
    // Demonstrate custom matchers
    const testDate = new Date('2024-01-01');
    const startDate = new Date('2023-01-01');
    const endDate = new Date('2025-01-01');
    
    expect(testDate).toBeWithinRange(startDate, endDate);
    expect('test@example.com').toBeValidEmail();
    expect('550e8400-e29b-41d4-a716-446655440000').toBeValidUUID();
  });
});
