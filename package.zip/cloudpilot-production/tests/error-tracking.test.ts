/**
 * Comprehensive tests for Error Tracking and Alerting System
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { 
  ErrorClassifier,
  ErrorAggregator,
  AlertManager,
  PerformanceTracker,
  ErrorAnalytics,
  ErrorTrackingSystem,
  createErrorTracking,
  getErrorTracking,
  errorTrackingMiddleware,
  type ErrorCategory,
  type ErrorSeverity,
  type ErrorInstance,
  type AlertRule,
  type PerformanceImpact
} from '../server/error-tracking-local';

// Mock dependencies
vi.mock('crypto', () => ({
  createHash: vi.fn(() => ({
    update: vi.fn().mockReturnThis(),
    digest: vi.fn(() => 'mocked-hash')
  }))
}));

// Mock fetch for notifications
global.fetch = vi.fn();

describe('Error Tracking System', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('ErrorClassifier', () => {
    describe('Error Classification', () => {
      it('should classify validation errors', () => {
        const validationError = new Error('Invalid input format');
        const result = ErrorClassifier.classifyError(validationError);

        expect(result.category).toBe('validation');
      });

      it('should classify authentication errors', () => {
        const authError = new Error('Unauthorized access');
        const result = ErrorClassifier.classifyError(authError);

        expect(result.category).toBe('authentication');
      });

      it('should classify authorization errors', () => {
        const authzError = new Error('403 Forbidden: Access denied');
        const result = ErrorClassifier.classifyError(authzError);

        expect(result.category).toBe('authorization');
      });

      it('should classify AWS errors', () => {
        const awsError = new Error('AWS S3 service unavailable');
        const result = ErrorClassifier.classifyError(awsError);

        expect(result.category).toBe('aws');
      });

      it('should classify database errors', () => {
        const dbError = new Error('PostgreSQL connection failed');
        const result = ErrorClassifier.classifyError(dbError);

        expect(result.category).toBe('database');
      });

      it('should classify network errors', () => {
        const networkError = new Error('Connection timeout');
        const result = ErrorClassifier.classifyError(networkError);

        expect(result.category).toBe('network');
      });

      it('should classify system errors', () => {
        const systemError = new Error('Out of memory');
        const result = ErrorClassifier.classifyError(systemError);

        expect(result.category).toBe('system');
      });

      it('should classify string errors', () => {
        const result = ErrorClassifier.classifyError('Database query failed');

        expect(result.category).toBe('database');
      });

      it('should default to application category for unknown errors', () => {
        const unknownError = new Error('Something unexpected happened');
        const result = ErrorClassifier.classifyError(unknownError);

        expect(result.category).toBe('application');
      });

      it('should determine severity levels correctly', () => {
        const authError = new Error('Unauthorized');
        const awsError = new Error('AWS service down');
        const dbError = new Error('Database connection failed');
        const validationError = new Error('Invalid input');
        const fatalError = new Error('Fatal crash');

        const authResult = ErrorClassifier.classifyError(authError);
        const awsResult = ErrorClassifier.classifyError(awsError);
        const dbResult = ErrorClassifier.classifyError(dbError);
        const validationResult = ErrorClassifier.classifyError(validationError);
        const fatalResult = ErrorClassifier.classifyError(fatalError);

        expect(authResult.severity).toBe('high');
        expect(awsResult.severity).toBe('critical');
        expect(dbResult.severity).toBe('critical');
        expect(validationResult.severity).toBe('medium');
        expect(fatalResult.severity).toBe('critical');
      });
    });

    describe('Recovery Suggestions', () => {
      it('should generate suggestions for validation errors', () => {
        const validationError = new Error('Invalid email format');
        const suggestions = ErrorClassifier.generateRecoverySuggestions(validationError, 'validation');

        expect(suggestions).toContain('Check input data format and required fields');
        expect(suggestions).toContain('Validate data against schema before processing');
        expect(suggestions).toContain('Implement client-side validation to catch errors early');
      });

      it('should generate suggestions for authentication errors', () => {
        const authError = new Error('Authentication token expired');
        const suggestions = ErrorClassifier.generateRecoverySuggestions(authError, 'authentication');

        expect(suggestions).toContain('Verify API keys and credentials');
        expect(suggestions).toContain('Check token expiration and refresh if needed');
        expect(suggestions).toContain('Ensure proper authentication middleware is configured');
      });

      it('should generate suggestions for AWS errors', () => {
        const awsError = new Error('AWS S3 access denied');
        const suggestions = ErrorClassifier.generateRecoverySuggestions(awsError, 'aws');

        expect(suggestions).toContain('Check AWS service limits and quotas');
        expect(suggestions).toContain('Verify IAM permissions for the service');
        expect(suggestions).toContain('Review AWS CloudWatch logs for detailed errors');
        expect(suggestions).toContain('Check AWS service status page for outages');
      });

      it('should generate suggestions for database errors', () => {
        const dbError = new Error('Database connection pool exhausted');
        const suggestions = ErrorClassifier.generateRecoverySuggestions(dbError, 'database');

        expect(suggestions).toContain('Check database connection pool configuration');
        expect(suggestions).toContain('Verify database server availability');
        expect(suggestions).toContain('Review query performance and add indexes if needed');
        expect(suggestions).toContain('Check for database locks or deadlocks');
      });

      it('should generate suggestions for network errors', () => {
        const networkError = new Error('Connection timeout');
        const suggestions = ErrorClassifier.generateRecoverySuggestions(networkError, 'network');

        expect(suggestions).toContain('Implement retry logic with exponential backoff');
        expect(suggestions).toContain('Check network connectivity and firewalls');
        expect(suggestions).toContain('Increase timeout values for slow connections');
      });

      it('should generate suggestions for system errors', () => {
        const systemError = new Error('Out of memory');
        const suggestions = ErrorClassifier.generateRecoverySuggestions(systemError, 'system');

        expect(suggestions).toContain('Monitor system resources (CPU, memory, disk)');
        expect(suggestions).toContain('Scale up resources if necessary');
        expect(suggestions).toContain('Check for memory leaks in the application');
        expect(suggestions).toContain('Review system logs for hardware issues');
      });

      it('should generate general suggestions for application errors', () => {
        const appError = new Error('Something went wrong');
        const suggestions = ErrorClassifier.generateRecoverySuggestions(appError, 'application');

        expect(suggestions).toContain('Check application logs for detailed error information');
        expect(suggestions).toContain('Review recent code changes that might have introduced the issue');
        expect(suggestions).toContain('Test the functionality in a development environment');
      });
    });
  });

  describe('ErrorAggregator', () => {
    let aggregator: ErrorAggregator;

    beforeEach(() => {
      aggregator = new ErrorAggregator();
    });

    describe('Error Deduplication', () => {
      it('should generate unique fingerprints for different errors', () => {
        const error1 = new Error('Database connection failed');
        const error2 = new Error('Authentication failed');
        const metadata1 = {
          category: 'database' as ErrorCategory,
          severity: 'high' as ErrorSeverity,
          timestamp: new Date()
        };
        const metadata2 = {
          category: 'authentication' as ErrorCategory,
          severity: 'high' as ErrorSeverity,
          timestamp: new Date()
        };

        const fingerprint1 = aggregator.generateFingerprint(error1, metadata1);
        const fingerprint2 = aggregator.generateFingerprint(error2, metadata2);

        expect(fingerprint1).not.toBe(fingerprint2);
      });

      it('should generate same fingerprints for similar errors', () => {
        const error1 = new Error('Database connection failed');
        const error2 = new Error('Database connection failed');
        const metadata = {
          category: 'database' as ErrorCategory,
          severity: 'high' as ErrorSeverity,
          timestamp: new Date(),
          endpoint: '/api/users'
        };

        const fingerprint1 = aggregator.generateFingerprint(error1, metadata);
        const fingerprint2 = aggregator.generateFingerprint(error2, metadata);

        expect(fingerprint1).toBe(fingerprint2);
      });

      it('should deduplicate errors correctly', () => {
        const error = new Error('Database connection failed');
        const metadata = {
          category: 'database' as ErrorCategory,
          severity: 'high' as ErrorSeverity,
          timestamp: new Date(),
          endpoint: '/api/users'
        };

        const instance1 = aggregator.addError(error, metadata);
        const instance2 = aggregator.addError(error, metadata);

        expect(instance1.id).toBe(instance2.id);
        expect(instance1.count).toBe(1);
        expect(instance2.count).toBe(2);
        expect(instance1.lastOccurrence).not.toBe(instance2.lastOccurrence);
      });

      it('should create new error instances for unique errors', () => {
        const error1 = new Error('Database connection failed');
        const error2 = new Error('Authentication failed');
        const metadata1 = {
          category: 'database' as ErrorCategory,
          severity: 'high' as ErrorSeverity,
          timestamp: new Date()
        };
        const metadata2 = {
          category: 'authentication' as ErrorCategory,
          severity: 'high' as ErrorSeverity,
          timestamp: new Date()
        };

        const instance1 = aggregator.addError(error1, metadata1);
        const instance2 = aggregator.addError(error2, metadata2);

        expect(instance1.id).not.toBe(instance2.id);
        expect(instance1.count).toBe(1);
        expect(instance2.count).toBe(1);
      });
    });

    describe('Error Management', () => {
      beforeEach(() => {
        const error = new Error('Test error');
        const metadata = {
          category: 'application' as ErrorCategory,
          severity: 'medium' as ErrorSeverity,
          timestamp: new Date()
        };
        aggregator.addError(error, metadata);
      });

      it('should retrieve all errors', () => {
        const errors = aggregator.getErrors();
        expect(errors.length).toBe(1);
        expect(errors[0].message).toBe('Test error');
      });

      it('should filter errors by category', () => {
        const authError = new Error('Auth failed');
        aggregator.addError(authError, {
          category: 'authentication' as ErrorCategory,
          severity: 'high' as ErrorSeverity,
          timestamp: new Date()
        });

        const dbErrors = aggregator.getErrors({ category: 'authentication' });
        expect(dbErrors.length).toBe(1);
        expect(dbErrors[0].message).toBe('Auth failed');
      });

      it('should filter errors by severity', () => {
        const criticalError = new Error('Critical error');
        aggregator.addError(criticalError, {
          category: 'application' as ErrorCategory,
          severity: 'critical' as ErrorSeverity,
          timestamp: new Date()
        });

        const criticalErrors = aggregator.getErrors({ severity: 'critical' });
        expect(criticalErrors.length).toBe(1);
        expect(criticalErrors[0].message).toBe('Critical error');
      });

      it('should filter errors by status', () => {
        const errors = aggregator.getErrors();
        expect(errors[0].status).toBe('active');

        const activeErrors = aggregator.getErrors({ status: 'active' });
        expect(activeErrors.length).toBe(1);
      });

      it('should filter errors by time', () => {
        const now = new Date();
        const recent = aggregator.getErrors({ since: new Date(now.getTime() - 1000) });
        expect(recent.length).toBe(1);

        const old = aggregator.getErrors({ since: new Date(now.getTime() + 1000) });
        expect(old.length).toBe(0);
      });

      it('should get error by fingerprint', () => {
        const error = new Error('Test error');
        const metadata = {
          category: 'application' as ErrorCategory,
          severity: 'medium' as ErrorSeverity,
          timestamp: new Date()
        };
        const instance = aggregator.addError(error, metadata);

        const retrieved = aggregator.getErrorByFingerprint(instance.fingerprint);
        expect(retrieved).toBeDefined();
        expect(retrieved?.message).toBe('Test error');
      });

      it('should resolve errors', () => {
        const error = new Error('Test error');
        const metadata = {
          category: 'application' as ErrorCategory,
          severity: 'medium' as ErrorSeverity,
          timestamp: new Date()
        };
        const instance = aggregator.addError(error, metadata);

        const result = aggregator.resolveError(instance.fingerprint);
        expect(result).toBe(true);

        const resolvedError = aggregator.getErrorByFingerprint(instance.fingerprint);
        expect(resolvedError?.status).toBe('resolved');
      });

      it('should ignore errors', () => {
        const error = new Error('Test error');
        const metadata = {
          category: 'application' as ErrorCategory,
          severity: 'medium' as ErrorSeverity,
          timestamp: new Date()
        };
        const instance = aggregator.addError(error, metadata);

        const result = aggregator.ignoreError(instance.fingerprint);
        expect(result).toBe(true);

        const ignoredError = aggregator.getErrorByFingerprint(instance.fingerprint);
        expect(ignoredError?.status).toBe('ignored');
      });

      it('should cleanup old resolved errors', () => {
        const oldError = new Error('Old error');
        const oldMetadata = {
          category: 'application' as ErrorCategory,
          severity: 'low' as ErrorSeverity,
          timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000) // 2 hours ago
        };
        const instance = aggregator.addError(oldError, oldMetadata);
        aggregator.resolveError(instance.fingerprint);

        const cleaned = aggregator.cleanupOldErrors(1); // 1 hour retention
        expect(cleaned).toBe(1);

        const remaining = aggregator.getErrors();
        expect(remaining.length).toBe(0);
      });
    });
  });

  describe('AlertManager', () => {
    let alertManager: AlertManager;

    beforeEach(() => {
      alertManager = new AlertManager();
    });

    describe('Alert Rules Management', () => {
      it('should add alert rules', () => {
        const rule: AlertRule = {
          id: 'test-rule',
          name: 'Test Alert',
          severity: 'critical',
          threshold: { count: 5, timeWindow: 10, occurrences: 1 },
          enabled: true,
          channels: ['webhook'],
          cooldown: 5
        };

        alertManager.addRule(rule);
        const retrieved = alertManager.getRule('test-rule');
        
        expect(retrieved).toEqual(rule);
      });

      it('should remove alert rules', () => {
        const rule: AlertRule = {
          id: 'remove-me',
          name: 'Remove Alert',
          threshold: { count: 1, timeWindow: 5, occurrences: 1 },
          enabled: true,
          channels: ['webhook'],
          cooldown: 5
        };

        alertManager.addRule(rule);
        const removed = alertManager.removeRule('remove-me');
        expect(removed).toBe(true);

        const retrieved = alertManager.getRule('remove-me');
        expect(retrieved).toBeUndefined();
      });

      it('should get all alert rules', () => {
        alertManager.addRule({
          id: 'rule1',
          name: 'Rule 1',
          threshold: { count: 1, timeWindow: 5, occurrences: 1 },
          enabled: true,
          channels: ['webhook'],
          cooldown: 5
        });

        alertManager.addRule({
          id: 'rule2',
          name: 'Rule 2',
          threshold: { count: 1, timeWindow: 5, occurrences: 1 },
          enabled: true,
          channels: ['email'],
          cooldown: 5
        });

        const allRules = alertManager.getAllRules();
        expect(allRules.length).toBeGreaterThanOrEqual(2);
      });

      it('should configure notification channels', () => {
        const webhookConfig = { url: 'https://example.com/webhook' };
        alertManager.configureNotification('webhook', webhookConfig);

        const config = (alertManager as any).notificationConfigs.get('webhook');
        expect(config).toEqual(webhookConfig);
      });
    });

    describe('Alert Checking and Triggering', () => {
      let mockErrorInstance: ErrorInstance;

      beforeEach(() => {
        mockErrorInstance = {
          id: 'test-error',
          message: 'Test error message',
          stack: 'Error stack trace',
          metadata: {
            category: 'database',
            severity: 'critical',
            timestamp: new Date()
          },
          fingerprint: 'test-fingerprint',
          count: 1,
          firstOccurrence: new Date(),
          lastOccurrence: new Date(),
          status: 'active'
        };
      });

      it('should trigger alerts based on severity', async () => {
        const alertSpy = vi.fn();
        alertManager.on('alert', alertSpy);

        await alertManager.checkAlerts(mockErrorInstance);

        expect(alertSpy).toHaveBeenCalled();
      });

      it('should respect cooldowns between alerts', async () => {
        const alertSpy = vi.fn();
        alertManager.on('alert', alertSpy);

        // First trigger
        await alertManager.checkAlerts(mockErrorInstance);
        expect(alertSpy).toHaveBeenCalledTimes(1);

        // Immediate second trigger should be skipped due to cooldown
        await alertManager.checkAlerts(mockErrorInstance);
        expect(alertSpy).toHaveBeenCalledTimes(1); // Still 1
      });

      it('should filter alerts by category', async () => {
        alertManager.addRule({
          id: 'category-rule',
          name: 'Category Filter',
          category: 'authentication',
          threshold: { count: 1, timeWindow: 5, occurrences: 1 },
          enabled: true,
          channels: ['webhook'],
          cooldown: 5
        });

        const alertSpy = vi.fn();
        alertManager.on('alert', alertSpy);

        // This error is database category, not authentication
        await alertManager.checkAlerts(mockErrorInstance);
        expect(alertSpy).not.toHaveBeenCalled();
      });

      it('should filter alerts by severity', async () => {
        alertManager.addRule({
          id: 'severity-rule',
          name: 'Severity Filter',
          severity: 'low',
          threshold: { count: 1, timeWindow: 5, occurrences: 1 },
          enabled: true,
          channels: ['webhook'],
          cooldown: 5
        });

        const alertSpy = vi.fn();
        alertManager.on('alert', alertSpy);

        // This error is critical, not low
        await alertManager.checkAlerts(mockErrorInstance);
        expect(alertSpy).not.toHaveBeenCalled();
      });
    });

    describe('Notification Channels', () => {
      let mockRule: AlertRule;
      let mockErrorInstance: ErrorInstance;

      beforeEach(() => {
        mockRule = {
          id: 'test-rule',
          name: 'Test Alert',
          threshold: { count: 1, timeWindow: 5, occurrences: 1 },
          enabled: true,
          channels: ['webhook'],
          cooldown: 5
        };

        mockErrorInstance = {
          id: 'test-error',
          message: 'Test error message',
          metadata: {
            category: 'database',
            severity: 'critical',
            timestamp: new Date(),
            endpoint: '/api/test'
          },
          fingerprint: 'test-fingerprint',
          count: 1,
          firstOccurrence: new Date(),
          lastOccurrence: new Date(),
          status: 'active'
        };
      });

      it('should send webhook notifications', async () => {
        const webhookConfig = {
          url: 'https://example.com/webhook',
          headers: { 'Authorization': 'Bearer token' },
          method: 'POST'
        };
        alertManager.configureNotification('webhook', webhookConfig);

        const mockFetch = vi.mocked(fetch);
        mockFetch.mockResolvedValueOnce({
          ok: true,
          status: 200
        } as any);

        await (alertManager as any).sendWebhookNotification(mockRule, mockErrorInstance);

        expect(mockFetch).toHaveBeenCalledWith(webhookConfig.url, {
          method: webhookConfig.method,
          headers: {
            'Content-Type': 'application/json',
            ...webhookConfig.headers
          },
          body: expect.any(String)
        });
      });

      it('should handle webhook notification failures', async () => {
        const webhookConfig = { url: 'https://example.com/webhook' };
        alertManager.configureNotification('webhook', webhookConfig);

        const mockFetch = vi.mocked(fetch);
        mockFetch.mockRejectedValueOnce(new Error('Network error'));

        const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});

        await (alertManager as any).sendWebhookNotification(mockRule, mockErrorInstance);

        expect(consoleSpy).toHaveBeenCalledWith(
          'Failed to send webhook notification:',
          expect.any(Error)
        );

        consoleSpy.mockRestore();
      });

      it('should send email notifications', async () => {
        const emailConfig = {
          to: ['admin@example.com'],
          from: 'system@example.com',
          subject: 'Alert: Test Error'
        };
        alertManager.configureNotification('email', emailConfig);

        const consoleSpy = vi.spyOn(console, 'log').mockImplementation(() => {});

        await (alertManager as any).sendEmailNotification(mockRule, mockErrorInstance);

        expect(consoleSpy).toHaveBeenCalledWith({
          to: emailConfig.to,
          from: emailConfig.from,
          subject: emailConfig.subject,
          body: expect.any(String)
        });

        consoleSpy.mockRestore();
      });

      it('should send Slack notifications', async () => {
        const slackConfig = {
          webhookUrl: 'https://hooks.slack.com/test',
          channel: '#alerts',
          username: 'ErrorBot'
        };
        alertManager.configureNotification('slack', slackConfig);

        const mockFetch = vi.mocked(fetch);
        mockFetch.mockResolvedValueOnce({
          ok: true,
          status: 200
        } as any);

        await (alertManager as any).sendSlackNotification(mockRule, mockErrorInstance);

        expect(mockFetch).toHaveBeenCalledWith(slackConfig.webhookUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: expect.stringContaining('attachments')
        });
      });

      it('should send SMS notifications', async () => {
        const smsConfig = {
          to: ['+1234567890'],
          provider: 'twilio'
        };
        alertManager.configureNotification('sms', smsConfig);

        const consoleSpy = vi.spyOn(console, 'log').mockImplementation(() => {});

        await (alertManager as any).sendSMSNotification(mockRule, mockErrorInstance);

        expect(consoleSpy).toHaveBeenCalledWith({
          to: smsConfig.to,
          provider: smsConfig.provider,
          message: expect.stringContaining('ALERT')
        });

        consoleSpy.mockRestore();
      });

      it('should warn when notification channel is not configured', async () => {
        const consoleSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});

        await (alertManager as any).sendNotification('webhook', mockRule, mockErrorInstance);

        expect(consoleSpy).toHaveBeenCalledWith(
          'No configuration found for webhook channel'
        );

        consoleSpy.mockRestore();
      });
    });
  });

  describe('PerformanceTracker', () => {
    let performanceTracker: PerformanceTracker;

    beforeEach(() => {
      performanceTracker = new PerformanceTracker();
    });

    it('should record requests', () => {
      performanceTracker.recordRequest('/api/users', 100, false);
      performanceTracker.recordRequest('/api/posts', 200, true);

      const metrics = performanceTracker.getPerformanceMetrics('/api/users');
      expect(metrics.has('/api/users')).toBe(true);

      const postMetrics = performanceTracker.getPerformanceMetrics('/api/posts');
      expect(postMetrics.has('/api/posts')).toBe(true);
    });

    it('should calculate performance metrics correctly', () => {
      // Add multiple requests
      performanceTracker.recordRequest('/api/test', 100, false);
      performanceTracker.recordRequest('/api/test', 200, false);
      performanceTracker.recordRequest('/api/test', 300, false);
      performanceTracker.recordRequest('/api/test', 400, false);
      performanceTracker.recordRequest('/api/test', 500, true); // 1 error out of 5

      const metrics = performanceTracker.getPerformanceMetrics('/api/test');
      const metric = metrics.get('/api/test');

      expect(metric).toBeDefined();
      expect(metric?.avgResponseTime).toBeGreaterThan(0);
      expect(metric?.errorRate).toBeGreaterThan(0);
      expect(metric?.throughput).toBeGreaterThan(0);
    });

    it('should track requests without errors', () => {
      performanceTracker.recordRequest('/api/success', 150, false);

      const metrics = performanceTracker.getPerformanceMetrics('/api/success');
      const metric = metrics.get('/api/success');

      expect(metric?.errorRate).toBe(0);
    });

    it('should limit tracked requests per endpoint', () => {
      // Add more than 1000 requests
      for (let i = 0; i < 1005; i++) {
        performanceTracker.recordRequest('/api/busy', 100 + i, false);
      }

      const metrics = performanceTracker.getPerformanceMetrics('/api/busy');
      const metric = metrics.get('/api/busy');

      expect(metric).toBeDefined();
      // Should have trimmed old requests
      expect(metric?.avgResponseTime).toBeGreaterThan(1000);
    });

    it('should get error correlation data', () => {
      performanceTracker.recordRequest('/api/test', 100, false);
      performanceTracker.recordRequest('/api/test', 200, false);

      const correlations = performanceTracker.getErrorCorrelation('/api/test', 60);
      expect(correlations).toHaveLength(2);
      expect(correlations[0]).toHaveProperty('requestId');
      expect(correlations[0]).toHaveProperty('timeline');
    });
  });

  describe('ErrorAnalytics', () => {
    let analytics: ErrorAnalytics;

    beforeEach(() => {
      analytics = new ErrorAnalytics();
    });

    it('should record error instances', () => {
      const errorInstance: ErrorInstance = {
        id: 'test-error',
        message: 'Test error',
        metadata: {
          category: 'database',
          severity: 'high',
          timestamp: new Date()
        },
        fingerprint: 'test-fp',
        count: 1,
        firstOccurrence: new Date(),
        lastOccurrence: new Date(),
        status: 'active'
      };

      analytics.recordErrorInstance(errorInstance);

      const errors = analytics.getErrorTrends();
      const dbErrors = errors.byCategory.get('database');
      expect(dbErrors).toBe(1);
    });

    it('should calculate error trends', () => {
      const now = new Date();
      
      // Add errors for different categories
      for (let i = 0; i < 5; i++) {
        const errorInstance: ErrorInstance = {
          id: `db-error-${i}`,
          message: `Database error ${i}`,
          metadata: {
            category: 'database',
            severity: 'high',
            timestamp: now
          },
          fingerprint: `db-fp-${i}`,
          count: 1,
          firstOccurrence: now,
          lastOccurrence: now,
          status: 'active'
        };
        analytics.recordErrorInstance(errorInstance);
      }

      for (let i = 0; i < 3; i++) {
        const errorInstance: ErrorInstance = {
          id: `auth-error-${i}`,
          message: `Auth error ${i}`,
          metadata: {
            category: 'authentication',
            severity: 'critical',
            timestamp: now
          },
          fingerprint: `auth-fp-${i}`,
          count: 1,
          firstOccurrence: now,
          lastOccurrence: now,
          status: 'active'
        };
        analytics.recordErrorInstance(errorInstance);
      }

      const trends = analytics.getErrorTrends(24);
      expect(trends.byCategory.get('database')).toBe(5);
      expect(trends.byCategory.get('authentication')).toBe(3);
    });

    it('should calculate hourly distribution', () => {
      const now = new Date();
      
      for (let hour = 0; hour < 24; hour++) {
        const timestamp = new Date(now.getTime() - (23 - hour) * 60 * 60 * 1000);
        timestamp.setHours(hour);
        
        const errorInstance: ErrorInstance = {
          id: `error-${hour}`,
          message: `Error at hour ${hour}`,
          metadata: {
            category: 'application',
            severity: 'medium',
            timestamp
          },
          fingerprint: `fp-${hour}`,
          count: 1,
          firstOccurrence: timestamp,
          lastOccurrence: timestamp,
          status: 'active'
        };
        analytics.recordErrorInstance(errorInstance);
      }

      const trends = analytics.getErrorTrends(24);
      expect(trends.hourlyDistribution.length).toBe(24);
      expect(trends.hourlyDistribution.reduce((a, b) => a + b, 0)).toBe(24);
    });

    it('should get top errors by count', () => {
      // Add multiple errors with different counts
      for (let i = 0; i < 10; i++) {
        const errorInstance: ErrorInstance = {
          id: `frequent-error`,
          message: 'Frequent error',
          metadata: {
            category: 'application',
            severity: 'medium',
            timestamp: new Date()
          },
          fingerprint: 'frequent-fp',
          count: i + 1,
          firstOccurrence: new Date(),
          lastOccurrence: new Date(),
          status: 'active'
        };
        analytics.recordErrorInstance(errorInstance);
      }

      const topErrors = analytics.getTopErrors(5);
      expect(topErrors.length).toBeLessThanOrEqual(5);
      expect(topErrors[0]?.count).toBe(10);
    });

    it('should analyze error patterns', () => {
      // Add errors with patterns
      for (let i = 0; i < 5; i++) {
        const errorInstance: ErrorInstance = {
          id: `pattern-error-${i}`,
          message: 'Pattern error',
          metadata: {
            category: 'database',
            severity: 'high',
            timestamp: new Date(),
            endpoint: '/api/users',
            method: 'POST'
          },
          fingerprint: `pattern-fp-${i}`,
          count: 1,
          firstOccurrence: new Date(),
          lastOccurrence: new Date(),
          status: 'active'
        };
        analytics.recordErrorInstance(errorInstance);
      }

      const patterns = analytics.getErrorPatterns();
      expect(patterns.frequentCombinations).toBeDefined();
      expect(patterns.timeBasedPatterns).toBeDefined();
    });
  });

  describe('ErrorTrackingSystem', () => {
    let errorSystem: ErrorTrackingSystem;

    beforeEach(() => {
      errorSystem = new ErrorTrackingSystem();
    });

    describe('Error Tracking', () => {
      it('should track errors with metadata', async () => {
        const error = new Error('Database connection failed');
        const metadata = {
          endpoint: '/api/users',
          method: 'GET',
          duration: 150
        };

        const errorInstance = await errorSystem.trackError(error, metadata);

        expect(errorInstance).toBeDefined();
        expect(errorInstance.message).toBe('Database connection failed');
        expect(errorInstance.metadata.endpoint).toBe('/api/users');
        expect(errorInstance.metadata.method).toBe('GET');
        expect(errorInstance.metadata.duration).toBe(150);
      });

      it('should track string errors', async () => {
        const errorInstance = await errorSystem.trackError('Something went wrong');

        expect(errorInstance).toBeDefined();
        expect(errorInstance.message).toBe('Something went wrong');
      });

      it('should add errors to aggregator', async () => {
        const error = new Error('Test error');
        await errorSystem.trackError(error);

        const errors = errorSystem.getErrors();
        expect(errors.length).toBe(1);
      });

      it('should emit error events', async () => {
        const eventSpy = vi.fn();
        errorSystem.on('error', eventSpy);

        await errorSystem.trackError('Test error');

        expect(eventSpy).toHaveBeenCalledWith(expect.objectContaining({
          message: 'Test error'
        }));
      });
    });

    describe('Performance Tracking', () => {
      it('should track successful requests', () => {
        errorSystem.trackRequest('/api/users', 100, { userId: '123' });

        const metrics = errorSystem.getPerformanceMetrics('/api/users');
        expect(metrics.has('/api/users')).toBe(true);
      });

      it('should emit request events', () => {
        const eventSpy = vi.fn();
        errorSystem.on('request', eventSpy);

        errorSystem.trackRequest('/api/test', 200);

        expect(eventSpy).toHaveBeenCalledWith({
          endpoint: '/api/test',
          duration: 200,
          metadata: {
            timestamp: expect.any(Date),
            endpoint: '/api/test'
          }
        });
      });
    });

    describe('Error Management', () => {
      beforeEach(async () => {
        await errorSystem.trackError('Test error');
      });

      it('should get active errors', () => {
        const activeErrors = errorSystem.getActiveErrors();
        expect(activeErrors.length).toBe(1);
        expect(activeErrors[0].status).toBe('active');
      });

      it('should get all errors with filters', () => {
        const allErrors = errorSystem.getErrors();
        expect(allErrors.length).toBe(1);

        const filtered = errorSystem.getErrors({ category: 'application' });
        expect(filtered.length).toBe(1);
      });

      it('should resolve errors', () => {
        const error = new Error('Test error');
        const instance = errorSystem.trackError(error);
        
        const resolved = errorSystem.resolveError(instance.fingerprint);
        expect(resolved).toBe(true);

        const activeErrors = errorSystem.getActiveErrors();
        expect(activeErrors.length).toBe(0);
      });

      it('should ignore errors', () => {
        const error = new Error('Test error');
        const instance = errorSystem.trackError(error);
        
        const ignored = errorSystem.ignoreError(instance.fingerprint);
        expect(ignored).toBe(true);

        const activeErrors = errorSystem.getActiveErrors();
        expect(activeErrors.length).toBe(0);
      });
    });

    describe('Analytics and Reporting', () => {
      beforeEach(async () => {
        await errorSystem.trackError('Database error');
        await errorSystem.trackError('Auth error');
        await errorSystem.trackError('Database error'); // Duplicate
      });

      it('should get error trends', () => {
        const trends = errorSystem.getErrorTrends();
        
        expect(trends).toHaveProperty('byCategory');
        expect(trends).toHaveProperty('bySeverity');
        expect(trends).toHaveProperty('hourlyDistribution');
      });

      it('should get top errors', () => {
        const topErrors = errorSystem.getTopErrors(10);
        
        expect(topErrors.length).toBeGreaterThan(0);
        expect(topErrors[0]).toHaveProperty('count');
      });

      it('should get error patterns', () => {
        const patterns = errorSystem.getErrorPatterns();
        
        expect(patterns).toHaveProperty('frequentCombinations');
        expect(patterns).toHaveProperty('timeBasedPatterns');
      });

      it('should get system statistics', () => {
        const stats = errorSystem.getSystemStats();
        
        expect(stats).toEqual({
          totalErrors: expect.any(Number),
          activeErrors: expect.any(Number),
          resolvedErrors: expect.any(Number),
          ignoredErrors: expect.any(Number),
          avgErrorRate: expect.any(Number),
          topCategories: expect.any(Array)
        });
      });
    });

    describe('Alert Management', () => {
      it('should add alert rules', () => {
        const rule: AlertRule = {
          id: 'test-rule',
          name: 'Test Alert',
          threshold: { count: 1, timeWindow: 5, occurrences: 1 },
          enabled: true,
          channels: ['webhook'],
          cooldown: 5
        };

        errorSystem.addAlertRule(rule);
        const rules = errorSystem.getAlertRules();
        
        expect(rules.some(r => r.id === 'test-rule')).toBe(true);
      });

      it('should configure notifications', () => {
        const config = { url: 'https://example.com/webhook' };
        errorSystem.configureNotifications('webhook', config);

        // This would be tested through the alert system
        expect(errorSystem).toBeDefined();
      });
    });
  });

  describe('Factory Functions', () => {
    it('should create error tracking system', () => {
      const system = createErrorTracking();
      expect(system).toBeInstanceOf(ErrorTrackingSystem);
    });

    it('should return same instance on subsequent calls', () => {
      const system1 = createErrorTracking();
      const system2 = createErrorTracking();
      
      expect(system1).toBe(system2);
    });

    it('should throw error if not initialized', () => {
      // Reset the singleton
      (createErrorTracking as any)._instance = null;
      
      expect(() => getErrorTracking()).toThrow();
    });
  });

  describe('Express Middleware', () => {
    let mockReq: any;
    let mockRes: any;
    let mockNext: any;
    let originalErrorTracking: any;

    beforeEach(() => {
      originalErrorTracking = getErrorTracking;
      mockReq = {
        path: '/api/test',
        method: 'GET',
        headers: {
          'user-agent': 'test-agent',
          'x-request-id': 'req-123'
        },
        ip: '192.168.1.1',
        startTime: Date.now() - 100
      };
      mockRes = {};
      mockNext = vi.fn();
    });

    afterEach(() => {
      // Restore original
      if (originalErrorTracking) {
        (global as any).getErrorTracking = originalErrorTracking;
      }
    });

    it('should track errors automatically', () => {
      const mockTrackError = vi.fn();
      const mockSystem = {
        trackError: mockTrackError
      };
      (global as any).getErrorTracking = () => mockSystem;

      const error = new Error('Test error');
      const middleware = errorTrackingMiddleware();
      
      middleware(error, mockReq, mockRes, mockNext);

      expect(mockTrackError).toHaveBeenCalledWith(error, expect.objectContaining({
        requestId: 'req-123',
        endpoint: '/api/test',
        method: 'GET',
        userAgent: 'test-agent',
        ip: '192.168.1.1',
        duration: expect.any(Number)
      }));
      expect(mockNext).toHaveBeenCalledWith(error);
    });

    it('should skip excluded paths', () => {
      const mockTrackError = vi.fn();
      const mockSystem = {
        trackError: mockTrackError
      };
      (global as any).getErrorTracking = () => mockSystem;

      const error = new Error('Test error');
      const middleware = errorTrackingMiddleware();
      
      mockReq.path = '/health'; // This should be excluded

      middleware(error, mockReq, mockRes, mockNext);

      expect(mockTrackError).not.toHaveBeenCalled();
      expect(mockNext).toHaveBeenCalledWith(error);
    });

    it('should include custom metadata', () => {
      const mockTrackError = vi.fn();
      const mockSystem = {
        trackError: mockTrackError
      };
      (global as any).getErrorTracking = () => mockSystem;

      const error = new Error('Test error');
      const customMetadata = (req: any, res: any) => ({
        userRole: req.user?.role || 'anonymous'
      });
      const middleware = errorTrackingMiddleware({ customMetadata });
      
      mockReq.user = { role: 'admin' };

      middleware(error, mockReq, mockRes, mockNext);

      expect(mockTrackError).toHaveBeenCalledWith(error, expect.objectContaining({
        userRole: 'admin'
      }));
    });

    it('should handle missing request metadata gracefully', () => {
      const mockTrackError = vi.fn();
      const mockSystem = {
        trackError: mockTrackError
      };
      (global as any).getErrorTracking = () => mockSystem;

      const error = new Error('Test error');
      const middleware = errorTrackingMiddleware();
      
      delete mockReq.headers['x-request-id'];
      delete mockReq.ip;
      delete mockReq.startTime;

      middleware(error, mockReq, mockRes, mockNext);

      expect(mockTrackError).toHaveBeenCalled();
    });
  });

  describe('Integration Scenarios', () => {
    it('should handle complete error lifecycle', async () => {
      const errorSystem = createErrorTracking();

      // Track an error
      const error1 = await errorSystem.trackError('Database connection failed', {
        endpoint: '/api/users',
        method: 'GET'
      });

      // Track same error again (should deduplicate)
      const error2 = await errorSystem.trackError('Database connection failed', {
        endpoint: '/api/users',
        method: 'GET'
      });

      expect(error1.id).toBe(error2.id);
      expect(error1.count).toBe(1);
      expect(error2.count).toBe(2);

      // Resolve the error
      const resolved = errorSystem.resolveError(error1.fingerprint);
      expect(resolved).toBe(true);

      // Should not appear in active errors
      const activeErrors = errorSystem.getActiveErrors();
      expect(activeErrors.length).toBe(0);

      // Should appear in all errors
      const allErrors = errorSystem.getErrors();
      expect(allErrors.length).toBe(1);
      expect(allErrors[0].status).toBe('resolved');
    });

    it('should handle alert triggering flow', async () => {
      const errorSystem = createErrorTracking();
      
      // Configure webhook notification
      const mockFetch = vi.mocked(fetch);
      mockFetch.mockResolvedValueOnce({ ok: true, status: 200 } as any);
      
      errorSystem.configureNotifications('webhook', {
        url: 'https://example.com/webhook'
      });

      // Add critical error rule
      errorSystem.addAlertRule({
        id: 'critical-errors',
        name: 'Critical Error Alert',
        severity: 'critical',
        threshold: { count: 1, timeWindow: 5, occurrences: 1 },
        enabled: true,
        channels: ['webhook'],
        cooldown: 5
      });

      // Track a critical error
      const alertSpy = vi.fn();
      errorSystem.on('alert', alertSpy);

      await errorSystem.trackError('Critical AWS failure', {
        category: 'aws',
        severity: 'critical',
        endpoint: '/api/aws/操作'
      });

      // Should have triggered alert (in a real scenario)
      expect(errorSystem).toBeDefined();
    });

    it('should correlate errors with performance metrics', async () => {
      const errorSystem = createErrorTracking();

      // Track some successful requests
      errorSystem.trackRequest('/api/users', 100);
      errorSystem.trackRequest('/api/users', 150);
      errorSystem.trackRequest('/api/users', 200);

      // Track an error
      await errorSystem.trackError('Database timeout', {
        endpoint: '/api/users',
        method: 'GET',
        duration: 5000 // Very slow
      });

      const performanceMetrics = errorSystem.getPerformanceMetrics('/api/users');
      const metric = performanceMetrics.get('/api/users');

      expect(metric).toBeDefined();
      expect(metric?.avgResponseTime).toBeGreaterThan(0);
      expect(metric?.errorRate).toBeGreaterThan(0);
    });
  });
});
