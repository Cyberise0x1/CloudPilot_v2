# Audit Trail System Documentation

## Table of Contents
1. [System Overview](#system-overview)
2. [Audit Events Reference](#audit-events-reference)
3. [Audit Endpoints Usage](#audit-endpoints-usage)
4. [Audit Middleware Configuration](#audit-middleware-configuration)
5. [Compliance Features](#compliance-features)
6. [Audit Retention Policies](#audit-retention-policies)
7. [Audit Export Procedures](#audit-export-procedures)
8. [Security Monitoring](#security-monitoring)
9. [Troubleshooting Guide](#troubleshooting-guide)

---

## System Overview

The CloudPilot Audit Trail System provides comprehensive tracking of all system activities, security events, and user actions. The system is designed to meet compliance requirements while providing real-time monitoring capabilities.

### Core Components

#### 1. Database Schema
The audit system uses three main database tables:

**`audit_logs`** - Main audit log table
- Tracks all user actions and system events
- Supports pagination and filtering
- Indexed for performance optimization

**`audit_sessions`** - Session tracking
- Monitors user login sessions
- Tracks session duration and activities
- Supports active session management

**`audit_events`** - Security and system events
- Detailed event tracking with severity levels
- Before/after value comparison for changes
- Supports metadata and correlation

#### 2. Storage Layer (`server/storage.ts`)
- **AuditQueue**: Batch processing system with automatic flushing
- **Context Management**: Preserves audit context across async operations
- **Performance Optimization**: Batch database operations and memory protection
- **Data Sanitization**: Automatic masking of sensitive information

#### 3. API Routes (`server/audit-routes.ts`)
RESTful endpoints for audit data access and management:
- Filtered log retrieval
- User activity tracking
- Security event monitoring
- Data export capabilities
- Analytics and reporting

#### 4. Audit Service (`server/services/audit-service.ts`)
Comprehensive audit management service with:
- Advanced querying and filtering
- Trend analysis and reporting
- Retention policy management
- Export functionality (JSON, CSV, XML)
- Suspicious activity detection

---

## Audit Events Reference

### Event Categories

#### Authentication Events
| Action | Description | Severity | Category |
|--------|-------------|----------|----------|
| `user.login` | Successful user login | info | AUTHENTICATION |
| `user.logout` | User logout | info | AUTHENTICATION |
| `user.login.failed` | Failed login attempt | warning | AUTHENTICATION |
| `user.password.reset` | Password reset requested | warning | AUTHENTICATION |
| `user.password.changed` | Password changed | warning | AUTHENTICATION |
| `session.expired` | Session timeout | info | AUTHENTICATION |

#### User Management Events
| Action | Description | Severity | Category |
|--------|-------------|----------|----------|
| `user.create` | New user created | info | USER_MANAGEMENT |
| `user.update` | User information updated | info | USER_MANAGEMENT |
| `user.delete` | User deleted | critical | USER_MANAGEMENT |
| `user.role.change` | User role modified | warning | USER_MANAGEMENT |

#### AWS Resource Events
| Action | Description | Severity | Category |
|--------|-------------|----------|----------|
| `instance.launch` | EC2 instance launched | info | AWS_EC2 |
| `instance.terminate` | EC2 instance terminated | warning | AWS_EC2 |
| `instance.start` | EC2 instance started | info | AWS_EC2 |
| `instance.stop` | EC2 instance stopped | info | AWS_EC2 |
| `bucket.create` | S3 bucket created | info | AWS_S3 |
| `bucket.delete` | S3 bucket deleted | warning | AWS_S3 |
| `rds.create` | RDS instance created | info | AWS_RDS |
| `rds.delete` | RDS instance deleted | warning | AWS_RDS |
| `cloudfront.create` | CloudFront distribution created | info | AWS_CLOUDFRONT |
| `cloudfront.delete` | CloudFront distribution deleted | warning | AWS_CLOUDFRONT |

#### Security Events
| Action | Description | Severity | Category |
|--------|-------------|----------|----------|
| `security.unauthorized` | Unauthorized access attempt | critical | SECURITY |
| `security.suspicious` | Suspicious activity detected | critical | SECURITY |
| `security.violation` | Security policy violation | critical | SECURITY |
| `rate.limit.exceeded` | Rate limit exceeded | warning | SECURITY |

#### System Events
| Action | Description | Severity | Category |
|--------|-------------|----------|----------|
| `system.error` | System error occurred | error | SYSTEM |
| `system.warning` | System warning | warning | SYSTEM |
| `api.rate.limit` | API rate limit triggered | info | SYSTEM |
| `api.usage` | API usage event | info | SYSTEM |

### Severity Levels

- **info**: Informational events, normal operations
- **warning**: Potential issues, important events
- **error**: Error conditions, failed operations
- **critical**: Security incidents, system failures

### Event Structure

```typescript
interface AuditEvent {
  id: string;
  userId: string;
  userEmail?: string;
  action: string;
  resource: string;
  resourceId?: string;
  status: 'success' | 'failure' | 'pending';
  details?: Record<string, any>;
  ipAddress?: string;
  userAgent?: string;
  severity: 'info' | 'warning' | 'error' | 'critical';
  category: string;
  metadata?: Record<string, any>;
  executionTime?: number;
  createdAt: Date;
  updatedAt: Date;
}
```

---

## Audit Endpoints Usage

### Authentication
All audit endpoints require JWT token authentication and admin role authorization.

```bash
curl -H "Authorization: Bearer <jwt-token>" \
  -H "Content-Type: application/json" \
  https://api.example.com/api/audit/...
```

### Endpoint Reference

#### GET `/api/audit/logs`
Retrieve filtered audit logs with pagination.

**Query Parameters:**
- `userId` - Filter by user ID
- `action` - Filter by action type
- `resourceType` - Filter by resource type
- `resourceId` - Filter by resource ID
- `status` - Filter by status (success/failure/pending)
- `severity` - Filter by severity level
- `startDate` / `endDate` - Date range filter (ISO 8601)
- `limit` - Number of records (default: 100, max: 1000)
- `offset` - Pagination offset (default: 0)
- `sortBy` - Sort field (createdAt, userId, action, resource)
- `sortOrder` - Sort order (asc, desc)

**Example:**
```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.example.com/api/audit/logs?userId=user-123&limit=50&sortBy=createdAt&sortOrder=desc"
```

**Response:**
```json
{
  "logs": [
    {
      "id": "audit-123",
      "userId": "user-123",
      "action": "instance.launch",
      "resource": "AWS_EC2",
      "status": "success",
      "severity": "info",
      "createdAt": "2024-01-15T10:30:00Z",
      "details": {
        "instanceType": "t2.micro",
        "region": "us-east-1"
      }
    }
  ],
  "pagination": {
    "total": 150,
    "offset": 0,
    "limit": 50,
    "hasMore": true
  }
}
```

#### GET `/api/audit/user/:userId`
Get complete audit trail for a specific user.

**Example:**
```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.example.com/api/audit/user/user-123?limit=20&page=1"
```

**Response:**
```json
{
  "user": {
    "id": "user-123",
    "email": "user@example.com",
    "role": "admin"
  },
  "logs": [...],
  "statistics": {
    "totalActions": 150,
    "successRate": 95.3,
    "topActions": [
      { "action": "instance.launch", "count": 45 },
      { "action": "bucket.create", "count": 23 }
    ]
  },
  "pagination": {...}
}
```

#### GET `/api/audit/resource/:type/:id`
Get audit trail for a specific resource.

**Parameters:**
- `type` - Resource type (EC2_INSTANCE, S3_BUCKET, RDS_INSTANCE, etc.)
- `id` - Resource ID

**Example:**
```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.example.com/api/audit/resource/EC2_INSTANCE/i-1234567890abcdef0"
```

#### GET `/api/audit/security`
Retrieve security-related events with filtering.

**Query Parameters:**
- `severity` - Filter by severity (info, warning, error, critical)
- `eventType` - Filter by event type
- `startDate` / `endDate` - Date range
- `limit` / `offset` - Pagination

**Example:**
```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.example.com/api/audit/security?severity=critical&limit=100"
```

#### GET `/api/audit/export`
Export audit data in various formats.

**Query Parameters:**
- `format` - Export format (json, csv, xml)
- `startDate` / `endDate` - Date range filter
- `userId`, `action`, `resourceType` - Additional filters
- `includeMetadata` - Include metadata (default: true)
- `includeDetails` - Include detailed information (default: false)

**Example:**
```bash
# Export as CSV
curl -H "Authorization: Bearer <token>" \
  "https://api.example.com/api/audit/export?format=csv&startDate=2024-01-01&endDate=2024-01-31" \
  --output audit-export.csv

# Export as JSON
curl -H "Authorization: Bearer <token>" \
  "https://api.example.com/api/audit/export?format=json&category=SECURITY" \
  --output security-audit.json
```

#### GET `/api/audit/analytics`
Get comprehensive audit analytics and insights.

**Example:**
```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.example.com/api/audit/analytics?startDate=2024-01-01&endDate=2024-01-31"
```

**Response:**
```json
{
  "totalEvents": 1250,
  "uniqueUsers": 45,
  "uniqueResources": 128,
  "successRate": 94.2,
  "averageExecutionTime": 245,
  "topActions": [
    { "action": "instance.launch", "count": 234 }
  ],
  "topUsers": [
    { "userId": "user-123", "userEmail": "admin@example.com", "count": 156 }
  ],
  "failuresByAction": [
    { "action": "instance.launch", "failureCount": 12, "failureRate": 5.1 }
  ],
  "suspiciousActivity": [
    {
      "userId": "user-456",
      "reason": "Multiple IP addresses",
      "details": { "ipCount": 8, "ipAddresses": ["192.168.1.1", "10.0.0.1", ...] }
    }
  ]
}
```

#### GET `/api/audit/trends`
Get audit trends and patterns.

**Query Parameters:**
- `period` - Analysis period (1d, 7d, 30d, 90d)
- `action` - Filter by specific action
- `resource` - Filter by resource type
- `category` - Filter by category

**Example:**
```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.example.com/api/audit/trends?period=7d&category=AUTHENTICATION"
```

---

## Audit Middleware Configuration

### Request Logging Middleware
Automatically logs all HTTP requests with correlation tracking.

```typescript
import { requestLoggingMiddleware } from './middleware/logger';

app.use(requestLoggingMiddleware);
```

**Features:**
- Correlation ID generation and tracking
- Request/response time monitoring
- User context capture
- IP address and user agent logging

### Performance Monitoring Middleware
Monitors request performance and alerts on slow operations.

```typescript
import { performanceMiddleware } from './middleware/logger';

app.use(performanceMiddleware(1000)); // 1 second threshold
```

### Security Middleware
Logs security-related events and suspicious activity.

```typescript
import { securityMiddleware } from './middleware/logger';

app.use(securityMiddleware);
```

**Detects:**
- Suspicious URL patterns
- Bot/crawler activity
- Authentication attempts
- Rate limit violations

### User Context Middleware
Captures and logs user context for all requests.

```typescript
import { userContextMiddleware } from './middleware/logger';

app.use(userContextMiddleware);
```

### Error Logging Middleware
Logs all errors with full context and stack traces.

```typescript
import { errorLoggingMiddleware } from './middleware/logger';

app.use(errorLoggingMiddleware);
```

### AWS Operation Logging
Logs AWS service operations with detailed context.

```typescript
import { awsOperationLogger } from './middleware/logger';

const logger = awsOperationLogger('EC2');

logger.before('LaunchInstances', 'i-1234567890abcdef0', { instanceType: 't2.micro' });
logger.after('LaunchInstances', 'i-1234567890abcdef0', { success: true });
logger.error('LaunchInstances', 'i-1234567890abcdef0', error);
```

### Integration Example

```typescript
import express from 'express';
import { 
  requestLoggingMiddleware,
  performanceMiddleware,
  securityMiddleware,
  userContextMiddleware,
  errorLoggingMiddleware
} from './middleware/logger';

const app = express();

// Audit middleware stack
app.use(requestLoggingMiddleware);
app.use(securityMiddleware);
app.use(userContextMiddleware);
app.use(performanceMiddleware(2000)); // 2 second threshold

// Your routes here

// Error handling
app.use(errorLoggingMiddleware);
```

---

## Compliance Features

### Regulatory Compliance

#### SOC 2 Type II
- Complete audit trail for all system access
- User activity tracking and monitoring
- Security event logging and alerting
- Data retention and archival policies

#### GDPR Compliance
- User activity tracking for data subject requests
- IP address and user agent logging
- Data processing activity logs
- Right to be forgotten support

#### HIPAA Compliance
- Access control audit trails
- PHI access logging
- Security incident tracking
- Audit log integrity controls

#### ISO 27001
- Information security event logging
- User access monitoring
- System change tracking
- Security control verification

### Compliance Controls

#### Data Integrity
- Immutable audit log records
- Before/after value tracking
- Digital signatures for log entries
- Hash-based integrity verification

#### Access Controls
- Role-based access to audit data
- Authentication required for all audit endpoints
- Admin-only access to sensitive audit functions
- Audit trail for audit data access

#### Data Retention
- Configurable retention policies by category
- Automatic data archival
- Legal hold capabilities
- Secure data disposal

#### Monitoring and Alerting
- Real-time security event monitoring
- Suspicious activity detection
- Automated alerting for critical events
- Compliance dashboard and reporting

### Compliance Configuration

```typescript
// Configure compliance settings
const complianceConfig = {
  retentionPolicies: [
    {
      category: 'SECURITY',
      retentionDays: 2555, // 7 years
      severityRetentionDays: {
        critical: 2555,
        high: 2555,
        medium: 1825, // 5 years
        low: 365     // 1 year
      }
    },
    {
      category: 'USER_MANAGEMENT',
      retentionDays: 2555
    },
    {
      category: 'AWS_EC2',
      retentionDays: 1095 // 3 years
    }
  ],
  encryption: {
    enabled: true,
    algorithm: 'AES-256'
  },
  signing: {
    enabled: true,
    algorithm: 'SHA-256'
  }
};
```

---

## Audit Retention Policies

### Policy Management

#### Default Retention Periods
| Category | Default Retention | Severity Adjustments |
|----------|------------------|---------------------|
| SECURITY | 7 years | Critical: 10 years |
| USER_MANAGEMENT | 7 years | - |
| AUTHENTICATION | 3 years | Failed login: 1 year |
| AWS_EC2 | 3 years | - |
| AWS_S3 | 3 years | - |
| SYSTEM | 1 year | Errors: 3 years |

### Configuration

#### Set Retention Policy
```typescript
await auditService.configureRetentionPolicy({
  category: 'SECURITY',
  retentionDays: 2555, // 7 years
  severityRetentionDays: {
    critical: 3650,  // 10 years
    high: 2555,      // 7 years
    medium: 1825,    // 5 years
    low: 365         // 1 year
  },
  isActive: true
});
```

#### Get Retention Policies
```typescript
const policies = await auditService.getRetentionPolicies();
console.log(policies);
```

### Automated Cleanup

#### Run Cleanup Process
```typescript
const result = await auditService.cleanupExpiredLogs();
console.log(`Deleted ${result.deletedCount} expired audit logs`);
```

#### Scheduled Cleanup
```typescript
// Run cleanup daily at 2 AM
const cleanupJob = cron.schedule('0 2 * * *', async () => {
  try {
    const result = await auditService.cleanupExpiredLogs();
    logger.info(`Audit cleanup completed: ${result.deletedCount} logs deleted`);
  } catch (error) {
    logger.error('Audit cleanup failed', { error });
  }
});
```

### Archive Strategy

#### Archive Instead of Delete
For long-term compliance, consider archiving instead of deleting:

```typescript
const archivePolicy = {
  categories: ['SECURITY', 'USER_MANAGEMENT'],
  archiveAfter: 90, // days
  archiveLocation: 's3://compliance-archive/',
  encryptionEnabled: true
};
```

#### Archive Audit Data
```typescript
async function archiveAuditData(category: string, cutoffDate: Date) {
  const logs = await auditService.queryAuditLogs({
    category,
    endDate: cutoffDate
  });

  const archiveData = await auditService.exportAuditLogs({
    category,
    format: 'json',
    startDate: new Date(0),
    endDate: cutoffDate
  });

  // Upload to secure archive location
  await uploadToSecureArchive(archiveData.data, `${category}-${cutoffDate.toISOString()}.json`);
  
  // Delete from primary storage
  await deleteAuditLogs(category, cutoffDate);
}
```

---

## Audit Export Procedures

### Export Formats

#### JSON Export
```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.example.com/api/audit/export?format=json&startDate=2024-01-01&endDate=2024-01-31" \
  --output audit-logs.json
```

#### CSV Export
```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.example.com/api/audit/export?format=csv&category=SECURITY" \
  --output security-audit.csv
```

#### XML Export
```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.example.com/api/audit/export?format=xml&userId=user-123" \
  --output user-audit.xml
```

### Programmatic Export

#### Export with Filters
```typescript
const exportOptions: ExportAuditLogsOptions = {
  startDate: new Date('2024-01-01'),
  endDate: new Date('2024-01-31'),
  userId: ['user-123', 'user-456'],
  action: ['instance.launch', 'bucket.create'],
  category: ['AWS_EC2', 'AWS_S3'],
  format: 'csv',
  includeMetadata: true,
  includeDetails: false
};

const exportResult = await auditService.exportAuditLogs(exportOptions);
console.log(`Exported ${exportResult.recordCount} records to ${exportResult.filename}`);
```

#### Batch Export Script
```typescript
async function performBatchExport() {
  const categories = ['SECURITY', 'USER_MANAGEMENT', 'AWS_EC2'];
  const startDate = new Date('2024-01-01');
  const endDate = new Date('2024-01-31');
  
  for (const category of categories) {
    const exportResult = await auditService.exportAuditLogs({
      category,
      startDate,
      endDate,
      format: 'json'
    });
    
    // Save to secure location
    await saveToSecureStorage(exportResult.data, exportResult.filename);
    
    console.log(`Exported ${exportResult.recordCount} ${category} records`);
  }
}
```

### Export Validation

#### Verify Export Integrity
```typescript
async function verifyExport(exportData: string, format: string): Promise<boolean> {
  try {
    switch (format) {
      case 'json':
        const jsonData = JSON.parse(exportData);
        return Array.isArray(jsonData) && jsonData.length > 0;
        
      case 'csv':
        const lines = exportData.split('\n');
        return lines.length > 1 && lines[0].includes('ID,User ID,Action');
        
      case 'xml':
        return exportData.includes('<auditLogs>') && exportData.includes('</auditLogs>');
        
      default:
        return false;
    }
  } catch (error) {
    logger.error('Export verification failed', { error });
    return false;
  }
}
```

### Secure Export Procedures

#### Encrypted Export
```typescript
async function exportWithEncryption(options: ExportAuditLogsOptions) {
  const exportResult = await auditService.exportAuditLogs(options);
  
  // Encrypt the export data
  const encryptedData = await encryptData(exportResult.data);
  
  // Save encrypted file
  await saveEncryptedFile(encryptedData, exportResult.filename + '.encrypted');
  
  // Generate decryption key for compliance
  const decryptionKey = generateDecryptionKey();
  
  return {
    filename: exportResult.filename + '.encrypted',
    recordCount: exportResult.recordCount,
    decryptionKey,
    encryptionAlgorithm: 'AES-256'
  };
}
```

#### Secure Transfer
```typescript
async function secureExportTransfer(exportData: string, destination: string) {
  // Sign the export data
  const signature = await signData(exportData);
  
  // Create secure package
  const securePackage = {
    data: exportData,
    signature,
    timestamp: new Date().toISOString(),
    exportedBy: getCurrentUserId(),
    checksum: await calculateChecksum(exportData)
  };
  
  // Transfer to destination with integrity verification
  await secureTransfer(securePackage, destination);
}
```

---

## Security Monitoring

### Real-time Monitoring

#### Security Dashboard
```typescript
// Get real-time security metrics
const securityMetrics = await auditService.getAuditAnalytics({
  category: 'SECURITY'
});

console.log({
  totalSecurityEvents: securityMetrics.totalEvents,
  criticalEvents: securityMetrics.failuresByAction.filter(a => a.failureRate > 50),
  suspiciousUsers: securityMetrics.suspiciousActivity
});
```

#### Monitor Failed Login Attempts
```typescript
async function monitorFailedLogins() {
  const failedLogins = await auditService.queryAuditLogs({
    action: 'user.login.failed',
    startDate: new Date(Date.now() - 24 * 60 * 60 * 1000), // Last 24 hours
    limit: 1000
  });
  
  const ipCounts = new Map<string, number>();
  const userCounts = new Map<string, number>();
  
  failedLogins.forEach(log => {
    const ip = log.ipAddress;
    const user = log.userId;
    
    if (ip) ipCounts.set(ip, (ipCounts.get(ip) || 0) + 1);
    if (user) userCounts.set(user, (userCounts.get(user) || 0) + 1);
  });
  
  // Alert on suspicious patterns
  for (const [ip, count] of ipCounts) {
    if (count > 10) {
      await alertSecurityTeam('High failed login count', {
        ip,
        count,
        timeRange: '24 hours'
      });
    }
  }
}
```

#### Monitor Unusual Activity Patterns
```typescript
async function detectUnusualActivity() {
  const recentActivity = await auditService.getAuditTrends({
    period: '1d'
  });
  
  // Detect users with unusually high activity
  recentActivity.userActivity.forEach(user => {
    if (user.count > 100) { // Threshold for unusual activity
      logger.warn('Unusual user activity detected', {
        userId: user.userId,
        actionCount: user.count,
        timeRange: '24 hours'
      });
    }
  });
  
  // Detect rapid successive actions
  const rapidActions = recentActivity.hourlyTrends.filter(hour => hour.count > 50);
  if (rapidActions.length > 0) {
    logger.warn('High activity periods detected', {
      periods: rapidActions
    });
  }
}
```

### Automated Alerts

#### Alert Configuration
```typescript
const alertRules = [
  {
    name: 'Multiple Failed Logins',
    condition: (logs: AuditLog[]) => {
      const failedLogins = logs.filter(log => 
        log.action === 'user.login.failed' &&
        log.createdAt > new Date(Date.now() - 15 * 60 * 1000) // Last 15 minutes
      );
      return failedLogins.length > 5;
    },
    severity: 'warning',
    action: 'notify_security_team'
  },
  {
    name: 'Critical Security Event',
    condition: (logs: AuditLog[]) => {
      return logs.some(log => 
        log.severity === 'critical' &&
        log.category === 'SECURITY' &&
        log.createdAt > new Date(Date.now() - 5 * 60 * 1000) // Last 5 minutes
      );
    },
    severity: 'critical',
    action: 'immediate_alert'
  }
];
```

#### Alert Implementation
```typescript
async function checkAlertRules() {
  const recentLogs = await auditService.queryAuditLogs({
    startDate: new Date(Date.now() - 60 * 60 * 1000), // Last hour
    limit: 10000
  });
  
  for (const rule of alertRules) {
    if (rule.condition(recentLogs)) {
      await triggerAlert(rule, recentLogs);
    }
  }
}

// Run alert checks every 5 minutes
setInterval(checkAlertRules, 5 * 60 * 1000);
```

### Security Metrics

#### Key Performance Indicators
```typescript
async function generateSecurityMetrics() {
  const analytics = await auditService.getAuditAnalytics({
    category: 'SECURITY'
  });
  
  const metrics = {
    securityPosture: {
      totalEvents: analytics.totalEvents,
      successRate: analytics.successRate,
      averageResponseTime: analytics.averageExecutionTime
    },
    threatDetection: {
      suspiciousActivityCount: analytics.suspiciousActivity.length,
      criticalEvents: analytics.failuresByAction.filter(f => f.failureRate > 50).length,
      highRiskUsers: analytics.topUsers.filter(u => u.count > 100).length
    },
    complianceStatus: {
      dataRetentionCompliance: await checkRetentionCompliance(),
      auditLogIntegrity: await verifyLogIntegrity(),
      accessControlCompliance: await verifyAccessControls()
    }
  };
  
  return metrics;
}
```

#### Threat Intelligence
```typescript
async function analyzeThreatPatterns() {
  const securityEvents = await auditService.queryAuditLogs({
    category: 'SECURITY',
    startDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) // Last 30 days
  });
  
  const patterns = {
    attackVectors: analyzeAttackVectors(securityEvents),
    geographicDistribution: analyzeGeographicDistribution(securityEvents),
    temporalPatterns: analyzeTemporalPatterns(securityEvents),
    userBehavior: analyzeUserBehavior(securityEvents)
  };
  
  return patterns;
}
```

---

## Troubleshooting Guide

### Common Issues

#### Issue: High Memory Usage by Audit Queue
**Symptoms:**
- Application memory usage continuously increasing
- Slow response times
- Out of memory errors

**Diagnosis:**
```typescript
// Check audit queue size
const queueSize = auditQueue.getSize();
const queueStats = auditQueue.getStats();
console.log({ queueSize, queueStats });
```

**Solutions:**
1. **Increase flush frequency:**
```typescript
const auditQueue = new AuditQueue({
  batchSize: 25,        // Reduce batch size
  flushInterval: 2000,  // Flush every 2 seconds
  maxQueueSize: 1000    // Set maximum queue size
});
```

2. **Manual flush during low traffic:**
```typescript
// Force flush during maintenance
setInterval(() => {
  if (auditQueue.getSize() > 0) {
    auditQueue.flush().catch(console.error);
  }
}, 30000); // Every 30 seconds
```

#### Issue: Slow Audit Queries
**Symptoms:**
- Audit endpoint timeouts
- Slow dashboard loading
- High database CPU usage

**Diagnosis:**
```sql
-- Check slow queries
SELECT query, mean_time, calls 
FROM pg_stat_statements 
WHERE query LIKE '%audit_logs%'
ORDER BY mean_time DESC;

-- Check index usage
SELECT indexname, indexdef 
FROM pg_indexes 
WHERE tablename = 'audit_logs';
```

**Solutions:**
1. **Optimize queries with proper indexes:**
```sql
-- Create composite indexes for common query patterns
CREATE INDEX CONCURRENTLY idx_audit_user_action_created 
ON audit_logs(user_id, action, created_at);

CREATE INDEX CONCURRENTLY idx_audit_category_severity_created 
ON audit_logs(category, severity, created_at);
```

2. **Use query optimization:**
```typescript
// Limit result sets and use pagination
const logs = await auditService.queryAuditLogs({
  startDate,
  endDate,
  limit: 100,        // Reasonable limit
  offset: 0,
  sortBy: 'createdAt',
  sortOrder: 'desc'
});
```

#### Issue: Missing Audit Logs
**Symptoms:**
- Incomplete audit trails
- Gaps in user activity
- Compliance violations

**Diagnosis:**
```typescript
// Check audit log creation
const recentLogs = await auditService.queryAuditLogs({
  startDate: new Date(Date.now() - 24 * 60 * 60 * 1000),
  limit: 1000
});

console.log(`Logs in last 24h: ${recentLogs.length}`);

// Verify audit context is being set
const context = storage.getAuditContext();
console.log('Current audit context:', context);
```

**Solutions:**
1. **Verify audit middleware is properly configured:**
```typescript
// Check middleware order
app.use(requestLoggingMiddleware);
app.use(authMiddleware);
app.use(auditMiddleware); // Must be after auth
app.use(routes);
```

2. **Ensure audit context is set:**
```typescript
// In route handlers
storage.setAuditContext({
  userId: req.user.id,
  sessionId: req.sessionId,
  ipAddress: req.ip,
  userAgent: req.headers['user-agent'],
  correlationId: req.correlationId
});
```

#### Issue: Export Failures
**Symptoms:**
- Timeout during large exports
- Memory errors during export
- Incomplete export files

**Diagnosis:**
```typescript
// Check export size
const logsCount = await auditService.getAuditLogsCount({
  startDate,
  endDate
});

console.log(`Records to export: ${logsCount}`);
```

**Solutions:**
1. **Implement chunked exports:**
```typescript
async function exportInChunks(startDate: Date, endDate: Date, chunkSize: number = 1000) {
  let offset = 0;
  const chunks = [];
  
  while (true) {
    const logs = await auditService.queryAuditLogs({
      startDate,
      endDate,
      limit: chunkSize,
      offset
    });
    
    if (logs.length === 0) break;
    
    chunks.push(logs);
    offset += chunkSize;
    
    // Allow other operations to run
    await new Promise(resolve => setImmediate(resolve));
  }
  
  return chunks;
}
```

2. **Use streaming exports:**
```typescript
async function streamExport(startDate: Date, endDate: Date, format: string) {
  const stream = new PassThrough();
  
  // Write header
  if (format === 'csv') {
    stream.write('ID,User ID,Action,Resource,Status,Created At\n');
  }
  
  let offset = 0;
  const chunkSize = 500;
  
  while (true) {
    const logs = await auditService.queryAuditLogs({
      startDate,
      endDate,
      limit: chunkSize,
      offset
    });
    
    if (logs.length === 0) break;
    
    for (const log of logs) {
      if (format === 'csv') {
        stream.write(`${log.id},${log.userId},${log.action},${log.resource},${log.status},${log.createdAt}\n`);
      }
    }
    
    offset += chunkSize;
  }
  
  return stream;
}
```

### Performance Optimization

#### Database Optimization
```sql
-- Partition audit logs by date for large tables
CREATE TABLE audit_logs_2024 PARTITION OF audit_logs
FOR VALUES FROM ('2024-01-01') TO ('2025-01-01');

-- Create partial indexes for recent data
CREATE INDEX idx_audit_logs_recent ON audit_logs(created_at DESC)
WHERE created_at > CURRENT_DATE - INTERVAL '90 days';
```

#### Memory Management
```typescript
class OptimizedAuditService {
  private batchSize = 100;
  private flushInterval = 5000;
  
  async createAuditLog(log: CreateAuditLogOptions): Promise<void> {
    await this.addToBatch(log);
    
    if (this.batch.length >= this.batchSize) {
      await this.flushBatch();
    }
  }
  
  private async flushBatch(): Promise<void> {
    if (this.batch.length === 0) return;
    
    try {
      await db.insert(auditLogs).values(this.batch);
      this.batch = [];
    } catch (error) {
      // Log error but don't crash
      logger.error('Audit batch flush failed', { error, batchSize: this.batch.length });
      throw error;
    }
  }
}
```

### Monitoring and Alerting

#### Health Check
```typescript
async function auditSystemHealthCheck(): Promise<HealthStatus> {
  const checks = {
    database: await checkDatabase(),
    queue: await checkAuditQueue(),
    middleware: await checkMiddleware(),
    endpoints: await checkEndpoints()
  };
  
  const overallStatus = Object.values(checks).every(check => check.healthy)
    ? 'healthy'
    : 'degraded';
    
  return {
    status: overallStatus,
    checks,
    timestamp: new Date().toISOString()
  };
}
```

#### Performance Monitoring
```typescript
class AuditPerformanceMonitor {
  private metrics = {
    queueSize: [],
    flushDuration: [],
    queryDuration: [],
    exportDuration: []
  };
  
  recordQueueSize(size: number): void {
    this.metrics.queueSize.push({ timestamp: Date.now(), value: size });
    this.cleanupOldMetrics();
  }
  
  getPerformanceReport(): PerformanceReport {
    return {
      averageQueueSize: this.calculateAverage('queueSize'),
      averageFlushDuration: this.calculateAverage('flushDuration'),
      averageQueryDuration: this.calculateAverage('queryDuration'),
      healthScore: this.calculateHealthScore()
    };
  }
}
```

### Debug Mode

#### Enable Debug Logging
```typescript
// Set environment variable
process.env.LOG_LEVEL = 'debug';
process.env.AUDIT_DEBUG = 'true';

// Or programmatically
logger.setLevel(LogLevel.DEBUG);
auditService.enableDebugMode(true);
```

#### Trace Audit Flow
```typescript
async function traceAuditFlow(operation: string, context: any): Promise<void> {
  const correlationId = logger.generateCorrelationId();
  
  logger.debug(`[AUDIT_TRACE] ${operation} started`, {
    correlationId,
    context,
    timestamp: new Date().toISOString()
  });
  
  try {
    // Perform operation
    const result = await performOperation(operation, context);
    
    logger.debug(`[AUDIT_TRACE] ${operation} completed`, {
      correlationId,
      result,
      duration: Date.now() - startTime
    });
    
    return result;
  } catch (error) {
    logger.error(`[AUDIT_TRACE] ${operation} failed`, {
      correlationId,
      error: error.message,
      context
    });
    
    throw error;
  }
}
```

### Emergency Procedures

#### Disable Audit Logging (Emergency Only)
```typescript
// Emergency disable - use with caution
process.env.AUDIT_DISABLED = 'true';

// Or programmatically
auditService.emergencyDisable();

// WARNING: This should only be used in extreme circumstances
// Ensure compliance requirements are met before using
```

#### Force Flush All Pending Logs
```typescript
async function emergencyFlush(): Promise<void> {
  logger.warn('Emergency audit log flush initiated');
  
  try {
    // Force flush all pending audit logs
    await auditService.flushAuditLogs();
    
    // Verify no logs remain in queue
    const remaining = auditQueue.getSize();
    if (remaining > 0) {
      logger.error('Emergency flush incomplete', { remaining });
    }
    
    logger.info('Emergency audit log flush completed');
  } catch (error) {
    logger.error('Emergency audit log flush failed', { error });
    throw error;
  }
}
```

---

## Conclusion

The CloudPilot Audit Trail System provides comprehensive monitoring, compliance, and security features essential for enterprise applications. This documentation covers the core functionality, configuration, and troubleshooting procedures.

For additional support:
- Review logs in `logs/audit.log`
- Check monitoring dashboard for real-time metrics
- Contact the security team for compliance questions
- Refer to the API documentation for detailed endpoint specifications

**Version:** 1.0  
**Last Updated:** 2024-01-15  
**Maintained by:** CloudPilot Security Team
