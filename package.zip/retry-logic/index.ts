/**
 * Retry Logic System - Main Entry Point
 * 
 * A comprehensive retry logic implementation with exponential backoff,
 * circuit breaker integration, metrics, and logging.
 * 
 * Features:
 * - Retry decorators for functions and classes
 * - Exponential backoff with jitter
 * - Circuit breaker pattern
 * - Configurable retry policies
 * - Async/await utilities
 * - Promise-based retry patterns
 * - Comprehensive metrics and logging
 * - Timeout handling
 * - Custom retry conditions
 */

export * from './types.js';
export * from './exponential-backoff.js';
export * from './circuit-breaker.js';
export * from './retry.js';
export * from './async-utils.js';
export * from './promise-retry.js';
export * from './metrics-logging.js';

// Re-export commonly used types and utilities
export type {
  RetryOptions,
  RetryResult,
  RetryMetrics,
  RetryContext,
  RetryFunction,
  SyncRetryFunction,
  CircuitBreakerState,
  RetryPolicy,
} from './types.js';

export {
  RetryPolicies,
  isRetryableError,
  isRetryableApiError,
  isDeadlockError,
} from './types.js';

export {
  ExponentialBackoff,
  BackoffStrategies,
  BackoffStatistics,
} from './exponential-backoff.js';

export {
  CircuitBreaker,
  withCircuitBreaker,
  CircuitBreakerGroup,
} from './circuit-breaker.js';

export {
  RetryLogic,
  retry,
  retrySync,
  createRetry,
} from './retry.js';

export {
  AsyncRetryUtils,
  RetryIterator,
  AsyncRetryPatterns,
  retryable,
  makeRetryable,
} from './async-utils.js';

export {
  RetryablePromise,
  PromiseRetryUtils,
  RetryablePromiseFactories,
  PromiseChain,
  AdvancedPromisePatterns,
} from './promise-retry.js';

export {
  RetryMetricsCollector,
  RetryLogger,
  RetryMetricsCollectorImpl,
  RetryLoggerImpl,
  RetryMonitoringSystem,
  MonitoringSystems,
} from './metrics-logging.js';

/**
 * Quick start examples
 */

// Basic retry usage
export async function basicRetryExample() {
  const { retry } = await import('./retry.js');
  const { AsyncRetryUtils } = await import('./async-utils.js');

  // Using the async utility
  const result = await AsyncRetryUtils.retry(
    async () => {
      // Your async operation here
      const response = await fetch('https://api.example.com/data');
      if (!response.ok) throw new Error('API Error');
      return response.json();
    },
    { maxAttempts: 3 }
  );

  console.log('Result:', result);
}

// Using decorators
export function decoratorExample() {
  const { retry, RetryLogic } = await import('./retry.js');

  class MyService {
    @retry({ maxAttempts: 5, baseDelay: 1000 })
    async fetchData() {
      const response = await fetch('https://api.example.com/data');
      if (!response.ok) throw new Error('API Error');
      return response.json();
    }
  }

  return new MyService();
}

// With circuit breaker
export async function circuitBreakerExample() {
  const { CircuitBreaker, retry } = await import('./retry.js');
  const circuitBreaker = new CircuitBreaker({
    failureThreshold: 50,
    monitoringWindow: 60000,
  });

  const result = await retry(
    { maxAttempts: 5 },
    circuitBreaker
  )(async () => {
    // Your operation here
    return 'success';
  })();

  console.log('Result with circuit breaker:', result);
}

// With monitoring
export async function monitoringExample() {
  const { AsyncRetryUtils, MonitoringSystems } = await import('./async-utils.js');

  const monitoring = MonitoringSystems.detailed();
  
  try {
    const result = await AsyncRetryUtils.retry(
      async () => {
        // Your operation here
        return 'success';
      },
      {
        maxAttempts: 5,
        onRetry: (error, attempt, delay) => {
          monitoring.getLogger().logRetryAttempt(attempt, 5, delay, error);
        },
      }
    );

    // Get monitoring report
    const report = monitoring.getMonitoringReport();
    console.log('Monitoring Report:', report);
  } catch (error) {
    monitoring.getLogger().logCustom(
      'Operation failed after all retries',
      'ERROR',
      { error }
    );
  }
}

// Advanced patterns
export async function advancedPatternsExample() {
  const { 
    AsyncRetryUtils, 
    PromiseRetryUtils, 
    RetryablePromise,
    BackoffStrategies 
  } = await import('./async-utils.js');

  // 1. Retry with specific backoff strategy
  const result1 = await AsyncRetryUtils.retryWithBackoff(
    async () => { /* operation */ },
    'database'
  );

  // 2. Retry with custom condition
  const result2 = await AsyncRetryUtils.retryUntil(
    async () => {
      const data = await someAsyncOperation();
      return data;
    },
    (result) => result.status === 'ready',
    10
  );

  // 3. Using RetryablePromise
  const retryable = new RetryablePromise(
    async () => { /* operation */ },
    { maxAttempts: 3 }
  );

  const result3 = await retryable.thenResolving();

  // 4. Promise-based retry with custom error handling
  const result4 = await PromiseRetryUtils.retryWithCustomErrorHandling(
    async () => { /* operation */ },
    new Map([
      [429, async (error, attempt) => {
        // Handle rate limiting
        return attempt < 3;
      }],
      [500, async (error, attempt) => {
        // Handle server errors
        return attempt < 5;
      }],
    ])
  );

  return [result1, result2, result3, result4];
}

/**
 * Performance monitoring example
 */
export async function performanceMonitoringExample() {
  const { RetryMonitoringSystem, MonitoringSystems } = await import('./metrics-logging.js');
  
  const monitoring = MonitoringSystems.detailed();
  const startTime = Date.now();

  try {
    // Run multiple operations
    const operations = Array.from({ length: 10 }, (_, i) => 
      AsyncRetryUtils.retry(
        async () => {
          // Simulate variable success rate
          if (Math.random() < 0.3) {
            throw new Error('Random failure');
          }
          return `Operation ${i} completed`;
        },
        {
          maxAttempts: 3,
          onRetry: (error, attempt, delay) => {
            monitoring.getMetricsCollector().recordRetryAttempt(attempt, delay, error);
          },
        }
      )
    );

    const results = await Promise.allSettled(operations);
    
    // Update metrics
    results.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        monitoring.getMetricsCollector().recordSuccess(1, Date.now() - startTime);
      } else {
        monitoring.getMetricsCollector().recordFailure(3, Date.now() - startTime, result.reason);
      }
    });

    // Generate performance report
    const report = monitoring.getMonitoringReport();
    
    console.log('Performance Metrics:');
    console.log(`- Success Rate: ${report.metrics.successRate}%`);
    console.log(`- Total Operations: ${report.performance.totalOperations}`);
    console.log(`- Average Delay: ${report.performance.averageDelay}ms`);
    console.log(`- Retry Rate: ${report.performance.retryRate}%`);
    
    return report;
  } catch (error) {
    monitoring.getLogger().logCustom(
      'Performance monitoring failed',
      'ERROR',
      { error }
    );
    throw error;
  }
}

/**
 * Configuration examples for different use cases
 */
export const ConfigurationExamples = {
  /**
   * Web scraping configuration
   */
  webScraping: {
    maxAttempts: 5,
    baseDelay: 2000,
    maxDelay: 30000,
    jitter: true,
    jitterFactor: 0.2,
    backoffMultiplier: 2,
    totalTimeout: 120000,
    retryCondition: (error) => {
      return error.status >= 500 || error.status === 429 || error.code === 'ETIMEDOUT';
    },
  },

  /**
   * Database operations configuration
   */
  database: {
    maxAttempts: 5,
    baseDelay: 500,
    maxDelay: 10000,
    jitter: true,
    jitterFactor: 0.1,
    backoffMultiplier: 2,
    totalTimeout: 45000,
    retryCondition: (error) => {
      return error.code && ['ECONNRESET', 'ETIMEDOUT', 'ECONNREFUSED'].includes(error.code);
    },
  },

  /**
   * API calls configuration
   */
  apiCalls: {
    maxAttempts: 7,
    baseDelay: 1000,
    maxDelay: 30000,
    jitter: true,
    jitterFactor: 0.2,
    backoffMultiplier: 2,
    totalTimeout: 120000,
    retryCondition: (error) => {
      return error.status >= 500 || error.status === 408 || error.status === 429;
    },
  },

  /**
   * File operations configuration
   */
  fileOperations: {
    maxAttempts: 3,
    baseDelay: 1000,
    maxDelay: 5000,
    jitter: true,
    jitterFactor: 0.1,
    backoffMultiplier: 2,
    totalTimeout: 30000,
    retryCondition: (error) => {
      return error.code && ['EMFILE', 'ENOSPC', 'EACCES'].includes(error.code);
    },
  },

  /**
   * Critical operations configuration (more aggressive)
   */
  critical: {
    maxAttempts: 10,
    baseDelay: 500,
    maxDelay: 60000,
    jitter: true,
    jitterFactor: 0.1,
    backoffMultiplier: 1.5,
    totalTimeout: 300000,
    retryCondition: (error) => {
      return error.status >= 500 || error.status === 429 || error.code === 'ETIMEDOUT';
    },
  },

  /**
   * Non-critical operations configuration (more conservative)
   */
  nonCritical: {
    maxAttempts: 2,
    baseDelay: 2000,
    maxDelay: 10000,
    jitter: true,
    jitterFactor: 0.3,
    backoffMultiplier: 2,
    totalTimeout: 30000,
    retryCondition: (error) => {
      return error.status >= 500;
    },
  },
} as const;

/**
 * Validation utilities for retry configurations
 */
export const ConfigurationValidators = {
  /**
   * Validate retry options
   */
  validateRetryOptions(options: any): boolean {
    if (!options || typeof options !== 'object') {
      return false;
    }

    const { maxAttempts, baseDelay, maxDelay, totalTimeout } = options;

    return (
      (maxAttempts === undefined || (Number.isInteger(maxAttempts) && maxAttempts > 0)) &&
      (baseDelay === undefined || (Number.isFinite(baseDelay) && baseDelay >= 0)) &&
      (maxDelay === undefined || (Number.isFinite(maxDelay) && maxDelay > 0)) &&
      (totalTimeout === undefined || (Number.isFinite(totalTimeout) && totalTimeout > 0))
    );
  },

  /**
   * Validate circuit breaker options
   */
  validateCircuitBreakerOptions(options: any): boolean {
    if (!options || typeof options !== 'object') {
      return false;
    }

    const { failureThreshold, minimumRequests, monitoringWindow, halfOpenCooldown, autoResetAttempts } = options;

    return (
      (failureThreshold === undefined || (Number.isFinite(failureThreshold) && failureThreshold >= 0 && failureThreshold <= 100)) &&
      (minimumRequests === undefined || (Number.isInteger(minimumRequests) && minimumRequests > 0)) &&
      (monitoringWindow === undefined || (Number.isFinite(monitoringWindow) && monitoringWindow > 0)) &&
      (halfOpenCooldown === undefined || (Number.isFinite(halfOpenCooldown) && halfOpenCooldown > 0)) &&
      (autoResetAttempts === undefined || (Number.isInteger(autoResetAttempts) && autoResetAttempts > 0))
    );
  },

  /**
   * Validate backoff configuration
   */
  validateBackoffConfig(config: any): boolean {
    if (!config || typeof config !== 'object') {
      return false;
    }

    const { initialDelay, maxDelay, multiplier, jitterFactor } = config;

    return (
      (initialDelay === undefined || (Number.isFinite(initialDelay) && initialDelay > 0)) &&
      (maxDelay === undefined || (Number.isFinite(maxDelay) && maxDelay > 0)) &&
      (multiplier === undefined || (Number.isFinite(multiplier) && multiplier > 0)) &&
      (jitterFactor === undefined || (Number.isFinite(jitterFactor) && jitterFactor >= 0 && jitterFactor <= 1))
    );
  },
} as const;

// Default export with all main utilities
const RetryLogicSystem = {
  // Core classes
  RetryLogic,
  ExponentialBackoff,
  CircuitBreaker,
  RetryablePromise,

  // Utilities
  AsyncRetryUtils,
  PromiseRetryUtils,
  RetryMonitoringSystem,
  RetryMetricsCollectorImpl,
  RetryLoggerImpl,

  // Decorators
  retry,
  retrySync,
  withCircuitBreaker,

  // Factories
  createRetry,
  BackoffStrategies,
  RetryablePromiseFactories,
  MonitoringSystems,

  // Patterns and examples
  AsyncRetryPatterns,
  AdvancedPromisePatterns,
  ConfigurationExamples,
  ConfigurationValidators,

  // Examples
  basicRetryExample,
  decoratorExample,
  circuitBreakerExample,
  monitoringExample,
  advancedPatternsExample,
  performanceMonitoringExample,
};

export default RetryLogicSystem;

/**
 * Version information
 */
export const VERSION = '1.0.0';
export const BUILD_DATE = new Date().toISOString();