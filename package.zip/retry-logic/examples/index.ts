/**
 * Example: Basic retry usage
 */

import RetryLogicSystem from '../index.js';

async function basicRetryExample() {
  console.log('=== Basic Retry Example ===\n');

  try {
    // Example 1: Simple retry
    console.log('1. Simple retry with default options:');
    const result1 = await RetryLogicSystem.AsyncRetryUtils.retry(
      async () => {
        const response = await fetch('https://jsonplaceholder.typicode.com/posts/1');
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return response.json();
      },
      { maxAttempts: 3 }
    );
    console.log('Result:', JSON.stringify(result1, null, 2));
    console.log('✅ Success!\n');

    // Example 2: Retry with exponential backoff
    console.log('2. Retry with exponential backoff:');
    const result2 = await RetryLogicSystem.AsyncRetryUtils.retryWithBackoff(
      async () => {
        // Simulate variable success rate
        if (Math.random() < 0.7) {
          throw new Error('Simulated network error');
        }
        return 'Success!';
      },
      'standard'
    );
    console.log('Result:', result2);
    console.log('✅ Success!\n');

    // Example 3: Retry until condition is met
    console.log('3. Retry until condition is met:');
    let attempts = 0;
    const result3 = await RetryLogicSystem.AsyncRetryUtils.retryUntil(
      async () => {
        attempts++;
        if (attempts < 3) {
          throw new Error('Not ready yet');
        }
        return { status: 'ready', attempts };
      },
      (result) => result.status === 'ready',
      5
    );
    console.log('Result:', JSON.stringify(result3, null, 2));
    console.log('✅ Success!\n');

  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

async function decoratorExample() {
  console.log('=== Decorator Example ===\n');

  class UserService {
    constructor(private baseUrl: string) {}

    @RetryLogicSystem.retry({
      maxAttempts: 5,
      baseDelay: 1000,
      retryCondition: (error) => error.status >= 500 || error.status === 429,
    })
    async fetchUsers() {
      const response = await fetch(`${this.baseUrl}/users`);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      return response.json();
    }

    @RetryLogicSystem.retry({
      maxAttempts: 3,
      baseDelay: 500,
      retryCondition: (error) => error.code && ['ECONNRESET', 'ETIMEDOUT'].includes(error.code),
    })
    async createUser(userData: any) {
      const response = await fetch(`${this.baseUrl}/users`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
      });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      return response.json();
    }
  }

  try {
    const userService = new UserService('https://jsonplaceholder.typicode.com');
    
    console.log('1. Fetching users with retry decorator:');
    const users = await userService.fetchUsers();
    console.log('Result:', `Fetched ${Array.isArray(users) ? users.length : 1} user(s)`);
    console.log('✅ Success!\n');

    console.log('2. Creating user with retry decorator:');
    const newUser = await userService.createUser({
      name: 'John Doe',
      email: 'john@example.com',
    });
    console.log('Result:', JSON.stringify(newUser, null, 2));
    console.log('✅ Success!\n');

  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

async function circuitBreakerExample() {
  console.log('=== Circuit Breaker Example ===\n');

  const circuitBreaker = new RetryLogicSystem.CircuitBreaker({
    failureThreshold: 50,  // 50% failure rate
    minimumRequests: 3,    // Need at least 3 requests
    monitoringWindow: 10000, // 10 second window
    halfOpenCooldown: 2000,  // 2 second cooldown
    autoResetAttempts: 2,    // 2 successful attempts to reset
  });

  console.log('Circuit Breaker State:', circuitBreaker.getState());

  // Test operations
  for (let i = 1; i <= 10; i++) {
    try {
      console.log(`\nAttempt ${i}:`);
      
      const result = await RetryLogicSystem.AsyncRetryUtils.retryWithCircuitBreaker(
        async () => {
          // Simulate a service that fails 80% of the time
          if (Math.random() < 0.8) {
            throw new Error('Service unavailable');
          }
          return 'Success!';
        },
        circuitBreaker,
        () => 'Fallback response' // Fallback function
      );

      console.log('Result:', result);
    } catch (error) {
      console.log('Error:', error.message);
      const state = circuitBreaker.getState();
      console.log('Circuit Breaker State:', state.state);
      
      if (state.state === 'open') {
        console.log('🔴 Circuit breaker is OPEN - failing fast');
        break;
      }
    }
  }
}

async function monitoringExample() {
  console.log('=== Monitoring Example ===\n');

  const monitoring = RetryLogicSystem.MonitoringSystems.detailed();

  try {
    console.log('Running multiple operations with monitoring...');

    // Run multiple operations
    const operations = Array.from({ length: 10 }, (_, i) =>
      RetryLogicSystem.AsyncRetryUtils.retry(
        async () => {
          // Simulate variable success rate
          if (Math.random() < 0.3) {
            throw new Error('Random failure');
          }
          return `Operation ${i} completed`;
        },
        {
          maxAttempts: 3,
          onRetry: (error, attempt, delay) => {
            monitoring.getMetricsCollector().recordRetryAttempt(attempt, delay, error);
            monitoring.getLogger().logRetryAttempt(attempt, 3, delay, error);
          },
          onSuccess: (result, attempt) => {
            monitoring.getMetricsCollector().recordSuccess(attempt, 100);
            monitoring.getLogger().logRetrySuccess(attempt, 100, result);
          },
          onExhausted: (error, attempt) => {
            monitoring.getMetricsCollector().recordFailure(attempt, 300, error);
            monitoring.getLogger().logRetryExhausted(attempt, 3, error);
          },
        }
      )
    );

    const results = await Promise.allSettled(operations);

    // Update metrics for completed operations
    results.forEach((result) => {
      if (result.status === 'fulfilled') {
        monitoring.getMetricsCollector().recordSuccess(1, 100);
      } else {
        monitoring.getMetricsCollector().recordFailure(3, 300, result.reason);
      }
    });

    // Get comprehensive monitoring report
    const report = monitoring.getMonitoringReport();

    console.log('\n📊 Metrics Summary:');
    console.log('==================');
    console.log(`Total Attempts: ${report.metrics.attempts}`);
    console.log(`Successes: ${report.metrics.successes}`);
    console.log(`Failures: ${report.metrics.failures}`);
    console.log(`Success Rate: ${report.metrics.successRate.toFixed(2)}%`);
    console.log(`Circuit Breaker Opens: ${report.metrics.circuitBreakerOpens}`);
    console.log(`Average Delay: ${report.metrics.averageDelay.toFixed(2)}ms`);
    console.log(`Total Retry Time: ${report.metrics.totalRetryTime}ms`);

    console.log('\n📈 Performance Metrics:');
    console.log('=======================');
    console.log(`Total Operations: ${report.performance.totalOperations}`);
    console.log(`Successful Operations: ${report.performance.successfulOperations}`);
    console.log(`Failed Operations: ${report.performance.failedOperations}`);
    console.log(`Retry Rate: ${report.performance.retryRate.toFixed(2)}%`);
    console.log(`Average Retry Delay: ${report.performance.averageDelay.toFixed(2)}ms`);
    console.log(`Median Retry Delay: ${report.performance.medianDelay.toFixed(2)}ms`);
    console.log(`95th Percentile Delay: ${report.performance.p95Delay.toFixed(2)}ms`);

    console.log('\n🐛 Error Types:');
    console.log('===============');
    report.metrics.errorTypes.forEach((count, errorType) => {
      console.log(`${errorType}: ${count}`);
    });

    console.log('\n📝 Recent Logs:');
    console.log('===============');
    const recentLogs = monitoring.getLogger().getLogs().slice(-5);
    recentLogs.forEach((log) => {
      console.log(`[${log.level}] ${log.message}`, log.data || '');
    });

  } catch (error) {
    monitoring.getLogger().logCustom(
      'Monitoring example failed',
      'ERROR',
      { error }
    );
  }
}

async function promiseRetryExample() {
  console.log('=== Promise-Based Retry Example ===\n');

  try {
    // Example 1: Using RetryablePromise
    console.log('1. Using RetryablePromise:');
    const retryable = new RetryLogicSystem.RetryablePromise(
      async () => {
        const response = await fetch('https://jsonplaceholder.typicode.com/posts/1');
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        return response.json();
      },
      {
        maxAttempts: 3,
        baseDelay: 1000,
      }
    );

    const result = await retryable.thenResolving();
    console.log('Result:', JSON.stringify(result, null, 2));
    console.log('✅ Success!\n');

    // Example 2: RetryablePromise with timeout
    console.log('2. RetryablePromise with timeout:');
    const timeoutPromise = new RetryLogicSystem.RetryablePromise(
      async () => {
        await new Promise(resolve => setTimeout(resolve, 5000));
        return 'Completed';
      },
      { maxAttempts: 2 }
    ).withTimeout(2000);

    try {
      await timeoutPromise.thenResolving();
    } catch (error) {
      console.log('Timeout error caught:', error.message);
      console.log('✅ Timeout handling works!\n');
    }

    // Example 3: PromiseChain with retry
    console.log('3. PromiseChain with retry:');
    const chain = new RetryLogicSystem.PromiseChain();

    chain.add(async () => {
      if (Math.random() < 0.5) throw new Error('Random failure');
      return 'Task 1 completed';
    });

    chain.add(async () => {
      if (Math.random() < 0.3) throw new Error('Random failure');
      return 'Task 2 completed';
    });

    chain.add(async () => {
      return 'Task 3 completed';
    });

    const results = await chain.executeSequential();
    console.log('Chain Results:', results);
    console.log('✅ Success!\n');

  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

async function advancedPatternsExample() {
  console.log('=== Advanced Patterns Example ===\n');

  try {
    // Example 1: Retry with progress tracking
    console.log('1. Retry with progress tracking:');
    const result1 = await RetryLogicSystem.AsyncRetryUtils.retryWithProgress(
      async () => {
        if (Math.random() < 0.6) {
          throw new Error('Progress retry failure');
        }
        return 'Progress success!';
      },
      (attempt, maxAttempts, delay, error) => {
        console.log(`Progress: Attempt ${attempt}/${maxAttempts}, delay: ${delay}ms`);
        if (error) {
          console.log('  Error:', error.message);
        }
      },
      { maxAttempts: 5 }
    );
    console.log('Result:', result1);
    console.log('✅ Success!\n');

    // Example 2: Retry with custom error handling
    console.log('2. Retry with custom error handling:');
    const result2 = await RetryLogicSystem.PromiseRetryUtils.retryWithCustomErrorHandling(
      async () => {
        // Simulate different types of errors
        const errorType = Math.floor(Math.random() * 3);
        switch (errorType) {
          case 0:
            throw { status: 429, message: 'Rate limit exceeded' };
          case 1:
            throw { status: 500, message: 'Internal server error' };
          case 2:
            throw { status: 400, message: 'Bad request' };
          default:
            return 'Success!';
        }
      },
      new Map([
        [429, async (error, attempt) => {
          console.log(`  Handling rate limit, attempt ${attempt}`);
          return attempt < 3;
        }],
        [500, async (error, attempt) => {
          console.log(`  Handling server error, attempt ${attempt}`);
          return attempt < 5;
        }],
        [400, async (error, attempt) => {
          console.log(`  Bad request, not retrying`);
          return false;
        }],
      ])
    );
    console.log('Result:', result2);
    console.log('✅ Success!\n');

    // Example 3: Concurrent retry operations
    console.log('3. Concurrent retry operations:');
    const operations = [
      async () => {
        if (Math.random() < 0.4) throw new Error('Operation 1 failed');
        return 'Operation 1 completed';
      },
      async () => {
        if (Math.random() < 0.3) throw new Error('Operation 2 failed');
        return 'Operation 2 completed';
      },
      async () => {
        if (Math.random() < 0.2) throw new Error('Operation 3 failed');
        return 'Operation 3 completed';
      },
    ];

    const results = await RetryLogicSystem.PromiseRetryUtils.retryAll(
      operations,
      { maxAttempts: 2 }
    );
    console.log('Concurrent Results:', results);
    console.log('✅ Success!\n');

  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

// Run all examples
async function runAllExamples() {
  console.log('🚀 Retry Logic System Examples');
  console.log('==============================\n');

  try {
    await basicRetryExample();
    await decoratorExample();
    await circuitBreakerExample();
    await monitoringExample();
    await promiseRetryExample();
    await advancedPatternsExample();

    console.log('🎉 All examples completed successfully!');
  } catch (error) {
    console.error('❌ Example run failed:', error);
  }
}

// Run examples if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  runAllExamples();
}

export {
  basicRetryExample,
  decoratorExample,
  circuitBreakerExample,
  monitoringExample,
  promiseRetryExample,
  advancedPatternsExample,
  runAllExamples,
};