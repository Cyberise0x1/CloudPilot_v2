/**
 * Core types and interfaces for retry logic system
 */

export interface RetryOptions {
  /** Maximum number of retry attempts */
  maxAttempts: number;
  
  /** Base delay in milliseconds for exponential backoff */
  baseDelay: number;
  
  /** Maximum delay in milliseconds */
  maxDelay: number;
  
  /** Jitter factor (0-1), randomizes delays to prevent thundering herd */
  jitter: boolean;
  
  /** Jitter factor value (0-1) */
  jitterFactor: number;
  
  /** Exponential backoff multiplier */
  backoffMultiplier: number;
  
  /** Function to determine if an error should trigger a retry */
  retryCondition: (error: any, attempt: number) => boolean;
  
  /** Function called before each retry attempt */
  onRetry?: (error: any, attempt: number, nextDelay: number) => void;
  
  /** Function called when all retries are exhausted */
  onExhausted?: (error: any, attempt: number, totalAttempts: number) => void;
  
  /** Function called when retry succeeds */
  onSuccess?: (result: any, attempt: number, totalAttempts: number) => void;
  
  /** Total timeout for all retry attempts in milliseconds */
  totalTimeout: number;
  
  /** Whether to abort on timeout */
  abortOnTimeout: boolean;
}

export interface CircuitBreakerOptions {
  /** Failure threshold percentage to open circuit */
  failureThreshold: number;
  
  /** Minimum number of requests before circuit can open */
  minimumRequests: number;
  
  /** Time window in milliseconds for monitoring failures */
  monitoringWindow: number;
  
  /** Half-open state cooldown in milliseconds */
  halfOpenCooldown: number;
  
  /** Auto-reset attempts */
  autoResetAttempts: number;
  
  /** Function to determine if an error should be tracked as a failure */
  failureCondition: (error: any) => boolean;
}

export interface RetryMetrics {
  /** Total number of retry attempts */
  attempts: number;
  
  /** Number of successful retries */
  successes: number;
  
  /** Number of failed retries */
  failures: number;
  
  /** Number of times circuit breaker opened */
  circuitBreakerOpens: number;
  
  /** Average retry delay */
  averageDelay: number;
  
  /** Total time spent retrying */
  totalRetryTime: number;
  
  /** Success rate percentage */
  successRate: number;
  
  /** Error types encountered */
  errorTypes: Map<string, number>;
  
  /** Timestamp of last retry */
  lastRetryTime: number;
}

export interface RetryContext {
  /** Current attempt number */
  attempt: number;
  
  /** Circuit breaker state */
  circuitBreaker: 'closed' | 'open' | 'half-open';
  
  /** Metrics for this retry session */
  metrics: RetryMetrics;
  
  /** Whether retry has been aborted */
  aborted: boolean;
  
  /** Abort reason if retry was aborted */
  abortReason?: string;
}

export type RetryFunction<T> = () => Promise<T> | T;
export type SyncRetryFunction<T> = () => T;

export interface RetryResult<T> {
  /** Whether the retry operation succeeded */
  success: boolean;
  
  /** The result if successful */
  result?: T;
  
  /** The error if failed */
  error?: any;
  
  /** Total attempts made */
  attempts: number;
  
  /** Context information */
  context: RetryContext;
  
  /** Total time spent */
  totalTime: number;
}

export interface CircuitBreakerState {
  /** Current state: closed, open, or half-open */
  state: 'closed' | 'open' | 'half-open';
  
  /** Number of consecutive failures */
  consecutiveFailures: number;
  
  /** Number of total failures in monitoring window */
  totalFailures: number;
  
  /** Number of total requests in monitoring window */
  totalRequests: number;
  
  /** Timestamp when circuit breaker opened */
  openedAt?: number;
  
  /** Number of successful attempts in half-open state */
  halfOpenSuccessCount: number;
  
  /** Whether circuit is ready to reset */
  canReset: boolean;
}

export interface ExponentialBackoffConfig {
  /** Initial delay in milliseconds */
  initialDelay: number;
  
  /** Maximum delay in milliseconds */
  maxDelay: number;
  
  /** Backoff multiplier */
  multiplier: number;
  
  /** Whether to apply jitter */
  jitter: boolean;
  
  /** Jitter factor */
  jitterFactor: number;
}

export interface RetryPolicy {
  /** Name of the policy */
  name: string;
  
  /** Description of the policy */
  description: string;
  
  /** Retry options configuration */
  options: Partial<RetryOptions>;
  
  /** Circuit breaker options configuration */
  circuitBreakerOptions?: Partial<CircuitBreakerOptions>;
}

/**
 * Common retry policies
 */
export const RetryPolicies = {
  /** Quick retry - for transient failures */
  quick: {
    name: 'quick',
    description: 'Quick retry for transient failures',
    options: {
      maxAttempts: 3,
      baseDelay: 100,
      maxDelay: 1000,
      jitter: true,
      jitterFactor: 0.1,
      backoffMultiplier: 2,
      totalTimeout: 5000,
      retryCondition: (error: any) => isRetryableError(error),
    }
  } as RetryPolicy,

  /** Standard retry - balanced approach */
  standard: {
    name: 'standard',
    description: 'Standard retry policy for most operations',
    options: {
      maxAttempts: 5,
      baseDelay: 1000,
      maxDelay: 30000,
      jitter: true,
      jitterFactor: 0.2,
      backoffMultiplier: 2,
      totalTimeout: 60000,
      retryCondition: (error: any) => isRetryableError(error),
    }
  } as RetryPolicy,

  /** Aggressive retry - for critical operations */
  aggressive: {
    name: 'aggressive',
    description: 'Aggressive retry for critical operations',
    options: {
      maxAttempts: 10,
      baseDelay: 500,
      maxDelay: 60000,
      jitter: true,
      jitterFactor: 0.1,
      backoffMultiplier: 1.5,
      totalTimeout: 300000,
      retryCondition: (error: any) => isRetryableError(error),
    }
  } as RetryPolicy,

  /** Conservative retry - minimal retries */
  conservative: {
    name: 'conservative',
    description: 'Conservative retry with minimal attempts',
    options: {
      maxAttempts: 2,
      baseDelay: 2000,
      maxDelay: 10000,
      jitter: true,
      jitterFactor: 0.3,
      backoffMultiplier: 2,
      totalTimeout: 30000,
      retryCondition: (error: any) => isRetryableError(error),
    }
  } as RetryPolicy,

  /** Database retry - optimized for database operations */
  database: {
    name: 'database',
    description: 'Optimized retry for database operations',
    options: {
      maxAttempts: 5,
      baseDelay: 500,
      maxDelay: 10000,
      jitter: true,
      jitterFactor: 0.1,
      backoffMultiplier: 2,
      totalTimeout: 45000,
      retryCondition: (error: any) => isRetryableError(error) && !isDeadlockError(error),
    }
  } as RetryPolicy,

  /** API retry - optimized for external API calls */
  api: {
    name: 'api',
    description: 'Optimized retry for external API calls',
    options: {
      maxAttempts: 7,
      baseDelay: 1000,
      maxDelay: 30000,
      jitter: true,
      jitterFactor: 0.2,
      backoffMultiplier: 2,
      totalTimeout: 120000,
      retryCondition: (error: any) => isRetryableApiError(error),
    }
  } as RetryPolicy,
} as const;

/**
 * Determine if an error is retryable
 */
export function isRetryableError(error: any): boolean {
  if (!error) return false;
  
  // HTTP errors that are retryable
  if (error.status || error.statusCode) {
    const status = error.status || error.statusCode;
    return [408, 429, 500, 502, 503, 504].includes(status);
  }
  
  // Network errors
  if (error.code) {
    const retryableCodes = [
      'ECONNRESET',
      'ENOTFOUND',
      'ECONNREFUSED',
      'ETIMEDOUT',
      'EAI_AGAIN',
      'NETWORK_ERROR',
      'REQUEST_TIMEOUT'
    ];
    return retryableCodes.includes(error.code);
  }
  
  // Custom retryable errors
  if (error.retryable) {
    return true;
  }
  
  // Database specific errors
  if (error.sqlState) {
    const retryableStates = ['08003', '08006', '08001', '08S01'];
    return retryableStates.includes(error.sqlState);
  }
  
  return false;
}

/**
 * Determine if an API error is retryable
 */
export function isRetryableApiError(error: any): boolean {
  if (!error) return false;
  
  const status = error.status || error.statusCode;
  if (status) {
    // Retry on server errors, rate limits, and timeouts
    return [408, 429, 500, 502, 503, 504].includes(status);
  }
  
  // Network and connection errors
  const retryableCodes = [
    'ECONNRESET',
    'ENOTFOUND',
    'ECONNREFUSED', 
    'ETIMEDOUT',
    'NETWORK_ERROR',
    'TIMEOUT'
  ];
  
  return error.code && retryableCodes.includes(error.code);
}

/**
 * Check if error is a database deadlock
 */
export function isDeadlockError(error: any): boolean {
  if (!error) return false;
  
  // PostgreSQL deadlock codes
  if (error.code === '40P01') return true;
  
  // MySQL deadlock error
  if (error.errno === 1213) return true;
  
  return false;
}