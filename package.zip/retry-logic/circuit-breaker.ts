/**
 * Circuit Breaker implementation for retry logic integration
 */

import { CircuitBreakerOptions, CircuitBreakerState } from './types.js';

/**
 * Circuit breaker states:
 * - CLOSED: Normal operation, requests pass through
 * - OPEN: Failing fast, reject requests immediately
 * - HALF-OPEN: Testing if service has recovered
 */
export class CircuitBreaker {
  private options: Required<CircuitBreakerOptions>;
  private state: CircuitBreakerState;
  private failureTimestamps: number[] = [];
  private successCount = 0;

  constructor(options: Partial<CircuitBreakerOptions> = {}) {
    this.options = {
      failureThreshold: 50, // 50% failure rate
      minimumRequests: 5,   // Need at least 5 requests before opening
      monitoringWindow: 60000, // 1 minute monitoring window
      halfOpenCooldown: 5000, // 5 seconds before trying half-open
      autoResetAttempts: 3,   // Reset after 3 successful requests in half-open
      failureCondition: (error: any) => error && !error.success,
      ...options,
    };

    this.state = {
      state: 'closed',
      consecutiveFailures: 0,
      totalFailures: 0,
      totalRequests: 0,
      halfOpenSuccessCount: 0,
      canReset: false,
    };
  }

  /**
   * Execute a function with circuit breaker protection
   */
  async execute<T>(
    operation: () => Promise<T>,
    fallback?: (error: any) => T | Promise<T>
  ): Promise<T> {
    // Check if circuit breaker allows execution
    this.ensureAllowedToExecute();

    try {
      // Increment request counter
      this.state.totalRequests++;
      this.cleanupOldFailures();

      // Execute the operation
      const result = await operation();

      // Handle success
      this.onSuccess();
      return result;
    } catch (error) {
      // Handle failure
      this.onFailure(error);
      
      // Execute fallback if provided
      if (fallback) {
        try {
          return await fallback(error);
        } catch (fallbackError) {
          // If fallback also fails, throw original error
          throw error;
        }
      }
      
      throw error;
    }
  }

  /**
   * Check if circuit breaker allows execution
   */
  private ensureAllowedToExecute(): void {
    switch (this.state.state) {
      case 'closed':
        // Always allow execution in closed state
        break;

      case 'open':
        // Check if we should transition to half-open
        if (this.shouldTransitionToHalfOpen()) {
          this.transitionToHalfOpen();
        } else {
          throw new Error(`Circuit breaker is OPEN. Service unavailable.`);
        }
        break;

      case 'half-open':
        // Allow limited execution in half-open state
        // The state tracks how many successful requests are needed
        break;
    }
  }

  /**
   * Handle successful operation
   */
  private onSuccess(): void {
    this.failureTimestamps = this.failureTimestamps.filter(
      timestamp => Date.now() - timestamp < this.options.monitoringWindow
    );

    if (this.state.state === 'half-open') {
      this.state.halfOpenSuccessCount++;
      this.successCount++;

      // Check if we can close the circuit breaker
      if (this.state.halfOpenSuccessCount >= this.options.autoResetAttempts) {
        this.transitionToClosed();
      }
    } else {
      this.successCount++;
    }

    // Reset consecutive failures on any success
    this.state.consecutiveFailures = 0;
  }

  /**
   * Handle failed operation
   */
  private onFailure(error: any): void {
    const shouldTrackAsFailure = this.options.failureCondition(error);

    if (!shouldTrackAsFailure) {
      // Don't count this as a failure (e.g., business logic errors)
      return;
    }

    // Record failure
    this.failureTimestamps.push(Date.now());
    this.state.totalFailures++;
    this.state.consecutiveFailures++;

    // Update circuit breaker state based on failures
    this.updateCircuitBreakerState();
  }

  /**
   * Update circuit breaker state based on failure metrics
   */
  private updateCircuitBreakerState(): void {
    if (this.state.state === 'closed') {
      // Check if failure threshold has been reached
      if (this.shouldOpenCircuit()) {
        this.transitionToOpen();
      }
    } else if (this.state.state === 'half-open') {
      // Any failure in half-open state immediately opens the circuit
      this.transitionToOpen();
    }
  }

  /**
   * Check if circuit breaker should open
   */
  private shouldOpenCircuit(): boolean {
    // Need minimum number of requests before considering opening
    if (this.state.totalRequests < this.options.minimumRequests) {
      return false;
    }

    // Check consecutive failures
    const consecutiveFailureRate = this.state.consecutiveFailures / this.state.totalRequests;
    if (consecutiveFailureRate >= (this.options.failureThreshold / 100)) {
      return true;
    }

    // Check overall failure rate in monitoring window
    this.cleanupOldFailures();
    const recentFailureRate = this.failureTimestamps.length / this.state.totalRequests;
    
    return recentFailureRate >= (this.options.failureThreshold / 100);
  }

  /**
   * Check if circuit breaker should transition from open to half-open
   */
  private shouldTransitionToHalfOpen(): boolean {
    if (!this.state.openedAt) return false;
    
    const timeSinceOpened = Date.now() - this.state.openedAt;
    return timeSinceOpened >= this.options.halfOpenCooldown;
  }

  /**
   * Clean up old failure timestamps outside monitoring window
   */
  private cleanupOldFailures(): void {
    const cutoff = Date.now() - this.options.monitoringWindow;
    this.failureTimestamps = this.failureTimestamps.filter(
      timestamp => timestamp > cutoff
    );
  }

  /**
   * Transition to closed state (normal operation)
   */
  private transitionToClosed(): void {
    this.state.state = 'closed';
    this.state.halfOpenSuccessCount = 0;
    this.state.consecutiveFailures = 0;
    this.state.openedAt = undefined;
    this.successCount = 0;
  }

  /**
   * Transition to open state (failing fast)
   */
  private transitionToOpen(): void {
    this.state.state = 'open';
    this.state.openedAt = Date.now();
    this.state.halfOpenSuccessCount = 0;
  }

  /**
   * Transition to half-open state (testing recovery)
   */
  private transitionToHalfOpen(): void {
    this.state.state = 'half-open';
    this.state.halfOpenSuccessCount = 0;
    this.state.consecutiveFailures = 0;
  }

  /**
   * Get current circuit breaker state
   */
  getState(): CircuitBreakerState {
    return { ...this.state };
  }

  /**
   * Get current failure rate
   */
  getFailureRate(): number {
    if (this.state.totalRequests === 0) return 0;
    return (this.state.totalFailures / this.state.totalRequests) * 100;
  }

  /**
   * Get recent failure count (within monitoring window)
   */
  getRecentFailureCount(): number {
    this.cleanupOldFailures();
    return this.failureTimestamps.length;
  }

  /**
   * Force close the circuit breaker (manual reset)
   */
  forceClose(): void {
    this.transitionToClosed();
    this.failureTimestamps = [];
    this.state.totalFailures = 0;
    this.state.totalRequests = 0;
  }

  /**
   * Force open the circuit breaker (manual trip)
   */
  forceOpen(): void {
    this.transitionToOpen();
  }

  /**
   * Reset all statistics
   */
  reset(): void {
    this.state = {
      state: 'closed',
      consecutiveFailures: 0,
      totalFailures: 0,
      totalRequests: 0,
      halfOpenSuccessCount: 0,
      canReset: false,
      openedAt: undefined,
    };
    this.failureTimestamps = [];
    this.successCount = 0;
  }

  /**
   * Create circuit breaker with preset configurations
   */
  static forUseCase(useCase: 'strict' | 'moderate' | 'permissive'): CircuitBreaker {
    const configs = {
      strict: {
        failureThreshold: 30,    // 30% failure rate opens circuit
        minimumRequests: 3,      // Only need 3 requests
        monitoringWindow: 30000, // 30 second window
        halfOpenCooldown: 10000, // 10 second cooldown
        autoResetAttempts: 2,    // Need 2 successful attempts
      },
      moderate: {
        failureThreshold: 50,    // 50% failure rate opens circuit
        minimumRequests: 5,      // Need 5 requests
        monitoringWindow: 60000, // 1 minute window
        halfOpenCooldown: 5000,  // 5 second cooldown
        autoResetAttempts: 3,    // Need 3 successful attempts
      },
      permissive: {
        failureThreshold: 70,    // 70% failure rate opens circuit
        minimumRequests: 10,     // Need 10 requests
        monitoringWindow: 120000, // 2 minute window
        halfOpenCooldown: 3000,  // 3 second cooldown
        autoResetAttempts: 5,    // Need 5 successful attempts
      },
    };

    return new CircuitBreaker(configs[useCase]);
  }
}

/**
 * Decorator-based circuit breaker
 */
export function withCircuitBreaker<T extends any[], R>(
  circuitBreaker: CircuitBreaker,
  operation: (...args: T) => Promise<R>
) {
  return async (...args: T): Promise<R> => {
    return circuitBreaker.execute(() => operation(...args));
  };
}

/**
 * Utility to wrap multiple operations with the same circuit breaker
 */
export class CircuitBreakerGroup {
  private circuitBreaker: CircuitBreaker;
  private operations: Map<string, (...args: any[]) => Promise<any>> = new Map();

  constructor(options?: Partial<CircuitBreakerOptions>) {
    this.circuitBreaker = new CircuitBreaker(options);
  }

  /**
   * Register an operation with the group
   */
  register(name: string, operation: (...args: any[]) => Promise<any>): void {
    this.operations.set(name, operation);
  }

  /**
   * Execute a registered operation
   */
  async execute<R>(name: string, ...args: any[]): Promise<R> {
    const operation = this.operations.get(name);
    if (!operation) {
      throw new Error(`Operation "${name}" not found`);
    }

    return this.circuitBreaker.execute(() => operation(...args));
  }

  /**
   * Get circuit breaker state
   */
  getState(): CircuitBreakerState {
    return this.circuitBreaker.getState();
  }

  /**
   * Get circuit breaker instance for advanced configuration
   */
  getCircuitBreaker(): CircuitBreaker {
    return this.circuitBreaker;
  }
}