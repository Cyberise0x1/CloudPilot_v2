/**
 * Exponential backoff with jitter implementation
 */

import { ExponentialBackoffConfig } from './types.js';

/**
 * Exponential backoff strategy with configurable jitter
 */
export class ExponentialBackoff {
  private config: ExponentialBackoffConfig;

  constructor(config: Partial<ExponentialBackoffConfig> = {}) {
    this.config = {
      initialDelay: 100,
      maxDelay: 60000,
      multiplier: 2,
      jitter: true,
      jitterFactor: 0.2,
      ...config,
    };
  }

  /**
   * Calculate delay for the given attempt number
   */
  calculateDelay(attempt: number): number {
    if (attempt <= 0) return this.config.initialDelay;

    // Calculate exponential delay
    const exponentialDelay = this.config.initialDelay * 
      Math.pow(this.config.multiplier, attempt - 1);

    // Apply jitter if enabled
    if (this.config.jitter) {
      const jitteredDelay = this.applyJitter(exponentialDelay);
      return this.clampDelay(jitteredDelay);
    }

    return this.clampDelay(exponentialDelay);
  }

  /**
   * Apply jitter to prevent thundering herd problem
   */
  private applyJitter(delay: number): number {
    const jitterRange = delay * this.config.jitterFactor;
    const minJitter = delay - jitterRange;
    const maxJitter = delay + jitterRange;
    
    return Math.random() * (maxJitter - minJitter) + minJitter;
  }

  /**
   * Clamp delay to maximum allowed value
   */
  private clampDelay(delay: number): number {
    return Math.min(delay, this.config.maxDelay);
  }

  /**
   * Get next delay for sequence starting from attempt
   */
  getNextDelay(attempt: number): number {
    return this.calculateDelay(attempt);
  }

  /**
   * Generate delay sequence for a given number of attempts
   */
  generateSequence(maxAttempts: number): number[] {
    const delays: number[] = [];
    
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      delays.push(this.calculateDelay(attempt));
    }
    
    return delays;
  }

  /**
   * Calculate total time for all attempts
   */
  calculateTotalTime(maxAttempts: number): number {
    const delays = this.generateSequence(maxAttempts);
    return delays.reduce((total, delay) => total + delay, 0);
  }

  /**
   * Create optimized backoff for specific use cases
   */
  static forPolicy(policy: 'quick' | 'standard' | 'aggressive' | 'conservative' | 'database' | 'api'): ExponentialBackoff {
    const configs = {
      quick: {
        initialDelay: 100,
        maxDelay: 1000,
        multiplier: 2,
        jitter: true,
        jitterFactor: 0.1,
      },
      standard: {
        initialDelay: 1000,
        maxDelay: 30000,
        multiplier: 2,
        jitter: true,
        jitterFactor: 0.2,
      },
      aggressive: {
        initialDelay: 500,
        maxDelay: 60000,
        multiplier: 1.5,
        jitter: true,
        jitterFactor: 0.1,
      },
      conservative: {
        initialDelay: 2000,
        maxDelay: 10000,
        multiplier: 2,
        jitter: true,
        jitterFactor: 0.3,
      },
      database: {
        initialDelay: 500,
        maxDelay: 10000,
        multiplier: 2,
        jitter: true,
        jitterFactor: 0.1,
      },
      api: {
        initialDelay: 1000,
        maxDelay: 30000,
        multiplier: 2,
        jitter: true,
        jitterFactor: 0.2,
      },
    };

    return new ExponentialBackoff(configs[policy]);
  }

  /**
   * Linear backoff strategy (for comparison)
   */
  static linear(): ExponentialBackoff {
    return new ExponentialBackoff({
      initialDelay: 1000,
      maxDelay: 60000,
      multiplier: 1,
      jitter: true,
      jitterFactor: 0.1,
    });
  }

  /**
   * Fixed delay strategy (for comparison)
   */
  static fixed(delay: number = 1000): ExponentialBackoff {
    return new ExponentialBackoff({
      initialDelay: delay,
      maxDelay: delay,
      multiplier: 1,
      jitter: false,
    });
  }

  /**
   * Decorrelated jitter backoff (advanced strategy)
   * Provides better distribution than simple jitter
   */
  static decorrelated(): ExponentialBackoff {
    return new class extends ExponentialBackoff {
      protected applyJitter(delay: number): number {
        // Decorrelated jitter: sleep = min(base * 3, base * (2^attempts + random))
        const base = this.config.initialDelay;
        const maxSleep = Math.min(base * 3, base * Math.pow(2, 0) + Math.random() * delay);
        return this.clampDelay(maxSleep);
      }
    }({
      initialDelay: 1000,
      maxDelay: 30000,
      multiplier: 2,
      jitter: true,
      jitterFactor: 0.2,
    });
  }

  /**
   * Exponential backoff with full jitter (AWS recommended)
   * Sleep = random_between(0, base * 2^n)
   */
  static fullJitter(): ExponentialBackoff {
    return new class extends ExponentialBackoff {
      calculateDelay(attempt: number): number {
        if (attempt <= 0) return this.config.initialDelay;

        const exponentialDelay = this.config.initialDelay * 
          Math.pow(this.config.multiplier, attempt - 1);

        if (this.config.jitter) {
          const maxSleep = exponentialDelay;
          const randomSleep = Math.random() * maxSleep;
          return this.clampDelay(randomSleep);
        }

        return this.clampDelay(exponentialDelay);
      }
    }({
      initialDelay: 1000,
      maxDelay: 30000,
      multiplier: 2,
      jitter: true,
      jitterFactor: 0.2,
    });
  }

  /**
   * Update configuration
   */
  updateConfig(newConfig: Partial<ExponentialBackoffConfig>): void {
    this.config = {
      ...this.config,
      ...newConfig,
    };
  }

  /**
   * Get current configuration
   */
  getConfig(): ExponentialBackoffConfig {
    return { ...this.config };
  }
}

/**
 * Factory functions for common backoff strategies
 */
export const BackoffStrategies = {
  /**
   * Fast retry strategy
   */
  fast: () => ExponentialBackoff.forPolicy('quick'),
  
  /**
   * Balanced strategy
   */
  balanced: () => ExponentialBackoff.forPolicy('standard'),
  
  /**
   * Slow, patient strategy
   */
  slow: () => ExponentialBackoff.forPolicy('aggressive'),
  
  /**
   * Very conservative strategy
   */
  minimal: () => ExponentialBackoff.forPolicy('conservative'),
  
  /**
   * Database optimized
   */
  database: () => ExponentialBackoff.forPolicy('database'),
  
  /**
   * API optimized
   */
  api: () => ExponentialBackoff.forPolicy('api'),
  
  /**
   * Custom strategy
   */
  custom: (config: Partial<ExponentialBackoffConfig>) => new ExponentialBackoff(config),
} as const;

/**
 * Backoff statistics utility
 */
export class BackoffStatistics {
  private delays: number[] = [];

  /**
   * Record a delay for analysis
   */
  recordDelay(delay: number): void {
    this.delays.push(delay);
  }

  /**
   * Get average delay
   */
  getAverageDelay(): number {
    if (this.delays.length === 0) return 0;
    return this.delays.reduce((sum, delay) => sum + delay, 0) / this.delays.length;
  }

  /**
   * Get median delay
   */
  getMedianDelay(): number {
    if (this.delays.length === 0) return 0;
    
    const sorted = [...this.delays].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    
    return sorted.length % 2 === 0 
      ? (sorted[mid - 1] + sorted[mid]) / 2
      : sorted[mid];
  }

  /**
   * Get minimum delay
   */
  getMinDelay(): number {
    return this.delays.length > 0 ? Math.min(...this.delays) : 0;
  }

  /**
   * Get maximum delay
   */
  getMaxDelay(): number {
    return this.delays.length > 0 ? Math.max(...this.delays) : 0;
  }

  /**
   * Get 95th percentile delay
   */
  get95thPercentile(): number {
    if (this.delays.length === 0) return 0;
    
    const sorted = [...this.delays].sort((a, b) => a - b);
    const index = Math.ceil(sorted.length * 0.95) - 1;
    return sorted[Math.max(0, index)];
  }

  /**
   * Reset statistics
   */
  reset(): void {
    this.delays = [];
  }

  /**
   * Get total number of delays recorded
   */
  getCount(): number {
    return this.delays.length;
  }
}