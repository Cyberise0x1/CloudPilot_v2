/**
 * Comprehensive test suite for retry logic system
 */

import { 
  RetryLogic, 
  ExponentialBackoff, 
  CircuitBreaker, 
  AsyncRetryUtils,
  RetryablePromise,
  MonitoringSystems,
  RetryPolicies,
  retry,
  retrySync
} from '../index.js';

describe('Retry Logic System', () => {
  describe('ExponentialBackoff', () => {
    test('should calculate correct delays', () => {
      const backoff = new ExponentialBackoff({
        initialDelay: 100,
        maxDelay: 1000,
        multiplier: 2,
        jitter: false,
      });

      expect(backoff.calculateDelay(1)).toBe(100);
      expect(backoff.calculateDelay(2)).toBe(200);
      expect(backoff.calculateDelay(3)).toBe(400);
      expect(backoff.calculateDelay(4)).toBe(800);
      expect(backoff.calculateDelay(5)).toBe(1000); // Clamped to maxDelay
    });

    test('should apply jitter when enabled', () => {
      const backoff = new ExponentialBackoff({
        initialDelay: 100,
        maxDelay: 1000,
        multiplier: 2,
        jitter: true,
        jitterFactor: 0.1,
      });

      const delay = backoff.calculateDelay(1);
      expect(delay).toBeGreaterThanOrEqual(90); // 100 - (100 * 0.1)
      expect(delay).toBeLessThanOrEqual(110);  // 100 + (100 * 0.1)
    });

    test('should generate correct delay sequences', () => {
      const backoff = new ExponentialBackoff({
        initialDelay: 1000,
        maxDelay: 10000,
        multiplier: 2,
        jitter: false,
      });

      const sequence = backoff.generateSequence(3);
      expect(sequence).toEqual([1000, 2000, 4000]);
    });

    test('should calculate total time correctly', () => {
      const backoff = new ExponentialBackoff({
        initialDelay: 1000,
        maxDelay: 10000,
        multiplier: 2,
        jitter: false,
      });

      const totalTime = backoff.calculateTotalTime(3);
      expect(totalTime).toBe(7000); // 1000 + 2000 + 4000
    });
  });

  describe('CircuitBreaker', () => {
    test('should start in closed state', () => {
      const breaker = new CircuitBreaker();
      const state = breaker.getState();
      expect(state.state).toBe('closed');
    });

    test('should open after reaching failure threshold', async () => {
      const breaker = new CircuitBreaker({
        failureThreshold: 50,
        minimumRequests: 2,
        monitoringWindow: 60000,
      });

      // Simulate 4 failures out of 4 requests (100% failure rate)
      for (let i = 0; i < 4; i++) {
        try {
          await breaker.execute(async () => {
            throw new Error('Service error');
          });
        } catch (error) {
          // Expected to fail
        }
      }

      const state = breaker.getState();
      expect(state.state).toBe('open');
    });

    test('should remain closed with successful operations', async () => {
      const breaker = new CircuitBreaker({
        failureThreshold: 50,
        minimumRequests: 5,
      });

      // All successful operations
      for (let i = 0; i < 5; i++) {
        await breaker.execute(async () => 'success');
      }

      const state = breaker.getState();
      expect(state.state).toBe('closed');
      expect(state.consecutiveFailures).toBe(0);
    });

    test('should provide fallback when circuit is open', async () => {
      const breaker = new CircuitBreaker({
        failureThreshold: 50,
        minimumRequests: 2,
      });

      // Force open the circuit
      breaker.forceOpen();

      const result = await breaker.execute(
        async () => 'should not reach here',
        () => 'fallback response'
      );

      expect(result).toBe('fallback response');
    });
  });

  describe('RetryLogic', () => {
    test('should succeed on first attempt', async () => {
      const retryLogic = new RetryLogic();
      const result = await retryLogic.execute(async () => 'success');

      expect(result.success).toBe(true);
      expect(result.result).toBe('success');
      expect(result.attempts).toBe(1);
    });

    test('should retry on failure and eventually succeed', async () => {
      let attempts = 0;
      const retryLogic = new RetryLogic({
        maxAttempts: 3,
        baseDelay: 100,
      });

      const result = await retryLogic.execute(async () => {
        attempts++;
        if (attempts < 3) {
          throw new Error('Temporary failure');
        }
        return 'success';
      });

      expect(result.success).toBe(true);
      expect(result.result).toBe('success');
      expect(result.attempts).toBe(3);
    });

    test('should exhaust retries and fail', async () => {
      const retryLogic = new RetryLogic({
        maxAttempts: 3,
        baseDelay: 100,
        retryCondition: () => true, // Always retry
      });

      const result = await retryLogic.execute(async () => {
        throw new Error('Persistent failure');
      });

      expect(result.success).toBe(false);
      expect(result.attempts).toBe(3);
      expect(result.error).toBeDefined();
    });

    test('should respect custom retry conditions', async () => {
      const retryLogic = new RetryLogic({
        maxAttempts: 3,
        baseDelay: 100,
        retryCondition: (error) => error.status >= 500, // Only retry server errors
      });

      // Should not retry on 400 error
      const result1 = await retryLogic.execute(async () => {
        const error = new Error('Bad request');
        error.status = 400;
        throw error;
      });

      expect(result1.success).toBe(false);
      expect(result1.attempts).toBe(1); // Only one attempt

      // Should retry on 500 error
      let attempts = 0;
      const result2 = await retryLogic.execute(async () => {
        attempts++;
        if (attempts < 2) {
          const error = new Error('Server error');
          error.status = 500;
          throw error;
        }
        return 'success';
      });

      expect(result2.success).toBe(true);
      expect(result2.attempts).toBe(2);
    });

    test('should track metrics correctly', async () => {
      const retryLogic = new RetryLogic();

      // Successful operation
      await retryLogic.execute(async () => 'success');
      let metrics = retryLogic.getMetrics();
      expect(metrics.successes).toBe(1);
      expect(metrics.failures).toBe(0);

      // Failed operation
      await retryLogic.execute(async () => {
        throw new Error('failure');
      });
      metrics = retryLogic.getMetrics();
      expect(metrics.successes).toBe(1);
      expect(metrics.failures).toBe(1);
    });
  });

  describe('AsyncRetryUtils', () => {
    test('should retry with default options', async () => {
      let attempts = 0;
      const result = await AsyncRetryUtils.retry(async () => {
        attempts++;
        if (attempts < 2) {
          throw new Error('temporary failure');
        }
        return 'success';
      });

      expect(result).toBe('success');
      expect(attempts).toBe(2);
    });

    test('should retry with backoff strategy', async () => {
      let attempts = 0;
      const startTime = Date.now();

      const result = await AsyncRetryUtils.retryWithBackoff(
        async () => {
          attempts++;
          if (attempts < 3) {
            throw new Error('failure');
          }
          return 'success';
        },
        'quick'
      );

      const endTime = Date.now();
      const duration = endTime - startTime;

      expect(result).toBe('success');
      expect(attempts).toBe(3);
      expect(duration).toBeGreaterThan(100); // Should have some delay
    });

    test('should retry until condition is met', async () => {
      let counter = 0;
      const result = await AsyncRetryUtils.retryUntil(
        async () => {
          counter++;
          return { status: counter >= 3 ? 'ready' : 'not-ready' };
        },
        (result) => result.status === 'ready',
        5
      );

      expect(result.status).toBe('ready');
      expect(counter).toBe(3);
    });

    test('should handle timeout correctly', async () => {
      const result = AsyncRetryUtils.retryWithTimeout(
        async () => {
          await new Promise(resolve => setTimeout(resolve, 2000));
          return 'success';
        },
        1000 // 1 second timeout
      );

      await expect(result).rejects.toThrow('timeout');
    });
  });

  describe('RetryablePromise', () => {
    test('should retry and resolve on success', async () => {
      let attempts = 0;
      const retryable = new RetryablePromise(async () => {
        attempts++;
        if (attempts < 2) {
          throw new Error('temporary failure');
        }
        return 'success';
      }, { maxAttempts: 3 });

      const result = await retryable.thenResolving();
      expect(result).toBe('success');
      expect(attempts).toBe(2);
    });

    test('should reject after exhausting retries', async () => {
      const retryable = new RetryablePromise(async () => {
        throw new Error('persistent failure');
      }, { maxAttempts: 2 });

      await expect(retryable.thenResolving()).rejects.toThrow('persistent failure');
    });

    test('should work with promise chain methods', async () => {
      let attempts = 0;
      const retryable = new RetryablePromise(async () => {
        attempts++;
        if (attempts < 2) {
          throw new Error('failure');
        }
        return 10;
      }, { maxAttempts: 3 });

      const result = await retryable
        .then(value => value * 2)
        .catch(error => {
          throw new Error('Should not reach here');
        });

      expect(result).toBe(20);
      expect(attempts).toBe(2);
    });
  });

  describe('Decorators', () => {
    test('should apply retry decorator to async methods', async () => {
      let attempts = 0;

      class TestService {
        @retry({ maxAttempts: 3, baseDelay: 100 })
        async fetchData() {
          attempts++;
          if (attempts < 2) {
            throw new Error('temporary failure');
          }
          return { data: 'success' };
        }
      }

      const service = new TestService();
      const result = await service.fetchData();

      expect(result.data).toBe('success');
      expect(attempts).toBe(2);
    });

    test('should apply retry decorator to sync methods', () => {
      let attempts = 0;

      class TestService {
        @retrySync({ maxAttempts: 3, baseDelay: 100 })
        syncOperation() {
          attempts++;
          if (attempts < 2) {
            throw new Error('temporary failure');
          }
          return 'success';
        }
      }

      const service = new TestService();
      const result = service.syncOperation();

      expect(result).toBe('success');
      expect(attempts).toBe(2);
    });
  });

  describe('Monitoring', () => {
    test('should collect metrics correctly', () => {
      const monitoring = MonitoringSystems.basic();
      const metrics = monitoring.getMetricsCollector();

      metrics.recordRetryAttempt(1, 1000);
      metrics.recordRetryAttempt(2, 2000);
      metrics.recordSuccess(2, 3000);

      const collectedMetrics = metrics.getMetrics();
      expect(collectedMetrics.attempts).toBe(2);
      expect(collectedMetrics.successes).toBe(1);
      expect(collectedMetrics.averageDelay).toBe(1500);
    });

    test('should log messages correctly', () => {
      const monitoring = MonitoringSystems.basic();
      const logger = monitoring.getLogger();

      logger.logRetryAttempt(1, 3, 1000, new Error('test error'));
      logger.logRetrySuccess(2, 2000, 'success');

      const logs = logger.getLogs();
      expect(logs.length).toBe(2);
      expect(logs[0].level).toBe('INFO');
      expect(logs[0].message).toContain('Retry attempt');
      expect(logs[1].message).toContain('Retry succeeded');
    });

    test('should generate comprehensive monitoring report', () => {
      const monitoring = MonitoringSystems.detailed();
      const metrics = monitoring.getMetricsCollector();

      // Record some test data
      metrics.recordRetryAttempt(1, 1000);
      metrics.recordRetryAttempt(2, 2000);
      metrics.recordSuccess(2, 3000);

      const report = monitoring.getMonitoringReport();

      expect(report.metrics).toBeDefined();
      expect(report.performance).toBeDefined();
      expect(report.logs).toBeDefined();
      expect(report.metrics.successes).toBe(1);
    });
  });

  describe('RetryPolicies', () => {
    test('should have predefined policies', () => {
      expect(RetryPolicies.quick).toBeDefined();
      expect(RetryPolicies.standard).toBeDefined();
      expect(RetryPolicies.aggressive).toBeDefined();
      expect(RetryPolicies.conservative).toBeDefined();
      expect(RetryPolicies.database).toBeDefined();
      expect(RetryPolicies.api).toBeDefined();
    });

    test('should have correct policy configurations', () => {
      expect(RetryPolicies.quick.options.maxAttempts).toBe(3);
      expect(RetryPolicies.quick.options.baseDelay).toBe(100);

      expect(RetryPolicies.aggressive.options.maxAttempts).toBe(10);
      expect(RetryPolicies.aggressive.options.baseDelay).toBe(500);

      expect(RetryPolicies.conservative.options.maxAttempts).toBe(2);
      expect(RetryPolicies.conservative.options.baseDelay).toBe(2000);
    });
  });

  describe('Error classification', () => {
    test('should correctly identify retryable errors', () => {
      const { isRetryableError } = require('../types.js');

      // HTTP retryable errors
      expect(isRetryableError({ status: 500 })).toBe(true);
      expect(isRetryableError({ status: 503 })).toBe(true);
      expect(isRetryableError({ status: 429 })).toBe(true);
      expect(isRetryableError({ status: 408 })).toBe(true);

      // HTTP non-retryable errors
      expect(isRetryableError({ status: 400 })).toBe(false);
      expect(isRetryableError({ status: 404 })).toBe(false);

      // Network errors
      expect(isRetryableError({ code: 'ECONNRESET' })).toBe(true);
      expect(isRetryableError({ code: 'ETIMEDOUT' })).toBe(true);
      expect(isRetryableError({ code: 'ECONNREFUSED' })).toBe(true);

      // Non-retryable errors
      expect(isRetryableError({ code: 'ENOTFOUND' })).toBe(true); // This is retryable
      expect(isRetryableError({})).toBe(false);
      expect(isRetryableError(null)).toBe(false);
      expect(isRetryableError(undefined)).toBe(false);
    });

    test('should identify deadlock errors', () => {
      const { isDeadlockError } = require('../types.js');

      // PostgreSQL deadlock
      expect(isDeadlockError({ code: '40P01' })).toBe(true);

      // MySQL deadlock
      expect(isDeadlockError({ errno: 1213 })).toBe(true);

      // Non-deadlock errors
      expect(isDeadlockError({ code: '23505' })).toBe(false);
      expect(isDeadlockError({})).toBe(false);
    });
  });

  describe('Integration Tests', () => {
    test('should work with circuit breaker and retry together', async () => {
      const circuitBreaker = new CircuitBreaker({
        failureThreshold: 50,
        minimumRequests: 2,
      });

      const retryLogic = new RetryLogic(
        { maxAttempts: 2, baseDelay: 100 },
        circuitBreaker
      );

      let attempts = 0;
      const result = await retryLogic.execute(async () => {
        attempts++;
        if (attempts < 3) {
          throw new Error('Service error');
        }
        return 'success';
      });

      expect(result.success).toBe(true);
      expect(result.result).toBe('success');
    });

    test('should handle complex error scenarios', async () => {
      const monitoring = MonitoringSystems.detailed();
      let attempts = 0;

      const result = await AsyncRetryUtils.retry(
        async () => {
          attempts++;
          if (attempts === 1) {
            const error = new Error('Network error');
            error.code = 'ECONNRESET';
            throw error;
          } else if (attempts === 2) {
            const error = new Error('Server error');
            error.status = 500;
            throw error;
          }
          return 'finally success';
        },
        {
          maxAttempts: 5,
          onRetry: (error, attempt, delay) => {
            monitoring.getMetricsCollector().recordRetryAttempt(attempt, delay, error);
          },
          onSuccess: (result, attempt) => {
            monitoring.getMetricsCollector().recordSuccess(attempt, 100);
          },
        }
      );

      expect(result).toBe('finally success');
      expect(attempts).toBe(3);

      const metrics = monitoring.getMetricsCollector().getMetrics();
      expect(metrics.attempts).toBe(3);
      expect(metrics.successes).toBe(1);
    });
  });

  describe('Performance Tests', () => {
    test('should complete operations within reasonable time', async () => {
      const startTime = Date.now();

      await AsyncRetryUtils.retryWithBackoff(
        async () => {
          if (Math.random() < 0.1) {
            throw new Error('rare failure');
          }
          return 'success';
        },
        'quick'
      );

      const endTime = Date.now();
      const duration = endTime - startTime;

      // Should complete relatively quickly even with retries
      expect(duration).toBeLessThan(10000); // 10 seconds max
    });

    test('should handle concurrent operations efficiently', async () => {
      const operations = Array.from({ length: 10 }, (_, i) =>
        AsyncRetryUtils.retry(
          async () => {
            if (Math.random() < 0.3) {
              throw new Error('concurrent failure');
            }
            return `operation-${i}`;
          },
          { maxAttempts: 2 }
        )
      );

      const results = await Promise.allSettled(operations);
      const successful = results.filter(r => r.status === 'fulfilled');

      expect(successful.length).toBeGreaterThan(0);
    });
  });
});