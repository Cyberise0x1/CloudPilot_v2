/**
 * Core retry logic implementation with decorators and utilities
 */

import { 
  RetryOptions, 
  RetryFunction, 
  SyncRetryFunction, 
  RetryResult, 
  RetryContext,
  RetryMetrics,
  isRetryableError,
  RetryPolicies 
} from './types.js';
import { ExponentialBackoff } from './exponential-backoff.js';
import { CircuitBreaker } from './circuit-breaker.js';

const DEFAULT_OPTIONS: Required<RetryOptions> = {
  maxAttempts: 3,
  baseDelay: 1000,
  maxDelay: 30000,
  jitter: true,
  jitterFactor: 0.2,
  backoffMultiplier: 2,
  retryCondition: isRetryableError,
  onRetry: undefined,
  onExhausted: undefined,
  onSuccess: undefined,
  totalTimeout: 60000,
  abortOnTimeout: true,
};

/**
 * Core retry logic implementation
 */
export class RetryLogic {
  private options: Required<RetryOptions>;
  private backoff: ExponentialBackoff;
  private circuitBreaker?: CircuitBreaker;
  private metrics: RetryMetrics;
  private statistics: {
    retryDelays: number[];
    operationTimes: number[];
  };

  constructor(options: Partial<RetryOptions> = {}, circuitBreaker?: CircuitBreaker) {
    this.options = { ...DEFAULT_OPTIONS, ...options };
    this.circuitBreaker = circuitBreaker;
    
    this.backoff = new ExponentialBackoff({
      initialDelay: this.options.baseDelay,
      maxDelay: this.options.maxDelay,
      multiplier: this.options.backoffMultiplier,
      jitter: this.options.jitter,
      jitterFactor: this.options.jitterFactor,
    });

    this.metrics = this.createInitialMetrics();
    this.statistics = {
      retryDelays: [],
      operationTimes: [],
    };
  }

  /**
   * Execute async function with retry logic
   */
  async execute<T>(fn: RetryFunction<T>): Promise<RetryResult<T>> {
    const startTime = Date.now();
    let attempts = 0;
    let lastError: any;

    const context: RetryContext = {
      attempt: 0,
      circuitBreaker: this.circuitBreaker?.getState().state || 'closed',
      metrics: this.metrics,
      aborted: false,
    };

    // Main retry loop
    for (let attempt = 1; attempt <= this.options.maxAttempts; attempt++) {
      context.attempt = attempt;
      const attemptStartTime = Date.now();

      try {
        // Check total timeout
        if (this.options.totalTimeout && Date.now() - startTime >= this.options.totalTimeout) {
          if (this.options.abortOnTimeout) {
            context.aborted = true;
            context.abortReason = 'Total timeout exceeded';
            break;
          }
        }

        // Execute the function
        let result: T;
        if (this.circuitBreaker) {
          result = await this.circuitBreaker.execute(() => fn());
        } else {
          result = await fn();
        }

        // Update statistics
        const attemptTime = Date.now() - attemptStartTime;
        this.statistics.operationTimes.push(attemptTime);
        this.metrics.successes++;
        this.metrics.attempts = attempt;

        // Call success callback
        if (this.options.onSuccess) {
          this.options.onSuccess(result, attempt, attempts);
        }

        // Update metrics
        this.metrics.successRate = (this.metrics.successes / this.metrics.attempts) * 100;
        this.metrics.lastRetryTime = Date.now();

        return {
          success: true,
          result,
          attempts: attempt,
          context,
          totalTime: Date.now() - startTime,
        };
      } catch (error) {
        lastError = error;
        attempts = attempt;

        // Update metrics for failure
        this.metrics.failures++;
        this.metrics.attempts = attempt;

        // Record error type
        const errorType = this.getErrorType(error);
        this.metrics.errorTypes.set(errorType, (this.metrics.errorTypes.get(errorType) || 0) + 1);

        // Check if error is retryable
        if (!this.options.retryCondition(error, attempt)) {
          // Non-retryable error, exit immediately
          this.updateAverageMetrics(attempt, Date.now() - attemptStartTime);
          return {
            success: false,
            error,
            attempts: attempt,
            context,
            totalTime: Date.now() - startTime,
          };
        }

        // Calculate delay for next attempt
        const delay = this.backoff.calculateDelay(attempt);
        this.statistics.retryDelays.push(delay);
        
        // Update average metrics
        this.updateAverageMetrics(attempt, Date.now() - attemptStartTime);

        // Call retry callback
        if (this.options.onRetry) {
          this.options.onRetry(error, attempt, delay);
        }

        // Wait before next attempt (if not last attempt)
        if (attempt < this.options.maxAttempts) {
          await this.sleep(delay);
        }
      }
    }

    // All retries exhausted
    this.metrics.attempts = attempts;
    this.metrics.successRate = (this.metrics.successes / this.metrics.attempts) * 100;

    if (this.options.onExhausted) {
      this.options.onExhausted(lastError, attempts, this.options.maxAttempts);
    }

    return {
      success: false,
      error: lastError,
      attempts,
      context,
      totalTime: Date.now() - startTime,
    };
  }

  /**
   * Execute sync function with retry logic
   */
  executeSync<T>(fn: SyncRetryFunction<T>): RetryResult<T> {
    const startTime = Date.now();
    let attempts = 0;
    let lastError: any;

    const context: RetryContext = {
      attempt: 0,
      circuitBreaker: this.circuitBreaker?.getState().state || 'closed',
      metrics: this.metrics,
      aborted: false,
    };

    // Main retry loop
    for (let attempt = 1; attempt <= this.options.maxAttempts; attempt++) {
      context.attempt = attempt;
      const attemptStartTime = Date.now();

      try {
        // Check total timeout
        if (this.options.totalTimeout && Date.now() - startTime >= this.options.totalTimeout) {
          if (this.options.abortOnTimeout) {
            context.aborted = true;
            context.abortReason = 'Total timeout exceeded';
            break;
          }
        }

        // Execute the function
        let result: T;
        if (this.circuitBreaker) {
          result = this.circuitBreaker.execute(() => Promise.resolve(fn()));
        } else {
          result = fn();
        }

        // Update statistics
        const attemptTime = Date.now() - attemptStartTime;
        this.statistics.operationTimes.push(attemptTime);
        this.metrics.successes++;
        this.metrics.attempts = attempt;

        // Call success callback
        if (this.options.onSuccess) {
          this.options.onSuccess(result, attempt, attempts);
        }

        // Update metrics
        this.metrics.successRate = (this.metrics.successes / this.metrics.attempts) * 100;
        this.metrics.lastRetryTime = Date.now();

        return {
          success: true,
          result,
          attempts: attempt,
          context,
          totalTime: Date.now() - startTime,
        };
      } catch (error) {
        lastError = error;
        attempts = attempt;

        // Update metrics for failure
        this.metrics.failures++;
        this.metrics.attempts = attempt;

        // Record error type
        const errorType = this.getErrorType(error);
        this.metrics.errorTypes.set(errorType, (this.metrics.errorTypes.get(errorType) || 0) + 1);

        // Check if error is retryable
        if (!this.options.retryCondition(error, attempt)) {
          // Non-retryable error, exit immediately
          this.updateAverageMetrics(attempt, Date.now() - attemptStartTime);
          return {
            success: false,
            error,
            attempts: attempt,
            context,
            totalTime: Date.now() - startTime,
          };
        }

        // Calculate delay for next attempt
        const delay = this.backoff.calculateDelay(attempt);
        this.statistics.retryDelays.push(delay);
        
        // Update average metrics
        this.updateAverageMetrics(attempt, Date.now() - attemptStartTime);

        // Call retry callback
        if (this.options.onRetry) {
          this.options.onRetry(error, attempt, delay);
        }

        // Wait before next attempt (if not last attempt)
        if (attempt < this.options.maxAttempts) {
          this.sleepSync(delay);
        }
      }
    }

    // All retries exhausted
    this.metrics.attempts = attempts;
    this.metrics.successRate = (this.metrics.successes / this.metrics.attempts) * 100;

    if (this.options.onExhausted) {
      this.options.onExhausted(lastError, attempts, this.options.maxAttempts);
    }

    return {
      success: false,
      error: lastError,
      attempts,
      context,
      totalTime: Date.now() - startTime,
    };
  }

  /**
   * Get retry metrics
   */
  getMetrics(): RetryMetrics {
    return { ...this.metrics };
  }

  /**
   * Reset metrics
   */
  resetMetrics(): void {
    this.metrics = this.createInitialMetrics();
    this.statistics = {
      retryDelays: [],
      operationTimes: [],
    };
  }

  /**
   * Get statistics
   */
  getStatistics() {
    return {
      retryDelays: [...this.statistics.retryDelays],
      operationTimes: [...this.statistics.operationTimes],
      averageDelay: this.calculateAverage(this.statistics.retryDelays),
      averageOperationTime: this.calculateAverage(this.statistics.operationTimes),
      minDelay: this.statistics.retryDelays.length > 0 ? Math.min(...this.statistics.retryDelays) : 0,
      maxDelay: this.statistics.retryDelays.length > 0 ? Math.max(...this.statistics.retryDelays) : 0,
      medianDelay: this.calculateMedian(this.statistics.retryDelays),
    };
  }

  /**
   * Private helper methods
   */
  private createInitialMetrics(): RetryMetrics {
    return {
      attempts: 0,
      successes: 0,
      failures: 0,
      circuitBreakerOpens: 0,
      averageDelay: 0,
      totalRetryTime: 0,
      successRate: 0,
      errorTypes: new Map(),
      lastRetryTime: 0,
    };
  }

  private async sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private sleepSync(ms: number): void {
    const start = Date.now();
    while (Date.now() - start < ms) {
      // Busy wait for sync operations
    }
  }

  private getErrorType(error: any): string {
    if (!error) return 'Unknown';
    
    // HTTP errors
    if (error.status || error.statusCode) {
      return `HTTP_${error.status || error.statusCode}`;
    }
    
    // Network errors
    if (error.code) {
      return `NETWORK_${error.code}`;
    }
    
    // Database errors
    if (error.code === 'SQL_ERROR') {
      return 'DATABASE_ERROR';
    }
    
    // Custom error types
    if (error.name) {
      return error.name;
    }
    
    return error.constructor?.name || 'Unknown';
  }

  private updateAverageMetrics(attempt: number, attemptTime: number): void {
    // Update average delay
    if (this.statistics.retryDelays.length > 0) {
      this.metrics.averageDelay = this.calculateAverage(this.statistics.retryDelays);
    }
    
    // Update total retry time
    this.metrics.totalRetryTime += attemptTime;
  }

  private calculateAverage(numbers: number[]): number {
    if (numbers.length === 0) return 0;
    return numbers.reduce((sum, num) => sum + num, 0) / numbers.length;
  }

  private calculateMedian(numbers: number[]): number {
    if (numbers.length === 0) return 0;
    
    const sorted = [...numbers].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    
    return sorted.length % 2 === 0 
      ? (sorted[mid - 1] + sorted[mid]) / 2
      : sorted[mid];
  }
}

/**
 * Decorator for retry logic
 */
export function retry(
  options?: Partial<RetryOptions>,
  circuitBreaker?: CircuitBreaker
) {
  return function (target: any, propertyName: string, descriptor: PropertyDescriptor) {
    const method = descriptor.value;

    descriptor.value = async function (...args: any[]) {
      const retryLogic = new RetryLogic(options, circuitBreaker);
      const result = await retryLogic.execute(() => method.apply(this, args));
      return result.success ? result.result : Promise.reject(result.error);
    };

    return descriptor;
  };
}

/**
 * Sync decorator for retry logic
 */
export function retrySync(
  options?: Partial<RetryOptions>,
  circuitBreaker?: CircuitBreaker
) {
  return function (target: any, propertyName: string, descriptor: PropertyDescriptor) {
    const method = descriptor.value;

    descriptor.value = function (...args: any[]) {
      const retryLogic = new RetryLogic(options, circuitBreaker);
      const result = retryLogic.executeSync(() => method.apply(this, args));
      return result.success ? result.result : (() => { throw result.error; })();
    };

    return descriptor;
  };
}

/**
 * Factory function for creating retry instances
 */
export function createRetry(
  policy?: 'quick' | 'standard' | 'aggressive' | 'conservative' | 'database' | 'api',
  circuitBreaker?: CircuitBreaker
): RetryLogic {
  if (policy) {
    return new RetryLogic(RetryPolicies[policy].options, circuitBreaker);
  }
  return new RetryLogic({}, circuitBreaker);
}