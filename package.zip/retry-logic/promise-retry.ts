/**
 * Promise-based retry patterns and utilities
 */

import { RetryOptions } from './types.js';
import { RetryLogic } from './retry.js';

/**
 * Promise wrapper with retry functionality
 */
export class RetryablePromise<T> {
  private promiseFactory: () => Promise<T>;
  private retryLogic: RetryLogic;

  constructor(
    promiseFactory: () => Promise<T>,
    options?: Partial<RetryOptions>
  ) {
    this.promiseFactory = promiseFactory;
    this.retryLogic = new RetryLogic(options);
  }

  /**
   * Execute the retryable promise
   */
  execute(): Promise<RetryResult<T>> {
    return this.retryLogic.execute(this.promiseFactory);
  }

  /**
   * Execute and return the result directly (throws on failure)
   */
  thenResolving(): Promise<T> {
    return this.execute().then(result => {
      if (!result.success) {
        throw result.error;
      }
      return result.result!;
    });
  }

  /**
   * Create a retryable promise with timeout
   */
  withTimeout(timeoutMs: number): RetryablePromise<T> {
    const newOptions = {
      ...this.retryLogic,
      totalTimeout: timeoutMs,
      abortOnTimeout: true,
    };

    return new RetryablePromise(this.promiseFactory, newOptions);
  }

  /**
   * Chain operations after retry
   */
  then<U>(onFulfilled?: (value: T) => U | Promise<U>, onRejected?: (reason: any) => U | Promise<U>): Promise<U> {
    return this.thenResolving().then(onFulfilled, onRejected);
  }

  /**
   * Catch errors
   */
  catch<U>(onRejected?: (reason: any) => U | Promise<U>): Promise<T | U> {
    return this.thenResolving().catch(onRejected);
  }

  /**
   * Finally handler
   */
  finally(onFinally?: () => void): Promise<T> {
    return this.thenResolving().finally(onFinally);
  }

  /**
   * Convert to regular promise
   */
  toPromise(): Promise<T> {
    return this.thenResolving();
  }
}

/**
 * Promise-based retry utilities
 */
export class PromiseRetryUtils {
  /**
   * Create a retryable promise
   */
  static from<T>(
    promiseFactory: () => Promise<T>,
    options?: Partial<RetryOptions>
  ): RetryablePromise<T> {
    return new RetryablePromise(promiseFactory, options);
  }

  /**
   * Retry a promise with custom retry logic
   */
  static async retry<T>(
    promiseFactory: () => Promise<T>,
    retryFn: (error: any, attempt: number) => Promise<boolean>,
    maxAttempts: number = 3,
    delayMs: number = 1000
  ): Promise<T> {
    let lastError: any;
    
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        return await promiseFactory();
      } catch (error) {
        lastError = error;
        
        // Check if we should retry
        const shouldRetry = await retryFn(error, attempt);
        
        if (!shouldRetry || attempt === maxAttempts) {
          throw error;
        }
        
        // Wait before retry
        await PromiseRetryUtils.sleep(delayMs);
      }
    }
    
    throw lastError;
  }

  /**
   * Retry with exponential backoff
   */
  static async retryWithBackoff<T>(
    promiseFactory: () => Promise<T>,
    baseDelay: number = 1000,
    maxAttempts: number = 3,
    multiplier: number = 2
  ): Promise<T> {
    return PromiseRetryUtils.retry(
      promiseFactory,
      async () => true, // Always retry for backoff
      maxAttempts,
      baseDelay
    );
  }

  /**
   * Retry with exponential backoff and jitter
   */
  static async retryWithJitter<T>(
    promiseFactory: () => Promise<T>,
    baseDelay: number = 1000,
    maxAttempts: number = 3,
    jitterFactor: number = 0.2
  ): Promise<T> {
    return PromiseRetryUtils.retry(
      promiseFactory,
      async (_, attempt) => {
        const delay = baseDelay * Math.pow(2, attempt - 1);
        const jitter = delay * jitterFactor * (Math.random() * 2 - 1);
        await PromiseRetryUtils.sleep(delay + jitter);
        return true;
      },
      maxAttempts,
      0 // No additional delay since it's handled in retryFn
    );
  }

  /**
   * Retry with timeout
   */
  static async retryWithTimeout<T>(
    promiseFactory: () => Promise<T>,
    timeoutMs: number,
    maxAttempts: number = 3,
    delayMs: number = 1000
  ): Promise<T> {
    const startTime = Date.now();
    
    return PromiseRetryUtils.retry(
      async () => {
        const remainingTime = timeoutMs - (Date.now() - startTime);
        if (remainingTime <= 0) {
          throw new Error('Timeout exceeded');
        }
        
        const timeoutPromise = new Promise<never>((_, reject) => {
          setTimeout(() => reject(new Error(`Timeout after ${remainingTime}ms`)), remainingTime);
        });
        
        return Promise.race([promiseFactory(), timeoutPromise]);
      },
      async () => {
        const elapsed = Date.now() - startTime;
        return elapsed < timeoutMs;
      },
      maxAttempts,
      delayMs
    );
  }

  /**
   * Retry until condition is met
   */
  static async retryUntil<T>(
    promiseFactory: () => Promise<T>,
    condition: (result: T) => boolean,
    maxAttempts: number = 10,
    delayMs: number = 1000
  ): Promise<T> {
    return PromiseRetryUtils.retry(
      promiseFactory,
      async (error, attempt) => {
        if (attempt >= maxAttempts) {
          return false;
        }
        return !error; // Only continue if no error
      },
      maxAttempts,
      delayMs
    );
  }

  /**
   * Retry with exponential backoff until condition is met
   */
  static async retryBackoffUntil<T>(
    promiseFactory: () => Promise<T>,
    condition: (result: T) => boolean,
    maxAttempts: number = 10,
    baseDelay: number = 1000
  ): Promise<T> {
    return PromiseRetryUtils.retry(
      promiseFactory,
      async (error, attempt) => {
        if (attempt >= maxAttempts) {
          return false;
        }
        
        const delay = baseDelay * Math.pow(2, attempt - 1);
        await PromiseRetryUtils.sleep(delay);
        return true;
      },
      maxAttempts,
      0
    );
  }

  /**
   * Concurrent retry with promises
   */
  static async retryAll<T>(
    promises: (() => Promise<T>)[],
    options?: Partial<RetryOptions>
  ): Promise<(T | Error)[]> {
    const retryablePromises = promises.map(promiseFactory =>
      PromiseRetryUtils.from(promiseFactory, options).thenResolving()
    );

    return Promise.allSettled(retryablePromises).then(results =>
      results.map(result =>
        result.status === 'fulfilled' ? result.value : result.reason
      )
    );
  }

  /**
   * Retry first successful promise
   */
  static async retryFirst<T>(
    promises: (() => Promise<T>)[],
    maxAttempts: number = 3,
    delayMs: number = 1000
  ): Promise<T> {
    const errors: any[] = [];
    
    for (const [index, promiseFactory] of promises.entries()) {
      try {
        return await promiseFactory();
      } catch (error) {
        errors.push({ index, error });
        if (index < promises.length - 1) {
          await PromiseRetryUtils.sleep(delayMs);
        }
      }
    }
    
    throw new Error(`All promises failed: ${errors.map(e => `Promise ${e.index}: ${e.error}`).join(', ')}`);
  }

  /**
   * Retry with circuit breaker pattern using promises
   */
  static async retryWithCircuitBreaker<T>(
    promiseFactory: () => Promise<T>,
    circuitBreaker: any,
    fallback?: (error: any) => Promise<T>
  ): Promise<T> {
    try {
      return await circuitBreaker.execute(promiseFactory);
    } catch (error) {
      if (fallback) {
        return await fallback(error);
      }
      throw error;
    }
  }

  /**
   * Retry with exponential backoff and custom error handling
   */
  static async retryWithCustomErrorHandling<T>(
    promiseFactory: () => Promise<T>,
    errorHandlers: Map<string | number, (error: any, attempt: number) => Promise<boolean>>,
    defaultDelay: number = 1000,
    maxAttempts: number = 3
  ): Promise<T> {
    let lastError: any;
    
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        return await promiseFactory();
      } catch (error) {
        lastError = error;
        
        // Get error identifier
        const errorId = error.status || error.code || error.name || 'unknown';
        const handler = errorHandlers.get(errorId);
        
        if (handler) {
          const shouldRetry = await handler(error, attempt);
          if (!shouldRetry || attempt === maxAttempts) {
            throw error;
          }
        } else {
          // Default handler
          if (attempt === maxAttempts) {
            throw error;
          }
        }
        
        // Calculate delay based on error type
        let delay = defaultDelay;
        if (error.status === 429) {
          // Rate limit - longer delay
          delay = (error.retryAfter || 5) * 1000;
        } else if (error.status >= 500) {
          // Server error - exponential backoff
          delay = defaultDelay * Math.pow(2, attempt - 1);
        }
        
        await PromiseRetryUtils.sleep(delay);
      }
    }
    
    throw lastError;
  }

  /**
   * Promise race with timeout and retry
   */
  static async retryRace<T>(
    promises: (() => Promise<T>)[],
    timeoutMs: number,
    maxAttempts: number = 3,
    delayMs: number = 1000
  ): Promise<T> {
    return PromiseRetryUtils.retry(
      async () => {
        const timeoutPromise = new Promise<never>((_, reject) => {
          setTimeout(() => reject(new Error('Timeout')), timeoutMs);
        });
        
        const racePromises = promises.map(p => p());
        return Promise.race([...racePromises, timeoutPromise]);
      },
      async () => true,
      maxAttempts,
      delayMs
    );
  }

  /**
   * Retry with progress tracking
   */
  static async retryWithProgress<T>(
    promiseFactory: () => Promise<T>,
    progressCallback: (attempt: number, maxAttempts: number, delay: number, error?: any) => void,
    maxAttempts: number = 3,
    delayMs: number = 1000
  ): Promise<T> {
    let lastError: any;
    
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        progressCallback(attempt, maxAttempts, 0);
        const result = await promiseFactory();
        progressCallback(attempt, maxAttempts, 0);
        return result;
      } catch (error) {
        lastError = error;
        progressCallback(attempt, maxAttempts, delayMs, error);
        
        if (attempt < maxAttempts) {
          await PromiseRetryUtils.sleep(delayMs);
        }
      }
    }
    
    throw lastError;
  }

  /**
   * Sleep utility
   */
  private static async sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

/**
 * Retryable promise factory functions
 */
export const RetryablePromiseFactories = {
  /**
   * Create a retryable API call
   */
  apiCall: (url: string, options?: RequestInit) => new RetryablePromise(
    async () => {
      const response = await fetch(url, options);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      return response.json();
    },
    {
      maxAttempts: 5,
      baseDelay: 1000,
      maxDelay: 30000,
      retryCondition: (error) => error.message.includes('HTTP 5') || error.message.includes('Network'),
    }
  ),

  /**
   * Create a retryable database query
   */
  databaseQuery: (queryFn: () => Promise<any>) => new RetryablePromise(
    queryFn,
    {
      maxAttempts: 5,
      baseDelay: 500,
      maxDelay: 10000,
      retryCondition: (error) => error.code && ['ECONNRESET', 'ETIMEDOUT'].includes(error.code),
    }
  ),

  /**
   * Create a retryable file operation
   */
  fileOperation: (operationFn: () => Promise<any>) => new RetryablePromise(
    operationFn,
    {
      maxAttempts: 3,
      baseDelay: 1000,
      maxDelay: 5000,
      retryCondition: (error) => error.code && ['EMFILE', 'ENOSPC'].includes(error.code),
    }
  ),
} as const;

/**
 * Promise chaining utilities
 */
export class PromiseChain {
  private tasks: Array<() => Promise<any>> = [];
  private currentIndex = 0;

  add<T>(task: () => Promise<T>): PromiseChain {
    this.tasks.push(task);
    return this;
  }

  async execute(): Promise<any[]> {
    const results: any[] = [];
    
    for (const task of this.tasks) {
      try {
        const result = await new RetryablePromise(task, { maxAttempts: 3 }).thenResolving();
        results.push(result);
      } catch (error) {
        results.push(error);
      }
    }
    
    return results;
  }

  async executeSequential(): Promise<any[]> {
    const results: any[] = [];
    
    for (let i = 0; i < this.tasks.length; i++) {
      try {
        const result = await new RetryablePromise(this.tasks[i], { maxAttempts: 3 }).thenResolving();
        results.push(result);
      } catch (error) {
        results.push(error);
        // Continue with next task even if one fails
      }
    }
    
    return results;
  }
}

/**
 * Advanced promise retry patterns
 */
export const AdvancedPromisePatterns = {
  /**
   * Exponential backoff with full jitter (AWS pattern)
   */
  fullJitter: async <T>(promiseFactory: () => Promise<T>, baseDelay = 1000, maxAttempts = 3) => {
    return PromiseRetryUtils.retryWithCustomErrorHandling(
      promiseFactory,
      new Map(),
      baseDelay,
      maxAttempts
    );
  },

  /**
   * Decorrelated jitter (Google Cloud pattern)
   */
  decorrelatedJitter: async <T>(promiseFactory: () => Promise<T>, baseDelay = 1000, maxAttempts = 3) => {
    return PromiseRetryUtils.retryWithCustomErrorHandling(
      promiseFactory,
      new Map(),
      baseDelay,
      maxAttempts
    );
  },

  /**
   * Equal jitter
   */
  equalJitter: async <T>(promiseFactory: () => Promise<T>, baseDelay = 1000, maxAttempts = 3) => {
    return PromiseRetryUtils.retryWithJitter(promiseFactory, baseDelay, maxAttempts, 0.5);
  },
} as const;