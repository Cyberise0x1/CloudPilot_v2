/**
 * Retry metrics and logging utilities
 */

import { RetryMetrics } from './types.js';

export interface LogEntry {
  timestamp: number;
  level: 'INFO' | 'WARN' | 'ERROR' | 'DEBUG';
  message: string;
  data?: any;
  correlationId?: string;
}

export interface RetryMetricsCollector {
  recordRetryAttempt(attempt: number, delay: number, error?: any): void;
  recordSuccess(attempts: number, totalTime: number): void;
  recordFailure(attempts: number, totalTime: number, finalError: any): void;
  recordCircuitBreakerOpen(): void;
  getMetrics(): RetryMetrics;
  reset(): void;
}

export interface RetryLogger {
  logRetryAttempt(attempt: number, maxAttempts: number, delay: number, error: any): void;
  logRetryExhausted(attempts: number, maxAttempts: number, finalError: any): void;
  logRetrySuccess(attempts: number, totalTime: number, result: any): void;
  logCircuitBreakerOpen(reason: string): void;
  logCustom(message: string, level: LogEntry['level'], data?: any): void;
}

/**
 * Comprehensive retry metrics collector
 */
export class RetryMetricsCollectorImpl implements RetryMetricsCollector {
  private metrics: RetryMetrics;
  private retryHistory: Array<{
    timestamp: number;
    attempt: number;
    delay: number;
    error?: any;
    success: boolean;
    totalTime: number;
  }> = [];
  private performanceMetrics: {
    averageRetryDelay: number;
    medianRetryDelay: number;
    p95RetryDelay: number;
    p99RetryDelay: number;
    averageAttempts: number;
    medianAttempts: number;
    successRateByAttempt: Map<number, { attempts: number; successes: number }>;
  };

  constructor() {
    this.metrics = this.createInitialMetrics();
    this.performanceMetrics = {
      averageRetryDelay: 0,
      medianRetryDelay: 0,
      p95RetryDelay: 0,
      p99RetryDelay: 0,
      averageAttempts: 0,
      medianAttempts: 0,
      successRateByAttempt: new Map(),
    };
  }

  /**
   * Record a retry attempt
   */
  recordRetryAttempt(attempt: number, delay: number, error?: any): void {
    this.metrics.attempts++;
    
    // Record error type
    if (error) {
      const errorType = this.getErrorType(error);
      this.metrics.errorTypes.set(errorType, (this.metrics.errorTypes.get(errorType) || 0) + 1);
    }

    // Add to retry history
    this.retryHistory.push({
      timestamp: Date.now(),
      attempt,
      delay,
      error,
      success: false, // Will be updated when operation completes
      totalTime: 0, // Will be updated when operation completes
    });

    this.updateMetrics();
  }

  /**
   * Record successful operation
   */
  recordSuccess(attempts: number, totalTime: number): void {
    this.metrics.successes++;
    this.updateRetryHistory(true, attempts, totalTime);
    this.updateMetrics();
  }

  /**
   * Record failed operation
   */
  recordFailure(attempts: number, totalTime: number, finalError: any): void {
    this.metrics.failures++;
    this.updateRetryHistory(false, attempts, totalTime, finalError);
    this.updateMetrics();
  }

  /**
   * Record circuit breaker open event
   */
  recordCircuitBreakerOpen(): void {
    this.metrics.circuitBreakerOpens++;
  }

  /**
   * Get current metrics
   */
  getMetrics(): RetryMetrics {
    return { ...this.metrics };
  }

  /**
   * Get detailed performance metrics
   */
  getPerformanceMetrics() {
    const delays = this.retryHistory.map(h => h.delay).filter(d => d > 0);
    const attempts = this.retryHistory.map(h => h.attempt);
    
    return {
      ...this.performanceMetrics,
      totalOperations: this.retryHistory.length,
      successfulOperations: this.retryHistory.filter(h => h.success).length,
      failedOperations: this.retryHistory.filter(h => !h.success).length,
      retryRate: this.retryHistory.length > 0 ? (this.retryHistory.filter(h => h.attempt > 1).length / this.retryHistory.length) * 100 : 0,
      averageDelay: this.calculateAverage(delays),
      medianDelay: this.calculateMedian(delays),
      p95Delay: this.calculatePercentile(delays, 95),
      p99Delay: this.calculatePercentile(delays, 99),
      minDelay: delays.length > 0 ? Math.min(...delays) : 0,
      maxDelay: delays.length > 0 ? Math.max(...delays) : 0,
      averageAttempts: this.calculateAverage(attempts),
      medianAttempts: this.calculateMedian(attempts),
    };
  }

  /**
   * Get retry history
   */
  getRetryHistory() {
    return [...this.retryHistory];
  }

  /**
   * Get success rate by error type
   */
  getSuccessRateByErrorType() {
    const errorTypeStats = new Map<string, { total: number; successes: number; failures: number }>();
    
    for (const history of this.retryHistory) {
      if (history.error) {
        const errorType = this.getErrorType(history.error);
        const stats = errorTypeStats.get(errorType) || { total: 0, successes: 0, failures: 0 };
        stats.total++;
        if (history.success) {
          stats.successes++;
        } else {
          stats.failures++;
        }
        errorTypeStats.set(errorType, stats);
      }
    }
    
    return errorTypeStats;
  }

  /**
   * Get time-series metrics
   */
  getTimeSeriesMetrics(timeWindowMs: number = 3600000): Array<{
    timestamp: number;
    attempts: number;
    successes: number;
    failures: number;
    averageDelay: number;
  }> {
    const cutoff = Date.now() - timeWindowMs;
    const windowedHistory = this.retryHistory.filter(h => h.timestamp > cutoff);
    
    // Group by minute
    const timeGroups = new Map<number, typeof windowedHistory>();
    
    for (const history of windowedHistory) {
      const minute = Math.floor(history.timestamp / 60000) * 60000;
      const group = timeGroups.get(minute) || [];
      group.push(history);
      timeGroups.set(minute, group);
    }
    
    const timeSeries = Array.from(timeGroups.entries()).map(([timestamp, group]) => {
      const successes = group.filter(h => h.success).length;
      const failures = group.filter(h => !h.success).length;
      const delays = group.map(h => h.delay).filter(d => d > 0);
      
      return {
        timestamp,
        attempts: group.length,
        successes,
        failures,
        averageDelay: this.calculateAverage(delays),
      };
    }).sort((a, b) => a.timestamp - b.timestamp);
    
    return timeSeries;
  }

  /**
   * Reset all metrics
   */
  reset(): void {
    this.metrics = this.createInitialMetrics();
    this.retryHistory = [];
    this.performanceMetrics = {
      averageRetryDelay: 0,
      medianRetryDelay: 0,
      p95RetryDelay: 0,
      p99RetryDelay: 0,
      averageAttempts: 0,
      medianAttempts: 0,
      successRateByAttempt: new Map(),
    };
  }

  /**
   * Export metrics to JSON
   */
  exportToJSON(): string {
    return JSON.stringify({
      metrics: this.getMetrics(),
      performance: this.getPerformanceMetrics(),
      history: this.getRetryHistory(),
      errorTypeStats: this.getSuccessRateByErrorType(),
      timeSeries: this.getTimeSeriesMetrics(),
    }, null, 2);
  }

  /**
   * Private helper methods
   */
  private createInitialMetrics(): RetryMetrics {
    return {
      attempts: 0,
      successes: 0,
      failures: 0,
      circuitBreakerOpens: 0,
      averageDelay: 0,
      totalRetryTime: 0,
      successRate: 0,
      errorTypes: new Map(),
      lastRetryTime: 0,
    };
  }

  private updateRetryHistory(
    success: boolean, 
    attempts: number, 
    totalTime: number, 
    error?: any
  ): void {
    // Update the most recent incomplete entry in history
    for (let i = this.retryHistory.length - 1; i >= 0; i--) {
      const history = this.retryHistory[i];
      if (history.success === false && history.totalTime === 0) {
        history.success = success;
        history.totalTime = totalTime;
        break;
      }
    }
  }

  private updateMetrics(): void {
    const delays = this.retryHistory.map(h => h.delay).filter(d => d > 0);
    const attempts = this.retryHistory.map(h => h.attempt);
    
    this.metrics.averageDelay = this.calculateAverage(delays);
    this.metrics.lastRetryTime = this.retryHistory.length > 0 
      ? this.retryHistory[this.retryHistory.length - 1].timestamp 
      : 0;
    
    // Update performance metrics
    this.performanceMetrics.averageRetryDelay = this.metrics.averageDelay;
    this.performanceMetrics.medianRetryDelay = this.calculateMedian(delays);
    this.performanceMetrics.p95RetryDelay = this.calculatePercentile(delays, 95);
    this.performanceMetrics.p99RetryDelay = this.calculatePercentile(delays, 99);
    this.performanceMetrics.averageAttempts = this.calculateAverage(attempts);
    this.performanceMetrics.medianAttempts = this.calculateMedian(attempts);
    
    // Update success rate by attempt
    for (const attempt of attempts) {
      const stats = this.performanceMetrics.successRateByAttempt.get(attempt) || { attempts: 0, successes: 0 };
      stats.attempts++;
      if (this.retryHistory.some(h => h.attempt === attempt && h.success)) {
        stats.successes++;
      }
      this.performanceMetrics.successRateByAttempt.set(attempt, stats);
    }
  }

  private getErrorType(error: any): string {
    if (!error) return 'Unknown';
    
    if (error.status || error.statusCode) {
      return `HTTP_${error.status || error.statusCode}`;
    }
    
    if (error.code) {
      return `NETWORK_${error.code}`;
    }
    
    return error.name || error.constructor?.name || 'Unknown';
  }

  private calculateAverage(numbers: number[]): number {
    if (numbers.length === 0) return 0;
    return numbers.reduce((sum, num) => sum + num, 0) / numbers.length;
  }

  private calculateMedian(numbers: number[]): number {
    if (numbers.length === 0) return 0;
    
    const sorted = [...numbers].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    
    return sorted.length % 2 === 0 
      ? (sorted[mid - 1] + sorted[mid]) / 2
      : sorted[mid];
  }

  private calculatePercentile(numbers: number[], percentile: number): number {
    if (numbers.length === 0) return 0;
    
    const sorted = [...numbers].sort((a, b) => a - b);
    const index = Math.ceil((percentile / 100) * sorted.length) - 1;
    return sorted[Math.max(0, index)];
  }
}

/**
 * Comprehensive retry logger
 */
export class RetryLoggerImpl implements RetryLogger {
  private logs: LogEntry[] = [];
  private maxLogEntries: number;

  constructor(maxLogEntries: number = 1000) {
    this.maxLogEntries = maxLogEntries;
  }

  /**
   * Log retry attempt
   */
  logRetryAttempt(attempt: number, maxAttempts: number, delay: number, error: any): void {
    this.log('INFO', `Retry attempt ${attempt}/${maxAttempts}`, {
      attempt,
      maxAttempts,
      delay,
      error: this.sanitizeError(error),
    });
  }

  /**
   * Log retry exhausted
   */
  logRetryExhausted(attempts: number, maxAttempts: number, finalError: any): void {
    this.log('ERROR', `All retry attempts exhausted`, {
      attempts,
      maxAttempts,
      finalError: this.sanitizeError(finalError),
    });
  }

  /**
   * Log retry success
   */
  logRetrySuccess(attempts: number, totalTime: number, result: any): void {
    this.log('INFO', `Retry succeeded after ${attempts} attempts`, {
      attempts,
      totalTime,
      result: this.sanitizeResult(result),
    });
  }

  /**
   * Log circuit breaker open
   */
  logCircuitBreakerOpen(reason: string): void {
    this.log('WARN', `Circuit breaker opened: ${reason}`, {
      reason,
      timestamp: Date.now(),
    });
  }

  /**
   * Log custom message
   */
  logCustom(message: string, level: LogEntry['level'], data?: any): void {
    this.log(level, message, data);
  }

  /**
   * Get all logs
   */
  getLogs(): LogEntry[] {
    return [...this.logs];
  }

  /**
   * Get logs by level
   */
  getLogsByLevel(level: LogEntry['level']): LogEntry[] {
    return this.logs.filter(log => log.level === level);
  }

  /**
   * Get logs within time range
   */
  getLogsByTimeRange(startTime: number, endTime: number): LogEntry[] {
    return this.logs.filter(log => log.timestamp >= startTime && log.timestamp <= endTime);
  }

  /**
   * Search logs by message content
   */
  searchLogs(query: string): LogEntry[] {
    const lowercaseQuery = query.toLowerCase();
    return this.logs.filter(log => 
      log.message.toLowerCase().includes(lowercaseQuery) ||
      JSON.stringify(log.data || {}).toLowerCase().includes(lowercaseQuery)
    );
  }

  /**
   * Clear all logs
   */
  clearLogs(): void {
    this.logs = [];
  }

  /**
   * Export logs to JSON
   */
  exportToJSON(): string {
    return JSON.stringify(this.logs, null, 2);
  }

  /**
   * Set correlation ID for log entries
   */
  setCorrelationId(correlationId: string): void {
    // This would be used in a more sophisticated implementation
    // For now, it's a placeholder for correlation tracking
  }

  /**
   * Private helper methods
   */
  private log(level: LogEntry['level'], message: string, data?: any): void {
    const logEntry: LogEntry = {
      timestamp: Date.now(),
      level,
      message,
      data,
    };

    this.logs.push(logEntry);

    // Maintain log size limit
    if (this.logs.length > this.maxLogEntries) {
      this.logs = this.logs.slice(-this.maxLogEntries);
    }

    // Also log to console for debugging
    if (level === 'ERROR') {
      console.error(`[Retry] ${message}`, data);
    } else if (level === 'WARN') {
      console.warn(`[Retry] ${message}`, data);
    } else {
      console.log(`[Retry] ${message}`, data);
    }
  }

  private sanitizeError(error: any): any {
    if (!error) return null;
    
    return {
      message: error.message || error.toString(),
      code: error.code,
      status: error.status || error.statusCode,
      name: error.name,
    };
  }

  private sanitizeResult(result: any): any {
    if (!result) return null;
    
    if (typeof result === 'object') {
      // Only include basic properties to avoid logging sensitive data
      return {
        type: result.constructor?.name,
        keys: Object.keys(result).slice(0, 10), // Limit to first 10 keys
      };
    }
    
    return result;
  }
}

/**
 * Combined metrics and logging system
 */
export class RetryMonitoringSystem {
  private metricsCollector: RetryMetricsCollectorImpl;
  private logger: RetryLoggerImpl;
  private correlationId?: string;

  constructor(metricsCollector?: RetryMetricsCollectorImpl, logger?: RetryLoggerImpl) {
    this.metricsCollector = metricsCollector || new RetryMetricsCollectorImpl();
    this.logger = logger || new RetryLoggerImpl();
  }

  /**
   * Get metrics collector
   */
  getMetricsCollector(): RetryMetricsCollector {
    return this.metricsCollector;
  }

  /**
   * Get logger
   */
  getLogger(): RetryLogger {
    return this.logger;
  }

  /**
   * Set correlation ID
   */
  setCorrelationId(correlationId: string): void {
    this.correlationId = correlationId;
    this.logger.setCorrelationId(correlationId);
  }

  /**
   * Get comprehensive monitoring report
   */
  getMonitoringReport() {
    return {
      timestamp: Date.now(),
      correlationId: this.correlationId,
      metrics: this.metricsCollector.getMetrics(),
      performance: this.metricsCollector.getPerformanceMetrics(),
      logs: this.logger.getLogs(),
      errorTypeStats: this.metricsCollector.getSuccessRateByErrorType(),
      timeSeries: this.metricsCollector.getTimeSeriesMetrics(),
    };
  }

  /**
   * Reset all monitoring data
   */
  reset(): void {
    this.metricsCollector.reset();
    this.logger.clearLogs();
  }

  /**
   * Export full monitoring data
   */
  exportToJSON(): string {
    return JSON.stringify(this.getMonitoringReport(), null, 2);
  }
}

/**
 * Factory for creating monitoring systems
 */
export const MonitoringSystems = {
  /**
   * Basic monitoring (console logging only)
   */
  basic: () => new RetryMonitoringSystem(
    new RetryMetricsCollectorImpl(),
    new RetryLoggerImpl(100)
  ),

  /**
   * Detailed monitoring (full logging and metrics)
   */
  detailed: () => new RetryMonitoringSystem(
    new RetryMetricsCollectorImpl(),
    new RetryLoggerImpl(5000)
  ),

  /**
   * Production monitoring (minimal logging, full metrics)
   */
  production: () => new RetryMonitoringSystem(
    new RetryMetricsCollectorImpl(),
    new RetryLoggerImpl(100)
  ),
} as const;