/**
 * Async/await retry utilities and patterns
 */

import { RetryOptions, RetryResult, RetryFunction } from './types.js';
import { RetryLogic } from './retry.js';
import { ExponentialBackoff, BackoffStrategies } from './exponential-backoff.js';

/**
 * Promise-based retry patterns with advanced async utilities
 */
export class AsyncRetryUtils {
  /**
   * Retry a promise-returning function with exponential backoff
   */
  static async retry<T>(
    fn: RetryFunction<T>,
    options?: Partial<RetryOptions>
  ): Promise<T> {
    const retryLogic = new RetryLogic(options);
    const result = await retryLogic.execute(fn);
    
    if (!result.success) {
      throw result.error;
    }
    
    return result.result!;
  }

  /**
   * Retry with timeout
   */
  static async retryWithTimeout<T>(
    fn: RetryFunction<T>,
    timeoutMs: number,
    options?: Partial<RetryOptions>
  ): Promise<T> {
    const retryOptions = {
      totalTimeout: timeoutMs,
      abortOnTimeout: true,
      ...options,
    };

    return AsyncRetryUtils.retry(fn, retryOptions);
  }

  /**
   * Retry with exponential backoff strategy
   */
  static async retryWithBackoff<T>(
    fn: RetryFunction<T>,
    strategy: 'quick' | 'standard' | 'aggressive' | 'conservative' | 'database' | 'api',
    options?: Partial<RetryOptions>
  ): Promise<T> {
    const backoff = BackoffStrategies[strategy]();
    const retryOptions = {
      baseDelay: backoff.getConfig().initialDelay,
      maxDelay: backoff.getConfig().maxDelay,
      backoffMultiplier: backoff.getConfig().multiplier,
      jitter: backoff.getConfig().jitter,
      jitterFactor: backoff.getConfig().jitterFactor,
      ...options,
    };

    return AsyncRetryUtils.retry(fn, retryOptions);
  }

  /**
   * Retry with custom delay calculation
   */
  static async retryWithCustomDelay<T>(
    fn: RetryFunction<T>,
    delayCalculator: (attempt: number) => number,
    options?: Partial<RetryOptions>
  ): Promise<T> {
    const retryLogic = new RetryLogic(options);
    const startTime = Date.now();
    
    // Override the backoff calculation
    const originalExecute = retryLogic.execute.bind(retryLogic);
    retryLogic.execute = async (fn: RetryFunction<T>) => {
      const attempts = 0;
      let lastError: any;
      
      for (let attempt = 1; attempt <= retryLogic['options'].maxAttempts; attempt++) {
        try {
          const result = await fn();
          
          if (!result.success) {
            return result;
          }
          
          return result;
        } catch (error) {
          lastError = error;
          attempts = attempt;
          
          // Use custom delay
          const delay = delayCalculator(attempt);
          
          if (attempt < retryLogic['options'].maxAttempts) {
            await AsyncRetryUtils.sleep(delay);
          }
        }
      }
      
      throw lastError;
    };

    return retryLogic.execute(fn).then(result => {
      if (!result.success) {
        throw result.error;
      }
      return result.result!;
    });
  }

  /**
   * Retry with exponential backoff and jitter
   */
  static async retryWithJitter<T>(
    fn: RetryFunction<T>,
    baseDelay = 1000,
    maxDelay = 30000,
    jitterFactor = 0.2,
    options?: Partial<RetryOptions>
  ): Promise<T> {
    const backoff = new ExponentialBackoff({
      initialDelay: baseDelay,
      maxDelay,
      jitter: true,
      jitterFactor,
    });

    return AsyncRetryUtils.retryWithCustomDelay(
      fn,
      (attempt) => backoff.calculateDelay(attempt),
      options
    );
  }

  /**
   * Retry with circuit breaker integration
   */
  static async retryWithCircuitBreaker<T>(
    fn: RetryFunction<T>,
    circuitBreaker: any,
    options?: Partial<RetryOptions>
  ): Promise<T> {
    const retryLogic = new RetryLogic(options, circuitBreaker);
    const result = await retryLogic.execute(fn);
    
    if (!result.success) {
      throw result.error;
    }
    
    return result.result!;
  }

  /**
   * Batch retry with multiple operations
   */
  static async retryBatch<T>(
    operations: (() => Promise<T>)[],
    options?: Partial<RetryOptions>
  ): Promise<(T | Error)[]> {
    const results: (T | Error)[] = [];
    
    await Promise.allSettled(
      operations.map(async (operation, index) => {
        try {
          const result = await AsyncRetryUtils.retry(operation, options);
          results[index] = result;
        } catch (error) {
          results[index] = error;
        }
      })
    );
    
    return results;
  }

  /**
   * Retry until condition is met
   */
  static async retryUntil<T>(
    fn: RetryFunction<T>,
    condition: (result: T, attempt: number) => boolean,
    maxAttempts = 10,
    options?: Partial<RetryOptions>
  ): Promise<T> {
    let lastResult: T;
    let attempt = 0;
    
    while (attempt < maxAttempts) {
      try {
        lastResult = await AsyncRetryUtils.retry(fn, {
          ...options,
          maxAttempts: 1, // Only try once per iteration
        });
        
        if (condition(lastResult, attempt)) {
          return lastResult;
        }
        
        attempt++;
        
        // Apply delay before next attempt
        const delay = options?.baseDelay || 1000;
        await AsyncRetryUtils.sleep(delay);
        
      } catch (error) {
        attempt++;
        
        if (attempt >= maxAttempts) {
          throw error;
        }
      }
    }
    
    throw new Error(`Condition not met after ${maxAttempts} attempts`);
  }

  /**
   * Retry with exponential backoff until condition is met
   */
  static async retryBackoffUntil<T>(
    fn: RetryFunction<T>,
    condition: (result: T, attempt: number) => boolean,
    maxAttempts = 10,
    strategy: 'quick' | 'standard' | 'aggressive' | 'conservative' = 'standard',
    options?: Partial<RetryOptions>
  ): Promise<T> {
    const backoff = BackoffStrategies[strategy]();
    let lastResult: T;
    let attempt = 0;
    
    while (attempt < maxAttempts) {
      try {
        lastResult = await AsyncRetryUtils.retry(fn, {
          ...options,
          maxAttempts: 1,
        });
        
        if (condition(lastResult, attempt)) {
          return lastResult;
        }
        
      } catch (error) {
        // Continue if it's the last attempt
        if (attempt >= maxAttempts - 1) {
          throw error;
        }
      }
      
      attempt++;
      
      // Apply exponential backoff
      const delay = backoff.calculateDelay(attempt);
      await AsyncRetryUtils.sleep(delay);
    }
    
    throw new Error(`Condition not met after ${maxAttempts} attempts`);
  }

  /**
   * Retry with timeout and cancellation
   */
  static async retryWithCancellation<T>(
    fn: RetryFunction<T>,
    timeoutMs: number,
    options?: Partial<RetryOptions>
  ): Promise<T> {
    const controller = new AbortController();
    
    const timeoutPromise = new Promise<never>((_, reject) => {
      setTimeout(() => {
        controller.abort();
        reject(new Error(`Operation timed out after ${timeoutMs}ms`));
      }, timeoutMs);
    });

    const retryPromise = AsyncRetryUtils.retry(
      () => fn(),
      {
        ...options,
        abortOnTimeout: true,
      }
    );

    return Promise.race([retryPromise, timeoutPromise]);
  }

  /**
   * Retry with progress callback
   */
  static async retryWithProgress<T>(
    fn: RetryFunction<T>,
    progress: (attempt: number, maxAttempts: number, delay: number, error?: any) => void,
    options?: Partial<RetryOptions>
  ): Promise<T> {
    const retryOptions = {
      ...options,
      onRetry: (error: any, attempt: number, delay: number) => {
        progress(attempt, options?.maxAttempts || 3, delay, error);
        if (options?.onRetry) {
          options.onRetry(error, attempt, delay);
        }
      },
    };

    return AsyncRetryUtils.retry(fn, retryOptions);
  }

  /**
   * Retry with logging
   */
  static async retryWithLogging<T>(
    fn: RetryFunction<T>,
    logger: (message: string, data?: any) => void = console.log,
    options?: Partial<RetryOptions>
  ): Promise<T> {
    const retryOptions = {
      ...options,
      onRetry: (error: any, attempt: number, delay: number) => {
        logger(`Retry attempt ${attempt}/${options?.maxAttempts || 3} after ${delay}ms delay`, {
          attempt,
          delay,
          error: error.message || error.toString(),
        });
        if (options?.onRetry) {
          options.onRetry(error, attempt, delay);
        }
      },
      onExhausted: (error: any, attempt: number, totalAttempts: number) => {
        logger(`All ${totalAttempts} retry attempts exhausted`, {
          finalAttempt: attempt,
          error: error.message || error.toString(),
        });
        if (options?.onExhausted) {
          options.onExhausted(error, attempt, totalAttempts);
        }
      },
      onSuccess: (result: any, attempt: number, totalAttempts: number) => {
        logger(`Retry succeeded on attempt ${attempt}/${totalAttempts}`);
        if (options?.onSuccess) {
          options.onSuccess(result, attempt, totalAttempts);
        }
      },
    };

    return AsyncRetryUtils.retry(fn, retryOptions);
  }

  /**
   * Concurrent retry with rate limiting
   */
  static async retryWithRateLimit<T>(
    fn: RetryFunction<T>,
    maxConcurrent = 5,
    rateLimitPerSecond = 10,
    options?: Partial<RetryOptions>
  ): Promise<T> {
    const semaphores: Promise<any>[] = [];
    
    // Rate limiting implementation
    let callsThisSecond = 0;
    let lastResetTime = Date.now();

    const rateLimitedFn = async () => {
      const now = Date.now();
      
      // Reset counter every second
      if (now - lastResetTime >= 1000) {
        callsThisSecond = 0;
        lastResetTime = now;
      }
      
      // Wait if rate limit exceeded
      while (callsThisSecond >= rateLimitPerSecond) {
        await AsyncRetryUtils.sleep(100);
      }
      
      callsThisSecond++;
      return fn();
    };

    // Ensure we don't exceed concurrent limit
    while (semaphores.length >= maxConcurrent) {
      await Promise.race(semaphores);
      semaphores.splice(0, 1);
    }

    const promise = AsyncRetryUtils.retry(rateLimitedFn, options);
    semaphores.push(promise);

    return promise;
  }

  /**
   * Sleep utility
   */
  private static async sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

/**
 * Async iterator for retry attempts
 */
export class RetryIterator<T> implements AsyncIterable<RetryResult<T>> {
  private fn: RetryFunction<T>;
  private options: Partial<RetryOptions>;
  private attempt = 0;
  private maxAttempts: number;

  constructor(fn: RetryFunction<T>, options: Partial<RetryOptions> = {}) {
    this.fn = fn;
    this.options = options;
    this.maxAttempts = options.maxAttempts || 3;
  }

  [Symbol.asyncIterator](): AsyncIterator<RetryResult<T>> {
    return this;
  }

  async next(): Promise<IteratorResult<RetryResult<T>>> {
    if (this.attempt >= this.maxAttempts) {
      return { done: true, value: undefined };
    }

    this.attempt++;
    const retryLogic = new RetryLogic(this.options);
    const result = await retryLogic.execute(this.fn);

    return {
      done: !result.success || this.attempt >= this.maxAttempts,
      value: result,
    };
  }
}

/**
 * Retry utilities for specific use cases
 */
export const AsyncRetryPatterns = {
  /**
   * Web scraping retry pattern
   */
  webScraping: (fn: RetryFunction<any>) => AsyncRetryUtils.retry(fn, {
    maxAttempts: 5,
    baseDelay: 2000,
    maxDelay: 30000,
    jitter: true,
    retryCondition: (error) => error.status >= 500 || error.status === 429,
  }),

  /**
   * Database operation retry pattern
   */
  database: (fn: RetryFunction<any>) => AsyncRetryUtils.retry(fn, {
    maxAttempts: 5,
    baseDelay: 500,
    maxDelay: 10000,
    jitter: true,
    retryCondition: (error) => error.code && ['ECONNRESET', 'ETIMEDOUT'].includes(error.code),
  }),

  /**
   * API call retry pattern
   */
  apiCall: (fn: RetryFunction<any>) => AsyncRetryUtils.retryWithBackoff(fn, 'api'),

  /**
   * File operation retry pattern
   */
  fileOperation: (fn: RetryFunction<any>) => AsyncRetryUtils.retry(fn, {
    maxAttempts: 3,
    baseDelay: 1000,
    maxDelay: 5000,
    jitter: true,
    retryCondition: (error) => error.code && ['EMFILE', 'ENOSPC'].includes(error.code),
  }),
} as const;

/**
 * Promise-based retry for chaining
 */
export function retryable<T extends (...args: any[]) => Promise<any>>(
  fn: T,
  options?: Partial<RetryOptions>
): T {
  return ((...args: Parameters<T>) => AsyncRetryUtils.retry(() => fn(...args), options)) as T;
}

/**
 * Create a retryable version of a function
 */
export function makeRetryable<T extends (...args: any[]) => Promise<any>>(
  fn: T,
  policy: 'quick' | 'standard' | 'aggressive' | 'conservative' | 'database' | 'api' = 'standard'
): T {
  return retryable(fn, RetryPolicies[policy].options) as T;
}