# Retry Logic System

A comprehensive retry logic implementation with exponential backoff, circuit breaker integration, metrics, and logging.

## Features

- ✅ **Retry Decorators**: Apply retry logic to functions and class methods
- ✅ **Exponential Backoff**: Configurable backoff strategies with jitter
- ✅ **Circuit Breaker**: Prevent cascading failures with circuit breaker pattern
- ✅ **Configurable Policies**: Pre-built policies for common use cases
- ✅ **Async/Await Support**: Full async/await utilities and patterns
- ✅ **Promise-Based**: Advanced promise-based retry patterns
- ✅ **Metrics & Logging**: Comprehensive monitoring and analytics
- ✅ **Timeout Handling**: Configurable timeouts and abort conditions
- ✅ **Custom Conditions**: Flexible retry conditions and error handling

## Installation

```typescript
// Import everything
import RetryLogicSystem from './retry-logic';

// Or import specific utilities
import { 
  retry, 
  AsyncRetryUtils, 
  RetryLogic, 
  CircuitBreaker 
} from './retry-logic';
```

## Quick Start

### Basic Usage

```typescript
import { AsyncRetryUtils } from './retry-logic';

async function example() {
  // Simple retry
  const result = await AsyncRetryUtils.retry(
    async () => {
      const response = await fetch('https://api.example.com/data');
      if (!response.ok) throw new Error('API Error');
      return response.json();
    },
    { maxAttempts: 3 }
  );

  console.log('Result:', result);
}
```

### Using Decorators

```typescript
import { retry, RetryLogic } from './retry-logic';

class MyService {
  @retry({ maxAttempts: 5, baseDelay: 1000 })
  async fetchData() {
    const response = await fetch('https://api.example.com/data');
    if (!response.ok) throw new Error('API Error');
    return response.json();
  }
}

const service = new MyService();
const data = await service.fetchData();
```

### With Circuit Breaker

```typescript
import { CircuitBreaker, retry } from './retry-logic';

const circuitBreaker = new CircuitBreaker({
  failureThreshold: 50,  // 50% failure rate
  monitoringWindow: 60000, // 1 minute window
});

const result = await retry(
  { maxAttempts: 5 },
  circuitBreaker
)(async () => {
  // Your operation here
  return 'success';
})();

console.log('Result with circuit breaker:', result);
```

## Configuration Options

### Retry Options

```typescript
interface RetryOptions {
  maxAttempts: number;           // Maximum retry attempts (default: 3)
  baseDelay: number;             // Base delay in ms (default: 1000)
  maxDelay: number;              // Maximum delay in ms (default: 30000)
  jitter: boolean;               // Enable jitter (default: true)
  jitterFactor: number;          // Jitter factor 0-1 (default: 0.2)
  backoffMultiplier: number;     // Exponential multiplier (default: 2)
  retryCondition: Function;      // Custom retry condition
  onRetry?: Function;            // Callback before each retry
  onExhausted?: Function;        // Callback when retries exhausted
  onSuccess?: Function;          // Callback on success
  totalTimeout: number;          // Total timeout in ms
  abortOnTimeout: boolean;       // Abort on timeout (default: true)
}
```

### Circuit Breaker Options

```typescript
interface CircuitBreakerOptions {
  failureThreshold: number;      // Failure % to open circuit (default: 50)
  minimumRequests: number;       // Min requests before circuit can open (default: 5)
  monitoringWindow: number;      // Monitoring window in ms (default: 60000)
  halfOpenCooldown: number;      // Cooldown before half-open in ms (default: 5000)
  autoResetAttempts: number;     // Successful attempts to reset (default: 3)
  failureCondition: Function;    // Custom failure condition
}
```

## Built-in Policies

```typescript
import { RetryPolicies } from './retry-logic';

// Quick retry - for transient failures
const quickPolicy = RetryPolicies.quick;

// Standard retry - balanced approach
const standardPolicy = RetryPolicies.standard;

// Aggressive retry - for critical operations
const aggressivePolicy = RetryPolicies.aggressive;

// Conservative retry - minimal retries
const conservativePolicy = RetryPolicies.conservative;

// Database optimized
const databasePolicy = RetryPolicies.database;

// API optimized
const apiPolicy = RetryPolicies.api;
```

## Advanced Patterns

### Exponential Backoff with Jitter

```typescript
import { AsyncRetryUtils, BackoffStrategies } from './retry-logic';

// Using predefined strategy
const result1 = await AsyncRetryUtils.retryWithBackoff(
  async () => { /* operation */ },
  'database'
);

// Using custom backoff
const result2 = await AsyncRetryUtils.retryWithJitter(
  async () => { /* operation */ },
  1000,    // base delay
  30000,   // max delay
  0.2      // jitter factor
);
```

### Retry Until Condition

```typescript
import { AsyncRetryUtils } from './retry-logic';

const result = await AsyncRetryUtils.retryUntil(
  async () => {
    const data = await fetchData();
    return data;
  },
  (result) => result.status === 'ready',
  10 // max attempts
);
```

### Retry with Progress Tracking

```typescript
import { AsyncRetryUtils } from './retry-logic';

const result = await AsyncRetryUtils.retryWithProgress(
  async () => { /* operation */ },
  (attempt, maxAttempts, delay, error) => {
    console.log(`Attempt ${attempt}/${maxAttempts} failed. Retrying in ${delay}ms`);
    if (error) {
      console.log('Error:', error.message);
    }
  },
  { maxAttempts: 5 }
);
```

## Promise-Based Retry

### RetryablePromise

```typescript
import { RetryablePromise } from './retry-logic';

const retryable = new RetryablePromise(
  async () => {
    const response = await fetch('https://api.example.com/data');
    if (!response.ok) throw new Error('API Error');
    return response.json();
  },
  { maxAttempts: 3 }
);

const result = await retryable.thenResolving();
```

### Promise Retry Utils

```typescript
import { PromiseRetryUtils } from './retry-logic';

// Retry with custom error handling
const result = await PromiseRetryUtils.retryWithCustomErrorHandling(
  async () => { /* operation */ },
  new Map([
    [429, async (error, attempt) => {
      // Handle rate limiting
      return attempt < 3;
    }],
    [500, async (error, attempt) => {
      // Handle server errors
      return attempt < 5;
    }],
  ])
);
```

## Monitoring and Metrics

### Basic Monitoring

```typescript
import { AsyncRetryUtils, MonitoringSystems } from './retry-logic';

const monitoring = MonitoringSystems.detailed();

try {
  const result = await AsyncRetryUtils.retry(
    async () => { /* operation */ },
    {
      maxAttempts: 5,
      onRetry: (error, attempt, delay) => {
        monitoring.getLogger().logRetryAttempt(attempt, 5, delay, error);
      },
    }
  );

  // Get comprehensive report
  const report = monitoring.getMonitoringReport();
  console.log('Success Rate:', report.metrics.successRate);
  console.log('Average Delay:', report.performance.averageDelay);
} catch (error) {
  monitoring.getLogger().logCustom(
    'Operation failed',
    'ERROR',
    { error }
  );
}
```

### Performance Metrics

```typescript
import { RetryMonitoringSystem } from './retry-logic';

const monitoring = new RetryMonitoringSystem();

// Get detailed metrics
const metrics = monitoring.getMetricsCollector().getMetrics();
const performance = monitoring.getMetricsCollector().getPerformanceMetrics();
const timeSeries = monitoring.getMetricsCollector().getTimeSeriesMetrics();

// Get all logs
const logs = monitoring.getLogger().getLogs();

// Export comprehensive report
const report = monitoring.exportToJSON();
```

## Circuit Breaker Patterns

### Basic Circuit Breaker

```typescript
import { CircuitBreaker } from './retry-logic';

const circuitBreaker = new CircuitBreaker({
  failureThreshold: 50,
  monitoringWindow: 60000,
});

try {
  const result = await circuitBreaker.execute(
    async () => { /* operation */ },
    (error) => {
      // Fallback function
      return 'fallback result';
    }
  );
} catch (error) {
  console.log('Circuit breaker is OPEN:', error.message);
}
```

### Circuit Breaker Group

```typescript
import { CircuitBreakerGroup } from './retry-logic';

const group = new CircuitBreakerGroup();

group.register('api-call', async (url: string) => {
  const response = await fetch(url);
  if (!response.ok) throw new Error('API Error');
  return response.json();
});

group.register('db-query', async (query: string) => {
  // Database operation
  return await database.query(query);
});

// Execute operations with shared circuit breaker
const result1 = await group.execute('api-call', 'https://api.example.com');
const result2 = await group.execute('db-query', 'SELECT * FROM users');
```

## Backoff Strategies

```typescript
import { ExponentialBackoff, BackoffStrategies } from './retry-logic';

// Using predefined strategies
const fastBackoff = BackoffStrategies.fast();
const balancedBackoff = BackoffStrategies.balanced();
const slowBackoff = BackoffStrategies.slow();

// Custom backoff
const customBackoff = new ExponentialBackoff({
  initialDelay: 500,
  maxDelay: 10000,
  multiplier: 2,
  jitter: true,
  jitterFactor: 0.1,
});

// Generate delay sequence
const delays = customBackoff.generateSequence(5);
// [500, 1000, 2000, 4000, 8000]

// Calculate total time
const totalTime = customBackoff.calculateTotalTime(5);
// 15500
```

## Error Handling

### Custom Retry Conditions

```typescript
import { retry } from './retry-logic';

// Custom retry condition for HTTP errors
const customRetry = retry({
  maxAttempts: 3,
  retryCondition: (error, attempt) => {
    // Retry only on specific HTTP status codes
    if (error.status) {
      return [408, 429, 500, 502, 503, 504].includes(error.status);
    }
    
    // Retry on network errors
    if (error.code) {
      return ['ECONNRESET', 'ETIMEDOUT', 'ECONNREFUSED'].includes(error.code);
    }
    
    return false;
  },
});

// Database deadlock handling
const dbRetry = retry({
  maxAttempts: 3,
  retryCondition: (error, attempt) => {
    // Don't retry on deadlocks
    if (error.code === '40P01' || error.errno === 1213) {
      return false;
    }
    
    // Retry on connection errors
    return error.code && ['ECONNRESET', 'ETIMEDOUT'].includes(error.code);
  },
});
```

### Error Classification

```typescript
import { isRetryableError, isRetryableApiError, isDeadlockError } from './retry-logic';

if (isRetryableError(error)) {
  console.log('Error is retryable');
}

if (isRetryableApiError(error)) {
  console.log('API error is retryable');
}

if (isDeadlockError(error)) {
  console.log('Database deadlock - should not retry');
}
```

## Use Case Examples

### Web Scraping

```typescript
import { AsyncRetryPatterns } from './retry-logic';

const scrapeWithRetry = AsyncRetryPatterns.webScraping(async () => {
  const response = await fetch('https://example.com');
  const html = await response.text();
  
  // Parse HTML and extract data
  return extractData(html);
});

const data = await scrapeWithRetry();
```

### Database Operations

```typescript
import { AsyncRetryPatterns } from './retry-logic';

const dbOperation = AsyncRetryPatterns.database(async () => {
  const result = await database.query('INSERT INTO users (name, email) VALUES (?, ?)', [
    'John Doe',
    'john@example.com'
  ]);
  return result;
});

const result = await dbOperation();
```

### API Calls

```typescript
import { AsyncRetryPatterns } from './retry-logic';

const apiCall = AsyncRetryPatterns.apiCall(async () => {
  const response = await fetch('https://api.example.com/data', {
    headers: {
      'Authorization': 'Bearer ' + token,
      'Content-Type': 'application/json',
    },
  });
  
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
  }
  
  return response.json();
});

const data = await apiCall();
```

## Performance Monitoring

```typescript
import { AsyncRetryUtils, MonitoringSystems } from './retry-logic';

const monitoring = MonitoringSystems.detailed();

// Run multiple operations and collect metrics
const operations = Array.from({ length: 100 }, (_, i) => 
  AsyncRetryUtils.retry(
    async () => {
      if (Math.random() < 0.3) {
        throw new Error('Random failure');
      }
      return `Operation ${i} completed`;
    },
    {
      maxAttempts: 3,
      onRetry: (error, attempt, delay) => {
        monitoring.getMetricsCollector().recordRetryAttempt(attempt, delay, error);
      },
    }
  )
);

const results = await Promise.allSettled(operations);

// Analyze performance
const report = monitoring.getMonitoringReport();
console.log('Performance Analysis:');
console.log(`- Total Operations: ${report.performance.totalOperations}`);
console.log(`- Success Rate: ${report.metrics.successRate}%`);
console.log(`- Average Retry Delay: ${report.performance.averageDelay}ms`);
console.log(`- Retry Rate: ${report.performance.retryRate}%`);
```

## Configuration Examples

### Production Configuration

```typescript
import { RetryPolicies } from './retry-logic';

const productionConfig = {
  ...RetryPolicies.standard.options,
  totalTimeout: 60000,
  retryCondition: (error) => {
    // More conservative for production
    return error.status >= 500 || error.status === 429;
  },
};
```

### Development Configuration

```typescript
import { RetryPolicies } from './retry-logic';

const developmentConfig = {
  ...RetryPolicies.aggressive.options,
  totalTimeout: 300000, // Longer timeout for debugging
  onRetry: (error, attempt, delay) => {
    console.log(`Debug: Retrying attempt ${attempt} after ${delay}ms delay`);
    console.log('Error:', error);
  },
};
```

## Best Practices

### 1. Choose Appropriate Policies

```typescript
// ✅ Good: Use specific policy for the use case
const result = await AsyncRetryUtils.retryWithBackoff(
  operation, 
  'database'
);

// ❌ Bad: Using generic policy for database operations
const result = await AsyncRetryUtils.retry(operation, { maxAttempts: 3 });
```

### 2. Implement Proper Error Handling

```typescript
// ✅ Good: Specific error conditions
const result = await AsyncRetryUtils.retry(
  async () => { /* operation */ },
  {
    retryCondition: (error) => error.status >= 500 && error.status < 600,
    onRetry: (error, attempt, delay) => {
      console.log(`Server error, retrying in ${delay}ms`);
    },
  }
);

// ❌ Bad: Catching all errors
const result = await AsyncRetryUtils.retry(
  async () => { /* operation */ },
  { retryCondition: () => true }
);
```

### 3. Monitor Performance

```typescript
// ✅ Good: Monitor and log metrics
const monitoring = MonitoringSystems.detailed();

try {
  const result = await AsyncRetryUtils.retry(operation, {
    onRetry: (error, attempt, delay) => {
      monitoring.getMetricsCollector().recordRetryAttempt(attempt, delay, error);
    },
  });
  
  const report = monitoring.getMonitoringReport();
  console.log('Success rate:', report.metrics.successRate);
} catch (error) {
  monitoring.getLogger().logCustom('Operation failed', 'ERROR', { error });
}

// ❌ Bad: No monitoring
const result = await AsyncRetryUtils.retry(operation);
```

### 4. Use Circuit Breakers for External Services

```typescript
// ✅ Good: Protect external API calls with circuit breaker
const circuitBreaker = new CircuitBreaker({
  failureThreshold: 50,
  monitoringWindow: 60000,
});

const result = await circuitBreaker.execute(async () => {
  const response = await fetch('https://external-api.com/data');
  return response.json();
}, () => 'Fallback data');

// ❌ Bad: No circuit breaker for external services
const result = await AsyncRetryUtils.retry(async () => {
  const response = await fetch('https://external-api.com/data');
  return response.json();
});
```

## API Reference

### Core Classes

- `RetryLogic`: Core retry implementation with metrics and logging
- `ExponentialBackoff`: Exponential backoff with jitter strategies
- `CircuitBreaker`: Circuit breaker pattern implementation
- `RetryablePromise`: Promise wrapper with retry functionality

### Decorators

- `retry(options?, circuitBreaker?)`: Async function decorator
- `retrySync(options?, circuitBreaker?)`: Sync function decorator
- `withCircuitBreaker(circuitBreaker, operation)`: Circuit breaker wrapper

### Utilities

- `AsyncRetryUtils`: Async/await retry utilities
- `PromiseRetryUtils`: Promise-based retry patterns
- `MonitoringSystems`: Pre-configured monitoring systems

### Factories

- `createRetry(policy?, circuitBreaker?)`: Create retry instance with policy
- `BackoffStrategies`: Pre-configured backoff strategies
- `RetryablePromiseFactories`: Pre-configured promise factories

## License

MIT License

## Contributing

Contributions are welcome! Please read the contributing guidelines and submit pull requests.

## Changelog

### v1.0.0
- Initial release
- Core retry logic with exponential backoff
- Circuit breaker implementation
- Decorators for functions and classes
- Comprehensive metrics and logging
- Async/await utilities
- Promise-based patterns
- Pre-built policies for common use cases