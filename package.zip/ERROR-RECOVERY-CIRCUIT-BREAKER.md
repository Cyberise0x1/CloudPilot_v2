# Error Recovery and Circuit Breaker Documentation

## Table of Contents

1. [Resilience Overview](#resilience-overview)
2. [Circuit Breaker Pattern Guide](#circuit-breaker-pattern-guide)
3. [Retry Logic Documentation](#retry-logic-documentation)
4. [Graceful Degradation Strategies](#graceful-degradation-strategies)
5. [Error Recovery Workflows](#error-recovery-workflows)
6. [AWS Service Integration](#aws-service-integration)
7. [Monitoring and Alerting](#monitoring-and-alerting)
8. [Best Practices](#best-practices)
9. [Troubleshooting Guide](#troubleshooting-guide)

---

## Resilience Overview

### Introduction

Resilience is the ability of a system to handle failures gracefully and continue operating. In modern distributed systems, resilience patterns are essential for maintaining service availability and providing a good user experience even when components fail.

### Key Resilience Patterns

#### 1. Circuit Breaker
- **Purpose**: Prevent cascading failures by detecting faulty services
- **States**: CLOSED (normal), OPEN (blocking), HALF-OPEN (testing)
- **Benefit**: Protects healthy parts of the system from failing components

#### 2. Retry Logic
- **Purpose**: Automatically retry failed operations that might succeed on subsequent attempts
- **Strategies**: Fixed delay, exponential backoff, jitter
- **Benefit**: Handles transient failures without manual intervention

#### 3. Graceful Degradation
- **Purpose**: Maintain reduced functionality when full functionality is unavailable
- **Strategies**: Fallbacks, caching, offline mode
- **Benefit**: Users can still use the application with limited features

#### 4. Error Recovery
- **Purpose**: Automatic and manual processes to restore normal operations
- **Types**: Automated recovery, manual intervention, escalation
- **Benefit**: Minimizes downtime and reduces manual effort

### Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                        Resilience Layer                             │
├─────────────────────────────────────────────────────────────────────┤
│  Circuit Breakers  │  Retry Logic  │  Graceful Degradation  │ Error │
│                    │               │                        │ Recovery│
├─────────────────────────────────────────────────────────────────────┤
│                    Monitoring & Alerting                           │
├─────────────────────────────────────────────────────────────────────┤
│                    Application Layer                               │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Circuit Breaker Pattern Guide

### What is a Circuit Breaker?

A circuit breaker is a design pattern that prevents an application from repeatedly trying to execute an operation that's likely to fail. It allows the application to continue without waiting for the failing service to recover.

### Circuit Breaker States

#### CLOSED State
- Normal operation state
- All requests pass through to the underlying service
- Monitors failure rate

```typescript
import { CircuitBreaker } from './circuit-breaker';

const breaker = new CircuitBreaker(
  async () => await externalService.call(),
  {
    failureThreshold: 3,
    resetTimeout: 5000,
    monitoringPeriod: 10000
  }
);

// In CLOSED state - operations execute normally
const result = await breaker.execute();
```

#### OPEN State
- Circuit breaker "triped"
- Immediately rejects requests with error
- Prevents load on failing service

```typescript
// When circuit is OPEN, requests are immediately rejected
try {
  const result = await breaker.execute();
} catch (error) {
  if (error.message.includes('Circuit breaker is OPEN')) {
    // Use fallback or cached response
    return getCachedData();
  }
}
```

#### HALF-OPEN State
- Testing state to check if service has recovered
- Allows limited requests to test service
- Returns to OPEN on failure, CLOSED on success

```typescript
// After resetTimeout expires, circuit moves to HALF-OPEN
// If a test request succeeds, circuit returns to CLOSED
// If test request fails, circuit returns to OPEN
```

### Circuit Breaker Configuration

```typescript
interface CircuitBreakerConfig {
  failureThreshold: number;        // Failures needed to open circuit (default: 5)
  resetTimeout: number;            // Time to wait before testing recovery (ms)
  monitoringPeriod: number;        // Window for calculating failure rate (ms)
  volumeThreshold: number;         // Min requests before circuit can open (default: 5)
  timeout: number;                 // Request timeout (ms)
  successThreshold: number;        // Successes to close circuit (default: 3)
  errorTypes?: Error[];            // Specific error types to count as failures
  onStateChange?: (from: string, to: string) => void;
  onFailure?: (error: Error) => void;
  onSuccess?: () => void;
}

const config: CircuitBreakerConfig = {
  failureThreshold: 5,
  resetTimeout: 30000,     // 30 seconds
  monitoringPeriod: 10000, // 10 seconds
  volumeThreshold: 5,
  timeout: 10000
};
```

### Implementation Examples

#### Basic Circuit Breaker

```typescript
import { createSimpleCircuitBreaker } from './circuit-breaker';

const flakyService = createSimpleCircuitBreaker(
  async () => {
    const response = await fetch('https://api.example.com/data');
    if (!response.ok) throw new Error('API Error');
    return response.json();
  },
  'api-service',
  {
    failureThreshold: 3,
    resetTimeout: 5000
  }
);

try {
  const data = await flakyService();
  console.log('Success:', data);
} catch (error) {
  console.error('Failed:', error.message);
}
```

#### Express Middleware Integration

```typescript
import express from 'express';
import { createCircuitBreakerMiddleware } from './circuit-breaker';

const app = express();

const protectedRoute = createCircuitBreakerMiddleware(
  async (req, res) => {
    // Your route logic here
    const data = await externalService.call();
    res.json(data);
  },
  {
    name: 'protected-api',
    config: {
      failureThreshold: 3,
      resetTimeout: 30000
    },
    onFailure: (req, res, error) => {
      res.status(503).json({
        error: 'Service temporarily unavailable',
        message: 'Please try again later'
      });
    }
  }
);

app.get('/api/data', protectedRoute);
```

#### Advanced Circuit Breaker with Health Check

```typescript
const advancedBreaker = new CircuitBreaker(
  async () => await externalService.call(),
  {
    failureThreshold: 5,
    resetTimeout: 30000,
    healthCheck: async () => {
      try {
        const response = await fetch('https://service-health.example.com/ping');
        return response.ok;
      } catch {
        return false;
      }
    }
  }
);

// Monitor circuit breaker events
advancedBreaker.on('stateChange', (from, to) => {
  console.log(`Circuit breaker ${name}: ${from} → ${to}`);
});

advancedBreaker.on('circuitTripped', (error) => {
  console.error('Circuit tripped due to:', error.message);
  // Trigger alerts, log event, etc.
});
```

### Circuit Breaker Metrics

```typescript
// Get circuit breaker metrics
const metrics = breaker.getMetrics();
console.log({
  state: metrics.state,
  totalRequests: metrics.totalRequests,
  totalFailures: metrics.totalFailures,
  successRate: metrics.successRate,
  failureRate: metrics.failureRate,
  averageLatency: metrics.averageLatency
});
```

---

## Retry Logic Documentation

### Retry Strategies

#### 1. Fixed Delay Retry
- Uses consistent delay between attempts
- Simple and predictable
- Best for: Known failure patterns with consistent timing

```typescript
import { retry, RetryPolicies } from './retry-logic';

const result = await retry(
  async () => {
    const response = await fetch('https://api.example.com/data');
    if (!response.ok) throw new Error('API Error');
    return response.json();
  },
  {
    maxAttempts: 3,
    baseDelay: 1000,  // 1 second delay between each retry
    retryCondition: (error) => error.status >= 500
  }
);
```

#### 2. Exponential Backoff
- Delay increases exponentially with each retry
- Reduces load on failing services
- Best for: Rate limiting, temporary network issues

```typescript
const result = await retry(
  async () => {
    // Your operation here
  },
  {
    maxAttempts: 5,
    baseDelay: 1000,           // Start with 1 second
    maxDelay: 30000,           // Cap at 30 seconds
    backoffMultiplier: 2,      // Double delay each time
    exponentialBackoff: true,
    jitterEnabled: true,       // Add randomness to prevent thundering herd
    jitterFactor: 0.1
  }
);

// Delays will be approximately: 1000, 2000, 4000, 8000, 16000
```

#### 3. Linear Backoff
- Delay increases linearly
- More aggressive than exponential
- Best for: Gradual load increase scenarios

```typescript
const result = await retry(
  async () => {
    // Your operation here
  },
  {
    maxAttempts: 4,
    baseDelay: 500,            // 0.5 seconds
    maxDelay: 10000,
    backoffMultiplier: 1.5,    // Linear increase
    exponentialBackoff: false
  }
);

// Delays: 500, 750, 1125, 1687
```

### Advanced Retry Patterns

#### Conditional Retry
```typescript
const result = await retry(
  async () => {
    const response = await apiCall();
    return response.json();
  },
  {
    maxAttempts: 5,
    retryCondition: (error, attempt) => {
      // Retry on specific conditions
      if (error.status === 429) {
        // Rate limited - longer delays
        return attempt < 3;
      }
      if (error.status >= 500) {
        // Server errors
        return attempt < 5;
      }
      if (error.code === 'ECONNRESET') {
        // Network errors
        return attempt < 3;
      }
      return false; // Don't retry other errors
    }
  }
);
```

#### Decorator Pattern
```typescript
import { retry } from './retry-logic';

class UserService {
  @retry({ maxAttempts: 3, baseDelay: 1000 })
  async fetchUser(id: string) {
    const response = await fetch(`/api/users/${id}`);
    if (!response.ok) throw new Error('User fetch failed');
    return response.json();
  }

  @retry({ 
    maxAttempts: 5, 
    baseDelay: 2000,
    retryCondition: (error) => error.status >= 500 
  })
  async updateUser(id: string, data: any) {
    const response = await fetch(`/api/users/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data)
    });
    if (!response.ok) throw new Error('User update failed');
    return response.json();
  }
}
```

### Pre-configured Policies

```typescript
// Quick retry for transient failures
const quickPolicy = RetryPolicies.quick;

// Standard retry for general use
const standardPolicy = RetryPolicies.standard;

// Aggressive retry for critical operations
const aggressivePolicy = RetryPolicies.aggressive;

// Conservative retry for non-critical operations
const conservativePolicy = RetryPolicies.conservative;

// Database optimized
const databasePolicy = RetryPolicies.database;

// API optimized
const apiPolicy = RetryPolicies.api;

// Use pre-configured policy
const result = await AsyncRetryUtils.retryWithBackoff(
  async () => await dbOperation(),
  'database'  // Uses database policy
);
```

### Retry with Circuit Breaker

```typescript
import { CircuitBreaker, retry } from './retry-logic';

// Combine retry logic with circuit breaker
const circuitBreaker = new CircuitBreaker({
  failureThreshold: 50,
  monitoringWindow: 60000,
});

const result = await retry(
  { 
    maxAttempts: 5, 
    baseDelay: 1000 
  },
  circuitBreaker  // Circuit breaker protects against cascading failures
)(async () => {
  const response = await fetch('https://api.example.com/data');
  if (!response.ok) throw new Error('API Error');
  return response.json();
})();
```

### Promise-Based Retry

```typescript
import { RetryablePromise } from './retry-logic';

// Create a retryable promise
const retryable = new RetryablePromise(
  async () => {
    const response = await fetch('https://api.example.com/data');
    if (!response.ok) throw new Error('API Error');
    return response.json();
  },
  { 
    maxAttempts: 3,
    baseDelay: 1000
  }
);

const result = await retryable.thenResolving();
```

---

## Graceful Degradation Strategies

### Overview

Graceful degradation ensures that when a system component fails, the overall system continues to function with reduced capabilities rather than complete failure.

### Fallback Strategies

#### 1. Cache-First Fallback
- Serve cached data when primary service is unavailable
- Best for: Read-heavy operations, data that doesn't change frequently

```typescript
import { FallbackHandler } from './graceful-degradation';

const fallback = new FallbackHandler();

const response = await fallback.executeWithFallback(
  request,
  async () => {
    // Primary service call
    const data = await fetchFromPrimaryService(request.id);
    return data;
  },
  {
    strategy: FallbackStrategy.CACHE_FIRST,
    cacheKey: `user:${request.id}`,
    maxCacheAge: 300000 // 5 minutes
  }
);

if (response.fallback) {
  console.log(`Using cached data (age: ${response.cacheAge}ms)`);
}
```

#### 2. Static Response Fallback
- Serve predefined static responses
- Best for: Non-critical features, error messages

```typescript
const response = await fallback.executeWithFallback(
  request,
  async () => await primaryService.call(),
  {
    strategy: FallbackStrategy.STATIC_RESPONSE,
    staticData: {
      status: 'unavailable',
      message: 'Service temporarily unavailable',
      retryAfter: 30
    }
  }
);
```

#### 3. Alternative Service Fallback
- Route to backup/alternative service
- Best for: Redundant systems, backup providers

```typescript
const response = await fallback.executeWithFallback(
  request,
  async () => await primaryService.call(),
  {
    strategy: FallbackStrategy.ALTERNATIVE_SERVICE,
    alternativeService: async (request) => {
      // Fallback to secondary service
      return await backupService.call(request);
    }
  }
);
```

#### 4. Queue for Later Processing
- Queue requests for processing when service recovers
- Best for: Write operations, non-time-sensitive tasks

```typescript
const response = await fallback.executeWithFallback(
  request,
  async () => await primaryService.call(),
  {
    strategy: FallbackStrategy.QUEUE_FOR_LATER,
    queueConfig: {
      maxQueueSize: 1000,
      queueTimeout: 3600000 // 1 hour
    }
  }
);
```

### Complete Graceful Degradation Setup

```typescript
import { GracefulDegradationSystem, ServicePriority } from './graceful-degradation';

const degradationSystem = new GracefulDegradationSystem();

await degradationSystem.initialize({
  services: [
    {
      id: 'api-service',
      name: 'API Service',
      endpoint: 'https://api.example.com',
      priority: ServicePriority.CRITICAL,
      healthCheckInterval: 30000,
      timeout: 5000,
      fallbackStrategies: [
        { strategy: FallbackStrategy.CACHE_FIRST },
        { strategy: FallbackStrategy.STATIC_RESPONSE }
      ]
    }
  ],
  globalSettings: {
    enableAutomaticFailover: true,
    defaultTimeout: 5000,
    maxCacheSize: 1000
  }
});
```

### Client-Side Graceful Degradation

```typescript
import { GracefulDegradationClient } from './graceful-degradation';

const client = new GracefulDegradationClient(degradationSystem);

// Request with automatic fallback
const userData = await client.request('/api/users', {
  method: 'GET',
  headers: { 'Authorization': 'Bearer token' }
}, {
  cacheKey: 'users:all',
  cacheTtl: 300000,
  fallbackData: [] // Default empty array if everything fails
});
```

### Offline Mode Support

```typescript
const offline = new OfflineModeManager();

// Enable offline mode
offline.enableOfflineMode();

// Store data for offline access
offline.storeOfflineData('cached-users', userList);

// Check if system is offline
if (offline.isSystemOffline()) {
  // Use offline data
  const cachedData = offline.getOfflineData('cached-users');
  return cachedData;
}

// Sync data when back online
offline.on('online', async () => {
  const pendingData = offline.getPendingData();
  for (const data of pendingData) {
    await syncWithServer(data);
  }
});
```

### Service Priority Management

```typescript
const priority = new ServicePriorityManager();

// Set service priority
priority.setServicePriority('api-service', ServicePriority.HIGH);

// Check if service can accept requests
if (priority.canAcceptRequest('api-service')) {
  // Acquire service slot
  const slotAcquired = await priority.requestServiceSlot(
    'api-service',
    ServicePriority.MEDIUM,
    5000
  );
  
  if (slotAcquired) {
    try {
      const result = await apiService.call();
      return result;
    } finally {
      priority.releaseServiceSlot('api-service');
    }
  }
}
```

### Priority Levels

```typescript
enum ServicePriority {
  CRITICAL = 1,    // Core functionality, must always work
  HIGH = 2,        // Important features, minimal degradation
  MEDIUM = 3,      // Normal features, can be degraded
  LOW = 4,         // Nice-to-have features, can be disabled
  BACKGROUND = 5   // Background tasks, can be suspended
}
```

---

## Error Recovery Workflows

### Automated Recovery

Automated recovery handles common, predictable errors without human intervention.

```typescript
import { automatedRecovery } from './error-recovery';

const result = await automatedRecovery.executeRecovery(classifiedError, {
  error: classifiedError,
  metadata: classifiedError.metadata,
  previousStepResults: new Map(),
  environment: 'production'
});

if (result.success) {
  console.log(`Recovery completed in ${result.executionTime}ms`);
} else {
  console.log(`Recovery failed: ${result.error?.message}`);
}
```

### Error Classification

```typescript
import { errorClassifier, ErrorSeverity } from './error-recovery';

const error = new Error('Database connection timeout');
const metadata = {
  timestamp: new Date(),
  source: 'database-service',
  component: 'user-service',
  environment: 'production'
};

const classifiedError = errorClassifier.classify(error, metadata);

console.log({
  category: classifiedError.category,
  severity: classifiedError.severity,
  autoRecoverable: classifiedError.autoRecoverable,
  recoveryProcedure: classifiedError.recoveryProcedure
});
```

### Recovery Procedures

#### Database Connection Recovery

```typescript
automatedRecovery.registerProcedure({
  name: 'Database Connection Recovery',
  category: 'database',
  severity: ['high', 'critical'],
  steps: [
    {
      id: 'check-connections',
      name: 'Check Database Connections',
      action: { type: 'check-db-connections' }
    },
    {
      id: 'restart-connection-pool',
      name: 'Restart Connection Pool',
      action: { type: 'restart-connection-pool' }
    },
    {
      id: 'verify-connection',
      name: 'Verify Connection',
      action: { type: 'verify-connection' }
    }
  ],
  timeout: 180000,
  maxRetries: 2
});
```

#### API Service Recovery

```typescript
automatedRecovery.registerProcedure({
  name: 'API Service Recovery',
  category: 'api',
  severity: ['medium', 'high'],
  steps: [
    {
      id: 'check-circuit-breaker',
      name: 'Check Circuit Breaker Status',
      action: { type: 'check-circuit-breaker' }
    },
    {
      id: 'reset-circuit-breaker',
      name: 'Reset Circuit Breaker',
      action: { type: 'reset-circuit-breaker' }
    },
    {
      id: 'test-endpoint',
      name: 'Test Service Endpoint',
      action: { type: 'test-endpoint' }
    }
  ],
  timeout: 120000,
  maxRetries: 1
});
```

### Manual Intervention Workflows

```typescript
import { manualInterventionWorkflow } from './error-recovery';

const request = await manualInterventionWorkflow.createInterventionRequest(
  classifiedError,
  'database-recovery',
  {
    sessionId: 'recovery-123',
    escalationReason: 'Automated recovery failed',
    requiredSkills: ['database-administration'],
    estimatedTime: 30 // minutes
  }
);

console.log({
  requestId: request.id,
  assignedTo: request.assignedTo,
  priority: request.priority,
  estimatedCompletion: request.estimatedCompletion
});
```

### Recovery Orchestration

```typescript
import { recoveryOrchestrator, RecoveryMode } from './error-recovery';

// Initiate recovery process
const sessionId = await recoveryOrchestrator.initiateRecovery(
  classifiedError,
  RecoveryMode.HYBRID,  // Automated first, then manual if needed
  'default-policy'
);

// Monitor recovery progress
recoveryOrchestrator.on('recoveryStepCompleted', (data) => {
  console.log(`Step ${data.stepId} completed: ${data.result}`);
});

recoveryOrchestrator.on('recoveryCompleted', (data) => {
  console.log(`Recovery completed: ${data.sessionId}`);
  console.log(`Duration: ${data.duration}ms`);
  console.log(`Success: ${data.success}`);
});
```

### Recovery Tracking

```typescript
import { recoveryTracker } from './error-recovery';

await recoveryTracker.recordRecoverySession(sessionId, {
  errorId: classifiedError.metadata.correlationId,
  error: {
    category: classifiedError.category,
    severity: classifiedError.severity,
    message: classifiedError.message
  },
  recovery: {
    method: RecoveryMethod.AUTOMATED,
    startTime: new Date(),
    outcome: RecoveryOutcome.SUCCESS,
    steps: [
      { id: 'step-1', duration: 5000, success: true },
      { id: 'step-2', duration: 3000, success: true },
      { id: 'step-3', duration: 2000, success: true }
    ]
  },
  metrics: {
    timeToDetection: 5000,
    timeToRecovery: 10000,
    automationSuccessRate: 100
  },
  impact: {
    userImpact: 2,
    businessImpact: 3,
    downtime: 10000,
    affectedUsers: 0
  }
});

// Generate analytics
const analytics = await recoveryTracker.generateAnalytics('month');
console.log({
  overallSuccessRate: analytics.overall.successRate,
  averageRecoveryTime: analytics.overall.averageRecoveryTime,
  automationCoverage: analytics.overall.automationCoverage
});
```

### Notification System

```typescript
import { notificationSystem, NotificationPriority } from './error-recovery';

// Send critical alert
const requestIds = await notificationSystem.sendCriticalAlert(
  classifiedError,
  'outage'
);

// Send custom notification
const requestId = await notificationSystem.sendNotification(
  classifiedError,
  'error-alert',
  ['engineering-team'],
  NotificationPriority.HIGH,
  {
    context: 'Production error detected',
    escalationDelay: 300 // 5 minutes
  }
);

// Track notification delivery
notificationSystem.on('notificationSent', (data) => {
  console.log(`Notification sent: ${data.recipient} via ${data.channel}`);
});

notificationSystem.on('notificationDelivered', (data) => {
  console.log(`Notification delivered: ${data.recipient} at ${data.deliveredAt}`);
});
```

### Recovery Testing

```typescript
import { recoveryTestingSystem } from './error-recovery';

// Run recovery test
const runId = await recoveryTestingSystem.runTest(
  'db-connection-test',
  {
    name: 'Test Environment',
    type: 'test',
    region: 'us-east-1',
    configuration: {},
    isolation: { network: true, data: true, resources: true }
  },
  'automated-test'
);

// Execute disaster recovery drill
const drillId = await recoveryTestingSystem.scheduleDrill(
  'Database Failover Drill',
  'Simulate database failure and verify recovery',
  [
    {
      id: 'participant-1',
      name: 'John Doe',
      role: 'Database Administrator',
      contact: 'john@company.com'
    }
  ],
  new Date(Date.now() + 24 * 60 * 60 * 1000), // Tomorrow
  60, // 60 minutes
  [
    {
      id: 'obj-1',
      description: 'Complete recovery within 30 minutes',
      type: 'technical',
      target: 1800000 // 30 minutes in ms
    }
  ]
);
```

---

## AWS Service Integration

### AWS Circuit Breaker Factory

```typescript
import { 
  AWSServiceCircuitBreakerFactory, 
  AWS_SERVICE_CONFIGS 
} from './circuit-breaker';

const s3Client = new S3Client({ region: 'us-east-1' });
const dynamoDBClient = new DynamoDBClient({ region: 'us-east-1' });

const factory = new AWSServiceCircuitBreakerFactory();

const serviceConfigs = [
  {
    service: 's3',
    config: {
      ...AWS_SERVICE_CONFIGS.s3,
      onError: (error: Error, operation: string) => {
        console.error(`S3 operation ${operation} failed:`, error.message);
      }
    },
    operations: ['getObject', 'putObject', 'deleteObject']
  },
  {
    service: 'dynamodb',
    config: AWS_SERVICE_CONFIGS.dynamodb,
    operations: ['getItem', 'putItem', 'query', 'scan']
  }
];

const protectedServices = factory.create(serviceConfigs, {
  s3: s3Client,
  dynamodb: dynamoDBClient
});
```

### Protected AWS Client Creation

```typescript
import { createProtectedAWSClient } from './circuit-breaker';

const s3Client = new S3Client({ region: 'us-east-1' });
const protectedS3 = createProtectedAWSClient('s3', s3Client, {
  config: {
    failureThreshold: 3,
    resetTimeout: 30000
  },
  operations: ['getObject', 'putObject']
});

// Use protected S3 client
const result = await protectedS3.getObject({
  Bucket: 'my-bucket',
  Key: 'my-file.txt'
});
```

### AWS Service-Specific Configurations

#### S3 Configuration
```typescript
const s3Config = {
  failureThreshold: 5,        // S3 is highly reliable
  resetTimeout: 60000,        // 1 minute to recover
  timeout: 30000,             // 30 second operation timeout
  retryableErrors: [
    'ServiceUnavailable',
    'Throttling',
    'Networking'
  ]
};
```

#### DynamoDB Configuration
```typescript
const dynamoDBConfig = {
  failureThreshold: 3,        // More sensitive for database
  resetTimeout: 30000,        // 30 seconds
  timeout: 15000,             // 15 second timeout
  retryableErrors: [
    'ThrottlingException',
    'ProvisionedThroughputExceededException',
    'RequestTimeoutException'
  ]
};
```

#### Lambda Configuration
```typescript
const lambdaConfig = {
  failureThreshold: 5,
  resetTimeout: 30000,
  timeout: 60000,             // Longer timeout for Lambda
  retryableErrors: [
    'ServiceException',
    'ThrottlingException'
  ]
};
```

### AWS SDK Integration Examples

#### S3 with Retry Logic
```typescript
import { AsyncRetryPatterns } from './retry-logic';

const s3Download = AsyncRetryPatterns.apiCall(async () => {
  const command = new GetObjectCommand({
    Bucket: 'my-bucket',
    Key: 'my-file.txt'
  });
  
  const response = await s3Client.send(command);
  return response.Body?.transformToString();
});

// Automatically retries on AWS-specific errors
const data = await s3Download();
```

#### DynamoDB with Circuit Breaker
```typescript
import { CircuitBreaker } from './circuit-breaker';

const dynamoCircuitBreaker = new CircuitBreaker(
  async (command) => {
    return await dynamoDBClient.send(command);
  },
  {
    failureThreshold: 3,
    resetTimeout: 30000,
    retryableErrors: ['ThrottlingException']
  }
);

// Execute DynamoDB operation
const result = await dynamoCircuitBreaker.execute(async () => {
  return await dynamoDBClient.send(new GetItemCommand({
    TableName: 'Users',
    Key: { id: { S: 'user123' } }
  }));
});
```

### Monitoring AWS Services

```typescript
import { MonitoringSystems } from './retry-logic';

const monitoring = MonitoringSystems.detailed();

// Monitor AWS service calls
const monitoredS3Call = AsyncRetryUtils.retry(
  async () => {
    const result = await s3Client.send(new GetObjectCommand({
      Bucket: 'my-bucket',
      Key: 'my-file.txt'
    }));
    
    monitoring.getMetricsCollector().recordSuccessfulCall('s3', 'GetObject');
    return result;
  },
  {
    maxAttempts: 3,
    onRetry: (error, attempt, delay) => {
      monitoring.getMetricsCollector().recordRetry('s3', 'GetObject', attempt, error);
    }
  }
);

const result = await monitoredS3Call();
const report = monitoring.getMonitoringReport();
console.log('S3 performance:', report.awsServices.s3);
```

### AWS Lambda with Resilience

```typescript
import { ResilienceConfigManager } from './resilience.config';

export const handler = async (event: any) => {
  const resilienceConfig = new ResilienceConfigManager();
  const circuitBreaker = resilienceConfig.getCircuitBreaker('dynamodb-operation');
  
  try {
    const result = await circuitBreaker.execute(async () => {
      const retryPolicy = resilienceConfig.getRetryPolicy('lambda-operation');
      
      return await retryPolicy.execute(async () => {
        const timeout = resilienceConfig.getTimeout('lambda-operation');
        
        return await timeout.execute(async () => {
          // Your Lambda logic here
          const dynamoResult = await dynamoDBClient.send(new GetItemCommand({
            TableName: process.env.TABLE_NAME!,
            Key: { id: { S: event.userId } }
          }));
          
          return {
            statusCode: 200,
            body: JSON.stringify(dynamoResult)
          };
        });
      });
    });
    
    return result;
  } catch (error) {
    // Graceful fallback
    return {
      statusCode: 503,
      body: JSON.stringify({
        error: 'Service temporarily unavailable',
        retryAfter: 30
      })
    };
  }
};
```

---

## Monitoring and Alerting

### Metrics Collection

The resilience system provides comprehensive metrics for monitoring system health and performance.

```typescript
import { ResilienceConfigManager } from './resilience.config';

const resilienceConfig = new ResilienceConfigManager();

// Get all metrics
const allMetrics = resilienceConfig.getMetrics();

console.log({
  circuitBreakerState: allMetrics.circuitBreakerState,
  retryAttempts: allMetrics.retryAttemptsTotal,
  fallbackTriggers: allMetrics.fallbackTriggerTotal,
  operationDuration: allMetrics.operationDuration,
  errorRate: allMetrics.errorRate
});

// Record custom metrics
resilienceConfig.recordMetric('my_custom_metric', 42, {
  label1: 'value1',
  label2: 'value2'
});
```

### Health Check Endpoints

#### Resilience Health Endpoint
```http
GET /api/resilience/health
```

Response:
```json
{
  "status": "healthy",
  "circuitBreakers": {
    "external-api": "closed",
    "database": "closed",
    "bulk-processor": "closed"
  },
  "metrics": {
    "uptime": 3600,
    "memoryUsage": {
      "rss": 50331648,
      "heapUsed": 20971520
    },
    "activeCircuitBreakers": 3,
    "totalRequests": 1500,
    "errorRate": 2.1
  },
  "timestamp": "2025-10-31T07:27:40.000Z"
}
```

#### Detailed Metrics Endpoint
```http
GET /api/resilience/metrics
```

Returns Prometheus-formatted metrics:
```
# HELP circuit_breaker_state Current state of circuit breakers (0=closed, 1=open, 2=half-open)
# TYPE circuit_breaker_state gauge
circuit_breaker_state{service="api-service",name="api-circuit"} 0

# HELP retry_attempts_total Total number of retry attempts
# TYPE retry_attempts_total counter
retry_attempts_total{operation="db-query",status="success"} 150
retry_attempts_total{operation="db-query",status="failure"} 25

# HELP operation_duration_ms Duration of operations in milliseconds
# TYPE operation_duration_ms histogram
operation_duration_ms_bucket{operation="api-call",le="1000"} 800
operation_duration_ms_bucket{operation="api-call",le="5000"} 995
operation_duration_ms_bucket{operation="api-call",le="10000"} 999
```

### Alert Management

```typescript
import { GracefulDegradationMonitor } from './graceful-degradation';

const monitor = new GracefulDegradationMonitor(degradationSystem);

// Add alert rules
monitor.addAlertRule({
  id: 'high-error-rate',
  name: 'High Error Rate Alert',
  serviceId: 'api-service',
  metric: 'error_rate',
  operator: '>',
  threshold: 10,           // 10% error rate
  duration: 300000,        // 5 minutes
  severity: NotificationSeverity.ERROR,
  enabled: true
});

monitor.addAlertRule({
  id: 'circuit-breaker-open',
  name: 'Circuit Breaker Open Alert',
  serviceId: 'api-service',
  metric: 'circuit_breaker_state',
  operator: '=',
  threshold: 1,            // Circuit breaker open
  duration: 0,             // Immediate
  severity: NotificationSeverity.WARNING,
  enabled: true
});

monitor.addAlertRule({
  id: 'high-latency',
  name: 'High Latency Alert',
  serviceId: 'api-service',
  metric: 'operation_duration_p95',
  operator: '>',
  threshold: 5000,         // 5 seconds
  duration: 600000,        // 10 minutes
  severity: NotificationSeverity.WARNING,
  enabled: true
});

// Check for active alerts
const alerts = monitor.checkAlerts();
if (alerts.length > 0) {
  console.log('Active alerts:', alerts);
}

// Generate monitoring report
const report = monitor.generateReport();
console.log({
  systemStatus: report.system,
  serviceHealth: report.services,
  activeAlerts: report.alerts,
  performance: report.performance
});
```

### Circuit Breaker Dashboard

```typescript
import { startDashboard } from './circuit-breaker';

const dashboard = await startDashboard({
  port: 3001,
  host: 'localhost',
  updateInterval: 5000,
  enableWebSocket: true,
  auth: {
    enabled: true,
    username: 'admin',
    password: 'password123'
  }
});

console.log('Dashboard available at http://localhost:3001');
```

### Event Monitoring

```typescript
import { getGlobalRegistry } from './circuit-breaker';

const registry = getGlobalRegistry();

// Subscribe to all circuit breaker events
registry.onEvent((event) => {
  console.log('Circuit breaker event:', {
    circuitName: event.circuitName,
    type: event.type,
    timestamp: event.timestamp,
    data: event.data
  });
});

// Subscribe to specific events
registry.on('CIRCUIT_TRIPPED', (data) => {
  console.warn(`Circuit ${data.circuitName} tripped:`, data.error);
  // Send alert
  sendAlert({
    severity: 'high',
    message: `Circuit breaker tripped for ${data.circuitName}`,
    details: data
  });
});

registry.on('CIRCUIT_RECOVERED', (data) => {
  console.log(`Circuit ${data.circuitName} recovered`);
  // Send recovery notification
  sendNotification({
    severity: 'info',
    message: `Service ${data.circuitName} has recovered`
  });
});
```

### Comprehensive Monitoring Setup

```typescript
import { AsyncRetryUtils, MonitoringSystems } from './retry-logic';

class ComprehensiveMonitoring {
  private monitoring: any;
  
  constructor() {
    this.monitoring = MonitoringSystems.detailed();
  }
  
  async monitorOperation(operation: string, fn: () => Promise<any>) {
    const startTime = Date.now();
    
    try {
      const result = await AsyncRetryUtils.retry(
        fn,
        {
          maxAttempts: 3,
          onRetry: (error, attempt, delay) => {
            this.monitoring.getMetricsCollector().recordRetryAttempt(
              attempt, 
              delay, 
              error
            );
          }
        }
      );
      
      const duration = Date.now() - startTime;
      this.monitoring.getMetricsCollector().recordSuccess(operation, duration);
      
      return result;
    } catch (error) {
      const duration = Date.now() - startTime;
      this.monitoring.getMetricsCollector().recordFailure(operation, duration, error);
      
      this.monitoring.getLogger().logCustom(
        `Operation ${operation} failed`,
        'ERROR',
        { 
          error: error.message, 
          duration,
          operation 
        }
      );
      
      throw error;
    }
  }
  
  generateReport() {
    return this.monitoring.getMonitoringReport();
  }
  
  getMetrics() {
    return this.monitoring.getMetricsCollector().getMetrics();
  }
  
  getLogs() {
    return this.monitoring.getLogger().getLogs();
  }
}

// Usage
const monitoring = new ComprehensiveMonitoring();

try {
  const result = await monitoring.monitorOperation(
    'api-call',
    async () => await fetch('https://api.example.com/data')
  );
  
  console.log('Operation successful:', result);
} catch (error) {
  console.error('Operation failed:', error);
}

// Generate comprehensive report
const report = monitoring.generateReport();
console.log({
  successRate: report.metrics.successRate,
  averageDelay: report.performance.averageDelay,
  totalOperations: report.performance.totalOperations,
  recentErrors: monitoring.getLogs().slice(-10)
});
```

### Prometheus Integration

```typescript
import client from 'prom-client';

class PrometheusMetrics {
  private registry: client.Registry;
  
  constructor() {
    this.registry = new client.Registry();
    this.setupMetrics();
  }
  
  private setupMetrics() {
    // Circuit breaker state
    new client.Gauge({
      name: 'circuit_breaker_state',
      help: 'Circuit breaker state (0=closed, 1=open, 2=half-open)',
      labelNames: ['service', 'circuit_name'],
      registers: [this.registry]
    });
    
    // Retry attempts
    new client.Counter({
      name: 'retry_attempts_total',
      help: 'Total number of retry attempts',
      labelNames: ['operation', 'status'],
      registers: [this.registry]
    });
    
    // Operation duration
    new client.Histogram({
      name: 'operation_duration_ms',
      help: 'Duration of operations in milliseconds',
      labelNames: ['operation'],
      buckets: [100, 500, 1000, 5000, 10000],
      registers: [this.registry]
    });
    
    // Error rate
    new client.Counter({
      name: 'operation_errors_total',
      help: 'Total number of operation errors',
      labelNames: ['operation', 'error_type'],
      registers: [this.registry]
    });
  }
  
  updateCircuitBreakerState(service: string, circuitName: string, state: number) {
    const gauge = client.register.getSingleMetric('circuit_breaker_state') as client.Gauge;
    gauge.labels({ service, circuit_name: circuitName }).set(state);
  }
  
  recordRetryAttempt(operation: string, status: 'success' | 'failure') {
    const counter = client.register.getSingleMetric('retry_attempts_total') as client.Counter;
    counter.labels({ operation, status }).inc();
  }
  
  recordOperationDuration(operation: string, duration: number) {
    const histogram = client.register.getSingleMetric('operation_duration_ms') as client.Histogram;
    histogram.labels({ operation }).observe(duration);
  }
  
  recordError(operation: string, errorType: string) {
    const counter = client.register.getSingleMetric('operation_errors_total') as client.Counter;
    counter.labels({ operation, error_type: errorType }).inc();
  }
  
  async getMetrics() {
    return await this.registry.metrics();
  }
}

// Usage
const promMetrics = new PrometheusMetrics();

// Update metrics based on circuit breaker events
registry.on('CIRCUIT_TRIPPED', (data) => {
  promMetrics.updateCircuitBreakerState(
    data.serviceName, 
    data.circuitName, 
    1 // OPEN state
  );
});

registry.on('CIRCUIT_RECOVERED', (data) => {
  promMetrics.updateCircuitBreakerState(
    data.serviceName, 
    data.circuitName, 
    0 // CLOSED state
  );
});

// Endpoint to expose metrics
app.get('/metrics', async (req, res) => {
  res.set('Content-Type', client.register.contentType);
  res.end(await promMetrics.getMetrics());
});
```

---

## Best Practices

### 1. Circuit Breaker Best Practices

#### Appropriate Thresholds
```typescript
// ✅ Good: Balanced thresholds
const goodConfig = {
  failureThreshold: 5,      // Reasonable failure count
  successThreshold: 3,      // Sufficient success confirmations
  resetTimeout: 30000,      // 30 seconds to recover
  monitoringPeriod: 10000   // 10 second monitoring window
};

// ❌ Bad: Poor thresholds
const badConfig = {
  failureThreshold: 1,      // Too sensitive - will open on single failure
  successThreshold: 10,     // Too strict - hard to close
  resetTimeout: 1000,       // Too short - may not have recovered
  monitoringPeriod: 60000   // Too long - slow to react
};
```

#### Error Classification
```typescript
// ✅ Good: Specific error handling
const breaker = new CircuitBreaker(operation, {
  errorTypes: [
    NetworkError,
    TimeoutError,
    ServiceUnavailableError
  ],
  excludeErrors: [
    ValidationError,
    AuthenticationError
  ],
  retryCondition: (error) => {
    // Only retry temporary failures
    return error.status >= 500 || error.code === 'ECONNRESET';
  }
});

// ❌ Bad: Catching all errors
const breaker = new CircuitBreaker(operation, {
  // No error classification - treats all errors equally
});
```

#### Monitoring and Alerting
```typescript
// ✅ Good: Comprehensive monitoring
const breaker = new CircuitBreaker(operation, {
  onStateChange: (from, to) => {
    // Log state changes
    logger.info(`Circuit ${name} state changed: ${from} → ${to}`);
    
    // Send alerts for state changes
    if (to === 'OPEN') {
      alerts.send({
        severity: 'warning',
        message: `Circuit breaker opened for ${name}`,
        context: { previousState: from, timestamp: Date.now() }
      });
    }
  },
  onFailure: (error) => {
    // Track failure patterns
    metrics.recordFailure(name, error);
  },
  onSuccess: () => {
    // Track success patterns
    metrics.recordSuccess(name);
  }
});

// ❌ Bad: No monitoring
const breaker = new CircuitBreaker(operation, {
  // No event handlers - no visibility into circuit behavior
});
```

### 2. Retry Logic Best Practices

#### Conservative Retry Limits
```typescript
// ✅ Good: Reasonable retry limits
const goodRetry = {
  maxAttempts: 3,           // Max 3 attempts (initial + 2 retries)
  maxRetryTime: 30000,      // Cap total retry time at 30 seconds
  baseDelay: 1000,          // Start with 1 second delay
  exponentialBackoff: true, // Reduce load on failing service
  jitterEnabled: true       // Prevent thundering herd problem
};

// ❌ Bad: Excessive retries
const badRetry = {
  maxAttempts: 10,          // Too many attempts
  maxRetryTime: 300000,     // 5 minutes of retries
  baseDelay: 100,           // Too aggressive
  exponentialBackoff: false, // No load reduction
  jitterEnabled: false      // Risk of thundering herd
};
```

#### Error-Specific Retry Decisions
```typescript
// ✅ Good: Smart retry decisions
const smartRetry = {
  retryCondition: (error, attempt) => {
    // Retry on temporary failures
    if (error.status === 429) {  // Rate limited
      return attempt < 3 && error.retryAfter <= 60;
    }
    
    if (error.status >= 500) {   // Server errors
      return attempt < 5;
    }
    
    if (error.code === 'ECONNRESET') {  // Network errors
      return attempt < 3;
    }
    
    // Don't retry on permanent failures
    if (error.status >= 400 && error.status < 500) {
      if (error.status !== 408 && error.status !== 429) {
        return false;  // Client errors (except timeout and rate limit)
      }
    }
    
    return false;
  }
};

// ❌ Bad: Retry everything or nothing
const dumbRetry = {
  retryCondition: () => true  // Retry everything - waste resources
  // OR
  retryCondition: () => false // Retry nothing - miss recoverable errors
};
```

#### Circuit Breaker Integration
```typescript
// ✅ Good: Protect retries with circuit breaker
const circuitBreaker = new CircuitBreaker(operation, {
  failureThreshold: 5,
  resetTimeout: 30000
});

const protectedRetry = retry({
  maxAttempts: 3,
  retryCondition: (error) => error.status >= 500
}, circuitBreaker);

// ✅ Good: Use appropriate retry policy for operation type
const dbRetry = AsyncRetryUtils.retryWithBackoff(
  operation, 
  'database'  // Uses database-optimized policy
);

const apiRetry = AsyncRetryUtils.retryWithBackoff(
  operation, 
  'api'  // Uses API-optimized policy
);
```

### 3. Graceful Degradation Best Practices

#### Fallback Strategy Ordering
```typescript
// ✅ Good: Logical fallback order
const goodFallbacks = [
  FallbackStrategy.CACHE_FIRST,      // Fast cached response
  FallbackStrategy.ALTERNATIVE_SERVICE, // Alternative provider
  FallbackStrategy.STATIC_RESPONSE    // Static fallback data
];

// ❌ Bad: Poor fallback order
const badFallbacks = [
  FallbackStrategy.STATIC_RESPONSE,  // Static response should be last resort
  FallbackStrategy.CACHE_FIRST,      // Cache should be attempted first
  FallbackStrategy.ALTERNATIVE_SERVICE // Alternative service should be before static
];
```

#### Cache Management
```typescript
// ✅ Good: Proper cache configuration
const cacheConfig = {
  maxAge: 300000,           // 5 minutes - reasonable staleness
  staleWhileRevalidate: true, // Serve stale while fetching fresh
  invalidateOnUpdate: true,   // Update cache on successful response
  maxSize: 1000             // Reasonable cache size
};

// ❌ Bad: Poor cache configuration
const badCacheConfig = {
  maxAge: 0,               // Never cache - defeats purpose
  staleWhileRevalidate: false, // No background refresh
  invalidateOnUpdate: false,   // Cache never updates
  maxSize: 1000000        // No size limit - memory leak risk
};
```

#### Service Priority Management
```typescript
// ✅ Good: Proper priority assignment
const serviceConfigs = [
  {
    id: 'auth-service',
    priority: ServicePriority.CRITICAL,  // Must always work
    fallbackStrategies: [FallbackStrategy.CACHE_FIRST]
  },
  {
    id: 'analytics-service',
    priority: ServicePriority.LOW,       // Nice to have
    fallbackStrategies: [FallbackStrategy.STATIC_RESPONSE]
  },
  {
    id: 'background-processor',
    priority: ServicePriority.BACKGROUND, // Can be suspended
    fallbackStrategies: [FallbackStrategy.QUEUE_FOR_LATER]
  }
];

// ❌ Bad: No priority strategy
const noPriority = [
  { id: 'service1', priority: ServicePriority.MEDIUM },
  { id: 'service2', priority: ServicePriority.MEDIUM },
  // All services treated equally - no degradation strategy
];
```

### 4. Error Recovery Best Practices

#### Automated vs Manual Recovery
```typescript
// ✅ Good: Clear automation boundaries
const recoveryPolicy = {
  automated: {
    maxAutomationTime: 300000,    // Max 5 minutes automation
    retryableErrors: ['timeout', 'connection_reset'],
    maxRetries: 3
  },
  manual: {
    escalateOnFailure: true,
    escalationDelay: 300000,      // 5 minutes
    requiredSkills: ['database-admin'],
    estimatedTime: 30             // 30 minutes for manual resolution
  }
};

// ❌ Bad: Unclear boundaries
const unclearPolicy = {
  // No max automation time - could run forever
  // No escalation criteria - manual intervention never triggered
  // No skill requirements - wrong person might be assigned
};
```

#### Recovery Procedure Design
```typescript
// ✅ Good: Structured recovery procedures
const goodProcedure = {
  name: 'Database Connection Recovery',
  category: 'database',
  severity: ['high', 'critical'],
  prerequisites: ['monitoring_available'],
  steps: [
    {
      id: 'check-connection',
      name: 'Check Connection Pool',
      description: 'Verify database connection pool status',
      action: { type: 'check-db-connections' },
      timeout: 10000,
      rollbackAction: null
    },
    {
      id: 'restart-pool',
      name: 'Restart Connection Pool',
      description: 'Restart the connection pool',
      action: { type: 'restart-connection-pool' },
      timeout: 30000,
      rollbackAction: { type: 'restore-connection-pool' }
    },
    {
      id: 'verify',
      name: 'Verify Connection',
      description: 'Test database connectivity',
      action: { type: 'verify-connection' },
      timeout: 15000,
      rollbackAction: null
    }
  ],
  timeout: 180000,
  maxRetries: 2,
  rollbackRequired: true,
  validationRequired: true
};

// ❌ Bad: Poor procedure design
const badProcedure = {
  name: 'Fix Database',
  // No clear steps, no timeout, no rollback, no validation
  steps: [
    {
      name: 'Try to fix it',
      action: { type: 'fix-database' }  // Vague action
    }
  ]
};
```

### 5. Monitoring Best Practices

#### Key Metrics to Monitor
```typescript
// ✅ Good: Comprehensive metrics
const keyMetrics = {
  circuitBreakers: {
    state: 'circuit_breaker_state',
    failureRate: 'circuit_breaker_failure_rate',
    recoveryTime: 'circuit_breaker_recovery_time'
  },
  retries: {
    attempts: 'retry_attempts_total',
    successRate: 'retry_success_rate',
    averageDelay: 'retry_average_delay'
  },
  operations: {
    duration: 'operation_duration_ms',
    errorRate: 'operation_error_rate',
    throughput: 'operation_throughput'
  },
  fallbacks: {
    activationRate: 'fallback_activation_rate',
    successRate: 'fallback_success_rate',
    responseTime: 'fallback_response_time'
  }
};

// ❌ Bad: Insufficient monitoring
const insufficientMetrics = {
  // Only monitoring errors - no visibility into performance
  errors: 'error_count'
};
```

#### Alert Strategy
```typescript
// ✅ Good: Tiered alerting
const alertStrategy = {
  immediate: {
    circuitBreakerOpen: {
      threshold: 0,           // Immediate
      severity: 'warning',
      channels: ['slack']
    },
    criticalErrorRate: {
      threshold: 0.05,        // 5% error rate
      duration: 0,            // Immediate
      severity: 'critical',
      channels: ['slack', 'email', 'pagerduty']
    }
  },
  trending: {
    highErrorRate: {
      threshold: 0.10,        // 10% error rate
      duration: 300000,       // 5 minutes
      severity: 'warning',
      channels: ['slack']
    },
    slowResponse: {
      threshold: 5000,        // 5 second P95
      duration: 600000,       // 10 minutes
      severity: 'warning',
      channels: ['email']
    }
  }
};

// ❌ Bad: Poor alerting
const badAlerts = {
  // Too many immediate alerts - alert fatigue
  // No trending alerts - miss gradual degradation
  // No severity differentiation - all alerts equal
};
```

### 6. Integration Best Practices

#### Service Discovery
```typescript
// ✅ Good: Resilient service discovery
class ResilientServiceClient {
  private circuitBreakers: Map<string, CircuitBreaker> = new Map();
  
  async callService(serviceName: string, endpoint: string) {
    const circuitBreaker = this.getCircuitBreaker(serviceName);
    
    return await circuitBreaker.execute(async () => {
      const serviceUrl = await this.serviceRegistry.discover(serviceName);
      const response = await fetch(`${serviceUrl}${endpoint}`);
      
      if (!response.ok) {
        throw new Error(`Service ${serviceName} returned ${response.status}`);
      }
      
      return response.json();
    });
  }
  
  private getCircuitBreaker(serviceName: string) {
    if (!this.circuitBreakers.has(serviceName)) {
      this.circuitBreakers.set(serviceName, new CircuitBreaker(
        (operation: () => Promise<any>) => operation(),
        {
          failureThreshold: 5,
          resetTimeout: 30000,
          monitoringPeriod: 10000
        }
      ));
    }
    
    return this.circuitBreakers.get(serviceName)!;
  }
}
```

#### Database Integration
```typescript
// ✅ Good: Resilient database operations
class ResilientDatabase {
  private circuitBreaker: CircuitBreaker;
  private retryPolicy: any;
  
  constructor() {
    this.circuitBreaker = new CircuitBreaker(
      (operation: () => Promise<any>) => operation(),
      {
        failureThreshold: 3,
        resetTimeout: 30000,
        errorTypes: [
          ConnectionError,
          TimeoutError,
          NetworkError
        ]
      }
    );
    
    this.retryPolicy = AsyncRetryUtils.retryWithBackoff(
      (operation: () => Promise<any>) => operation(),
      'database'
    );
  }
  
  async query(sql: string, params: any[] = []) {
    return await this.circuitBreaker.execute(async () => {
      return await this.retryPolicy.execute(async () => {
        // Actual database query with timeout
        const timeout = this.resilienceConfig.getTimeout('database-query');
        
        return await timeout.execute(async () => {
          return await this.database.query(sql, params);
        });
      });
    });
  }
}
```

#### Express.js Integration
```typescript
// ✅ Good: Comprehensive Express integration
class ResilienceMiddleware {
  constructor(private resilienceConfig: ResilienceConfigManager) {}
  
  circuitBreaker(serviceName: string) {
    return async (req: Request, res: Response, next: NextFunction) => {
      const circuitBreaker = this.resilienceConfig.getCircuitBreaker(serviceName);
      
      try {
        const result = await circuitBreaker.execute(async () => {
          return await this.processRequest(req);
        });
        
        res.json(result);
      } catch (error) {
        if (error.message.includes('Circuit breaker is OPEN')) {
          // Try fallback
          try {
            const fallbackResult = await this.resilienceConfig.executeFallback(
              'static-response',
              { operation: serviceName, error }
            );
            res.status(503).json(fallbackResult);
          } catch (fallbackError) {
            res.status(503).json({
              error: 'Service temporarily unavailable',
              retryAfter: 30
            });
          }
        } else {
          next(error);
        }
      }
    };
  }
  
  private async processRequest(req: Request) {
    // Your route logic here
    return { success: true };
  }
}

// Usage
const resilienceMiddleware = new ResilienceMiddleware(resilienceConfig);

app.get('/api/data', resilienceMiddleware.circuitBreaker('data-service'));
app.get('/api/users', resilienceMiddleware.circuitBreaker('user-service'));
```

---

## Troubleshooting Guide

### Common Issues and Solutions

#### 1. Circuit Breaker Always Open

**Symptoms:**
- All requests fail with "Circuit breaker is OPEN"
- Service appears healthy but requests are blocked
- High number of rejected requests

**Diagnosis:**
```typescript
// Check circuit breaker state and metrics
const breaker = getCircuitBreaker('my-service');
const metrics = breaker.getMetrics();

console.log({
  state: metrics.state,
  totalRequests: metrics.totalRequests,
  totalFailures: metrics.totalFailures,
  failureRate: metrics.failureRate,
  lastFailureTime: metrics.lastFailureTime
});

// Check recent events
const recentEvents = getCircuitBreakerEvents('my-service', Date.now() - 60000);
console.log('Recent events:', recentEvents);
```

**Solutions:**
```typescript
// Solution 1: Increase failure threshold
const updatedBreaker = new CircuitBreaker(operation, {
  failureThreshold: 10,        // Increase from default 5
  successThreshold: 2,         // Decrease from default 3
  resetTimeout: 60000          // Increase timeout
});

// Solution 2: Exclude transient errors
const tolerantBreaker = new CircuitBreaker(operation, {
  excludeErrors: [
    ValidationError,
    AuthenticationError,
    AuthorizationError
  ],
  retryCondition: (error) => {
    // Only count severe failures
    return error.status >= 500 || error.code === 'ECONNREFUSED';
  }
});

// Solution 3: Manual reset
breaker.forceState('CLOSED');  // Manual override (use sparingly)

// Solution 4: Adjust monitoring period
const adjustedBreaker = new CircuitBreaker(operation, {
  monitoringPeriod: 30000,     // Longer window for calculation
  volumeThreshold: 10          // Higher minimum volume
});
```

#### 2. Excessive Retry Attempts

**Symptoms:**
- Slow response times
- High resource usage
- Cascading failures
- Service overload

**Diagnosis:**
```typescript
// Check retry metrics
const metrics = retryPolicy.getMetrics();
console.log({
  totalAttempts: metrics.totalAttempts,
  averageAttempts: metrics.averageAttempts,
  maxAttempts: metrics.maxAttempts,
  averageDelay: metrics.averageDelay,
  totalRetryTime: metrics.totalRetryTime
});

// Check for retry storms
const recentRetries = getRetryEvents(Date.now() - 60000);
const uniqueOperations = new Set(recentRetries.map(r => r.operation));
console.log('Operations with retries:', uniqueOperations.size);
console.log('Total retries in last minute:', recentRetries.length);
```

**Solutions:**
```typescript
// Solution 1: Reduce retry attempts
const conservativeRetry = {
  maxAttempts: 2,              // Reduce from 3 or 5
  maxRetryTime: 10000,         // Cap total retry time
  baseDelay: 2000,             // Increase base delay
  exponentialBackoff: true,
  jitterEnabled: true
};

// Solution 2: Implement circuit breaker protection
const protectedRetry = retry(conservativeRetry, circuitBreaker);

// Solution 3: Context-aware retry
const smartRetry = {
  retryCondition: (error, attempt) => {
    // Don't retry if we're already taking too long
    if (attempt >= 3) return false;
    
    // Don't retry on client errors (except rate limiting)
    if (error.status >= 400 && error.status < 500 && error.status !== 429) {
      return false;
    }
    
    // Only retry severe server errors
    return error.status >= 500 || error.code === 'ECONNRESET';
  }
};

// Solution 4: Add timeout to retry logic
const timeBoundedRetry = {
  maxAttempts: 5,
  totalTimeout: 30000,         // Cap total time spent retrying
  abortOnTimeout: true
};
```

#### 3. Fallbacks Not Triggering

**Symptoms:**
- No fallback responses despite failures
- All requests fail completely
- Application shows 500 errors instead of graceful degradation

**Diagnosis:**
```typescript
// Check fallback configuration
const config = degradationSystem.getConfig();
console.log('Configured fallbacks:', Object.keys(config.fallback.strategies));

// Check if fallbacks are enabled
const isEnabled = degradationSystem.isFallbackEnabled('api-service');
console.log('Fallback enabled:', isEnabled);

// Check fallback execution logs
const fallbackLogs = getFallbackExecutionLogs();
console.log('Recent fallback attempts:', fallbackLogs);

// Check circuit breaker state
const circuitState = circuitBreaker.getState();
console.log('Circuit breaker state:', circuitState);
```

**Solutions:**
```typescript
// Solution 1: Ensure fallback configuration
degradationSystem.updateServiceConfig('api-service', {
  fallbackEnabled: true,
  fallbackStrategies: [
    { strategy: FallbackStrategy.CACHE_FIRST },
    { strategy: FallbackStrategy.STATIC_RESPONSE }
  ]
});

// Solution 2: Fix fallback order
degradationSystem.updateFallbackConfig({
  fallbackOrder: [
    'cached-response',
    'static-response'
  ],
  strategies: {
    'cached-response': {
      priority: 1,
      config: {
        maxAge: 300000,
        staleWhileRevalidate: true
      }
    },
    'static-response': {
      priority: 2,
      config: {
        staticData: {
          status: 'unavailable',
          message: 'Service temporarily unavailable'
        }
      }
    }
  }
});

// Solution 3: Test fallback manually
const testFallback = await degradationSystem.executeFallback(
  'static-response',
  { operation: 'test', error: new Error('Test error') }
);
console.log('Test fallback result:', testFallback);

// Solution 4: Fix circuit breaker integration
const integratedBreaker = new CircuitBreaker(operation, {
  onFallback: (error, operation) => {
    // Ensure fallback is called when circuit is open
    return degradationSystem.executeFallback('circuit-breaker-fallback', {
      originalOperation: operation,
      error
    });
  }
});
```

#### 4. High Error Rate Despite Resilience Measures

**Symptoms:**
- Error rates remain high (>10%)
- Circuit breakers opening frequently
- Fallbacks being used continuously
- User complaints about poor performance

**Diagnosis:**
```typescript
// Comprehensive error analysis
const errorAnalysis = await errorCorrelationAnalyzer.analyzeError(error);

console.log('Error correlations:', errorAnalysis.correlations);
console.log('Root cause confidence:', errorAnalysis.rootCause?.confidence);
console.log('Anomalies detected:', errorAnalysis.anomalies.length);

// Check for systemic issues
const systemHealth = degradationSystem.getSystemHealth();
console.log('System status:', systemHealth.overall);
console.log('Critical services:', systemHealth.services.filter(s => s.priority <= 2));

// Check dependencies
const dependencyHealth = await checkAllDependencies();
console.log('External dependencies:', dependencyHealth.external);
console.log('Internal dependencies:', dependencyHealth.internal);
```

**Solutions:**
```typescript
// Solution 1: Fix root cause instead of symptoms
if (errorAnalysis.rootCause?.type === 'database_connection') {
  // Fix database connection pool
  await databaseConfiguration.updatePool({
    maxConnections: 100,
    minConnections: 20,
    connectionTimeout: 30000,
    idleTimeout: 300000
  });
}

// Solution 2: Scale critical services
if (systemHealth.services.some(s => s.load > 0.8)) {
  await autoScaling.scaleUp('api-service', 2);
}

// Solution 3: Update error thresholds
const newThresholds = {
  circuitBreaker: {
    failureThreshold: 10,      // More tolerant
    resetTimeout: 60000,       // Longer recovery time
    volumeThreshold: 20        // Higher volume required
  },
  retry: {
    maxAttempts: 2,            // Fewer retries
    maxRetryTime: 15000        // Shorter total time
  },
  fallback: {
    activationThreshold: 0.05  // Activate fallbacks earlier
  }
};

// Solution 4: Implement bulkhead pattern
const bulkhead = new BulkheadCircuitBreaker(5, 30000); // Max 5 concurrent

// Different circuit breakers for different operations
const readBreaker = new CircuitBreaker(readOperation, { failureThreshold: 5 });
const writeBreaker = new CircuitBreaker(writeOperation, { failureThreshold: 3 });
```

#### 5. Memory Leaks in Resilience Components

**Symptoms:**
- Gradually increasing memory usage
- Out of memory errors after extended runtime
- Slow garbage collection
- System performance degradation over time

**Diagnosis:**
```typescript
// Check memory usage over time
const memorySnapshot = process.memoryUsage();
console.log('Memory usage:', {
  rss: `${Math.round(memorySnapshot.rss / 1024 / 1024)}MB`,
  heapUsed: `${Math.round(memorySnapshot.heapUsed / 1024 / 1024)}MB`,
  heapTotal: `${Math.round(memorySnapshot.heapTotal / 1024 / 1024)}MB`,
  external: `${Math.round(memorySnapshot.external / 1024 / 1024)}MB`
});

// Check circuit breaker registry size
const registrySize = getGlobalRegistry().getStats();
console.log('Registry size:', registrySize);

// Check cache sizes
const cacheStats = getAllCacheStats();
console.log('Cache sizes:', cacheStats);
```

**Solutions:**
```typescript
// Solution 1: Configure cleanup intervals
const breaker = new CircuitBreaker(operation, {
  maxInactiveTime: 3600000,     // Remove inactive breakers after 1 hour
  cleanupInterval: 300000,      // Cleanup every 5 minutes
  maxCacheSize: 1000            // Limit cache size
});

// Solution 2: Use bounded collections
const boundedMetrics = new CircularBuffer(10000); // Keep only last 10k entries

// Solution 3: Configure TTL for cached data
const fallbackHandler = new FallbackHandler({
  cacheConfig: {
    defaultTTL: 300000,         // 5 minutes
    maxSize: 1000,             // Maximum 1000 entries
    cleanupInterval: 60000      // Cleanup every minute
  }
});

// Solution 4: Enable automatic garbage collection hints
if (global.gc) {
  setInterval(() => {
    global.gc();
  }, 60000); // Force GC every minute (use with --expose-gc flag)
}
```

### Debug Commands and Tools

#### Circuit Breaker Debugging
```typescript
// Enable debug logging
process.env.LOG_LEVEL = 'debug';

// Capture circuit breaker snapshot
const snapshot = captureCircuitBreakerSnapshot();
console.log(JSON.stringify(snapshot, null, 2));

// Force state changes for testing
breaker.forceState('HALF_OPEN');
breaker.forceState('OPEN');
breaker.forceState('CLOSED');

// Get detailed circuit breaker info
const detailedInfo = {
  state: breaker.getState(),
  metrics: breaker.getMetrics(),
  configuration: breaker.getConfig(),
  events: breaker.getEventLog(),
  health: breaker.getHealth()
};
console.log(JSON.stringify(detailedInfo, null, 2));
```

#### Retry Logic Debugging
```typescript
// Enable detailed retry logging
const debugRetry = retry({
  maxAttempts: 5,
  onRetry: (error, attempt, delay) => {
    console.log(`Retry attempt ${attempt}:`, {
      error: error.message,
      delay,
      timestamp: new Date(),
      stack: error.stack
    });
  },
  onExhausted: (error, attempts) => {
    console.log('All retries exhausted:', {
      finalError: error.message,
      attempts,
      totalDelay: attempts.reduce((sum, a) => sum + a.delay, 0)
    });
  }
});

// Trace retry execution
const tracedRetry = AsyncRetryUtils.retryWithProgress(
  operation,
  (attempt, maxAttempts, delay, error) => {
    console.log(`[${new Date().toISOString()}] Retry ${attempt}/${maxAttempts}`, {
      delay,
      error: error?.message,
      nextDelay: delay * 2
    });
  },
  { maxAttempts: 5 }
);
```

#### Graceful Degradation Debugging
```typescript
// Enable comprehensive logging
degradationSystem.updateConfig({
  logging: {
    level: 'debug',
    enableTracing: true,
    logOperations: true,
    logFallbacks: true,
    logHealthChecks: true
  }
});

// Capture system snapshot
const snapshot = degradationSystem.captureSystemSnapshot();
console.log('System snapshot:', JSON.stringify(snapshot, null, 2));

// Monitor real-time events
degradationSystem.on('*', (event, data) => {
  console.log(`[${new Date().toISOString()}] Event: ${event}`, data);
});

// Test all fallback strategies
const testResults = await degradationSystem.testAllFallbacks();
console.log('Fallback test results:', testResults);
```

#### Performance Analysis
```typescript
// Profile resilience operations
const profiler = new ResilienceProfiler();

profiler.startProfiling('api-call');
const result = await resilientOperation();
profiler.endProfiling('api-call');

const profile = profiler.getProfile('api-call');
console.log('Operation profile:', {
  averageDuration: profile.averageDuration,
  p95Duration: profile.p95Duration,
  successRate: profile.successRate,
  circuitBreakerOverhead: profile.circuitBreakerOverhead,
  retryOverhead: profile.retryOverhead,
  fallbackFrequency: profile.fallbackFrequency
});

// Memory analysis
const memoryAnalyzer = new ResilienceMemoryAnalyzer();
const memoryReport = memoryAnalyzer.generateReport();
console.log('Memory analysis:', {
  totalMemoryUsed: memoryReport.totalMemoryUsed,
  componentMemoryUsage: memoryReport.componentMemoryUsage,
  leaksDetected: memoryReport.leaksDetected,
  recommendations: memoryReport.recommendations
});
```

### Recovery from Complete System Failure

When the entire resilience system fails, follow these steps:

#### 1. Emergency Shutdown
```typescript
// Gracefully shutdown all resilience components
await degradationSystem.shutdown();
await recoveryOrchestrator.shutdown();
await notificationSystem.shutdown();

// Disable all circuit breakers
const registry = getGlobalRegistry();
registry.forceAllStates('CLOSED');

// Disable all retries
AsyncRetryUtils.disableGlobalRetry();
```

#### 2. Emergency Mode
```typescript
// Enable emergency mode with simplified fallbacks
const emergencyConfig = {
  fallbackEnabled: true,
  emergencyFallback: true,
  circuitBreakerEnabled: false,  // Disable circuit breakers temporarily
  retryEnabled: false,           // Disable retries temporarily
  staticFallback: {
    enabled: true,
    response: {
      status: 'degraded',
      message: 'System operating in emergency mode'
    }
  }
};

degradationSystem.enableEmergencyMode(emergencyConfig);
```

#### 3. Gradual Recovery
```typescript
// Step 1: Re-enable circuit breakers with high thresholds
circuitBreaker.updateConfig({
  failureThreshold: 20,         // Very high threshold
  resetTimeout: 300000          // 5 minute timeout
});

// Step 2: Re-enable conservative retries
AsyncRetryUtils.updateGlobalConfig({
  maxAttempts: 1,               // No retries initially
  enabled: true
});

// Step 3: Monitor for stability
const stabilityMonitor = setInterval(() => {
  const health = degradationSystem.getSystemHealth();
  const errorRate = health.metrics.errorRate;
  
  if (errorRate < 0.01) { // Less than 1% error rate
    // Gradually restore normal configuration
    circuitBreaker.updateConfig({
      failureThreshold: 5,
      resetTimeout: 30000
    });
    
    AsyncRetryUtils.updateGlobalConfig({
      maxAttempts: 3,
      enabled: true
    });
    
    clearInterval(stabilityMonitor);
    console.log('Resilience system fully restored');
  }
}, 60000); // Check every minute
```

#### 4. Post-Incident Analysis
```typescript
// Generate post-incident report
const postIncidentReport = await generatePostIncidentReport({
  incidentStartTime: incidentStart,
  incidentEndTime: incidentEnd,
  affectedServices: affectedServices,
  recoveryActions: recoveryActions,
  rootCause: rootCause,
  preventionMeasures: preventionMeasures
});

console.log('Post-incident report:', postIncidentReport);

// Update configurations based on lessons learned
await updateResilienceConfigurations(postIncidentReport.lessonsLearned);
```

---

## Conclusion

This comprehensive documentation covers all aspects of implementing robust error recovery and circuit breaker patterns in your application. The key to successful resilience engineering is:

1. **Start Simple**: Begin with basic circuit breakers and conservative retry policies
2. **Monitor Everything**: Collect metrics and monitor system behavior continuously
3. **Test Regularly**: Run chaos experiments and recovery drills frequently
4. **Learn from Failures**: Analyze incidents and improve configurations
5. **Gradual Rollout**: Deploy resilience features gradually with proper testing

Remember that resilience is not a one-time implementation but an ongoing process of improvement and adaptation to changing system requirements and failure patterns.

For additional support or specific implementation questions, refer to the inline code documentation or consult the individual component documentation in the respective module directories.
