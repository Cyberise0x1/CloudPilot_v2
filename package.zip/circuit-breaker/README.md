# Circuit Breaker Pattern Implementation

A comprehensive circuit breaker pattern implementation for Node.js applications with state management, health monitoring, Express middleware, AWS service integration, and a real-time monitoring dashboard.

## Features

- 🔌 **Core Circuit Breaker**: Three-state circuit breaker (CLOSED, OPEN, HALF-OPEN)
- 📊 **Health Monitoring**: Comprehensive metrics and health status tracking
- 🚀 **Express Middleware**: Easy integration with Express routes
- ☁️ **AWS Integration**: Circuit breaker protection for AWS SDK operations
- 📈 **Real-time Dashboard**: Web-based monitoring interface with WebSocket support
- 🔧 **Flexible Configuration**: Customizable failure thresholds, timeouts, and recovery detection
- 📝 **Event System**: Event-driven monitoring and logging
- 🏗️ **Bulkhead Pattern**: Concurrent operation limiting
- 🔄 **Retry Logic**: Built-in retry mechanisms with circuit breaker protection
- 💾 **Caching Support**: Circuit breaker with caching capabilities
- 🌐 **Rate Limiting**: Circuit breaker with rate limiting
- ⚡ **Streaming Support**: Circuit breaker for async iterables

## Installation

```bash
npm install @circuit-breaker/core
# or
yarn add @circuit-breaker/core
# or
pnpm add @circuit-breaker/core
```

## Quick Start

### Basic Usage

```typescript
import { CircuitBreaker, CircuitBreakerConfig, CircuitBreakerOptions } from '@circuit-breaker/core';

const riskyOperation = async () => {
  // Simulate a flaky service
  if (Math.random() > 0.7) {
    throw new Error('Service temporarily unavailable');
  }
  return { data: 'Success!', timestamp: new Date() };
};

const config: CircuitBreakerConfig = {
  failureThreshold: 3,
  resetTimeout: 5000,
  monitoringPeriod: 10000,
  volumeThreshold: 5,
  timeout: 30000
};

const options: CircuitBreakerOptions = {
  name: 'example-service',
  service: 'example-api'
};

const breaker = new CircuitBreaker(riskyOperation, config, options);

try {
  const result = await breaker.execute();
  console.log('Result:', result);
} catch (error) {
  console.error('Operation failed:', error);
}

// Monitor the circuit breaker
console.log('State:', breaker.getState());
console.log('Metrics:', breaker.getMetrics());
```

### Using Utility Functions

```typescript
import { 
  createSimpleCircuitBreaker,
  createHttpCircuitBreaker,
  createDatabaseCircuitBreaker
} from '@circuit-breaker/core';

// Simple circuit breaker
const simpleBreaker = createSimpleCircuitBreaker(
  async () => await fetch('https://api.example.com/data'),
  'api-service'
);

// HTTP client circuit breaker
const httpClient = createHttpCircuitBreaker('https://api.example.com');
const response = await httpClient.get('/users');

// Database circuit breaker
const dbOperation = createDatabaseCircuitBreaker(
  async () => await database.query('SELECT * FROM users'),
  'user-service'
);
```

## Circuit Breaker States

### CLOSED
- Normal operation state
- All requests pass through to the underlying service
- Monitors failure rate and opens the circuit if threshold is exceeded

### OPEN
- Circuit breaker is "tripped"
- All requests are immediately rejected with an error
- Prevents load from reaching an unhealthy service
- Automatically transitions to HALF_OPEN after reset timeout

### HALF_OPEN
- Testing state to check if the service has recovered
- Allows a limited number of requests to test the service
- Returns to OPEN if failures occur, or CLOSED if successful

## Configuration Options

```typescript
interface CircuitBreakerConfig {
  /** Number of failures to trigger the circuit breaker */
  failureThreshold: number;
  /** Time in milliseconds to wait before attempting to reset */
  resetTimeout: number;
  /** Time in milliseconds to wait before transitioning from half-open to open on failure */
  monitoringPeriod: number;
  /** Minimum number of requests to consider before changing state */
  volumeThreshold: number;
  /** Custom timeout for requests (ms) */
  timeout?: number;
  /** Error types that should be counted as failures */
  errorTypes?: Array<new (...args: any[]) => Error>;
  /** Success rate threshold percentage for half-open state */
  successThreshold?: number;
  /** Health check function to determine service health */
  healthCheck?: () => Promise<boolean>;
  /** Event handlers for state changes */
  onStateChange?: (from: CircuitBreakerState, to: CircuitBreakerState) => void;
  /** Event handler for successful requests */
  onSuccess?: (latency: number) => void;
  /** Event handler for failed requests */
  onFailure?: (error: Error, latency: number) => void;
  /** Event handler for circuit trips */
  onCircuitTripped?: (error: Error) => void;
}
```

## Express Middleware Integration

### Route Protection

```typescript
import express from 'express';
import { 
  createCircuitBreakerMiddleware,
  CircuitBreakerMiddleware 
} from '@circuit-breaker/core';

const app = express();

// Method 1: Using createCircuitBreakerMiddleware
const protectedHandler = createCircuitBreakerMiddleware(
  async (req, res, next) => {
    const userData = await fetchUserData(req.params.id);
    res.json(userData);
  },
  {
    name: 'user-service',
    config: {
      failureThreshold: 3,
      resetTimeout: 30000
    },
    onFailure: (req, res, error, result) => {
      res.status(503).json({
        error: 'Service temporarily unavailable',
        message: 'Please try again later'
      });
    }
  }
);

app.get('/api/users/:id', protectedHandler);

// Method 2: Using CircuitBreakerMiddleware factory
const cbMiddleware = new CircuitBreakerMiddleware();

app.get('/api/data', cbMiddleware.protectRoute('/api/data', async (req, res) => {
  return await fetchExternalAPI();
}, {
  name: 'external-api',
  config: templates.unreliable
}));
```

### Protected Router

```typescript
import { createProtectedRouter } from '@circuit-breaker/core';

const router = createProtectedRouter('/api/v1');

// All routes are automatically protected
router.get('/users', async (req, res) => {
  const users = await queryUsers();
  res.json(users);
});

router.post('/users', async (req, res) => {
  const user = await createUser(req.body);
  res.json(user);
});
```

## AWS Service Integration

### Protecting AWS SDK Operations

```typescript
import { 
  AWSServiceCircuitBreakerFactory,
  AWS_SERVICE_CONFIGS 
} from '@circuit-breaker/core';
import { S3Client, DynamoDBClient } from '@aws-sdk/client-*';

// Your AWS clients
const s3Client = new S3Client({ region: 'us-east-1' });
const dynamoDBClient = new DynamoDBClient({ region: 'us-east-1' });

// Create factory and protect services
const factory = new AWSServiceCircuitBreakerFactory();

const serviceConfigs = [
  {
    service: 's3',
    config: {
      ...AWS_SERVICE_CONFIGS.s3,
      onError: (error: Error, operation: string) => {
        console.error(`S3 operation ${operation} failed:`, error.message);
      }
    },
    operations: ['getObject', 'putObject', 'deleteObject']
  },
  {
    service: 'dynamodb',
    config: AWS_SERVICE_CONFIGS.dynamodb,
    operations: ['getItem', 'putItem', 'query', 'scan']
  }
];

const protectedServices = factory.create(serviceConfigs, {
  s3: s3Client,
  dynamodb: dynamoDBClient
});

// All operations are now protected with circuit breakers
const protectedS3 = protectedServices.s3;
const protectedDynamoDB = protectedServices.dynamodb;
```

### Simple AWS Client Protection

```typescript
import { createProtectedAWSClient } from '@circuit-breaker/core';

const s3Client = new S3Client({ region: 'us-east-1' });
const protectedS3 = createProtectedAWSClient('s3', s3Client, {
  config: {
    failureThreshold: 3,
    resetTimeout: 30000
  },
  operations: ['getObject', 'putObject']
});
```

## Monitoring Dashboard

### Start Dashboard

```typescript
import { startDashboard } from '@circuit-breaker/core';

const dashboard = await startDashboard({
  port: 3001,
  host: 'localhost',
  updateInterval: 5000,
  enableWebSocket: true,
  auth: {
    enabled: true,
    username: 'admin',
    password: 'password123'
  }
});

console.log('Dashboard available at http://localhost:3001');
```

### Dashboard Features

- **Real-time Monitoring**: Live circuit breaker state updates via WebSocket
- **Metrics Visualization**: Success rates, failure counts, latency metrics
- **Health Status**: Overall health assessment for all circuit breakers
- **Interactive Controls**: Reset circuit breakers, force state changes
- **Filtering**: Filter circuit breakers by state (Closed, Open, Half-Open)
- **Authentication**: Optional basic authentication for dashboard access

## Utility Functions

### Retry with Circuit Breaker

```typescript
import { executeWithRetry } from '@circuit-breaker/core';

const result = await executeWithRetry(
  async () => await fetch('https://api.example.com/data'),
  3, // Max retries
  1000, // Retry delay
  { failureThreshold: 5, timeout: 10000 } // Circuit breaker config
);
```

### Parallel Operations

```typescript
import { executeParallel } from '@circuit-breaker/core';

const operations = [
  async () => await fetch('https://api1.example.com/data'),
  async () => await fetch('https://api2.example.com/data'),
  async () => await fetch('https://api3.example.com/data')
];

const results = await executeParallel(operations, {
  failureThreshold: 3,
  timeout: 10000
});
```

### Bulkhead Pattern

```typescript
import { BulkheadCircuitBreaker } from '@circuit-breaker/core';

const bulkhead = new BulkheadCircuitBreaker(5, 30000); // Max 5 concurrent, 30s timeout

const results = await Promise.allSettled([
  bulkhead.execute(() => processItem(1)),
  bulkhead.execute(() => processItem(2)),
  bulkhead.execute(() => processItem(3)),
  // ... more operations
]);

console.log('Bulkhead stats:', bulkhead.getStats());
```

### Rate Limited Circuit Breaker

```typescript
import { createRateLimitedCircuitBreaker } from '@circuit-breaker/core';

const limitedApi = createRateLimitedCircuitBreaker(
  async () => await fetch('https://api.example.com/data'),
  5, // Max 5 calls
  60000, // Per minute
  'limited-api'
);
```

## Pre-configured Templates

```typescript
import { templates } from '@circuit-breaker/core';

// Use pre-configured templates
const breaker = createSimpleCircuitBreaker(
  operation,
  'fast-service',
  templates.fast // or templates.slow, templates.unreliable, templates.critical
);
```

### Template Configurations

- **fast**: For high-performance services (short timeout, high failure threshold)
- **slow**: For slower legacy systems (longer timeout, lower volume threshold)
- **unreliable**: For external services (longer reset timeout, sensitive to failures)
- **critical**: For critical services (very sensitive, short reset timeout)

## Metrics and Health Monitoring

### Get Circuit Breaker Metrics

```typescript
const metrics = breaker.getMetrics();
console.log({
  state: metrics.state,
  successRate: metrics.successRate,
  totalRequests: metrics.totalRequests,
  averageLatency: metrics.averageLatency,
  totalTrips: metrics.totalTrips
});
```

### Get Health Status

```typescript
const health = breaker.getHealth();
console.log({
  healthy: health.healthy,
  state: health.state,
  details: health.details
});
```

### Registry Statistics

```typescript
import { getGlobalRegistry } from '@circuit-breaker/core';

const registry = getGlobalRegistry();
const stats = registry.getStats();
console.log({
  totalBreakers: stats.totalBreakers,
  stateCounts: stats.stateCounts,
  overallSuccessRate: stats.overallSuccessRate
});
```

## Event System

### Subscribe to Circuit Breaker Events

```typescript
import { getGlobalRegistry } from '@circuit-breaker/core';

const registry = getGlobalRegistry();

registry.onEvent((event) => {
  console.log('Circuit breaker event:', {
    circuitName: event.circuitName,
    type: event.type,
    timestamp: event.timestamp,
    data: event.data
  });
});

// Or subscribe to individual circuit breaker events
const breaker = getCircuitBreaker('my-service');
breaker.onEvent((event) => {
  if (event.type === 'CIRCUIT_TRIPPED') {
    console.log('Circuit tripped:', event.data);
  }
});
```

## Advanced Patterns

### Custom Health Check

```typescript
const breaker = new CircuitBreaker(operation, {
  ...config,
  healthCheck: async () => {
    // Custom health check logic
    try {
      const response = await fetch('https://service-health.example.com/ping');
      return response.ok;
    } catch {
      return false;
    }
  }
});
```

### Circuit Breaker with Caching

```typescript
import { createCachedCircuitBreaker } from '@circuit-breaker/core';

const cachedApi = createCachedCircuitBreaker(
  async (userId: string) => {
    return await fetch(`https://api.example.com/users/${userId}`);
  },
  (userId: string) => `user-${userId}`, // Cache key function
  60000, // Cache duration
  { failureThreshold: 3, timeout: 10000 }
);
```

### Streaming Circuit Breaker

```typescript
import { createStreamingCircuitBreaker } from '@circuit-breaker/core';

const processStream = createStreamingCircuitBreaker(
  async (item: any) => {
    return await processItem(item);
  },
  { failureThreshold: 2, resetTimeout: 10000 }
);

// Use with async iterables
for await (const result of processStream(dataStream)) {
  console.log('Processed:', result);
}
```

## Error Handling

### Circuit Breaker Specific Errors

```typescript
try {
  const result = await breaker.execute();
} catch (error) {
  if (error.message.includes('Circuit breaker is OPEN')) {
    // Handle open circuit
    return res.status(503).json({
      error: 'Service temporarily unavailable'
    });
  } else if (error.message.includes('timed out')) {
    // Handle timeout
    return res.status(504).json({
      error: 'Request timed out'
    });
  }
  // Handle other errors
}
```

### Express Error Handler

```typescript
import { circuitBreakerErrorHandler } from '@circuit-breaker/core';

app.use(circuitBreakerErrorHandler());
```

## Testing Circuit Breakers

### Testing State Transitions

```typescript
import { CircuitBreakerState } from '@circuit-breaker/core';

describe('Circuit Breaker', () => {
  let breaker: CircuitBreaker;

  beforeEach(() => {
    breaker = createSimpleCircuitBreaker(
      async () => { throw new Error('Service failed'); },
      'test-service',
      { failureThreshold: 2, resetTimeout: 1000 }
    );
  });

  it('should open after reaching failure threshold', async () => {
    // Force failures
    await breaker.execute();
    await breaker.execute();
    
    expect(breaker.getState()).toBe(CircuitBreakerState.OPEN);
  });

  it('should allow manual state changes', () => {
    breaker.forceState(CircuitBreakerState.HALF_OPEN);
    expect(breaker.getState()).toBe(CircuitBreakerState.HALF_OPEN);
  });
});
```

## Performance Considerations

### Memory Usage
- Circuit breakers maintain minimal state in memory
- Automatic cleanup of inactive breakers prevents memory leaks
- Configurable maximum number of circuit breakers in registry

### Latency Impact
- Minimal overhead when circuit is CLOSED (~1-2ms)
- Faster failures when circuit is OPEN (immediate rejection)
- Half-open state allows quick recovery detection

### Monitoring Overhead
- Metrics collection is lightweight
- Dashboard updates are throttled to prevent excessive WebSocket traffic
- Event processing is asynchronous to avoid blocking operations

## Best Practices

1. **Choose Appropriate Timeouts**: Set timeouts based on your service's expected response times
2. **Monitor Circuit Breaker Health**: Use the dashboard to monitor circuit breaker states
3. **Handle Open Circuits Gracefully**: Provide meaningful error messages to clients
4. **Use Different Configurations**: Adjust failure thresholds based on service criticality
5. **Implement Health Checks**: Use custom health checks for complex service dependencies
6. **Log Circuit Breaker Events**: Monitor circuit breaker events for operational insights
7. **Test Circuit Breaker Behavior**: Ensure circuit breakers behave correctly in failure scenarios

## Examples

See the `examples.ts` file for comprehensive examples covering:
- Basic usage patterns
- Express middleware integration
- AWS service protection
- Utility function usage
- Full application integration
- Dashboard setup

## API Reference

For detailed API documentation, see the individual module files:
- `CircuitBreaker` - Core circuit breaker implementation
- `CircuitBreakerRegistry` - Circuit breaker management
- `CircuitBreakerMiddleware` - Express middleware
- `AWSServiceCircuitBreaker` - AWS integration
- `CircuitBreakerDashboard` - Monitoring dashboard
- Utility functions in `utils.ts`

## License

MIT License - see LICENSE file for details.

## Contributing

Contributions are welcome! Please read the contributing guidelines and submit pull requests for any improvements.