/**
 * Circuit Breaker Pattern Examples
 * Comprehensive examples showing how to use the circuit breaker pattern in various scenarios
 */

import express from 'express';
import { 
  CircuitBreaker,
  CircuitBreakerConfig,
  CircuitBreakerOptions,
  CircuitBreakerState 
} from './types';
import {
  createSimpleCircuitBreaker,
  createHttpCircuitBreaker,
  createDatabaseCircuitBreaker,
  createApiCircuitBreaker,
  executeWithRetry,
  executeParallel,
  BulkheadCircuitBreaker,
  createRateLimitedCircuitBreaker,
  withTimeout
} from './utils';
import {
  createCircuitBreakerMiddleware,
  CircuitBreakerMiddleware,
  createProtectedRouter
} from './express-middleware';
import {
  AWSServiceCircuitBreakerFactory,
  AWS_SERVICE_CONFIGS
} from './aws-integration';
import { startDashboard } from './dashboard';

// ============================================================================
// BASIC USAGE EXAMPLES
// ============================================================================

/**
 * Example 1: Basic Circuit Breaker Usage
 */
export async function basicUsageExample() {
  // Define an operation that might fail
  const riskyOperation = async () => {
    // Simulate a flaky API call
    if (Math.random() > 0.7) {
      throw new Error('Service temporarily unavailable');
    }
    return { data: 'Success!', timestamp: new Date() };
  };

  // Create a circuit breaker
  const config: CircuitBreakerConfig = {
    failureThreshold: 3,
    resetTimeout: 5000,
    monitoringPeriod: 10000,
    volumeThreshold: 5
  };

  const options: CircuitBreakerOptions = {
    name: 'example-service',
    service: 'example-api'
  };

  const breaker = new CircuitBreaker(riskyOperation, config, options);

  // Use the circuit breaker
  try {
    const result = await breaker.execute();
    console.log('Result:', result);
  } catch (error) {
    if (error instanceof Error && error.message.includes('Circuit breaker is OPEN')) {
      console.log('Circuit breaker is open - service is unavailable');
    } else {
      console.error('Operation failed:', error);
    }
  }

  // Monitor the circuit breaker
  console.log('Circuit breaker state:', breaker.getState());
  console.log('Metrics:', breaker.getMetrics());
}

// ============================================================================
// EXPRESS MIDDLEWARE EXAMPLES
// ============================================================================

/**
 * Example 2: Express Route Protection
 */
export function expressMiddlewareExample() {
  const app = express();
  
  // Create a circuit breaker middleware factory
  const cbMiddleware = new CircuitBreakerMiddleware();

  // Example route handler
  const userServiceHandler = async (req: express.Request, res: express.Response) => {
    // Simulate a database call
    const userId = req.params.id;
    
    // This could be a database operation, external API call, etc.
    return {
      id: userId,
      name: 'John Doe',
      email: 'john@example.com'
    };
  };

  // Protect the route with circuit breaker
  app.get('/api/users/:id', 
    cbMiddleware.protectRoute(
      '/api/users/:id',
      userServiceHandler,
      {
        name: 'user-service',
        onSuccess: (req, res, result) => {
          res.json(result.data);
        },
        onFailure: (req, res, error, result) => {
          res.status(503).json({
            error: 'User service temporarily unavailable',
            message: 'Please try again later'
          });
        }
      }
    )
  );

  // Example with createCircuitBreakerMiddleware
  const riskyHandler = createCircuitBreakerMiddleware(
    async (req, res, next) => {
      // Simulate external API call
      const response = await fetch('https://api.example.com/data');
      return response.json();
    },
    {
      name: 'external-api',
      config: {
        timeout: 10000,
        failureThreshold: 3,
        resetTimeout: 30000
      },
      onFailure: (req, res, error, result) => {
        res.status(502).json({
          error: 'External service error',
          details: error.message
        });
      }
    }
  );

  app.get('/api/external-data', riskyHandler);

  return app;
}

/**
 * Example 3: Protected Router
 */
export function protectedRouterExample() {
  const router = createProtectedRouter('/api/v1');

  // These routes are automatically protected
  router.get('/users', async (req, res) => {
    // Database query
    const users = await queryUsers();
    res.json(users);
  });

  router.post('/users', async (req, res) => {
    // User creation
    const user = await createUser(req.body);
    res.json(user);
  });

  router.put('/users/:id', async (req, res) => {
    // User update
    const user = await updateUser(req.params.id, req.body);
    res.json(user);
  });

  return router;
}

// ============================================================================
// AWS SERVICE INTEGRATION EXAMPLES
// ============================================================================

/**
 * Example 4: AWS Service Protection
 */
export async function awsServiceExample() {
  // AWS SDK clients (you would import these from AWS SDK)
  // import { S3Client, DynamoDBClient } from '@aws-sdk/client-*';
  
  const s3Client = {} as any; // Your S3 client
  const dynamoDBClient = {} as any; // Your DynamoDB client

  // Create circuit breaker factory
  const factory = new AWSServiceCircuitBreakerFactory();

  // Configure circuit breakers for AWS services
  const serviceConfigs = [
    {
      service: 's3',
      config: {
        ...AWS_SERVICE_CONFIGS.s3,
        onError: (error: Error, operation: string) => {
          console.error(`S3 operation ${operation} failed:`, error.message);
        }
      },
      operations: ['getObject', 'putObject', 'deleteObject']
    },
    {
      service: 'dynamodb',
      config: {
        ...AWS_SERVICE_CONFIGS.dynamodb,
        onError: (error: Error, operation: string) => {
          console.error(`DynamoDB operation ${operation} failed:`, error.message);
        }
      },
      operations: ['getItem', 'putItem', 'query']
    }
  ];

  const protectedServices = factory.create(serviceConfigs, {
    s3: s3Client,
    dynamodb: dynamoDBClient
  });

  // Use protected services
  const s3Service = protectedServices.s3;
  const dynamoService = protectedServices.dynamodb;

  // Now all operations are automatically protected
  return {
    s3: s3Service,
    dynamodb: dynamoService
  };
}

// ============================================================================
// UTILITY FUNCTION EXAMPLES
// ============================================================================

/**
 * Example 5: HTTP Client Circuit Breaker
 */
export async function httpClientExample() {
  // Create protected HTTP client
  const httpClient = createHttpCircuitBreaker('https://api.example.com');

  try {
    const response = await httpClient.get('/users');
    const users = await response.json();
    console.log('Users:', users);
  } catch (error) {
    console.error('HTTP request failed:', error);
  }

  try {
    const response = await httpClient.post('/users', {
      name: 'John Doe',
      email: 'john@example.com'
    });
    const newUser = await response.json();
    console.log('Created user:', newUser);
  } catch (error) {
    console.error('User creation failed:', error);
  }
}

/**
 * Example 6: Database Operation Protection
 */
export async function databaseExample() {
  // Simulated database operation
  const findUser = async (userId: string) => {
    // Simulate database query
    if (Math.random() > 0.8) {
      throw new Error('Database connection timeout');
    }
    return { id: userId, name: 'John Doe', email: 'john@example.com' };
  };

  const createUser = async (userData: any) => {
    // Simulate user creation
    if (Math.random() > 0.7) {
      throw new Error('Database constraint violation');
    }
    return { id: Date.now().toString(), ...userData };
  };

  // Create protected database operations
  const findUserBreaker = createDatabaseCircuitBreaker(findUser, 'users');
  const createUserBreaker = createDatabaseCircuitBreaker(createUser, 'users');

  // Use the protected operations
  try {
    const user = await findUserBreaker.execute('123');
    console.log('Found user:', user);
  } catch (error) {
    console.error('Failed to find user:', error);
  }
}

/**
 * Example 7: Retry with Circuit Breaker
 */
export async function retryExample() {
  const unstableOperation = async () => {
    if (Math.random() > 0.3) {
      throw new Error('Service temporarily unavailable');
    }
    return { success: true, data: 'Operation completed' };
  };

  try {
    const result = await executeWithRetry(unstableOperation, 3, 1000);
    console.log('Operation succeeded after retry:', result);
  } catch (error) {
    console.error('Operation failed after retries:', error);
  }
}

/**
 * Example 8: Parallel Operations with Circuit Breakers
 */
export async function parallelOperationsExample() {
  const operations = [
    async () => ({ service: 'service-a', data: 'A' }),
    async () => ({ service: 'service-b', data: 'B' }),
    async () => ({ service: 'service-c', data: 'C' }),
    async () => { throw new Error('Service C failed'); return { service: 'service-c', error: true }; },
    async () => ({ service: 'service-d', data: 'D' })
  ];

  const results = await executeParallel(operations, {
    failureThreshold: 2,
    resetTimeout: 5000,
    timeout: 3000
  });

  console.log('Parallel operation results:');
  results.forEach((result, index) => {
    if (result.success) {
      console.log(`Operation ${index}: Success -`, result.data);
    } else {
      console.log(`Operation ${index}: Failed -`, result.error?.message);
    }
  });
}

/**
 * Example 9: Rate Limited Circuit Breaker
 */
export async function rateLimitedExample() {
  const apiCall = async () => {
    console.log('API call executed');
    return { success: true };
  };

  const limitedBreaker = createRateLimitedCircuitBreaker(
    apiCall,
    3,  // Max 3 calls
    10000, // Per 10 seconds
    'rate-limited-api'
  );

  // Test rate limiting
  for (let i = 0; i < 5; i++) {
    try {
      const result = await limitedBreaker.execute();
      console.log(`Call ${i + 1}:`, result.success ? 'Success' : 'Failed');
    } catch (error) {
      console.log(`Call ${i + 1}: Rate limited -`, error.message);
    }
  }
}

/**
 * Example 10: Bulkhead Pattern
 */
export async function bulkheadExample() {
  const bulkhead = new BulkheadCircuitBreaker(3, 5000); // Max 3 concurrent operations

  const operation = async (id: number) => {
    console.log(`Operation ${id} started`);
    await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate work
    console.log(`Operation ${id} completed`);
    return { id, result: 'success' };
  };

  // Start 5 operations (only 3 will run concurrently)
  const promises = [
    bulkhead.execute(() => operation(1)),
    bulkhead.execute(() => operation(2)),
    bulkhead.execute(() => operation(3)),
    bulkhead.execute(() => operation(4)),
    bulkhead.execute(() => operation(5))
  ];

  // Wait for all operations
  const results = await Promise.allSettled(promises);
  console.log('All operations completed');
  console.log('Bulkhead stats:', bulkhead.getStats());
}

// ============================================================================
// MONITORING AND DASHBOARD EXAMPLES
// ============================================================================

/**
 * Example 11: Circuit Breaker Dashboard
 */
export async function dashboardExample() {
  const dashboard = await startDashboard({
    port: 3001,
    host: 'localhost',
    updateInterval: 5000,
    enableWebSocket: true,
    auth: {
      enabled: true,
      username: 'admin',
      password: 'password123'
    }
  });

  console.log('Dashboard available at http://localhost:3001');
  console.log('Login with username: admin, password: password123');

  // Keep the dashboard running (don't call dashboard.stop() immediately)
  return dashboard;
}

// ============================================================================
// INTEGRATED EXAMPLE: FULL APPLICATION
// ============================================================================

/**
 * Example 12: Full Application Integration
 */
export async function fullApplicationExample() {
  const app = express();
  
  // Create circuit breaker middleware
  const cbMiddleware = new CircuitBreakerMiddleware();

  // Protected user service
  const userService = async (req: express.Request, res: express.Response) => {
    const userId = req.params.id;
    
    // Simulate user data retrieval
    const userData = await getUserData(userId);
    res.json(userData);
  };

  // Protected external API call
  const externalApi = async (req: express.Request, res: express.Response) => {
    const data = await fetchExternalData();
    res.json(data);
  };

  // Protected bulk operation
  const bulkOperation = async (req: express.Request, res: express.Response) => {
    const userIds = req.body.userIds;
    
    // Process multiple users concurrently with circuit breakers
    const operations = userIds.map((id: string) => () => processUser(id));
    const results = await executeParallel(operations);
    
    res.json({
      processed: results.filter(r => r.success).length,
      failed: results.filter(r => !r.success).length,
      details: results
    });
  };

  // Apply circuit breaker protection
  app.get('/api/users/:id', cbMiddleware.protectRoute('/api/users', userService, {
    name: 'user-service',
    config: templates.fast
  }));

  app.get('/api/external', cbMiddleware.protectRoute('/api/external', externalApi, {
    name: 'external-api',
    config: templates.unreliable
  }));

  app.post('/api/bulk-process', cbMiddleware.protectRoute('/api/bulk-process', bulkOperation, {
    name: 'bulk-processor',
    config: templates.critical
  }));

  // Add circuit breaker error handler and logger
  app.use(cbMiddleware.circuitBreakerErrorHandler());
  app.use(cbMiddleware.circuitBreakerLogger());

  // Start the application
  const server = app.listen(3000, () => {
    console.log('Application running on port 3000');
    console.log('Circuit breaker dashboard available on port 3001');
  });

  return { app, server };
}

// ============================================================================
// HELPER FUNCTIONS FOR EXAMPLES
// ============================================================================

async function getUserData(userId: string) {
  // Simulate user data retrieval
  return { id: userId, name: 'John Doe', email: 'john@example.com' };
}

async function fetchExternalData() {
  // Simulate external API call
  return { data: 'External data', timestamp: new Date() };
}

async function processUser(userId: string) {
  // Simulate user processing
  return { userId, processed: true };
}

async function queryUsers() {
  // Simulate database query
  return [
    { id: '1', name: 'Alice', email: 'alice@example.com' },
    { id: '2', name: 'Bob', email: 'bob@example.com' }
  ];
}

async function createUser(userData: any) {
  // Simulate user creation
  return { id: Date.now().toString(), ...userData };
}

async function updateUser(userId: string, userData: any) {
  // Simulate user update
  return { id: userId, ...userData };
}

// Run examples if this file is executed directly
if (require.main === module) {
  console.log('Running Circuit Breaker Examples...\n');

  // Run basic examples
  basicUsageExample().catch(console.error);
  
  setTimeout(() => {
    console.log('\n=== Express Middleware Example ===');
    const app = expressMiddlewareExample();
    console.log('Express app created with circuit breaker protection');
  }, 1000);

  setTimeout(() => {
    console.log('\n=== HTTP Client Example ===');
    httpClientExample().catch(console.error);
  }, 2000);

  setTimeout(() => {
    console.log('\n=== Retry Example ===');
    retryExample().catch(console.error);
  }, 3000);

  setTimeout(() => {
    console.log('\n=== Parallel Operations Example ===');
    parallelOperationsExample().catch(console.error);
  }, 4000);

  setTimeout(() => {
    console.log('\n=== Rate Limited Example ===');
    rateLimitedExample().catch(console.error);
  }, 5000);

  setTimeout(() => {
    console.log('\n=== Bulkhead Example ===');
    bulkheadExample().catch(console.error);
  }, 6000);
}