#!/usr/bin/env node

/**
 * Circuit Breaker Pattern Demo
 * Comprehensive demonstration of circuit breaker functionality
 */

const express = require('express');
const http = require('http');

// Import the circuit breaker modules (in a real implementation, these would be compiled)
const { 
  CircuitBreaker,
  CircuitBreakerState,
  getGlobalRegistry,
  createSimpleCircuitBreaker,
  createCircuitBreakerMiddleware,
  CircuitBreakerMiddleware,
  templates
} = require('./dist/index.js');

// Mock external services for demonstration
class MockUserService {
  constructor() {
    this.requestCount = 0;
    this.shouldFail = false;
  }

  async getUser(id) {
    this.requestCount++;
    
    // Simulate failures based on request count
    if (this.shouldFail || this.requestCount % 4 === 0) {
      throw new Error('User service temporarily unavailable');
    }
    
    return {
      id,
      name: `User ${id}`,
      email: `user${id}@example.com`,
      createdAt: new Date().toISOString()
    };
  }

  async createUser(userData) {
    this.requestCount++;
    
    if (this.shouldFail || this.requestCount % 3 === 0) {
      throw new Error('Database connection timeout');
    }
    
    return {
      id: Math.random().toString(36).substr(2, 9),
      ...userData,
      createdAt: new Date().toISOString()
    };
  }

  setFailureMode(shouldFail) {
    this.shouldFail = shouldFail;
  }

  reset() {
    this.requestCount = 0;
    this.shouldFail = false;
  }
}

class MockPaymentService {
  constructor() {
    this.requestCount = 0;
    this.failureRate = 0.7; // 70% failure rate
  }

  async processPayment(amount, userId) {
    this.requestCount++;
    
    if (Math.random() < this.failureRate) {
      throw new Error('Payment gateway timeout');
    }
    
    return {
      transactionId: 'txn_' + Math.random().toString(36).substr(2, 9),
      amount,
      userId,
      status: 'completed',
      processedAt: new Date().toISOString()
    };
  }

  setFailureRate(rate) {
    this.failureRate = rate;
  }

  reset() {
    this.requestCount = 0;
  }
}

class MockNotificationService {
  constructor() {
    this.requestCount = 0;
    this.isDown = false;
  }

  async sendNotification(userId, message) {
    this.requestCount++;
    
    if (this.isDown) {
      throw new Error('Notification service is down');
    }
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, Math.random() * 1000));
    
    return {
      notificationId: 'notif_' + Math.random().toString(36).substr(2, 9),
      userId,
      message,
      sentAt: new Date().toISOString()
    };
  }

  setDown(isDown) {
    this.isDown = isDown;
  }

  reset() {
    this.requestCount = 0;
    this.isDown = false;
  }
}

// Initialize services
const userService = new MockUserService();
const paymentService = new MockPaymentService();
const notificationService = new MockNotificationService();

// Create circuit breakers
const userServiceBreaker = createSimpleCircuitBreaker(
  (id) => userService.getUser(id),
  'user-service',
  {
    ...templates.slow,
    onFailure: (error, latency) => {
      console.log(`🔥 User service failed: ${error.message} (${latency}ms)`);
    },
    onSuccess: (latency) => {
      console.log(`✅ User service success (${latency}ms)`);
    }
  }
);

const createUserBreaker = createSimpleCircuitBreaker(
  (userData) => userService.createUser(userData),
  'create-user-service',
  {
    ...templates.critical,
    onFailure: (error, latency) => {
      console.log(`💥 Create user failed: ${error.message} (${latency}ms)`);
    }
  }
);

const paymentBreaker = createSimpleCircuitBreaker(
  (amount, userId) => paymentService.processPayment(amount, userId),
  'payment-service',
  {
    ...templates.unreliable,
    onCircuitTripped: (error) => {
      console.log(`🚨 Payment circuit tripped: ${error.message}`);
    },
    onStateChange: (from, to) => {
      console.log(`🔄 Payment service state change: ${from} → ${to}`);
    }
  }
);

const notificationBreaker = createSimpleCircuitBreaker(
  (userId, message) => notificationService.sendNotification(userId, message),
  'notification-service',
  {
    ...templates.fast,
    onCircuitTripped: (error) => {
      console.log(`📢 Notification circuit tripped: ${error.message}`);
    }
  }
);

// Express application
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Add request logging
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] ${req.method} ${req.path}`);
  next();
});

// Circuit breaker middleware for specific routes
const cbMiddleware = new CircuitBreakerMiddleware();

// Routes
app.get('/', (req, res) => {
  res.json({
    message: 'Circuit Breaker Demo API',
    version: '1.0.0',
    endpoints: {
      'GET /health': 'Health check with circuit breaker status',
      'GET /users/:id': 'Get user with circuit breaker protection',
      'POST /users': 'Create user with circuit breaker protection',
      'POST /payment': 'Process payment with circuit breaker protection',
      'POST /notify': 'Send notification with circuit breaker protection',
      'GET /circuit-status': 'Get all circuit breaker status',
      'GET /circuit-metrics': 'Get detailed circuit breaker metrics',
      'POST /circuit/reset/:name': 'Reset specific circuit breaker',
      'POST /circuit/reset-all': 'Reset all circuit breakers',
      'POST /simulate/failure/:service': 'Simulate service failure',
      'POST /simulate/recovery/:service': 'Simulate service recovery'
    }
  });
});

app.get('/health', (req, res) => {
  const registry = getGlobalRegistry();
  const health = registry.getAllHealth();
  const stats = registry.getStats();
  
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    overall: {
      totalBreakers: stats.totalBreakers,
      openBreakers: stats.stateCounts.OPEN || 0,
      overallSuccessRate: Math.round(stats.overallSuccessRate * 100) / 100
    },
    circuitBreakers: health
  });
});

// Get user with circuit breaker protection
app.get('/users/:id', cbMiddleware.protectRoute('/users/:id', async (req, res) => {
  const { id } = req.params;
  console.log(`🔍 Getting user ${id}...`);
  
  const result = await userServiceBreaker.execute(id);
  return result.data;
}, {
  name: 'user-service-route',
  onSuccess: (req, res, result) => {
    res.json({
      ...result.data,
      circuitBreaker: {
        state: result.state,
        latency: result.latency
      }
    });
  },
  onFailure: (req, res, error, result) => {
    res.status(503).json({
      error: 'User service temporarily unavailable',
      message: 'The user service is experiencing issues. Please try again later.',
      circuitBreaker: {
        state: result.state,
        latency: result.latency
      }
    });
  }
}));

// Create user with circuit breaker protection
app.post('/users', cbMiddleware.protectRoute('/users', async (req, res) => {
  const userData = req.body;
  console.log(`👤 Creating user:`, userData);
  
  const result = await createUserBreaker.execute(userData);
  return result.data;
}, {
  name: 'create-user-route',
  onSuccess: (req, res, result) => {
    res.status(201).json({
      ...result.data,
      circuitBreaker: {
        state: result.state,
        latency: result.latency
      }
    });
  },
  onFailure: (req, res, error, result) => {
    res.status(503).json({
      error: 'User creation service unavailable',
      message: 'Unable to create user at this time. Please try again later.',
      circuitBreaker: {
        state: result.state,
        latency: result.latency
      }
    });
  }
}));

// Process payment with circuit breaker protection
app.post('/payment', cbMiddleware.protectRoute('/payment', async (req, res) => {
  const { amount, userId } = req.body;
  console.log(`💳 Processing payment: $${amount} for user ${userId}`);
  
  if (!amount || !userId) {
    throw new Error('Missing required payment information');
  }
  
  const result = await paymentBreaker.execute(amount, userId);
  return result.data;
}, {
  name: 'payment-route',
  onSuccess: (req, res, result) => {
    res.json({
      ...result.data,
      circuitBreaker: {
        state: result.state,
        latency: result.latency
      }
    });
  },
  onFailure: (req, res, error, result) => {
    res.status(503).json({
      error: 'Payment processing unavailable',
      message: 'Payment service is temporarily unavailable. Please try again later.',
      circuitBreaker: {
        state: result.state,
        latency: result.latency
      }
    });
  }
}));

// Send notification with circuit breaker protection
app.post('/notify', cbMiddleware.protectRoute('/notify', async (req, res) => {
  const { userId, message } = req.body;
  console.log(`📧 Sending notification to user ${userId}: ${message}`);
  
  if (!userId || !message) {
    throw new Error('Missing required notification information');
  }
  
  const result = await notificationBreaker.execute(userId, message);
  return result.data;
}, {
  name: 'notification-route',
  onSuccess: (req, res, result) => {
    res.json({
      ...result.data,
      circuitBreaker: {
        state: result.state,
        latency: result.latency
      }
    });
  },
  onFailure: (req, res, error, result) => {
    res.status(503).json({
      error: 'Notification service unavailable',
      message: 'Unable to send notification at this time.',
      circuitBreaker: {
        state: result.state,
        latency: result.latency
      }
    });
  }
}));

// Get circuit breaker status for all services
app.get('/circuit-status', (req, res) => {
  const registry = getGlobalRegistry();
  const metrics = registry.getAllMetrics();
  const health = registry.getAllHealth();
  
  res.json({
    timestamp: new Date().toISOString(),
    summary: {
      totalBreakers: Object.keys(metrics).length,
      stateBreakdown: {
        closed: Object.values(metrics).filter(m => m.state === 'CLOSED').length,
        open: Object.values(metrics).filter(m => m.state === 'OPEN').length,
        halfOpen: Object.values(metrics).filter(m => m.state === 'HALF_OPEN').length
      }
    },
    metrics,
    health
  });
});

// Get detailed circuit breaker metrics
app.get('/circuit-metrics', (req, res) => {
  const registry = getGlobalRegistry();
  const metrics = registry.getAllMetrics();
  
  const detailed = {};
  
  Object.entries(metrics).forEach(([name, metric]) => {
    detailed[name] = {
      ...metric,
      successRate: Math.round(metric.successRate * 100) / 100,
      uptime: Date.now() - metric.lastStateChange,
      isHealthy: metric.failureCount < metric.totalRequests * 0.1, // Less than 10% failure rate
      recommendations: []
    };
    
    // Add recommendations
    if (metric.state === 'OPEN') {
      detailed[name].recommendations.push('Service is experiencing issues - consider investigating');
    }
    if (metric.successRate < 80) {
      detailed[name].recommendations.push('Low success rate - consider adjusting timeout or failure threshold');
    }
    if (metric.averageLatency > 5000) {
      detailed[name].recommendations.push('High latency detected - consider scaling service');
    }
    if (metric.totalTrips > 5) {
      detailed[name].recommendations.push('Frequent circuit trips - service may need fixes or scaling');
    }
  });
  
  res.json({
    timestamp: new Date().toISOString(),
    detailed
  });
});

// Reset specific circuit breaker
app.post('/circuit/reset/:name', (req, res) => {
  const { name } = req.params;
  const registry = getGlobalRegistry();
  
  const success = registry.forceState(name, CircuitBreakerState.CLOSED);
  
  if (success) {
    console.log(`🔄 Manually reset circuit breaker: ${name}`);
    res.json({
      success: true,
      message: `Circuit breaker '${name}' has been reset to CLOSED state`
    });
  } else {
    res.status(404).json({
      success: false,
      message: `Circuit breaker '${name}' not found`
    });
  }
});

// Reset all circuit breakers
app.post('/circuit/reset-all', (req, res) => {
  const registry = getGlobalRegistry();
  registry.resetAll();
  
  console.log('🔄 Manually reset all circuit breakers');
  res.json({
    success: true,
    message: 'All circuit breakers have been reset to CLOSED state'
  });
});

// Simulation endpoints
app.post('/simulate/failure/:service', (req, res) => {
  const { service } = req.params;
  
  switch (service) {
    case 'user':
      userService.setFailureMode(true);
      console.log('⚠️  Simulating user service failure');
      break;
    case 'payment':
      paymentService.setFailureRate(1.0); // 100% failure rate
      console.log('⚠️  Simulating payment service failure');
      break;
    case 'notification':
      notificationService.setDown(true);
      console.log('⚠️  Simulating notification service failure');
      break;
    default:
      return res.status(400).json({
        error: 'Invalid service',
        available: ['user', 'payment', 'notification']
      });
  }
  
  res.json({
    success: true,
    message: `Simulated failure for ${service} service`
  });
});

app.post('/simulate/recovery/:service', (req, res) => {
  const { service } = req.params;
  
  switch (service) {
    case 'user':
      userService.setFailureMode(false);
      console.log('✅ User service recovered');
      break;
    case 'payment':
      paymentService.setFailureRate(0.3); // Back to normal 30% failure rate
      console.log('✅ Payment service recovered');
      break;
    case 'notification':
      notificationService.setDown(false);
      console.log('✅ Notification service recovered');
      break;
    default:
      return res.status(400).json({
        error: 'Invalid service',
        available: ['user', 'payment', 'notification']
      });
  }
  
  res.json({
    success: true,
    message: `${service} service has been marked as recovered`
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('❌ Error:', err.message);
  res.status(500).json({
    error: 'Internal server error',
    message: err.message,
    timestamp: new Date().toISOString()
  });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    error: 'Endpoint not found',
    path: req.originalUrl,
    method: req.method,
    timestamp: new Date().toISOString()
  });
});

// Performance monitoring
setInterval(() => {
  const registry = getGlobalRegistry();
  const stats = registry.getStats();
  
  console.log('📊 Circuit Breaker Statistics:');
  console.log(`   Total Breakers: ${stats.totalBreakers}`);
  console.log(`   State Distribution:`, stats.stateCounts);
  console.log(`   Overall Success Rate: ${stats.overallSuccessRate.toFixed(1)}%`);
  console.log(`   Total Requests: ${stats.totalRequests}`);
  console.log('---');
}, 30000); // Every 30 seconds

// Start server
const server = app.listen(PORT, () => {
  console.log('🚀 Circuit Breaker Demo Server Started');
  console.log('=====================================');
  console.log(`📍 Server running at http://localhost:${PORT}`);
  console.log('');
  console.log('🔍 Test the following endpoints:');
  console.log(`   • GET  http://localhost:${PORT}/ - API documentation`);
  console.log(`   • GET  http://localhost:${PORT}/health - Health check`);
  console.log(`   • GET  http://localhost:${PORT}/users/123 - Get user (protected)`);
  console.log(`   • POST http://localhost:${PORT}/users - Create user (protected)`);
  console.log(`   • POST http://localhost:${PORT}/payment - Process payment (protected)`);
  console.log(`   • POST http://localhost:${PORT}/notify - Send notification (protected)`);
  console.log(`   • GET  http://localhost:${PORT}/circuit-status - Circuit breaker status`);
  console.log(`   • GET  http://localhost:${PORT}/circuit-metrics - Detailed metrics`);
  console.log('');
  console.log('🧪 Test failure scenarios:');
  console.log(`   • POST http://localhost:${PORT}/simulate/failure/user - Simulate user service failure`);
  console.log(`   • POST http://localhost:${PORT}/simulate/failure/payment - Simulate payment failure`);
  console.log(`   • POST http://localhost:${PORT}/simulate/failure/notification - Simulate notification failure`);
  console.log('');
  console.log('🔄 Test recovery:');
  console.log(`   • POST http://localhost:${PORT}/simulate/recovery/user - Recover user service`);
  console.log(`   • POST http://localhost:${PORT}/circuit/reset/user-service - Reset user service circuit breaker`);
  console.log(`   • POST http://localhost:${PORT}/circuit/reset-all - Reset all circuit breakers`);
  console.log('');
  console.log('💡 Watch the console to see circuit breaker behavior!');
  console.log('=====================================');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('🛑 Received SIGTERM, shutting down gracefully...');
  server.close(() => {
    console.log('🔒 Server closed');
    
    const registry = getGlobalRegistry();
    registry.destroy();
    console.log('🧹 Circuit breaker registry cleaned up');
    
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('\n🛑 Received SIGINT, shutting down gracefully...');
  server.close(() => {
    console.log('🔒 Server closed');
    
    const registry = getGlobalRegistry();
    registry.destroy();
    console.log('🧹 Circuit breaker registry cleaned up');
    
    process.exit(0);
  });
});