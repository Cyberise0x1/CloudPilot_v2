/**
 * Circuit Breaker Tests
 * Comprehensive test suite for the circuit breaker pattern implementation
 */

import {
  CircuitBreaker,
  CircuitBreakerConfig,
  CircuitBreakerOptions,
  CircuitBreakerState,
  CircuitBreakerEvent
} from '../src/types';
import {
  createSimpleCircuitBreaker,
  executeWithRetry,
  executeParallel,
  BulkheadCircuitBreaker,
  createRateLimitedCircuitBreaker,
  withTimeout,
  generateCircuitBreakerConfig
} from '../src/utils';
import { getGlobalRegistry, CircuitBreakerRegistry } from '../src/registry';

describe('Circuit Breaker', () => {
  let breaker: CircuitBreaker;
  let successCount = 0;
  let failureCount = 0;

  const createOperation = (shouldFail: boolean = false) => async () => {
    if (shouldFail) {
      failureCount++;
      throw new Error('Service temporarily unavailable');
    }
    successCount++;
    return { data: 'Success', timestamp: Date.now() };
  };

  beforeEach(() => {
    successCount = 0;
    failureCount = 0;
    breaker = new CircuitBreaker(createOperation(false), {
      failureThreshold: 3,
      resetTimeout: 5000,
      monitoringPeriod: 10000,
      volumeThreshold: 5,
      timeout: 30000
    }, {
      name: 'test-circuit-breaker',
      service: 'test-service'
    });
  });

  afterEach(() => {
    breaker.destroy();
  });

  describe('Initial State', () => {
    it('should start in CLOSED state', () => {
      expect(breaker.getState()).toBe(CircuitBreakerState.CLOSED);
    });

    it('should have zero metrics initially', () => {
      const metrics = breaker.getMetrics();
      expect(metrics.state).toBe(CircuitBreakerState.CLOSED);
      expect(metrics.totalRequests).toBe(0);
      expect(metrics.successCount).toBe(0);
      expect(metrics.failureCount).toBe(0);
    });
  });

  describe('Successful Operations', () => {
    it('should execute operations successfully', async () => {
      const result = await breaker.execute();
      
      expect(result.success).toBe(true);
      expect(result.data).toEqual({ data: 'Success', timestamp: expect.any(Number) });
      expect(result.circuitOpen).toBe(false);
      expect(result.latency).toBeGreaterThan(0);
    });

    it('should increment success metrics', async () => {
      await breaker.execute();
      await breaker.execute();
      await breaker.execute();

      const metrics = breaker.getMetrics();
      expect(metrics.successCount).toBe(3);
      expect(metrics.totalRequests).toBe(3);
      expect(metrics.failureCount).toBe(0);
    });
  });

  describe('Failed Operations', () => {
    it('should handle failures correctly', async () => {
      const failingBreaker = new CircuitBreaker(
        createOperation(true),
        {
          failureThreshold: 2,
          resetTimeout: 5000,
          monitoringPeriod: 10000,
          volumeThreshold: 5,
          timeout: 30000
        },
        { name: 'failing-test', service: 'test' }
      );

      const result1 = await failingBreaker.execute();
      const result2 = await failingBreaker.execute();

      expect(result1.success).toBe(false);
      expect(result1.error).toBeInstanceOf(Error);
      expect(result2.success).toBe(false);

      const metrics = failingBreaker.getMetrics();
      expect(metrics.failureCount).toBe(2);
      expect(metrics.totalRequests).toBe(2);

      failingBreaker.destroy();
    });

    it('should trip circuit breaker after threshold', async () => {
      const failingBreaker = new CircuitBreaker(
        createOperation(true),
        {
          failureThreshold: 2,
          resetTimeout: 1000,
          monitoringPeriod: 10000,
          volumeThreshold: 2,
          timeout: 30000
        },
        { name: 'threshold-test', service: 'test' }
      );

      // First failure
      await failingBreaker.execute();
      expect(failingBreaker.getState()).toBe(CircuitBreakerState.CLOSED);

      // Second failure - should trip
      await failingBreaker.execute();
      expect(failingBreaker.getState()).toBe(CircuitBreakerState.OPEN);

      // Third attempt should be blocked
      const result = await failingBreaker.execute();
      expect(result.success).toBe(false);
      expect(result.circuitOpen).toBe(true);
      expect(result.error!.message).toContain('Circuit breaker is OPEN');

      failingBreaker.destroy();
    });
  });

  describe('State Transitions', () => {
    it('should transition from CLOSED to OPEN when threshold reached', async () => {
      const failingBreaker = new CircuitBreaker(
        createOperation(true),
        {
          failureThreshold: 2,
          resetTimeout: 1000,
          monitoringPeriod: 10000,
          volumeThreshold: 2,
          timeout: 30000
        },
        { name: 'transition-test', service: 'test' }
      );

      expect(failingBreaker.getState()).toBe(CircuitBreakerState.CLOSED);

      await failingBreaker.execute(); // First failure
      expect(failingBreaker.getState()).toBe(CircuitBreakerState.CLOSED);

      await failingBreaker.execute(); // Second failure
      expect(failingBreaker.getState()).toBe(CircuitBreakerState.OPEN);

      failingBreaker.destroy();
    });

    it('should transition from OPEN to HALF_OPEN after timeout', async () => {
      jest.useFakeTimers();

      const failingBreaker = new CircuitBreaker(
        createOperation(true),
        {
          failureThreshold: 1,
          resetTimeout: 5000,
          monitoringPeriod: 10000,
          volumeThreshold: 1,
          timeout: 30000
        },
        { name: 'timeout-test', service: 'test' }
      );

      // Trigger failure
      await failingBreaker.execute();
      expect(failingBreaker.getState()).toBe(CircuitBreakerState.OPEN);

      // Fast-forward time
      jest.advanceTimersByTime(5000);

      // Should transition to HALF_OPEN
      expect(failingBreaker.getState()).toBe(CircuitBreakerState.HALF_OPEN);

      jest.useRealTimers();
      failingBreaker.destroy();
    });

    it('should transition from HALF_OPEN to CLOSED on success', async () => {
      let attempt = 0;
      const conditionalOperation = async () => {
        attempt++;
        if (attempt <= 2) {
          throw new Error('Service failed');
        }
        return { data: 'Success after recovery' };
      };

      const conditionalBreaker = new CircuitBreaker(
        conditionalOperation,
        {
          failureThreshold: 2,
          resetTimeout: 1000,
          monitoringPeriod: 10000,
          volumeThreshold: 1,
          timeout: 30000,
          successThreshold: 2
        },
        { name: 'conditional-test', service: 'test' }
      );

      // First attempt - fails, trips circuit
      await conditionalBreaker.execute();
      expect(conditionalBreaker.getState()).toBe(CircuitBreakerState.OPEN);

      // Fast-forward to HALF_OPEN
      jest.useFakeTimers();
      jest.advanceTimersByTime(1000);
      expect(conditionalBreaker.getState()).toBe(CircuitBreakerState.HALF_OPEN);

      // Second attempt - fails, back to OPEN
      await conditionalBreaker.execute();
      expect(conditionalBreaker.getState()).toBe(CircuitBreakerState.OPEN);

      // Fast-forward again
      jest.advanceTimersByTime(1000);
      expect(conditionalBreaker.getState()).toBe(CircuitBreakerState.HALF_OPEN);

      // Third attempt - succeeds
      await conditionalBreaker.execute();
      expect(conditionalBreaker.getState()).toBe(CircuitBreakerState.CLOSED);

      jest.useRealTimers();
      conditionalBreaker.destroy();
    });
  });

  describe('Health Monitoring', () => {
    it('should provide accurate health status', async () => {
      const healthyBreaker = new CircuitBreaker(
        createOperation(false),
        {
          failureThreshold: 5,
          resetTimeout: 60000,
          monitoringPeriod: 10000,
          volumeThreshold: 10,
          timeout: 30000
        },
        { name: 'healthy-test', service: 'test' }
      );

      await healthyBreaker.execute();
      await healthyBreaker.execute();

      const health = healthyBreaker.getHealth();
      expect(health.healthy).toBe(true);
      expect(health.state).toBe(CircuitBreakerState.CLOSED);
      expect(health.metrics.successCount).toBe(2);
      expect(health.timestamp).toBeGreaterThan(0);

      healthyBreaker.destroy();
    });

    it('should detect unhealthy state', async () => {
      const failingBreaker = new CircuitBreaker(
        createOperation(true),
        {
          failureThreshold: 2,
          resetTimeout: 5000,
          monitoringPeriod: 10000,
          volumeThreshold: 2,
          timeout: 30000
        },
        { name: 'unhealthy-test', service: 'test' }
      );

      await failingBreaker.execute();
      await failingBreaker.execute();

      const health = failingBreaker.getHealth();
      expect(health.healthy).toBe(false);
      expect(health.state).toBe(CircuitBreakerState.OPEN);
      expect(health.details).toBeDefined();

      failingBreaker.destroy();
    });
  });

  describe('Event System', () => {
    it('should emit state change events', (done) => {
      const failingBreaker = new CircuitBreaker(
        createOperation(true),
        {
          failureThreshold: 1,
          resetTimeout: 1000,
          monitoringPeriod: 10000,
          volumeThreshold: 1,
          timeout: 30000
        },
        { name: 'event-test', service: 'test' }
      );

      failingBreaker.onEvent((event) => {
        if (event.type === 'STATE_CHANGE') {
          expect(event.data.from).toBe(CircuitBreakerState.CLOSED);
          expect(event.data.to).toBe(CircuitBreakerState.OPEN);
          expect(event.name).toBe('event-test');
          done();
        }
      });

      failingBreaker.execute().then(() => {
        failingBreaker.destroy();
      });
    });

    it('should emit success and failure events', (done) => {
      let eventCount = 0;
      const testBreaker = new CircuitBreaker(
        createOperation(false),
        {
          failureThreshold: 5,
          resetTimeout: 60000,
          monitoringPeriod: 10000,
          volumeThreshold: 10,
          timeout: 30000
        },
        { name: 'event-success-test', service: 'test' }
      );

      testBreaker.onEvent((event) => {
        eventCount++;
        if (event.type === 'SUCCESS' && eventCount >= 2) {
          done();
        }
      });

      testBreaker.execute().then(() => {
        testBreaker.execute().then(() => {
          testBreaker.destroy();
        });
      });
    });
  });

  describe('Manual State Control', () => {
    it('should allow manual state changes', () => {
      expect(breaker.getState()).toBe(CircuitBreakerState.CLOSED);

      breaker.forceState(CircuitBreakerState.OPEN);
      expect(breaker.getState()).toBe(CircuitBreakerState.OPEN);

      breaker.forceState(CircuitBreakerState.HALF_OPEN);
      expect(breaker.getState()).toBe(CircuitBreakerState.HALF_OPEN);

      breaker.forceState(CircuitBreakerState.CLOSED);
      expect(breaker.getState()).toBe(CircuitBreakerState.CLOSED);
    });

    it('should reset all counters when resetting to CLOSED', async () => {
      await breaker.execute();
      await breaker.execute();

      let metrics = breaker.getMetrics();
      expect(metrics.successCount).toBe(2);

      // Manually force to OPEN state
      breaker.forceState(CircuitBreakerState.OPEN);
      
      // Reset to CLOSED
      breaker.reset();

      metrics = breaker.getMetrics();
      expect(metrics.successCount).toBe(0);
      expect(metrics.totalRequests).toBe(0);
      expect(metrics.state).toBe(CircuitBreakerState.CLOSED);
    });
  });

  describe('Timeout Handling', () => {
    it('should handle operation timeouts', async () => {
      const slowOperation = async () => {
        await new Promise(resolve => setTimeout(resolve, 1000));
        return { data: 'Slow result' };
      };

      const timeoutBreaker = new CircuitBreaker(
        slowOperation,
        {
          failureThreshold: 1,
          resetTimeout: 5000,
          monitoringPeriod: 10000,
          volumeThreshold: 1,
          timeout: 100 // Very short timeout
        },
        { name: 'timeout-operation-test', service: 'test' }
      );

      const result = await timeoutBreaker.execute();
      expect(result.success).toBe(false);
      expect(result.error!.message).toContain('timed out');

      timeoutBreaker.destroy();
    });
  });

  describe('Utility Functions', () => {
    describe('createSimpleCircuitBreaker', () => {
      it('should create a working circuit breaker', async () => {
        const operation = async () => ({ message: 'Hello' });
        const simpleBreaker = createSimpleCircuitBreaker(operation, 'simple-test');

        const result = await simpleBreaker.execute();
        expect(result.success).toBe(true);
        expect(result.data).toEqual({ message: 'Hello' });

        simpleBreaker.destroy();
      });
    });

    describe('withTimeout', () => {
      it('should add timeout to operations', async () => {
        const slowOp = async () => {
          await new Promise(resolve => setTimeout(resolve, 500));
          return 'Done';
        };

        const timedOp = withTimeout(slowOp, 200);

        const result = await timedOp();
        expect(result.success).toBe(false);
        expect(result.error!.message).toContain('timed out');
      });

      it('should allow operations that complete within timeout', async () => {
        const fastOp = async () => 'Done';
        const timedOp = withTimeout(fastOp, 1000);

        const result = await timedOp();
        expect(result.success).toBe(true);
        expect(result.data).toBe('Done');
      });
    });

    describe('generateCircuitBreakerConfig', () => {
      it('should generate appropriate configs for different service types', () => {
        const fastConfig = generateCircuitBreakerConfig('fast');
        const slowConfig = generateCircuitBreakerConfig('slow');
        const unreliableConfig = generateCircuitBreakerConfig('unreliable');
        const criticalConfig = generateCircuitBreakerConfig('critical');

        expect(fastConfig.timeout).toBe(5000);
        expect(slowConfig.timeout).toBe(30000);
        expect(unreliableConfig.resetTimeout).toBe(120000);
        expect(criticalConfig.failureThreshold).toBe(2);
      });
    });
  });
});

describe('Circuit Breaker Registry', () => {
  let registry: CircuitBreakerRegistry;

  beforeEach(() => {
    registry = new CircuitBreakerRegistry({
      defaultConfig: {
        failureThreshold: 5,
        resetTimeout: 60000,
        monitoringPeriod: 10000,
        volumeThreshold: 10,
        timeout: 30000
      },
      enableAutoCleanup: false
    });
  });

  afterEach(() => {
    registry.destroy();
  });

  describe('Circuit Breaker Creation', () => {
    it('should create circuit breakers', () => {
      const operation = async () => 'test';
      const breaker = registry.create('test-breaker', operation);

      expect(breaker).toBeInstanceOf(CircuitBreaker);
      expect(registry.has('test-breaker')).toBe(true);
      expect(registry.get('test-breaker')).toBe(breaker);
    });

    it('should return existing circuit breaker if name exists', () => {
      const operation1 = async () => 'test1';
      const operation2 = async () => 'test2';
      
      const breaker1 = registry.create('existing-breaker', operation1);
      const breaker2 = registry.create('existing-breaker', operation2);

      expect(breaker1).toBe(breaker2);
    });
  });

  describe('Registry Operations', () => {
    it('should list all circuit breaker names', () => {
      registry.create('breaker1', async () => 'test1');
      registry.create('breaker2', async () => 'test2');
      registry.create('breaker3', async () => 'test3');

      const names = registry.getNames();
      expect(names).toContain('breaker1');
      expect(names).toContain('breaker2');
      expect(names).toContain('breaker3');
    });

    it('should get circuit breakers by state', () => {
      const breaker1 = registry.create('closed-breaker', async () => 'test1');
      const breaker2 = registry.create('open-breaker', async () => { throw new Error('fail'); });
      
      // Force second breaker to open
      breaker2.forceState(CircuitBreakerState.OPEN);

      const closedBreakers = registry.getByState(CircuitBreakerState.CLOSED);
      const openBreakers = registry.getByState(CircuitBreakerState.OPEN);

      expect(closedBreakers).toHaveLength(1);
      expect(closedBreakers[0].name).toBe('closed-breaker');
      expect(openBreakers).toHaveLength(1);
      expect(openBreakers[0].name).toBe('open-breaker');
    });

    it('should get unhealthy circuit breakers', () => {
      const healthyBreaker = registry.create('healthy', async () => 'test');
      const unhealthyBreaker = registry.create('unhealthy', async () => { throw new Error('fail'); });
      
      unhealthyBreaker.forceState(CircuitBreakerState.OPEN);

      const unhealthy = registry.getUnhealthy();
      expect(unhealthy).toHaveLength(1);
      expect(unhealthy[0].name).toBe('unhealthy');
    });

    it('should provide registry statistics', () => {
      registry.create('breaker1', async () => 'test1');
      registry.create('breaker2', async () => 'test2');
      
      const stats = registry.getStats();
      expect(stats.totalBreakers).toBe(2);
      expect(stats.stateCounts).toBeDefined();
      expect(stats.totalRequests).toBe(0);
    });
  });

  describe('Execute Through Registry', () => {
    it('should execute operations through registry', async () => {
      const operation = async (name: string) => `Hello, ${name}!`;
      
      const result = await registry.execute('greeting', operation, 'World');
      expect(result).toBe('Hello, World!');
    });
  });

  describe('Registry Events', () => {
    it('should emit registry events', (done) => {
      registry.onEvent((event) => {
        if (event.type === 'STATE_CHANGE' && event.circuitName === 'test') {
          done();
        }
      });

      const breaker = registry.create('test', async () => 'test');
      breaker.forceState(CircuitBreakerState.OPEN);
    });
  });
});

describe('Bulkhead Circuit Breaker', () => {
  let bulkhead: BulkheadCircuitBreaker;

  beforeEach(() => {
    bulkhead = new BulkheadCircuitBreaker(2, 5000);
  });

  it('should limit concurrent operations', async () => {
    let activeOperations = 0;
    const operation = async (id: number) => {
      activeOperations++;
      expect(activeOperations).toBeLessThanOrEqual(2);
      await new Promise(resolve => setTimeout(resolve, 100));
      activeOperations--;
      return { id, result: 'success' };
    };

    const promises = [
      bulkhead.execute(() => operation(1)),
      bulkhead.execute(() => operation(2)),
      bulkhead.execute(() => operation(3)), // This should wait
      bulkhead.execute(() => operation(4))  // This should wait
    ];

    const results = await Promise.allSettled(promises);
    expect(results).toHaveLength(4);
    
    const stats = bulkhead.getStats();
    expect(stats.maxConcurrent).toBe(2);
    expect(stats.queuedOperations).toBe(0); // Should be cleared after execution
  });
});

describe('Rate Limited Circuit Breaker', () => {
  it('should enforce rate limits', async () => {
    let callCount = 0;
    const operation = async () => {
      callCount++;
      return { call: callCount };
    };

    const limitedBreaker = createRateLimitedCircuitBreaker(
      operation,
      3, // Max 3 calls
      1000, // Per second
      'rate-limited'
    );

    // First 3 calls should succeed
    for (let i = 0; i < 3; i++) {
      const result = await limitedBreaker.execute();
      expect(result.success).toBe(true);
    }

    // Fourth call should be rate limited
    const limitedResult = await limitedBreaker.execute();
    expect(limitedResult.success).toBe(false);
    expect(limitedResult.error!.message).toContain('Rate limit exceeded');
  });
});

describe('Utility Functions', () => {
  describe('executeWithRetry', () => {
    it('should retry failed operations', async () => {
      let attempts = 0;
      const flakyOperation = async () => {
        attempts++;
        if (attempts < 3) {
          throw new Error('Temporary failure');
        }
        return 'Success';
      };

      const result = await executeWithRetry(flakyOperation, 3, 100);
      expect(result).toBe('Success');
      expect(attempts).toBe(3);
    });

    it('should fail after max retries', async () => {
      const alwaysFailingOperation = async () => {
        throw new Error('Always fails';
      };

      await expect(executeWithRetry(alwaysFailingOperation, 2, 50))
        .rejects.toThrow('Always fails');
    });
  });

  describe('executeParallel', () => {
    it('should execute operations in parallel with circuit breakers', async () => {
      const operations = [
        async () => 'result1',
        async () => 'result2',
        async () => { throw new Error('fail'); return 'result3'; },
        async () => 'result4'
      ];

      const results = await executeParallel(operations);
      
      expect(results).toHaveLength(4);
      expect(results[0].success).toBe(true);
      expect(results[1].success).toBe(true);
      expect(results[2].success).toBe(false);
      expect(results[3].success).toBe(true);
    });
  });
});