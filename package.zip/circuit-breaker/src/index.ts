/**
 * Circuit Breaker Pattern Library - Main Exports
 * Comprehensive circuit breaker implementation with state management, monitoring, and integrations
 */

// Core classes and types
export { CircuitBreaker } from './circuit-breaker';
export { CircuitBreakerRegistry } from './registry';

// Types and interfaces
export * from './types';

// Express middleware
export {
  createCircuitBreakerMiddleware,
  CircuitBreakerMiddleware,
  createProtectedRouter,
  circuitBreakerErrorHandler,
  circuitBreakerLogger
} from './express-middleware';

// AWS service integration
export {
  AWSServiceCircuitBreaker,
  AWSServiceCircuitBreakerFactory,
  AWS_SERVICE_CONFIGS,
  createProtectedAWSClient
} from './aws-integration';

// Dashboard and monitoring
export {
  CircuitBreakerDashboard,
  startDashboard
} from './dashboard';

// Utility functions
export {
  createSimpleCircuitBreaker,
  executeWithRetry,
  executeParallel,
  withTimeout,
  createRateLimitedCircuitBreaker,
  createHttpCircuitBreaker,
  createDatabaseCircuitBreaker,
  createApiCircuitBreaker,
  BulkheadCircuitBreaker,
  createStreamingCircuitBreaker,
  createCachedCircuitBreaker,
  checkCircuitBreakerHealth,
  generateCircuitBreakerConfig
} from './utils';

// Global registry access
export {
  getGlobalRegistry,
  createCircuitBreaker,
  getCircuitBreaker
} from './registry';

// Convenience re-exports for common patterns
import { CircuitBreaker } from './circuit-breaker';
import { CircuitBreakerConfig, CircuitBreakerOptions } from './types';
import { createSimpleCircuitBreaker, createHttpCircuitBreaker, createDatabaseCircuitBreaker } from './utils';

// Quick start functions for common use cases
export const circuitBreakers = {
  /**
   * Create a simple circuit breaker for any async operation
   */
  simple: createSimpleCircuitBreaker,
  
  /**
   * Create an HTTP client circuit breaker
   */
  http: createHttpCircuitBreaker,
  
  /**
   * Create a database circuit breaker
   */
  database: createDatabaseCircuitBreaker
};

// Pre-configured circuit breaker templates
export const templates = {
  /**
   * Configuration for fast, reliable services
   */
  fast: {
    failureThreshold: 5,
    resetTimeout: 30000,
    monitoringPeriod: 5000,
    volumeThreshold: 20,
    timeout: 5000
  } as CircuitBreakerConfig,

  /**
   * Configuration for slow services (e.g., legacy systems)
   */
  slow: {
    failureThreshold: 3,
    resetTimeout: 60000,
    monitoringPeriod: 15000,
    volumeThreshold: 5,
    timeout: 30000
  } as CircuitBreakerConfig,

  /**
   * Configuration for unreliable external services
   */
  unreliable: {
    failureThreshold: 3,
    resetTimeout: 120000,
    monitoringPeriod: 20000,
    volumeThreshold: 3,
    timeout: 45000
  } as CircuitBreakerConfig,

  /**
   * Configuration for critical services (more sensitive)
   */
  critical: {
    failureThreshold: 2,
    resetTimeout: 30000,
    monitoringPeriod: 10000,
    volumeThreshold: 2,
    timeout: 10000
  } as CircuitBreakerConfig
};

// Version information
export const version = '1.0.0';
export const name = '@circuit-breaker/core';

// Default export object for convenience
const circuitBreakerLibrary = {
  // Core
  CircuitBreaker,
  
  // Registry
  getGlobalRegistry,
  createCircuitBreaker,
  getCircuitBreaker,
  
  // Templates
  templates,
  circuitBreakers,
  
  // Utility functions
  createSimpleCircuitBreaker,
  createHttpCircuitBreaker,
  createDatabaseCircuitBreaker,
  
  // Middleware
  createCircuitBreakerMiddleware,
  CircuitBreakerMiddleware,
  circuitBreakerErrorHandler,
  circuitBreakerLogger,
  
  // AWS
  AWSServiceCircuitBreaker,
  AWSServiceCircuitBreakerFactory,
  createProtectedAWSClient,
  
  // Dashboard
  CircuitBreakerDashboard,
  startDashboard,
  
  // Version
  version,
  name
};

export default circuitBreakerLibrary;