/**
 * Express Middleware for Circuit Breaker Integration
 * Provides middleware to protect Express routes with circuit breakers
 */

import { Request, Response, NextFunction, Router } from 'express';
import {
  CircuitBreakerRegistry,
  getGlobalRegistry,
  createCircuitBreaker
} from './registry';
import {
  CircuitBreakerConfig,
  CircuitBreakerOptions,
  ExpressMiddlewareConfig,
  CircuitBreakerState,
  CircuitBreakerResult
} from './types';

export interface RouteProtectionConfig {
  /** Circuit breaker name (defaults to route path) */
  name?: string;
  /** Service identifier */
  service?: string;
  /** Circuit breaker configuration */
  config?: Partial<CircuitBreakerConfig>;
  /** Circuit breaker options */
  options?: Omit<CircuitBreakerOptions, 'name'>;
  /** Custom success handler */
  onSuccess?: (req: Request, res: Response, result: CircuitBreakerResult<any>) => void;
  /** Custom failure handler */
  onFailure?: (req: Request, res: Response, error: Error, result: CircuitBreakerResult<any>) => void;
  /** Response headers to add */
  headers?: Record<string, string>;
}

/**
 * Create circuit breaker middleware for a specific route
 */
export function createCircuitBreakerMiddleware(
  protectedOperation: (req: Request, res: Response, next: NextFunction) => Promise<any>,
  config: RouteProtectionConfig = {}
) {
  const {
    name,
    service,
    config: circuitBreakerConfig,
    options,
    onSuccess,
    onFailure,
    headers = {}
  } = config;

  const cbOptions: CircuitBreakerOptions = {
    name: name || `route-${Date.now()}`,
    service,
    ...options
  };

  const breaker = createCircuitBreaker(protectedOperation, circuitBreakerConfig, cbOptions);

  return async (req: Request, res: Response, next: NextFunction) => {
    const startTime = Date.now();

    // Add circuit breaker headers to response
    Object.entries(headers).forEach(([key, value]) => {
      res.setHeader(key, value);
    });

    try {
      // Execute the protected operation
      const result = await breaker.execute(req, res, next);

      // Add circuit breaker info headers
      res.setHeader('X-Circuit-Breaker-State', result.state);
      res.setHeader('X-Circuit-Breaker-Latency', result.latency.toString());

      // Handle success
      if (onSuccess) {
        onSuccess(req, res, result);
      }

      // If operation didn't send response, continue to next middleware
      if (!res.headersSent) {
        next();
      }

    } catch (error) {
      const latency = Date.now() - startTime;
      const errorResult: CircuitBreakerResult<any> = {
        success: false,
        error: error instanceof Error ? error : new Error(String(error)),
        latency,
        circuitOpen: false,
        state: breaker.getState()
      };

      // Add circuit breaker info headers even for failures
      res.setHeader('X-Circuit-Breaker-State', errorResult.state);
      res.setHeader('X-Circuit-Breaker-Latency', errorResult.latency.toString());

      // Handle failure
      if (onFailure) {
        onFailure(req, res, errorResult.error!, errorResult);
      } else {
        // Default error handling
        if (errorResult.circuitOpen) {
          res.status(503).json({
            error: 'Service Unavailable',
            message: 'Circuit breaker is open - service temporarily unavailable',
            circuitBreaker: {
              state: errorResult.state,
              latency: errorResult.latency
            }
          });
        } else {
          res.status(500).json({
            error: 'Internal Server Error',
            message: errorResult.error!.message,
            circuitBreaker: {
              state: errorResult.state,
              latency: errorResult.latency
            }
          });
        }
      }
    }
  };
}

/**
 * Middleware factory for route protection
 */
export class CircuitBreakerMiddleware {
  private registry: CircuitBreakerRegistry;

  constructor(registry?: CircuitBreakerRegistry) {
    this.registry = registry || getGlobalRegistry();
  }

  /**
   * Protect a single route with a circuit breaker
   */
  protectRoute(
    route: string,
    protectedOperation: (req: Request, res: Response, next: NextFunction) => Promise<any>,
    config?: RouteProtectionConfig
  ) {
    return createCircuitBreakerMiddleware(protectedOperation, {
      ...config,
      name: config?.name || `route-${route}`
    });
  }

  /**
   * Protect multiple routes with the same circuit breaker
   */
  protectRoutes(
    routes: string[],
    protectedOperation: (req: Request, res: Response, next: NextFunction) => Promise<any>,
    config?: RouteProtectionConfig
  ) {
    const middleware = createCircuitBreakerMiddleware(protectedOperation, config);
    
    return (req: Request, res: Response, next: NextFunction) => {
      if (routes.some(route => {
        // Simple pattern matching for routes
        if (route.endsWith('*')) {
          const baseRoute = route.slice(0, -1);
          return req.path.startsWith(baseRoute);
        }
        return req.path === route;
      })) {
        return middleware(req, res, next);
      }
      next();
    };
  }

  /**
   * Create a circuit breaker-protected HTTP client operation
   */
  protectHttpOperation(
    operation: (config: any) => Promise<any>,
    config: RouteProtectionConfig & {
      /** HTTP method to protect */
      method?: string;
      /** URL pattern to match */
      urlPattern?: string;
    } = {}
  ) {
    const { method, urlPattern, ...routeConfig } = config;
    const name = routeConfig.name || `http-${method || 'request'}-${Date.now()}`;

    return this.registry.create(name, operation, routeConfig.config, {
      ...routeConfig.options,
      service: routeConfig.options?.service || 'http-client'
    });
  }

  /**
   * Create a circuit breaker for database operations
   */
  protectDatabaseOperation(
    operation: (...args: any[]) => Promise<any>,
    config: RouteProtectionConfig & {
      /** Database connection identifier */
      connectionName?: string;
    } = {}
  ) {
    const { connectionName, ...routeConfig } = config;
    const name = routeConfig.name || `db-${connectionName || 'default'}-${Date.now()}`;

    return createCircuitBreaker(operation, {
      ...routeConfig.config,
      timeout: routeConfig.config?.timeout || 5000 // Shorter timeout for DB operations
    }, {
      ...routeConfig.options,
      name,
      service: routeConfig.options?.service || 'database'
    });
  }

  /**
   * Create a circuit breaker for external API calls
   */
  protectApiCall(
    operation: (...args: any[]) => Promise<any>,
    config: RouteProtectionConfig & {
      /** API name */
      apiName?: string;
      /** Use longer timeout for external APIs */
      timeout?: number;
    } = {}
  ) {
    const { apiName, timeout, ...routeConfig } = config;
    const name = routeConfig.name || `api-${apiName || 'external'}-${Date.now()}`;

    return createCircuitBreaker(operation, {
      ...routeConfig.config,
      timeout: timeout || 30000, // Default 30s for external APIs
      failureThreshold: routeConfig.config?.failureThreshold || 3, // Lower threshold for external APIs
      resetTimeout: routeConfig.config?.resetTimeout || 60000 // Default 1 minute
    }, {
      ...routeConfig.options,
      name,
      service: routeConfig.options?.service || 'external-api'
    });
  }

  /**
   * Get middleware configuration for specific routes
   */
  getMiddlewareConfig(): ExpressMiddlewareConfig[] {
    const allMetrics = this.registry.getAllMetrics();
    const configs: ExpressMiddlewareConfig[] = [];

    for (const [name, metrics] of Object.entries(allMetrics)) {
      configs.push({
        routes: [name],
        circuitBreakerOptions: {
          failureThreshold: 5,
          resetTimeout: 60000,
          timeout: 30000
        }
      });
    }

    return configs;
  }
}

/**
 * Create Express Router with circuit breaker protection
 */
export function createProtectedRouter(basePath: string, registry?: CircuitBreakerRegistry) {
  const router = Router();
  const middlewareFactory = new CircuitBreakerMiddleware(registry);

  /**
   * GET endpoint with circuit breaker protection
   */
  router.get = function(path: string, ...handlers: any[]) {
    const protectedHandlers = handlers.map(handler => {
      if (typeof handler === 'function') {
        return createCircuitBreakerMiddleware(handler, {
          name: `get-${basePath}${path}`,
          service: 'express-router'
        });
      }
      return handler;
    });

    return Router.get.call(this, path, ...protectedHandlers);
  };

  /**
   * POST endpoint with circuit breaker protection
   */
  router.post = function(path: string, ...handlers: any[]) {
    const protectedHandlers = handlers.map(handler => {
      if (typeof handler === 'function') {
        return createCircuitBreakerMiddleware(handler, {
          name: `post-${basePath}${path}`,
          service: 'express-router'
        });
      }
      return handler;
    });

    return Router.post.call(this, path, ...protectedHandlers);
  };

  /**
   * PUT endpoint with circuit breaker protection
   */
  router.put = function(path: string, ...handlers: any[]) {
    const protectedHandlers = handlers.map(handler => {
      if (typeof handler === 'function') {
        return createCircuitBreakerMiddleware(handler, {
          name: `put-${basePath}${path}`,
          service: 'express-router'
        });
      }
      return handler;
    });

    return Router.put.call(this, path, ...protectedHandlers);
  };

  /**
   * DELETE endpoint with circuit breaker protection
   */
  router.delete = function(path: string, ...handlers: any[]) {
    const protectedHandlers = handlers.map(handler => {
      if (typeof handler === 'function') {
        return createCircuitBreakerMiddleware(handler, {
          name: `delete-${basePath}${path}`,
          service: 'express-router'
        });
      }
      return handler;
    });

    return Router.delete.call(this, path, ...protectedHandlers);
  };

  return router;
}

/**
 * Express error handling middleware for circuit breakers
 */
export function circuitBreakerErrorHandler() {
  return (error: Error, req: Request, res: Response, next: NextFunction) => {
    // Log circuit breaker errors
    console.error('Circuit Breaker Error:', {
      error: error.message,
      stack: error.stack,
      path: req.path,
      method: req.method,
      userAgent: req.get('User-Agent'),
      timestamp: new Date().toISOString()
    });

    // Send appropriate error response
    if (error.message.includes('Circuit breaker is OPEN')) {
      res.status(503).json({
        error: 'Service Unavailable',
        message: 'Service is temporarily unavailable due to high failure rate',
        timestamp: new Date().toISOString()
      });
    } else if (error.message.includes('timed out')) {
      res.status(504).json({
        error: 'Gateway Timeout',
        message: 'Request timed out',
        timestamp: new Date().toISOString()
      });
    } else {
      res.status(500).json({
        error: 'Internal Server Error',
        message: 'An unexpected error occurred',
        timestamp: new Date().toISOString()
      });
    }
  };
}

/**
 * Express request/response logging middleware for circuit breakers
 */
export function circuitBreakerLogger() {
  return (req: Request, res: Response, next: NextFunction) => {
    const startTime = Date.now();

    // Log circuit breaker state on response finish
    res.on('finish', () => {
      const duration = Date.now() - startTime;
      const state = res.getHeader('X-Circuit-Breaker-State');
      const latency = res.getHeader('X-Circuit-Breaker-Latency');

      if (state && latency) {
        console.log(`Circuit Breaker Request:`, {
          method: req.method,
          path: req.path,
          statusCode: res.statusCode,
          duration,
          circuitState: state,
          circuitLatency: latency,
          timestamp: new Date().toISOString()
        });
      }
    });

    next();
  };
}