/**
 * Circuit Breaker Pattern Implementation
 * Types and interfaces for the circuit breaker system
 */

export enum CircuitBreakerState {
  CLOSED = 'CLOSED',
  OPEN = 'OPEN',
  HALF_OPEN = 'HALF_OPEN'
}

export interface CircuitBreakerConfig {
  /** Number of failures to trigger the circuit breaker */
  failureThreshold: number;
  /** Time in milliseconds to wait before attempting to reset */
  resetTimeout: number;
  /** Time in milliseconds to wait before transitioning from half-open to open on failure */
  monitoringPeriod: number;
  /** Minimum number of requests to consider before changing state */
  volumeThreshold: number;
  /** Custom timeout for requests (ms) */
  timeout?: number;
  /** Error types that should be counted as failures */
  errorTypes?: Array<new (...args: any[]) => Error>;
  /** Success rate threshold percentage for half-open state */
  successThreshold?: number;
  /** Health check function to determine service health */
  healthCheck?: () => Promise<boolean>;
  /** Event handlers for state changes */
  onStateChange?: (from: CircuitBreakerState, to: CircuitBreakerState) => void;
  /** Event handler for successful requests */
  onSuccess?: (latency: number) => void;
  /** Event handler for failed requests */
  onFailure?: (error: Error, latency: number) => void;
  /** Event handler for circuit trips */
  onCircuitTripped?: (error: Error) => void;
}

export interface CircuitBreakerMetrics {
  /** Current state of the circuit breaker */
  state: CircuitBreakerState;
  /** Number of successful requests */
  successCount: number;
  /** Number of failed requests */
  failureCount: number;
  /** Total number of requests */
  totalRequests: number;
  /** Success rate percentage */
  successRate: number;
  /** Average latency in milliseconds */
  averageLatency: number;
  /** Total latency accumulated */
  totalLatency: number;
  /** Last state change timestamp */
  lastStateChange: number;
  /** Last failure timestamp */
  lastFailure?: number;
  /** Last success timestamp */
  lastSuccess?: number;
  /** Number of times the circuit has been tripped */
  totalTrips: number;
  /** Requests blocked when circuit is open */
  blockedRequests: number;
  /** Current failure streak */
  currentFailureStreak: number;
  /** Current success streak (when half-open) */
  currentSuccessStreak: number;
}

export interface CircuitBreakerOptions {
  /** Name identifier for the circuit breaker */
  name: string;
  /** Service or resource identifier */
  service?: string;
  /** Additional metadata */
  metadata?: Record<string, any>;
}

export interface CircuitBreakerResult<T> {
  /** The result of the operation */
  data?: T;
  /** Error if operation failed */
  error?: Error;
  /** Whether the operation was successful */
  success: boolean;
  /** Latency in milliseconds */
  latency: number;
  /** Whether the circuit was open and request was blocked */
  circuitOpen: boolean;
  /** Current circuit state */
  state: CircuitBreakerState;
}

export interface HealthStatus {
  /** Overall health status */
  healthy: boolean;
  /** Current circuit state */
  state: CircuitBreakerState;
  /** Detailed health metrics */
  metrics: CircuitBreakerMetrics;
  /** Timestamp of health check */
  timestamp: number;
  /** Additional health information */
  details?: Record<string, any>;
}

export interface CircuitBreakerEvent {
  /** Event type */
  type: 'STATE_CHANGE' | 'SUCCESS' | 'FAILURE' | 'CIRCUIT_TRIPPED' | 'REQUEST_BLOCKED';
  /** Event timestamp */
  timestamp: number;
  /** Event data */
  data: any;
  /** Circuit breaker name */
  name: string;
  /** Current state */
  state: CircuitBreakerState;
}

/**
 * Circuit breaker middleware configuration for Express
 */
export interface ExpressMiddlewareConfig {
  /** Route patterns to apply circuit breaker to */
  routes: string[];
  /** Circuit breaker options */
  circuitBreakerOptions: Partial<CircuitBreakerConfig>;
  /** HTTP methods to protect */
  methods?: string[];
  /** Custom response for blocked requests */
  blockedResponse?: {
    status: number;
    message: string;
    headers?: Record<string, string>;
  };
}

/**
 * AWS service circuit breaker configuration
 */
export interface AWSServiceConfig {
  /** AWS service name */
  service: string;
  /** Region */
  region?: string;
  /** Specific operations to protect */
  operations?: string[];
  /** Circuit breaker configuration */
  circuitBreakerOptions: Partial<CircuitBreakerConfig>;
}

/**
 * Circuit breaker dashboard configuration
 */
export interface DashboardConfig {
  /** Port to run dashboard on */
  port: number;
  /** Host address */
  host: string;
  /** Update interval in milliseconds */
  updateInterval: number;
  /** Enable real-time updates via WebSocket */
  enableWebSocket?: boolean;
  /** Authentication configuration */
  auth?: {
    enabled: boolean;
    username: string;
    password: string;
  };
  /** Circuit breakers to display (all if not specified) */
  circuits?: string[];
}