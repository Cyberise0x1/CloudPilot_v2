/**
 * AWS Service Integration with Circuit Breakers
 * Provides circuit breaker protection for AWS SDK operations
 */

import {
  AWSServiceClient,
  AWSClientConfig,
  AWSServiceError,
  CircuitBreaker,
  CircuitBreakerConfig,
  CircuitBreakerOptions
} from './types';
import { createCircuitBreaker } from './registry';

/**
 * Configuration for AWS service circuit breaker protection
 */
export interface AWSServiceBreakerConfig {
  /** AWS service name (s3, dynamodb, lambda, etc.) */
  service: string;
  /** AWS region */
  region?: string;
  /** Circuit breaker name (defaults to service-operation) */
  name?: string;
  /** Operations to protect (all if not specified) */
  operations?: string[];
  /** Circuit breaker configuration */
  config?: Partial<CircuitBreakerConfig>;
  /** Custom error handling */
  onError?: (error: Error, operation: string) => void;
  /** Success callback */
  onSuccess?: (latency: number, operation: string) => void;
  /** Operation timeout overrides */
  operationTimeouts?: Record<string, number>;
}

/**
 * AWS service client wrapper with circuit breaker protection
 */
export class AWSServiceCircuitBreaker {
  private serviceClients = new Map<string, AWSServiceClient>();
  private circuitBreakers = new Map<string, CircuitBreaker>();

  constructor(
    private awsConfig: AWSServiceBreakerConfig,
    private originalClients: Record<string, AWSServiceClient>
  ) {
    this.initializeCircuitBreakers();
  }

  /**
   * Get a protected client for the specified service
   */
  getClient(service: string): AWSServiceClient | undefined {
    return this.serviceClients.get(service);
  }

  /**
   * Get circuit breaker for a specific operation
   */
  getCircuitBreaker(operation: string): CircuitBreaker | undefined {
    const breakerName = this.getBreakerName(operation);
    return this.circuitBreakers.get(breakerName);
  }

  /**
   * Execute an AWS operation with circuit breaker protection
   */
  async execute<T>(
    service: string,
    operation: string,
    operationFn: (...args: any[]) => Promise<T>,
    ...args: any[]
  ): Promise<T> {
    const breaker = this.getCircuitBreaker(operation);
    if (!breaker) {
      throw new Error(`No circuit breaker found for operation: ${operation}`);
    }

    return breaker.execute(...args);
  }

  /**
   * Wrap individual AWS SDK methods with circuit breakers
   */
  wrapMethods(service: string, client: AWSServiceClient): AWSServiceClient {
    const protectedClient = { ...client } as any;

    // Get operations to protect
    const operationsToProtect = this.awsConfig.operations || this.getAvailableOperations(service);

    for (const operation of operationsToProtect) {
      if (typeof protectedClient[operation] === 'function') {
        const originalMethod = protectedClient[operation].bind(protectedClient);
        
        // Create circuit breaker for this operation
        const breaker = this.createOperationBreaker(service, operation);
        
        // Wrap the method
        protectedClient[operation] = async (...args: any[]) => {
          try {
            return await breaker.execute(async () => {
              const result = await originalMethod(...args);
              return result;
            });
          } catch (error) {
            // Handle circuit breaker specific errors
            if (error instanceof Error && error.message.includes('Circuit breaker is OPEN')) {
              this.awsConfig.onError?.(error, operation);
              throw new Error(`Circuit breaker for ${service}.${operation} is OPEN`);
            }
            throw error;
          }
        };
      }
    }

    this.serviceClients.set(service, protectedClient);
    return protectedClient;
  }

  /**
   * Get metrics for all service circuit breakers
   */
  getMetrics(): Record<string, any> {
    const metrics: Record<string, any> = {};
    
    for (const [name, breaker] of this.circuitBreakers) {
      metrics[name] = breaker.getMetrics();
    }
    
    return metrics;
  }

  /**
   * Get health status for all service circuit breakers
   */
  getHealth(): Record<string, any> {
    const health: Record<string, any> = {};
    
    for (const [name, breaker] of this.circuitBreakers) {
      health[name] = breaker.getHealth();
    }
    
    return health;
  }

  /**
   * Initialize circuit breakers for the configured service
   */
  private initializeCircuitBreakers(): void {
    const service = this.awsConfig.service;
    const client = this.originalClients[service];
    
    if (!client) {
      throw new Error(`AWS service client not found: ${service}`);
    }

    // Get operations to protect
    const operations = this.awsConfig.operations || this.getAvailableOperations(service);
    
    for (const operation of operations) {
      const breaker = this.createOperationBreaker(service, operation);
      this.circuitBreakers.set(this.getBreakerName(operation), breaker);
    }
  }

  /**
   * Create a circuit breaker for a specific service operation
   */
  private createOperationBreaker(service: string, operation: string): CircuitBreaker {
    const breakerName = this.getBreakerName(operation);
    
    // Create the operation function
    const operationFn = async (...args: any[]) => {
      const client = this.originalClients[service];
      if (!client || typeof client[operation] !== 'function') {
        throw new Error(`Operation ${operation} not found on ${service} client`);
      }
      
      try {
        const result = await client[operation](...args);
        return result;
      } catch (error) {
        // Handle AWS SDK specific errors
        if (error instanceof Error) {
          const awsError = error as AWSServiceError;
          
          // Don't trip circuit breaker on client errors (4xx)
          if (awsError.$metadata?.httpStatusCode && awsError.$metadata.httpStatusCode < 500) {
            throw error;
          }
          
          // Trip circuit breaker on server errors (5xx)
          if (awsError.$metadata?.httpStatusCode && awsError.$metadata.httpStatusCode >= 500) {
            throw error;
          }
        }
        
        throw error;
      }
    };

    // Create circuit breaker configuration
    const config: CircuitBreakerConfig = {
      failureThreshold: this.awsConfig.config?.failureThreshold || 3,
      resetTimeout: this.awsConfig.config?.resetTimeout || 60000,
      monitoringPeriod: this.awsConfig.config?.monitoringPeriod || 10000,
      volumeThreshold: this.awsConfig.config?.volumeThreshold || 5,
      timeout: this.getOperationTimeout(operation),
      errorTypes: this.awsConfig.config?.errorTypes || [],
      onSuccess: (latency: number) => this.awsConfig.onSuccess?.(latency, operation),
      onFailure: (error: Error, latency: number) => this.awsConfig.onError?.(error, operation),
      healthCheck: this.awsConfig.config?.healthCheck
    };

    const options: CircuitBreakerOptions = {
      name: breakerName,
      service: `${service}-${operation}`,
      metadata: {
        awsService: service,
        operation,
        region: this.awsConfig.region
      }
    };

    return createCircuitBreaker(operationFn, config, options);
  }

  /**
   * Get timeout for a specific operation
   */
  private getOperationTimeout(operation: string): number {
    return this.awsConfig.operationTimeouts?.[operation] || 
           this.awsConfig.config?.timeout || 
           this.getDefaultTimeout(operation);
  }

  /**
   * Get default timeout for operation type
   */
  private getDefaultTimeout(operation: string): number {
    // Different operations have different timeout requirements
    const timeoutMap: Record<string, number> = {
      // S3 operations
      'getObject': 30000,
      'putObject': 60000,
      'deleteObject': 15000,
      'headObject': 10000,
      'listObjects': 20000,
      
      // DynamoDB operations
      'getItem': 10000,
      'putItem': 10000,
      'deleteItem': 10000,
      'query': 15000,
      'scan': 30000,
      'batchGetItem': 20000,
      'batchWriteItem': 20000,
      
      // Lambda operations
      'invoke': 30000,
      'getFunction': 10000,
      'createFunction': 120000,
      'updateFunction': 60000,
      
      // SQS operations
      'sendMessage': 20000,
      'receiveMessage': 20000,
      'deleteMessage': 15000,
      
      // SES operations
      'sendEmail': 30000,
      'sendRawEmail': 30000,
      
      // Default
      'default': 30000
    };

    return timeoutMap[operation] || timeoutMap['default'];
  }

  /**
   * Get available operations for a service
   */
  private getAvailableOperations(service: string): string[] {
    const operationMap: Record<string, string[]> = {
      s3: [
        'getObject', 'putObject', 'deleteObject', 'headObject', 'listObjects',
        'copyObject', 'getBucketAcl', 'putBucketAcl', 'getBucketLocation'
      ],
      dynamodb: [
        'getItem', 'putItem', 'deleteItem', 'updateItem', 'query', 'scan',
        'batchGetItem', 'batchWriteItem', 'describeTable', 'listTables'
      ],
      lambda: [
        'invoke', 'getFunction', 'createFunction', 'updateFunction', 'deleteFunction',
        'listFunctions', 'getFunctionConfiguration'
      ],
      sqs: [
        'sendMessage', 'receiveMessage', 'deleteMessage', 'createQueue',
        'getQueueUrl', 'getQueueAttributes', 'setQueueAttributes'
      ],
      ses: [
        'sendEmail', 'sendRawEmail', 'createTemplate', 'sendTemplatedEmail',
        'getSendQuota', 'getSendStatistics'
      ],
      ec2: [
        'describeInstances', 'runInstances', 'stopInstances', 'startInstances',
        'terminateInstances', 'describeImages'
      ]
    };

    return operationMap[service] || ['default'];
  }

  /**
   * Generate circuit breaker name for operation
   */
  private getBreakerName(operation: string): string {
    if (this.awsConfig.name) {
      return `${this.awsConfig.name}-${operation}`;
    }
    return `aws-${this.awsConfig.service}-${operation}`;
  }
}

/**
 * Factory for creating AWS service circuit breakers
 */
export class AWSServiceCircuitBreakerFactory {
  private services = new Map<string, AWSServiceCircuitBreaker>();

  /**
   * Create circuit breaker protection for AWS services
   */
  create(
    serviceConfigs: AWSServiceBreakerConfig[],
    clients: Record<string, AWSServiceClient>
  ): Record<string, AWSServiceCircuitBreaker> {
    const protectedServices: Record<string, AWSServiceCircuitBreaker> = {};

    for (const config of serviceConfigs) {
      const breaker = new AWSServiceCircuitBreaker(config, clients);
      
      // Wrap each service client
      for (const serviceName of Object.keys(clients)) {
        if (serviceName === config.service) {
          const client = clients[serviceName];
          const protectedClient = breaker.wrapMethods(serviceName, client);
          protectedServices[serviceName] = breaker;
          breaker.getClient(serviceName); // This will store the protected client
        }
      }

      this.services.set(config.service, breaker);
    }

    return protectedServices;
  }

  /**
   * Get circuit breaker for a service
   */
  get(service: string): AWSServiceCircuitBreaker | undefined {
    return this.services.get(service);
  }

  /**
   * Get all circuit breaker metrics
   */
  getAllMetrics(): Record<string, any> {
    const allMetrics: Record<string, any> = {};
    
    for (const [service, breaker] of this.services) {
      allMetrics[service] = breaker.getMetrics();
    }
    
    return allMetrics;
  }

  /**
   * Get all health statuses
   */
  getAllHealth(): Record<string, any> {
    const allHealth: Record<string, any> = {};
    
    for (const [service, breaker] of this.services) {
      allHealth[service] = breaker.getHealth();
    }
    
    return allHealth;
  }

  /**
   * Create a simple circuit breaker for a single AWS client
   */
  static createSimple(
    service: string,
    client: AWSServiceClient,
    config?: Partial<CircuitBreakerConfig>
  ): AWSServiceCircuitBreaker {
    const breakerConfig: AWSServiceBreakerConfig = {
      service,
      config: {
        failureThreshold: config?.failureThreshold || 3,
        resetTimeout: config?.resetTimeout || 60000,
        monitoringPeriod: config?.monitoringPeriod || 10000,
        volumeThreshold: config?.volumeThreshold || 5,
        timeout: config?.timeout || 30000
      }
    };

    return new AWSServiceCircuitBreaker(breakerConfig, { [service]: client });
  }
}

/**
 * Pre-configured circuit breaker configurations for common AWS services
 */
export const AWS_SERVICE_CONFIGS: Record<string, Partial<CircuitBreakerConfig>> = {
  s3: {
    failureThreshold: 5,
    resetTimeout: 30000,
    timeout: 30000
  },
  dynamodb: {
    failureThreshold: 3,
    resetTimeout: 60000,
    timeout: 10000
  },
  lambda: {
    failureThreshold: 3,
    resetTimeout: 90000,
    timeout: 30000
  },
  sqs: {
    failureThreshold: 5,
    resetTimeout: 30000,
    timeout: 20000
  },
  ses: {
    failureThreshold: 3,
    resetTimeout: 60000,
    timeout: 30000
  },
  ec2: {
    failureThreshold: 3,
    resetTimeout: 60000,
    timeout: 30000
  }
};

/**
 * Create a circuit breaker-protected AWS client
 */
export function createProtectedAWSClient(
  service: string,
  client: AWSServiceClient,
  options?: {
    config?: Partial<CircuitBreakerConfig>;
    operations?: string[];
    name?: string;
  }
): AWSServiceClient {
  const serviceConfig = AWS_SERVICE_CONFIGS[service] || {};
  
  const breakerConfig: AWSServiceBreakerConfig = {
    service,
    config: {
      ...serviceConfig,
      ...options?.config
    },
    operations: options?.operations
  };

  const breaker = new AWSServiceCircuitBreaker(breakerConfig, { [service]: client });
  return breaker.wrapMethods(service, client);
}