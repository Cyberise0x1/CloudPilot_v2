/**
 * Circuit Breaker Registry and Manager
 * Manages multiple circuit breakers, provides centralized control and monitoring
 */

import {
  CircuitBreaker,
  CircuitBreakerConfig,
  CircuitBreakerOptions,
  CircuitBreakerState,
  HealthStatus,
  CircuitBreakerEvent,
  CircuitBreakerMetrics
} from './types';

export interface RegistryOptions {
  /** Default configuration for new circuit breakers */
  defaultConfig: CircuitBreakerConfig;
  /** Enable automatic cleanup of inactive breakers */
  enableAutoCleanup?: boolean;
  /** Cleanup interval in milliseconds */
  cleanupInterval?: number;
  /** Maximum number of circuit breakers to maintain */
  maxBreakers?: number;
}

export class CircuitBreakerRegistry {
  private breakers = new Map<string, CircuitBreaker>();
  private eventHandlers: Array<(event: CircuitBreakerEvent & { circuitName: string }) => void> = [];
  private options: Required<RegistryOptions>;
  private lastAccess = new Map<string, number>();

  constructor(options: RegistryOptions) {
    this.options = {
      defaultConfig: options.defaultConfig,
      enableAutoCleanup: options.enableAutoCleanup ?? true,
      cleanupInterval: options.cleanupInterval ?? 300000, // 5 minutes
      maxBreakers: options.maxBreakers ?? 100
    };

    if (this.options.enableAutoCleanup) {
      this.startAutoCleanup();
    }
  }

  /**
   * Create or get an existing circuit breaker
   */
  create(
    name: string,
    operation: (...args: any[]) => Promise<any>,
    config?: Partial<CircuitBreakerConfig>,
    options?: Omit<CircuitBreakerOptions, 'name'>
  ): CircuitBreaker {
    // Check if breaker already exists
    const existingBreaker = this.breakers.get(name);
    if (existingBreaker) {
      this.updateLastAccess(name);
      return existingBreaker;
    }

    // Check if we're at capacity
    if (this.breakers.size >= this.options.maxBreakers) {
      this.cleanupOldest();
    }

    // Merge configurations
    const mergedConfig: CircuitBreakerConfig = {
      ...this.options.defaultConfig,
      ...config
    };

    const breakerOptions: CircuitBreakerOptions = {
      name,
      ...options
    };

    // Create new circuit breaker
    const breaker = new CircuitBreaker(operation, mergedConfig, breakerOptions);
    
    // Subscribe to breaker events
    breaker.onEvent((event) => {
      const fullEvent = {
        ...event,
        circuitName: name
      };
      this.eventHandlers.forEach(handler => {
        try {
          handler(fullEvent);
        } catch (error) {
          console.error('Error in registry event handler:', error);
        }
      });
    });

    this.breakers.set(name, breaker);
    this.lastAccess.set(name, Date.now());

    return breaker;
  }

  /**
   * Get a circuit breaker by name
   */
  get(name: string): CircuitBreaker | undefined {
    const breaker = this.breakers.get(name);
    if (breaker) {
      this.updateLastAccess(name);
    }
    return breaker;
  }

  /**
   * Check if a circuit breaker exists
   */
  has(name: string): boolean {
    return this.breakers.has(name);
  }

  /**
   * Remove a circuit breaker
   */
  remove(name: string): boolean {
    const breaker = this.breakers.get(name);
    if (breaker) {
      breaker.destroy();
      this.breakers.delete(name);
      this.lastAccess.delete(name);
      return true;
    }
    return false;
  }

  /**
   * Get all circuit breaker names
   */
  getNames(): string[] {
    return Array.from(this.breakers.keys());
  }

  /**
   * Get metrics for all circuit breakers
   */
  getAllMetrics(): Record<string, CircuitBreakerMetrics> {
    const metrics: Record<string, CircuitBreakerMetrics> = {};
    
    for (const [name, breaker] of this.breakers) {
      metrics[name] = breaker.getMetrics();
    }
    
    return metrics;
  }

  /**
   * Get health status for all circuit breakers
   */
  getAllHealth(): Record<string, HealthStatus> {
    const health: Record<string, HealthStatus> = {};
    
    for (const [name, breaker] of this.breakers) {
      health[name] = breaker.getHealth();
    }
    
    return health;
  }

  /**
   * Get circuit breakers by state
   */
  getByState(state: CircuitBreakerState): Array<{ name: string; breaker: CircuitBreaker }> {
    const result: Array<{ name: string; breaker: CircuitBreaker }> = [];
    
    for (const [name, breaker] of this.breakers) {
      if (breaker.getState() === state) {
        result.push({ name, breaker });
      }
    }
    
    return result;
  }

  /**
   * Get unhealthy circuit breakers
   */
  getUnhealthy(): Array<{ name: string; health: HealthStatus }> {
    const unhealthy: Array<{ name: string; health: HealthStatus }> = [];
    
    for (const [name, breaker] of this.breakers) {
      const health = breaker.getHealth();
      if (!health.healthy) {
        unhealthy.push({ name, health });
      }
    }
    
    return unhealthy;
  }

  /**
   * Execute a function through a circuit breaker
   */
  async execute<T>(
    name: string,
    operation: (...args: any[]) => Promise<T>,
    ...args: any[]
  ): Promise<T> {
    const breaker = this.get(name) || this.create(name, operation);
    const result = await breaker.execute(...args);
    
    if (!result.success) {
      throw result.error;
    }
    
    return result.data!;
  }

  /**
   * Force state change for a specific circuit breaker
   */
  forceState(name: string, state: CircuitBreakerState): boolean {
    const breaker = this.get(name);
    if (breaker) {
      breaker.forceState(state);
      return true;
    }
    return false;
  }

  /**
   * Reset all circuit breakers
   */
  resetAll(): void {
    for (const [, breaker] of this.breakers) {
      breaker.reset();
    }
  }

  /**
   * Subscribe to registry-wide events
   */
  onEvent(handler: (event: CircuitBreakerEvent & { circuitName: string }) => void): void {
    this.eventHandlers.push(handler);
  }

  /**
   * Unsubscribe from registry-wide events
   */
  offEvent(handler: (event: CircuitBreakerEvent & { circuitName: string }) => void): void {
    this.eventHandlers = this.eventHandlers.filter(h => h !== handler);
  }

  /**
   * Get registry statistics
   */
  getStats() {
    const stateCounts = {
      [CircuitBreakerState.CLOSED]: 0,
      [CircuitBreakerState.OPEN]: 0,
      [CircuitBreakerState.HALF_OPEN]: 0
    };

    let totalRequests = 0;
    let totalSuccesses = 0;
    let totalFailures = 0;
    let totalBlocked = 0;

    for (const [, breaker] of this.breakers) {
      const metrics = breaker.getMetrics();
      stateCounts[metrics.state]++;
      totalRequests += metrics.totalRequests;
      totalSuccesses += metrics.successCount;
      totalFailures += metrics.failureCount;
      totalBlocked += metrics.blockedRequests;
    }

    return {
      totalBreakers: this.breakers.size,
      stateCounts,
      totalRequests,
      totalSuccesses,
      totalFailures,
      totalBlocked,
      overallSuccessRate: totalRequests > 0 ? (totalSuccesses / totalRequests) * 100 : 0,
      lastCleanup: this.lastAccess.size === 0 ? undefined : Math.min(...this.lastAccess.values())
    };
  }

  /**
   * Update last access timestamp for a breaker
   */
  private updateLastAccess(name: string): void {
    this.lastAccess.set(name, Date.now());
  }

  /**
   * Clean up oldest circuit breakers when at capacity
   */
  private cleanupOldest(): void {
    if (this.breakers.size === 0) return;

    // Sort by last access time
    const sortedBreakers = Array.from(this.lastAccess.entries())
      .sort(([, a], [, b]) => a - b)
      .slice(0, Math.ceil(this.breakers.size * 0.2)); // Remove oldest 20%

    for (const [name] of sortedBreakers) {
      this.remove(name);
    }
  }

  /**
   * Start automatic cleanup process
   */
  private startAutoCleanup(): void {
    setInterval(() => {
      const now = Date.now();
      const inactiveThreshold = this.options.cleanupInterval * 2; // 2x cleanup interval
      
      for (const [name, lastAccess] of this.lastAccess) {
        if (now - lastAccess > inactiveThreshold) {
          this.remove(name);
        }
      }
    }, this.options.cleanupInterval);
  }

  /**
   * Destroy the registry and all circuit breakers
   */
  destroy(): void {
    for (const [, breaker] of this.breakers) {
      breaker.destroy();
    }
    this.breakers.clear();
    this.lastAccess.clear();
    this.eventHandlers = [];
  }
}

// Global registry instance
let globalRegistry: CircuitBreakerRegistry | null = null;

/**
 * Get or create the global circuit breaker registry
 */
export function getGlobalRegistry(options?: RegistryOptions): CircuitBreakerRegistry {
  if (!globalRegistry && options) {
    globalRegistry = new CircuitBreakerRegistry(options);
  } else if (!globalRegistry) {
    // Create with default options if not provided
    globalRegistry = new CircuitBreakerRegistry({
      defaultConfig: {
        failureThreshold: 5,
        resetTimeout: 60000,
        monitoringPeriod: 10000,
        volumeThreshold: 10,
        timeout: 30000
      }
    });
  }
  return globalRegistry;
}

/**
 * Convenience function to create a circuit breaker in the global registry
 */
export function createCircuitBreaker(
  name: string,
  operation: (...args: any[]) => Promise<any>,
  config?: Partial<CircuitBreakerConfig>,
  options?: Omit<CircuitBreakerOptions, 'name'>
): CircuitBreaker {
  return getGlobalRegistry().create(name, operation, config, options);
}

/**
 * Convenience function to get a circuit breaker from the global registry
 */
export function getCircuitBreaker(name: string): CircuitBreaker | undefined {
  return getGlobalRegistry().get(name);
}