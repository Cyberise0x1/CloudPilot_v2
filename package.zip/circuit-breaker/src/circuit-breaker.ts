/**
 * Circuit Breaker Core Implementation
 * Implements the circuit breaker pattern with state management, metrics, and health monitoring
 */

import {
  CircuitBreakerState,
  CircuitBreakerConfig,
  CircuitBreakerMetrics,
  CircuitBreakerOptions,
  CircuitBreakerResult,
  HealthStatus,
  CircuitBreakerEvent
} from './types';

export class CircuitBreaker {
  private state: CircuitBreakerState = CircuitBreakerState.CLOSED;
  private failureCount = 0;
  private successCount = 0;
  private totalRequests = 0;
  private totalLatency = 0;
  private lastStateChange = Date.now();
  private lastFailure?: number;
  private lastSuccess?: number;
  private totalTrips = 0;
  private blockedRequests = 0;
  private currentFailureStreak = 0;
  private currentSuccessStreak = 0;
  private monitoringStartTime = Date.now();
  private resetTimeoutId?: NodeJS.Timeout;
  private healthCheckTimeoutId?: NodeJS.Timeout;
  
  private readonly config: Required<CircuitBreakerConfig>;
  private readonly options: CircuitBreakerOptions;
  private eventHandlers: Array<(event: CircuitBreakerEvent) => void> = [];

  constructor(
    private operation: (...args: any[]) => Promise<any>,
    config: CircuitBreakerConfig,
    options: CircuitBreakerOptions
  ) {
    this.options = options;
    this.config = {
      failureThreshold: config.failureThreshold || 5,
      resetTimeout: config.resetTimeout || 60000,
      monitoringPeriod: config.monitoringPeriod || 10000,
      volumeThreshold: config.volumeThreshold || 10,
      timeout: config.timeout || 30000,
      errorTypes: config.errorTypes || [],
      successThreshold: config.successThreshold || 3,
      healthCheck: config.healthCheck,
      onStateChange: config.onStateChange,
      onSuccess: config.onSuccess,
      onFailure: config.onFailure,
      onCircuitTripped: config.onCircuitTripped
    };

    // Bind methods
    this.execute = this.execute.bind(this);
  }

  /**
   * Execute the protected operation
   */
  async execute(...args: any[]): Promise<CircuitBreakerResult<any>> {
    const startTime = Date.now();
    
    // Check if circuit is open
    if (this.state === CircuitBreakerState.OPEN) {
      if (this.shouldAttemptReset()) {
        this.transitionTo(CircuitBreakerState.HALF_OPEN);
      } else {
        this.blockedRequests++;
        this.recordEvent('REQUEST_BLOCKED', { reason: 'Circuit is open' });
        return {
          success: false,
          error: new Error(`Circuit breaker for ${this.options.name} is OPEN`),
          latency: Date.now() - startTime,
          circuitOpen: true,
          state: this.state
        };
      }
    }

    this.totalRequests++;

    try {
      // Set up timeout for the operation
      const timeoutPromise = new Promise<never>((_, reject) => {
        setTimeout(() => {
          reject(new Error(`Operation timed out after ${this.config.timeout}ms`));
        }, this.config.timeout);
      });

      // Execute the operation with timeout
      const result = await Promise.race([this.operation(...args), timeoutPromise]);
      const latency = Date.now() - startTime;

      this.handleSuccess(latency);
      
      return {
        data: result,
        success: true,
        latency,
        circuitOpen: false,
        state: this.state
      };

    } catch (error) {
      const latency = Date.now() - startTime;
      const err = error instanceof Error ? error : new Error(String(error));
      
      this.handleFailure(err, latency);
      
      return {
        error: err,
        success: false,
        latency,
        circuitOpen: false,
        state: this.state
      };
    }
  }

  /**
   * Handle successful operation
   */
  private handleSuccess(latency: number): void {
    this.successCount++;
    this.totalLatency += latency;
    this.lastSuccess = Date.now();
    this.currentSuccessStreak++;
    this.currentFailureStreak = 0;

    this.recordEvent('SUCCESS', { latency });

    // Handle state transitions
    if (this.state === CircuitBreakerState.HALF_OPEN) {
      if (this.currentSuccessStreak >= this.config.successThreshold) {
        this.transitionTo(CircuitBreakerState.CLOSED);
      }
    } else if (this.state === CircuitBreakerState.CLOSED) {
      // Reset counters periodically in closed state
      if (Date.now() - this.monitoringStartTime >= this.config.monitoringPeriod) {
        this.resetCounters();
      }
    }

    this.config.onSuccess?.(latency);
  }

  /**
   * Handle failed operation
   */
  private handleFailure(error: Error, latency: number): void {
    this.failureCount++;
    this.totalLatency += latency;
    this.lastFailure = Date.now();
    this.currentFailureStreak++;
    this.currentSuccessStreak = 0;

    this.recordEvent('FAILURE', { error: error.message, latency });

    // Check if this failure should trip the circuit
    const shouldTrip = this.shouldTripCircuit();
    
    if (shouldTrip) {
      this.tripCircuit(error);
    }

    // Handle state transitions based on failure thresholds
    if (this.state === CircuitBreakerState.HALF_OPEN) {
      this.transitionTo(CircuitBreakerState.OPEN);
    }

    this.config.onFailure?.(error, latency);
  }

  /**
   * Trip the circuit breaker (transition to OPEN state)
   */
  private tripCircuit(error: Error): void {
    if (this.state !== CircuitBreakerState.OPEN) {
      this.transitionTo(CircuitBreakerState.OPEN);
      this.totalTrips++;
      this.currentFailureStreak = 0;
      this.currentSuccessStreak = 0;
      
      this.recordEvent('CIRCUIT_TRIPPED', { error: error.message });
      
      // Schedule automatic reset attempt
      this.scheduleReset();
      
      this.config.onCircuitTripped?.(error);
    }
  }

  /**
   * Transition between states
   */
  private transitionTo(newState: CircuitBreakerState): void {
    const oldState = this.state;
    this.state = newState;
    this.lastStateChange = Date.now();

    if (newState === CircuitBreakerState.HALF_OPEN) {
      this.currentSuccessStreak = 0;
      this.currentFailureStreak = 0;
    }

    this.recordEvent('STATE_CHANGE', { from: oldState, to: newState });
    this.config.onStateChange?.(oldState, newState);
  }

  /**
   * Check if circuit should be tripped based on failure thresholds
   */
  private shouldTripCircuit(): boolean {
    // Check failure threshold
    if (this.failureCount >= this.config.failureThreshold) {
      return true;
    }

    // Check volume threshold (need minimum requests before considering failure rate)
    if (this.totalRequests >= this.config.volumeThreshold) {
      const failureRate = this.failureCount / this.totalRequests;
      if (failureRate >= 0.5) { // 50% failure rate
        return true;
      }
    }

    return false;
  }

  /**
   * Check if should attempt to reset the circuit
   */
  private shouldAttemptReset(): boolean {
    return Date.now() - this.lastStateChange >= this.config.resetTimeout;
  }

  /**
   * Schedule automatic circuit reset
   */
  private scheduleReset(): void {
    // Clear existing timeout
    if (this.resetTimeoutId) {
      clearTimeout(this.resetTimeoutId);
    }

    // Schedule reset attempt
    this.resetTimeoutId = setTimeout(async () => {
      if (this.config.healthCheck) {
        try {
          const isHealthy = await this.config.healthCheck();
          if (isHealthy) {
            this.transitionTo(CircuitBreakerState.HALF_OPEN);
          } else {
            // Schedule another attempt
            this.scheduleReset();
          }
        } catch (error) {
          // Health check failed, schedule another attempt
          this.scheduleReset();
        }
      } else {
        // No health check, automatically transition to half-open
        this.transitionTo(CircuitBreakerState.HALF_OPEN);
      }
    }, this.config.resetTimeout);
  }

  /**
   * Reset all counters and return to closed state
   */
  private resetCounters(): void {
    this.failureCount = 0;
    this.successCount = 0;
    this.totalRequests = 0;
    this.totalLatency = 0;
    this.currentFailureStreak = 0;
    this.currentSuccessStreak = 0;
    this.monitoringStartTime = Date.now();
  }

  /**
   * Get current metrics
   */
  getMetrics(): CircuitBreakerMetrics {
    const averageLatency = this.successCount > 0 ? this.totalLatency / this.successCount : 0;
    const successRate = this.totalRequests > 0 ? (this.successCount / this.totalRequests) * 100 : 0;

    return {
      state: this.state,
      successCount: this.successCount,
      failureCount: this.failureCount,
      totalRequests: this.totalRequests,
      successRate: Math.round(successRate * 100) / 100,
      averageLatency: Math.round(averageLatency),
      totalLatency: this.totalLatency,
      lastStateChange: this.lastStateChange,
      lastFailure: this.lastFailure,
      lastSuccess: this.lastSuccess,
      totalTrips: this.totalTrips,
      blockedRequests: this.blockedRequests,
      currentFailureStreak: this.currentFailureStreak,
      currentSuccessStreak: this.currentSuccessStreak
    };
  }

  /**
   * Get health status
   */
  getHealth(): HealthStatus {
    const metrics = this.getMetrics();
    
    // Determine overall health
    let healthy = true;
    let details: Record<string, any> = {};

    // Check circuit state
    if (this.state === CircuitBreakerState.OPEN) {
      healthy = false;
      details.circuitState = 'Circuit is open - requests are being blocked';
    }

    // Check failure rate
    if (metrics.successRate < 50) {
      healthy = false;
      details.successRate = `Success rate is ${metrics.successRate}%`;
    }

    // Check if circuit has tripped too frequently
    if (metrics.totalTrips > 10) {
      healthy = false;
      details.tripCount = `Circuit has tripped ${metrics.totalTrips} times`;
    }

    // Check latency
    if (metrics.averageLatency > this.config.timeout * 0.8) {
      details.latency = `Average latency is ${metrics.averageLatency}ms`;
    }

    return {
      healthy,
      state: this.state,
      metrics,
      timestamp: Date.now(),
      details: Object.keys(details).length > 0 ? details : undefined
    };
  }

  /**
   * Force transition to a specific state (for testing/management)
   */
  forceState(state: CircuitBreakerState): void {
    this.transitionTo(state);
    if (state === CircuitBreakerState.CLOSED) {
      this.resetCounters();
    }
  }

  /**
   * Get current state
   */
  getState(): CircuitBreakerState {
    return this.state;
  }

  /**
   * Get circuit breaker name
   */
  getName(): string {
    return this.options.name;
  }

  /**
   * Subscribe to circuit breaker events
   */
  onEvent(handler: (event: CircuitBreakerEvent) => void): void {
    this.eventHandlers.push(handler);
  }

  /**
   * Unsubscribe from circuit breaker events
   */
  offEvent(handler: (event: CircuitBreakerEvent) => void): void {
    this.eventHandlers = this.eventHandlers.filter(h => h !== handler);
  }

  /**
   * Record and emit an event
   */
  private recordEvent(type: CircuitBreakerEvent['type'], data: any): void {
    const event: CircuitBreakerEvent = {
      type,
      timestamp: Date.now(),
      data,
      name: this.options.name,
      state: this.state
    };

    this.eventHandlers.forEach(handler => {
      try {
        handler(event);
      } catch (error) {
        console.error(`Error in circuit breaker event handler:`, error);
      }
    });
  }

  /**
   * Reset the circuit breaker to initial state
   */
  reset(): void {
    this.state = CircuitBreakerState.CLOSED;
    this.failureCount = 0;
    this.successCount = 0;
    this.totalRequests = 0;
    this.totalLatency = 0;
    this.lastStateChange = Date.now();
    this.lastFailure = undefined;
    this.lastSuccess = undefined;
    this.totalTrips = 0;
    this.blockedRequests = 0;
    this.currentFailureStreak = 0;
    this.currentSuccessStreak = 0;
    this.monitoringStartTime = Date.now();

    // Clear timeouts
    if (this.resetTimeoutId) {
      clearTimeout(this.resetTimeoutId);
      this.resetTimeoutId = undefined;
    }

    if (this.healthCheckTimeoutId) {
      clearTimeout(this.healthCheckTimeoutId);
      this.healthCheckTimeoutId = undefined;
    }

    this.recordEvent('STATE_CHANGE', { from: this.state, to: CircuitBreakerState.CLOSED, manual: true });
  }

  /**
   * Cleanup resources
   */
  destroy(): void {
    this.reset();
    this.eventHandlers = [];
  }
}