/**
 * Circuit Breaker Dashboard and Monitoring
 * Provides a web interface for monitoring and managing circuit breakers
 */

import { createServer, Server } from 'http';
import { Router, Request, Response } from 'express';
import { WebSocketServer, WebSocket } from 'ws';
import {
  CircuitBreakerRegistry,
  getGlobalRegistry
} from './registry';
import {
  CircuitBreakerState,
  CircuitBreakerMetrics,
  HealthStatus,
  CircuitBreakerEvent,
  DashboardConfig
} from './types';

export class CircuitBreakerDashboard {
  private server: Server;
  private app: Router;
  private wss?: WebSocketServer;
  private clients = new Set<WebSocket>();
  private config: DashboardConfig;
  private registry: CircuitBreakerRegistry;
  private updateInterval?: NodeJS.Timeout;

  constructor(config: DashboardConfig, registry?: CircuitBreakerRegistry) {
    this.config = config;
    this.registry = registry || getGlobalRegistry();
    this.app = Router();
    
    this.setupRoutes();
    this.setupWebSocket();
    this.startPeriodicUpdates();
    
    this.server = createServer((req, res) => {
      this.handleRequest(req, res);
    });
  }

  /**
   * Start the dashboard server
   */
  async start(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.server.listen(this.config.port, this.config.host, (err?: Error) => {
        if (err) {
          reject(err);
        } else {
          console.log(`Circuit Breaker Dashboard running on http://${this.config.host}:${this.config.port}`);
          resolve();
        }
      });
    });
  }

  /**
   * Stop the dashboard server
   */
  stop(): void {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
    }
    
    // Close all WebSocket connections
    this.clients.forEach(client => {
      client.close();
    });
    
    this.server.close();
  }

  /**
   * Setup HTTP routes
   */
  private setupRoutes(): void {
    // Main dashboard page
    this.app.get('/', (req: Request, res: Response) => {
      res.setHeader('Content-Type', 'text/html');
      res.send(this.generateDashboardHTML());
    });

    // API endpoint for circuit breaker metrics
    this.app.get('/api/metrics', (req: Request, res: Response) => {
      const metrics = this.registry.getAllMetrics();
      res.json({
        timestamp: Date.now(),
        metrics
      });
    });

    // API endpoint for health status
    this.app.get('/api/health', (req: Request, res: Response) => {
      const health = this.registry.getAllHealth();
      res.json({
        timestamp: Date.now(),
        health
      });
    });

    // API endpoint for registry stats
    this.app.get('/api/stats', (req: Request, res: Response) => {
      const stats = this.registry.getStats();
      res.json({
        timestamp: Date.now(),
        stats
      });
    });

    // API endpoint for circuit breaker by state
    this.app.get('/api/state/:state', (req: Request, res: Response) => {
      const state = req.params.state as CircuitBreakerState;
      if (!Object.values(CircuitBreakerState).includes(state)) {
        return res.status(400).json({ error: 'Invalid state' });
      }
      
      const breakers = this.registry.getByState(state);
      res.json({
        timestamp: Date.now(),
        state,
        breakers: breakers.map(cb => ({
          name: cb.name,
          metrics: cb.breaker.getMetrics()
        }))
      });
    });

    // API endpoint for unhealthy circuit breakers
    this.app.get('/api/unhealthy', (req: Request, res: Response) => {
      const unhealthy = this.registry.getUnhealthy();
      res.json({
        timestamp: Date.now(),
        unhealthy: unhealthy.map(cb => ({
          name: cb.name,
          health: cb.health
        }))
      });
    });

    // API endpoint for circuit breaker events
    this.app.get('/api/events', (req: Request, res: Response) => {
      const limit = parseInt(req.query.limit as string) || 100;
      // In a real implementation, you would store and retrieve events
      // For now, return empty array
      res.json({
        timestamp: Date.now(),
        events: []
      });
    });

    // API endpoint to reset a circuit breaker
    this.app.post('/api/reset/:name', (req: Request, res: Response) => {
      const name = req.params.name;
      const success = this.registry.forceState(name, CircuitBreakerState.CLOSED);
      
      if (success) {
        res.json({
          success: true,
          message: `Circuit breaker ${name} reset successfully`
        });
      } else {
        res.status(404).json({
          success: false,
          message: `Circuit breaker ${name} not found`
        });
      }
    });

    // API endpoint to force state change
    this.app.post('/api/state/:name', (req: Request, res: Response) => {
      const name = req.params.name;
      const { state } = req.body;
      
      if (!Object.values(CircuitBreakerState).includes(state)) {
        return res.status(400).json({ error: 'Invalid state' });
      }
      
      const success = this.registry.forceState(name, state);
      
      if (success) {
        res.json({
          success: true,
          message: `Circuit breaker ${name} state changed to ${state}`
        });
      } else {
        res.status(404).json({
          success: false,
          message: `Circuit breaker ${name} not found`
        });
      }
    });

    // API endpoint to reset all circuit breakers
    this.app.post('/api/reset-all', (req: Request, res: Response) => {
      this.registry.resetAll();
      res.json({
        success: true,
        message: 'All circuit breakers reset successfully'
      });
    });

    // Serve static assets (CSS, JS, etc.)
    this.app.get('/static/:file', (req: Request, res: Response) => {
      const file = req.params.file;
      res.sendFile(`${__dirname}/static/${file}`);
    });
  }

  /**
   * Setup WebSocket server for real-time updates
   */
  private setupWebSocket(): void {
    if (!this.config.enableWebSocket) return;

    this.wss = new WebSocketServer({ 
      server: this.server,
      path: '/ws'
    });

    this.wss.on('connection', (ws: WebSocket) => {
      this.clients.add(ws);
      
      // Send initial data
      this.sendToClient(ws, {
        type: 'initial',
        data: {
          metrics: this.registry.getAllMetrics(),
          health: this.registry.getAllHealth(),
          stats: this.registry.getStats()
        }
      });

      ws.on('close', () => {
        this.clients.delete(ws);
      });

      ws.on('error', (error) => {
        console.error('WebSocket error:', error);
        this.clients.delete(ws);
      });
    });

    // Subscribe to circuit breaker events
    this.registry.onEvent((event) => {
      this.broadcastToClients({
        type: 'event',
        data: event
      });
    });
  }

  /**
   * Start periodic updates for dashboard
   */
  private startPeriodicUpdates(): void {
    this.updateInterval = setInterval(() => {
      this.broadcastToClients({
        type: 'update',
        data: {
          metrics: this.registry.getAllMetrics(),
          health: this.registry.getAllHealth(),
          stats: this.registry.getStats(),
          timestamp: Date.now()
        }
      });
    }, this.config.updateInterval);
  }

  /**
   * Handle HTTP requests
   */
  private handleRequest(req: any, res: any): void {
    // Authentication middleware
    if (this.config.auth?.enabled) {
      const authHeader = req.headers.authorization;
      if (!authHeader || !this.isAuthorized(authHeader)) {
        res.writeHead(401, { 'WWW-Authenticate': 'Basic realm="Circuit Breaker Dashboard"' });
        res.end('Unauthorized');
        return;
      }
    }

    this.app(req, res);
  }

  /**
   * Check if request is authorized
   */
  private isAuthorized(authHeader: string): boolean {
    if (!this.config.auth?.enabled) return true;

    const [type, credentials] = authHeader.split(' ');
    if (type !== 'Basic') return false;

    const [username, password] = Buffer.from(credentials, 'base64')
      .toString()
      .split(':');

    return username === this.config.auth.username && password === this.config.auth.password;
  }

  /**
   * Send data to a specific WebSocket client
   */
  private sendToClient(ws: WebSocket, data: any): void {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(data));
    }
  }

  /**
   * Broadcast data to all WebSocket clients
   */
  private broadcastToClients(data: any): void {
    if (!this.wss) return;

    const message = JSON.stringify(data);
    this.clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  /**
   * Generate the dashboard HTML
   */
  private generateDashboardHTML(): string {
    return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Circuit Breaker Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }

        .header {
            background-color: #2c3e50;
            color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .header h1 {
            display: inline-block;
            margin-right: 2rem;
        }

        .stats {
            display: inline-block;
            margin-right: 2rem;
        }

        .stats span {
            background-color: rgba(255,255,255,0.1);
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            margin-right: 0.5rem;
        }

        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }

        .section {
            background: white;
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .section h2 {
            margin-bottom: 1rem;
            color: #2c3e50;
            border-bottom: 2px solid #3498db;
            padding-bottom: 0.5rem;
        }

        .filter-bar {
            margin-bottom: 1rem;
        }

        .filter-bar select {
            padding: 0.5rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-right: 1rem;
        }

        .circuit-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1rem;
        }

        .circuit-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 1rem;
            transition: transform 0.2s;
        }

        .circuit-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }

        .circuit-card.closed {
            border-left: 4px solid #27ae60;
        }

        .circuit-card.open {
            border-left: 4px solid #e74c3c;
        }

        .circuit-card.half-open {
            border-left: 4px solid #f39c12;
        }

        .circuit-name {
            font-weight: bold;
            font-size: 1.1rem;
            margin-bottom: 0.5rem;
        }

        .circuit-state {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.8rem;
            font-weight: bold;
            color: white;
            margin-bottom: 0.5rem;
        }

        .circuit-state.closed {
            background-color: #27ae60;
        }

        .circuit-state.open {
            background-color: #e74c3c;
        }

        .circuit-state.half-open {
            background-color: #f39c12;
        }

        .circuit-metrics {
            font-size: 0.9rem;
            color: #666;
        }

        .circuit-metrics div {
            margin-bottom: 0.25rem;
        }

        .action-buttons {
            margin-top: 1rem;
        }

        .btn {
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 0.5rem;
            font-size: 0.9rem;
        }

        .btn-primary {
            background-color: #3498db;
            color: white;
        }

        .btn-warning {
            background-color: #f39c12;
            color: white;
        }

        .btn-danger {
            background-color: #e74c3c;
            color: white;
        }

        .btn:hover {
            opacity: 0.8;
        }

        .refresh-status {
            font-size: 0.8rem;
            color: #666;
            margin-top: 1rem;
        }

        .alert {
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
        }

        .alert-warning {
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            color: #856404;
        }

        .alert-danger {
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }

        .loading {
            text-align: center;
            padding: 2rem;
            color: #666;
        }

        .real-time-indicator {
            display: inline-block;
            width: 8px;
            height: 8px;
            background-color: #27ae60;
            border-radius: 50%;
            margin-left: 0.5rem;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Circuit Breaker Dashboard</h1>
        <div class="stats">
            <span id="totalBreakers">0</span> Total
            <span id="closedCount">0</span> Closed
            <span id="openCount">0</span> Open
            <span id="halfOpenCount">0</span> Half-Open
            <span class="real-time-indicator"></span>
        </div>
    </div>

    <div class="container">
        <div class="section">
            <h2>Filter and Controls</h2>
            <div class="filter-bar">
                <select id="stateFilter">
                    <option value="all">All States</option>
                    <option value="CLOSED">Closed</option>
                    <option value="OPEN">Open</option>
                    <option value="HALF_OPEN">Half-Open</option>
                </select>
                <button class="btn btn-primary" onclick="refreshData()">Refresh</button>
                <button class="btn btn-warning" onclick="resetAll()">Reset All</button>
            </div>
        </div>

        <div class="section">
            <h2>Circuit Breakers</h2>
            <div id="circuitGrid" class="circuit-grid">
                <div class="loading">Loading circuit breakers...</div>
            </div>
            <div class="refresh-status" id="refreshStatus">
                Last updated: <span id="lastUpdated">Never</span>
            </div>
        </div>

        <div class="section">
            <h2>Unhealthy Circuit Breakers</h2>
            <div id="unhealthyList">
                <div class="loading">Loading unhealthy circuit breakers...</div>
            </div>
        </div>
    </div>

    <script>
        let circuitData = {};
        let healthData = {};
        let isRealTimeEnabled = ${this.config.enableWebSocket ? 'true' : 'false'};

        // Initialize dashboard
        document.addEventListener('DOMContentLoaded', function() {
            loadDashboardData();
            if (isRealTimeEnabled) {
                initWebSocket();
            }
        });

        // Load dashboard data
        async function loadDashboardData() {
            try {
                await Promise.all([
                    loadMetrics(),
                    loadHealth(),
                    loadStats(),
                    loadUnhealthy()
                ]);
                updateLastUpdated();
            } catch (error) {
                console.error('Error loading dashboard data:', error);
            }
        }

        // Load circuit breaker metrics
        async function loadMetrics() {
            const response = await fetch('/api/metrics');
            const data = await response.json();
            circuitData = data.metrics;
            renderCircuitBreakers();
        }

        // Load health status
        async function loadHealth() {
            const response = await fetch('/api/health');
            const data = await response.json();
            healthData = data.health;
        }

        // Load registry stats
        async function loadStats() {
            const response = await fetch('/api/stats');
            const data = await response.json();
            updateStats(data.stats);
        }

        // Load unhealthy circuit breakers
        async function loadUnhealthy() {
            const response = await fetch('/api/unhealthy');
            const data = await response.json();
            renderUnhealthy(data.unhealthy);
        }

        // Update statistics display
        function updateStats(stats) {
            document.getElementById('totalBreakers').textContent = stats.totalBreakers;
            document.getElementById('closedCount').textContent = stats.stateCounts.CLOSED || 0;
            document.getElementById('openCount').textContent = stats.stateCounts.OPEN || 0;
            document.getElementById('halfOpenCount').textContent = stats.stateCounts.HALF_OPEN || 0;
        }

        // Render circuit breakers
        function renderCircuitBreakers() {
            const grid = document.getElementById('circuitGrid');
            const filter = document.getElementById('stateFilter').value;
            
            let filteredData = circuitData;
            if (filter !== 'all') {
                filteredData = Object.fromEntries(
                    Object.entries(circuitData).filter(([name, metrics]) => metrics.state === filter)
                );
            }

            if (Object.keys(filteredData).length === 0) {
                grid.innerHTML = '<div class="loading">No circuit breakers found</div>';
                return;
            }

            grid.innerHTML = Object.entries(filteredData)
                .map(([name, metrics]) => createCircuitCard(name, metrics))
                .join('');
        }

        // Create circuit breaker card HTML
        function createCircuitCard(name, metrics) {
            const stateClass = metrics.state.toLowerCase();
            const successRate = metrics.successRate.toFixed(1);
            
            return \`
                <div class="circuit-card \${stateClass}">
                    <div class="circuit-name">\${name}</div>
                    <div class="circuit-state \${stateClass}">\${metrics.state}</div>
                    <div class="circuit-metrics">
                        <div>Success Rate: \${successRate}%</div>
                        <div>Total Requests: \${metrics.totalRequests}</div>
                        <div>Successes: \${metrics.successCount}</div>
                        <div>Failures: \${metrics.failureCount}</div>
                        <div>Avg Latency: \${metrics.averageLatency}ms</div>
                        <div>Blocked Requests: \${metrics.blockedRequests}</div>
                        <div>Circuit Trips: \${metrics.totalTrips}</div>
                    </div>
                    <div class="action-buttons">
                        <button class="btn btn-primary" onclick="resetCircuit('\${name}')">Reset</button>
                        <button class="btn btn-warning" onclick="forceHalfOpen('\${name}')">Half-Open</button>
                    </div>
                </div>
            \`;
        }

        // Render unhealthy circuit breakers
        function renderUnhealthy(unhealthy) {
            const container = document.getElementById('unhealthyList');
            
            if (unhealthy.length === 0) {
                container.innerHTML = '<div class="alert alert-success">All circuit breakers are healthy!</div>';
                return;
            }

            container.innerHTML = unhealthy.map(cb => \`
                <div class="alert alert-danger">
                    <strong>\${cb.name}</strong> - \${cb.health.details ? Object.values(cb.health.details).join(', ') : 'Unhealthy'}
                    <button class="btn btn-primary" onclick="resetCircuit('\${cb.name}')" style="float: right;">Reset</button>
                </div>
            \`).join('');
        }

        // Reset individual circuit breaker
        async function resetCircuit(name) {
            try {
                const response = await fetch(\`/api/reset/\${name}\`, { method: 'POST' });
                const result = await response.json();
                if (result.success) {
                    loadDashboardData();
                }
            } catch (error) {
                console.error('Error resetting circuit breaker:', error);
            }
        }

        // Force circuit breaker to half-open state
        async function forceHalfOpen(name) {
            try {
                const response = await fetch(\`/api/state/\${name}\`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ state: 'HALF_OPEN' })
                });
                const result = await response.json();
                if (result.success) {
                    loadDashboardData();
                }
            } catch (error) {
                console.error('Error changing circuit breaker state:', error);
            }
        }

        // Reset all circuit breakers
        async function resetAll() {
            try {
                const response = await fetch('/api/reset-all', { method: 'POST' });
                const result = await response.json();
                if (result.success) {
                    loadDashboardData();
                }
            } catch (error) {
                console.error('Error resetting all circuit breakers:', error);
            }
        }

        // Refresh dashboard data
        function refreshData() {
            loadDashboardData();
        }

        // Update last updated timestamp
        function updateLastUpdated() {
            document.getElementById('lastUpdated').textContent = new Date().toLocaleTimeString();
        }

        // Initialize WebSocket connection for real-time updates
        function initWebSocket() {
            const ws = new WebSocket(\`ws://\${window.location.host}/ws\`);
            
            ws.onmessage = function(event) {
                const data = JSON.parse(event.data);
                
                if (data.type === 'update') {
                    circuitData = data.data.metrics;
                    healthData = data.data.health;
                    updateStats(data.data.stats);
                    renderCircuitBreakers();
                    renderUnhealthy(Object.entries(healthData)
                        .filter(([name, health]) => !health.healthy)
                        .map(([name, health]) => ({ name, health })));
                    updateLastUpdated();
                } else if (data.type === 'event') {
                    console.log('Circuit breaker event:', data.data);
                }
            };

            ws.onclose = function() {
                console.log('WebSocket connection closed. Reconnecting in 5 seconds...');
                setTimeout(initWebSocket, 5000);
            };

            ws.onerror = function(error) {
                console.error('WebSocket error:', error);
            };
        }

        // Filter change handler
        document.getElementById('stateFilter').addEventListener('change', renderCircuitBreakers);

        // Auto-refresh every 30 seconds if WebSocket is not enabled
        \${!this.config.enableWebSocket ? 'setInterval(refreshData, 30000);' : ''}
    </script>
</body>
</html>`;
  }
}

/**
 * Create and start a circuit breaker dashboard
 */
export async function startDashboard(
  config: DashboardConfig,
  registry?: CircuitBreakerRegistry
): Promise<CircuitBreakerDashboard> {
  const dashboard = new CircuitBreakerDashboard(config, registry);
  await dashboard.start();
  return dashboard;
}