/**
 * Circuit Breaker Utility Functions
 * Provides convenient utilities for common circuit breaker patterns
 */

import {
  CircuitBreakerConfig,
  CircuitBreakerOptions,
  CircuitBreakerResult,
  CircuitBreakerState
} from './types';
import { CircuitBreaker } from './circuit-breaker';

/**
 * Create a simple circuit breaker with sensible defaults
 */
export function createSimpleCircuitBreaker<T>(
  operation: (...args: any[]) => Promise<T>,
  name: string,
  config?: Partial<CircuitBreakerConfig>
): CircuitBreaker {
  const defaultConfig: CircuitBreakerConfig = {
    failureThreshold: 5,
    resetTimeout: 60000,
    monitoringPeriod: 10000,
    volumeThreshold: 10,
    timeout: 30000
  };

  const options: CircuitBreakerOptions = {
    name,
    service: 'default'
  };

  return new CircuitBreaker(operation, { ...defaultConfig, ...config }, options);
}

/**
 * Execute a function with automatic retry and circuit breaker protection
 */
export async function executeWithRetry<T>(
  operation: (...args: any[]) => Promise<T>,
  maxRetries: number = 3,
  retryDelay: number = 1000,
  config?: Partial<CircuitBreakerConfig>
): Promise<T> {
  let lastError: Error;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      
      if (attempt < maxRetries) {
        await new Promise(resolve => setTimeout(resolve, retryDelay * Math.pow(2, attempt)));
      }
    }
  }

  throw lastError!;
}

/**
 * Execute multiple operations in parallel with circuit breaker protection
 */
export async function executeParallel<T>(
  operations: Array<() => Promise<T>>,
  circuitConfig?: Partial<CircuitBreakerConfig>
): Promise<Array<CircuitBreakerResult<T>>> {
  const results = await Promise.allSettled(
    operations.map((operation, index) => {
      const breaker = createSimpleCircuitBreaker(operation, `parallel-${index}`, circuitConfig);
      return breaker.execute();
    })
  );

  return results.map(result => {
    if (result.status === 'fulfilled') {
      return result.value;
    } else {
      return {
        success: false,
        error: result.reason,
        latency: 0,
        circuitOpen: false,
        state: CircuitBreakerState.CLOSED
      } as CircuitBreakerResult<T>;
    }
  });
}

/**
 * Create a circuit breaker-protected timeout wrapper
 */
export function withTimeout<T>(
  operation: (...args: any[]) => Promise<T>,
  timeoutMs: number,
  timeoutMessage?: string
): (...args: any[]) => Promise<T> {
  return async (...args: any[]): Promise<T> => {
    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        reject(new Error(timeoutMessage || `Operation timed out after ${timeoutMs}ms`));
      }, timeoutMs);

      operation(...args)
        .then(result => {
          clearTimeout(timeoutId);
          resolve(result);
        })
        .catch(error => {
          clearTimeout(timeoutId);
          reject(error);
        });
    });
  };
}

/**
 * Create a circuit breaker-protected rate limiter
 */
export function createRateLimitedCircuitBreaker<T>(
  operation: (...args: any[]) => Promise<T>,
  maxCalls: number,
  timeWindow: number,
  name: string
): CircuitBreaker {
  let callCount = 0;
  let resetTime = Date.now() + timeWindow;

  const rateLimitedOperation = async (...args: any[]): Promise<T> => {
    const now = Date.now();
    
    if (now > resetTime) {
      callCount = 0;
      resetTime = now + timeWindow;
    }

    if (callCount >= maxCalls) {
      throw new Error(`Rate limit exceeded: ${maxCalls} calls per ${timeWindow}ms`);
    }

    callCount++;
    return operation(...args);
  };

  return createSimpleCircuitBreaker(rateLimitedOperation, name, {
    timeout: 5000
  });
}

/**
 * Create a circuit breaker for HTTP requests
 */
export function createHttpCircuitBreaker(
  baseURL: string,
  defaultOptions?: RequestInit
): {
  get: (path: string, options?: RequestInit) => Promise<Response>;
  post: (path: string, data?: any, options?: RequestInit) => Promise<Response>;
  put: (path: string, data?: any, options?: RequestInit) => Promise<Response>;
  delete: (path: string, options?: RequestInit) => Promise<Response>;
} {
  const breaker = createSimpleCircuitBreaker(
    async (url: string, options?: RequestInit) => {
      const response = await fetch(url, {
        ...defaultOptions,
        ...options
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      return response;
    },
    `http-${baseURL}`,
    {
      timeout: 10000,
      failureThreshold: 3,
      resetTimeout: 30000
    }
  );

  return {
    get: async (path: string, options?: RequestInit) => {
      const result = await breaker.execute(`${baseURL}${path}`, {
        method: 'GET',
        ...options
      });
      return result.data!;
    },
    post: async (path: string, data?: any, options?: RequestInit) => {
      const result = await breaker.execute(`${baseURL}${path}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...options?.headers
        },
        body: data ? JSON.stringify(data) : undefined,
        ...options
      });
      return result.data!;
    },
    put: async (path: string, data?: any, options?: RequestInit) => {
      const result = await breaker.execute(`${baseURL}${path}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...options?.headers
        },
        body: data ? JSON.stringify(data) : undefined,
        ...options
      });
      return result.data!;
    },
    delete: async (path: string, options?: RequestInit) => {
      const result = await breaker.execute(`${baseURL}${path}`, {
        method: 'DELETE',
        ...options
      });
      return result.data!;
    }
  };
}

/**
 * Create a circuit breaker for database operations
 */
export function createDatabaseCircuitBreaker<T>(
  operation: (...args: any[]) => Promise<T>,
  connectionName: string = 'default'
): CircuitBreaker {
  return createSimpleCircuitBreaker(operation, `db-${connectionName}`, {
    timeout: 5000,
    failureThreshold: 3,
    resetTimeout: 30000
  });
}

/**
 * Create a circuit breaker for external API calls
 */
export function createApiCircuitBreaker<T>(
  operation: (...args: any[]) => Promise<T>,
  apiName: string
): CircuitBreaker {
  return createSimpleCircuitBreaker(operation, `api-${apiName}`, {
    timeout: 30000,
    failureThreshold: 3,
    resetTimeout: 60000,
    volumeThreshold: 5
  });
}

/**
 * Bulkhead pattern implementation with circuit breakers
 */
export class BulkheadCircuitBreaker {
  private readonly maxConcurrent: number;
  private readonly timeout: number;
  private currentOperations = 0;
  private queue: Array<{ operation: () => Promise<any>; resolve: Function; reject: Function }> = [];

  constructor(
    maxConcurrent: number = 10,
    timeout: number = 30000
  ) {
    this.maxConcurrent = maxConcurrent;
    this.timeout = timeout;
  }

  /**
   * Execute operation with bulkhead protection
   */
  async execute<T>(operation: () => Promise<T>): Promise<T> {
    return new Promise((resolve, reject) => {
      this.queue.push({ operation, resolve, reject });
      this.processQueue();
    });
  }

  /**
   * Process queued operations
   */
  private processQueue(): void {
    while (this.currentOperations < this.maxConcurrent && this.queue.length > 0) {
      const { operation, resolve, reject } = this.queue.shift()!;
      this.currentOperations++;

      Promise.race([
        operation(),
        new Promise((_, timeoutReject) => 
          setTimeout(() => timeoutReject(new Error(`Bulkhead timeout after ${this.timeout}ms`)), this.timeout)
        )
      ])
      .then(resolve)
      .catch(reject)
      .finally(() => {
        this.currentOperations--;
        this.processQueue();
      });
    }
  }

  /**
   * Get bulkhead statistics
   */
  getStats() {
    return {
      maxConcurrent: this.maxConcurrent,
      currentOperations: this.currentOperations,
      queuedOperations: this.queue.length,
      availableSlots: Math.max(0, this.maxConcurrent - this.currentOperations)
    };
  }
}

/**
 * Circuit breaker for async iterables (streaming data)
 */
export function createStreamingCircuitBreaker<T, R>(
  operation: (item: T) => Promise<R>,
  circuitConfig?: Partial<CircuitBreakerConfig>
) {
  const breaker = createSimpleCircuitBreaker(operation, `streaming-${Date.now()}`, {
    ...circuitConfig,
    failureThreshold: 2, // More sensitive for streaming
    resetTimeout: 10000
  });

  return async function* processStream(iterable: AsyncIterable<T>): AsyncGenerator<R, void, unknown> {
    for await (const item of iterable) {
      try {
        const result = await breaker.execute(() => operation(item));
        yield result.data!;
      } catch (error) {
        // For streaming, we might want to skip failed items rather than stop entirely
        console.error('Streaming operation failed for item:', item, error);
        continue;
      }
    }
  };
}

/**
 * Circuit breaker with circuit breaker pattern for caching
 */
export function createCachedCircuitBreaker<T>(
  operation: (...args: any[]) => Promise<T>,
  getCacheKey: (...args: any[]) => string,
  cacheDuration: number = 60000,
  circuitConfig?: Partial<CircuitBreakerConfig>
): CircuitBreaker {
  const cache = new Map<string, { data: T; timestamp: number }>();
  const breaker = createSimpleCircuitBreaker(
    async (...args: any[]) => {
      const cacheKey = getCacheKey(...args);
      const cached = cache.get(cacheKey);

      if (cached && Date.now() - cached.timestamp < cacheDuration) {
        return cached.data;
      }

      const result = await operation(...args);
      cache.set(cacheKey, { data: result, timestamp: Date.now() });
      return result;
    },
    `cached-${Date.now()}`,
    circuitConfig
  );

  return breaker;
}

/**
 * Circuit breaker health checker
 */
export async function checkCircuitBreakerHealth(
  circuit: CircuitBreaker
): Promise<{
  healthy: boolean;
  state: CircuitBreakerState;
  metrics: any;
  recommendations: string[];
}> {
  const metrics = circuit.getMetrics();
  const recommendations: string[] = [];

  // Check overall health
  let healthy = true;

  if (metrics.state === CircuitBreakerState.OPEN) {
    healthy = false;
    recommendations.push('Circuit breaker is open - service is experiencing high failure rates');
  }

  if (metrics.successRate < 50) {
    healthy = false;
    recommendations.push('Low success rate detected - consider investigating underlying issues');
  }

  if (metrics.averageLatency > 10000) {
    recommendations.push('High latency detected - consider increasing timeout or optimizing service');
  }

  if (metrics.totalTrips > 5) {
    recommendations.push('Frequent circuit trips detected - service may need scaling or fixes');
  }

  return {
    healthy,
    state: metrics.state,
    metrics,
    recommendations
  };
}

/**
 * Generate circuit breaker configuration based on service characteristics
 */
export function generateCircuitBreakerConfig(serviceType: 'fast' | 'slow' | 'unreliable' | 'critical'): CircuitBreakerConfig {
  const configs = {
    fast: {
      failureThreshold: 5,
      resetTimeout: 30000,
      monitoringPeriod: 5000,
      volumeThreshold: 20,
      timeout: 5000
    },
    slow: {
      failureThreshold: 3,
      resetTimeout: 60000,
      monitoringPeriod: 15000,
      volumeThreshold: 5,
      timeout: 30000
    },
    unreliable: {
      failureThreshold: 3,
      resetTimeout: 120000,
      monitoringPeriod: 20000,
      volumeThreshold: 3,
      timeout: 45000
    },
    critical: {
      failureThreshold: 2,
      resetTimeout: 30000,
      monitoringPeriod: 10000,
      volumeThreshold: 2,
      timeout: 10000
    }
  };

  return configs[serviceType];
}