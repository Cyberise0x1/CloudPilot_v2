# Secrets Management System Documentation

**Version:** 2.0  
**Last Updated:** October 31, 2025  
**Status:** ✅ Production Ready

---

## Table of Contents

1. [System Overview](#system-overview)
2. [Environment Variable Reference](#environment-variable-reference)
3. [Setup Instructions](#setup-instructions)
4. [Rotation Configuration](#rotation-configuration)
5. [Security Best Practices](#security-best-practices)
6. [Troubleshooting Guide](#troubleshooting-guide)
7. [Migration from Legacy System](#migration-from-legacy-system)
8. [API Reference](#api-reference)
9. [Examples](#examples)

---

## System Overview

The Secrets Management System is a comprehensive solution for handling sensitive configuration data, credentials, and API keys across the CloudPilot application. It provides:

### Core Features

- **🔐 Centralized Secret Management**: Unified interface for all secrets and configuration values
- **✅ Validation**: Built-in validation for common secret types (AWS keys, database URLs, JWT secrets, etc.)
- **📦 Caching**: Intelligent caching with change detection and staleness indicators
- **🔄 Automated Rotation**: Scheduled rotation of secrets with rollback capabilities
- **📊 Monitoring**: Real-time monitoring and audit logging
- **🔔 Notifications**: Multi-channel notifications (webhook, Slack, email)
- **🛡️ Security**: No hardcoded credentials, environment isolation, and secure defaults

### Architecture

```
┌─────────────────────────────────────────────────────────┐
│                   Client Application                    │
└─────────────────────┬───────────────────────────────────┘
                      │
┌─────────────────────▼───────────────────────────────────┐
│              Enhanced Secrets Manager                    │
│  ┌─────────────────┐    ┌──────────────────────┐       │
│  │ Secrets Manager │    │  Rotation Service    │       │
│  │                 │    │                      │       │
│  │ • Validation    │    │ • Scheduling         │       │
│  │ • Caching       │    │ • Notifications      │       │
│  │ • Change Events │    │ • Audit Logging      │       │
│  │ • Metadata      │    │ • Rollback           │       │
│  └─────────────────┘    └──────────────────────┘       │
└─────────────────────┬───────────────────────────────────┘
                      │
┌─────────────────────▼───────────────────────────────────┐
│              Environment Variables                      │
│  (process.env)                                         │
└─────────────────────────────────────────────────────────┘
```

### Components

#### 1. Secrets Manager (`SecretsManager`)

The core component that manages environment variables with validation, caching, and change detection.

**Key Responsibilities:**
- Load and validate environment variables
- Cache secrets with metadata
- Detect secret changes
- Validate against predefined rules
- Emit change events
- Provide statistics and monitoring

#### 2. Rotation Service (`SecretsRotationService`)

Manages automated rotation of secrets with scheduling, notifications, and audit trails.

**Key Responsibilities:**
- Schedule secret rotations
- Manage rotation intervals
- Handle rotation failures and rollbacks
- Send notifications
- Maintain audit logs
- Provide rotation status

#### 3. Enhanced Integration

Combines both services for a complete secrets management solution.

---

## Environment Variable Reference

### Required Variables

These variables must be set in all environments:

| Variable | Type | Description | Validation | Example |
|----------|------|-------------|------------|---------|
| `NODE_ENV` | string | Environment mode | Must be 'development', 'production', or 'test' | `production` |
| `DATABASE_URL` | string | Database connection string | Must match database URL pattern | `postgresql://user:pass@host:5432/db` |
| `JWT_SECRET` | string | JWT signing secret | Minimum 32 characters | `your-secure-32-char-secret-key` |

### Optional Variables

#### AWS Configuration
| Variable | Type | Description | Validation | Example |
|----------|------|-------------|------------|---------|
| `AWS_ACCESS_KEY_ID` | string | AWS access key | Must match AWS format (20 chars, starts with AKIA/ASIA) | `AKIAIOSFODNN7EXAMPLE` |
| `AWS_SECRET_ACCESS_KEY` | string | AWS secret key | Exactly 40 characters | `wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY` |
| `AWS_REGION` | string | AWS region | Valid AWS region | `us-east-1` |
| `AWS_DEFAULT_REGION` | string | AWS default region | Valid AWS region | `us-east-1` |

#### JWT Configuration
| Variable | Type | Description | Validation | Example |
|----------|------|-------------|------------|---------|
| `JWT_EXPIRES_IN` | string | JWT expiration time | Valid time format | `24h`, `7d` |
| `JWT_REFRESH_TOKEN_SECRET` | string | Refresh token secret | Minimum 32 characters | `separate-refresh-secret` |

#### Redis Configuration
| Variable | Type | Description | Validation | Example |
|----------|------|-------------|------------|---------|
| `REDIS_URL` | string | Redis connection URL | Must be valid URL | `redis://localhost:6379` |

#### SMTP Configuration
| Variable | Type | Description | Validation | Example |
|----------|------|-------------|------------|---------|
| `SMTP_HOST` | string | SMTP server host | Valid hostname or IP | `smtp.gmail.com` |
| `SMTP_PORT` | number | SMTP port | Positive number | `587`, `465`, `25` |
| `SMTP_USER` | string | SMTP username | Non-empty string | `your-email@gmail.com` |
| `SMTP_PASSWORD` | string | SMTP password | Non-empty string | `your-app-password` |

#### Application Configuration
| Variable | Type | Description | Default | Example |
|----------|------|-------------|---------|---------|
| `PORT` | number | Server port | `3000` | `3000`, `8080` |
| `API_KEY` | string | External API key | - | `your-api-key-here` |
| `ENCRYPTION_KEY` | string | Data encryption key | - | `your-32-char-encryption-key` |

### Validation Rules

The system enforces the following validation rules:

#### AWS Access Key
- **Pattern**: `^[A-Z0-9]{20}$`
- **Prefix**: Must start with `AKIA` or `ASIA`
- **Example**: `AKIAIOSFODNN7EXAMPLE`

#### AWS Secret Key
- **Pattern**: `^[A-Za-z0-9/+=]{40}$`
- **Length**: Exactly 40 characters
- **Example**: `wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY`

#### Database URL
- **Pattern**: `^(postgresql|mysql|mongodb|redis)://[^:]+:[^@]+@[^:]+:\d+/[^?]+(\?.*)?$`
- **Components**: Must include protocol, username, password, host, port, and database
- **Example**: `postgresql://user:password@localhost:5432/mydb`

#### JWT Secret
- **Pattern**: `^[A-Za-z0-9._-]{32,}$`
- **Length**: Minimum 32 characters
- **Example**: `your-secure-jwt-secret-key-32-chars-min`

#### Email
- **Pattern**: `^[^\s@]+@[^\s@]+\.[^\s@]+$`
- **Example**: `user@example.com`

#### URL
- **Pattern**: `^https?://[^\s/$.?#].[^\s]*$`
- **Protocol**: Must start with `http://` or `https://`
- **Example**: `https://api.example.com`

---

## Setup Instructions

### 1. Basic Setup

#### Step 1: Install Dependencies

```bash
npm install
# or
pnpm install
```

#### Step 2: Create Environment File

```bash
# Copy the example file
cp .env.example .env

# Edit with your actual values
nano .env
```

#### Step 3: Configure Required Secrets

Edit `.env` file with your actual values:

```env
# Required
NODE_ENV=production
DATABASE_URL=postgresql://username:password@localhost:5432/database
JWT_SECRET=your-very-secure-jwt-secret-min-32-chars

# Optional
AWS_ACCESS_KEY_ID=AKIA...
AWS_SECRET_ACCESS_KEY=...
AWS_REGION=us-east-1
PORT=3000
```

#### Step 4: Initialize Secrets Manager

```typescript
import { secretsManager } from './server/secrets-manager';

async function initializeApp() {
  try {
    await secretsManager.initialize();
    console.log('✅ Secrets Manager initialized');
  } catch (error) {
    console.error('❌ Failed to initialize:', error);
    process.exit(1);
  }
}

initializeApp();
```

### 2. Advanced Setup with Rotation

#### Step 1: Import Required Modules

```typescript
import {
  EnhancedSecretsManager,
  EXTENDED_SECRET_CONFIGS
} from './server/integration-rotation';
```

#### Step 2: Configure Extended Secrets

```typescript
// Customize the configuration for your needs
const customConfigs = EXTENDED_SECRET_CONFIGS.map(config => ({
  ...config,
  rotationInterval: config.key === 'JWT_SECRET' ? 7 : 30, // JWT rotates every 7 days
}));
```

#### Step 3: Initialize Enhanced Manager

```typescript
async function initializeEnhancedSecrets() {
  const enhancedManager = new EnhancedSecretsManager(secretsManager);
  
  try {
    await enhancedManager.initialize(customConfigs);
    console.log('✅ Enhanced Secrets Manager initialized with rotation');
  } catch (error) {
    console.error('❌ Initialization failed:', error);
    process.exit(1);
  }
  
  return enhancedManager;
}
```

#### Step 4: Set Up Monitoring

```typescript
import { eventEmitter } from './server/secrets-rotation';

eventEmitter.on('rotation_event', (event) => {
  if (event.status === 'failed') {
    // Send alert to monitoring system
    console.error(`🚨 Rotation failed: ${event.secretName}`);
  } else if (event.status === 'success') {
    console.log(`✅ Rotation successful: ${event.secretName}`);
  }
});
```

### 3. Environment-Specific Setup

#### Development Environment

```typescript
const devConfigs = [
  {
    key: 'DATABASE_URL',
    required: true,
    rotationInterval: 7, // More frequent rotation in dev
    autoRotate: true,
    environment: 'development'
  },
  {
    key: 'JWT_SECRET',
    required: true,
    rotationInterval: 1, // Daily rotation in dev
    autoRotate: true,
    environment: 'development'
  }
];
```

#### Production Environment

```typescript
const prodConfigs = [
  {
    key: 'DATABASE_URL',
    required: true,
    rotationInterval: 30, // Less frequent in prod
    autoRotate: true,
    environment: 'production'
  },
  {
    key: 'JWT_SECRET',
    required: true,
    rotationInterval: 7, // Weekly rotation in prod
    autoRotate: true,
    environment: 'production'
  }
];
```

### 4. Docker Setup

#### Dockerfile

```dockerfile
FROM node:18-alpine

WORKDIR /app

# Copy package files
COPY package*.json ./
RUN npm ci --only=production

# Copy application
COPY . .

# Set production environment
ENV NODE_ENV=production

# Expose port
EXPOSE 3000

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD node -e "require('http').get('http://localhost:3000/health', (r) => { if (r.statusCode === 200) process.exit(0); else process.exit(1); })"

CMD ["node", "dist/index.js"]
```

#### Docker Compose

```yaml
version: '3.8'

services:
  app:
    build: .
    environment:
      - NODE_ENV=production
      - DATABASE_URL=postgresql://user:pass@postgres:5432/db
      - JWT_SECRET=${JWT_SECRET}
    depends_on:
      - postgres
      - redis
    secrets:
      - jwt_secret

  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: db
      POSTGRES_USER: user
      POSTGRES_PASSWORD: password

  redis:
    image: redis:7-alpine

secrets:
  jwt_secret:
    file: ./secrets/jwt_secret.txt
```

---

## Rotation Configuration

### Basic Rotation Setup

#### 1. Register Secret for Rotation

```typescript
import { registerSecret, type Secret } from './server/secrets-rotation';

const secret: Secret = {
  id: 'api-key-1',
  name: 'API Key for Service A',
  value: 'current-secret-value',
  version: 1,
  lastRotated: new Date(),
  nextRotation: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
  rotationInterval: 30, // days
  isActive: true,
  environment: 'production',
  metadata: {
    service: 'service-a',
    owner: 'team-alpha'
  }
};

await registerSecret(secret);
```

#### 2. Configure Rotation Intervals

**Recommended Rotation Intervals:**

| Secret Type | Interval | Reason |
|-------------|----------|--------|
| JWT Secret | 7 days | Short-lived tokens, frequent rotation recommended |
| Database Password | 30 days | Regular credential refresh |
| API Keys | 60 days | Balance security and operational overhead |
| AWS Credentials | 45 days | AWS best practice |
| SMTP Password | 90 days | Lower frequency, less critical |
| Encryption Keys | 90 days | Infrequent, high impact when changed |

#### 3. Set Up Scheduling

```typescript
import { startRotationScheduler, scheduleRotation } from './server/secrets-rotation';

// Start automatic scheduler
startRotationScheduler();

// Schedule specific rotations with cron
scheduleRotation('api-key-1', '0 2 * * 0'); // Weekly on Sunday at 2 AM
scheduleRotation('db-password', '0 3 1 * *'); // Monthly on 1st at 3 AM
```

### Advanced Rotation Configuration

#### 1. Custom Configuration

```typescript
import { updateRotationConfig } from './server/secrets-rotation';

updateRotationConfig({
  maxRotationInterval: 60,        // Max 60 days between rotations
  notificationTimeout: 10000,     // 10 second timeout for notifications
  rotationTimeout: 60000,         // 60 second timeout for rotation
  retryAttempts: 5,               // Retry failed rotations 5 times
  retryDelay: 2000,               // 2 seconds between retries
  enableRollback: true,           // Enable automatic rollback
  enableNotifications: true,      // Enable notifications
  webhookUrl: 'https://your-webhook.com/notify',
  slackWebhookUrl: 'https://hooks.slack.com/...',
  emailRecipients: ['admin@company.com', 'security@company.com']
});
```

#### 2. Environment-Specific Configurations

```typescript
// Development - Frequent rotations with detailed logging
const devConfig = {
  maxRotationInterval: 7,
  retryAttempts: 3,
  enableNotifications: false, // Reduce noise in dev
  slackWebhookUrl: undefined
};

// Production - Conservative settings with full monitoring
const prodConfig = {
  maxRotationInterval: 30,
  retryAttempts: 5,
  enableNotifications: true,
  slackWebhookUrl: 'https://hooks.slack.com/...',
  emailRecipients: ['operations@company.com']
};

const config = process.env.NODE_ENV === 'production' ? prodConfig : devConfig;
updateRotationConfig(config);
```

#### 3. Manual Rotation Trigger

```typescript
import { rotateSecret } from './server/secrets-rotation';

// Trigger immediate rotation
const event = await rotateSecret('api-key-1', 'admin-user');
console.log(`Rotation ${event.status}: ${event.secretName}`);
```

#### 4. Bulk Rotation

```typescript
import { rotateDueSecrets } from './server/secrets-rotation';

// Rotate all secrets due for rotation
const events = await rotateDueSecrets('scheduled-maintenance');
console.log(`Completed ${events.length} rotations`);

events.forEach(event => {
  console.log(`${event.secretName}: ${event.status} (${event.duration}ms)`);
});
```

### Rotation Monitoring

#### 1. Check Rotation Status

```typescript
import { getRotationStatus } from './server/secrets-rotation';

const status = await getRotationStatus('api-key-1');
console.log('Rotation Status:', {
  secret: status.secret?.name,
  currentVersion: status.secret?.version,
  lastRotated: status.secret?.lastRotated,
  nextRotation: status.nextRotation,
  isScheduled: status.schedules.length > 0
});
```

#### 2. View Audit Log

```typescript
import { getAuditLog } from './server/secrets-rotation';

const auditLog = getAuditLog(50); // Last 50 events

console.log('Recent Rotations:');
auditLog.forEach(event => {
  console.log(`${event.timestamp.toISOString()} - ${event.secretName}: ${event.status}`);
  if (event.error) {
    console.error(`  Error: ${event.error}`);
  }
});
```

#### 3. Event Monitoring

```typescript
import { eventEmitter } from './server/secrets-rotation';

eventEmitter.on('rotation_event', (event) => {
  // Log to external monitoring system
  if (event.status === 'failed') {
    // Alert operations team
    sendAlert({
      type: 'rotation_failure',
      secret: event.secretName,
      error: event.error,
      timestamp: event.timestamp
    });
  }
  
  // Update metrics
  metrics.increment(`secrets.rotation.${event.status}`, {
    secret: event.secretName
  });
});
```

---

## Security Best Practices

### 1. Secret Generation

#### Generate Strong Secrets

```typescript
import { generateSecureSecret } from './server/secrets-manager';

// Generate a 32-character secure secret
const jwtSecret = generateSecureSecret(32);
// Result: "K9mX3PnBv8dL2QrW5tY6uI1oP4aS7gH2"

// Generate with custom character set
const apiKey = generateSecureSecret(24, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789');
// Result: "A1B2C3D4E5F6G7H8I9J0K1L2"
```

#### AWS Credentials Format

```typescript
// AWS Access Key ID - 20 characters, starts with AKIA or ASIA
const awsAccessKey = `AKIA${generateSecureSecret(16, 'A-Z0-9')}`;
// Example: AKIAIOSFODNN7EXAMPLE

// AWS Secret Access Key - 40 characters
const awsSecretKey = generateSecureSecret(40, 'A-Za-z0-9/+=）;
// Example: wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
```

### 2. Environment Isolation

#### Development Environment

```typescript
// dev.env
NODE_ENV=development
DATABASE_URL=postgresql://dev_user:dev_pass@dev-db:5432/dev_db
JWT_SECRET=dev-jwt-secret-for-testing-only
AWS_ACCESS_KEY_ID=AKIA...DEV...
```

#### Production Environment

```typescript
// prod.env (stored securely, never in version control)
NODE_ENV=production
DATABASE_URL=postgresql://prod_user:${prod_db_password}@prod-db:5432/prod_db
JWT_SECRET=${prod_jwt_secret_from_vault}
AWS_ACCESS_KEY_ID=${aws_access_key_from_vault}
```

### 3. Secret Storage

#### Option 1: Environment Variables (Basic)

```bash
# .env file (development only)
DATABASE_URL=postgresql://user:password@localhost:5432/db
JWT_SECRET=your-secret-key
```

#### Option 2: Docker Secrets (Containerized)

```yaml
# docker-compose.yml
secrets:
  database_password:
    file: ./secrets/db_password.txt
  jwt_secret:
    file: ./secrets/jwt_secret.txt

services:
  app:
    secrets:
      - database_password
      - jwt_secret
    environment:
      DATABASE_URL=postgresql://user:${database_password}@db:5432/db
      JWT_SECRET=${jwt_secret}
```

#### Option 3: External Secret Manager (Recommended)

```typescript
// AWS Secrets Manager
import { SecretsManager } from '@aws-sdk/client-secrets-manager';

const secretsClient = new SecretsManager({ region: 'us-east-1 });

async function getSecret(name: string): Promise<string> {
  const result = await secretsClient.getSecretValue({ SecretId: name });
  return result.SecretString!;
}

// Example usage
const databaseUrl = await getSecret('cloudpilot/database/url');
const jwtSecret = await getSecret('cloudpilot/jwt/secret');
```

#### Option 4: HashiCorp Vault (Enterprise)

```typescript
import { Client } from 'vault@^0.12.0';

const vault = new Client({
  api: { url: 'https://vault.company.com' },
  token: process.env.VAULT_TOKEN
});

async function getVaultSecret(path: string): Promise<string> {
  const result = await vault.read(`secret/${path}`);
  return result.data.value;
}
```

### 4. Validation and Verification

#### Always Validate Secrets

```typescript
import { secretsManager } from './server/secrets-manager';

// Validate on startup
const validationResults = secretsManager.validateAllSecrets();
const hasErrors = Object.values(validationResults).some(errors => errors.length > 0);

if (hasErrors) {
  console.error('❌ Secret validation failed:');
  Object.entries(validationResults).forEach(([key, errors]) => {
    if (errors.length > 0) {
      console.error(`  ${key}: ${errors.join(', ')}`);
    }
  });
  process.exit(1);
}
```

#### Check Secret Status

```typescript
// Check if all required secrets are present
const requiredSecrets = ['DATABASE_URL', 'JWT_SECRET'];
const missingSecrets = requiredSecrets.filter(key => !secretsManager.getSecret(key));

if (missingSecrets.length > 0) {
  throw new Error(`Missing required secrets: ${missingSecrets.join(', ')}`);
}

// Verify secret strength
const jwtSecret = secretsManager.getSecret('JWT_SECRET');
if (jwtSecret && jwtSecret.length < 32) {
  throw new Error('JWT_SECRET must be at least 32 characters');
}
```

### 5. Rotation Security

#### Secure Rotation Process

```typescript
import { rotateSecret, eventEmitter } from './server/secrets-rotation';

// Add security checks before rotation
async function secureRotate(secretId: string, performedBy: string) {
  // Verify permissions
  if (!hasRotationPermission(performedBy)) {
    throw new Error('Insufficient permissions for rotation');
  }
  
  // Verify secret is not in use
  if (isSecretInUse(secretId)) {
    throw new Error('Secret is currently in use, cannot rotate');
  }
  
  // Perform rotation
  const event = await rotateSecret(secretId, performedBy);
  
  // Verify rotation completed successfully
  if (event.status !== 'success') {
    throw new Error(`Rotation failed: ${event.error}`);
  }
  
  // Update dependent services
  await updateDependentServices(secretId);
  
  return event;
}
```

#### Audit Trail

```typescript
eventEmitter.on('rotation_event', (event) => {
  // Log to immutable audit store
  auditLogger.log({
    event: 'secret_rotation',
    secretId: event.secretId,
    secretName: event.secretName,
    performedBy: event.performedBy,
    status: event.status,
    timestamp: event.timestamp.toISOString(),
    ipAddress: getClientIP(),
    userAgent: getUserAgent()
  });
});
```

### 6. Monitoring and Alerting

#### Security Monitoring

```typescript
// Monitor for suspicious patterns
eventEmitter.on('rotation_event', (event) => {
  // Alert on multiple failures
  if (event.status === 'failed') {
    incrementFailureCount(event.secretId);
    
    if (getFailureCount(event.secretId) > 3) {
      alertSecurityTeam({
        type: 'multiple_rotation_failures',
        secret: event.secretName,
        failures: getFailureCount(event.secretId),
        lastError: event.error
      });
    }
  }
  
  // Alert on off-hours rotations
  const hour = new Date().getHours();
  if (hour < 6 || hour > 22) {
    alertOperationsTeam({
      type: 'off_hours_rotation',
      secret: event.secretName,
      time: event.timestamp.toISOString()
    });
  }
});
```

---

## Troubleshooting Guide

### Common Issues and Solutions

#### 1. Secret Validation Failures

**Problem:** `Validation failed for JWT_SECRET`

**Symptoms:**
- Application fails to start
- Validation errors in logs
- Secrets marked as invalid

**Solutions:**

```typescript
// Check current value
const jwtSecret = secretsManager.getSecret('JWT_SECRET');
console.log('JWT Secret length:', jwtSecret?.length);
console.log('JWT Secret format:', jwtSecret?.substring(0, 10) + '...');

// Verify against pattern
const isValid = validateEnvFormat('JWT_SECRET', VALIDATION_RULES.jwt_secret);
console.log('Is valid:', isValid);

// Common fixes:
if (!jwtSecret || jwtSecret.length < 32) {
  console.error('JWT_SECRET must be at least 32 characters');
  process.exit(1);
}

if (!/^[A-Za-z0-9._-]{32,}$/.test(jwtSecret)) {
  console.error('JWT_SECRET contains invalid characters');
  process.exit(1);
}
```

#### 2. AWS Credentials Issues

**Problem:** `AWS credentials validation failed`

**Symptoms:**
- AWS operations fail
- Validation errors for AWS keys
- "Access Denied" errors

**Solutions:**

```typescript
// Check AWS credentials format
const accessKey = secretsManager.getSecret('AWS_ACCESS_KEY_ID');
const secretKey = secretsManager.getSecret('AWS_SECRET_ACCESS_KEY');

console.log('Access Key Format:', {
  length: accessKey?.length,
  startsWithAKIA: accessKey?.startsWith('AKIA'),
  startsWithASIA: accessKey?.startsWith('ASIA'),
  isAlphanumeric: /^[A-Z0-9]+$/.test(accessKey || '')
});

console.log('Secret Key Format:', {
  length: secretKey?.length,
  hasValidChars: /^[A-Za-z0-9/+=]+$/.test(secretKey || '')
});

// Test AWS connectivity
import { STSClient, GetCallerIdentityCommand } from '@aws-sdk/client-sts';

const sts = new STSClient({
  region: secretsManager.getSecret('AWS_REGION') || 'us-east-1',
  credentials: {
    accessKeyId: accessKey!,
    secretAccessKey: secretKey!
  }
});

try {
  const identity = await sts.send(new GetCallerIdentityCommand({}));
  console.log('AWS Identity:', identity);
} catch (error) {
  console.error('AWS credentials test failed:', error);
}
```

#### 3. Database Connection Issues

**Problem:** `Database URL validation failed`

**Symptoms:**
- Cannot connect to database
- Database operations fail
- Validation errors

**Solutions:**

```typescript
// Validate database URL
const dbUrl = secretsManager.getSecret('DATABASE_URL');
const isValid = validateEnvFormat('DATABASE_URL', VALIDATION_RULES.database_url);

console.log('Database URL:', {
  isValid,
  protocol: dbUrl?.split('://')[0],
  hasCredentials: dbUrl?.includes('@'),
  format: dbUrl
});

// Test connection
import { createClient } from '@supabase/supabase-js';

try {
  const supabase = createClient(dbUrl!, {
    auth: { persistSession: false }
  });
  
  const { data, error } = await supabase.from('_test').select('*').limit(1);
  if (error && error.code !== 'PGRST116') { // PGRST116 = table doesn't exist, which is ok for test
    throw error;
  }
  
  console.log('✅ Database connection successful');
} catch (error) {
  console.error('❌ Database connection failed:', error.message);
}
```

#### 4. Rotation Failures

**Problem:** `Secret rotation failed`

**Symptoms:**
- Rotation events show failed status
- Notifications sent about rotation failures
- Audit log shows errors

**Solutions:**

```typescript
// Check rotation status
import { getRotationStatus, getAuditLog } from './server/secrets-rotation';

const status = await getRotationStatus('problematic-secret');
console.log('Rotation Status:', {
  isActive: status.secret?.isActive,
  lastRotated: status.secret?.lastRotated,
  nextRotation: status.nextRotation,
  schedules: status.schedules
});

// Check recent failures
const recentEvents = getAuditLog(10);
const failures = recentEvents.filter(e => e.status === 'failed');

console.log('Recent Failures:', failures.map(f => ({
  secret: f.secretName,
  error: f.error,
  timestamp: f.timestamp
})));

// Manual rotation with detailed logging
try {
  const event = await rotateSecret('problematic-secret', 'manual-debug');
  console.log('Manual rotation result:', event);
} catch (error) {
  console.error('Manual rotation failed:', error);
}
```

#### 5. Environment Variable Not Found

**Problem:** `Secret DATABASE_URL not found in cache`

**Symptoms:**
- Warnings in logs about missing secrets
- Application falls back to defaults
- Some features may not work

**Solutions:**

```typescript
// Check environment variables
console.log('Environment check:');
console.log('NODE_ENV:', process.env.NODE_ENV);
console.log('Available vars:', Object.keys(process.env).filter(k => 
  k.startsWith('DATABASE') || 
  k.startsWith('JWT') || 
  k.startsWith('AWS')
));

// Verify .env file is loaded
if (process.env.NODE_ENV === 'development') {
  const fs = require('fs');
  const envExists = fs.existsSync('.env');
  console.log('.env file exists:', envExists);
  
  if (envExists) {
    const envContent = fs.readFileSync('.env', 'utf8');
    console.log('Contains DATABASE_URL:', envContent.includes('DATABASE_URL'));
    console.log('Contains JWT_SECRET:', envContent.includes('JWT_SECRET'));
  }
}

// Check process environment
const requiredVars = ['DATABASE_URL', 'JWT_SECRET'];
const missing = requiredVars.filter(varName => !process.env[varName]);

if (missing.length > 0) {
  console.error('Missing environment variables:', missing);
  console.error('Please set these variables before starting the application');
  process.exit(1);
}
```

### Debugging Tools

#### 1. Enable Debug Logging

```typescript
// Enable debug mode
process.env.DEBUG = 'secrets:*';

// Or configure specific logging
const debug = process.env.DEBUG === 'true';

if (debug) {
  // Log all secret access
  const originalGetSecret = secretsManager.getSecret.bind(secretsManager);
  secretsManager.getSecret = (key: string) => {
    const value = originalGetSecret(key);
    console.log(`[DEBUG] Accessing secret ${key}: ${value ? '***' : 'undefined'}`);
    return value;
  };
  
  // Log all rotation events
  eventEmitter.on('rotation_event', (event) => {
    console.log(`[DEBUG] Rotation event:`, JSON.stringify(event, null, 2));
  });
}
```

#### 2. Secret Inspector

```typescript
function inspectSecrets() {
  console.log('\n=== Secret Inspector ===');
  
  const stats = secretsManager.getStatistics();
  console.log('Statistics:', stats);
  
  const allConfigs = secretsManager.getAllSecretConfigs();
  console.log('\nConfigured Secrets:');
  Object.entries(allConfigs).forEach(([key, config]) => {
    const value = secretsManager.getSecret(key);
    const isValid = secretsManager.isSecretValid(key);
    
    console.log(`  ${key}:`);
    console.log(`    Required: ${config.required}`);
    console.log(`    Present: ${!!value}`);
    console.log(`    Valid: ${isValid}`);
    console.log(`    Length: ${value?.length || 0}`);
  });
  
  console.log('\nValidation Results:');
  const validationResults = secretsManager.validateAllSecrets();
  Object.entries(validationResults).forEach(([key, errors]) => {
    if (errors.length > 0) {
      console.log(`  ${key}: ❌ ${errors.join(', ')}`);
    } else {
      console.log(`  ${key}: ✅ Valid`);
    }
  });
}

// Run inspector
inspectSecrets();
```

#### 3. Rotation Diagnostic

```typescript
function diagnoseRotation() {
  console.log('\n=== Rotation Diagnostic ===');
  
  const auditLog = getAuditLog(20);
  console.log('Recent Events:', auditLog.length);
  
  // Success rate
  const successful = auditLog.filter(e => e.status === 'success').length;
  const failed = auditLog.filter(e => e.status === 'failed').length;
  console.log(`Success Rate: ${((successful / auditLog.length) * 100).toFixed(1)}%`);
  
  // Average duration
  const durations = auditLog.filter(e => e.duration > 0).map(e => e.duration);
  const avgDuration = durations.reduce((a, b) => a + b, 0) / durations.length;
  console.log(`Average Duration: ${avgDuration.toFixed(0)}ms`);
  
  // Most problematic secrets
  const failuresBySecret = auditLog
    .filter(e => e.status === 'failed')
    .reduce((acc, e) => {
      acc[e.secretName] = (acc[e.secretName] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
  
  console.log('Most Failed Secrets:');
  Object.entries(failuresBySecret)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 5)
    .forEach(([secret, count]) => {
      console.log(`  ${secret}: ${count} failures`);
    });
}

// Run diagnostic
diagnoseRotation();
```

### Getting Help

#### Log Collection

When troubleshooting, collect the following information:

```bash
# Application logs
npm run logs > application.log

# Environment information
node -e "console.log(process.env)" > environment.log

# System information
uname -a > system.log
node --version >> system.log
npm --version >> system.log
```

#### Health Check Endpoint

```typescript
// Add to your application
app.get('/health/secrets', (req, res) => {
  const stats = secretsManager.getStatistics();
  const validation = secretsManager.validateAllSecrets();
  const auditLog = getAuditLog(10);
  
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    statistics: stats,
    validationErrors: Object.entries(validation)
      .filter(([, errors]) => errors.length > 0)
      .reduce((acc, [key, errors]) => ({ ...acc, [key]: errors }), {}),
    recentRotations: auditLog.filter(e => e.status === 'failed').length
  });
});
```

---

## Migration from Legacy System

This section guides you through migrating from the old secrets management approach to the new centralized system.

### Legacy System Overview

The old system used:
- Direct `process.env` access
- Manual validation
- No caching or change detection
- No rotation mechanism
- Hardcoded fallback values

### Migration Steps

#### Step 1: Audit Existing Secrets

```typescript
// migration-audit.ts
// Run this to audit your current secret usage

const fs = require('fs');
const path = require('path');

function auditSecretUsage() {
  console.log('=== Secret Usage Audit ===\n');
  
  // Scan for direct process.env usage
  const scanDir = './src';
  const secrets = new Set();
  
  function scanFiles(dir) {
    const files = fs.readdirSync(dir);
    
    for (const file of files) {
      const fullPath = path.join(dir, file);
      const stat = fs.statSync(fullPath);
      
      if (stat.isDirectory()) {
        scanFiles(fullPath);
      } else if (file.endsWith('.ts') || file.endsWith('.js')) {
        const content = fs.readFileSync(fullPath, 'utf8');
        
        // Find process.env usage
        const envMatches = content.match(/process\.env\.([A-Z_]+)/g);
        if (envMatches) {
          envMatches.forEach(match => {
            const key = match.replace('process.env.', '');
            secrets.add(key);
            
            // Show context
            const lines = content.split('\n');
            const lineNum = lines.findIndex(line => line.includes(match));
            console.log(`${fullPath}:${lineNum + 1} - ${key}`);
          });
        }
      }
    }
  }
  
  scanFiles(scanDir);
  
  console.log(`\n=== Found ${secrets.size} unique environment variables ===`);
  console.log(Array.from(secrets).sort());
  
  return Array.from(secrets);
}

auditSecretUsage();
```

#### Step 2: Replace Direct Access

**Before (Old System):**
```typescript
// auth.ts - OLD
const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret';
const DATABASE_URL = process.env.DATABASE_URL;

function authenticate() {
  const secret = process.env.JWT_SECRET;
  // ... use secret
}
```

**After (New System):**
```typescript
// auth.ts - NEW
import { secretsManager } from './secrets-manager';

function authenticate() {
  const secret = secretsManager.getSecret('JWT_SECRET');
  if (!secret) {
    throw new Error('JWT_SECRET is required');
  }
  // ... use secret
}
```

#### Step 3: Remove Hardcoded Fallbacks

**Before:**
```typescript
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
const DATABASE_URL = process.env.DATABASE_URL || 'postgresql://localhost/db';
```

**After:**
```typescript
// Validation will handle missing secrets
import { secretsManager } from './secrets-manager';

const JWT_SECRET = secretsManager.getSecret('JWT_SECRET'); // Will be undefined if not set
```

#### Step 4: Add Validation

```typescript
// migration-validation.ts
import { secretsManager } from './secrets-manager';

async function validateMigration() {
  console.log('=== Migration Validation ===\n');
  
  // Initialize secrets manager
  await secretsManager.initialize();
  
  // Validate all secrets
  const validationResults = secretsManager.validateAllSecrets();
  const hasErrors = Object.values(validationResults).some(errors => errors.length > 0);
  
  if (hasErrors) {
    console.log('❌ Validation failed:');
    Object.entries(validationResults).forEach(([key, errors]) => {
      if (errors.length > 0) {
        console.log(`  ${key}:`);
        errors.forEach(error => console.log(`    - ${error}`));
      }
    });
    return false;
  }
  
  console.log('✅ All secrets validated successfully');
  return true;
}
```

#### Step 5: Add Caching and Change Detection

**Before:**
```typescript
// database.ts - OLD
function connect() {
  const dbUrl = process.env.DATABASE_URL;
  // Connect directly
}
```

**After:**
```typescript
// database.ts - NEW
import { secretsManager } from './secrets-manager';
import { eventEmitter } from './secrets-rotation';

let dbConnection = null;

function connect() {
  const dbUrl = secretsManager.getSecret('DATABASE_URL');
  if (!dbUrl) {
    throw new Error('DATABASE_URL is required');
  }
  // Connect using cached value
}

// Listen for secret changes
secretsManager.onSecretChange((event) => {
  if (event.key === 'DATABASE_URL') {
    console.log('Database URL changed, reconnecting...');
    connect();
  }
});
```

#### Step 6: Enable Rotation (Optional)

```typescript
// rotation-setup.ts
import { 
  registerSecret, 
  startRotationScheduler,
  EXTENDED_SECRET_CONFIGS 
} from './server/integration-rotation';

async function setupRotation() {
  console.log('Setting up rotation...');
  
  // Register secrets for rotation
  for (const config of EXTENDED_SECRET_CONFIGS) {
    if (config.autoRotate && config.rotationInterval) {
      const secretValue = secretsManager.getSecret(config.key);
      if (secretValue) {
        const secret = {
          id: config.key,
          name: config.description || config.key,
          value: secretValue,
          version: 1,
          lastRotated: new Date(),
          nextRotation: new Date(Date.now() + config.rotationInterval * 24 * 60 * 60 * 1000),
          rotationInterval: config.rotationInterval,
          isActive: true,
          environment: 'production'
        };
        
        await registerSecret(secret);
        console.log(`✅ Registered ${config.key} for rotation`);
      }
    }
  }
  
  // Start scheduler
  startRotationScheduler();
  console.log('✅ Rotation scheduler started');
}
```

### Migration Checklist

- [ ] **Audit Phase**
  - [ ] Run secret usage audit
  - [ ] Document all environment variables
  - [ ] Identify hardcoded values
  - [ ] Check validation requirements

- [ ] **Replacement Phase**
  - [ ] Replace `process.env` with `secretsManager.getSecret()`
  - [ ] Remove all hardcoded fallback values
  - [ ] Add validation calls
  - [ ] Update import statements

- [ ] **Enhancement Phase**
  - [ ] Add secret change listeners
  - [ ] Enable caching benefits
  - [ ] Set up rotation (if needed)
  - [ ] Configure notifications

- [ ] **Testing Phase**
  - [ ] Test with missing secrets
  - [ ] Test with invalid secrets
  - [ ] Test rotation functionality
  - [ ] Test change detection
  - [ ] Verify all features work

- [ ] **Deployment Phase**
  - [ ] Update environment documentation
  - [ ] Train team on new system
  - [ ] Monitor initial deployment
  - [ ] Verify audit logging
  - [ ] Check notification delivery

### Rollback Plan

If issues occur during migration:

1. **Revert to Previous Version**
   ```bash
   git checkout <previous-commit>
   npm run build
   npm run start
   ```

2. **Gradual Migration**
   - Migrate one module at a time
   - Test each migration in staging
   - Keep old system as fallback during transition

3. **Hybrid Approach**
   - Use both systems during transition
   - Gradually increase new system usage
   - Remove old system once stable

---

## API Reference

### SecretsManager Class

#### Constructor

```typescript
new SecretsManager(configs?: SecretConfig[])
```

#### Methods

##### `initialize(): Promise<void>`

Initialize the secrets manager and load all secrets.

```typescript
await secretsManager.initialize();
```

##### `getSecret(key: string): string | undefined`

Get a secret value from cache.

```typescript
const jwtSecret = secretsManager.getSecret('JWT_SECRET');
```

##### `getSecretWithMetadata(key: string): CacheEntry | undefined`

Get secret with metadata.

```typescript
const entry = secretsManager.getSecretWithMetadata('JWT_SECRET');
console.log('Last loaded:', entry?.metadata.lastLoaded);
```

##### `getAllSecrets(): Record<string, string>`

Get all cached secrets.

```typescript
const allSecrets = secretsManager.getAllSecrets();
```

##### `validateAllSecrets(): Record<string, string[]>`

Validate all configured secrets.

```typescript
const results = secretsManager.validateAllSecrets();
Object.entries(results).forEach(([key, errors]) => {
  if (errors.length > 0) {
    console.error(`${key}: ${errors.join(', ')}`);
  }
});
```

##### `isSecretValid(key: string): boolean`

Check if a secret is valid.

```typescript
const isValid = secretsManager.isSecretValid('JWT_SECRET');
```

##### `hasSecretChanged(key: string): boolean`

Check if a secret has changed in environment.

```typescript
const changed = secretsManager.hasSecretChanged('DATABASE_URL');
```

##### `onSecretChange(listener: (event: SecretsChangeEvent) => void)`

Add listener for secret changes.

```typescript
secretsManager.onSecretChange((event) => {
  console.log(`Secret ${event.key} changed`);
});
```

##### `reload(): Promise<void>`

Reload secrets from environment.

```typescript
await secretsManager.reload();
```

##### `shutdown(): void`

Cleanup and shutdown.

```typescript
secretsManager.shutdown();
```

##### `getStatistics(): SecretsStatistics`

Get statistics about the secrets manager.

```typescript
const stats = secretsManager.getStatistics();
console.log('Total secrets:', stats.totalSecrets);
```

### SecretsRotationService

#### Functions

##### `registerSecret(secret: Secret): Promise<void>`

Register a secret for rotation.

```typescript
await registerSecret({
  id: 'api-key-1',
  name: 'API Key',
  value: 'current-value',
  version: 1,
  lastRotated: new Date(),
  nextRotation: new Date(),
  rotationInterval: 30,
  isActive: true,
  environment: 'production'
});
```

##### `rotateSecret(secretId: string, performedBy?: string): Promise<RotationEvent>`

Manually rotate a secret.

```typescript
const event = await rotateSecret('api-key-1', 'admin-user');
```

##### `rotateDueSecrets(performedBy?: string): Promise<RotationEvent[]>`

Rotate all due secrets.

```typescript
const events = await rotateDueSecrets('scheduled');
```

##### `getRotationStatus(secretId: string): Promise<RotationStatus>`

Get rotation status for a secret.

```typescript
const status = await getRotationStatus('api-key-1');
```

##### `getAuditLog(limit?: number): RotationEvent[]`

Get rotation audit log.

```typescript
const log = getAuditLog(50);
```

##### `startRotationScheduler(): void`

Start the automatic scheduler.

```typescript
startRotationScheduler();
```

##### `stopRotationScheduler(): void`

Stop the automatic scheduler.

```typescript
stopRotationScheduler();
```

##### `scheduleRotation(secretId: string, cronExpression: string): void`

Schedule rotation with cron expression.

```typescript
scheduleRotation('api-key-1', '0 2 * * 0'); // Weekly on Sunday
```

##### `updateRotationConfig(config: Partial<RotationConfig>): void`

Update rotation configuration.

```typescript
updateRotationConfig({
  maxRotationInterval: 60,
  retryAttempts: 5
});
```

### Types and Interfaces

#### `SecretConfig`

```typescript
interface SecretConfig {
  key: string;
  required?: boolean;
  validation?: ValidationRule;
  refreshInterval?: number;
  fallback?: string;
  description?: string;
}
```

#### `Secret`

```typescript
interface Secret {
  id: string;
  name: string;
  value: string;
  version: number;
  lastRotated: Date;
  nextRotation: Date;
  rotationInterval: number;
  isActive: boolean;
  environment: string;
  metadata?: Record<string, any>;
}
```

#### `RotationEvent`

```typescript
interface RotationEvent {
  id: string;
  secretId: string;
  secretName: string;
  timestamp: Date;
  status: 'success' | 'failed' | 'rollback';
  oldVersion: number;
  newVersion: number;
  error?: string;
  duration: number;
  performedBy: string;
}
```

#### `SecretsChangeEvent`

```typescript
interface SecretsChangeEvent {
  key: string;
  oldValue?: string;
  newValue: string;
  timestamp: number;
}
```

### Utility Functions

#### `maskSecret(value: string, showStart?: number, showEnd?: number): string`

Mask secret for logging.

```typescript
const masked = maskSecret('my-secret-value');
// Result: "my-s*********lue"
```

#### `generateSecureSecret(length?: number, charset?: string): string`

Generate a secure random secret.

```typescript
const newSecret = generateSecureSecret(32);
```

#### `checkRequiredSecrets(configs: SecretConfig[]): string[]`

Check for missing required secrets.

```typescript
const missing = checkRequiredSecrets(DEFAULT_SECRETS);
```

---

## Examples

### Basic Usage

```typescript
import { secretsManager } from './server/secrets-manager';

async function basicExample() {
  // Initialize
  await secretsManager.initialize();
  
  // Get secrets
  const jwtSecret = secretsManager.getSecret('JWT_SECRET');
  const dbUrl = secretsManager.getSecret('DATABASE_URL');
  
  if (!jwtSecret || !dbUrl) {
    throw new Error('Required secrets missing');
  }
  
  // Use secrets
  console.log('Using JWT secret:', maskSecret(jwtSecret));
}
```

### With Validation

```typescript
async function validationExample() {
  await secretsManager.initialize();
  
  // Check all secrets
  const results = secretsManager.validateAllSecrets();
  const errors = Object.entries(results).filter(([, errors]) => errors.length > 0);
  
  if (errors.length > 0) {
    console.error('Validation errors:');
    errors.forEach(([key, errors]) => {
      console.error(`  ${key}: ${errors.join(', ')}`);
    });
    throw new Error('Secret validation failed');
  }
  
  console.log('✅ All secrets valid');
}
```

### With Rotation

```typescript
import { 
  registerSecret, 
  rotateSecret, 
  startRotationScheduler 
} from './server/secrets-rotation';

async function rotationExample() {
  // Register secret for rotation
  await registerSecret({
    id: 'api-key-1',
    name: 'API Key',
    value: process.env.API_KEY!,
    version: 1,
    lastRotated: new Date(),
    nextRotation: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
    rotationInterval: 30,
    isActive: true,
    environment: 'production'
  });
  
  // Start scheduler
  startRotationScheduler();
  
  // Manual rotation
  const event = await rotateSecret('api-key-1', 'admin');
  console.log(`Rotation: ${event.status}`);
}
```

### With Monitoring

```typescript
import { eventEmitter } from './server/secrets-rotation';

function monitoringExample() {
  // Listen for rotation events
  eventEmitter.on('rotation_event', (event) => {
    if (event.status === 'failed') {
      console.error(`🚨 Rotation failed: ${event.secretName}`);
      console.error(`Error: ${event.error}`);
      // Send alert
    } else if (event.status === 'success') {
      console.log(`✅ Rotation successful: ${event.secretName}`);
    }
  });
  
  // Listen for secret changes
  secretsManager.onSecretChange((event) => {
    console.log(`🔔 Secret changed: ${event.key}`);
    // Update dependent services
  });
}
```

### Full Integration

```typescript
import { EnhancedSecretsManager, EXTENDED_SECRET_CONFIGS } from './server/integration-rotation';

async function fullIntegrationExample() {
  const enhancedManager = new EnhancedSecretsManager(secretsManager);
  
  try {
    // Initialize with rotation
    await enhancedManager.initialize(EXTENDED_SECRET_CONFIGS);
    
    // Get secret with rotation info
    const info = await enhancedManager.getSecretWithRotationInfo('JWT_SECRET');
    console.log('Secret info:', {
      value: info.value ? '***' : undefined,
      rotation: info.rotation,
      config: info.config
    });
    
    // Get statistics
    const stats = enhancedManager.getRotationStatistics();
    console.log('Statistics:', stats);
    
  } finally {
    enhancedManager.shutdown();
  }
}
```

### Docker Deployment

```dockerfile
FROM node:18-alpine

WORKDIR /app

# Install dependencies
COPY package*.json ./
RUN npm ci --only=production

# Copy application
COPY . .

# Create secrets directory
RUN mkdir -p /app/secrets

# Copy secrets (in production, use Docker secrets or external secret manager)
COPY secrets/ /app/secrets/

# Set production environment
ENV NODE_ENV=production

# Expose port
EXPOSE 3000

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD node -e "require('http').get('http://localhost:3000/health', (r) => process.exit(r.statusCode === 200 ? 0 : 1))"

CMD ["node", "dist/index.js"]
```

### Kubernetes Deployment

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: cloudpilot
spec:
  replicas: 3
  selector:
    matchLabels:
      app: cloudpilot
  template:
    metadata:
      labels:
        app: cloudpilot
    spec:
      containers:
      - name: cloudpilot
        image: cloudpilot:latest
        ports:
        - containerPort: 3000
        env:
        - name: NODE_ENV
          value: "production"
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: database-url
        - name: JWT_SECRET
          valueFrom:
            secretKeyRef:
              name: app-secrets
              key: jwt-secret
        resources:
          limits:
            memory: "512Mi"
            cpu: "500m"
          requests:
            memory: "256Mi"
            cpu: "250m"
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 3000
          initialDelaySeconds: 5
          periodSeconds: 5
---
apiVersion: v1
kind: Secret
metadata:
  name: app-secrets
type: Opaque
stringData:
  database-url: "postgresql://user:password@postgres:5432/db"
  jwt-secret: "your-32-character-secret-here"
```

---

**Documentation Version:** 2.0  
**Maintained by:** CloudPilot Development Team  
**Last Updated:** October 31, 2025
