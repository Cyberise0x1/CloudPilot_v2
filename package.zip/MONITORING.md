# Monitoring and Alerting System Documentation

## 📋 Table of Contents

1. [System Overview](#system-overview)
2. [Monitoring Endpoints Reference](#monitoring-endpoints-reference)
3. [Metrics and Logging Usage](#metrics-and-logging-usage)
4. [Health Check System](#health-check-system)
5. [Alert Configuration](#alert-configuration)
6. [Troubleshooting Guide](#troubleshooting-guide)
7. [Integration Examples](#integration-examples)
8. [Production Deployment Notes](#production-deployment-notes)

---

## System Overview

### Architecture

The CloudPilot Production monitoring system consists of several interconnected components:

```
┌─────────────────────────────────────────────────────────────────┐
│                    Monitoring Dashboard API                     │
├─────────────────────────────────────────────────────────────────┤
│  • Metrics Visualization  • Real-time Status  • Performance     │
│  • Error Analysis         • Alert Management  • Dashboard Config │
└─────────────────────────────────────────────────────────────────┘
                                │
┌─────────────────────────────────────────────────────────────────┐
│                     Metrics Collector                            │
├─────────────────────────────────────────────────────────────────┤
│  • HTTP Request Metrics  • AWS Operations  • System Resources   │
│  • Business Metrics      • Prometheus Export  • Aggregation      │
└─────────────────────────────────────────────────────────────────┘
                                │
┌─────────────────────────────────────────────────────────────────┐
│                     Health Check System                         │
├─────────────────────────────────────────────────────────────────┤
│  • Database Health       • AWS Services     • External APIs      │
│  • System Resources      • Application Health  • Kubernetes       │
└─────────────────────────────────────────────────────────────────┘
                                │
┌─────────────────────────────────────────────────────────────────┐
│                     Logging System                               │
├─────────────────────────────────────────────────────────────────┤
│  • Request Logging       • AWS Operations   • Security Events    │
│  • Performance Logging   • Error Tracking   • Sensitive Data Filter │
└─────────────────────────────────────────────────────────────────┘
```

### Core Components

1. **Monitoring Dashboard API** (`server/monitoring-dashboard.ts`)
   - RESTful API for metrics visualization and management
   - Real-time status monitoring with alerting
   - Performance trends and error analysis
   - Dashboard configuration and data export

2. **Metrics Collector** (`server/metrics.ts`)
   - Prometheus-compatible metrics collection
   - Automatic aggregation across multiple time windows
   - System resource monitoring
   - Business metrics tracking

3. **Health Check System** (`server/health.ts`)
   - Comprehensive health monitoring across all services
   - Kubernetes-ready probes (liveness, readiness)
   - Historical health data and trend analysis
   - Configurable thresholds and retry logic

4. **Logging System** (`server/middleware/logger.ts`)
   - Structured logging with Winston
   - Correlation ID tracking
   - Sensitive data filtering
   - Performance and security event logging

### Key Features

- ✅ **Real-time Monitoring**: Live metrics and status updates
- ✅ **Historical Data**: 7-day retention with trend analysis
- ✅ **Kubernetes Ready**: Standard probe endpoints
- ✅ **Alerting System**: Configurable alerts with severity levels
- ✅ **Prometheus Integration**: Native Prometheus format export
- ✅ **Security**: Sensitive data filtering and correlation tracking
- ✅ **Performance**: Low overhead monitoring with async operations

---

## Monitoring Endpoints Reference

### Dashboard API Endpoints

#### Metrics Management

```http
# Get all metrics with optional filtering
GET /api/monitoring/metrics
Query Parameters:
  - metric_name: Filter by specific metric name
  - start_time: ISO 8601 start time
  - end_time: ISO 8601 end time
  - limit: Maximum number of results (default: 1000)

# Get specific metric data
GET /api/monitoring/metrics/:name

# Add new metric data point
POST /api/monitoring/metrics
Content-Type: application/json
{
  "name": "custom_metric",
  "value": 42,
  "labels": { "service": "api", "region": "us-east-1" },
  "unit": "count"
}

# Get chart data for visualization
GET /api/monitoring/metrics/:name/chart
Query Parameters:
  - period: Time period (1m, 1h, 24h, 7d)
  - aggregation: Aggregation method (avg, min, max, sum)
```

**Example Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "http_requests_total-1640995200000",
      "name": "http_requests_total",
      "value": 1543,
      "timestamp": "2024-01-01T00:00:00.000Z",
      "labels": {
        "method": "GET",
        "status": "200"
      },
      "unit": "count"
    }
  ],
  "count": 1
}
```

#### System Status

```http
# Get overall system status
GET /api/monitoring/status

# Get detailed system health
GET /api/monitoring/status/health

# Get live status summary
GET /api/monitoring/status/live
```

**Health Status Response:**
```json
{
  "success": true,
  "data": {
    "status": "healthy",
    "uptime": 86400,
    "last_check": "2024-01-01T12:00:00.000Z",
    "services": [
      {
        "name": "API Service",
        "status": "healthy",
        "response_time": 50
      }
    ]
  }
}
```

#### Performance Monitoring

```http
# Get performance trends
GET /api/monitoring/performance/trends
Query Parameters:
  - period: Time period (1h, 24h, 7d, 30d)
  - metrics: Comma-separated metrics list

# Get performance comparison
GET /api/monitoring/performance/comparison
Query Parameters:
  - period1: First period to compare
  - period2: Second period to compare
  - metric: Specific metric to compare

# Get performance summary
GET /api/monitoring/performance/summary
```

#### Error Analysis

```http
# Get error logs
GET /api/monitoring/errors
Query Parameters:
  - level: Error level (error, warning, info, debug)
  - start_time: ISO 8601 start time
  - end_time: ISO 8601 end time
  - limit: Maximum results (default: 100)

# Get error analysis
GET /api/monitoring/errors/analysis

# Log new error
POST /api/monitoring/errors/log
Content-Type: application/json
{
  "level": "error",
  "message": "Database connection failed",
  "stack": "Error: Connection failed...",
  "source": "database"
}
```

#### Alert Management

```http
# Get all alerts
GET /api/monitoring/alerts
Query Parameters:
  - status: Alert status (active, resolved, acknowledged)
  - severity: Alert severity (low, medium, high, critical)
  - limit: Maximum results (default: 100)

# Create new alert
POST /api/monitoring/alerts
Content-Type: application/json
{
  "name": "High CPU Usage",
  "description": "CPU usage above 80%",
  "condition": "cpu_usage > 80",
  "threshold": 80,
  "severity": "high"
}

# Update alert
PUT /api/monitoring/alerts/:id
Content-Type: application/json
{
  "threshold": 90,
  "description": "Updated threshold"
}

# Acknowledge alert
POST /api/monitoring/alerts/:id/acknowledge

# Resolve alert
POST /api/monitoring/alerts/:id/resolve
```

### Health Check Endpoints

```http
# Comprehensive health check
GET /api/health

# Specific service health
GET /api/health/:service
# Services: database, aws, system, external

# Health history
GET /api/health/history
Query Parameters:
  - start_time: ISO 8601 start time
  - end_time: ISO 8601 end time
  - limit: Maximum results (default: 100)

# System metrics only
GET /api/health/metrics

# Basic status
GET /api/status

# Kubernetes readiness probe
GET /api/ready

# Kubernetes liveness probe
GET /api/live
```

### Prometheus Metrics Endpoint

```http
# Export metrics in Prometheus format
GET /metrics

# Health metrics for Prometheus
GET /api/health/prometheus
```

---

## Metrics and Logging Usage

### Using the Metrics Collector

#### Basic Metric Tracking

```typescript
import { metrics, trackRequest, trackAwsOperation } from './metrics';

// Track HTTP requests (handled automatically by middleware)
trackRequest('GET', '/api/users', 200, 150, 'Mozilla/5.0', '192.168.1.1');

// Track AWS operations
trackAwsOperation('S3', 'GetObject', 250, 'success');

// Track business events
metrics.trackUserRegistration();
metrics.trackUserLogin();
metrics.trackApiCall();
```

#### Custom Metrics

```typescript
import { Counter, Gauge, Histogram } from './metrics';

// Create custom counter
const customCounter = new Counter(
  'user_actions_total',
  'Total number of user actions',
  { action_type: '', user_type: '' }
);

// Increment counter
customCounter.inc(1, { action_type: 'login', user_type: 'premium' });

// Create custom gauge
const memoryGauge = new Gauge(
  'app_memory_bytes',
  'Application memory usage in bytes'
);

// Set gauge value
memoryGauge.set(process.memoryUsage().heapUsed);

// Create custom histogram
const responseTimeHistogram = new Histogram(
  'api_response_time_seconds',
  'API response time in seconds',
  [0.1, 0.5, 1, 2, 5, 10] // Buckets
);

// Observe value
responseTimeHistogram.observe(1.5);
```

#### Getting Metrics Data

```typescript
// Get dashboard data
const dashboardData = metrics.getDashboardData();
console.log('Current RPS:', dashboardData.realTimeMetrics.requestsPerSecond);
console.log('Error rate:', dashboardData.realTimeMetrics.errorRate);

// Get Prometheus format
const prometheusMetrics = metrics.toPrometheus();
console.log(prometheusMetrics);
```

### Using the Logging System

#### Basic Logging

```typescript
import { logger } from './middleware/logger';

// Basic logging
logger.info('User logged in', { userId: '123', email: 'user@example.com' });
logger.warn('Slow database query', { query: 'SELECT * FROM users', duration: 5000 });
logger.error('Payment processing failed', { amount: 100, userId: '123' });

// Performance logging
logger.logPerformance('Database query', 3000, { queryType: 'SELECT', table: 'users' });

// Security logging
logger.logSecurityEvent('Failed login attempt', LogLevel.WARN, {
  ip: '192.168.1.100',
  userAgent: 'Suspicious Bot'
});
```

#### Request Context Logging

```typescript
import { requestLoggingMiddleware, getCorrelationId } from './middleware/logger';

// In your route handler
app.get('/api/users/:id', (req, res) => {
  const correlationId = getCorrelationId(req);
  
  logger.info('Fetching user', {
    correlationId,
    userId: req.params.id
  });
  
  // Your logic here
});
```

#### AWS Operation Logging

```typescript
import { awsOperationLogger } from './middleware/logger';

const s3Logger = awsOperationLogger('S3');

try {
  s3Logger.before('GetObject', 'bucket/file.jpg');
  
  // AWS operation
  const result = await s3.getObject({
    Bucket: 'my-bucket',
    Key: 'file.jpg'
  }).promise();
  
  s3Logger.after('GetObject', 'bucket/file.jpg', { size: result.ContentLength });
} catch (error) {
  s3Logger.error('GetObject', 'bucket/file.jpg', error, { retryCount: 2 });
  throw error;
}
```

#### Sensitive Data Filtering

The logger automatically filters sensitive data based on patterns:

```typescript
// These values will be filtered as [FILTERED]
logger.info('Processing payment', {
  creditCard: '1234-5678-9012-3456', // Will be filtered
  password: 'secret123',             // Will be filtered
  apiKey: 'sk_test_123456789',       // Will be filtered
  userId: '12345',                   // Will be logged normally
  email: 'user@example.com'          // Will be logged normally
});
```

### Configuration

#### Environment Variables

```bash
# Logging
LOG_LEVEL=info
NODE_ENV=production

# Health Check Configuration
HEALTH_CHECK_DATABASE_TIMEOUT=5000
HEALTH_CHECK_AWS_TIMEOUT=3000
HEALTH_CHECK_SYSTEM_INTERVAL=30000
HEALTH_CHECK_CPU_THRESHOLD=80
HEALTH_CHECK_MEMORY_THRESHOLD=85
HEALTH_CHECK_DISK_THRESHOLD=90

# Monitoring Dashboard
MONITORING_RETENTION_DAYS=7
MONITORING_CLEANUP_INTERVAL=3600000
MONITORING_MAX_METRICS=10000
```

---

## Health Check System

### Overview

The health check system provides comprehensive monitoring of all system components with Kubernetes-ready probes.

### Health Check Types

#### Database Health

```typescript
// Checks PostgreSQL connectivity, version, and response time
await checkDatabaseHealth({
  timeout: 5000,
  retries: 2,
  critical: true
});
```

#### AWS Services Health

```typescript
// Checks S3, CloudFront, EC2, RDS availability
await checkAwsServicesHealth({
  services: ['s3', 'cloudfront', 'ec2', 'rds'],
  timeout: 3000,
  retries: 1,
  critical: true
});
```

#### External Dependencies

```typescript
// Checks GitHub API, NPM Registry, etc.
await checkExternalDependencies([
  {
    name: 'github',
    url: 'https://api.github.com',
    timeout: 10000,
    critical: true
  }
]);
```

#### System Resources

```typescript
// Monitors CPU, memory, disk usage
await checkSystemResources({
  cpuThreshold: 80,
  memoryThreshold: 85,
  diskThreshold: 90,
  interval: 30000
});
```

### Health Status Levels

- **🟢 Healthy**: All systems operational
- **🟡 Degraded**: Some issues detected, functionality reduced
- **🔴 Unhealthy**: Critical systems down or failing
- **❓ Unknown**: Health check failed or timeout

### Custom Health Checks

```typescript
import { createHealthCheck } from './health';

const customCheck = createHealthCheck({
  name: 'redis_cache',
  critical: true,
  timeout: 2000,
  async check(): Promise<HealthResult> {
    try {
      await redis.ping();
      return {
        status: 'healthy',
        responseTime: 100,
        message: 'Redis is operational'
      };
    } catch (error) {
      return {
        status: 'unhealthy',
        responseTime: 0,
        message: `Redis check failed: ${error.message}`,
        error
      };
    }
  }
});
```

### Health History and Trends

```typescript
// Get health history
const history = await getHealthHistory({
  startTime: new Date(Date.now() - 24 * 60 * 60 * 1000),
  endTime: new Date(),
  limit: 100
});

// Calculate uptime percentage
const uptime = calculateUptimePercentage(history);

// Get trend analysis
const trends = analyzeHealthTrends(history);
```

---

## Alert Configuration

### Alert Types and Severity

#### Severity Levels

- **🔵 Low**: Informational alerts, no immediate action required
- **🟡 Medium**: Warning alerts, monitor closely
- **🟠 High**: Error alerts, investigate soon
- **🔴 Critical**: System down, immediate action required

#### Alert Conditions

```typescript
// CPU usage alert
{
  name: "High CPU Usage",
  condition: "cpu_usage > 80",
  threshold: 80,
  severity: "high",
  description: "CPU usage above 80% for 5 minutes"
}

// Memory usage alert
{
  name: "High Memory Usage",
  condition: "memory_usage > 85",
  threshold: 85,
  severity: "critical",
  description: "Memory usage above 85%"
}

// Error rate alert
{
  name: "High Error Rate",
  condition: "error_rate > 0.05",
  threshold: 0.05,
  severity: "high",
  description: "Error rate above 5%"
}
```

### Alert Configuration Examples

#### Create Alert via API

```typescript
// High response time alert
const responseTimeAlert = await fetch('/api/monitoring/alerts', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: 'High Response Time',
    description: 'API response time above 2 seconds',
    condition: 'avg_response_time > 2',
    threshold: 2,
    severity: 'medium'
  })
});

// Low availability alert
const availabilityAlert = await fetch('/api/monitoring/alerts', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    name: 'Low Availability',
    description: 'Service availability below 99%',
    condition: 'availability < 99',
    threshold: 99,
    severity: 'critical'
  })
});
```

#### Configure via Environment

```bash
# Alert thresholds
ALERT_CPU_THRESHOLD=80
ALERT_MEMORY_THRESHOLD=85
ALERT_DISK_THRESHOLD=90
ALERT_ERROR_RATE_THRESHOLD=0.05
ALERT_RESPONSE_TIME_THRESHOLD=2000
ALERT_AVAILABILITY_THRESHOLD=99

# Alert behavior
ALERT_ESCALATION_TIMEOUT=300000  # 5 minutes
ALERT_SILENCE_DURATION=3600000   # 1 hour
```

### Alert Integration

#### Prometheus AlertManager

```yaml
# alertmanager.yml
groups:
- name: cloudpilot.rules
  rules:
  - alert: HighCPUUsage
    expr: cpu_usage_percent > 80
    for: 5m
    labels:
      severity: warning
    annotations:
      summary: High CPU usage detected
      description: "CPU usage is above 80% for 5 minutes"

  - alert: HighErrorRate
    expr: error_rate > 0.05
    for: 2m
    labels:
      severity: critical
    annotations:
      summary: High error rate detected
      description: "Error rate is above 5%"
```

#### PagerDuty Integration

```typescript
import axios from 'axios';

const pagerDutyIntegration = async (alert) => {
  if (alert.severity === 'critical') {
    await axios.post('https://events.pagerduty.com/v2/enqueue', {
      routing_key: process.env.PAGERDUTY_ROUTING_KEY,
      event_action: 'trigger',
      payload: {
        summary: alert.name,
        severity: 'critical',
        source: 'cloudpilot-monitoring',
        custom_details: alert
      }
    });
  }
};
```

---

## Troubleshooting Guide

### Common Issues and Solutions

#### 1. High Memory Usage

**Symptoms:**
- Memory usage consistently above 85%
- Out-of-memory errors in logs
- Application slowdowns

**Diagnosis:**
```bash
# Check current memory usage
curl -s http://localhost:3000/api/health/metrics | jq '.memory'

# Check for memory leaks
curl -s http://localhost:3000/api/monitoring/status/health | jq '.memory_usage'

# Check system memory
free -h
```

**Solutions:**
1. **Check for memory leaks**:
   ```bash
   # Review application logs for memory warnings
   grep -i "memory\|heap" logs/combined.log
   ```

2. **Restart application**:
   ```bash
   pm2 restart cloudpilot
   ```

3. **Scale horizontally**:
   ```bash
   # Add more application instances
   pm2 scale cloudpilot 4
   ```

#### 2. High CPU Usage

**Symptoms:**
- CPU usage consistently above 80%
- Slow response times
- Timeouts in API calls

**Diagnosis:**
```bash
# Check CPU usage
curl -s http://localhost:3000/api/health/metrics | jq '.cpu'

# Check top processes
top -bn1 | head -20

# Check application performance
curl -s http://localhost:3000/api/monitoring/performance/summary
```

**Solutions:**
1. **Optimize database queries**:
   ```bash
   # Check slow query logs
   grep "slow query" logs/combined.log
   ```

2. **Add caching**:
   ```typescript
   // Implement Redis caching for frequent queries
   const cachedData = await redis.get(`cache:${key}`);
   if (cachedData) return JSON.parse(cachedData);
   ```

3. **Scale up**:
   ```bash
   # Upgrade to larger instance
   aws ec2 modify-instance-attribute --instance-id i-1234567890abcdef0 --instance-type t3.large
   ```

#### 3. Database Connection Issues

**Symptoms:**
- Health check shows database as unhealthy
- Connection timeout errors
- "connection refused" in logs

**Diagnosis:**
```bash
# Check database health
curl -s http://localhost:3000/api/health/database

# Test database connectivity
psql -h $DB_HOST -U $DB_USER -d $DB_NAME -c "SELECT 1;"

# Check database logs
tail -f /var/log/postgresql/postgresql.log
```

**Solutions:**
1. **Check connection string**:
   ```bash
   echo $DATABASE_URL
   ```

2. **Verify database is running**:
   ```bash
   sudo systemctl status postgresql
   sudo systemctl restart postgresql
   ```

3. **Check firewall/security groups**:
   ```bash
   # AWS security groups
   aws ec2 describe-security-groups --group-ids sg-12345678
   ```

#### 4. High Error Rates

**Symptoms:**
- Error rate above 5%
- 500 errors in application logs
- User complaints about functionality

**Diagnosis:**
```bash
# Check error rate
curl -s http://localhost:3000/api/monitoring/errors/analysis

# Review recent errors
curl -s http://localhost:3000/api/monitoring/errors?limit=10

# Check application logs
tail -f logs/error.log
```

**Solutions:**
1. **Identify error patterns**:
   ```bash
   # Get top errors
   curl -s http://localhost:3000/api/monitoring/errors/analysis | jq '.top_errors'
   ```

2. **Fix common issues**:
   ```typescript
   // Add better error handling
   try {
     await riskyOperation();
   } catch (error) {
     logger.error('Operation failed', { error: error.message });
     // Provide fallback or graceful degradation
   }
   ```

3. **Implement circuit breaker**:
   ```typescript
   // Add circuit breaker for external services
   const circuitBreaker = new CircuitBreaker(externalService, {
     timeout: 3000,
     errorThresholdPercentage: 50,
     resetTimeout: 30000
   });
   ```

#### 5. AWS Service Unavailability

**Symptoms:**
- AWS health checks failing
- S3/CloudFront access errors
- SDK timeout exceptions

**Diagnosis:**
```bash
# Check AWS service health
curl -s http://localhost:3000/api/health/aws

# Test AWS credentials
aws sts get-caller-identity

# Test S3 access
aws s3 ls s3://your-bucket-name/
```

**Solutions:**
1. **Verify credentials**:
   ```bash
   # Check AWS credentials
   cat ~/.aws/credentials
   
   # Refresh credentials
   aws configure
   ```

2. **Check service status**:
   ```bash
   # Check AWS service status
   curl https://status.aws.amazon.com/rss/all.rss
   ```

3. **Implement retry logic**:
   ```typescript
   // Add exponential backoff
   const retry = async (fn: Function, maxRetries = 3) => {
     for (let i = 0; i < maxRetries; i++) {
       try {
         return await fn();
       } catch (error) {
         if (i === maxRetries - 1) throw error;
         await new Promise(resolve => setTimeout(resolve, Math.pow(2, i) * 1000));
       }
     }
   };
   ```

### Performance Troubleshooting

#### Slow Response Times

1. **Identify slow endpoints**:
   ```bash
   curl -s http://localhost:3000/api/monitoring/performance/trends?period=1h
   ```

2. **Check database queries**:
   ```bash
   # Enable slow query logging
   # PostgreSQL: log_min_duration_statement = 1000
   ```

3. **Analyze request patterns**:
   ```typescript
   // Check response time histogram
   const histogram = metrics.getMetric('http_request_duration_seconds');
   console.log('P95:', histogram.getQuantile(0.95));
   console.log('P99:', histogram.getQuantile(0.99));
   ```

#### Memory Leaks

1. **Monitor memory usage over time**:
   ```bash
   # Track memory growth
   watch -n 5 'curl -s http://localhost:3000/api/health/metrics | jq .memory'
   ```

2. **Check for common leak patterns**:
   ```typescript
   // Event listeners not removed
   // Global variables growing
   // Timers not cleared
   ```

3. **Use heap snapshots**:
   ```bash
   # Enable heap snapshots in Node.js
   node --inspect app.js
   # Use Chrome DevTools to analyze heap
   ```

### Monitoring System Issues

#### Health Checks Failing

1. **Check health check configuration**:
   ```bash
   curl -s http://localhost:3000/api/health | jq '.config'
   ```

2. **Verify external dependencies**:
   ```bash
   # Test GitHub API
   curl -I https://api.github.com
   
   # Test NPM registry
   curl -I https://registry.npmjs.org/
   ```

3. **Check system resources**:
   ```bash
   # Disk space
   df -h
   
   # Memory
   free -h
   
   # CPU
   top -bn1
   ```

#### Alert Storm

**Symptoms:**
- Multiple alerts firing simultaneously
- Alert fatigue
- Important alerts being missed

**Solutions:**
1. **Implement alert grouping**:
   ```yaml
   # Prometheus alert grouping
   route:
     group_by: ['alertname']
     group_wait: 30s
     group_interval: 5m
     repeat_interval: 12h
   ```

2. **Set appropriate thresholds**:
   ```bash
   # Don't alert on every minor fluctuation
   ALERT_CPU_THRESHOLD=80  # Not 75
   ALERT_MEMORY_THRESHOLD=85  # Not 80
   ```

3. **Implement alert deduplication**:
   ```typescript
   // Only send alert if condition persists
   if (!alert.isActive && value > threshold) {
     await sendAlert(alert);
     alert.isActive = true;
   } else if (alert.isActive && value < threshold * 0.9) {
     alert.isActive = false;
   }
   ```

---

## Integration Examples

### Prometheus and Grafana

#### Prometheus Configuration

```yaml
# prometheus.yml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'cloudpilot'
    static_configs:
      - targets: ['localhost:3000']
    metrics_path: '/metrics'
    scrape_interval: 10s

rule_files:
  - "cloudpilot_alerts.yml"

alerting:
  alertmanagers:
    - static_configs:
        - targets:
          - alertmanager:9093
```

#### Grafana Dashboard

```json
{
  "dashboard": {
    "title": "CloudPilot Production",
    "panels": [
      {
        "title": "Request Rate",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(http_requests_total[5m])",
            "legendFormat": "{{method}} {{status}}"
          }
        ]
      },
      {
        "title": "Response Time",
        "type": "graph",
        "targets": [
          {
            "expr": "histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))",
            "legendFormat": "P95"
          }
        ]
      },
      {
        "title": "Error Rate",
        "type": "singlestat",
        "targets": [
          {
            "expr": "rate(http_errors_total[5m]) / rate(http_requests_total[5m]) * 100",
            "legendFormat": "Error Rate"
          }
        ]
      }
    ]
  }
}
```

### Kubernetes Integration

#### Deployment Configuration

```yaml
# deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: cloudpilot
spec:
  replicas: 3
  selector:
    matchLabels:
      app: cloudpilot
  template:
    metadata:
      labels:
        app: cloudpilot
    spec:
      containers:
      - name: cloudpilot
        image: cloudpilot:latest
        ports:
        - containerPort: 3000
        livenessProbe:
          httpGet:
            path: /api/live
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /api/ready
            port: 3000
          initialDelaySeconds: 5
          periodSeconds: 5
        env:
        - name: NODE_ENV
          value: "production"
        - name: LOG_LEVEL
          value: "info"
```

#### Service Monitor

```yaml
# servicemonitor.yaml
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: cloudpilot
  namespace: monitoring
spec:
  selector:
    matchLabels:
      app: cloudpilot
  endpoints:
  - port: metrics
    path: /metrics
    interval: 30s
```

### Docker Integration

#### Dockerfile

```dockerfile
FROM node:18-alpine

WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci --only=production

# Copy application code
COPY . .

# Create logs directory
RUN mkdir -p logs

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD curl -f http://localhost:3000/api/health || exit 1

EXPOSE 3000

CMD ["node", "server/index.js"]
```

#### Docker Compose

```yaml
# docker-compose.yml
version: '3.8'
services:
  cloudpilot:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - LOG_LEVEL=info
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/api/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s
    volumes:
      - ./logs:/app/logs
    depends_on:
      - postgres
      - redis

  postgres:
    image: postgres:14
    environment:
      - POSTGRES_DB=cloudpilot
      - POSTGRES_USER=cloudpilot
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine

volumes:
  postgres_data:
```

### CloudWatch Integration

```typescript
import { CloudWatch } from 'aws-sdk';

const cloudwatch = new CloudWatch({ region: 'us-east-1' });

// Send custom metrics to CloudWatch
const sendCloudWatchMetrics = async (metrics: DashboardData) => {
  const params = {
    Namespace: 'CloudPilot/Production',
    MetricData: [
      {
        MetricName: 'RequestRate',
        Value: metrics.realTimeMetrics.requestsPerSecond,
        Unit: 'Count/Second',
        Timestamp: new Date()
      },
      {
        MetricName: 'ErrorRate',
        Value: metrics.realTimeMetrics.errorRate * 100,
        Unit: 'Percent',
        Timestamp: new Date()
      },
      {
        MetricName: 'MemoryUsage',
        Value: metrics.systemMetrics.memory.percentage,
        Unit: 'Percent',
        Timestamp: new Date()
      }
    ]
  };

  await cloudwatch.putMetricData(params).promise();
};

// Schedule metric sending
setInterval(() => {
  const dashboardData = metrics.getDashboardData();
  sendCloudWatchMetrics(dashboardData);
}, 60000); // Every minute
```

### Slack Integration

```typescript
import axios from 'axios';

const slackWebhook = process.env.SLACK_WEBHOOK_URL;

const sendSlackAlert = async (alert: Alert) => {
  const color = {
    low: '#36a64f',
    medium: '#ff9500',
    high: '#ff6600',
    critical: '#ff0000'
  }[alert.severity];

  const message = {
    attachments: [
      {
        color,
        title: `🚨 Alert: ${alert.name}`,
        text: alert.description,
        fields: [
          {
            title: 'Severity',
            value: alert.severity.toUpperCase(),
            short: true
          },
          {
            title: 'Status',
            value: alert.status,
            short: true
          },
          {
            title: 'Current Value',
            value: alert.current_value.toString(),
            short: true
          },
          {
            title: 'Threshold',
            value: alert.threshold.toString(),
            short: true
          }
        ],
        ts: Math.floor(Date.now() / 1000)
      }
    ]
  };

  await axios.post(slackWebhook, message);
};
```

---

## Production Deployment Notes

### Performance Considerations

#### Resource Allocation

```yaml
# Recommended resource limits for production
resources:
  requests:
    cpu: "500m"
    memory: "512Mi"
  limits:
    cpu: "2000m"
    memory: "2Gi"
```

#### Optimization Settings

```typescript
// Environment variables for production
{
  NODE_ENV: 'production',
  LOG_LEVEL: 'info',  // Not 'debug' in production
  HEALTH_CHECK_INTERVAL: '30000',  // 30 seconds
  METRICS_RETENTION_DAYS: '30',    // Longer retention
  MAX_REQUEST_METRICS: '50000',    // More metrics storage
  PROMETHEUS_ENABLED: 'true',
  ALERT_AGGREGATION_WINDOW: '300'  // 5 minutes
}
```

### Security Best Practices

#### Access Control

```typescript
// Protect monitoring endpoints in production
const requireAuth = (req: Request, res: Response, next: NextFunction) => {
  const token = req.headers.authorization?.replace('Bearer ', '');
  
  if (!token || token !== process.env.MONITORING_TOKEN) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  
  next();
};

// Apply to monitoring endpoints
app.use('/api/monitoring', requireAuth);
app.use('/api/health', requireAuth);
```

#### Secure Headers

```typescript
// Add security headers to monitoring responses
const securityHeaders = (req: Request, res: Response, next: NextFunction) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  next();
};

app.use('/api/monitoring', securityHeaders);
app.use('/api/health', securityHeaders);
```

### Scaling Considerations

#### Horizontal Scaling

```yaml
# Kubernetes Horizontal Pod Autoscaler
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: cloudpilot-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: cloudpilot
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

#### Database Optimization

```sql
-- Optimize health check queries
CREATE INDEX idx_health_checks_timestamp ON health_checks(timestamp);
CREATE INDEX idx_health_checks_status ON health_checks(status);

-- Optimize metrics queries
CREATE INDEX idx_metrics_name_timestamp ON metrics(name, timestamp);
CREATE INDEX idx_alerts_status_severity ON alerts(status, severity);
```

### Monitoring Dashboard Deployment

#### Nginx Configuration

```nginx
# /etc/nginx/sites-available/cloudpilot-monitoring
server {
    listen 80;
    server_name monitoring.example.com;

    # Security headers
    add_header X-Content-Type-Options nosniff;
    add_header X-Frame-Options DENY;
    add_header X-XSS-Protection "1; mode=block";

    # Rate limiting
    limit_req_zone $binary_remote_addr zone=monitoring:10m rate=10r/m;

    location / {
        limit_req zone=monitoring burst=5 nodelay;
        
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

### Backup and Recovery

#### Metrics Data Backup

```bash
#!/bin/bash
# backup_metrics.sh

BACKUP_DIR="/backups/metrics"
DATE=$(date +%Y%m%d_%H%M%S)

# Backup metrics data
curl -s http://localhost:3000/api/monitoring/export?type=all > "$BACKUP_DIR/metrics_$DATE.json"

# Compress backup
gzip "$BACKUP_DIR/metrics_$DATE.json"

# Keep only last 30 days
find $BACKUP_DIR -name "metrics_*.json.gz" -mtime +30 -delete
```

#### Configuration Backup

```bash
#!/bin/bash
# backup_config.sh

CONFIG_DIR="/backups/config"
DATE=$(date +%Y%m%d_%H%M%S)

# Backup dashboard configurations
curl -s http://localhost:3000/api/monitoring/dashboard/configs > "$CONFIG_DIR/dashboards_$DATE.json"

# Backup alert configurations
curl -s http://localhost:3000/api/monitoring/alerts > "$CONFIG_DIR/alerts_$DATE.json"
```

### Maintenance Procedures

#### Log Rotation

```bash
#!/bin/bash
# log_rotation.sh

LOG_DIR="/app/logs"
DAYS_TO_KEEP=30

# Compress old logs
find $LOG_DIR -name "*.log" -mtime +1 -exec gzip {} \;

# Remove old compressed logs
find $LOG_DIR -name "*.log.gz" -mtime +$DAYS_TO_KEEP -delete

# Restart logging to new files (if using log rotation daemons)
kill -HUP $(cat /var/run/nginx.pid 2>/dev/null || echo 1)
```

#### Health Check Maintenance

```bash
#!/bin/bash
# cleanup_health_data.sh

# Clean up old health check data (keep last 30 days)
curl -X DELETE "http://localhost:3000/api/health/history?older_than=30d"

# Clean up old metrics data
curl -X DELETE "http://localhost:3000/api/monitoring/retention/cleanup"

# Verify cleanup
curl -s http://localhost:3000/api/health/history | jq '.count'
```

### Deployment Checklist

- [ ] **Security**
  - [ ] Authentication enabled for monitoring endpoints
  - [ ] SSL/TLS configured for monitoring dashboard
  - [ ] Security headers implemented
  - [ ] Sensitive data filtering active
  - [ ] Access logs enabled

- [ ] **Performance**
  - [ ] Resource limits configured
  - [ ] Auto-scaling policies defined
  - [ ] Database indexes optimized
  - [ ] Caching strategies implemented
  - [ ] CDN configured for static assets

- [ ] **Monitoring**
  - [ ] Health checks configured
  - [ ] Alert thresholds tuned
  - [ ] Dashboard panels optimized
  - [ ] Log retention policies set
  - [ ] Backup procedures tested

- [ ] **Reliability**
  - [ ] Circuit breakers implemented
  - [ ] Retry policies configured
  - [ ] Graceful degradation enabled
  - [ ] Backup and recovery tested
  - [ ] Incident response plan ready

- [ ] **Documentation**
  - [ ] Runbooks created
  - [ ] Troubleshooting guide updated
  - [ ] Contact information current
  - [ ] Escalation procedures defined
  - [ ] Testing procedures documented

---

## Additional Resources

### API Documentation
- **Monitoring Dashboard**: `/api/monitoring/docs` (when implemented)
- **Health Check API**: `/api/health/docs` (when implemented)
- **Prometheus Metrics**: `/metrics`

### External Documentation
- [Prometheus Documentation](https://prometheus.io/docs/)
- [Grafana Documentation](https://grafana.com/docs/)
- [Node.js Monitoring Best Practices](https://nodejs.org/en/docs/guides/)
- [Kubernetes Health Checks](https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/)

### Support Contacts
- **Technical Lead**: technical@example.com
- **DevOps Team**: devops@example.com
- **Emergency Contact**: +1-555-EMERGENCY

---

*Last Updated: 2025-10-31*
*Version: 1.0.0*
*Maintained by: CloudPilot Production Team*