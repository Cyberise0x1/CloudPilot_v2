#!/usr/bin/env node

/**
 * Recovery Testing Runner
 * Command-line interface for running recovery tests and generating reports
 */

import { RecoveryTestingOrchestrator } from './index.js';
import fs from 'fs';
import path from 'path';

interface CliOptions {
  command: 'test' | 'scenario' | 'validate' | 'report' | 'readiness';
  scenario?: string;
  output?: string;
  format?: 'json' | 'html' | 'csv';
  verbose?: boolean;
}

class RecoveryTestRunner {
  private orchestrator: RecoveryTestingOrchestrator;

  constructor() {
    this.orchestrator = new RecoveryTestingOrchestrator();
  }

  async run(): Promise<void> {
    const args = this.parseArgs();
    
    try {
      switch (args.command) {
        case 'test':
          await this.runFullTest(args);
          break;
        case 'scenario':
          await this.runScenarioTest(args);
          break;
        case 'validate':
          await this.validateBackups(args);
          break;
        case 'report':
          await this.generateReport(args);
          break;
        case 'readiness':
          await this.generateReadinessReport(args);
          break;
        default:
          this.showHelp();
          process.exit(1);
      }
    } catch (error) {
      console.error('Recovery testing failed:', error);
      process.exit(1);
    }
  }

  private parseArgs(): CliOptions {
    const args = process.argv.slice(2);
    
    if (args.length === 0) {
      return { command: 'test' };
    }

    const command = args[0] as CliOptions['command'];
    const options: CliOptions = { command };

    // Parse additional options
    for (let i = 1; i < args.length; i++) {
      const arg = args[i];
      
      if (arg === '--scenario' || arg === '-s') {
        options.scenario = args[++i];
      } else if (arg === '--output' || arg === '-o') {
        options.output = args[++i];
      } else if (arg === '--format' || arg === '-f') {
        options.format = args[++i] as 'json' | 'html' | 'csv';
      } else if (arg === '--verbose' || arg === '-v') {
        options.verbose = true;
      } else if (arg === '--help' || arg === '-h') {
        this.showHelp();
        process.exit(0);
      }
    }

    return options;
  }

  private async runFullTest(args: CliOptions): Promise<void> {
    console.log('🚀 Starting comprehensive recovery testing...\n');

    if (args.verbose) {
      console.log('Running all recovery test components:');
      console.log('  - Automated recovery tests');
      console.log('  - Backup integrity validation');
      console.log('  - Disaster recovery drills');
      console.log('  - Recovery procedure testing');
      console.log('  - Monitoring system validation\n');
    }

    const results = await this.orchestrator.runFullRecoveryTest();

    console.log('📊 Test Results Summary:');
    console.log(`  Total Tests: ${results.summary.totalTests}`);
    console.log(`  Passed: ${results.summary.passedTests}`);
    console.log(`  Failed: ${results.summary.failedTests}`);
    console.log(`  Coverage: ${results.summary.coverage.toFixed(1)}%\n`);

    if (results.success) {
      console.log('✅ All recovery tests passed successfully!');
    } else {
      console.log('❌ Some recovery tests failed. Review results for details.');
    }

    // Save results to file if output specified
    if (args.output) {
      await this.saveResults(results, args.output, args.format);
    }
  }

  private async runScenarioTest(args: CliOptions): Promise<void> {
    if (!args.scenario) {
      console.error('Error: Scenario ID required for scenario test');
      process.exit(1);
    }

    console.log(`🎯 Testing disaster scenario: ${args.scenario}\n`);

    const results = await this.orchestrator.testDisasterScenario(args.scenario);

    console.log('📋 Scenario Test Results:');
    console.log(`  Scenario: ${results.scenario?.name || 'Unknown'}`);
    console.log(`  Status: ${results.success ? '✅ Completed' : '❌ Failed'}`);
    console.log(`  Duration: ${results.drillResults?.actualRecoveryTime || 'N/A'}ms\n`);

    if (results.recoveryProcedure) {
      console.log('🔧 Recovery Procedure:');
      console.log(`  Success: ${results.recoveryProcedure.success}`);
      console.log(`  Duration: ${results.recoveryProcedure.duration}ms`);
      console.log(`  Errors: ${results.recoveryProcedure.errors.length}\n`);
    }

    // Save results if output specified
    if (args.output) {
      await this.saveResults(results, args.output, args.format);
    }
  }

  private async validateBackups(args: CliOptions): Promise<void> {
    console.log('🔍 Validating backup integrity...\n');

    const results = await this.orchestrator.validateAllBackups();

    console.log('📦 Backup Validation Results:');
    console.log(`  Total Backups: ${results.validationResults.totalBackups}`);
    console.log(`  Valid Backups: ${results.validationResults.validBackups}`);
    console.log(`  Corrupted Backups: ${results.validationResults.corruptedBackups}`);
    console.log(`  Missing Backups: ${results.validationResults.missingBackups}`);
    console.log(`  Overall Status: ${results.validationResults.summary.healthy ? '✅ Healthy' : '❌ Issues Found'}\n`);

    if (results.issues.length > 0) {
      console.log('⚠️  Issues Found:');
      results.issues.forEach(issue => console.log(`  - ${issue}`));
      console.log();
    }

    if (results.recommendations.length > 0) {
      console.log('💡 Recommendations:');
      results.recommendations.forEach(rec => console.log(`  - ${rec}`));
      console.log();
    }

    // Save results if output specified
    if (args.output) {
      await this.saveResults(results, args.output, args.format);
    }
  }

  private async generateReport(args: CliOptions): Promise<void> {
    const format = args.format || 'html';
    const output = args.output || `recovery-report.${format}`;
    
    console.log(`📄 Generating ${format.toUpperCase()} report...\n`);

    const endTime = new Date();
    const startTime = new Date(endTime.getTime() - 7 * 24 * 60 * 60 * 1000); // Last 7 days

    const report = await this.orchestrator['monitoringSystem'].generateMonitoringReport(
      startTime.toISOString(),
      endTime.toISOString(),
      format
    );

    await fs.promises.writeFile(output, report);
    
    console.log(`✅ Report saved to: ${output}`);
    
    if (args.verbose) {
      console.log(`Report format: ${format}`);
      console.log(`Period: ${startTime.toISOString()} to ${endTime.toISOString()}`);
    }
  }

  private async generateReadinessReport(args: CliOptions): Promise<void> {
    console.log('📊 Generating recovery readiness report...\n');

    const results = await this.orchestrator.generateRecoveryReadinessReport();

    console.log('🎯 Recovery Readiness Assessment:');
    console.log(`  Overall Readiness: ${results.overallReadiness.toFixed(1)}%\n`);

    console.log('📈 Category Scores:');
    console.log(`  Backups: ${results.categories.backups.toFixed(1)}%`);
    console.log(`  Procedures: ${results.categories.procedures.toFixed(1)}%`);
    console.log(`  Monitoring: ${results.categories.monitoring.toFixed(1)}%`);
    console.log(`  Testing: ${results.categories.testing.toFixed(1)}%\n`);

    if (results.criticalGaps.length > 0) {
      console.log('🚨 Critical Gaps:');
      results.criticalGaps.forEach(gap => console.log(`  - ${gap}`));
      console.log();
    }

    if (results.recommendations.length > 0) {
      console.log('💡 Recommendations:');
      results.recommendations.forEach(rec => console.log(`  - ${rec}`));
      console.log();
    }

    // Save results if output specified
    if (args.output) {
      await this.saveResults(results, args.output, args.format);
    }
  }

  private async saveResults(results: any, output: string, format?: string): Promise<void> {
    let content: string;
    
    if (format === 'html') {
      content = this.convertToHtml(results);
    } else if (format === 'csv') {
      content = this.convertToCsv(results);
    } else {
      content = JSON.stringify(results, null, 2);
    }

    await fs.promises.writeFile(output, content);
    console.log(`\n📄 Results saved to: ${output}`);
  }

  private convertToHtml(results: any): string {
    return `<!DOCTYPE html>
<html>
<head>
    <title>Recovery Testing Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .header { color: #333; border-bottom: 2px solid #007acc; padding-bottom: 10px; }
        .success { color: #28a745; }
        .error { color: #dc3545; }
        .warning { color: #ffc107; }
        .summary { background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0; }
        .details { margin: 20px 0; }
        pre { background: #f8f9fa; padding: 15px; border-radius: 5px; overflow-x: auto; }
    </style>
</head>
<body>
    <h1 class="header">Recovery Testing Report</h1>
    <div class="summary">
        <h2>Summary</h2>
        <p>Generated: ${new Date().toISOString()}</p>
        ${results.summary ? `
        <p><strong>Total Tests:</strong> ${results.summary.totalTests}</p>
        <p><strong>Passed:</strong> <span class="success">${results.summary.passedTests}</span></p>
        <p><strong>Failed:</strong> <span class="error">${results.summary.failedTests}</span></p>
        <p><strong>Coverage:</strong> ${results.summary.coverage.toFixed(1)}%</p>
        ` : ''}
    </div>
    <div class="details">
        <h2>Detailed Results</h2>
        <pre>${JSON.stringify(results, null, 2)}</pre>
    </div>
</body>
</html>`;
  }

  private convertToCsv(results: any): string {
    // Simple CSV conversion - would need to be more sophisticated in real implementation
    return `Type,Count,Status
Recovery Tests,${results.summary?.totalTests || 0},${results.summary?.failedTests === 0 ? 'PASS' : 'FAIL'}
Backups,${results.validationResults?.totalBackups || 0},${results.validationResults?.summary.healthy ? 'PASS' : 'WARN'}
`;
  }

  private showHelp(): void {
    console.log(`
Recovery Testing Suite

Usage: node recovery-test-runner.js <command> [options]

Commands:
  test                 Run comprehensive recovery testing
  scenario <id>        Test specific disaster scenario
  validate             Validate backup integrity
  report               Generate monitoring report
  readiness            Generate recovery readiness report

Options:
  -s, --scenario <id>  Specify scenario ID for testing
  -o, --output <file>  Output file for results
  -f, --format <fmt>   Output format (json|html|csv)
  -v, --verbose        Verbose output
  -h, --help           Show this help message

Examples:
  # Run all recovery tests
  node recovery-test-runner.js test

  # Test specific scenario
  node recovery-test-runner.js scenario --scenario db-corruption

  # Validate backups and save HTML report
  node recovery-test-runner.js validate --output backup-report.html --format html

  # Generate recovery readiness report
  node recovery-test-runner.js readiness --output readiness.json

  # Generate monitoring report in CSV format
  node recovery-test-runner.js report --output monitoring.csv --format csv
`);
  }
}

// Run the CLI
if (import.meta.url === `file://${process.argv[1]}`) {
  const runner = new RecoveryTestRunner();
  runner.run().catch(error => {
    console.error('Recovery test runner failed:', error);
    process.exit(1);
  });
}

export default RecoveryTestRunner;