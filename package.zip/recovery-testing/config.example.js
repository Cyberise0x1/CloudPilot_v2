/**
 * Example Recovery Testing Configuration
 * Copy this file to config.js and customize for your environment
 */

export const recoveryTestingConfig = {
  // Test execution settings
  testExecution: {
    timeout: 3600000, // 1 hour in milliseconds
    parallelExecution: false,
    retryFailedTests: 3,
    testDataPath: './test-data',
    backupPath: './backups',
    recoveryPath: './recovery'
  },

  // Backup settings
  backups: {
    locations: [
      './backups/daily',
      './backups/weekly',
      './backups/monthly',
      './backups/emergency'
    ],
    retentionDays: 30,
    compressionEnabled: true,
    encryptionEnabled: true,
    validationEnabled: true
  },

  // Recovery Time Objectives (RTO) in seconds
  recoveryTimeObjectives: {
    'database-corruption': 3600, // 1 hour
    'data-center-outage': 14400, // 4 hours
    'security-breach': 21600, // 6 hours
    'network-partition': 1800, // 30 minutes
    'storage-failure': 7200, // 2 hours
    'cascading-failure': 10800, // 3 hours
    'natural-disaster': 172800, // 48 hours
    'cyber-attack': 28800 // 8 hours
  },

  // Recovery Point Objectives (RPO) in seconds
  recoveryPointObjectives: {
    'database-corruption': 300, // 5 minutes
    'data-center-outage': 900, // 15 minutes
    'security-breach': 0, // No data loss
    'network-partition': 60, // 1 minute
    'storage-failure': 180, // 3 minutes
    'cascading-failure': 600, // 10 minutes
    'natural-disaster': 3600, // 1 hour
    'cyber-attack': 0 // No data loss
  },

  // Monitoring configuration
  monitoring: {
    enabled: true,
    pollingInterval: 60, // seconds
    metricsRetention: 30, // days
    logLevel: 'info', // debug | info | warn | error
    alertThresholds: {
      backupFailure: 5, // percentage
      recoveryTime: 3600, // seconds
      storageUsage: 85, // percentage
      networkLatency: 100, // milliseconds
      diskIOWait: 20, // percentage
      memoryUsage: 80, // percentage
      cpuUsage: 80 // percentage
    },
    notifications: {
      email: {
        enabled: true,
        smtpServer: 'smtp.company.com',
        recipients: [
          'recovery-team@company.com',
          'ops-manager@company.com'
        ]
      },
      slack: {
        enabled: true,
        webhookUrl: 'https://hooks.slack.com/...',
        channel: '#recovery-alerts'
      },
      pagerduty: {
        enabled: true,
        integrationKey: 'your-integration-key'
      }
    }
  },

  // Disaster recovery drills configuration
  disasterDrills: {
    enabled: true,
    frequency: 'monthly', // daily | weekly | monthly | quarterly
    participants: [
      'recovery-coordinator',
      'technical-team',
      'management',
      'communications-team'
    ],
    scenarios: [
      'database-corruption',
      'data-center-outage',
      'security-breach',
      'network-partition',
      'storage-failure',
      'cascading-failure',
      'natural-disaster',
      'cyber-attack'
    ]
  },

  // Security settings
  security: {
    encryptionAlgorithm: 'AES-256-GCM',
    keyRotationDays: 90,
    accessControl: {
      recoveryTests: ['recovery-team', 'devops'],
      drillParticipation: ['recovery-team', 'management'],
      monitoring: ['operations', 'security']
    }
  },

  // Reporting settings
  reporting: {
    enabled: true,
    formats: ['json', 'html', 'csv'],
    schedule: 'weekly',
    recipients: [
      'cto@company.com',
      'operations-director@company.com'
    ],
    storage: {
      local: './reports',
      s3: {
        bucket: 'recovery-test-reports',
        region: 'us-east-1'
      }
    }
  },

  // Environment-specific overrides
  environments: {
    development: {
      testExecution: {
        timeout: 1800000 // 30 minutes for dev
      },
      monitoring: {
        logLevel: 'debug'
      }
    },
    staging: {
      testExecution: {
        timeout: 2700000 // 45 minutes for staging
      },
      monitoring: {
        logLevel: 'info'
      }
    },
    production: {
      testExecution: {
        timeout: 3600000 // Full hour for production
      },
      monitoring: {
        logLevel: 'warn',
        notifications: {
          email: {
            enabled: true
          },
          slack: {
            enabled: true
          },
          pagerduty: {
            enabled: true
          }
        }
      }
    }
  }
};

export default recoveryTestingConfig;