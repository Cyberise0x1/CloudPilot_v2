/**
 * Recovery Monitoring
 * Comprehensive monitoring and alerting for backup and recovery operations
 */

import { EventEmitter } from 'events';
import fs from 'fs/promises';
import path from 'path';

interface MonitoringConfig {
  metricsRetention: number; // Days to retain metrics
  alertThresholds: AlertThresholds;
  pollingInterval: number; // Seconds between metric collection
  logLevel: 'debug' | 'info' | 'warn' | 'error';
  backupLocations: string[];
  monitoringEnabled: boolean;
}

interface AlertThresholds {
  backupFailure: number; // Percentage threshold for backup failure alerts
  recoveryTime: number; // Maximum acceptable recovery time in seconds
  storageUsage: number; // Maximum storage usage percentage
  networkLatency: number; // Maximum acceptable network latency
  diskIOWait: number; // Maximum acceptable disk I/O wait time
  memoryUsage: number; // Maximum memory usage percentage
  cpuUsage: number; // Maximum CPU usage percentage
}

interface MetricData {
  timestamp: string;
  type: 'backup' | 'recovery' | 'system' | 'performance';
  name: string;
  value: number;
  unit: string;
  status: 'normal' | 'warning' | 'critical';
  tags: Record<string, string>;
}

interface BackupMetrics {
  backupId: string;
  startTime: string;
  endTime?: string;
  status: 'running' | 'completed' | 'failed' | 'cancelled';
  duration?: number;
  size: number;
  compressionRatio: number;
  throughput: number; // MB/s
  errors: string[];
  warnings: string[];
  location: string;
  type: 'full' | 'incremental' | 'differential';
}

interface RecoveryMetrics {
  recoveryId: string;
  startTime: string;
  endTime?: string;
  status: 'running' | 'completed' | 'failed' | 'cancelled';
  duration?: number;
  dataRestored: number;
  throughput: number; // MB/s
  rto: number; // Recovery Time Objective
  rpo: number; // Recovery Point Objective
  errors: string[];
  warnings: string[];
  steps: RecoveryStepMetric[];
}

interface RecoveryStepMetric {
  stepId: string;
  name: string;
  startTime: string;
  endTime?: string;
  duration?: number;
  status: 'pending' | 'running' | 'completed' | 'failed' | 'skipped';
  errors: string[];
  warnings: string[];
}

interface SystemMetrics {
  timestamp: string;
  cpuUsage: number;
  memoryUsage: number;
  diskUsage: number;
  diskIOWait: number;
  networkLatency: number;
  networkThroughput: number;
  connections: number;
  processes: number;
}

interface Alert {
  id: string;
  timestamp: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  type: 'backup' | 'recovery' | 'system' | 'performance';
  title: string;
  message: string;
  metric?: MetricData;
  resolved: boolean;
  resolvedAt?: string;
  escalationLevel: number;
  notificationSent: boolean;
}

export class RecoveryMonitoringSystem {
  private config: MonitoringConfig;
  private eventEmitter: EventEmitter;
  private metricsHistory: MetricData[];
  private backupMetrics: Map<string, BackupMetrics>;
  private recoveryMetrics: Map<string, RecoveryMetrics>;
  private systemMetrics: SystemMetrics[];
  private activeAlerts: Map<string, Alert>;
  private monitoringInterval?: NodeJS.Timeout;

  constructor(config: Partial<MonitoringConfig> = {}) {
    this.config = {
      metricsRetention: 30,
      alertThresholds: {
        backupFailure: 5, // 5% failure rate
        recoveryTime: 3600, // 1 hour
        storageUsage: 85, // 85%
        networkLatency: 100, // 100ms
        diskIOWait: 20, // 20%
        memoryUsage: 80, // 80%
        cpuUsage: 80 // 80%
      },
      pollingInterval: 60, // 1 minute
      logLevel: 'info',
      backupLocations: ['./backups/daily', './backups/weekly', './backups/monthly'],
      monitoringEnabled: true,
      ...config
    };

    this.eventEmitter = new EventEmitter();
    this.metricsHistory = [];
    this.backupMetrics = new Map();
    this.recoveryMetrics = new Map();
    this.systemMetrics = [];
    this.activeAlerts = new Map();

    if (this.config.monitoringEnabled) {
      this.startMonitoring();
    }
  }

  /**
   * Start monitoring system
   */
  startMonitoring(): void {
    console.log('Starting recovery monitoring system...');
    
    this.monitoringInterval = setInterval(() => {
      this.collectMetrics();
      this.checkThresholds();
      this.processAlerts();
      this.cleanupOldData();
    }, this.config.pollingInterval * 1000);

    this.eventEmitter.on('backup-started', this.onBackupStarted.bind(this));
    this.eventEmitter.on('backup-completed', this.onBackupCompleted.bind(this));
    this.eventEmitter.on('backup-failed', this.onBackupFailed.bind(this));
    this.eventEmitter.on('recovery-started', this.onRecoveryStarted.bind(this));
    this.eventEmitter.on('recovery-completed', this.onRecoveryCompleted.bind(this));
    this.eventEmitter.on('recovery-failed', this.onRecoveryFailed.bind(this));
  }

  /**
   * Stop monitoring system
   */
  stopMonitoring(): void {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = undefined;
    }
    console.log('Recovery monitoring system stopped');
  }

  /**
   * Collect system metrics
   */
  private async collectMetrics(): Promise<void> {
    try {
      const systemMetrics = await this.collectSystemMetrics();
      this.systemMetrics.push(systemMetrics);
      
      // Add to metrics history
      this.addMetric({
        timestamp: systemMetrics.timestamp,
        type: 'system',
        name: 'cpu_usage',
        value: systemMetrics.cpuUsage,
        unit: 'percent',
        status: this.getStatus(systemMetrics.cpuUsage, this.config.alertThresholds.cpuUsage),
        tags: { component: 'system' }
      });

      this.addMetric({
        timestamp: systemMetrics.timestamp,
        type: 'system',
        name: 'memory_usage',
        value: systemMetrics.memoryUsage,
        unit: 'percent',
        status: this.getStatus(systemMetrics.memoryUsage, this.config.alertThresholds.memoryUsage),
        tags: { component: 'system' }
      });

      this.addMetric({
        timestamp: systemMetrics.timestamp,
        type: 'system',
        name: 'disk_usage',
        value: systemMetrics.diskUsage,
        unit: 'percent',
        status: this.getStatus(systemMetrics.diskUsage, this.config.alertThresholds.storageUsage),
        tags: { component: 'storage' }
      });

    } catch (error) {
      this.log('error', `Failed to collect system metrics: ${error.message}`);
    }
  }

  /**
   * Monitor backup operations
   */
  async monitorBackupOperation(backupId: string, location: string): Promise<void> {
    const backupMetrics: BackupMetrics = {
      backupId,
      startTime: new Date().toISOString(),
      status: 'running',
      size: 0,
      compressionRatio: 0,
      throughput: 0,
      errors: [],
      warnings: [],
      location,
      type: 'full'
    };

    this.backupMetrics.set(backupId, backupMetrics);
    this.eventEmitter.emit('backup-started', backupMetrics);

    try {
      // Monitor backup progress
      const monitoringPromises = [
        this.monitorBackupSize(backupId, location),
        this.monitorBackupThroughput(backupId, location),
        this.monitorBackupErrors(backupId, location)
      ];

      await Promise.all(monitoringPromises);

      // Complete backup monitoring
      backupMetrics.endTime = new Date().toISOString();
      backupMetrics.duration = new Date(backupMetrics.endTime).getTime() - 
                              new Date(backupMetrics.startTime).getTime();
      backupMetrics.status = 'completed';

      this.eventEmitter.emit('backup-completed', backupMetrics);
      this.log('info', `Backup ${backupId} completed successfully`);

    } catch (error) {
      backupMetrics.status = 'failed';
      backupMetrics.errors.push(error.message);
      this.eventEmitter.emit('backup-failed', backupMetrics);
      this.log('error', `Backup ${backupId} failed: ${error.message}`);
    }
  }

  /**
   * Monitor recovery operations
   */
  async monitorRecoveryOperation(recoveryId: string, procedure: string): Promise<void> {
    const recoveryMetrics: RecoveryMetrics = {
      recoveryId,
      startTime: new Date().toISOString(),
      status: 'running',
      dataRestored: 0,
      throughput: 0,
      rto: 0,
      rpo: 0,
      errors: [],
      warnings: [],
      steps: []
    };

    this.recoveryMetrics.set(recoveryId, recoveryMetrics);
    this.eventEmitter.emit('recovery-started', recoveryMetrics);

    try {
      // Monitor recovery progress
      const monitoringPromises = [
        this.monitorRecoveryProgress(recoveryId, procedure),
        this.monitorRecoveryTime(recoveryId),
        this.monitorRecoveryDataIntegrity(recoveryId)
      ];

      await Promise.all(monitoringPromises);

      // Complete recovery monitoring
      recoveryMetrics.endTime = new Date().toISOString();
      recoveryMetrics.duration = new Date(recoveryMetrics.endTime).getTime() - 
                                new Date(recoveryMetrics.startTime).getTime();
      recoveryMetrics.status = 'completed';

      this.eventEmitter.emit('recovery-completed', recoveryMetrics);
      this.log('info', `Recovery ${recoveryId} completed successfully`);

    } catch (error) {
      recoveryMetrics.status = 'failed';
      recoveryMetrics.errors.push(error.message);
      this.eventEmitter.emit('recovery-failed', recoveryMetrics);
      this.log('error', `Recovery ${recoveryId} failed: ${error.message}`);
    }
  }

  /**
   * Check alert thresholds
   */
  private checkThresholds(): void {
    // Check backup failure rate
    this.checkBackupFailureRate();
    
    // Check recovery times
    this.checkRecoveryTimes();
    
    // Check storage usage
    this.checkStorageUsage();
    
    // Check system performance
    this.checkSystemPerformance();
    
    // Check network latency
    this.checkNetworkLatency();
  }

  /**
   * Process and manage alerts
   */
  private processAlerts(): void {
    // Auto-resolve alerts that are no longer triggered
    for (const [alertId, alert] of this.activeAlerts) {
      if (this.shouldResolveAlert(alert)) {
        this.resolveAlert(alertId);
      }
    }

    // Send notifications for critical alerts
    for (const [alertId, alert] of this.activeAlerts) {
      if (!alert.notificationSent && alert.severity === 'critical') {
        this.sendNotification(alert);
        alert.notificationSent = true;
      }
    }
  }

  /**
   * Generate monitoring reports
   */
  async generateMonitoringReport(
    startTime: string, 
    endTime: string, 
    format: 'json' | 'csv' | 'html' = 'json'
  ): Promise<string> {
    const reportData = {
      period: { startTime, endTime },
      summary: {
        totalBackups: this.getBackupCountInPeriod(startTime, endTime),
        successfulBackups: this.getSuccessfulBackupCount(startTime, endTime),
        totalRecoveries: this.getRecoveryCountInPeriod(startTime, endTime),
        successfulRecoveries: this.getSuccessfulRecoveryCount(startTime, endTime),
        avgRecoveryTime: this.getAverageRecoveryTime(startTime, endTime),
        alertCount: this.getAlertCountInPeriod(startTime, endTime)
      },
      metrics: this.getMetricsInPeriod(startTime, endTime),
      alerts: this.getAlertsInPeriod(startTime, endTime),
      trends: this.calculateTrends(startTime, endTime)
    };

    switch (format) {
      case 'json':
        return JSON.stringify(reportData, null, 2);
      case 'csv':
        return this.convertToCSV(reportData);
      case 'html':
        return this.convertToHTML(reportData);
      default:
        return JSON.stringify(reportData, null, 2);
    }
  }

  /**
   * Get current system status
   */
  getCurrentStatus(): {
    overall: 'healthy' | 'warning' | 'critical';
    components: {
      backups: 'healthy' | 'warning' | 'critical';
      recoveries: 'healthy' | 'warning' | 'critical';
      storage: 'healthy' | 'warning' | 'critical';
      system: 'healthy' | 'warning' | 'critical';
    };
    activeAlerts: number;
    lastBackupTime?: string;
    lastRecoveryTime?: string;
  } {
    const backupStatus = this.getBackupStatus();
    const recoveryStatus = this.getRecoveryStatus();
    const storageStatus = this.getStorageStatus();
    const systemStatus = this.getSystemStatus();

    const overallStatus = this.determineOverallStatus([
      backupStatus,
      recoveryStatus,
      storageStatus,
      systemStatus
    ]);

    return {
      overall: overallStatus,
      components: {
        backups: backupStatus,
        recoveries: recoveryStatus,
        storage: storageStatus,
        system: systemStatus
      },
      activeAlerts: this.activeAlerts.size,
      lastBackupTime: this.getLastBackupTime(),
      lastRecoveryTime: this.getLastRecoveryTime()
    };
  }

  /**
   * Event handlers for backup operations
   */
  private onBackupStarted(backupMetrics: BackupMetrics): void {
    this.log('info', `Backup ${backupMetrics.backupId} started`);
    
    // Add metric to history
    this.addMetric({
      timestamp: backupMetrics.startTime,
      type: 'backup',
      name: 'backup_started',
      value: 1,
      unit: 'count',
      status: 'normal',
      tags: { backupId: backupMetrics.backupId, location: backupMetrics.location }
    });
  }

  private onBackupCompleted(backupMetrics: BackupMetrics): void {
    this.log('info', `Backup ${backupMetrics.backupId} completed in ${backupMetrics.duration}ms`);
    
    // Add metrics to history
    this.addMetric({
      timestamp: backupMetrics.endTime!,
      type: 'backup',
      name: 'backup_duration',
      value: backupMetrics.duration! / 1000, // Convert to seconds
      unit: 'seconds',
      status: 'normal',
      tags: { backupId: backupMetrics.backupId, type: backupMetrics.type }
    });

    this.addMetric({
      timestamp: backupMetrics.endTime!,
      type: 'backup',
      name: 'backup_size',
      value: backupMetrics.size,
      unit: 'bytes',
      status: 'normal',
      tags: { backupId: backupMetrics.backupId, type: backupMetrics.type }
    });

    this.addMetric({
      timestamp: backupMetrics.endTime!,
      type: 'backup',
      name: 'backup_compression_ratio',
      value: backupMetrics.compressionRatio,
      unit: 'ratio',
      status: 'normal',
      tags: { backupId: backupMetrics.backupId }
    });
  }

  private onBackupFailed(backupMetrics: BackupMetrics): void {
    this.log('error', `Backup ${backupMetrics.backupId} failed: ${backupMetrics.errors.join(', ')}`);
    
    // Create alert for backup failure
    this.createAlert({
      severity: 'high',
      type: 'backup',
      title: 'Backup Failed',
      message: `Backup ${backupMetrics.backupId} failed: ${backupMetrics.errors.join(', ')}`,
      tags: { backupId: backupMetrics.backupId }
    });

    // Add failure metric
    this.addMetric({
      timestamp: new Date().toISOString(),
      type: 'backup',
      name: 'backup_failed',
      value: 1,
      unit: 'count',
      status: 'critical',
      tags: { backupId: backupMetrics.backupId, location: backupMetrics.location }
    });
  }

  /**
   * Event handlers for recovery operations
   */
  private onRecoveryStarted(recoveryMetrics: RecoveryMetrics): void {
    this.log('info', `Recovery ${recoveryMetrics.recoveryId} started`);
    
    this.addMetric({
      timestamp: recoveryMetrics.startTime,
      type: 'recovery',
      name: 'recovery_started',
      value: 1,
      unit: 'count',
      status: 'normal',
      tags: { recoveryId: recoveryMetrics.recoveryId }
    });
  }

  private onRecoveryCompleted(recoveryMetrics: RecoveryMetrics): void {
    this.log('info', `Recovery ${recoveryMetrics.recoveryId} completed in ${recoveryMetrics.duration}ms`);
    
    // Check if RTO was met
    if (recoveryMetrics.rto > 0 && (recoveryMetrics.duration! / 1000) > recoveryMetrics.rto) {
      this.createAlert({
        severity: 'medium',
        type: 'recovery',
        title: 'RTO Exceeded',
        message: `Recovery ${recoveryMetrics.recoveryId} exceeded RTO by ${(recoveryMetrics.duration! / 1000) - recoveryMetrics.rto} seconds`,
        tags: { recoveryId: recoveryMetrics.recoveryId }
      });
    }

    this.addMetric({
      timestamp: recoveryMetrics.endTime!,
      type: 'recovery',
      name: 'recovery_duration',
      value: recoveryMetrics.duration! / 1000,
      unit: 'seconds',
      status: (recoveryMetrics.duration! / 1000) > recoveryMetrics.rto ? 'warning' : 'normal',
      tags: { recoveryId: recoveryMetrics.recoveryId }
    });
  }

  private onRecoveryFailed(recoveryMetrics: RecoveryMetrics): void {
    this.log('error', `Recovery ${recoveryMetrics.recoveryId} failed: ${recoveryMetrics.errors.join(', ')}`);
    
    this.createAlert({
      severity: 'critical',
      type: 'recovery',
      title: 'Recovery Failed',
      message: `Recovery ${recoveryMetrics.recoveryId} failed: ${recoveryMetrics.errors.join(', ')}`,
      tags: { recoveryId: recoveryMetrics.recoveryId }
    });

    this.addMetric({
      timestamp: new Date().toISOString(),
      type: 'recovery',
      name: 'recovery_failed',
      value: 1,
      unit: 'count',
      status: 'critical',
      tags: { recoveryId: recoveryMetrics.recoveryId }
    });
  }

  /**
   * Private helper methods
   */
  private async collectSystemMetrics(): Promise<SystemMetrics> {
    // Simulated metrics collection - replace with actual system calls
    return {
      timestamp: new Date().toISOString(),
      cpuUsage: Math.random() * 100,
      memoryUsage: Math.random() * 100,
      diskUsage: Math.random() * 100,
      diskIOWait: Math.random() * 30,
      networkLatency: Math.random() * 50,
      networkThroughput: Math.random() * 1000,
      connections: Math.floor(Math.random() * 1000),
      processes: Math.floor(Math.random() * 500)
    };
  }

  private getStatus(value: number, threshold: number): 'normal' | 'warning' | 'critical' {
    if (value >= threshold * 0.8 && value < threshold) return 'warning';
    if (value >= threshold) return 'critical';
    return 'normal';
  }

  private addMetric(metric: MetricData): void {
    this.metricsHistory.push(metric);
    
    // Keep only recent metrics based on retention policy
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - this.config.metricsRetention);
    this.metricsHistory = this.metricsHistory.filter(
      m => new Date(m.timestamp) > cutoffDate
    );
  }

  private async monitorBackupSize(backupId: string, location: string): Promise<void> {
    // Simulate backup size monitoring
    const backup = this.backupMetrics.get(backupId);
    if (backup) {
      backup.size = Math.random() * 1000000000; // 1GB simulated
    }
  }

  private async monitorBackupThroughput(backupId: string, location: string): Promise<void> {
    // Simulate throughput monitoring
    const backup = this.backupMetrics.get(backupId);
    if (backup) {
      backup.throughput = Math.random() * 100; // 100 MB/s simulated
    }
  }

  private async monitorBackupErrors(backupId: string, location: string): Promise<void> {
    // Simulate error monitoring
    if (Math.random() < 0.05) { // 5% chance of error
      const backup = this.backupMetrics.get(backupId);
      if (backup) {
        backup.errors.push('Simulated backup error');
      }
    }
  }

  private async monitorRecoveryProgress(recoveryId: string, procedure: string): Promise<void> {
    // Simulate recovery progress monitoring
    const recovery = this.recoveryMetrics.get(recoveryId);
    if (recovery) {
      recovery.dataRestored = Math.random() * 1000000000; // 1GB simulated
      recovery.throughput = Math.random() * 50; // 50 MB/s simulated
    }
  }

  private async monitorRecoveryTime(recoveryId: string): Promise<void> {
    // Simulate time monitoring
    // In real implementation, would track elapsed time
  }

  private async monitorRecoveryDataIntegrity(recoveryId: string): Promise<void> {
    // Simulate data integrity monitoring
    // In real implementation, would validate restored data
  }

  private checkBackupFailureRate(): void {
    const recentBackups = Array.from(this.backupMetrics.values())
      .filter(b => new Date(b.startTime) > new Date(Date.now() - 24 * 60 * 60 * 1000));
    
    if (recentBackups.length === 0) return;

    const failedBackups = recentBackups.filter(b => b.status === 'failed');
    const failureRate = (failedBackups.length / recentBackups.length) * 100;

    if (failureRate > this.config.alertThresholds.backupFailure) {
      this.createAlert({
        severity: 'high',
        type: 'backup',
        title: 'High Backup Failure Rate',
        message: `Backup failure rate is ${failureRate.toFixed(1)}% over the last 24 hours`,
        tags: { failureRate: failureRate.toString() }
      });
    }
  }

  private checkRecoveryTimes(): void {
    const recentRecoveries = Array.from(this.recoveryMetrics.values())
      .filter(r => r.status === 'completed' && r.duration && r.rto > 0)
      .filter(r => new Date(r.startTime) > new Date(Date.now() - 24 * 60 * 60 * 1000));

    for (const recovery of recentRecoveries) {
      if ((recovery.duration! / 1000) > recovery.rto) {
        this.createAlert({
          severity: 'medium',
          type: 'recovery',
          title: 'RTO Exceeded',
          message: `Recovery ${recovery.recoveryId} exceeded RTO by ${(recovery.duration! / 1000) - recovery.rto} seconds`,
          tags: { 
            recoveryId: recovery.recoveryId,
            actualTime: (recovery.duration! / 1000).toString(),
            rto: recovery.rto.toString()
          }
        });
      }
    }
  }

  private checkStorageUsage(): void {
    const latestSystemMetrics = this.systemMetrics[this.systemMetrics.length - 1];
    if (latestSystemMetrics) {
      const diskUsage = latestSystemMetrics.diskUsage;
      
      if (diskUsage > this.config.alertThresholds.storageUsage) {
        this.createAlert({
          severity: 'high',
          type: 'system',
          title: 'High Storage Usage',
          message: `Storage usage is at ${diskUsage.toFixed(1)}%`,
          tags: { storageUsage: diskUsage.toString() }
        });
      }
    }
  }

  private checkSystemPerformance(): void {
    const latestSystemMetrics = this.systemMetrics[this.systemMetrics.length - 1];
    if (latestSystemMetrics) {
      const cpuUsage = latestSystemMetrics.cpuUsage;
      const memoryUsage = latestSystemMetrics.memoryUsage;

      if (cpuUsage > this.config.alertThresholds.cpuUsage) {
        this.createAlert({
          severity: 'medium',
          type: 'system',
          title: 'High CPU Usage',
          message: `CPU usage is at ${cpuUsage.toFixed(1)}%`,
          tags: { cpuUsage: cpuUsage.toString() }
        });
      }

      if (memoryUsage > this.config.alertThresholds.memoryUsage) {
        this.createAlert({
          severity: 'medium',
          type: 'system',
          title: 'High Memory Usage',
          message: `Memory usage is at ${memoryUsage.toFixed(1)}%`,
          tags: { memoryUsage: memoryUsage.toString() }
        });
      }
    }
  }

  private checkNetworkLatency(): void {
    const latestSystemMetrics = this.systemMetrics[this.systemMetrics.length - 1];
    if (latestSystemMetrics) {
      const networkLatency = latestSystemMetrics.networkLatency;

      if (networkLatency > this.config.alertThresholds.networkLatency) {
        this.createAlert({
          severity: 'medium',
          type: 'system',
          title: 'High Network Latency',
          message: `Network latency is at ${networkLatency.toFixed(1)}ms`,
          tags: { networkLatency: networkLatency.toString() }
        });
      }
    }
  }

  private createAlert(alertData: {
    severity: Alert['severity'];
    type: Alert['type'];
    title: string;
    message: string;
    tags?: Record<string, string>;
  }): void {
    const alertId = `alert-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const alert: Alert = {
      id: alertId,
      timestamp: new Date().toISOString(),
      severity: alertData.severity,
      type: alertData.type,
      title: alertData.title,
      message: alertData.message,
      resolved: false,
      escalationLevel: this.calculateEscalationLevel(alertData.severity),
      notificationSent: false,
      tags: alertData.tags || {}
    };

    this.activeAlerts.set(alertId, alert);
    this.log('warn', `Alert created: ${alert.title} - ${alert.message}`);
  }

  private resolveAlert(alertId: string): void {
    const alert = this.activeAlerts.get(alertId);
    if (alert && !alert.resolved) {
      alert.resolved = true;
      alert.resolvedAt = new Date().toISOString();
      this.log('info', `Alert resolved: ${alert.title}`);
    }
  }

  private shouldResolveAlert(alert: Alert): boolean {
    // Implementation would check if alert conditions are no longer present
    return false; // Simplified for this example
  }

  private sendNotification(alert: Alert): void {
    console.log(`NOTIFICATION: ${alert.severity.toUpperCase()} - ${alert.title}`);
    console.log(`Message: ${alert.message}`);
    console.log(`Time: ${alert.timestamp}`);
    
    // In real implementation, would send email, Slack, PagerDuty, etc.
  }

  private calculateEscalationLevel(severity: Alert['severity']): number {
    switch (severity) {
      case 'critical': return 3;
      case 'high': return 2;
      case 'medium': return 1;
      case 'low': return 0;
      default: return 0;
    }
  }

  private cleanupOldData(): void {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - this.config.metricsRetention);

    // Clean up old metrics
    this.metricsHistory = this.metricsHistory.filter(
      m => new Date(m.timestamp) > cutoffDate
    );

    // Clean up old system metrics
    this.systemMetrics = this.systemMetrics.filter(
      m => new Date(m.timestamp) > cutoffDate
    );

    // Clean up resolved alerts older than 7 days
    const alertCutoffDate = new Date();
    alertCutoffDate.setDate(alertCutoffDate.getDate() - 7);

    for (const [alertId, alert] of this.activeAlerts) {
      if (alert.resolved && alert.resolvedAt && new Date(alert.resolvedAt) < alertCutoffDate) {
        this.activeAlerts.delete(alertId);
      }
    }
  }

  private log(level: string, message: string): void {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] [${level.toUpperCase()}] ${message}`);
  }

  // Additional helper methods for reporting and status
  private getBackupCountInPeriod(startTime: string, endTime: string): number {
    return Array.from(this.backupMetrics.values())
      .filter(b => new Date(b.startTime) >= new Date(startTime) && 
                   new Date(b.startTime) <= new Date(endTime)).length;
  }

  private getSuccessfulBackupCount(startTime: string, endTime: string): number {
    return Array.from(this.backupMetrics.values())
      .filter(b => b.status === 'completed' &&
                   new Date(b.startTime) >= new Date(startTime) && 
                   new Date(b.startTime) <= new Date(endTime)).length;
  }

  private getRecoveryCountInPeriod(startTime: string, endTime: string): number {
    return Array.from(this.recoveryMetrics.values())
      .filter(r => new Date(r.startTime) >= new Date(startTime) && 
                   new Date(r.startTime) <= new Date(endTime)).length;
  }

  private getSuccessfulRecoveryCount(startTime: string, endTime: string): number {
    return Array.from(this.recoveryMetrics.values())
      .filter(r => r.status === 'completed' &&
                   new Date(r.startTime) >= new Date(startTime) && 
                   new Date(r.startTime) <= new Date(endTime)).length;
  }

  private getAverageRecoveryTime(startTime: string, endTime: string): number {
    const completedRecoveries = Array.from(this.recoveryMetrics.values())
      .filter(r => r.status === 'completed' && r.duration &&
                   new Date(r.startTime) >= new Date(startTime) && 
                   new Date(r.startTime) <= new Date(endTime));
    
    if (completedRecoveries.length === 0) return 0;
    
    const totalTime = completedRecoveries.reduce((sum, r) => sum + r.duration!, 0);
    return totalTime / completedRecoveries.length / 1000; // Convert to seconds
  }

  private getAlertCountInPeriod(startTime: string, endTime: string): number {
    return Array.from(this.activeAlerts.values())
      .filter(a => new Date(a.timestamp) >= new Date(startTime) && 
                   new Date(a.timestamp) <= new Date(endTime)).length;
  }

  private getMetricsInPeriod(startTime: string, endTime: string): MetricData[] {
    return this.metricsHistory.filter(
      m => new Date(m.timestamp) >= new Date(startTime) && 
           new Date(m.timestamp) <= new Date(endTime)
    );
  }

  private getAlertsInPeriod(startTime: string, endTime: string): Alert[] {
    return Array.from(this.activeAlerts.values())
      .filter(a => new Date(a.timestamp) >= new Date(startTime) && 
                   new Date(a.timestamp) <= new Date(endTime));
  }

  private calculateTrends(startTime: string, endTime: string): any {
    // Simplified trend calculation
    return {
      backupSuccessRate: 'stable',
      recoveryTimeTrend: 'improving',
      storageUsageTrend: 'increasing',
      alertFrequencyTrend: 'stable'
    };
  }

  private convertToCSV(reportData: any): string {
    // Simplified CSV conversion
    return 'timestamp,metric,value,unit,status\n' + 
           reportData.metrics.map((m: any) => 
             `${m.timestamp},${m.name},${m.value},${m.unit},${m.status}`
           ).join('\n');
  }

  private convertToHTML(reportData: any): string {
    // Simplified HTML conversion
    return `<!DOCTYPE html>
<html>
<head><title>Recovery Monitoring Report</title></head>
<body>
<h1>Recovery Monitoring Report</h1>
<p>Period: ${reportData.period.startTime} to ${reportData.period.endTime}</p>
<h2>Summary</h2>
<ul>
<li>Total Backups: ${reportData.summary.totalBackups}</li>
<li>Successful Backups: ${reportData.summary.successfulBackups}</li>
<li>Total Recoveries: ${reportData.summary.totalRecoveries}</li>
<li>Successful Recoveries: ${reportData.summary.successfulRecoveries}</li>
</ul>
</body>
</html>`;
  }

  private getBackupStatus(): 'healthy' | 'warning' | 'critical' {
    const recentBackups = Array.from(this.backupMetrics.values())
      .filter(b => new Date(b.startTime) > new Date(Date.now() - 24 * 60 * 60 * 1000));
    
    if (recentBackups.length === 0) return 'warning';
    
    const failedBackups = recentBackups.filter(b => b.status === 'failed');
    const failureRate = (failedBackups.length / recentBackups.length) * 100;
    
    if (failureRate > 10) return 'critical';
    if (failureRate > 5) return 'warning';
    return 'healthy';
  }

  private getRecoveryStatus(): 'healthy' | 'warning' | 'critical' {
    const recentRecoveries = Array.from(this.recoveryMetrics.values())
      .filter(r => new Date(r.startTime) > new Date(Date.now() - 24 * 60 * 60 * 1000));
    
    if (recentRecoveries.length === 0) return 'warning';
    
    const failedRecoveries = recentRecoveries.filter(r => r.status === 'failed');
    if (failedRecoveries.length > 0) return 'critical';
    
    const exceededRTO = recentRecoveries.filter(r => 
      r.duration && r.rto > 0 && (r.duration / 1000) > r.rto
    );
    
    if (exceededRTO.length > 0) return 'warning';
    return 'healthy';
  }

  private getStorageStatus(): 'healthy' | 'warning' | 'critical' {
    const latestSystemMetrics = this.systemMetrics[this.systemMetrics.length - 1];
    if (!latestSystemMetrics) return 'warning';
    
    const diskUsage = latestSystemMetrics.diskUsage;
    if (diskUsage > 90) return 'critical';
    if (diskUsage > 80) return 'warning';
    return 'healthy';
  }

  private getSystemStatus(): 'healthy' | 'warning' | 'critical' {
    const latestSystemMetrics = this.systemMetrics[this.systemMetrics.length - 1];
    if (!latestSystemMetrics) return 'warning';
    
    const cpuUsage = latestSystemMetrics.cpuUsage;
    const memoryUsage = latestSystemMetrics.memoryUsage;
    
    if (cpuUsage > 90 || memoryUsage > 90) return 'critical';
    if (cpuUsage > 80 || memoryUsage > 80) return 'warning';
    return 'healthy';
  }

  private determineOverallStatus(statuses: string[]): 'healthy' | 'warning' | 'critical' {
    if (statuses.includes('critical')) return 'critical';
    if (statuses.includes('warning')) return 'warning';
    return 'healthy';
  }

  private getLastBackupTime(): string | undefined {
    const completedBackups = Array.from(this.backupMetrics.values())
      .filter(b => b.status === 'completed')
      .sort((a, b) => new Date(b.endTime!).getTime() - new Date(a.endTime!).getTime());
    
    return completedBackups[0]?.endTime;
  }

  private getLastRecoveryTime(): string | undefined {
    const completedRecoveries = Array.from(this.recoveryMetrics.values())
      .filter(r => r.status === 'completed')
      .sort((a, b) => new Date(b.endTime!).getTime() - new Date(a.endTime!).getTime());
    
    return completedRecoveries[0]?.endTime;
  }
}

export default RecoveryMonitoringSystem;