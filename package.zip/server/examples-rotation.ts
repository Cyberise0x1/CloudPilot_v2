/**
 * Example usage of the Secrets Rotation System
 */

import {
  rotationSystem,
  registerSecret,
  rotateSecret,
  rotateDueSecrets,
  startRotationScheduler,
  stopRotationScheduler,
  scheduleRotation,
  getRotationStatus,
  getAuditLog,
  eventEmitter,
  type Secret
} from './secrets-rotation';

/**
 * Example 1: Basic Secret Registration and Rotation
 */
async function basicRotationExample() {
  console.log('\n=== Basic Rotation Example ===');

  // Define a secret
  const apiKeySecret: Secret = {
    id: 'api-key-main',
    name: 'Main API Key',
    value: 'current-api-key-value',
    version: 1,
    lastRotated: new Date(),
    nextRotation: new Date(),
    rotationInterval: 30, // Rotate every 30 days
    isActive: true,
    environment: 'production',
    metadata: {
      service: 'api-gateway',
      owner: 'backend-team'
    }
  };

  // Register the secret
  await registerSecret(apiKeySecret);
  console.log('✅ Secret registered for rotation');

  // Manually rotate the secret
  const rotationEvent = await rotateSecret('api-key-main', 'example-script');
  console.log(`✅ Secret rotated: ${rotationEvent.status}`);
  console.log(`   Duration: ${rotationEvent.duration}ms`);
  console.log(`   Version: ${rotationEvent.oldVersion} → ${rotationEvent.newVersion}`);
}

/**
 * Example 2: Multiple Secrets with Different Schedules
 */
async function multipleSecretsExample() {
  console.log('\n=== Multiple Secrets Example ===');

  // Database credentials
  const dbSecret: Secret = {
    id: 'db-credentials',
    name: 'Database Password',
    value: 'current-db-password',
    version: 2,
    lastRotated: new Date(Date.now() - 25 * 24 * 60 * 60 * 1000), // 25 days ago
    nextRotation: new Date(),
    rotationInterval: 30,
    isActive: true,
    environment: 'production',
    metadata: {
      type: 'database',
      system: 'postgresql'
    }
  };

  // OAuth client secret
  const oauthSecret: Secret = {
    id: 'oauth-client-secret',
    name: 'OAuth Client Secret',
    value: 'current-oauth-secret',
    version: 1,
    lastRotated: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000), // 60 days ago
    nextRotation: new Date(),
    rotationInterval: 90,
    isActive: true,
    environment: 'production',
    metadata: {
      application: 'mobile-app',
      provider: 'oauth2'
    }
  };

  // JWT signing key
  const jwtSecret: Secret = {
    id: 'jwt-signing-key',
    name: 'JWT Signing Key',
    value: 'current-jwt-key',
    version: 3,
    lastRotated: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000), // 45 days ago
    nextRotation: new Date(),
    rotationInterval: 60,
    isActive: true,
    environment: 'production',
    metadata: {
      algorithm: 'RS256',
      purpose: 'token-signing'
    }
  };

  // Register all secrets
  await registerSecret(dbSecret);
  await registerSecret(oauthSecret);
  await registerSecret(jwtSecret);
  console.log('✅ 3 secrets registered');

  // Rotate all due secrets
  const dueSecrets = await rotateDueSecrets('bulk-rotation');
  console.log(`✅ Rotated ${dueSecrets.length} due secrets`);
}

/**
 * Example 3: Scheduled Rotation
 */
async function scheduledRotationExample() {
  console.log('\n=== Scheduled Rotation Example ===');

  // Schedule daily rotation for critical secrets
  scheduleRotation('api-key-main', '0 2 * * *'); // 2 AM daily
  scheduleRotation('db-credentials', '0 3 */7 * *'); // 3 AM every 7 days

  console.log('✅ Rotation schedules configured');

  // Start the scheduler
  startRotationScheduler();
  console.log('✅ Rotation scheduler started');

  // In a real application, you would keep the scheduler running
  // For this example, we'll stop it after a short time
  setTimeout(() => {
    stopRotationScheduler();
    console.log('🛑 Rotation scheduler stopped');
  }, 5000);
}

/**
 * Example 4: Status Monitoring
 */
async function statusMonitoringExample() {
  console.log('\n=== Status Monitoring Example ===');

  // Check rotation status for a specific secret
  const status = await getRotationStatus('api-key-main');
  console.log('📊 Rotation Status:');
  console.log(`   Secret: ${status.secret?.name}`);
  console.log(`   Current Version: ${status.secret?.version}`);
  console.log(`   Last Rotated: ${status.secret?.lastRotated.toISOString()}`);
  console.log(`   Next Rotation: ${status.nextRotation?.toISOString()}`);
  console.log(`   Rotation Interval: ${status.secret?.rotationInterval} days`);

  // Check if rotation is due
  const now = new Date();
  const isDue = status.secret ? 
    (now.getTime() - status.secret.lastRotated.getTime()) / (1000 * 60 * 60 * 24) >= status.secret.rotationInterval :
    false;
  console.log(`   Rotation Due: ${isDue ? 'Yes' : 'No'}`);
}

/**
 * Example 5: Audit Log and Event Monitoring
 */
async function auditAndMonitoringExample() {
  console.log('\n=== Audit and Monitoring Example ===');

  // Listen for rotation events
  eventEmitter.on('rotation_event', (event) => {
    console.log(`🔔 Rotation Event: ${event.secretName} - ${event.status}`);
    if (event.status === 'failed') {
      console.log(`   Error: ${event.error}`);
    }
    console.log(`   Duration: ${event.duration}ms`);
  });

  // Listen for notifications
  eventEmitter.on('notification', (notification) => {
    console.log(`📢 Notification: ${notification.type}`);
  });

  // Get recent audit log
  const auditLog = getAuditLog(10);
  console.log('📋 Recent Audit Log:');
  auditLog.forEach(event => {
    console.log(`   ${event.timestamp.toISOString()}: ${event.secretName} - ${event.status}`);
  });
}

/**
 * Example 6: Environment-Specific Rotation
 */
async function environmentSpecificExample() {
  console.log('\n=== Environment-Specific Example ===');

  // Development secrets - rotate more frequently
  const devApiKey: Secret = {
    id: 'dev-api-key',
    name: 'Development API Key',
    value: 'dev-api-key-value',
    version: 1,
    lastRotated: new Date(),
    nextRotation: new Date(),
    rotationInterval: 7, // Weekly for dev
    isActive: true,
    environment: 'development'
  };

  // Production secrets - more conservative
  const prodApiKey: Secret = {
    id: 'prod-api-key',
    name: 'Production API Key',
    value: 'prod-api-key-value',
    version: 1,
    lastRotated: new Date(),
    nextRotation: new Date(),
    rotationInterval: 90, // Quarterly for prod
    isActive: true,
    environment: 'production'
  };

  await registerSecret(devApiKey);
  await registerSecret(prodApiKey);

  // Rotate only production secrets due for rotation
  const allSecrets = await rotationSystem.rotateDueSecrets('environment-check');
  const prodSecrets = allSecrets.filter(event => 
    event.secretId.includes('prod-')
  );

  console.log(`✅ Rotated ${prodSecrets.length} production secrets`);
}

/**
 * Main execution function
 */
async function runExamples() {
  console.log('🚀 Starting Secrets Rotation System Examples\n');

  try {
    // Run examples in sequence
    await basicRotationExample();
    await new Promise(resolve => setTimeout(resolve, 1000)); // Small delay

    await multipleSecretsExample();
    await new Promise(resolve => setTimeout(resolve, 1000));

    await statusMonitoringExample();
    await new Promise(resolve => setTimeout(resolve, 1000));

    await auditAndMonitoringExample();
    await new Promise(resolve => setTimeout(resolve, 1000));

    await environmentSpecificExample();
    await new Promise(resolve => setTimeout(resolve, 1000));

    await scheduledRotationExample();

    console.log('\n✅ All examples completed successfully!');
    
    // Display final audit summary
    const finalAuditLog = getAuditLog();
    console.log(`\n📊 Final Summary:`);
    console.log(`   Total rotation events: ${finalAuditLog.length}`);
    console.log(`   Successful: ${finalAuditLog.filter(e => e.status === 'success').length}`);
    console.log(`   Failed: ${finalAuditLog.filter(e => e.status === 'failed').length}`);
    console.log(`   Rollbacks: ${finalAuditLog.filter(e => e.status === 'rollback').length}`);

  } catch (error) {
    console.error('❌ Example failed:', error);
  }
}

// Export functions for external use
export {
  basicRotationExample,
  multipleSecretsExample,
  scheduledRotationExample,
  statusMonitoringExample,
  auditAndMonitoringExample,
  environmentSpecificExample,
  runExamples
};

// Run examples if this file is executed directly
if (require.main === module) {
  runExamples().catch(console.error);
}
