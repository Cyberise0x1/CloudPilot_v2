import express, { Request, Response, NextFunction } from 'express';
import { 
  validateBody, 
  validateQuery, 
  validateParams,
  validateFileUpload,
  comprehensiveValidation,
  validationSchemas,
  customValidators,
  ValidationError
} from './validation';
import Joi from 'joi';
import { z } from 'zod';

const app = express();
app.use(express.json());

/**
 * Example 1: Basic body validation with Joi
 */
const userSchema = Joi.object({
  email: validationSchemas.email.required(),
  password: validationSchemas.password.required(),
  name: Joi.string().min(2).max(100).required(),
  age: Joi.number().integer().min(18).max(120),
  phone: validationSchemas.phone
});

app.post('/api/users', validateBody(userSchema), (req: Request, res: Response) => {
  // req.body is validated and sanitized
  res.json({
    success: true,
    data: req.body
  });
});

/**
 * Example 2: Query parameter validation
 */
const paginationSchema = Joi.object({
  page: Joi.number().integer().min(1).default(1),
  limit: Joi.number().integer().min(1).max(100).default(10),
  sort: Joi.string().valid('asc', 'desc').default('desc'),
  search: validationSchemas.search
});

app.get('/api/users', validateQuery(paginationSchema), (req: Request, res: Response) => {
  const { page, limit, sort, search } = req.query;
  
  res.json({
    success: true,
    data: {
      page,
      limit,
      sort,
      search,
      users: [] // would fetch from database
    }
  });
});

/**
 * Example 3: Path parameter validation
 */
const userIdSchema = Joi.object({
  id: validationSchemas.mongoId.required()
});

app.get('/api/users/:id', validateParams(userIdSchema), (req: Request, res: Response) => {
  const { id } = req.params;
  
  res.json({
    success: true,
    data: { id }
  });
});

/**
 * Example 4: File upload validation
 */
app.post('/api/upload', 
  validateFileUpload({
    allowedMimeTypes: ['image/jpeg', 'image/png', 'image/gif'],
    maxFileSize: 5 * 1024 * 1024, // 5MB
    required: true,
    fieldName: 'avatar'
  }),
  (req: Request, res: Response) => {
    const files = req.files;
    
    res.json({
      success: true,
      message: 'File uploaded successfully',
      files: files
    });
  }
);

/**
 * Example 5: Comprehensive validation (body + query + params)
 */
const createPostSchema = Joi.object({
  title: Joi.string().min(5).max(200).required(),
  content: Joi.string().min(10).max(5000).required(),
  tags: Joi.array().items(Joi.string().max(50)).max(10),
  published: Joi.boolean().default(false)
});

const postQuerySchema = Joi.object({
  draft: Joi.boolean().default(false),
  category: Joi.string().max(50)
});

const postParamsSchema = Joi.object({
  userId: validationSchemas.mongoId.required()
});

app.post('/api/users/:userId/posts',
  validateParams(postParamsSchema),
  validateQuery(postQuerySchema),
  validateBody(createPostSchema),
  (req: Request, res: Response) => {
    const { userId } = req.params;
    const query = req.query;
    const post = req.body;
    
    res.json({
      success: true,
      data: {
        userId,
        query,
        post
      }
    });
  }
);

/**
 * Example 6: Using Zod schema
 */
const zodUserSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  name: z.string().min(2).max(100),
  preferences: z.object({
    theme: z.enum(['light', 'dark']).default('light'),
    notifications: z.boolean().default(true)
  }).optional()
});

app.post('/api/zod-users', validateBody(zodUserSchema), (req: Request, res: Response) => {
  res.json({
    success: true,
    data: req.body
  });
});

/**
 * Example 7: Custom validation with custom validators
 */
const customSchema = Joi.object({
  username: Joi.string().min(3).max(50).custom((value, helpers) => {
    if (!customValidators.alphanumeric(value)) {
      return helpers.error('string.alphanumeric');
    }
    return value;
  }, 'alphanumeric validation'),
  
  creditCard: Joi.string().creditCard().custom((value, helpers) => {
    if (!customValidators.creditCard(value)) {
      return helpers.error('string.creditCard');
    }
    return value;
  }, 'credit card validation'),
  
  category: Joi.string().valid('general', 'support', 'feedback').required(),
  age: Joi.number().min(18).max(120).required()
});

app.post('/api/custom-validation', validateBody(customSchema), (req: Request, res: Response) => {
  res.json({
    success: true,
    data: req.body
  });
});

/**
 * Example 8: Using comprehensive validation middleware
 */
app.post('/api/comprehensive',
  comprehensiveValidation({
    bodySchema: Joi.object({
      title: Joi.string().min(3).max(100).required(),
      description: Joi.string().max(500),
      price: Joi.number().positive().required(),
      categoryId: validationSchemas.mongoId.required(),
      images: Joi.array().items(Joi.string().uri()).max(5)
    }),
    querySchema: Joi.object({
      validate: Joi.boolean().default(true),
      dryRun: Joi.boolean().default(false)
    }),
    paramsSchema: Joi.object({
      vendorId: validationSchemas.mongoId.required()
    }),
    fileOptions: {
      allowedMimeTypes: ['image/jpeg', 'image/png', 'image/webp'],
      maxFileSize: 10 * 1024 * 1024, // 10MB
      required: false,
      fieldName: 'images'
    },
    rateLimit: true,
    sanitize: true,
    validationOptions: {
      stripUnknown: true,
      abortEarly: false
    }
  }),
  (req: Request, res: Response) => {
    res.json({
      success: true,
      message: 'All inputs validated successfully',
      data: {
        body: req.body,
        query: req.query,
        params: req.params,
        files: req.files
      }
    });
  }
);

/**
 * Example 9: Nested object validation
 */
const nestedSchema = Joi.object({
  user: Joi.object({
    name: Joi.string().required(),
    email: validationSchemas.email.required(),
    address: Joi.object({
      street: Joi.string().required(),
      city: Joi.string().required(),
      country: Joi.string().required(),
      zipCode: Joi.string().pattern(/^\d{5}(-\d{4})?$/).required()
    }).required()
  }).required(),
  preferences: Joi.object({
    newsletter: Joi.boolean().default(false),
    theme: Joi.string().valid('light', 'dark').default('light'),
    language: Joi.string().valid('en', 'es', 'fr').default('en')
  }).default({})
});

app.post('/api/profile', validateBody(nestedSchema), (req: Request, res: Response) => {
  res.json({
    success: true,
    data: req.body
  });
});

/**
 * Example 10: Array validation
 */
const arraySchema = Joi.object({
  tags: Joi.array()
    .items(Joi.string().alphanum().max(20))
    .min(1)
    .max(10)
    .required(),
  skills: Joi.array()
    .items(Joi.object({
      name: Joi.string().required(),
      level: Joi.number().min(1).max(5).required()
    }))
    .min(1)
    .max(20),
  ids: Joi.array().items(validationSchemas.mongoId).max(50)
});

app.post('/api/arrays', validateBody(arraySchema), (req: Request, res: Response) => {
  res.json({
    success: true,
    data: req.body
  });
});

/**
 * Example 11: Date and time validation
 */
const dateSchema = Joi.object({
  birthDate: validationSchemas.date.required(),
  appointmentDate: Joi.date().greater('now').required(),
  endDate: Joi.date().greater(Joi.ref('startDate')).when('startDate', {
    is: Joi.exist(),
    then: Joi.required()
  }),
  startDate: Joi.date().required()
});

app.post('/api/schedule', validateBody(dateSchema), (req: Request, res: Response) => {
  res.json({
    success: true,
    data: req.body
  });
});

/**
 * Example 12: URL and URI validation
 */
const linkSchema = Joi.object({
  website: validationSchemas.url,
  socialMedia: Joi.object({
    twitter: validationSchemas.url,
    linkedin: validationSchemas.url,
    github: validationSchemas.url
  }),
  redirectUrl: Joi.string().uri({ scheme: ['http', 'https'] }).required()
});

app.post('/api/links', validateBody(linkSchema), (req: Request, res: Response) => {
  res.json({
    success: true,
    data: req.body
  });
});

/**
 * Example 13: Error handling middleware
 */
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  if (err instanceof ValidationError) {
    return res.status(err.statusCode).json({
      success: false,
      error: {
        message: err.message,
        code: err.code || 'VALIDATION_ERROR',
        details: err.errors
      }
    });
  }
  
  if (err.name === 'ValidationError' && 'issues' in err) {
    // Zod validation error
    const zodError = err as any;
    return res.status(400).json({
      success: false,
      error: {
        message: 'Validation failed',
        code: 'ZOD_VALIDATION_ERROR',
        details: zodError.issues.map((issue: any) => ({
          field: issue.path.join('.'),
          message: issue.message,
          code: issue.code,
          value: issue.input
        }))
      }
    });
  }
  
  console.error('Unhandled error:', err);
  res.status(500).json({
    success: false,
    error: {
      message: 'Internal server error',
      code: 'INTERNAL_ERROR'
    }
  });
});

/**
 * Example 14: Multiple file uploads
 */
app.post('/api/multiple-uploads',
  validateFileUpload({
    allowedMimeTypes: ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'],
    maxFileSize: 20 * 1024 * 1024, // 20MB
    required: false,
    fieldName: 'documents'
  }),
  (req: Request, res: Response) => {
    const files = req.files;
    
    res.json({
      success: true,
      message: 'Files uploaded successfully',
      fileCount: files?.length || 0,
      files: files
    });
  }
);

/**
 * Example 15: Conditional validation
 */
const conditionalSchema = Joi.object({
  type: Joi.string().valid('personal', 'business').required(),
  personalInfo: Joi.object({
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    ssn: Joi.string().pattern(/^\d{3}-?\d{2}-?\d{4}$/)
  }).when('type', {
    is: 'personal',
    then: Joi.required(),
    otherwise: Joi.optional()
  }),
  businessInfo: Joi.object({
    companyName: Joi.string().required(),
    taxId: Joi.string().pattern(/^\d{2}-?\d{7}$/)
  }).when('type', {
    is: 'business',
    then: Joi.required(),
    otherwise: Joi.optional()
  })
});

app.post('/api/conditional', validateBody(conditionalSchema), (req: Request, res: Response) => {
  res.json({
    success: true,
    data: req.body
  });
});

/**
 * Example 16: API key validation
 */
const apiKeySchema = Joi.object({
  apiKey: Joi.string()
    .pattern(/^[a-zA-Z0-9]{32}$/, 'API key')
    .required()
    .messages({
      'string.pattern.base': 'Invalid API key format'
    })
});

app.get('/api/protected',
  validateQuery(apiKeySchema),
  (req: Request, res: Response) => {
    res.json({
      success: true,
      message: 'Access granted',
      data: 'Protected data'
    });
  }
);

// Export app for testing
export { app };

// Start server if run directly
if (require.main === module) {
  const port = process.env.PORT || 3000;
  app.listen(port, () => {
    console.log(`Validation examples server running on port ${port}`);
  });
}
