# Comprehensive Rate Limiting Middleware

A production-ready, enterprise-grade rate limiting middleware for Express.js applications with sliding window rate limiting, Redis-backed distributed support, and granular endpoint-based controls.

## 🚀 Features

### Core Functionality
- **Sliding Window Rate Limiting**: Accurate rate limiting with time-based windows
- **Multi-layer Rate Limiting**: IP-based and user-based limiting simultaneously
- **Endpoint-specific Limits**: Different rate limits for auth, AWS, API, and admin endpoints
- **Redis-backed Distribution**: Distributed rate limiting for multi-instance deployments
- **Fallback Memory Store**: In-memory storage when Redis is unavailable
- **Rate Limit Headers**: Standard rate limit information in HTTP responses
- **Admin Bypass**: Automatic bypass for admin users and development environments
- **Custom Rate Limit Messages**: Customizable error messages and status codes

### Advanced Features
- **Sliding Window Algorithm**: Uses sliding window for accurate rate limiting
- **Multiple Storage Backends**: Redis for distributed, memory for development
- **Granular Configuration**: Different limits per endpoint type
- **Skip Logic**: Conditional rate limiting based on request attributes
- **Custom Key Generation**: Flexible key generation for rate limit identification
- **Health Monitoring**: Built-in health checks for rate limiter status
- **Performance Optimized**: Minimal overhead with efficient storage operations

## 📦 Dependencies

```bash
npm install express ioredis
```

For development and testing:
```bash
npm install @types/express --save-dev
```

## 🔧 Quick Start

### Basic Setup

```typescript
import express from 'express';
import { rateLimiter } from './middleware/rateLimiter';

const app = express();

// Apply rate limiter to all routes
app.use(rateLimiter());

// Your routes
app.get('/api/users', (req, res) => {
  res.json({ users: [] });
});

app.post('/api/auth/login', (req, res) => {
  // Auth-specific rate limits apply automatically
  res.json({ token: 'token' });
});

app.listen(3000);
```

### With Redis (Recommended for Production)

```typescript
import express from 'express';
import Redis from 'ioredis';
import { rateLimiter } from './middleware/rateLimiter';

// Initialize Redis connection
const redis = new Redis({
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379'),
  password: process.env.REDIS_PASSWORD,
  retryDelayOnFailover: 100,
  enableReadyCheck: true,
  maxRetriesPerRequest: 3,
});

const app = express();

// Use Redis-backed rate limiter
app.use(rateLimiter(undefined, redis));

app.get('/api/data', (req, res) => {
  res.json({ data: 'content' });
});

app.listen(3000);
```

### Advanced Configuration

```typescript
import express from 'express';
import { rateLimiter } from './middleware/rateLimiter';

const app = express();

// Custom rate limit configuration
app.use(rateLimiter({
  default: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    maxRequests: 100,
    message: 'Too many requests from this IP',
    headers: true,
  },
  auth: {
    windowMs: 15 * 60 * 1000,
    maxRequests: 5, // Strict limit for login attempts
    message: 'Too many login attempts. Please try again later.',
  },
  aws: {
    windowMs: 60 * 1000, // 1 minute
    maxRequests: 10,
    message: 'AWS operation rate limit exceeded',
  },
  api: {
    windowMs: 15 * 60 * 1000,
    maxRequests: 1000, // Generous limit for API
    message: 'API rate limit exceeded',
  }
}));

app.listen(3000);
```

## 📖 Usage Guide

### Endpoint-specific Rate Limiting

The middleware automatically applies different rate limits based on endpoint paths:

```typescript
// Auth endpoints (strict limits)
app.post('/api/auth/login', (req, res) => {
  // Limited to 5 requests per 15 minutes
});

app.post('/api/auth/register', (req, res) => {
  // Limited to 5 requests per 15 minutes
});

// AWS endpoints (moderate limits)
app.post('/api/aws/s3/upload', (req, res) => {
  // Limited to 10 requests per minute
});

app.get('/api/aws/secrets', (req, res) => {
  // Limited to 10 requests per minute
});

// API endpoints (generous limits)
app.get('/api/users', (req, res) => {
  // Limited to 1000 requests per 15 minutes
});

app.get('/api/data', (req, res) => {
  // Limited to 1000 requests per 15 minutes
});

// Admin endpoints (custom limits)
app.get('/admin/users', (req, res) => {
  // Admin bypass applies automatically if user is admin
});

// Default endpoints
app.get('/health', (req, res) => {
  // Limited to 100 requests per 15 minutes
});
```

### Admin User Bypass

Admin users are automatically bypassed from rate limiting:

```typescript
// User object with admin role
app.use(async (req, res, next) => {
  // Mock authentication
  const token = req.headers.authorization?.split(' ')[1];
  if (token === 'admin-token') {
    req.user = { id: 'admin123', role: 'admin' };
  } else if (token) {
    req.user = { id: 'user123', role: 'user' };
  }
  next();
});

app.use(rateLimiter());

// Admin routes (bypassed for admin users)
app.get('/api/admin/stats', (req, res) => {
  // No rate limiting for admin users
  res.json({ stats: 'data' });
});

// User routes (rate limited for everyone)
app.get('/api/data', (req, res) => {
  // Rate limited for all users including admins
  res.json({ data: 'content' });
});
```

### Custom Rate Limit Configuration

```typescript
// Create custom rate limiter for specific use cases
const customLimiter = rateLimiter({
  default: {
    windowMs: 5 * 60 * 1000, // 5 minutes
    maxRequests: 50,
    skip: (req) => {
      // Skip rate limiting for internal requests
      return req.headers['x-internal'] === 'true';
    },
    keyGenerator: (req) => {
      // Custom key based on API version
      return `v1:${req.path}`;
    }
  }
});

// Apply to specific route
app.use('/api/v1', customLimiter);

// Multiple configurations
const strictLimiter = rateLimiter({
  default: {
    windowMs: 60 * 1000, // 1 minute
    maxRequests: 10,
    skipSuccessfulRequests: true, // Don't count successful requests
    message: 'Rate limit exceeded. Please slow down.'
  }
});

const lenientLimiter = rateLimiter({
  default: {
    windowMs: 60 * 1000,
    maxRequests: 1000,
    skipFailedRequests: true // Don't count failed requests
  }
});

app.use('/api/internal', strictLimiter);
app.use('/api/public', lenientLimiter);
```

### Manual Rate Limit Checks

```typescript
import { checkRateLimit, RedisRateLimitStore } from './middleware/rateLimiter';

const redis = new Redis();
const store = new RedisRateLimitStore(redis);

// Check rate limit manually
app.post('/api/operation', async (req, res) => {
  const identifier = `user:${req.user.id}:operation:special`;
  const result = await checkRateLimit(
    identifier,
    10, // max requests
    60000, // 1 minute window
    store
  );

  if (!result.allowed) {
    return res.status(429).json({
      error: 'Rate limit exceeded',
      remaining: result.remaining,
      reset: result.reset
    });
  }

  // Continue with operation
  res.json({ success: true });
});
```

### Rate Limit Information

```typescript
// Get current rate limit info
app.get('/api/rate-limit-info', async (req, res) => {
  const identifier = `ip:${req.ip}`;
  const info = await getRateLimitInfo(identifier, store);
  
  res.json(info);
});

// Clear rate limit (admin only)
app.delete('/api/admin/rate-limit/:identifier', async (req, res) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ error: 'Forbidden' });
  }

  await clearRateLimit(req.params.identifier, store);
  res.json({ success: true });
});
```

## 🔍 Rate Limit Headers

All responses include rate limit information when enabled:

```typescript
// Request
GET /api/users
Authorization: Bearer user-token

// Response Headers
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1640995200
Retry-After: 60

// Response Body
{
  "users": [...]
}
```

### Rate Limit Exceeded Response

```typescript
// When rate limit is exceeded
{
  "error": "Rate Limit Exceeded",
  "message": "Too many authentication attempts. Please try again in 15 minutes.",
  "retryAfter": 900,
  "limit": 5,
  "remaining": 0
}
```

## 🏗️ Architecture

### Sliding Window Algorithm

The rate limiter uses a sliding window algorithm for accurate rate limiting:

```
Window: 15 minutes (900000ms)
Max Requests: 100

Request 1: [00:00] ✓ Window starts
Request 2: [05:00] ✓ Within window
Request 3: [10:00] ✓ Within window
...
Request 101: [14:59] ✗ Exceeds limit

New window starts at request 101 time
```

### Multi-layer Rate Limiting

Rate limits are applied in layers:

```typescript
// Layer 1: IP-based
key: "ip:192.168.1.1:endpoint:auth"

// Layer 2: User-based (if authenticated)
key: "user:123:ip:192.168.1.1:endpoint:auth"

// Layer 3: Custom
key: "user:123:ip:192.168.1.1:endpoint:auth:custom:api-v1"
```

### Storage Backends

#### Redis Store (Production)

```typescript
class RedisRateLimitStore {
  // Uses Redis pipeline for atomic operations
  // Supports distributed deployments
  // Automatic cleanup with TTL
}
```

#### Memory Store (Development)

```typescript
class MemoryRateLimitStore {
  // In-memory storage
  // Automatic cleanup
  // No external dependencies
}
```

## 📊 Configuration Reference

### RateLimitConfig Interface

```typescript
interface RateLimitConfig {
  windowMs: number;              // Time window in milliseconds
  maxRequests: number;           // Maximum requests allowed
  skipSuccessfulRequests?: boolean; // Skip counting successful requests
  skipFailedRequests?: boolean;     // Skip counting failed requests
  keyGenerator?: (req: Request) => string; // Custom key generator
  skip?: (req: Request) => boolean; // Skip rate limiting
  message?: string | ((req: Request, res: Response) => string);
  statusCode?: number;           // HTTP status code (default: 429)
  headers?: boolean;             // Include rate limit headers
  skipUserBased?: boolean;       // Skip user-based limiting
  skipIPBased?: boolean;         // Skip IP-based limiting
}
```

### RateLimitOptions Interface

```typescript
interface RateLimitOptions {
  auth?: RateLimitConfig;    // Authentication endpoints
  aws?: RateLimitConfig;     // AWS operation endpoints
  api?: RateLimitConfig;     // General API endpoints
  admin?: RateLimitConfig;   // Admin endpoints
  default: RateLimitConfig;  // Default for all endpoints
}
```

### Default Configuration

```typescript
const defaultRateLimits = {
  default: {
    windowMs: 15 * 60 * 1000,  // 15 minutes
    maxRequests: 100,
    headers: true,
    statusCode: 429,
    message: 'Too many requests, please try again later.',
  },
  auth: {
    windowMs: 15 * 60 * 1000,
    maxRequests: 5,  // Strict for security
    headers: true,
    statusCode: 429,
    message: 'Too many authentication attempts, please try again later.',
  },
  aws: {
    windowMs: 60 * 1000,  // 1 minute
    maxRequests: 10,  // Moderate for AWS operations
    headers: true,
    statusCode: 429,
    message: 'AWS operation rate limit exceeded, please slow down.',
  },
  api: {
    windowMs: 15 * 60 * 1000,
    maxRequests: 1000,  // Generous for API
    headers: true,
    statusCode: 429,
    message: 'API rate limit exceeded.',
  },
  admin: {
    windowMs: 5 * 60 * 1000,  // 5 minutes
    maxRequests: 500,
    headers: true,
    statusCode: 429,
    message: 'Admin endpoint rate limit exceeded.',
  },
};
```

## 🧪 Testing

### Unit Testing

```typescript
import request from 'supertest';
import express from 'express';
import { rateLimiter } from '../middleware/rateLimiter';

describe('Rate Limiter', () => {
  let app: express.Application;
  
  beforeEach(() => {
    app = express();
    app.use(rateLimiter());
    app.get('/test', (req, res) => res.json({ ok: true }));
  });
  
  it('should allow requests under limit', async () => {
    for (let i = 0; i < 5; i++) {
      const response = await request(app)
        .get('/test')
        .expect(200);
      
      expect(response.headers['x-ratelimit-remaining']).toBeDefined();
    }
  });
  
  it('should block requests over limit', async () => {
    // Make requests up to limit
    for (let i = 0; i < 100; i++) {
      await request(app).get('/test').expect(200);
    }
    
    // Next request should be blocked
    const response = await request(app)
      .get('/test')
      .expect(429);
    
    expect(response.body.error).toBe('Rate Limit Exceeded');
  });
  
  it('should apply different limits to auth endpoints', async () => {
    // Auth endpoints have stricter limits
    for (let i = 0; i < 5; i++) {
      await request(app).post('/api/auth/login').expect(200);
    }
    
    const response = await request(app)
      .post('/api/auth/login')
      .expect(429);
    
    expect(response.body.message).toContain('authentication');
  });
});
```

### Integration Testing with Redis

```typescript
import Redis from 'ioredis';
import { rateLimiter } from '../middleware/rateLimiter';

describe('Rate Limiter with Redis', () => {
  let redis: Redis;
  let app: express.Application;
  
  beforeAll(async () => {
    redis = new Redis({
      host: 'localhost',
      port: 6379,
    });
    
    app = express();
    app.use(rateLimiter(undefined, redis));
    app.get('/test', (req, res) => res.json({ ok: true }));
  });
  
  afterAll(async () => {
    await redis.flushall();
    await redis.quit();
  });
  
  it('should work with Redis backend', async () => {
    const response = await request(app)
      .get('/test')
      .expect(200);
    
    expect(response.headers['x-ratelimit-remaining']).toBe('99');
  });
});
```

## 🔧 Environment-specific Configuration

### Development

```typescript
// config/development.ts
export const rateLimitConfig = {
  default: {
    windowMs: 15 * 60 * 1000,
    maxRequests: 1000,  // Higher limits for development
    skip: (req) => {
      // Skip for localhost
      return req.ip === '127.0.0.1' || req.ip === '::1';
    }
  },
  // Use memory store in development
};
```

### Production

```typescript
// config/production.ts
export const rateLimitConfig = {
  default: {
    windowMs: 15 * 60 * 1000,
    maxRequests: 100,  // Stricter limits in production
    headers: true,
  },
  auth: {
    windowMs: 15 * 60 * 1000,
    maxRequests: 5,  // Very strict for auth
  },
  // Always use Redis in production
};
```

## 🐛 Troubleshooting

### Common Issues

1. **Redis Connection Issues**
   ```typescript
   // The middleware falls back to memory store if Redis fails
   // Check Redis connection with health check
   const healthCheck = createRateLimitHealthCheck(store);
   const status = await healthCheck();
   console.log(status); // { healthy: true, store: 'redis' }
   ```

2. **High Memory Usage**
   ```typescript
   // Use Redis for production to avoid memory buildup
   const redis = new Redis(process.env.REDIS_URL);
   app.use(rateLimiter(config, redis));
   ```

3. **Rate Limits Too Strict**
   ```typescript
   // Adjust limits for your use case
   app.use(rateLimiter({
     default: {
       windowMs: 15 * 60 * 1000,
       maxRequests: 1000,  // Increase limit
     }
   }));
   ```

4. **Admin Bypass Not Working**
   ```typescript
   // Ensure user object has correct role
   app.use((req, res, next) => {
     if (req.user?.role === 'admin') {
       req.user.isAdmin = true;  // Alternative check
     }
     next();
   });
   ```

### Debug Mode

```typescript
// Enable debug logging
process.env.RATE_LIMITER_DEBUG = 'true';

// Custom logging
const logger = {
  info: (msg) => console.log(`[RateLimiter] ${msg}`),
  error: (msg) => console.error(`[RateLimiter] ${msg}`),
};

// The middleware will log rate limit decisions
```

### Health Monitoring

```typescript
import { createRateLimitHealthCheck } from './middleware/rateLimiter';

const healthCheck = createRateLimitHealthCheck(store);

// Check health in your monitoring system
setInterval(async () => {
  const status = await healthCheck();
  if (!status.healthy) {
    console.error('Rate limiter unhealthy:', status);
    // Alert monitoring system
  }
}, 60000);
```

## 📋 Best Practices

### 1. Choose Appropriate Limits

```typescript
// Authentication: Very strict
const authLimits = {
  maxRequests: 5,
  windowMs: 15 * 60 * 1000,  // 15 minutes
};

// Data operations: Moderate
const dataLimits = {
  maxRequests: 100,
  windowMs: 60 * 1000,  // 1 minute
};

// Read operations: Generous
const readLimits = {
  maxRequests: 1000,
  windowMs: 15 * 60 * 1000,  // 15 minutes
};
```

### 2. Use Redis in Production

```typescript
// Production setup
const redis = new Redis(process.env.REDIS_URL, {
  retryDelayOnFailover: 100,
  enableReadyCheck: true,
  maxRetriesPerRequest: 3,
});

app.use(rateLimiter(config, redis));
```

### 3. Monitor Rate Limit Hits

```typescript
app.use((req, res, next) => {
  const originalSend = res.send;
  res.send = function(data) {
    if (res.statusCode === 429) {
      console.log('Rate limit exceeded:', {
        ip: req.ip,
        path: req.path,
        user: req.user?.id,
      });
    }
    return originalSend.call(this, data);
  };
  next();
});
```

### 4. Test Under Load

```typescript
import { checkRateLimit } from './middleware/rateLimiter';

// Test your rate limits
const testLoad = async () => {
  for (let i = 0; i < 200; i++) {
    const result = await checkRateLimit('test-key', 100, 60000, store);
    if (!result.allowed) {
      console.log(`Rate limited after ${i} requests`);
      break;
    }
  }
};
```

## 🔍 API Reference

### Middleware Factory

```typescript
function rateLimiter(options?: Partial<RateLimitOptions>, redisClient?: Redis): RequestHandler
```

### Specific Middleware

```typescript
export const authRateLimiter = rateLimiter({
  auth: { /* config */ }
});

export const awsRateLimiter = rateLimiter({
  aws: { /* config */ }
});

export const apiRateLimiter = rateLimiter({
  api: { /* config */ }
});
```

### Utility Functions

```typescript
// Check rate limit manually
async function checkRateLimit(
  key: string,
  limit: number,
  windowMs: number,
  store: RateLimitStore
): Promise<{ allowed: boolean; remaining: number; reset: number }>

// Get rate limit info
async function getRateLimitInfo(
  identifier: string,
  store: RateLimitStore,
  windowMs?: number
): Promise<{ count: number; resetTime: number; remaining: number } | null>

// Clear rate limit
async function clearRateLimit(identifier: string, store: RateLimitStore): Promise<void>

// Health check
function createRateLimitHealthCheck(store: RateLimitStore): () => Promise<{ healthy: boolean; store: string }>
```

## 📚 Additional Resources

- [Rate Limiting Strategies](https://cloud.google.com/architecture/rate-limiting-strategies-techniques)
- [Stripe Rate Limiting](https://stripe.com/blog/rate-limiters)
- [Resilience in Distributed Systems](https://martinfowler.com/bliki/Resilience.html)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Ensure all tests pass
5. Submit a pull request

## 📄 License

MIT License - see LICENSE file for details.
