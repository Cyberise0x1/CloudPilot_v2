# Comprehensive Audit Logging Middleware

A production-ready, enterprise-grade audit logging middleware for Express.js applications that provides comprehensive audit trail management, security monitoring, and performance optimization.

## 🚀 Features

### Core Functionality
- **Automatic Audit Logging**: Captures all API requests with detailed metadata
- **User Action Tracking**: Tracks user activities with correlation across requests
- **AWS Operation Logging**: Detailed logging for AWS service operations
- **Authentication Events**: Comprehensive authentication attempt logging
- **Security Event Monitoring**: Real-time security threat detection and alerting
- **Data Sanitization**: Automatic PII protection and sensitive data filtering
- **Performance Optimization**: Async logging with buffering to minimize impact
- **Database Storage**: Structured audit data with advanced querying capabilities

### Advanced Features
- **Suspicious Activity Detection**: Pattern-based detection of malicious requests
- **Request/Response Body Capture**: Optional body logging with size limits
- **Correlation ID Tracking**: End-to-end request correlation
- **Performance Monitoring**: Slow request detection and alerting
- **Configurable Filtering**: Granular control over what gets audited
- **Batch Processing**: Efficient database operations with batching
- **Log Rotation**: Built-in log management and retention policies

## 📦 Installation

```bash
npm install winston uuid
```

## 🔧 Quick Start

### Basic Setup

```typescript
import express from 'express';
import { auditMiddleware } from './middleware/audit';

const app = express();

// Basic audit middleware
app.use(auditMiddleware());

// Your routes
app.get('/api/users', (req, res) => {
  res.json({ users: [] });
});

app.listen(3000);
```

### Advanced Configuration

```typescript
import express from 'express';
import { auditMiddleware } from './middleware/audit';

const app = express();

// Advanced audit middleware with custom configuration
app.use(auditMiddleware({
  // Performance settings
  asyncLogging: true,
  bufferSize: 100,
  flushInterval: 5000,
  
  // Content capture
  captureBodies: true,
  captureHeaders: true,
  sanitizeBodies: true,
  maxBodySize: 10240,
  
  // Filtering
  excludePaths: ['/health', '/metrics', '/favicon.ico'],
  includePaths: ['/api/*'],
  includeBodiesForPaths: ['/api/auth/login', '/api/users/*'],
  
  // Security features
  logAuthenticationAttempts: true,
  logSecurityEvents: true,
  logSuspiciousRequests: true,
  detectSuspiciousActivity: true,
  
  // Performance monitoring
  slowRequestThreshold: 2000,
  logSlowRequests: true,
  
  // Custom functions
  shouldAuditRequest: (req) => !req.path.includes('/internal'),
  sanitizeRequestData: (data) => removeCustomSensitiveFields(data),
  categorizeRequest: (req) => categorizeByBusinessLogic(req)
}));

app.listen(3000);
```

## 📖 Usage Guide

### Manual Audit Logging

```typescript
// In your route handlers
app.post('/api/users', async (req, res) => {
  try {
    // Create user logic
    const user = await createUser(req.body);
    
    // Manual audit log
    await req.auditLog('user.created', 'user_management', {
      status: 'success',
      severity: 'low',
      details: {
        userId: user.id,
        userEmail: user.email,
        creationMethod: 'api'
      }
    });
    
    res.json(user);
  } catch (error) {
    // Log failure
    await req.auditLog('user.creation_failed', 'user_management', {
      status: 'failure',
      severity: 'high',
      details: {
        error: error.message,
        requestData: req.body
      }
    });
    
    res.status(500).json({ error: 'Failed to create user' });
  }
});
```

### Security Event Logging

```typescript
app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  
  try {
    const user = await authenticateUser(email, password);
    
    if (user) {
      await req.auditLog('auth.success', 'authentication', {
        status: 'success',
        severity: 'medium',
        details: {
          authenticationMethod: 'password',
          userAgent: req.headers['user-agent']
        }
      });
      
      res.json({ token: generateToken(user) });
    } else {
      await req.logSecurityEvent('auth.failure', 'medium', {
        reason: 'invalid_credentials',
        email,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent']
      });
      
      res.status(401).json({ error: 'Invalid credentials' });
    }
  } catch (error) {
    await req.logSecurityEvent('auth.error', 'high', {
      reason: 'authentication_error',
      error: error.message
    });
    
    res.status(500).json({ error: 'Authentication failed' });
  }
});
```

### AWS Operations Audit

```typescript
import { createAWSAuditWrapper } from './middleware/audit';

// Wrap AWS operations with audit logging
const s3Audit = createAWSAuditWrapper('s3', 'upload');

app.post('/api/files/upload', upload.single('file'), async (req, res) => {
  const file = req.file;
  
  try {
    // Before operation
    await s3Audit.before(`bucket/${req.body.bucket}`, {
      fileName: file.originalname,
      fileSize: file.size,
      contentType: file.mimetype
    }, req);
    
    // AWS operation
    const result = await s3Client.upload({
      Bucket: req.body.bucket,
      Key: file.originalname,
      Body: file.buffer
    }).promise();
    
    // After success
    await s3Audit.after(`bucket/${req.body.bucket}`, {
      etag: result.ETag,
      location: result.Location
    }, {}, req);
    
    res.json({ success: true, location: result.Location });
  } catch (error) {
    // On error
    await s3Audit.error(`bucket/${req.body.bucket}`, error, {
      fileName: file.originalname
    }, req);
    
    res.status(500).json({ error: 'Upload failed' });
  }
});
```

### User Context Middleware Integration

```typescript
import { auditMiddleware } from './middleware/audit';
import { authenticateUser } from './auth';

// Add user context before audit middleware
app.use(authenticateUser);

app.use(auditMiddleware({
  includeUserContext: true,
  requiredUserFields: ['id', 'email', 'role', 'permissions']
}));

// Now all audit logs will include user context
app.get('/api/profile', (req, res) => {
  // req.user is automatically included in audit logs
  res.json(req.user);
});
```

## 🔒 Security Features

### Suspicious Activity Detection

The middleware automatically detects and logs suspicious activities:

```typescript
// Automatically detected patterns:
const SUSPICIOUS_PATTERNS = {
  path: [
    /admin/i, /wp-admin/i, /\.env/i, /\.git/i,
    /config/i, /\.\./, /script/i, /javascript/i,
    /union.*select/i, /drop.*table/i
  ],
  userAgent: [
    /bot/i, /crawler/i, /spider/i, /scanner/i,
    /sqlmap/i, /nikto/i, /nmap/i, /masscan/i
  ],
  payload: [
    /<script/i, /javascript:/i, /onload/i,
    /eval\(/i, /function\(/i, /data:/i
  ]
};
```

### Security Event Types

```typescript
import { SECURITY_EVENTS } from './middleware/audit';

// Use standardized security event types
await req.logSecurityEvent(SECURITY_EVENTS.AUTH_LOCKOUT, 'high', {
  userId: 'user123',
  reason: 'Multiple failed attempts',
  lockoutDuration: 1800
});

await req.logSecurityEvent(SECURITY_EVENTS.BRUTE_FORCE, 'critical', {
  ipAddress: req.ip,
  attemptsCount: 10,
  timeWindow: 300
});
```

## 📊 Data Sanitization

### Automatic PII Protection

The middleware automatically sanitizes sensitive data:

```typescript
const SENSITIVE_PATTERNS = {
  fields: [
    /password/i, /token/i, /key/i, /ssn/i,
    /credit.*card/i, /authorization/i, /bearer/i,
    /refresh.*token/i, /private.*key/i
  ],
  valuePatterns: [
    /eyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*\.[A-Za-z0-9_-]*/, // JWT
    /sk_[a-zA-Z0-9]{48}/, // Stripe keys
    /AKIA[0-9A-Z]{16}/, // AWS keys
    /[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}[\s-]?[0-9]{4}/ // Credit cards
  ]
};
```

### Custom Sanitization

```typescript
app.use(auditMiddleware({
  sanitizeRequestData: (data) => {
    // Remove custom sensitive fields
    delete data.internalNotes;
    delete data.debugInfo;
    
    // Hash or mask specific fields
    if (data.employeeId) {
      data.employeeId = hashValue(data.employeeId);
    }
    
    return data;
  }
}));
```

## ⚡ Performance Optimization

### Async Logging with Buffering

```typescript
const config = {
  asyncLogging: true,
  bufferSize: 100,        // Flush after 100 entries
  flushInterval: 5000,    // Or every 5 seconds
  
  // Reduces database load by batching writes
  // Automatically flushes on server shutdown
};
```

### Request Filtering

```typescript
// Skip expensive operations for certain paths
const config = {
  excludePaths: [
    '/health', '/metrics', '/status',
    '/static/*', '/assets/*'
  ],
  
  shouldAuditRequest: (req) => {
    // Skip internal API calls
    if (req.headers['x-internal']) {
      return false;
    }
    
    // Only audit authenticated requests
    return !!req.user;
  }
};
```

## 📈 Monitoring and Analytics

### Query Audit Logs

```typescript
import { auditService } from './services/audit-service';

// Get recent security events
const securityEvents = await auditService.queryAuditLogs({
  category: 'security',
  severity: ['high', 'critical'],
  startDate: new Date(Date.now() - 24 * 60 * 60 * 1000),
  limit: 50
});

// Get user activity
const userActivity = await auditService.queryAuditLogs({
  userId: 'user123',
  startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
  sortBy: 'createdAt',
  sortOrder: 'desc'
});
```

### Export Audit Data

```typescript
// Export to CSV for compliance
const csvExport = await auditService.exportAuditLogs({
  startDate: new Date('2024-01-01'),
  endDate: new Date('2024-01-31'),
  category: 'security',
  format: 'csv'
});

// Download the file
res.setHeader('Content-Type', csvExport.mimeType);
res.setHeader('Content-Disposition', `attachment; filename="${csvExport.filename}"`);
res.send(csvExport.data);
```

### Analytics and Trends

```typescript
// Get security trends
const trends = await auditService.getAuditTrends({
  period: '7d',
  category: 'security'
});

console.log(`Critical events: ${trends.severityBreakdown.find(s => s.severity === 'critical')?.count}`);

// Get suspicious activity
const analytics = await auditService.getAuditAnalytics({
  category: 'security'
});

console.log('Top suspicious users:', analytics.suspiciousActivity);
```

## 🔧 Configuration Reference

### Complete Configuration Options

```typescript
interface AuditMiddlewareConfig {
  // Core settings
  enabled?: boolean;
  auditLevel?: 'basic' | 'detailed' | 'comprehensive';
  asyncLogging?: boolean;
  bufferSize?: number;
  flushInterval?: number;
  
  // Content capture
  captureBodies?: boolean;
  captureHeaders?: boolean;
  sanitizeBodies?: boolean;
  maxBodySize?: number;
  
  // Filtering
  excludePaths?: string[];
  includePaths?: string[];
  includeBodiesForPaths?: string[];
  excludeBodiesForPaths?: string[];
  
  // Security features
  logAuthenticationAttempts?: boolean;
  logSecurityEvents?: boolean;
  logSuspiciousRequests?: boolean;
  detectSuspiciousActivity?: boolean;
  
  // AWS operations
  trackAWSOperations?: boolean;
  awsOperationPrefix?: string;
  
  // Performance monitoring
  slowRequestThreshold?: number;
  logSlowRequests?: boolean;
  
  // User context
  includeUserContext?: boolean;
  requiredUserFields?: string[];
  
  // Custom functions
  shouldAuditRequest?: (req: Request) => boolean;
  sanitizeRequestData?: (data: any) => any;
  categorizeRequest?: (req: Request) => string;
}
```

### Environment-Specific Configuration

```typescript
// development.ts
export const auditConfig = {
  auditLevel: 'comprehensive',
  captureBodies: true,
  captureHeaders: true,
  logSuspiciousRequests: true,
  slowRequestThreshold: 500 // Lower threshold in dev
};

// production.ts
export const auditConfig = {
  auditLevel: 'detailed',
  captureBodies: false,
  captureHeaders: false,
  asyncLogging: true,
  bufferSize: 200,
  logSuspiciousRequests: true,
  slowRequestThreshold: 2000
};
```

## 🧪 Testing

### Unit Testing

```typescript
import { auditMiddleware } from '../middleware/audit';
import request from 'supertest';
import express from 'express';

describe('Audit Middleware', () => {
  let app: express.Application;
  
  beforeEach(() => {
    app = express();
    app.use(express.json());
    app.use(auditMiddleware({
      excludePaths: ['/health']
    }));
    
    app.get('/test', (req, res) => res.json({ ok: true }));
    app.post('/test', (req, res) => res.json({ ok: true }));
  });
  
  it('should log requests', async () => {
    const response = await request(app)
      .get('/test')
      .expect(200);
    
    // Verify audit log was created
    expect(response.status).toBe(200);
  });
  
  it('should exclude health endpoint', async () => {
    const response = await request(app)
      .get('/health')
      .expect(404);
    
    // Should not log health endpoint
    expect(response.status).toBe(404);
  });
});
```

### Integration Testing

```typescript
import { auditService } from '../services/audit-service';

describe('Audit Integration', () => {
  it('should store audit logs in database', async () => {
    const logs = await auditService.queryAuditLogs({
      limit: 1,
      sortBy: 'createdAt',
      sortOrder: 'desc'
    });
    
    expect(logs.length).toBeGreaterThan(0);
    expect(logs[0]).toHaveProperty('id');
    expect(logs[0]).toHaveProperty('action');
    expect(logs[0]).toHaveProperty('resource');
  });
});
```

## 🔍 Troubleshooting

### Common Issues

1. **High Database Load**
   ```typescript
   // Increase buffer size and use async logging
   const config = {
     asyncLogging: true,
     bufferSize: 200,
     flushInterval: 10000
   };
   ```

2. **Large Request Bodies**
   ```typescript
   // Limit body capture
   const config = {
     captureBodies: true,
     maxBodySize: 5120, // 5KB
     excludeBodiesForPaths: ['/api/upload/*']
   };
   ```

3. **Performance Issues**
   ```typescript
   // Disable unnecessary features
   const config = {
     captureHeaders: false,
     logSuspiciousRequests: false,
     excludePaths: ['/health', '/metrics']
   };
   ```

### Debug Mode

```typescript
// Enable detailed logging
process.env.LOG_LEVEL = 'debug';
process.env.AUDIT_DEBUG = 'true';

// Custom debug logging
app.use(auditMiddleware({
  // This will log all configuration decisions
  debug: true
}));
```

## 📋 Best Practices

### 1. Selective Auditing

```typescript
// Don't audit everything
const config = {
  excludePaths: [
    '/health', '/metrics', '/favicon.ico',
    '/static/*', '/assets/*', '/css/*', '/js/*'
  ],
  
  includePaths: [
    '/api/*', '/auth/*', '/admin/*'
  ],
  
  shouldAuditRequest: (req) => {
    // Only audit authenticated requests
    return !!req.user && req.user.role !== 'system';
  }
};
```

### 2. Data Minimization

```typescript
// Only capture what's necessary
const config = {
  captureBodies: true,
  includeBodiesForPaths: [
    '/api/auth/login', // Authentication data
    '/api/users'       // User management
  ],
  
  sanitizeRequestData: (data) => {
    // Remove unnecessary data
    const { debug, internal, temp, ...cleanData } = data;
    return cleanData;
  }
};
```

### 3. Performance Monitoring

```typescript
// Monitor performance impact
const config = {
  slowRequestThreshold: 2000,
  logSlowRequests: true,
  
  // Use async logging in production
  asyncLogging: process.env.NODE_ENV === 'production',
  bufferSize: process.env.NODE_ENV === 'production' ? 100 : 10
};
```

### 4. Security Monitoring

```typescript
// Enhanced security logging
const config = {
  logSecurityEvents: true,
  logSuspiciousRequests: true,
  detectSuspiciousActivity: true,
  
  // Set up alerting for critical events
  customSecurityHandler: async (event) => {
    if (event.severity === 'critical') {
      await sendAlert(event);
      await notifySecurityTeam(event);
    }
  }
};
```

## 📚 API Reference

### Middleware Factory

```typescript
function auditMiddleware(config?: AuditMiddlewareConfig): RequestHandler
```

### Request Extensions

```typescript
interface Request {
  auditLog(action: string, resource: string, options?: Partial<CreateAuditLogOptions>): Promise<void>;
  logSecurityEvent(event: string, severity: 'low' | 'medium' | 'high' | 'critical', details?: Record<string, any>): Promise<void>;
  auditContext?: AuditContext;
}
```

### AWS Audit Wrapper

```typescript
function createAWSAuditWrapper(service: string, operation: string): {
  before(resource: string, metadata?: any, req?: Request): Promise<void>;
  after(resource: string, result: any, metadata?: any, req?: Request): Promise<void>;
  error(resource: string, error: Error, metadata?: any, req?: Request): Promise<void>;
}
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Ensure all tests pass
5. Submit a pull request

## 📄 License

MIT License - see LICENSE file for details.
