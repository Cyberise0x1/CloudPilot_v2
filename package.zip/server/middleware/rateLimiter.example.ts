import express, { Request, Response, NextFunction } from 'express';
import Redis from 'ioredis';
import { 
  rateLimiter, 
  authRateLimiter, 
  awsRateLimiter, 
  apiRateLimiter,
  checkRateLimit,
  getRateLimitInfo,
  clearRateLimit,
  RateLimitConfig
} from './rateLimiter';

// Example Express application with rate limiting integration
class RateLimiterExample {
  private app: express.Application;
  private redis?: Redis;
  private store?: any;

  constructor() {
    this.app = express();
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    // Parse JSON bodies
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));

    // Initialize Redis (optional, falls back to memory store)
    this.initializeRedis();

    // Add user context (mock authentication)
    this.app.use(this.addUserContext.bind(this));

    // Apply rate limiting
    this.setupRateLimiting();
  }

  private initializeRedis(): void {
    try {
      const redisUrl = process.env.REDIS_URL || 'redis://localhost:6379';
      this.redis = new Redis(redisUrl, {
        retryDelayOnFailover: 100,
        enableReadyCheck: true,
        maxRetriesPerRequest: 3,
      });

      this.redis.on('connect', () => {
        console.log('✓ Redis connected for rate limiting');
      });

      this.redis.on('error', (err) => {
        console.warn('⚠ Redis connection failed, falling back to memory store:', err.message);
        this.redis = undefined;
      });

      // Test connection
      this.redis.ping().then((pong) => {
        console.log('✓ Redis ping successful:', pong);
      }).catch((err) => {
        console.warn('⚠ Redis ping failed:', err.message);
        this.redis = undefined;
      });
    } catch (error) {
      console.warn('⚠ Failed to initialize Redis, using memory store');
    }
  }

  private addUserContext(req: Request, res: Response, next: NextFunction): void {
    // Mock authentication - extract user from JWT token
    const authHeader = req.headers.authorization;
    
    if (authHeader?.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      
      // Mock token parsing
      if (token === 'admin-token') {
        req.user = { 
          id: 'admin-001', 
          role: 'admin',
          email: 'admin@example.com',
          isAdmin: true 
        };
      } else if (token.startsWith('user-')) {
        req.user = { 
          id: token.replace('user-', ''), 
          role: 'user',
          email: 'user@example.com'
        };
      } else if (token === 'internal-token') {
        // Mark as internal request (may skip rate limiting)
        (req as any).isInternal = true;
      }
    }
    
    next();
  }

  private setupRateLimiting(): void {
    // Global rate limiter with custom configuration
    this.app.use(rateLimiter({
      default: {
        windowMs: 15 * 60 * 1000, // 15 minutes
        maxRequests: 100,
        headers: true,
        message: (req, res) => {
          return `Too many requests from ${req.ip}. Please try again in 15 minutes.`;
        },
        skip: (req) => {
          // Skip rate limiting for internal requests
          return (req as any).isInternal === true;
        }
      },
      auth: {
        windowMs: 15 * 60 * 1000,
        maxRequests: 5,
        message: 'Too many authentication attempts. Account temporarily locked.',
        skip: (req) => {
          // Don't rate limit if user is authenticated
          return !!req.user;
        }
      },
      aws: {
        windowMs: 60 * 1000, // 1 minute
        maxRequests: 10,
        message: 'AWS operation rate limit exceeded. Please slow down.',
        keyGenerator: (req) => {
          // Custom key based on AWS service
          const service = req.path.split('/')[2]; // /api/aws/{service}/...
          return service;
        }
      },
      api: {
        windowMs: 15 * 60 * 1000,
        maxRequests: 1000,
        message: 'API rate limit exceeded. Please try again later.',
        skipSuccessfulRequests: true, // Don't count successful requests
      },
      admin: {
        windowMs: 5 * 60 * 1000,
        maxRequests: 500,
        message: 'Admin endpoint rate limit exceeded.',
      }
    }, this.redis));

    // Alternative: Apply specific middleware to routes
    // this.app.use('/auth', authRateLimiter);
    // this.app.use('/aws', awsRateLimiter);
    // this.app.use('/api', apiRateLimiter);
  }

  private setupRoutes(): void {
    // Health check (usually excluded from rate limiting)
    this.app.get('/health', (req, res) => {
      res.json({ 
        status: 'healthy',
        timestamp: new Date().toISOString(),
        uptime: process.uptime()
      });
    });

    // Authentication endpoints (strict rate limiting)
    this.app.post('/api/auth/login', this.handleLogin.bind(this));
    this.app.post('/api/auth/register', this.handleRegister.bind(this));
    this.app.post('/api/auth/forgot-password', this.handleForgotPassword.bind(this));

    // AWS operation endpoints (moderate rate limiting)
    this.app.post('/api/aws/s3/upload', this.handleS3Upload.bind(this));
    this.app.get('/api/aws/s3/download/:key', this.handleS3Download.bind(this));
    this.app.post('/api/aws/secrets-manager/create', this.handleSecretsCreate.bind(this));

    // API endpoints (generous rate limiting)
    this.app.get('/api/users', this.handleGetUsers.bind(this));
    this.app.post('/api/users', this.handleCreateUser.bind(this));
    this.app.get('/api/data', this.handleGetData.bind(this));

    // Admin endpoints (custom rate limiting + admin bypass)
    this.app.get('/admin/stats', this.handleAdminStats.bind(this));
    this.app.get('/admin/users', this.handleAdminUsers.bind(this));
    this.app.delete('/admin/users/:id', this.handleAdminDeleteUser.bind(this));

    // Rate limit management endpoints
    this.app.get('/api/rate-limit/info', this.handleRateLimitInfo.bind(this));
    this.app.delete('/api/rate-limit/clear', this.handleClearRateLimit.bind(this));

    // Example of manual rate limit check
    this.app.post('/api/special-operation', this.handleSpecialOperation.bind(this));

    // Test endpoint with custom rate limiting
    this.app.use('/api/strict', rateLimiter({
      default: {
        windowMs: 60 * 1000, // 1 minute
        maxRequests: 5, // Very strict
        message: 'This endpoint has very strict rate limiting.'
      }
    }));

    this.app.get('/api/strict/test', (req, res) => {
      res.json({ message: 'Strict endpoint test' });
    });

    // Example endpoint with custom key generation
    this.app.use('/api/versioned', rateLimiter({
      default: {
        windowMs: 10 * 60 * 1000, // 10 minutes
        maxRequests: 50,
        keyGenerator: (req) => {
          // Rate limit by API version
          const version = req.headers['api-version'] || 'v1';
          return version;
        }
      }
    }));

    this.app.get('/api/versioned/data', (req, res) => {
      res.json({ 
        version: req.headers['api-version'] || 'v1',
        data: 'versioned data'
      });
    });

    // Error handler
    this.app.use(this.errorHandler.bind(this));
  }

  // Route Handlers
  private async handleLogin(req: Request, res: Response): Promise<void> {
    const { email, password } = req.body;

    try {
      // Mock authentication logic
      if (email === 'admin@example.com' && password === 'admin') {
        res.json({
          success: true,
          token: 'admin-token',
          user: req.user
        });
      } else if (email && password) {
        res.json({
          success: true,
          token: `user-${Date.now()}`,
          user: { id: '123', role: 'user' }
        });
      } else {
        res.status(401).json({
          success: false,
          error: 'Invalid credentials'
        });
      }
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Authentication failed'
      });
    }
  }

  private async handleRegister(req: Request, res: Response): Promise<void> {
    const { email, password } = req.body;
    
    // Mock registration
    res.json({
      success: true,
      message: 'User registered successfully',
      userId: 'new-user-id'
    });
  }

  private async handleForgotPassword(req: Request, res: Response): Promise<void> {
    const { email } = req.body;
    
    res.json({
      success: true,
      message: 'Password reset email sent'
    });
  }

  private async handleS3Upload(req: Request, res: Response): Promise<void> {
    // Mock S3 upload
    res.json({
      success: true,
      key: `uploaded-file-${Date.now()}`,
      url: 'https://s3.amazonaws.com/bucket/key'
    });
  }

  private async handleS3Download(req: Request, res: Response): Promise<void> {
    const { key } = req.params;
    
    res.json({
      success: true,
      key,
      url: `https://s3.amazonaws.com/bucket/${key}`
    });
  }

  private async handleSecretsCreate(req: Request, res: Response): Promise<void> {
    // Mock secrets creation
    res.json({
      success: true,
      secretId: 'secret-123',
      arn: 'arn:aws:secretsmanager:region:account:secret:secret-123'
    });
  }

  private async handleGetUsers(req: Request, res: Response): Promise<void> {
    // Mock user list
    res.json({
      users: [
        { id: '1', email: 'user1@example.com' },
        { id: '2', email: 'user2@example.com' }
      ],
      total: 2
    });
  }

  private async handleCreateUser(req: Request, res: Response): Promise<void> {
    const { email } = req.body;
    
    res.json({
      success: true,
      user: {
        id: 'new-user',
        email
      }
    });
  }

  private async handleGetData(req: Request, res: Response): Promise<void> {
    res.json({
      data: 'sample data',
      timestamp: new Date().toISOString(),
      user: req.user
    });
  }

  private async handleAdminStats(req: Request, res: Response): Promise<void> {
    // Check if user is admin (rate limiting will be bypassed)
    if (req.user?.role !== 'admin') {
      res.status(403).json({
        error: 'Admin access required'
      });
      return;
    }

    res.json({
      stats: {
        totalUsers: 1000,
        totalRequests: 50000,
        activeUsers: 150
      }
    });
  }

  private async handleAdminUsers(req: Request, res: Response): Promise<void> {
    if (req.user?.role !== 'admin') {
      res.status(403).json({
        error: 'Admin access required'
      });
      return;
    }

    res.json({
      users: [
        { id: '1', email: 'user1@example.com', role: 'user' },
        { id: '2', email: 'user2@example.com', role: 'user' }
      ]
    });
  }

  private async handleAdminDeleteUser(req: Request, res: Response): Promise<void> {
    if (req.user?.role !== 'admin') {
      res.status(403).json({
        error: 'Admin access required'
      });
      return;
    }

    const { id } = req.params;
    
    res.json({
      success: true,
      message: `User ${id} deleted`
    });
  }

  private async handleRateLimitInfo(req: Request, res: Response): Promise<void> {
    if (!this.redis) {
      res.status(503).json({
        error: 'Redis not available for rate limit info'
      });
      return;
    }

    try {
      const identifier = `ip:${req.ip}`;
      const info = await getRateLimitInfo(identifier, this.redis);
      
      res.json({
        identifier,
        info
      });
    } catch (error) {
      res.status(500).json({
        error: 'Failed to get rate limit info'
      });
    }
  }

  private async handleClearRateLimit(req: Request, res: Response): Promise<void> {
    // Only admins can clear rate limits
    if (req.user?.role !== 'admin') {
      res.status(403).json({
        error: 'Admin access required'
      });
      return;
    }

    if (!this.redis) {
      res.status(503).json({
        error: 'Redis not available'
      });
      return;
    }

    try {
      const { identifier } = req.body;
      await clearRateLimit(identifier, this.redis);
      
      res.json({
        success: true,
        message: `Rate limit cleared for ${identifier}`
      });
    } catch (error) {
      res.status(500).json({
        error: 'Failed to clear rate limit'
      });
    }
  }

  private async handleSpecialOperation(req: Request, res: Response): Promise<void> {
    if (!this.redis) {
      res.status(503).json({
        error: 'Redis not available for manual rate limiting'
      });
      return;
    }

    try {
      // Manual rate limit check for special operations
      const identifier = `special:${req.user?.id || req.ip}`;
      const result = await checkRateLimit(
        identifier,
        3, // Max 3 special operations
        5 * 60 * 1000, // Per 5 minutes
        this.redis
      );

      if (!result.allowed) {
        res.status(429).json({
          error: 'Special operation rate limit exceeded',
          remaining: result.remaining,
          reset: result.reset
        });
        return;
      }

      // Perform special operation
      res.json({
        success: true,
        operation: 'special',
        remaining: result.remaining
      });
    } catch (error) {
      res.status(500).json({
        error: 'Operation failed'
      });
    }
  }

  private errorHandler(err: Error, req: Request, res: Response, next: NextFunction): void {
    console.error('Error:', err);

    res.status(500).json({
      error: 'Internal server error',
      message: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
  }

  public getApp(): express.Application {
    return this.app;
  }

  public async close(): Promise<void> {
    if (this.redis) {
      await this.redis.quit();
    }
  }
}

// Export for use in other modules
export default RateLimiterExample;

// Example usage
if (require.main === module) {
  const server = new RateLimiterExample();
  const app = server.getApp();
  
  const PORT = process.env.PORT || 3000;
  
  app.listen(PORT, () => {
    console.log(`🚀 Rate Limiter Example Server running on port ${PORT}`);
    console.log(`📊 Rate limiting enabled with Redis: ${!!server['redis']}`);
    console.log('');
    console.log('Test endpoints:');
    console.log(`  GET  http://localhost:${PORT}/health`);
    console.log(`  POST http://localhost:${PORT}/api/auth/login`);
    console.log(`  GET  http://localhost:${PORT}/api/users`);
    console.log(`  POST http://localhost:${PORT}/api/special-operation`);
    console.log('');
    console.log('With authentication:');
    console.log(`  curl -H "Authorization: Bearer user-token" http://localhost:${PORT}/api/data`);
    console.log(`  curl -H "Authorization: Bearer admin-token" http://localhost:${PORT}/admin/stats`);
  });

  // Graceful shutdown
  process.on('SIGTERM', async () => {
    console.log('Received SIGTERM, shutting down gracefully...');
    await server.close();
    process.exit(0);
  });

  process.on('SIGINT', async () => {
    console.log('Received SIGINT, shutting down gracefully...');
    await server.close();
    process.exit(0);
  });
}
