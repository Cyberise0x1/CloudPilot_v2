# Input Validation & Sanitization Middleware

Comprehensive validation and sanitization middleware for Express.js applications with protection against common security vulnerabilities.

## Features

- ✅ Request body validation (Joi & Zod support)
- ✅ Query parameter validation
- ✅ Path parameter validation
- ✅ File upload validation
- ✅ SQL injection prevention
- ✅ XSS prevention
- ✅ Command injection prevention
- ✅ Input sanitization functions
- ✅ Custom validation rules
- ✅ Validation error handling
- ✅ Rate limiting for validation attempts
- ✅ Comprehensive security measures

## Installation

```bash
npm install joi zod
# or
pnpm add joi zod
# or
yarn add joi zod
```

## Quick Start

```typescript
import express from 'express';
import { validateBody, validateQuery, validateParams, comprehensiveValidation } from './middleware/validation';

const app = express();

// Using individual middleware
app.post('/users', validateBody(userSchema), (req, res) => {
  // req.body is validated and sanitized
});

app.get('/users', validateQuery(paginationSchema), (req, res) => {
  // req.query is validated and sanitized
});

app.get('/users/:id', validateParams(idSchema), (req, res) => {
  // req.params is validated and sanitized
});

// Using comprehensive validation
app.post('/users', 
  comprehensiveValidation({
    bodySchema: userSchema,
    querySchema: querySchema,
    paramsSchema: paramsSchema,
    fileOptions: {
      allowedMimeTypes: ['image/jpeg', 'image/png'],
      maxFileSize: 5 * 1024 * 1024, // 5MB
      required: false
    },
    rateLimit: true,
    sanitize: true
  }),
  (req, res) => {
    // All inputs validated and sanitized
  }
);
```

## Validation Schemas

### Using Joi

```typescript
import Joi from 'joi';
import { validateBody, validationSchemas } from './middleware/validation';

const userSchema = Joi.object({
  email: validationSchemas.email.required(),
  password: validationSchemas.password.required(),
  name: Joi.string().min(2).max(100).required(),
  age: Joi.number().integer().min(18).max(120),
  phone: validationSchemas.phone
});

app.post('/users', validateBody(userSchema), handler);
```

### Using Zod

```typescript
import { z } from 'zod';
import { validateBody } from './middleware/validation';

const userSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  name: z.string().min(2).max(100),
  age: z.number().int().min(18).max(120),
  phone: z.string().regex(/^\+?[1-9]\d{1,14}$/)
});

app.post('/users', validateBody(userSchema), handler);
```

## Built-in Validation Schemas

The middleware provides pre-built schemas for common validations:

```typescript
import { validationSchemas } from './middleware/validation';

// MongoDB ObjectId
validationSchemas.mongoId

// UUID v4
validationSchemas.uuid

// Email
validationSchemas.email

// Password (strong)
validationSchemas.password

// URL
validationSchemas.url

// Phone (international)
validationSchemas.phone

// Date (ISO format)
validationSchemas.date

// Pagination
validationSchemas.pagination

// File upload
validationSchemas.file
```

## Custom Validators

```typescript
import { customValidators } from './middleware/validation';

const customSchema = Joi.object({
  username: Joi.string().custom((value, helpers) => {
    if (!customValidators.alphanumeric(value)) {
      return helpers.error('string.alphanumeric');
    }
    return value;
  }, 'alphanumeric validation'),
  
  creditCard: Joi.string().custom((value, helpers) => {
    if (!customValidators.creditCard(value)) {
      return helpers.error('string.creditCard');
    }
    return value;
  }, 'credit card validation')
});
```

## Sanitization Functions

```typescript
import { sanitizers } from './middleware/validation';

// HTML sanitization
const cleanHtml = sanitizers.sanitizeHtml(userInput);

// HTML entity escaping
const escapedHtml = sanitizers.escapeHtml(userInput);

// Filename sanitization
const safeFilename = sanitizers.sanitizeFilename(fileName);

// Object sanitization (recursive)
const sanitizedObject = sanitizers.sanitizeObject(userObject);

// SQL injection prevention
const sqlSafe = sanitizers.preventSQLInjection(userInput);

// Command injection prevention
const cmdSafe = sanitizers.preventCommandInjection(userInput);
```

## File Upload Validation

```typescript
import { validateFileUpload } from './middleware/validation';

app.post('/upload', 
  validateFileUpload({
    allowedMimeTypes: ['image/jpeg', 'image/png', 'image/gif'],
    maxFileSize: 5 * 1024 * 1024, // 5MB
    required: true,
    fieldName: 'avatar'
  }),
  (req, res) => {
    // File validated and safe
  }
);
```

## Error Handling

The middleware provides structured error responses:

```typescript
{
  "success": false,
  "error": {
    "message": "Validation failed",
    "code": "VALIDATION_ERROR",
    "details": [
      {
        "field": "email",
        "message": "Invalid email address",
        "code": "string.email",
        "value": "invalid-email"
      }
    ]
  }
}
```

## Security Features

### SQL Injection Prevention
```typescript
// Automatically sanitizes input to prevent SQL injection
const userInput = "'; DROP TABLE users; --";
const safeInput = sanitizers.preventSQLInjection(userInput);
// Result: " DROP TABLE users  "
```

### XSS Prevention
```typescript
// Sanitizes HTML to prevent XSS attacks
const maliciousInput = "<script>alert('XSS')</script>";
const cleanInput = sanitizers.sanitizeHtml(maliciousInput);
// Result: "scriptalert(XSS)/script"
```

### Command Injection Prevention
```typescript
// Removes shell metacharacters
const cmdInput = "file.txt; rm -rf /";
const safeCmd = sanitizers.preventCommandInjection(cmdInput);
// Result: "file.txt rm -rf /"
```

### Null Byte Prevention
```typescript
// Removes null bytes from strings
const nullInput = "valid\x00string";
const cleanInput = sanitizers.removeNullBytes(nullInput);
// Result: "validstring"
```

## Rate Limiting

The middleware includes rate limiting for validation attempts:

- Max 100 validation attempts per 15-minute window
- Applies per client IP address
- Returns 429 status code when exceeded

```typescript
// Rate limiting is enabled by default in comprehensiveValidation
const middlewares = comprehensiveValidation({
  // ... schemas
  rateLimit: true // Can be disabled if needed
});
```

## Advanced Usage

### Custom Validation Middleware

```typescript
import { createValidator } from './middleware/validation';

const customValidator = createValidator(customSchema, {
  stripUnknown: true,
  abortEarly: false,
  allowUnknown: false,
  stripNull: false,
  convert: true
});

app.post('/endpoint', customValidator, handler);
```

### Multiple File Upload Validation

```typescript
app.post('/upload-multiple',
  validateFileUpload({
    allowedMimeTypes: ['image/jpeg', 'image/png'],
    maxFileSize: 10 * 1024 * 1024, // 10MB
    required: false
  }),
  (req, res) => {
    const files = req.files;
    // All files validated
  }
);
```

### Validation with Custom Error Messages

```typescript
const customSchema = Joi.object({
  age: Joi.number()
    .min(18)
    .max(120)
    .messages({
      'number.min': 'You must be at least 18 years old',
      'number.max': 'Age cannot exceed 120 years',
      'number.base': 'Age must be a number'
    })
    .required()
});
```

## TypeScript Support

The middleware is fully typed with TypeScript:

```typescript
import { ValidationError, ValidationErrorDetail } from './middleware/validation';

try {
  // Validation logic
} catch (error) {
  if (error instanceof ValidationError) {
    console.log(error.errors); // ValidationErrorDetail[]
    console.log(error.statusCode); // 400
  }
}
```

## Best Practices

1. **Always sanitize user input** before validation
2. **Use rate limiting** to prevent abuse
3. **Validate both client and server side**
4. **Use strong password validation**
5. **Sanitize file uploads** thoroughly
6. **Handle validation errors gracefully**
7. **Log validation failures** for security monitoring
8. **Use HTTPS** in production
9. **Implement proper error logging**
10. **Test validation thoroughly**

## Integration with Express

```typescript
import express from 'express';
import { validationErrorHandler } from './middleware/validation';

const app = express();

// Add all validation middlewares
app.use(validationErrorHandler);

// Global error handler
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  console.error(err);
  res.status(500).json({
    success: false,
    error: {
      message: 'Internal server error',
      code: 'INTERNAL_ERROR'
    }
  });
});
```

## Testing Validation

```typescript
import request from 'supertest';
import { app } from './app';

describe('Validation Tests', () => {
  test('should reject invalid email', async () => {
    const response = await request(app)
      .post('/users')
      .send({ email: 'invalid-email', password: 'Password123!' });
    
    expect(response.status).toBe(400);
    expect(response.body.success).toBe(false);
    expect(response.body.error.code).toBe('VALIDATION_ERROR');
  });
});
```

## Performance Considerations

- Validation is performed synchronously for minimal overhead
- Rate limiting uses in-memory storage (consider Redis for production)
- File validation checks basic properties (extend as needed)
- Sanitization is optimized for common use cases

## Security Checklist

- ✅ SQL Injection prevention
- ✅ XSS prevention
- ✅ Command Injection prevention
- ✅ CSRF protection (implement separately)
- ✅ Rate limiting
- ✅ Input sanitization
- ✅ File type validation
- ✅ Size validation
- ✅ Null byte removal
- ✅ Control character removal
- ✅ Whitespace normalization

## License

MIT License - use freely in your projects.
