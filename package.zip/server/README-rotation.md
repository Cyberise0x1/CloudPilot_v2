# Secrets Rotation System

A comprehensive automated secrets rotation system with scheduling, notifications, auditing, and rollback capabilities.

## Features

- **Scheduled Rotation Checking**: Automatic rotation of secrets based on configured intervals
- **Notification System**: Multi-channel notifications (webhook, Slack, email) for rotation events
- **Secure Secret Updates**: Atomic secret rotation with version tracking
- **Rotation Logging**: Complete audit trail of all rotation activities
- **Rollback Mechanisms**: Automatic rollback on failed rotations
- **Flexible Configuration**: Configurable schedules and rotation intervals

## Usage

### Basic Setup

```typescript
import { 
  rotationSystem,
  registerSecret,
  rotateSecret,
  startRotationScheduler 
} from './secrets-rotation';

// Define your secret
const secret = {
  id: 'api-key-1',
  name: 'API Key for Service A',
  value: 'current-secret-value',
  version: 1,
  lastRotated: new Date(),
  nextRotation: new Date(),
  rotationInterval: 30, // days
  isActive: true,
  environment: 'production',
  metadata: {
    service: 'service-a',
    owner: 'team-alpha'
  }
};

// Register the secret for rotation
await registerSecret(secret);

// Start the automatic scheduler
startRotationScheduler();
```

### Manual Rotation

```typescript
// Rotate a specific secret manually
const event = await rotateSecret('api-key-1', 'user-alice');
console.log(`Secret rotated: ${event.status}`);
```

### Rotation Status

```typescript
import { getRotationStatus } from './secrets-rotation';

const status = await getRotationStatus('api-key-1');
console.log('Next rotation:', status.nextRotation);
console.log('Current version:', status.secret?.version);
```

### Audit Trail

```typescript
import { getAuditLog } from './secrets-rotation';

const auditLog = getAuditLog(50); // Get last 50 events
auditLog.forEach(event => {
  console.log(`${event.timestamp}: ${event.secretName} - ${event.status}`);
});
```

### Custom Configuration

```typescript
import { updateRotationConfig } from './secrets-rotation';

updateRotationConfig({
  maxRotationInterval: 60,
  enableNotifications: true,
  webhookUrl: 'https://your-webhook-endpoint.com/notify',
  slackWebhookUrl: 'https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK',
  emailRecipients: ['admin@company.com'],
  retryAttempts: 5,
  retryDelay: 2000
});
```

### Event Monitoring

```typescript
import { eventEmitter } from './secrets-rotation';

eventEmitter.on('rotation_event', (event) => {
  console.log(`Rotation event: ${event.secretName} - ${event.status}`);
  // Send to monitoring system
});

eventEmitter.on('notification', (notification) => {
  console.log(`Notification: ${notification.type}`);
  // Track notification delivery
});
```

## API Reference

### Core Functions

#### `registerSecret(secret: Secret): Promise<void>`
Registers a secret for automatic rotation management.

#### `rotateSecret(secretId: string, performedBy?: string): Promise<RotationEvent>`
Manually triggers rotation for a specific secret.

#### `rotateDueSecrets(performedBy?: string): Promise<RotationEvent[]>`
Rotates all secrets that are due for rotation.

### Scheduler Functions

#### `startRotationScheduler(): void`
Starts the automatic rotation scheduler.

#### `stopRotationScheduler(): void`
Stops the automatic rotation scheduler.

#### `scheduleRotation(secretId: string, cronExpression: string): void`
Schedules rotation using a cron expression.

### Status & Monitoring

#### `getRotationStatus(secretId: string): Promise<RotationStatus>`
Retrieves rotation status for a specific secret.

#### `getAuditLog(limit?: number): RotationEvent[]`
Returns the rotation audit log.

### Event System

#### `eventEmitter`
Event emitter for monitoring rotation events and notifications.

### Utility Functions

#### `calculateNextRotationDate(lastRotated: Date, intervalDays: number): Date`
Calculates the next rotation date based on last rotation.

#### `isRotationDue(secret: Secret, maxInterval?: number): boolean`
Checks if a secret is due for rotation.

## Configuration Options

```typescript
interface RotationConfig {
  maxRotationInterval: number;      // Maximum days between rotations
  notificationTimeout: number;       // Timeout for notifications (ms)
  rotationTimeout: number;           // Timeout for rotation (ms)
  retryAttempts: number;             // Number of retry attempts
  retryDelay: number;                // Delay between retries (ms)
  enableRollback: boolean;           // Enable automatic rollback
  enableNotifications: boolean;      // Enable notifications
  webhookUrl?: string;               // Custom webhook URL
  emailRecipients?: string[];        // Email recipients
  slackWebhookUrl?: string;          // Slack webhook URL
}
```

## Secret Object Format

```typescript
interface Secret {
  id: string;                        // Unique identifier
  name: string;                      // Human-readable name
  value: string;                     // Secret value (encrypted in production)
  version: number;                   // Current version
  lastRotated: Date;                 // Last rotation timestamp
  nextRotation: Date;                // Next scheduled rotation
  rotationInterval: number;          // Rotation interval in days
  isActive: boolean;                 // Whether rotation is enabled
  environment: string;               // Environment (dev, prod, etc.)
  metadata?: Record<string, any>;    // Additional metadata
}
```

## Rotation Events

```typescript
interface RotationEvent {
  id: string;                        // Event ID
  secretId: string;                  // Secret identifier
  secretName: string;                // Secret name
  timestamp: Date;                   // Event timestamp
  status: 'success' | 'failed' | 'rollback'; // Event status
  oldVersion: number;                // Previous version
  newVersion: number;                // New version
  error?: string;                    // Error message if failed
  duration: number;                  // Duration in milliseconds
  performedBy: string;               // Who performed the rotation
}
```

## Notification Types

- **rotation_started**: Triggered when rotation begins
- **rotation_success**: Triggered on successful rotation
- **rotation_failed**: Triggered on rotation failure
- **rotation_rollback**: Triggered when rollback occurs

## Integration Examples

### With AWS Secrets Manager

```typescript
// Replace the generateNewSecretValue method with AWS SDK calls
async function generateNewSecretValue(oldValue: string): Promise<string> {
  const newSecret = await secretsManager.getSecretValue({
    SecretId: 'your-secret-id'
  }).promise();
  return newSecret.SecretString;
}
```

### With External Database

```typescript
class DatabaseSecretsStorage implements ISecretsStorage {
  // Implement database-backed storage
}
```

### With Monitoring Systems

```typescript
eventEmitter.on('rotation_event', (event) => {
  // Send to DataDog, New Relic, etc.
  datadogMetric('secrets.rotation.duration', event.duration, {
    secret: event.secretName,
    status: event.status
  });
});
```

## Best Practices

1. **Regular Audits**: Regularly review the audit log for anomalies
2. **Test Rollbacks**: Periodically test rollback functionality
3. **Monitor Notifications**: Ensure notification channels are working
4. **Stagger Rotations**: Use different intervals to avoid simultaneous rotations
5. **Backup Secrets**: Always maintain backup copies before rotation
6. **Environment Separation**: Use different rotation schedules per environment

## Security Considerations

- Secrets are stored in memory for demonstration; use encrypted database in production
- Implement proper access controls for rotation operations
- Use secure communication channels for notifications
- Maintain audit logs in immutable storage
- Implement proper authentication for rotation triggers
