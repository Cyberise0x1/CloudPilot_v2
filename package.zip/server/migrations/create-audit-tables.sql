-- =====================================================================================
-- Create Audit Tables Migration
-- =====================================================================================
-- Description: Complete database migration for audit trail system including 
--              auditLogs, auditSessions, and auditEvents tables with proper
--              indexes, constraints, RLS policies, and sample data
-- Migration File: create-audit-tables.sql
-- Created: 2025-10-31
-- =====================================================================================

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =====================================================================================
-- TABLE DEFINITIONS
-- =====================================================================================

-- Create audit_logs table for general audit trail
CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    session_id TEXT,
    action TEXT NOT NULL,
    resource_type TEXT NOT NULL,
    resource_id TEXT,
    details JSONB DEFAULT '{}',
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    request_id TEXT,
    correlation_id TEXT,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    success BOOLEAN NOT NULL DEFAULT TRUE,
    error_message TEXT,
    execution_time_ms INTEGER,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create audit_sessions table for user session tracking
CREATE TABLE IF NOT EXISTS audit_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    session_id TEXT NOT NULL UNIQUE,
    ip_address INET,
    user_agent TEXT,
    device_type TEXT,
    browser_name TEXT,
    browser_version TEXT,
    os_name TEXT,
    os_version TEXT,
    country_code TEXT,
    city TEXT,
    login_time TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_activity TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    logout_time TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT TRUE,
    session_duration INTERVAL,
    request_count INTEGER DEFAULT 0,
    failure_count INTEGER DEFAULT 0,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create audit_events table for detailed event tracking
CREATE TABLE IF NOT EXISTS audit_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    session_id UUID REFERENCES audit_sessions(id) ON DELETE SET NULL,
    event_type TEXT NOT NULL,
    event_category TEXT NOT NULL,
    event_subcategory TEXT,
    description TEXT NOT NULL,
    severity TEXT NOT NULL DEFAULT 'info' CHECK (severity IN ('debug', 'info', 'warning', 'error', 'critical')),
    priority INTEGER DEFAULT 0 CHECK (priority >= 0 AND priority <= 100),
    resource_type TEXT,
    resource_id TEXT,
    action TEXT,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    request_id TEXT,
    correlation_id TEXT,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    processed BOOLEAN DEFAULT FALSE,
    retry_count INTEGER DEFAULT 0,
    max_retries INTEGER DEFAULT 3,
    error_details JSONB,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================================================

-- Indexes for audit_logs table
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_session_id ON audit_logs(session_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_logs_resource ON audit_logs(resource_type, resource_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_timestamp ON audit_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_success ON audit_logs(success);
CREATE INDEX IF NOT EXISTS idx_audit_logs_request_id ON audit_logs(request_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_correlation_id ON audit_logs(correlation_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_ip_address ON audit_logs(ip_address);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_details_gin ON audit_logs USING GIN (details);
CREATE INDEX IF NOT EXISTS idx_audit_logs_metadata_gin ON audit_logs USING GIN (metadata);

-- Indexes for audit_sessions table
CREATE INDEX IF NOT EXISTS idx_audit_sessions_user_id ON audit_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_sessions_session_id ON audit_sessions(session_id);
CREATE INDEX IF NOT EXISTS idx_audit_sessions_last_activity ON audit_sessions(last_activity DESC);
CREATE INDEX IF NOT EXISTS idx_audit_sessions_is_active ON audit_sessions(is_active);
CREATE INDEX IF NOT EXISTS idx_audit_sessions_login_time ON audit_sessions(login_time DESC);
CREATE INDEX IF NOT EXISTS idx_audit_sessions_ip_address ON audit_sessions(ip_address);
CREATE INDEX IF NOT EXISTS idx_audit_sessions_device_type ON audit_sessions(device_type);
CREATE INDEX IF NOT EXISTS idx_audit_sessions_metadata_gin ON audit_sessions USING GIN (metadata);

-- Indexes for audit_events table
CREATE INDEX IF NOT EXISTS idx_audit_events_user_id ON audit_events(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_events_session_id ON audit_events(session_id);
CREATE INDEX IF NOT EXISTS idx_audit_events_event_type ON audit_events(event_type);
CREATE INDEX IF NOT EXISTS idx_audit_events_event_category ON audit_events(event_category);
CREATE INDEX IF NOT EXISTS idx_audit_events_severity ON audit_events(severity);
CREATE INDEX IF NOT EXISTS idx_audit_events_priority ON audit_events(priority DESC);
CREATE INDEX IF NOT EXISTS idx_audit_events_resource ON audit_events(resource_type, resource_id);
CREATE INDEX IF NOT EXISTS idx_audit_events_timestamp ON audit_events(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_events_processed ON audit_events(processed);
CREATE INDEX IF NOT EXISTS idx_audit_events_request_id ON audit_events(request_id);
CREATE INDEX IF NOT EXISTS idx_audit_events_correlation_id ON audit_events(correlation_id);
CREATE INDEX IF NOT EXISTS idx_audit_events_metadata_gin ON audit_events USING GIN (metadata);

-- Composite indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_timestamp ON audit_logs(user_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_logs_resource_timestamp ON audit_logs(resource_type, resource_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_events_user_timestamp ON audit_events(user_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_events_category_timestamp ON audit_events(event_category, timestamp DESC);

-- =====================================================================================
-- TRIGGERS AND FUNCTIONS
-- =====================================================================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply updated_at triggers to all tables
CREATE TRIGGER update_audit_logs_updated_at BEFORE UPDATE ON audit_logs
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_audit_sessions_updated_at BEFORE UPDATE ON audit_sessions
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_audit_events_updated_at BEFORE UPDATE ON audit_events
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to automatically log audit actions
CREATE OR REPLACE FUNCTION log_audit_action(
    p_user_id UUID,
    p_action TEXT,
    p_resource_type TEXT,
    p_resource_id TEXT DEFAULT NULL,
    p_details JSONB DEFAULT '{}',
    p_success BOOLEAN DEFAULT TRUE,
    p_error_message TEXT DEFAULT NULL,
    p_session_id TEXT DEFAULT NULL,
    p_ip_address INET DEFAULT NULL,
    p_user_agent TEXT DEFAULT NULL,
    p_old_values JSONB DEFAULT NULL,
    p_new_values JSONB DEFAULT NULL,
    p_request_id TEXT DEFAULT NULL,
    p_correlation_id TEXT DEFAULT NULL,
    p_execution_time_ms INTEGER DEFAULT NULL,
    p_metadata JSONB DEFAULT '{}'
) RETURNS UUID AS $$
DECLARE
    audit_id UUID;
BEGIN
    INSERT INTO audit_logs (
        user_id, action, resource_type, resource_id, details, success, error_message,
        session_id, ip_address, user_agent, old_values, new_values, request_id,
        correlation_id, execution_time_ms, metadata
    ) VALUES (
        p_user_id, p_action, p_resource_type, p_resource_id, p_details, p_success, p_error_message,
        p_session_id, p_ip_address, p_user_agent, p_old_values, p_new_values, p_request_id,
        p_correlation_id, p_execution_time_ms, p_metadata
    ) RETURNING id INTO audit_id;
    
    RETURN audit_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to create audit event
CREATE OR REPLACE FUNCTION create_audit_event(
    p_user_id UUID,
    p_event_type TEXT,
    p_event_category TEXT,
    p_description TEXT,
    p_severity TEXT DEFAULT 'info',
    p_session_id UUID DEFAULT NULL,
    p_resource_type TEXT DEFAULT NULL,
    p_resource_id TEXT DEFAULT NULL,
    p_action TEXT DEFAULT NULL,
    p_old_values JSONB DEFAULT NULL,
    p_new_values JSONB DEFAULT NULL,
    p_ip_address INET DEFAULT NULL,
    p_user_agent TEXT DEFAULT NULL,
    p_request_id TEXT DEFAULT NULL,
    p_correlation_id TEXT DEFAULT NULL,
    p_priority INTEGER DEFAULT 0,
    p_metadata JSONB DEFAULT '{}'
) RETURNS UUID AS $$
DECLARE
    event_id UUID;
BEGIN
    INSERT INTO audit_events (
        user_id, event_type, event_category, description, severity, session_id,
        resource_type, resource_id, action, old_values, new_values, ip_address,
        user_agent, request_id, correlation_id, priority, metadata
    ) VALUES (
        p_user_id, p_event_type, p_event_category, p_description, p_severity, p_session_id,
        p_resource_type, p_resource_id, p_action, p_old_values, p_new_values, p_ip_address,
        p_user_agent, p_request_id, p_correlation_id, p_priority, p_metadata
    ) RETURNING id INTO event_id;
    
    RETURN event_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to update session last activity
CREATE OR REPLACE FUNCTION update_session_activity(p_session_id TEXT)
RETURNS VOID AS $$
BEGIN
    UPDATE audit_sessions 
    SET 
        last_activity = NOW(),
        request_count = request_count + 1,
        updated_at = NOW()
    WHERE session_id = p_session_id AND is_active = TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =====================================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- =====================================================================================

-- Enable RLS on all audit tables
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_events ENABLE ROW LEVEL SECURITY;

-- RLS policies for audit_logs
CREATE POLICY "Users can view their own audit logs" ON audit_logs
    FOR SELECT USING (auth.uid() = user_id OR auth.jwt() ->> 'role' = 'admin');

CREATE POLICY "Service role can manage all audit logs" ON audit_logs
    FOR ALL USING (auth.jwt() ->> 'role' = 'service_role');

CREATE POLICY "Authenticated users can insert audit logs" ON audit_logs
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- RLS policies for audit_sessions
CREATE POLICY "Users can view their own sessions" ON audit_sessions
    FOR SELECT USING (auth.uid() = user_id OR auth.jwt() ->> 'role' = 'admin');

CREATE POLICY "Service role can manage all sessions" ON audit_sessions
    FOR ALL USING (auth.jwt() ->> 'role' = 'service_role');

CREATE POLICY "Authenticated users can insert sessions" ON audit_sessions
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- RLS policies for audit_events
CREATE POLICY "Users can view their own audit events" ON audit_events
    FOR SELECT USING (auth.uid() = user_id OR auth.jwt() ->> 'role' = 'admin');

CREATE POLICY "Service role can manage all audit events" ON audit_events
    FOR ALL USING (auth.jwt() ->> 'role' = 'service_role');

CREATE POLICY "Authenticated users can insert audit events" ON audit_events
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- =====================================================================================
-- SAMPLE DATA FOR TESTING
-- =====================================================================================

-- Sample audit logs
INSERT INTO audit_logs (user_id, action, resource_type, resource_id, details, success, ip_address, user_agent) VALUES
(uuid_generate_v4(), 'user_login', 'authentication', 'session_123', '{"method": "password"}', TRUE, '192.168.1.100', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'),
(uuid_generate_v4(), 'user_logout', 'authentication', 'session_123', '{"duration": "2h 15m"}', TRUE, '192.168.1.100', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'),
(uuid_generate_v4(), 'create', 'user_profile', uuid_generate_v4(), '{"field": "email", "value": "user@example.com"}', TRUE, '192.168.1.101', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36'),
(uuid_generate_v4(), 'update', 'user_profile', uuid_generate_v4(), '{"field": "profile", "changes": {"name": "John Doe"}}', TRUE, '192.168.1.102', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'),
(uuid_generate_v4(), 'delete', 'document', uuid_generate_v4(), '{"document_id": "doc_456"}', TRUE, '192.168.1.103', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'),
(uuid_generate_v4(), 'failed_login', 'authentication', 'invalid_session', '{"reason": "invalid_credentials"}', FALSE, '192.168.1.104', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'),
(uuid_generate_v4(), 'export_data', 'user_data', uuid_generate_v4(), '{"format": "csv", "records": 1500}', TRUE, '192.168.1.105', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36');

-- Sample audit sessions
INSERT INTO audit_sessions (user_id, session_id, ip_address, user_agent, device_type, browser_name, os_name, country_code, city) VALUES
(uuid_generate_v4(), 'sess_abc123def456', '192.168.1.100', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', 'desktop', 'Chrome', 'Windows', 'US', 'New York'),
(uuid_generate_v4(), 'sess_def456ghi789', '192.168.1.101', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36', 'desktop', 'Safari', 'macOS', 'US', 'San Francisco'),
(uuid_generate_v4(), 'sess_ghi789jkl012', '192.168.1.102', 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X) AppleWebKit/605.1.15', 'mobile', 'Safari', 'iOS', 'CA', 'Los Angeles'),
(uuid_generate_v4(), 'sess_jkl012mno345', '192.168.1.103', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36', 'desktop', 'Firefox', 'Linux', 'GB', 'London'),
(uuid_generate_v4(), 'sess_mno345pqr678', '192.168.1.104', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', 'desktop', 'Edge', 'Windows', 'DE', 'Berlin');

-- Sample audit events
INSERT INTO audit_events (user_id, session_id, event_type, event_category, description, severity, resource_type, resource_id, action, ip_address, user_agent, priority) VALUES
(uuid_generate_v4(), (SELECT id FROM audit_sessions LIMIT 1), 'authentication', 'login', 'User successfully logged in', 'info', 'session', 'sess_abc123def456', 'login', '192.168.1.100', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', 1),
(uuid_generate_v4(), (SELECT id FROM audit_sessions LIMIT 1), 'data_access', 'read', 'User accessed sensitive customer data', 'warning', 'customer_data', uuid_generate_v4(), 'read', '192.168.1.100', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', 2),
(uuid_generate_v4(), (SELECT id FROM audit_sessions LIMIT 1), 'system', 'error', 'Database connection timeout occurred', 'error', 'database', 'connection_pool', 'connect', '192.168.1.100', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', 3),
(uuid_generate_v4(), (SELECT id FROM audit_sessions LIMIT 2), 'security', 'permission', 'User attempted to access admin panel without permission', 'critical', 'admin_panel', 'dashboard', 'access', '192.168.1.101', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36', 4),
(uuid_generate_v4(), (SELECT id FROM audit_sessions LIMIT 2), 'data_modification', 'create', 'New user account created', 'info', 'user_account', uuid_generate_v4(), 'create', '192.168.1.101', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36', 1),
(uuid_generate_v4(), (SELECT id FROM audit_sessions LIMIT 3), 'api', 'rate_limit', 'API rate limit exceeded for user', 'warning', 'api_endpoint', '/api/v1/users', 'GET', '192.168.1.102', 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X) AppleWebKit/605.1.15', 2),
(uuid_generate_v4(), (SELECT id FROM audit_sessions LIMIT 4), 'backup', 'maintenance', 'Daily backup completed successfully', 'info', 'backup_system', 'daily_2025_10_31', 'backup', '192.168.1.103', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36', 1);

-- =====================================================================================
-- VIEWS FOR COMMON QUERIES
-- =====================================================================================

-- View for recent audit activity
CREATE OR REPLACE VIEW recent_audit_activity AS
SELECT 
    al.id,
    al.user_id,
    al.action,
    al.resource_type,
    al.resource_id,
    al.success,
    al.timestamp,
    al.ip_address,
    au.email as user_email,
    CASE 
        WHEN al.timestamp > NOW() - INTERVAL '1 hour' THEN 'last_hour'
        WHEN al.timestamp > NOW() - INTERVAL '1 day' THEN 'last_day'
        WHEN al.timestamp > NOW() - INTERVAL '1 week' THEN 'last_week'
        ELSE 'older'
    END as time_category
FROM audit_logs al
LEFT JOIN auth.users au ON al.user_id = au.id
WHERE al.timestamp > NOW() - INTERVAL '1 month'
ORDER BY al.timestamp DESC;

-- View for user session summary
CREATE OR REPLACE VIEW user_session_summary AS
SELECT 
    s.user_id,
    au.email as user_email,
    COUNT(s.id) as total_sessions,
    COUNT(CASE WHEN s.is_active THEN 1 END) as active_sessions,
    MAX(s.last_activity) as last_activity,
    SUM(s.session_duration) as total_session_duration,
    AVG(s.request_count) as avg_requests_per_session
FROM audit_sessions s
LEFT JOIN auth.users au ON s.user_id = au.id
GROUP BY s.user_id, au.email;

-- View for security events
CREATE OR REPLACE VIEW security_events AS
SELECT 
    ae.id,
    ae.user_id,
    ae.event_type,
    ae.event_category,
    ae.description,
    ae.severity,
    ae.ip_address,
    ae.timestamp,
    au.email as user_email,
    ae.metadata
FROM audit_events ae
LEFT JOIN auth.users au ON ae.user_id = au.id
WHERE ae.severity IN ('warning', 'error', 'critical')
   OR ae.event_category IN ('security', 'authentication', 'permission')
ORDER BY ae.severity DESC, ae.timestamp DESC;

-- =====================================================================================
-- PERMISSIONS
-- =====================================================================================

-- Grant permissions to authenticated users
GRANT SELECT ON audit_logs TO authenticated;
GRANT SELECT ON audit_sessions TO authenticated;
GRANT SELECT ON audit_events TO authenticated;

-- Grant permissions to service role for full access
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO service_role;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO service_role;

-- Grant permissions on functions
GRANT EXECUTE ON FUNCTION log_audit_action TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION create_audit_event TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION update_session_activity TO authenticated, service_role;

-- Grant permissions on views
GRANT SELECT ON recent_audit_activity TO authenticated;
GRANT SELECT ON user_session_summary TO authenticated;
GRANT SELECT ON security_events TO authenticated;

-- =====================================================================================
-- VERIFICATION QUERIES
-- =====================================================================================

-- Check table creation
DO $$
BEGIN
    -- Verify tables exist
    IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'audit_logs') THEN
        RAISE EXCEPTION 'audit_logs table was not created';
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'audit_sessions') THEN
        RAISE EXCEPTION 'audit_sessions table was not created';
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'audit_events') THEN
        RAISE EXCEPTION 'audit_events table was not created';
    END IF;
    
    -- Verify indexes exist
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_audit_logs_user_id') THEN
        RAISE EXCEPTION 'Index idx_audit_logs_user_id was not created';
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_audit_sessions_user_id') THEN
        RAISE EXCEPTION 'Index idx_audit_sessions_user_id was not created';
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_audit_events_user_id') THEN
        RAISE EXCEPTION 'Index idx_audit_events_user_id was not created';
    END IF;
    
    -- Verify functions exist
    IF NOT EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'log_audit_action') THEN
        RAISE EXCEPTION 'Function log_audit_action was not created';
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM pg_proc WHERE proname = 'create_audit_event') THEN
        RAISE EXCEPTION 'Function create_audit_event was not created';
    END IF;
    
    -- Verify views exist
    IF NOT EXISTS (SELECT 1 FROM information_schema.views WHERE table_name = 'recent_audit_activity') THEN
        RAISE EXCEPTION 'View recent_audit_activity was not created';
    END IF;
    
    RAISE NOTICE 'All audit tables, indexes, functions, and views created successfully';
END $$;

-- Display table statistics
SELECT 
    schemaname,
    tablename,
    tableowner,
    hasindexes,
    hasrules,
    hastriggers
FROM pg_tables 
WHERE tablename IN ('audit_logs', 'audit_sessions', 'audit_events')
ORDER BY tablename;

-- Display index statistics
SELECT 
    schemaname,
    tablename,
    indexname,
    indexdef
FROM pg_indexes 
WHERE tablename IN ('audit_logs', 'audit_sessions', 'audit_events')
    AND schemaname = 'public'
ORDER BY tablename, indexname;

-- Display function information
SELECT 
    proname as function_name,
    prosrc as function_body,
    proowner
FROM pg_proc 
WHERE proname IN ('log_audit_action', 'create_audit_event', 'update_session_activity')
ORDER BY proname;

-- Display RLS policies
SELECT 
    schemaname,
    tablename,
    policyname,
    permissive,
    roles,
    cmd,
    qual
FROM pg_policies 
WHERE tablename IN ('audit_logs', 'audit_sessions', 'audit_events')
ORDER BY tablename, policyname;

-- Display sample data counts
SELECT 
    'audit_logs' as table_name,
    COUNT(*) as record_count
FROM audit_logs
UNION ALL
SELECT 
    'audit_sessions' as table_name,
    COUNT(*) as record_count
FROM audit_sessions
UNION ALL
SELECT 
    'audit_events' as table_name,
    COUNT(*) as record_count
FROM audit_events
ORDER BY table_name;

-- =====================================================================================
-- MIGRATION COMPLETE
-- =====================================================================================

DO $$
BEGIN
    RAISE NOTICE 'Audit tables migration completed successfully at %', NOW();
    RAISE NOTICE 'Created tables: audit_logs, audit_sessions, audit_events';
    RAISE NOTICE 'Created functions: log_audit_action, create_audit_event, update_session_activity';
    RAISE NOTICE 'Created views: recent_audit_activity, user_session_summary, security_events';
    RAISE NOTICE 'RLS policies enabled with appropriate permissions';
    RAISE NOTICE 'Sample data inserted for testing';
END $$;
