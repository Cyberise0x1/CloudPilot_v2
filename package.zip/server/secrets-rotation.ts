import { setTimeout as delay } from 'timers/promises';
import { EventEmitter } from 'events';

/**
 * Types for secrets rotation system
 */
export interface Secret {
  id: string;
  name: string;
  value: string;
  version: number;
  lastRotated: Date;
  nextRotation: Date;
  rotationInterval: number; // in days
  isActive: boolean;
  environment: string;
  metadata?: Record<string, any>;
}

export interface RotationConfig {
  maxRotationInterval: number; // maximum days between rotations
  notificationTimeout: number; // timeout for notifications in ms
  rotationTimeout: number; // timeout for rotation operations in ms
  retryAttempts: number; // number of retry attempts for failed rotations
  retryDelay: number; // delay between retries in ms
  enableRollback: boolean;
  enableNotifications: boolean;
  webhookUrl?: string;
  emailRecipients?: string[];
  slackWebhookUrl?: string;
}

export interface RotationEvent {
  id: string;
  secretId: string;
  secretName: string;
  timestamp: Date;
  status: 'success' | 'failed' | 'rollback';
  oldVersion: number;
  newVersion: number;
  error?: string;
  duration: number;
  performedBy: string;
}

export interface RotationSchedule {
  secretId: string;
  cronExpression: string;
  lastRun?: Date;
  nextRun?: Date;
  isActive: boolean;
}

export interface NotificationData {
  type: 'rotation_started' | 'rotation_success' | 'rotation_failed' | 'rotation_rollback';
  event: RotationEvent;
  timestamp: Date;
  recipients?: string[];
}

/**
 * Default configuration
 */
const DEFAULT_CONFIG: RotationConfig = {
  maxRotationInterval: 90,
  notificationTimeout: 5000,
  rotationTimeout: 30000,
  retryAttempts: 3,
  retryDelay: 1000,
  enableRollback: true,
  enableNotifications: true,
  webhookUrl: undefined,
  emailRecipients: [],
  slackWebhookUrl: undefined,
};

/**
 * Event emitter for rotation events
 */
class RotationEventEmitter extends EventEmitter {
  emitRotationEvent(event: RotationEvent) {
    this.emit('rotation_event', event);
  }

  emitNotification(notification: NotificationData) {
    this.emit('notification', notification);
  }
}

const eventEmitter = new RotationEventEmitter();

/**
 * Secrets Storage Interface
 */
interface ISecretsStorage {
  getSecret(id: string): Promise<Secret | null>;
  updateSecret(secret: Secret): Promise<void>;
  getAllSecrets(): Promise<Secret[]>;
  createAuditLog(event: RotationEvent): Promise<void>;
  rollbackSecret(secretId: string, version: number): Promise<void>;
}

/**
 * In-memory secrets storage for demonstration
 * In production, this would be replaced with a database or external service
 */
class InMemorySecretsStorage implements ISecretsStorage {
  private secrets = new Map<string, Secret>();
  private auditLog: RotationEvent[] = [];

  async getSecret(id: string): Promise<Secret | null> {
    return this.secrets.get(id) || null;
  }

  async updateSecret(secret: Secret): Promise<void> {
    this.secrets.set(secret.id, { ...secret, lastRotated: new Date() });
  }

  async getAllSecrets(): Promise<Secret[]> {
    return Array.from(this.secrets.values());
  }

  async createAuditLog(event: RotationEvent): Promise<void> {
    this.auditLog.push(event);
    console.log(`[AUDIT] ${event.timestamp.toISOString()} - Secret ${event.secretName}: ${event.status}`);
  }

  async rollbackSecret(secretId: string, version: number): Promise<void> {
    const secret = this.secrets.get(secretId);
    if (secret) {
      secret.version = version;
      // In production, you'd fetch the value for that version
      console.log(`[ROLLBACK] Rolled back secret ${secretId} to version ${version}`);
    }
  }

  getAuditLog(): RotationEvent[] {
    return this.auditLog;
  }
}

const storage = new InMemorySecretsStorage();

/**
 * Notification Service
 */
class NotificationService {
  private config: RotationConfig;

  constructor(config: RotationConfig) {
    this.config = config;
  }

  async sendNotification(notification: NotificationData): Promise<void> {
    if (!this.config.enableNotifications) {
      return;
    }

    const timeoutPromise = delay(this.config.notificationTimeout);
    const sendPromise = this.performSend(notification);

    try {
      await Promise.race([sendPromise, timeoutPromise]);
    } catch (error) {
      console.error(`[NOTIFICATION] Failed to send notification: ${error}`);
    }
  }

  private async performSend(notification: NotificationData): Promise<void> {
    const { type, event } = notification;
    
    const message = this.formatMessage(notification);

    // Send to webhook if configured
    if (this.config.webhookUrl) {
      await this.sendWebhook(message);
    }

    // Send to Slack if configured
    if (this.config.slackWebhookUrl) {
      await this.sendSlackMessage(message);
    }

    // Send to email recipients if configured
    if (this.config.emailRecipients?.length) {
      await this.sendEmail(message, this.config.emailRecipients);
    }

    // Log to console as fallback
    console.log(`[NOTIFICATION] ${type.toUpperCase()}: ${event.secretName} - ${event.status}`);
  }

  private formatMessage(notification: NotificationData): string {
    const { type, event, timestamp } = notification;
    
    const typeDescriptions = {
      rotation_started: '🔄 Secret rotation started',
      rotation_success: '✅ Secret rotation completed successfully',
      rotation_failed: '❌ Secret rotation failed',
      rotation_rollback: '↩️ Secret rotation rolled back',
    };

    return `${typeDescriptions[type]}\n` +
           `Secret: ${event.secretName}\n` +
           `Status: ${event.status}\n` +
           `Duration: ${event.duration}ms\n` +
           `Timestamp: ${timestamp.toISOString()}\n` +
           (event.error ? `Error: ${event.error}` : '');
  }

  private async sendWebhook(message: string): Promise<void> {
    if (!this.config.webhookUrl) return;

    try {
      const response = await fetch(this.config.webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message }),
      });

      if (!response.ok) {
        throw new Error(`Webhook returned ${response.status}`);
      }
    } catch (error) {
      console.error('[NOTIFICATION] Webhook error:', error);
      throw error;
    }
  }

  private async sendSlackMessage(message: string): Promise<void> {
    if (!this.config.slackWebhookUrl) return;

    try {
      const response = await fetch(this.config.slackWebhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: message }),
      });

      if (!response.ok) {
        throw new Error(`Slack webhook returned ${response.status}`);
      }
    } catch (error) {
      console.error('[NOTIFICATION] Slack error:', error);
      throw error;
    }
  }

  private async sendEmail(message: string, recipients: string[]): Promise<void> {
    // In production, you would integrate with an email service like SendGrid, SES, etc.
    console.log(`[NOTIFICATION] Email would be sent to ${recipients.join(', ')}:\n${message}`);
  }
}

/**
 * Secrets Rotation Service
 */
class SecretsRotationService {
  private config: RotationConfig;
  private notificationService: NotificationService;
  private rotationSchedules = new Map<string, RotationSchedule>();
  private scheduler: RotationScheduler | null = null;

  constructor(config: RotationConfig) {
    this.config = config;
    this.notificationService = new NotificationService(config);
  }

  /**
   * Register a secret for rotation
   */
  async registerSecret(secret: Secret): Promise<void> {
    const nextRotation = this.calculateNextRotation(secret);
    const updatedSecret = {
      ...secret,
      nextRotation,
    };

    await storage.updateSecret(updatedSecret);
    console.log(`[ROTATION] Registered secret ${secret.name} for rotation every ${secret.rotationInterval} days`);
  }

  /**
   * Manually rotate a secret
   */
  async rotateSecret(secretId: string, performedBy: string = 'manual'): Promise<RotationEvent> {
    const startTime = Date.now();
    const secret = await storage.getSecret(secretId);
    
    if (!secret) {
      throw new Error(`Secret ${secretId} not found`);
    }

    if (!secret.isActive) {
      throw new Error(`Secret ${secretId} is not active`);
    }

    const oldVersion = secret.version;
    const eventId = this.generateEventId();

    // Emit rotation started notification
    const startEvent: RotationEvent = {
      id: eventId,
      secretId: secret.id,
      secretName: secret.name,
      timestamp: new Date(),
      status: 'success',
      oldVersion,
      newVersion: oldVersion + 1,
      duration: 0,
      performedBy,
    };

    await this.notificationService.sendNotification({
      type: 'rotation_started',
      event: startEvent,
      timestamp: new Date(),
    });

    try {
      // Attempt rotation with retries
      const newSecret = await this.performRotationWithRetry(secret, performedBy);
      
      const duration = Date.now() - startTime;
      const successEvent: RotationEvent = {
        id: eventId,
        secretId: secret.id,
        secretName: secret.name,
        timestamp: new Date(),
        status: 'success',
        oldVersion,
        newVersion: newSecret.version,
        duration,
        performedBy,
      };

      await storage.updateSecret(newSecret);
      await storage.createAuditLog(successEvent);

      // Update next rotation
      await this.updateNextRotation(newSecret);

      // Emit success notification
      await this.notificationService.sendNotification({
        type: 'rotation_success',
        event: successEvent,
        timestamp: new Date(),
      });

      eventEmitter.emitRotationEvent(successEvent);
      return successEvent;

    } catch (error) {
      const duration = Date.now() - startTime;
      const failedEvent: RotationEvent = {
        id: eventId,
        secretId: secret.id,
        secretName: secret.name,
        timestamp: new Date(),
        status: 'failed',
        oldVersion,
        newVersion: oldVersion,
        duration,
        performedBy,
        error: error instanceof Error ? error.message : String(error),
      };

      await storage.createAuditLog(failedEvent);

      // Attempt rollback if enabled
      if (this.config.enableRollback) {
        try {
          await this.performRollback(secret, failedEvent);
        } catch (rollbackError) {
          console.error(`[ROTATION] Rollback failed: ${rollbackError}`);
        }
      }

      // Emit failure notification
      await this.notificationService.sendNotification({
        type: 'rotation_failed',
        event: failedEvent,
        timestamp: new Date(),
      });

      eventEmitter.emitRotationEvent(failedEvent);
      throw error;
    }
  }

  /**
   * Rotate all due secrets
   */
  async rotateDueSecrets(performedBy: string = 'scheduled'): Promise<RotationEvent[]> {
    const secrets = await storage.getAllSecrets();
    const now = new Date();
    const dueSecrets = secrets.filter(secret => 
      secret.isActive && secret.nextRotation <= now
    );

    console.log(`[ROTATION] Found ${dueSecrets.length} secrets due for rotation`);

    const results: RotationEvent[] = [];
    
    for (const secret of dueSecrets) {
      try {
        const event = await this.rotateSecret(secret.id, performedBy);
        results.push(event);
      } catch (error) {
        console.error(`[ROTATION] Failed to rotate secret ${secret.name}: ${error}`);
      }
    }

    return results;
  }

  /**
   * Schedule rotation for a secret using cron expression
   */
  scheduleRotation(secretId: string, cronExpression: string): void {
    const schedule: RotationSchedule = {
      secretId,
      cronExpression,
      isActive: true,
    };

    this.rotationSchedules.set(secretId, schedule);
    console.log(`[SCHEDULER] Scheduled rotation for secret ${secretId} with cron: ${cronExpression}`);
  }

  /**
   * Start the rotation scheduler
   */
  startScheduler(): void {
    if (this.scheduler) {
      console.log('[SCHEDULER] Scheduler already running');
      return;
    }

    this.scheduler = new RotationScheduler(this);
    this.scheduler.start();
    console.log('[SCHEDULER] Rotation scheduler started');
  }

  /**
   * Stop the rotation scheduler
   */
  stopScheduler(): void {
    if (this.scheduler) {
      this.scheduler.stop();
      this.scheduler = null;
      console.log('[SCHEDULER] Rotation scheduler stopped');
    }
  }

  /**
   * Get rotation status for a secret
   */
  getRotationStatus(secretId: string): Promise<{
    secret: Secret | null;
    schedules: RotationSchedule[];
    nextRotation?: Date;
  }> {
    return this.getRotationStatusInternal(secretId);
  }

  /**
   * Get audit log
   */
  getAuditLog(limit?: number): RotationEvent[] {
    const log = storage.getAuditLog();
    return limit ? log.slice(-limit) : log;
  }

  /**
   * Calculate next rotation date
   */
  private calculateNextRotation(secret: Secret): Date {
    const next = new Date(secret.lastRotated);
    next.setDate(next.getDate() + secret.rotationInterval);
    return next;
  }

  /**
   * Perform rotation with retry logic
   */
  private async performRotationWithRetry(secret: Secret, performedBy: string): Promise<Secret> {
    let lastError: Error | null = null;

    for (let attempt = 1; attempt <= this.config.retryAttempts; attempt++) {
      try {
        console.log(`[ROTATION] Attempting rotation ${attempt}/${this.config.retryAttempts} for ${secret.name}`);
        
        // Simulate secret rotation (generate new value)
        const newValue = this.generateNewSecretValue(secret.value);
        const newVersion = secret.version + 1;

        const rotatedSecret: Secret = {
          ...secret,
          value: newValue,
          version: newVersion,
          lastRotated: new Date(),
        };

        // Simulate rotation timeout
        await delay(Math.min(this.config.rotationTimeout, 100));

        return rotatedSecret;

      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
        console.error(`[ROTATION] Attempt ${attempt} failed:`, lastError);

        if (attempt < this.config.retryAttempts) {
          await delay(this.config.retryDelay * attempt);
        }
      }
    }

    throw lastError;
  }

  /**
   * Perform rollback
   */
  private async performRollback(secret: Secret, failedEvent: RotationEvent): Promise<void> {
    console.log(`[ROLLBACK] Starting rollback for secret ${secret.name}`);
    
    const rollbackEvent: RotationEvent = {
      ...failedEvent,
      status: 'rollback',
      timestamp: new Date(),
    };

    await storage.rollbackSecret(secret.id, secret.version);
    await storage.createAuditLog(rollbackEvent);

    await this.notificationService.sendNotification({
      type: 'rotation_rollback',
      event: rollbackEvent,
      timestamp: new Date(),
    });

    console.log(`[ROLLBACK] Completed rollback for secret ${secret.name}`);
  }

  /**
   * Generate new secret value
   */
  private generateNewSecretValue(oldValue: string): string {
    // In production, this would integrate with your secret management service
    // For now, we'll just generate a new random value
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    
    for (let i = 0; i < oldValue.length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    return result;
  }

  /**
   * Update next rotation for a secret
   */
  private async updateNextRotation(secret: Secret): Promise<void> {
    const nextRotation = this.calculateNextRotation(secret);
    const updatedSecret = { ...secret, nextRotation };
    await storage.updateSecret(updatedSecret);
  }

  /**
   * Generate unique event ID
   */
  private generateEventId(): string {
    return `evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Get rotation status internal
   */
  private async getRotationStatusInternal(secretId: string) {
    const secret = await storage.getSecret(secretId);
    const schedules = Array.from(this.rotationSchedules.values()).filter(
      s => s.secretId === secretId
    );
    
    const nextRotation = secret ? this.calculateNextRotation(secret) : undefined;

    return {
      secret,
      schedules,
      nextRotation,
    };
  }
}

/**
 * Rotation Scheduler
 */
class RotationScheduler {
  private service: SecretsRotationService;
  private intervalId: NodeJS.Timeout | null = null;
  private isRunning = false;

  constructor(service: SecretsRotationService) {
    this.service = service;
  }

  start(): void {
    if (this.isRunning) return;

    this.isRunning = true;
    // Check for due secrets every hour
    this.intervalId = setInterval(() => {
      this.checkAndRotateDueSecrets();
    }, 60 * 60 * 1000);

    console.log('[SCHEDULER] Started interval check for due secrets');
  }

  stop(): void {
    if (!this.isRunning) return;

    this.isRunning = false;
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  private async checkAndRotateDueSecrets(): Promise<void> {
    if (!this.isRunning) return;

    try {
      await this.service.rotateDueSecrets('scheduler');
    } catch (error) {
      console.error('[SCHEDULER] Error during scheduled rotation:', error);
    }
  }
}

/**
 * Main rotation system instance
 */
const rotationSystem = new SecretsRotationService(DEFAULT_CONFIG);

// Event listeners for monitoring
eventEmitter.on('rotation_event', (event: RotationEvent) => {
  console.log(`[MONITOR] Rotation event: ${event.secretName} - ${event.status}`);
});

eventEmitter.on('notification', (notification: NotificationData) => {
  console.log(`[MONITOR] Notification sent: ${notification.type}`);
});

/**
 * Public API exports
 */

// Rotation service instance
export { rotationSystem };

// Core functions
export async function rotateSecret(secretId: string, performedBy?: string): Promise<RotationEvent> {
  return rotationSystem.rotateSecret(secretId, performedBy);
}

export async function registerSecret(secret: Secret): Promise<void> {
  return rotationSystem.registerSecret(secret);
}

export async function rotateDueSecrets(performedBy?: string): Promise<RotationEvent[]> {
  return rotationSystem.rotateDueSecrets(performedBy);
}

// Scheduling functions
export function startRotationScheduler(): void {
  rotationSystem.startScheduler();
}

export function stopRotationScheduler(): void {
  rotationSystem.stopScheduler();
}

export function scheduleRotation(secretId: string, cronExpression: string): void {
  rotationSystem.scheduleRotation(secretId, cronExpression);
}

// Status and monitoring functions
export async function getRotationStatus(secretId: string) {
  return rotationSystem.getRotationStatus(secretId);
}

export function getAuditLog(limit?: number): RotationEvent[] {
  return rotationSystem.getAuditLog(limit);
}

// Event emitter for external listeners
export { eventEmitter };

// Configuration
export function updateRotationConfig(config: Partial<RotationConfig>): void {
  Object.assign(DEFAULT_CONFIG, config);
  console.log('[CONFIG] Rotation configuration updated');
}

// Utility functions
export function calculateNextRotationDate(lastRotated: Date, intervalDays: number): Date {
  const next = new Date(lastRotated);
  next.setDate(next.getDate() + intervalDays);
  return next;
}

export function isRotationDue(secret: Secret, maxInterval?: number): boolean {
  const interval = maxInterval || DEFAULT_CONFIG.maxRotationInterval;
  const now = new Date();
  const daysSinceRotation = (now.getTime() - secret.lastRotated.getTime()) / (1000 * 60 * 60 * 24);
  return daysSinceRotation >= interval;
}

// Types for external use
export type {
  Secret,
  RotationConfig,
  RotationEvent,
  RotationSchedule,
  NotificationData,
  ISecretsStorage,
};

console.log('[SECRETS-ROTATION] Secrets rotation system initialized');
