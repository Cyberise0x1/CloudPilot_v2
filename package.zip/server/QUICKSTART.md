# 🚀 Quick Start Guide - Secrets Rotation System

## Installation & Setup

The secrets rotation system is ready to use! Just import and start rotating secrets.

## Basic 5-Minute Setup

### Step 1: Import the system

```typescript
import {
  rotationSystem,
  registerSecret,
  rotateSecret,
  startRotationScheduler,
  getRotationStatus
} from './server/secrets-rotation';
```

### Step 2: Define your secret

```typescript
const mySecret = {
  id: 'my-api-key',
  name: 'My API Key',
  value: 'current-secret-value',
  version: 1,
  lastRotated: new Date(),
  nextRotation: new Date(),
  rotationInterval: 30, // days
  isActive: true,
  environment: 'production'
};
```

### Step 3: Register for rotation

```typescript
await registerSecret(mySecret);
console.log('Secret registered!');
```

### Step 4: Start automatic rotation

```typescript
startRotationScheduler();
console.log('Rotation scheduler started!');
```

### Step 5: Check status

```typescript
const status = await getRotationStatus('my-api-key');
console.log('Next rotation:', status.nextRotation);
```

**That's it! Your secret will now be automatically rotated every 30 days.**

## Common Tasks

### Rotate a secret manually

```typescript
const event = await rotateSecret('my-api-key', 'admin-user');
console.log(`Rotation ${event.status} in ${event.duration}ms`);
```

### Rotate all due secrets

```typescript
const events = await rotateDueSecrets('maintenance-script');
console.log(`Rotated ${events.length} secrets`);
```

### Configure notifications

```typescript
import { updateRotationConfig } from './server/secrets-rotation';

updateRotationConfig({
  webhookUrl: 'https://your-webhook.com/notify',
  slackWebhookUrl: 'https://hooks.slack.com/YOUR/WEBHOOK',
  emailRecipients: ['security@company.com'],
  enableNotifications: true
});
```

### Monitor rotation events

```typescript
import { eventEmitter } from './server/secrets-rotation';

eventEmitter.on('rotation_event', (event) => {
  console.log(`Rotation ${event.status}: ${event.secretName}`);
  
  if (event.status === 'failed') {
    console.error(`Error: ${event.error}`);
    // Send alert to team
  }
});
```

### View audit log

```typescript
const auditLog = getAuditLog(100); // Last 100 events
console.log('Recent rotations:', auditLog);
```

## Environment-Specific Usage

### Development Environment

```typescript
// Rotate more frequently in dev
const devSecret = {
  id: 'dev-api-key',
  rotationInterval: 7, // Weekly in dev
  environment: 'development'
};
```

### Production Environment

```typescript
// More conservative in prod
const prodSecret = {
  id: 'prod-api-key',
  rotationInterval: 90, // Quarterly in prod
  environment: 'production'
};
```

## Integration with Existing Secrets Manager

If you're using the existing secrets manager:

```typescript
import { EnhancedSecretsManager } from './server/integration-rotation';
import { secretsManager } from './server/secrets-manager';

const enhanced = new EnhancedSecretsManager(secretsManager);
await enhanced.initialize([
  {
    key: 'DATABASE_URL',
    required: true,
    rotationInterval: 30,
    autoRotate: true,
    environment: 'production'
  }
]);
```

## Running Examples

Try the example files to see all features:

```bash
# Basic rotation examples
npx ts-node server/examples-rotation.ts

# Integration examples
npx ts-node server/integration-rotation.ts
```

## Configuration Cheat Sheet

| What to change | How to change it |
|---------------|------------------|
| Rotation interval | `secret.rotationInterval = 30` (days) |
| Enable/disable rotation | `secret.isActive = true/false` |
| Notification webhook | `updateRotationConfig({ webhookUrl: '...' })` |
| Max rotation interval | `updateRotationConfig({ maxRotationInterval: 60 })` |
| Retry attempts | `updateRotationConfig({ retryAttempts: 5 })` |
| Enable rollback | `updateRotationConfig({ enableRollback: true })` |
| Email notifications | `updateRotationConfig({ emailRecipients: ['admin@company.com'] })` |
| Slack notifications | `updateRotationConfig({ slackWebhookUrl: '...' })` |

## Key Features Available

- ✅ **Scheduled rotation**: Automatic based on intervals
- ✅ **Manual rotation**: Trigger on demand
- ✅ **Notifications**: Webhook, Slack, Email
- ✅ **Audit trail**: Complete rotation history
- ✅ **Rollback**: Automatic on failure
- ✅ **Retry logic**: Configurable attempts
- ✅ **Event monitoring**: Real-time event tracking
- ✅ **Status queries**: Check rotation status anytime

## Need Help?

- Full documentation: `server/README-rotation.md`
- Implementation details: `server/IMPLEMENTATION-SUMMARY.md`
- Examples: `server/examples-rotation.ts`
- Integration guide: `server/integration-rotation.ts`

## Production Checklist

Before going to production:

- [ ] Replace InMemorySecretsStorage with database or external service
- [ ] Configure notifications (webhook/Slack/email)
- [ ] Set appropriate rotation intervals per environment
- [ ] Test rollback functionality
- [ ] Set up monitoring for rotation events
- [ ] Implement authentication for rotation endpoints
- [ ] Review audit log regularly
- [ ] Configure proper secret generation method

## Next Steps

1. Run the examples to familiarize yourself
2. Configure notifications for your team
3. Register your production secrets
4. Set up monitoring
5. Test in development environment first
6. Deploy to production with proper security measures

**Happy Rotating! 🔄**