/**
 * Integration Example: Using Secrets Rotation System with Secrets Manager
 * 
 * This example demonstrates how to integrate the rotation system with the existing
 * secrets manager for a complete secrets management solution.
 */

import {
  SecretsManager,
  secretsManager,
  type SecretConfig,
  type SecretsChangeEvent
} from './secrets-manager';

import {
  rotationSystem,
  registerSecret,
  rotateSecret,
  rotateDueSecrets,
  startRotationScheduler,
  getRotationStatus,
  getAuditLog,
  eventEmitter,
  type Secret,
  type RotationEvent
} from './secrets-rotation';

/**
 * Extended Secret Configuration
 * Combines both secrets manager and rotation capabilities
 */
interface ExtendedSecretConfig extends SecretConfig {
  rotationInterval?: number; // days
  autoRotate?: boolean;
  environment?: string;
}

/**
 * Enhanced Secrets Manager with Rotation Integration
 */
class EnhancedSecretsManager {
  private secretsManager: SecretsManager;
  private rotationConfig: Map<string, ExtendedSecretConfig> = new Map();

  constructor(secretsManager: SecretsManager) {
    this.secretsManager = secretsManager;

    // Listen for secret changes from the base secrets manager
    this.secretsManager.onSecretChange((event) => {
      this.handleSecretChange(event);
    });
  }

  /**
   * Initialize both secrets manager and rotation system
   */
  async initialize(configs: ExtendedSecretConfig[]): Promise<void> {
    console.log('🚀 Initializing Enhanced Secrets Manager with Rotation...');

    // Initialize base secrets manager
    await this.secretsManager.initialize();

    // Store extended configurations
    configs.forEach(config => {
      this.rotationConfig.set(config.key, config);
    });

    // Register secrets that need rotation
    await this.registerSecretsForRotation(configs);

    // Start rotation scheduler
    startRotationScheduler();

    console.log('✅ Enhanced Secrets Manager initialized');
  }

  /**
   * Get a secret value (same as base secrets manager)
   */
  getSecret(key: string): string | undefined {
    return this.secretsManager.getSecret(key);
  }

  /**
   * Get secret with rotation metadata
   */
  async getSecretWithRotationInfo(key: string) {
    const secretValue = this.secretsManager.getSecret(key);
    const rotationStatus = await getRotationStatus(key);
    
    return {
      value: secretValue,
      rotation: rotationStatus,
      config: this.rotationConfig.get(key)
    };
  }

  /**
   * Manually rotate a specific secret
   */
  async rotateSecretNow(key: string, performedBy: string = 'manual'): Promise<RotationEvent> {
    const config = this.rotationConfig.get(key);
    if (!config) {
      throw new Error(`Secret ${key} not configured for rotation`);
    }

    return await rotateSecret(key, performedBy);
  }

  /**
   * Get rotation statistics
   */
  getRotationStatistics() {
    const baseStats = this.secretsManager.getStatistics();
    const auditLog = getAuditLog();
    
    return {
      ...baseStats,
      rotationEvents: auditLog.length,
      successfulRotations: auditLog.filter(e => e.status === 'success').length,
      failedRotations: auditLog.filter(e => e.status === 'failed').length,
      recentRotations: auditLog.slice(-10)
    };
  }

  /**
   * Register secrets for rotation
   */
  private async registerSecretsForRotation(configs: ExtendedSecretConfig[]): Promise<void> {
    const secrets = this.secretsManager.getAllSecrets();

    for (const config of configs) {
      if (config.autoRotate && config.rotationInterval) {
        const secretValue = secrets[config.key];
        if (secretValue) {
          const rotationSecret: Secret = {
            id: config.key,
            name: config.description || config.key,
            value: secretValue,
            version: 1,
            lastRotated: new Date(),
            nextRotation: new Date(Date.now() + config.rotationInterval * 24 * 60 * 60 * 1000),
            rotationInterval: config.rotationInterval,
            isActive: true,
            environment: config.environment || 'production',
            metadata: {
              originalConfig: config
            }
          };

          await registerSecret(rotationSecret);
          console.log(`🔄 Registered ${config.key} for rotation (every ${config.rotationInterval} days)`);
        }
      }
    }
  }

  /**
   * Handle secret changes from base manager
   */
  private async handleSecretChange(event: SecretsChangeEvent): Promise<void> {
    console.log(`🔔 Secret changed: ${event.key}`);

    // Check if this secret has rotation enabled
    const config = this.rotationConfig.get(event.key);
    if (config?.autoRotate) {
      try {
        // Trigger rotation for the changed secret
        await this.rotateSecretNow(event.key, 'auto-detected-change');
        console.log(`✅ Auto-rotated ${event.key} due to change detection`);
      } catch (error) {
        console.error(`❌ Failed to auto-rotate ${event.key}:`, error);
      }
    }
  }

  /**
   * Shutdown both managers
   */
  shutdown(): void {
    console.log('🔐 Shutting down Enhanced Secrets Manager...');
    this.secretsManager.shutdown();
  }
}

/**
 * Example usage configurations
 */
const EXTENDED_SECRET_CONFIGS: ExtendedSecretConfig[] = [
  // Database credentials with rotation
  {
    key: 'DATABASE_URL',
    required: true,
    validation: { type: 'database_url' },
    rotationInterval: 30,
    autoRotate: true,
    environment: 'production',
    description: 'Production Database Connection String'
  },
  
  // JWT secrets with frequent rotation
  {
    key: 'JWT_SECRET',
    required: true,
    validation: { type: 'jwt_secret' },
    rotationInterval: 7,
    autoRotate: true,
    environment: 'production',
    description: 'JWT Signing Secret'
  },

  // API Keys
  {
    key: 'API_KEY',
    required: false,
    rotationInterval: 60,
    autoRotate: true,
    environment: 'production',
    description: 'External API Access Key'
  },

  // AWS credentials
  {
    key: 'AWS_SECRET_ACCESS_KEY',
    required: false,
    validation: { type: 'aws_secret_key' },
    rotationInterval: 45,
    autoRotate: true,
    environment: 'production',
    description: 'AWS Secret Access Key'
  },

  // SMTP credentials
  {
    key: 'SMTP_PASSWORD',
    required: false,
    rotationInterval: 90,
    autoRotate: true,
    environment: 'production',
    description: 'SMTP Email Password'
  },

  // Non-rotating secrets
  {
    key: 'NODE_ENV',
    required: true,
    description: 'Environment Mode',
    // No rotationInterval = no rotation
  },
  {
    key: 'PORT',
    required: false,
    description: 'Server Port'
    // No rotationInterval = no rotation
  }
];

/**
 * Example 1: Basic Integration
 */
async function basicIntegrationExample() {
  console.log('\n=== Basic Integration Example ===');

  const enhancedManager = new EnhancedSecretsManager(secretsManager);

  try {
    // Initialize with extended configurations
    await enhancedManager.initialize(EXTENDED_SECRET_CONFIGS);

    // Get a secret with rotation info
    const jwtInfo = await enhancedManager.getSecretWithRotationInfo('JWT_SECRET');
    console.log('🔍 JWT Secret Status:');
    console.log(`   Value: ${jwtInfo.value ? '***masked***' : 'not set'}`);
    console.log(`   Next Rotation: ${jwtInfo.rotation.nextRotation?.toISOString()}`);
    console.log(`   Rotation Interval: ${jwtInfo.config?.rotationInterval} days`);

    // Get overall statistics
    const stats = enhancedManager.getRotationStatistics();
    console.log('📊 Rotation Statistics:');
    console.log(`   Total Secrets: ${stats.totalSecrets}`);
    console.log(`   Rotation Events: ${stats.rotationEvents}`);
    console.log(`   Success Rate: ${((stats.successfulRotations / stats.rotationEvents) * 100).toFixed(1)}%`);

  } finally {
    enhancedManager.shutdown();
  }
}

/**
 * Example 2: Monitoring and Alerting
 */
async function monitoringExample() {
  console.log('\n=== Monitoring and Alerting Example ===');

  const enhancedManager = new EnhancedSecretsManager(secretsManager);
  
  try {
    await enhancedManager.initialize(EXTENDED_SECRET_CONFIGS);

    // Set up event monitoring
    eventEmitter.on('rotation_event', (event) => {
      // In production, send to monitoring system (DataDog, New Relic, etc.)
      if (event.status === 'failed') {
        console.error(`🚨 ALERT: Rotation failed for ${event.secretName}`);
        console.error(`   Error: ${event.error}`);
        // Send alert notification
      } else if (event.status === 'success') {
        console.log(`✅ Rotation successful: ${event.secretName}`);
        // Log to monitoring system
      }
    });

    // Simulate some rotations
    console.log('🔄 Simulating manual rotations...');
    await enhancedManager.rotateSecretNow('JWT_SECRET', 'monitoring-test');
    await enhancedManager.rotateSecretNow('API_KEY', 'monitoring-test');

    // Wait a bit for events to process
    await new Promise(resolve => setTimeout(resolve, 2000));

  } finally {
    enhancedManager.shutdown();
  }
}

/**
 * Example 3: Environment-Specific Rotation
 */
async function environmentSpecificExample() {
  console.log('\n=== Environment-Specific Rotation Example ===');

  // Different configurations for different environments
  const devConfigs: ExtendedSecretConfig[] = [
    {
      key: 'DATABASE_URL',
      required: true,
      rotationInterval: 7, // More frequent in dev
      autoRotate: true,
      environment: 'development',
      description: 'Development Database'
    }
  ];

  const prodConfigs: ExtendedSecretConfig[] = [
    {
      key: 'DATABASE_URL',
      required: true,
      rotationInterval: 30, // Less frequent in prod
      autoRotate: true,
      environment: 'production',
      description: 'Production Database'
    }
  ];

  // Initialize for current environment
  const isProduction = process.env.NODE_ENV === 'production';
  const configs = isProduction ? prodConfigs : devConfigs;
  
  console.log(`🌍 Initializing for ${isProduction ? 'production' : 'development'} environment`);

  const enhancedManager = new EnhancedSecretsManager(secretsManager);
  
  try {
    await enhancedManager.initialize(configs);
    
    console.log('✅ Environment-specific rotation configured');

  } finally {
    enhancedManager.shutdown();
  }
}

/**
 * Example 4: Bulk Operations
 */
async function bulkOperationsExample() {
  console.log('\n=== Bulk Operations Example ===');

  const enhancedManager = new EnhancedSecretsManager(secretsManager);
  
  try {
    await enhancedManager.initialize(EXTENDED_SECRET_CONFIGS);

    // Rotate all due secrets
    console.log('🔄 Rotating all due secrets...');
    const rotationEvents = await rotateDueSecrets('bulk-operation');
    
    console.log(`✅ Completed ${rotationEvents.length} rotations:`);
    rotationEvents.forEach(event => {
      console.log(`   ${event.secretName}: ${event.status} (${event.duration}ms)`);
    });

    // Get comprehensive status report
    const stats = enhancedManager.getRotationStatistics();
    console.log('\n📋 Comprehensive Status Report:');
    console.log(`   Secrets in Cache: ${stats.cachedSecrets}`);
    console.log(`   Required Secrets: ${stats.requiredSecrets}`);
    console.log(`   Validated Secrets: ${stats.validatedSecrets}`);
    console.log(`   Total Rotations: ${stats.rotationCount}`);
    console.log(`   Recent Events: ${stats.recentRotations.length}`);

  } finally {
    enhancedManager.shutdown();
  }
}

/**
 * Main execution
 */
async function runIntegrationExamples() {
  console.log('🚀 Starting Secrets Manager + Rotation Integration Examples\n');

  try {
    await basicIntegrationExample();
    await new Promise(resolve => setTimeout(resolve, 1000));

    await monitoringExample();
    await new Promise(resolve => setTimeout(resolve, 1000));

    await environmentSpecificExample();
    await new Promise(resolve => setTimeout(resolve, 1000));

    await bulkOperationsExample();

    console.log('\n✅ All integration examples completed successfully!');
    
  } catch (error) {
    console.error('❌ Integration example failed:', error);
  }
}

// Export for external use
export {
  EnhancedSecretsManager,
  EXTENDED_SECRET_CONFIGS,
  basicIntegrationExample,
  monitoringExample,
  environmentSpecificExample,
  bulkOperationsExample,
  runIntegrationExamples
};

// Run examples if executed directly
if (require.main === module) {
  runIntegrationExamples().catch(console.error);
}
