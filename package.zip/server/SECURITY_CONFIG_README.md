# Security Configuration Documentation

## Overview

The security.config.ts file provides a comprehensive security management system with the following capabilities:

- **Security Settings Management**: Authentication, authorization, and encryption configurations
- **Security Policies**: CORS, CSP, input validation, and password policies
- **Threat Detection**: Pattern matching, behavioral analysis, and anomaly detection
- **Security Monitoring**: Health checks, metrics, and alerting
- **Event Handling**: Security event queuing and processing
- **Best Practices Enforcement**: Automated security checks and compliance reporting
- **Audit Management**: Compliance framework support and violation detection

## Quick Start

### Basic Usage

```typescript
import { SecurityConfigManager, defaultSecurityConfigManager } from './security.config';

// Use the default configuration
const securityManager = defaultSecurityConfigManager;

// Or create a custom configuration
import { SecurityConfigManager, SecurityConfigUtils } from './security.config';

const customConfig = {
  authentication: {
    sessionTimeout: 60,
    requireMFA: true,
    // ... other settings
  }
};

const securityManager = SecurityConfigUtils.createCustomConfig(customConfig);
```

### Security Monitoring

```typescript
// Monitor security events
securityManager.on('securityEvent', (event) => {
  console.log('Security Event:', event);
});

// Get security health metrics
const healthMetrics = securityManager.getSecurityHealthMetrics();
```

### Threat Detection

```typescript
// Analyze input for threats
const threats = securityManager.analyzeThreats(userInput);

// The system will automatically:
- Detect SQL injection attempts
- Identify XSS patterns
- Flag path traversal attempts
- Detect command injection
```

### Event Handling

```typescript
// Create security events
securityManager.createSecurityEvent({
  type: SecurityEventType.AUTHENTICATION_FAILURE,
  severity: 'high',
  source: 'auth-system',
  description: 'Multiple failed login attempts detected',
  metadata: { userId: '123', attempts: 5 }
});
```

## Configuration Components

### 1. Authentication Configuration

```typescript
{
  sessionTimeout: 30, // minutes
  maxLoginAttempts: 5,
  lockoutDuration: 15, // minutes
  requireMFA: true,
  passwordPolicy: {
    minLength: 12,
    requireUppercase: true,
    requireNumbers: true,
    // ... more requirements
  }
}
```

### 2. Threat Detection

The system includes pre-configured threat patterns:

- **SQL Injection**: Detects SQL keywords in input
- **Cross-Site Scripting**: Identifies script tags and malicious patterns
- **Path Traversal**: Detects directory traversal attempts
- **Command Injection**: Identifies command shell operators

### 3. Security Policies

#### Content Security Policy (CSP)
```typescript
{
  defaultSrc: ["'self'"],
  scriptSrc: ["'self'", "'unsafe-inline'"],
  styleSrc: ["'self'", "'unsafe-inline'"],
  // ... more CSP directives
}
```

#### CORS Policy
```typescript
{
  origin: ['https://yourdomain.com'],
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  headers: ['Content-Type', 'Authorization'],
  credentials: true
}
```

### 4. Rate Limiting

```typescript
{
  enabled: true,
  windowMs: 15 * 60 * 1000, // 15 minutes
  maxRequests: 100,
  customLimiters: {
    login: { windowMs: 15 * 60 * 1000, max: 5 },
    api: { windowMs: 60 * 1000, max: 1000 }
  }
}
```

## Security Best Practices

The system automatically enforces best practices:

### Password Security
- Minimum 12 characters
- Complexity requirements (uppercase, lowercase, numbers, special chars)
- Prevents common passwords
- Password expiration policies

### Session Management
- Configurable session timeouts
- Automatic session cleanup
- Multi-factor authentication support

### Data Protection
- Encryption at rest and in transit
- Secure key management
- Data sanitization

### Monitoring & Auditing
- Real-time security event monitoring
- Comprehensive audit logging
- Compliance framework support (SOC2, ISO27001, GDPR)

## Event Types

The system supports these security event types:

- `AUTHENTICATION_FAILURE`
- `AUTHORIZATION_FAILURE`
- `THREAT_DETECTED`
- `ANOMALY_DETECTED`
- `RATE_LIMIT_EXCEEDED`
- `SUSPICIOUS_ACTIVITY`
- `SECURITY_VIOLATION`
- `AUDIT_LOG_EVENT`
- `COMPLIANCE_VIOLATION`
- `DATA_BREACH_ATTEMPT`

## Utilities

### Password Validation

```typescript
const result = SecurityConfigUtils.validatePassword('MyPassword123!');
if (!result.valid) {
  console.log('Password errors:', result.errors);
}
```

### Input Sanitization

```typescript
const sanitized = SecurityConfigUtils.sanitizeInput(userInput, [
  { field: 'email', type: 'email', stripHtml: true, trimWhitespace: true, escapeHtml: true }
]);
```

### Security Headers

```typescript
const securityHeaders = securityManager.getSecurityHeaders();
// Returns headers object ready for HTTP responses
```

### Token Generation

```typescript
const token = SecurityConfigUtils.generateSecurityToken(32);
```

### Entropy Calculation

```typescript
const entropy = SecurityConfigUtils.calculateEntropy('MyComplexPassword123!');
```

## Compliance & Auditing

The system supports multiple compliance frameworks:

- **SOC2**: Automated compliance checks
- **ISO27001**: Security control monitoring
- **GDPR**: Data protection and privacy compliance

### Generate Compliance Report

```typescript
const report = securityManager.enforceBestPractices();
console.log(`Security Score: ${report.score}/100`);
console.log('Issues:', report.issues);
console.log('Recommendations:', report.recommendations);
```

## Configuration Management

### Update Configuration

```typescript
// Update specific sections
securityManager.updateThreatDetection({
  enabled: true,
  sensitivity: 0.8
});

securityManager.updateMonitoring({
  logLevel: 'debug',
  alertingEnabled: true
});
```

### Export Configuration

```typescript
const configJson = securityManager.exportConfig();
// Save to file or external storage
```

### Validate Configuration

```typescript
const validation = securityManager.validateConfig(newConfig);
if (!validation.valid) {
  console.log('Configuration errors:', validation.errors);
}
```

## Integration Examples

### Express.js Middleware

```typescript
import { Request, Response, NextFunction } from 'express';

export const securityMiddleware = (req: Request, res: Response, next: NextFunction) => {
  // Apply security headers
  const headers = securityManager.getSecurityHeaders();
  Object.entries(headers).forEach(([key, value]) => {
    res.setHeader(key, value);
  });

  // Check rate limiting
  const rateLimitResult = securityManager.checkRateLimit(req.ip, 'api');
  if (!rateLimitResult.allowed) {
    return res.status(429).json({ error: 'Rate limit exceeded' });
  }

  // Analyze requests for threats
  const threats = securityManager.analyzeThreats(JSON.stringify(req.body));
  if (threats.length > 0) {
    // Log and potentially block
    securityManager.createSecurityEvent({
      type: SecurityEventType.THREAT_DETECTED,
      severity: 'high',
      source: 'request-analysis',
      description: 'Threat detected in request',
      metadata: { threats }
    });
  }

  next();
};
```

### Health Check Endpoint

```typescript
app.get('/health/security', (req, res) => {
  const metrics = securityManager.getSecurityHealthMetrics();
  res.json({
    status: 'healthy',
    metrics,
    timestamp: new Date()
  });
});
```

## Best Practices Recommendations

Based on the security configuration, the system provides recommendations:

1. **Enable MFA**: Require multi-factor authentication for all users
2. **Strengthen Passwords**: Use 12+ character passwords with complexity
3. **Short Sessions**: Keep session timeouts under 30 minutes
4. **Encrypt Everything**: Enable encryption at rest and in transit
5. **Monitor Continuously**: Enable real-time monitoring and alerting
6. **Regular Audits**: Perform regular security audits and compliance checks
7. **Patch Regularly**: Keep dependencies updated
8. **Least Privilege**: Implement role-based access control

## Support

For issues or questions about the security configuration:

1. Check the configuration validation results
2. Review the security audit logs
3. Monitor the security dashboard
4. Consult the compliance reports

The security configuration is designed to be enterprise-ready and can be extended to meet specific organizational requirements.