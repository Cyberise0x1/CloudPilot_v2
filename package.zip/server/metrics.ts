/**
 * Comprehensive Metrics Tracking System
 * Supports Prometheus format with real-time monitoring
 */

import { performance } from 'perf_hooks';
import { EventEmitter } from 'events';

// ============================================================================
// Types and Interfaces
// ============================================================================

export interface MetricLabels {
  [key: string]: string | number;
}

export interface CounterMetric {
  name: string;
  help: string;
  value: number;
  labels?: MetricLabels;
  timestamp: number;
}

export interface GaugeMetric {
  name: string;
  help: string;
  value: number;
  labels?: MetricLabels;
  timestamp: number;
}

export interface HistogramMetric {
  name: string;
  help: string;
  buckets: Record<string, number>;
  sum: number;
  count: number;
  labels?: MetricLabels;
  timestamp: number;
}

export interface RequestMetrics {
  method: string;
  path: string;
  statusCode: number;
  duration: number;
  timestamp: number;
  userAgent?: string;
  ip?: string;
  userId?: string;
}

export interface BusinessMetrics {
  user_registrations: number;
  user_logins: number;
  api_calls: number;
  db_queries: number;
  cache_hits: number;
  cache_misses: number;
  file_uploads: number;
  emails_sent: number;
  errors_total: number;
  successful_operations: number;
}

export interface SystemMetrics {
  memory: {
    used: number;
    total: number;
    percentage: number;
    heapUsed: number;
    heapTotal: number;
    external: number;
  };
  cpu: {
    usage: number;
    loadAverage: number[];
  };
  activeConnections: number;
  uptime: number;
  eventLoopLag: number;
}

export interface DashboardData {
  timestamp: number;
  realTimeMetrics: {
    requestsPerSecond: number;
    averageResponseTime: number;
    errorRate: number;
    activeConnections: number;
    memoryUsage: number;
  };
  aggregatedMetrics: {
    totalRequests: number;
    totalErrors: number;
    averageResponseTime: number;
    p95ResponseTime: number;
    p99ResponseTime: number;
    requestRateByEndpoint: Record<string, number>;
    errorRateByEndpoint: Record<string, number>;
    topErrors: Array<{ error: string; count: number }>;
  };
  systemMetrics: SystemMetrics;
  businessMetrics: BusinessMetrics;
}

// ============================================================================
// Metrics Collector Classes
// ============================================================================

export class Counter {
  private value: number = 0;
  private labels: MetricLabels;

  constructor(
    public name: string,
    public help: string,
    labels: MetricLabels = {}
  ) {
    this.labels = labels;
  }

  inc(value: number = 1, labels?: MetricLabels): void {
    this.value += value;
  }

  reset(): void {
    this.value = 0;
  }

  getValue(): number {
    return this.value;
  }

  getMetrics(): CounterMetric {
    return {
      name: this.name,
      help: this.help,
      value: this.value,
      labels: this.labels,
      timestamp: Date.now()
    };
  }

  toPrometheus(): string {
    return `# HELP ${this.name} ${this.help}
# TYPE ${this.name} counter
${this.name}{${Object.entries(this.labels).map(([k, v]) => `${k}="${v}"`).join(',')}} ${this.value}`;
  }
}

export class Gauge {
  private value: number;
  private labels: MetricLabels;

  constructor(
    public name: string,
    public help: string,
    initialValue: number = 0,
    labels: MetricLabels = {}
  ) {
    this.value = initialValue;
    this.labels = labels;
  }

  set(value: number, labels?: MetricLabels): void {
    this.value = value;
  }

  inc(value: number = 1): void {
    this.value += value;
  }

  dec(value: number = 1): void {
    this.value -= value;
  }

  getValue(): number {
    return this.value;
  }

  getMetrics(): GaugeMetric {
    return {
      name: this.name,
      help: this.help,
      value: this.value,
      labels: this.labels,
      timestamp: Date.now()
    };
  }

  toPrometheus(): string {
    return `# HELP ${this.name} ${this.help}
# TYPE ${this.name} gauge
${this.name}{${Object.entries(this.labels).map(([k, v]) => `${k}="${v}"`).join(',')}} ${this.value}`;
  }
}

export class Histogram {
  private buckets: Map<number, number> = new Map();
  private sum: number = 0;
  private count: number = 0;
  private labels: MetricLabels;

  constructor(
    public name: string,
    public help: string,
    public buckets: number[] = [0.1, 0.3, 0.5, 0.7, 1, 3, 5, 7, 10],
    labels: MetricLabels = {}
  ) {
    this.labels = labels;
    // Initialize buckets
    buckets.forEach(bucket => this.buckets.set(bucket, 0));
    this.buckets.set(+Infinity, 0);
  }

  observe(value: number, labels?: MetricLabels): void {
    this.count++;
    this.sum += value;
    
    // Update buckets
    for (const bucket of this.buckets.keys()) {
      if (value <= bucket) {
        this.buckets.set(bucket, this.buckets.get(bucket)! + 1);
      }
    }
  }

  getQuantile(quantile: number): number {
    if (this.count === 0) return 0;
    
    const target = quantile * this.count;
    let cumulative = 0;
    
    for (const [bucket, count] of this.buckets.entries()) {
      cumulative += count;
      if (cumulative >= target) {
        return bucket;
      }
    }
    
    return Array.from(this.buckets.keys()).pop() || 0;
  }

  getMetrics(): HistogramMetric {
    const buckets: Record<string, number> = {};
    this.buckets.forEach((value, key) => {
      buckets[key.toString()] = value;
    });

    return {
      name: this.name,
      help: this.help,
      buckets,
      sum: this.sum,
      count: this.count,
      labels: this.labels,
      timestamp: Date.now()
    };
  }

  toPrometheus(): string {
    const lines: string[] = [];
    
    lines.push(`# HELP ${this.name} ${this.help}`);
    lines.push(`# TYPE ${this.name} histogram`);
    
    const labelStr = Object.entries(this.labels).map(([k, v]) => `${k}="${v}"`).join(',');
    
    // Bucket metrics
    this.buckets.forEach((count, bucket) => {
      lines.push(`${name}_bucket{${labelStr},le="${bucket}"} ${count}`);
    });
    
    // +Inf bucket
    lines.push(`${this.name}_bucket{${labelStr},le="+Inf"} ${this.buckets.get(+Infinity)}`);
    
    // Count and sum
    lines.push(`${this.name}_count{${labelStr}} ${this.count}`);
    lines.push(`${this.name}_sum{${labelStr}} ${this.sum}`);
    
    return lines.join('\n');
  }
}

// ============================================================================
// Main Metrics Collector
// ============================================================================

export class MetricsCollector extends EventEmitter {
  // Core metrics
  private counters: Map<string, Counter> = new Map();
  private gauges: Map<string, Gauge> = new Map();
  private histograms: Map<string, Histogram> = new Map();
  
  // Request tracking
  private requestMetrics: RequestMetrics[] = [];
  private maxRequestMetrics: number = 10000;
  
  // Aggregation windows
  private aggregationWindows = [60, 300, 900, 3600]; // 1m, 5m, 15m, 1h
  private aggregatedData: Map<number, any> = new Map();
  
  // System monitoring
  private systemMetricsInterval?: NodeJS.Timer;
  private collectionInterval: number = 10000; // 10 seconds

  constructor() {
    super();
    this.initializeMetrics();
    this.startSystemMonitoring();
  }

  private initializeMetrics(): void {
    // Request metrics
    this.counters.set('http_requests_total', new Counter(
      'http_requests_total',
      'Total number of HTTP requests',
      { method: '', status: '' }
    ));

    this.histograms.set('http_request_duration_seconds', new Histogram(
      'http_request_duration_seconds',
      'HTTP request duration in seconds',
      [0.1, 0.3, 0.5, 0.7, 1, 3, 5, 7, 10]
    ));

    // Error metrics
    this.counters.set('http_errors_total', new Counter(
      'http_errors_total',
      'Total number of HTTP errors',
      { status: '', endpoint: '' }
    ));

    // AWS operations
    this.counters.set('aws_operations_total', new Counter(
      'aws_operations_total',
      'Total number of AWS operations',
      { service: '', operation: '', status: '' }
    ));

    this.histograms.set('aws_operation_duration_seconds', new Histogram(
      'aws_operation_duration_seconds',
      'AWS operation duration in seconds',
      [0.1, 0.5, 1, 2, 5, 10, 30]
    ));

    // System metrics
    this.gauges.set('memory_usage_bytes', new Gauge(
      'memory_usage_bytes',
      'Memory usage in bytes'
    ));

    this.gauges.set('active_connections', new Gauge(
      'active_connections',
      'Number of active connections'
    ));

    this.gauges.set('cpu_usage_percent', new Gauge(
      'cpu_usage_percent',
      'CPU usage percentage'
    ));

    this.gauges.set('uptime_seconds', new Gauge(
      'uptime_seconds',
      'Application uptime in seconds'
    ));

    // Business metrics
    this.counters.set('user_registrations_total', new Counter(
      'user_registrations_total',
      'Total number of user registrations'
    ));

    this.counters.set('user_logins_total', new Counter(
      'user_logins_total',
      'Total number of user logins'
    ));

    this.counters.set('api_calls_total', new Counter(
      'api_calls_total',
      'Total number of API calls'
    ));

    this.counters.set('db_queries_total', new Counter(
      'db_queries_total',
      'Total number of database queries'
    ));

    this.counters.set('cache_hits_total', new Counter(
      'cache_hits_total',
      'Total number of cache hits'
    ));

    this.counters.set('cache_misses_total', new Counter(
      'cache_misses_total',
      'Total number of cache misses'
    ));
  }

  // HTTP Request Metrics
  trackRequest(
    method: string,
    path: string,
    statusCode: number,
    duration: number,
    userAgent?: string,
    ip?: string,
    userId?: string
  ): void {
    const metric: RequestMetrics = {
      method,
      path,
      statusCode,
      duration,
      timestamp: Date.now(),
      userAgent,
      ip,
      userId
    };

    this.requestMetrics.push(metric);
    if (this.requestMetrics.length > this.maxRequestMetrics) {
      this.requestMetrics.shift();
    }

    // Update counters
    const requestCounter = this.counters.get('http_requests_total')!;
    requestCounter.inc(1, { method, status: statusCode.toString() });

    if (statusCode >= 400) {
      const errorCounter = this.counters.get('http_errors_total')!;
      errorCounter.inc(1, { status: statusCode.toString(), endpoint: path });
    }

    // Update histograms
    const durationHistogram = this.histograms.get('http_request_duration_seconds')!;
    durationHistogram.observe(duration);

    // Update active connections gauge
    const activeConnections = this.gauges.get('active_connections')!;
    activeConnections.set(this.getActiveConnections());

    // Emit real-time metric
    this.emit('request', metric);
  }

  // AWS Operations
  trackAwsOperation(
    service: string,
    operation: string,
    duration: number,
    status: 'success' | 'error' = 'success'
  ): void {
    const counter = this.counters.get('aws_operations_total')!;
    counter.inc(1, { service, operation, status });

    const histogram = this.histograms.get('aws_operation_duration_seconds')!;
    histogram.observe(duration);

    this.emit('aws_operation', { service, operation, duration, status });
  }

  // Business Metrics
  trackUserRegistration(): void {
    const counter = this.counters.get('user_registrations_total')!;
    counter.inc();
    this.emit('business_event', { type: 'user_registration' });
  }

  trackUserLogin(): void {
    const counter = this.counters.get('user_logins_total')!;
    counter.inc();
    this.emit('business_event', { type: 'user_login' });
  }

  trackApiCall(): void {
    const counter = this.counters.get('api_calls_total')!;
    counter.inc();
    this.emit('business_event', { type: 'api_call' });
  }

  trackDbQuery(): void {
    const counter = this.counters.get('db_queries_total')!;
    counter.inc();
  }

  trackCacheHit(): void {
    const counter = this.counters.get('cache_hits_total')!;
    counter.inc();
  }

  trackCacheMiss(): void {
    const counter = this.counters.get('cache_misses_total')!;
    counter.inc();
  }

  // System Monitoring
  private startSystemMonitoring(): void {
    this.systemMetricsInterval = setInterval(() => {
      this.collectSystemMetrics();
    }, this.collectionInterval);

    this.collectSystemMetrics(); // Initial collection
  }

  private collectSystemMetrics(): void {
    const memUsage = process.memoryUsage();
    const systemMem = require('os').freemem();
    const totalMem = require('os').totalmem();

    // Update memory gauges
    const memoryGauge = this.gauges.get('memory_usage_bytes')!;
    memoryGauge.set(memUsage.heapUsed);

    // Calculate CPU usage
    const startUsage = process.cpuUsage();
    setTimeout(() => {
      const endUsage = process.cpuUsage();
      const cpuPercent = ((endUsage.user - startUsage.user) / 1000000) * 100;
      
      const cpuGauge = this.gauges.get('cpu_usage_percent')!;
      cpuGauge.set(Math.min(cpuPercent, 100));
    }, 100);

    // Update uptime
    const uptimeGauge = this.gauges.get('uptime_seconds')!;
    uptimeGauge.set(process.uptime());

    // Emit system metrics
    const systemMetrics: SystemMetrics = {
      memory: {
        used: memUsage.heapUsed,
        total: totalMem,
        percentage: (memUsage.heapUsed / totalMem) * 100,
        heapUsed: memUsage.heapUsed,
        heapTotal: memUsage.heapTotal,
        external: memUsage.external
      },
      cpu: {
        usage: 0, // Will be updated asynchronously
        loadAverage: require('os').loadavg()
      },
      activeConnections: this.getActiveConnections(),
      uptime: process.uptime(),
      eventLoopLag: this.measureEventLoopLag()
    };

    this.emit('system_metrics', systemMetrics);
  }

  private measureEventLoopLag(): number {
    const start = performance.now();
    setImmediate(() => {
      // This will be called in the next event loop iteration
    });
    return performance.now() - start;
  }

  private getActiveConnections(): number {
    // Placeholder for actual connection tracking
    // This would integrate with your server's connection pool
    return Math.floor(Math.random() * 100); // Mock data
  }

  // Aggregation Methods
  aggregateMetrics(windowSeconds: number): void {
    const cutoffTime = Date.now() - (windowSeconds * 1000);
    const windowMetrics = this.requestMetrics.filter(m => m.timestamp >= cutoffTime);

    const aggregated = {
      window: windowSeconds,
      totalRequests: windowMetrics.length,
      totalErrors: windowMetrics.filter(m => m.statusCode >= 400).length,
      avgResponseTime: windowMetrics.length > 0 
        ? windowMetrics.reduce((sum, m) => sum + m.duration, 0) / windowMetrics.length 
        : 0,
      p95ResponseTime: this.calculatePercentile(windowMetrics.map(m => m.duration), 0.95),
      p99ResponseTime: this.calculatePercentile(windowMetrics.map(m => m.duration), 0.99),
      requestRate: windowMetrics.length / windowSeconds,
      errorRate: windowMetrics.filter(m => m.statusCode >= 400).length / windowSeconds,
      endpoints: this.aggregateByEndpoint(windowMetrics)
    };

    this.aggregatedData.set(windowSeconds, aggregated);
    this.emit('aggregated_metrics', { window: windowSeconds, data: aggregated });
  }

  private calculatePercentile(values: number[], percentile: number): number {
    if (values.length === 0) return 0;
    
    const sorted = values.sort((a, b) => a - b);
    const index = Math.ceil(sorted.length * percentile) - 1;
    return sorted[index] || 0;
  }

  private aggregateByEndpoint(metrics: RequestMetrics[]): Record<string, any> {
    const endpoints: Record<string, any> = {};
    
    metrics.forEach(metric => {
      if (!endpoints[metric.path]) {
        endpoints[metric.path] = {
          count: 0,
          errors: 0,
          totalDuration: 0,
          methods: new Set()
        };
      }
      
      endpoints[metric.path].count++;
      endpoints[metric.path].totalDuration += metric.duration;
      if (metric.statusCode >= 400) {
        endpoints[metric.path].errors++;
      }
      endpoints[metric.path].methods.add(metric.method);
    });

    // Convert to final format
    Object.keys(endpoints).forEach(endpoint => {
      const data = endpoints[endpoint];
      endpoints[endpoint] = {
        count: data.count,
        errorRate: data.errors / data.count,
        avgResponseTime: data.totalDuration / data.count,
        methods: Array.from(data.methods)
      };
    });

    return endpoints;
  }

  // Dashboard Data
  getDashboardData(): DashboardData {
    const now = Date.now();
    
    // Get aggregated data for all windows
    const aggregated = {
      totalRequests: 0,
      totalErrors: 0,
      averageResponseTime: 0,
      p95ResponseTime: 0,
      p99ResponseTime: 0,
      requestRateByEndpoint: {},
      errorRateByEndpoint: {},
      topErrors: []
    };

    // Use the 5-minute window for aggregated metrics
    const fiveMinData = this.aggregatedData.get(300);
    if (fiveMinData) {
      Object.assign(aggregated, fiveMinData);
    }

    // Calculate real-time metrics (last 60 seconds)
    const recentCutoff = now - 60000;
    const recentMetrics = this.requestMetrics.filter(m => m.timestamp >= recentCutoff);

    const realTimeMetrics = {
      requestsPerSecond: recentMetrics.length / 60,
      averageResponseTime: recentMetrics.length > 0
        ? recentMetrics.reduce((sum, m) => sum + m.duration, 0) / recentMetrics.length
        : 0,
      errorRate: recentMetrics.filter(m => m.statusCode >= 400).length / recentMetrics.length,
      activeConnections: this.getActiveConnections(),
      memoryUsage: process.memoryUsage().heapUsed
    };

    // Get current system metrics
    const systemMetrics: SystemMetrics = {
      memory: {
        used: process.memoryUsage().heapUsed,
        total: require('os').totalmem(),
        percentage: (process.memoryUsage().heapUsed / require('os').totalmem()) * 100,
        heapUsed: process.memoryUsage().heapUsed,
        heapTotal: process.memoryUsage().heapTotal,
        external: process.memoryUsage().external
      },
      cpu: {
        usage: 0, // Would need more sophisticated measurement
        loadAverage: require('os').loadavg()
      },
      activeConnections: this.getActiveConnections(),
      uptime: process.uptime(),
      eventLoopLag: 0 // Would need to be measured separately
    };

    // Get business metrics
    const businessMetrics: BusinessMetrics = {
      user_registrations: this.counters.get('user_registrations_total')?.getValue() || 0,
      user_logins: this.counters.get('user_logins_total')?.getValue() || 0,
      api_calls: this.counters.get('api_calls_total')?.getValue() || 0,
      db_queries: this.counters.get('db_queries_total')?.getValue() || 0,
      cache_hits: this.counters.get('cache_hits_total')?.getValue() || 0,
      cache_misses: this.counters.get('cache_misses_total')?.getValue() || 0,
      file_uploads: 0, // Add custom counter if needed
      emails_sent: 0, // Add custom counter if needed
      errors_total: this.counters.get('http_errors_total')?.getValue() || 0,
      successful_operations: this.counters.get('http_requests_total')?.getValue() || 0
    };

    return {
      timestamp: now,
      realTimeMetrics,
      aggregatedMetrics: aggregated,
      systemMetrics,
      businessMetrics
    };
  }

  // Prometheus Export
  toPrometheus(): string {
    const lines: string[] = [];
    
    // Add timestamp comment
    lines.push(`# Generated at ${new Date().toISOString()}`);
    lines.push('');

    // Add all metrics
    this.counters.forEach(counter => {
      lines.push(counter.toPrometheus());
      lines.push('');
    });

    this.gauges.forEach(gauge => {
      lines.push(gauge.toPrometheus());
      lines.push('');
    });

    this.histograms.forEach(histogram => {
      lines.push(histogram.toPrometheus());
      lines.push('');
    });

    return lines.join('\n');
  }

  // Utility Methods
  getMetric(name: string): Counter | Gauge | Histogram | undefined {
    return this.counters.get(name) || this.gauges.get(name) || this.histograms.get(name);
  }

  resetAllMetrics(): void {
    this.counters.forEach(counter => counter.reset());
    this.gauges.forEach(gauge => gauge.set(0));
    this.histograms.forEach(histogram => {
      // Reset histogram by recreating it
      const newHistogram = new Histogram(
        histogram.name,
        histogram.help,
        histogram.buckets,
        histogram.labels
      );
      this.histograms.set(histogram.name, newHistogram);
    });
    this.requestMetrics = [];
    this.aggregatedData.clear();
  }

  destroy(): void {
    if (this.systemMetricsInterval) {
      clearInterval(this.systemMetricsInterval);
    }
    this.removeAllListeners();
  }
}

// ============================================================================
// Global Instance and Exports
// ============================================================================

// Global metrics collector instance
export const metrics = new MetricsCollector();

// Auto-aggregate metrics periodically
setInterval(() => {
  metrics.aggregateMetrics(60);   // 1 minute
  metrics.aggregateMetrics(300);  // 5 minutes
  metrics.aggregateMetrics(900);  // 15 minutes
  metrics.aggregateMetrics(3600); // 1 hour
}, 30000); // Every 30 seconds

// Utility functions for easy metric tracking
export const trackRequest = (
  method: string,
  path: string,
  statusCode: number,
  duration: number,
  userAgent?: string,
  ip?: string,
  userId?: string
) => {
  metrics.trackRequest(method, path, statusCode, duration, userAgent, ip, userId);
};

export const trackAwsOperation = (
  service: string,
  operation: string,
  duration: number,
  status: 'success' | 'error' = 'success'
) => {
  metrics.trackAwsOperation(service, operation, duration, status);
};

export const trackBusinessEvent = {
  userRegistration: () => metrics.trackUserRegistration(),
  userLogin: () => metrics.trackUserLogin(),
  apiCall: () => metrics.trackApiCall(),
  dbQuery: () => metrics.trackDbQuery(),
  cacheHit: () => metrics.trackCacheHit(),
  cacheMiss: () => metrics.trackCacheMiss()
};

// Express middleware for automatic request tracking
export const metricsMiddleware = (req: any, res: any, next: any) => {
  const start = Date.now();
  
  res.on('finish', () => {
    const duration = (Date.now() - start) / 1000; // Convert to seconds
    metrics.trackRequest(
      req.method,
      req.path,
      res.statusCode,
      duration,
      req.get('user-agent'),
      req.ip,
      req.user?.id
    );
  });
  
  next();
};

// Health check endpoint data
export const getHealthMetrics = () => {
  const dashboardData = metrics.getDashboardData();
  return {
    status: 'healthy',
    uptime: dashboardData.systemMetrics.uptime,
    memoryUsage: dashboardData.systemMetrics.memory.percentage,
    activeConnections: dashboardData.systemMetrics.activeConnections,
    errorRate: dashboardData.realTimeMetrics.errorRate,
    timestamp: dashboardData.timestamp
  };
};

// Cleanup on process exit
process.on('SIGTERM', () => {
  metrics.destroy();
});

process.on('SIGINT', () => {
  metrics.destroy();
});

export default metrics;
