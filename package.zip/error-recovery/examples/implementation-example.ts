/**
 * Example Implementation of Error Recovery System
 * 
 * This file demonstrates how to use the Error Recovery System in a real-world
 * application with Express.js, monitoring integration, and database handling.
 */

import express, { Request, Response, NextFunction } from 'express';
import { 
  ErrorRecoverySystem,
  createErrorRecoverySystem,
  defaultRecoveryConfig,
  ErrorSeverity,
  ErrorCategory
} from './index';

// Example Express.js application with error recovery integration
class ApplicationWithErrorRecovery {
  private app: express.Application;
  private recoverySystem: ErrorRecoverySystem;

  constructor() {
    this.app = express();
    this.recoverySystem = createErrorRecoverySystem({
      ...defaultRecoveryConfig,
      enableTesting: true,
      maxAutomationTime: 180000, // 3 minutes
      notificationChannels: ['slack', 'email']
    });
  }

  async initialize(): Promise<void> {
    // Initialize error recovery system
    await this.recoverySystem.initialize();

    // Set up middleware
    this.setupMiddleware();

    // Set up routes
    this.setupRoutes();

    // Set up error handlers
    this.setupErrorHandling();

    // Start background services
    this.startBackgroundServices();

    console.log('Application with Error Recovery initialized successfully');
  }

  private setupMiddleware(): void {
    // Request ID middleware
    this.app.use((req, res, next) => {
      const requestId = req.headers['x-request-id'] || `req-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      (req as any).requestId = requestId;
      res.setHeader('X-Request-ID', requestId);
      next();
    });

    // Health check endpoint
    this.app.get('/health', (req, res) => {
      const status = this.recoverySystem.getSystemStatus();
      res.json({
        status: 'healthy',
        system: status,
        timestamp: new Date().toISOString()
      });
    });

    // Error recovery status endpoint
    this.app.get('/recovery/status', (req, res) => {
      const status = this.recoverySystem.getSystemStatus();
      res.json(status);
    });

    // Test recovery endpoint (for testing purposes)
    this.app.post('/recovery/test', async (req, res) => {
      try {
        const testType = req.body.testType || 'integration';
        const results = await this.recoverySystem.runRecoveryTests({ testType });
        res.json({
          success: true,
          testRunIds: results.testRunIds,
          summary: results.summary
        });
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });

    // Execute disaster recovery drill
    this.app.post('/recovery/drill', async (req, res) => {
      try {
        const drillConfig = req.body;
        const result = await this.recoverySystem.executeDrill(drillConfig);
        res.json(result);
      } catch (error) {
        res.status(500).json({
          success: false,
          error: error.message
        });
      }
    });
  }

  private setupRoutes(): void {
    // User service routes
    this.app.get('/users/:id', this.asyncHandler(async (req, res) => {
      const userId = req.params.id;
      const user = await this.getUserFromDatabase(userId);
      res.json(user);
    }));

    this.app.post('/users', this.asyncHandler(async (req, res) => {
      const userData = req.body;
      const user = await this.createUser(userData);
      res.status(201).json(user);
    }));

    // Payment service routes
    this.app.post('/payments', this.asyncHandler(async (req, res) => {
      const paymentData = req.body;
      const payment = await this.processPayment(paymentData);
      res.json(payment);
    }));

    // Product service routes
    this.app.get('/products', this.asyncHandler(async (req, res) => {
      const products = await this.getProducts();
      res.json(products);
    }));

    this.app.post('/orders', this.asyncHandler(async (req, res) => {
      const orderData = req.body;
      const order = await this.createOrder(orderData);
      res.json(order);
    }));

    // Analytics endpoint
    this.app.get('/analytics/recovery', this.asyncHandler(async (req, res) => {
      const period = (req.query.period as any) || 'day';
      const analytics = await this.recoverySystem.getAnalytics(period);
      res.json(analytics);
    }));
  }

  private setupErrorHandling(): void {
    // Global error handling middleware
    this.app.use(async (error: Error, req: Request, res: Response, next: NextFunction) => {
      try {
        console.error('Unhandled error:', {
          error: error.message,
          stack: error.stack,
          requestId: (req as any).requestId,
          url: req.url,
          method: req.method,
          timestamp: new Date().toISOString()
        });

        // Process error through recovery system
        const result = await this.recoverySystem.processError(error, {
          timestamp: new Date(),
          source: 'express-application',
          component: this.extractComponentFromPath(req.path),
          environment: process.env.NODE_ENV || 'development',
          context: {
            requestId: (req as any).requestId,
            url: req.url,
            method: req.method,
            headers: req.headers,
            body: req.body,
            params: req.params,
            query: req.query,
            userAgent: req.get('User-Agent'),
            ip: req.ip
          }
        });

        // Log recovery processing result
        console.log('Error processed through recovery system:', {
          sessionId: result.sessionId,
          classification: result.classification,
          notificationsSent: result.notifications?.length || 0
        });

        // Determine appropriate HTTP status code
        const statusCode = this.determineHttpStatusCode(error);

        // Send error response
        res.status(statusCode).json({
          error: {
            message: this.getErrorMessage(error),
            code: this.getErrorCode(error),
            requestId: (req as any).requestId,
            recoverySession: result.sessionId,
            timestamp: new Date().toISOString()
          }
        });

      } catch (recoveryError) {
        console.error('Failed to process error through recovery system:', recoveryError);

        // Fallback error response
        res.status(500).json({
          error: {
            message: 'Internal server error',
            code: 'INTERNAL_ERROR',
            requestId: (req as any).requestId,
            timestamp: new Date().toISOString()
          }
        });
      }
    });

    // 404 handler
    this.app.use('*', (req, res) => {
      res.status(404).json({
        error: {
          message: 'Route not found',
          code: 'NOT_FOUND',
          path: req.originalUrl,
          method: req.method,
          requestId: (req as any).requestId,
          timestamp: new Date().toISOString()
        }
      });
    });
  }

  private startBackgroundServices(): void {
    // Monitor system health
    setInterval(() => {
      this.monitorSystemHealth();
    }, 30000); // Every 30 seconds

    // Perform periodic cleanup
    setInterval(() => {
      this.performPeriodicCleanup();
    }, 3600000); // Every hour

    // Run scheduled recovery tests
    setInterval(() => {
      this.runScheduledTests();
    }, 86400000); // Daily

    // Process monitoring alerts
    this.setupMonitoringIntegration();
  }

  // Example service methods with error handling
  private async getUserFromDatabase(userId: string): Promise<any> {
    try {
      // Simulate database call
      await this.simulateDatabaseOperation('read', 'users', { id: userId });
      
      // Simulate user data
      return {
        id: userId,
        name: 'John Doe',
        email: 'john@example.com',
        createdAt: new Date()
      };
    } catch (error) {
      // Let the error propagate to be handled by global error handler
      throw new Error(`Failed to fetch user ${userId}: ${error.message}`);
    }
  }

  private async createUser(userData: any): Promise<any> {
    try {
      // Validate user data
      if (!userData.email || !userData.name) {
        throw new Error('Invalid user data: email and name are required');
      }

      // Simulate database operation
      await this.simulateDatabaseOperation('write', 'users', userData);

      // Simulate external service call
      await this.simulateExternalServiceCall('user-creation', userData);

      return {
        id: `user-${Date.now()}`,
        ...userData,
        createdAt: new Date()
      };
    } catch (error) {
      throw new Error(`Failed to create user: ${error.message}`);
    }
  }

  private async processPayment(paymentData: any): Promise<any> {
    try {
      // Validate payment data
      if (!paymentData.amount || !paymentData.currency || !paymentData.userId) {
        throw new Error('Invalid payment data: amount, currency, and userId are required');
      }

      // Simulate payment processing
      await this.simulateExternalServiceCall('payment-processing', paymentData);

      // Simulate database update
      await this.simulateDatabaseOperation('write', 'payments', paymentData);

      return {
        id: `payment-${Date.now()}`,
        status: 'completed',
        amount: paymentData.amount,
        currency: paymentData.currency,
        processedAt: new Date()
      };
    } catch (error) {
      // Categorize payment errors as high severity
      if (error.message.includes('payment')) {
        const categorizedError = new Error(`Payment processing failed: ${error.message}`);
        (categorizedError as any).severity = ErrorSeverity.HIGH;
        throw categorizedError;
      }
      throw error;
    }
  }

  private async getProducts(): Promise<any[]> {
    try {
      // Simulate database operation
      await this.simulateDatabaseOperation('read', 'products');
      
      return [
        { id: 1, name: 'Product 1', price: 29.99 },
        { id: 2, name: 'Product 2', price: 39.99 },
        { id: 3, name: 'Product 3', price: 49.99 }
      ];
    } catch (error) {
      throw new Error(`Failed to fetch products: ${error.message}`);
    }
  }

  private async createOrder(orderData: any): Promise<any> {
    try {
      if (!orderData.userId || !orderData.items || !Array.isArray(orderData.items)) {
        throw new Error('Invalid order data');
      }

      // Simulate order creation
      await this.simulateDatabaseOperation('write', 'orders', orderData);

      // Simulate inventory update
      for (const item of orderData.items) {
        await this.simulateDatabaseOperation('update', 'inventory', item);
      }

      return {
        id: `order-${Date.now()}`,
        ...orderData,
        status: 'created',
        createdAt: new Date()
      };
    } catch (error) {
      throw new Error(`Failed to create order: ${error.message}`);
    }
  }

  // Simulation methods for demonstration
  private async simulateDatabaseOperation(operation: string, table: string, data?: any): Promise<void> {
    // Simulate potential database errors
    const errorProbability = Math.random();
    
    if (errorProbability < 0.05) { // 5% chance of error
      const errors = [
        'Connection timeout',
        'Database connection refused',
        'Query execution timeout',
        'Deadlock detected',
        'Insufficient privileges'
      ];
      throw new Error(`Database ${operation} failed: ${errors[Math.floor(Math.random() * errors.length)]}`);
    }

    // Simulate operation delay
    await new Promise(resolve => setTimeout(resolve, Math.random() * 100));
  }

  private async simulateExternalServiceCall(service: string, data: any): Promise<void> {
    // Simulate potential external service errors
    const errorProbability = Math.random();
    
    if (errorProbability < 0.03) { // 3% chance of error
      const errors = [
        'Service unavailable',
        'Request timeout',
        'Rate limit exceeded',
        'Invalid API key',
        'Service temporarily unavailable'
      ];
      throw new Error(`${service} failed: ${errors[Math.floor(Math.random() * errors.length)]}`);
    }

    // Simulate operation delay
    await new Promise(resolve => setTimeout(resolve, Math.random() * 200));
  }

  // Monitoring and maintenance methods
  private async monitorSystemHealth(): Promise<void> {
    try {
      const status = this.recoverySystem.getSystemStatus();
      
      if (status.status === 'unhealthy') {
        console.warn('System health degraded:', {
          status: status.status,
          activeRecoveries: status.activeRecoveries,
          availability: status.metrics.overall.systemAvailability
        });
      }
    } catch (error) {
      console.error('Failed to monitor system health:', error);
    }
  }

  private async performPeriodicCleanup(): Promise<void> {
    try {
      // Perform cleanup of temporary data, logs, etc.
      console.log('Performing periodic cleanup...');
      
      // Simulate cleanup operations
      await this.simulateCleanup();
    } catch (error) {
      console.error('Periodic cleanup failed:', error);
    }
  }

  private async runScheduledTests(): Promise<void> {
    try {
      console.log('Running scheduled recovery tests...');
      
      const results = await this.recoverySystem.runRecoveryTests({
        testType: 'integration',
        category: 'database'
      });
      
      console.log('Scheduled tests completed:', results.summary);
    } catch (error) {
      console.error('Scheduled tests failed:', error);
    }
  }

  private async simulateCleanup(): Promise<void> {
    // Simulate cleanup operations
    await new Promise(resolve => setTimeout(resolve, 1000));
  }

  private setupMonitoringIntegration(): void {
    // Simulate monitoring system integration
    console.log('Setting up monitoring integration...');
    
    // In a real implementation, you would:
    // 1. Connect to your monitoring system (e.g., Datadog, New Relic, etc.)
    // 2. Listen for alerts and events
    // 3. Process them through the recovery system
    
    // Example: Listen for alerts
    process.on('SIGUSR2', async () => { // Simulated alert signal
      const alert = {
        severity: 'critical',
        service: 'payment-service',
        message: 'High error rate detected',
        timestamp: new Date(),
        metadata: { errorRate: 0.15 }
      };

      try {
        await this.processMonitoringAlert(alert);
      } catch (error) {
        console.error('Failed to process monitoring alert:', error);
      }
    });
  }

  private async processMonitoringAlert(alert: any): Promise<void> {
    console.log('Processing monitoring alert:', alert);
    
    const error = new Error(`Monitoring alert: ${alert.message}`);
    
    const result = await this.recoverySystem.processError(error, {
      timestamp: alert.timestamp,
      source: 'monitoring-system',
      component: alert.service,
      environment: process.env.NODE_ENV || 'production',
      context: alert.metadata
    });

    console.log('Alert processed:', result.sessionId);
  }

  // Utility methods
  private extractComponentFromPath(path: string): string {
    const components = {
      '/users': 'user-service',
      '/payments': 'payment-service',
      '/products': 'product-service',
      '/orders': 'order-service'
    };

    for (const [routePattern, component] of Object.entries(components)) {
      if (path.startsWith(routePattern)) {
        return component;
      }
    }

    return 'unknown';
  }

  private determineHttpStatusCode(error: Error): number {
    if (error.message.includes('validation') || error.message.includes('Invalid')) {
      return 400;
    }
    if (error.message.includes('not found')) {
      return 404;
    }
    if (error.message.includes('unauthorized') || error.message.includes('permission')) {
      return 403;
    }
    if (error.message.includes('timeout')) {
      return 408;
    }
    if (error.message.includes('rate limit')) {
      return 429;
    }
    if (error.message.includes('database') || error.message.includes('connection')) {
      return 503;
    }
    
    return 500;
  }

  private getErrorMessage(error: Error): string {
    // Don't expose internal error details in production
    if (process.env.NODE_ENV === 'production') {
      return 'An internal error occurred';
    }
    return error.message;
  }

  private getErrorCode(error: Error): string {
    if (error.message.includes('validation')) return 'VALIDATION_ERROR';
    if (error.message.includes('database')) return 'DATABASE_ERROR';
    if (error.message.includes('timeout')) return 'TIMEOUT_ERROR';
    if (error.message.includes('payment')) return 'PAYMENT_ERROR';
    if (error.message.includes('unauthorized')) return 'AUTHORIZATION_ERROR';
    
    return 'INTERNAL_ERROR';
  }

  private asyncHandler(fn: Function) {
    return (req: Request, res: Response, next: NextFunction) => {
      Promise.resolve(fn(req, res, next)).catch(next);
    };
  }

  // Start the application
  async start(port: number = 3000): Promise<void> {
    await this.initialize();
    
    this.app.listen(port, () => {
      console.log(`Application with Error Recovery listening on port ${port}`);
      console.log('Health check available at: http://localhost:' + port + '/health');
      console.log('Recovery status available at: http://localhost:' + port + '/recovery/status');
    });
  }

  // Graceful shutdown
  async shutdown(): Promise<void> {
    console.log('Shutting down application...');
    await this.recoverySystem.shutdown();
    process.exit(0);
  }
}

// Example usage
async function main() {
  const app = new ApplicationWithErrorRecovery();
  
  // Handle graceful shutdown
  process.on('SIGTERM', () => app.shutdown());
  process.on('SIGINT', () => app.shutdown());
  
  try {
    await app.start(3000);
  } catch (error) {
    console.error('Failed to start application:', error);
    process.exit(1);
  }
}

// Example test scenarios
class ErrorRecoveryTester {
  constructor(private app: ApplicationWithErrorRecovery) {}

  async testErrorScenarios(): Promise<void> {
    console.log('Testing error recovery scenarios...\n');

    // Test 1: Database connection error
    console.log('1. Testing database connection error...');
    await this.simulateErrorScenario({
      path: '/users/user123',
      method: 'GET',
      expectedError: 'Database connection failed'
    });

    // Test 2: Payment service error
    console.log('\n2. Testing payment service error...');
    await this.simulateErrorScenario({
      path: '/payments',
      method: 'POST',
      body: { amount: 100, currency: 'USD', userId: 'user123' },
      expectedError: 'Payment processing failed'
    });

    // Test 3: High error rate scenario
    console.log('\n3. Simulating high error rate (monitoring alert)...');
    process.kill(process.pid, 'SIGUSR2'); // Trigger simulated alert

    // Test 4: Run recovery test
    console.log('\n4. Running recovery test...');
    await this.testRecoveryProcedures();
  }

  private async simulateErrorScenario(scenario: {
    path: string;
    method: string;
    body?: any;
    expectedError?: string;
  }): Promise<void> {
    try {
      // In a real test, you would make HTTP requests to your application
      console.log(`Simulating ${scenario.method} ${scenario.path}`);
      
      // For demonstration, we'll just log the scenario
      console.log('This would trigger the error recovery system');
      console.log('Expected behavior:', scenario.expectedError);
      
    } catch (error) {
      console.log('Error scenario completed:', error.message);
    }
  }

  private async testRecoveryProcedures(): Promise<void> {
    try {
      const results = await this.app['recoverySystem'].runRecoveryTests({
        testType: 'integration'
      });
      
      console.log('Recovery test results:', results.summary);
    } catch (error) {
      console.log('Recovery test failed:', error.message);
    }
  }
}

// Run the example if this file is executed directly
if (require.main === module) {
  main().catch(console.error);
}

export { ApplicationWithErrorRecovery, ErrorRecoveryTester };
