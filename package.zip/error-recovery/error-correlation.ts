/**
 * Error Correlation and Analysis System
 * 
 * This module provides advanced error correlation, pattern analysis, and
 * predictive capabilities to improve error recovery and prevention.
 */

import { ErrorInstance, ErrorCategory, ErrorSeverity } from './error-classification';

export interface ErrorEvent {
  id: string;
  error: ErrorInstance;
  timestamp: Date;
  source: string;
  context: Record<string, any>;
  correlations: string[]; // IDs of related events
  cluster?: string; // Cluster ID for related events
  trend?: TrendAnalysis;
}

export interface CorrelationRule {
  id: string;
  name: string;
  description: string;
  conditions: CorrelationCondition[];
  relationship: 'causal' | 'concurrent' | 'sequential' | 'similar';
  confidence: number; // 0-1
  timeWindow?: number; // milliseconds
  enabled: boolean;
  lastMatched?: Date;
  matchCount: number;
}

export interface CorrelationCondition {
  field: string;
  operator: 'equals' | 'contains' | 'regex' | 'greater_than' | 'less_than' | 'in';
  value: any;
  weight: number;
}

export interface ClusterAnalysis {
  clusterId: string;
  errors: ErrorEvent[];
  pattern: ErrorPattern;
  frequency: number;
  firstOccurrence: Date;
  lastOccurrence: Date;
  averageInterval: number; // milliseconds
  impact: ClusterImpact;
  recommendedActions: string[];
}

export interface ErrorPattern {
  type: 'recurring' | 'burst' | 'progressive' | 'seasonal' | 'random';
  description: string;
  characteristics: Record<string, any>;
  predictability: number; // 0-1
  seasonality?: SeasonalPattern;
}

export interface SeasonalPattern {
  type: 'hourly' | 'daily' | 'weekly' | 'monthly';
  peakHours?: number[];
  peakDays?: string[];
  trend: 'increasing' | 'decreasing' | 'stable';
}

export interface ClusterImpact {
  userImpact: number; // 0-10 scale
  businessImpact: number; // 0-10 scale
  systemImpact: number; // 0-10 scale
  frequency: number; // occurrences per time period
  duration: number; // average duration in milliseconds
  escalationRate: number; // percentage
}

export interface TrendAnalysis {
  direction: 'increasing' | 'decreasing' | 'stable';
  slope: number; // rate of change
  confidence: number; // 0-1
  prediction: TrendPrediction;
}

export interface TrendPrediction {
  nextWeekForecast: number;
  nextMonthForecast: number;
  seasonalAdjustment: number;
  anomalyScore: number; // 0-1
}

export interface RootCauseAnalysis {
  eventId: string;
  confidence: number; // 0-1
  rootCauses: RootCause[];
  evidence: AnalysisEvidence[];
  recommendedFixes: RecommendedFix[];
  preventedBy: PreventionMeasure[];
}

export interface RootCause {
  category: string;
  description: string;
  likelihood: number; // 0-1
  impact: number; // 0-1
  evidence: string[];
}

export interface AnalysisEvidence {
  type: 'log-pattern' | 'metrics-correlation' | 'code-analysis' | 'infrastructure-change';
  description: string;
  confidence: number; // 0-1
  data: Record<string, any>;
}

export interface RecommendedFix {
  type: 'code-change' | 'configuration' | 'infrastructure' | 'process';
  description: string;
  priority: 'low' | 'medium' | 'high' | 'critical';
  effort: 'low' | 'medium' | 'high';
  impact: 'low' | 'medium' | 'high';
  estimatedTime: number; // hours
}

export interface PreventionMeasure {
  type: 'monitoring' | 'alert' | 'circuit-breaker' | 'retry-logic' | 'rate-limiting';
  description: string;
  implementation: string;
  effectiveness: number; // 0-1
}

export interface AnomalyDetection {
  type: 'statistical' | 'machine-learning' | 'rule-based';
  algorithm: string;
  parameters: Record<string, any>;
  baseline: AnomalyBaseline;
  threshold: number;
}

export interface AnomalyBaseline {
  mean: number;
  stdDev: number;
  percentiles: Record<string, number>;
  seasonality: Record<string, number>;
}

export interface AnomalyAlert {
  id: string;
  timestamp: Date;
  type: 'error-rate' | 'response-time' | 'resource-usage' | 'custom';
  severity: ErrorSeverity;
  score: number; // 0-1
  baseline: number;
  current: number;
  deviation: number; // percentage
  description: string;
  relatedEvents: string[];
}

export class ErrorCorrelationAnalyzer {
  private events: Map<string, ErrorEvent> = new Map();
  private correlationRules: Map<string, CorrelationRule> = new Map();
  private clusters: Map<string, ClusterAnalysis> = new Map();
  private baselines: Map<string, AnomalyBaseline> = new Map();
  private anomalyDetectors: Map<string, AnomalyDetection> = new Map();

  constructor() {
    this.initializeDefaultRules();
    this.initializeBaselineMetrics();
    this.initializeAnomalyDetectors();
  }

  async analyzeError(error: ErrorInstance): Promise<{
    correlations: ErrorEvent[];
    clusters: ClusterAnalysis[];
    patterns: ErrorPattern[];
    anomalies: AnomalyAlert[];
    rootCause?: RootCauseAnalysis;
  }> {
    const event = await this.createErrorEvent(error);
    this.events.set(event.id, event);

    // Find correlations
    const correlations = await this.findCorrelations(event);

    // Analyze clusters
    const clusters = await this.analyzeClusters(event);

    // Detect patterns
    const patterns = await this.detectPatterns(event);

    // Check for anomalies
    const anomalies = await this.detectAnomalies(event);

    // Perform root cause analysis if significant
    let rootCause: RootCauseAnalysis | undefined;
    if (this.isSignificantError(error)) {
      rootCause = await this.performRootCauseAnalysis(event);
    }

    return {
      correlations,
      clusters,
      patterns,
      anomalies,
      rootCause
    };
  }

  private async createErrorEvent(error: ErrorInstance): Promise<ErrorEvent> {
    return {
      id: this.generateEventId(error),
      error,
      timestamp: error.metadata.timestamp,
      source: error.metadata.source,
      context: error.metadata.context,
      correlations: []
    };
  }

  private async findCorrelations(event: ErrorEvent): Promise<ErrorEvent[]> {
    const correlations: ErrorEvent[] = [];
    const timeWindow = 300000; // 5 minutes

    for (const [eventId, otherEvent] of this.events.entries()) {
      if (eventId === event.id) continue;

      // Check temporal correlation
      const timeDiff = Math.abs(event.timestamp.getTime() - otherEvent.timestamp.getTime());
      if (timeDiff > timeWindow) continue;

      // Check rule-based correlations
      for (const rule of this.correlationRules.values()) {
        if (!rule.enabled) continue;

        const correlation = await this.evaluateCorrelation(event, otherEvent, rule);
        if (correlation.confidence > 0.5) {
          correlations.push(otherEvent);
          event.correlations.push(otherEvent.id);
          
          if (!rule.lastMatched) {
            rule.lastMatched = new Date();
          }
          rule.matchCount++;
          break;
        }
      }
    }

    return correlations;
  }

  private async evaluateCorrelation(
    event1: ErrorEvent,
    event2: ErrorEvent,
    rule: CorrelationRule
  ): Promise<{ confidence: number; relationship: string }> {
    let totalWeight = 0;
    let matchedWeight = 0;

    for (const condition of rule.conditions) {
      const event1Value = this.getFieldValue(event1, condition.field);
      const event2Value = this.getFieldValue(event2, condition.field);

      totalWeight += condition.weight;

      if (this.evaluateCondition(event1Value, event2Value, condition)) {
        matchedWeight += condition.weight;
      }
    }

    const confidence = totalWeight > 0 ? (matchedWeight / totalWeight) * rule.confidence : 0;
    
    return {
      confidence,
      relationship: rule.relationship
    };
  }

  private evaluateCondition(value1: any, value2: any, condition: CorrelationCondition): boolean {
    switch (condition.operator) {
      case 'equals':
        return value1 === value2;
      case 'contains':
        return String(value1).includes(String(value2));
      case 'regex':
        return new RegExp(condition.value).test(String(value1));
      case 'greater_than':
        return Number(value1) > Number(value2);
      case 'less_than':
        return Number(value1) < Number(value2);
      case 'in':
        return Array.isArray(condition.value) && condition.value.includes(value1);
      default:
        return false;
    }
  }

  private getFieldValue(event: ErrorEvent, field: string): any {
    const parts = field.split('.');
    let value: any = event;

    for (const part of parts) {
      if (part === 'error') value = value.error;
      else if (part === 'metadata') value = value.metadata;
      else if (part === 'category') value = value.error.category;
      else if (part === 'severity') value = value.error.severity;
      else if (part === 'component') value = value.error.metadata.component;
      else if (part === 'source') value = value.source;
      else if (part === 'timestamp') value = value.timestamp;
      else value = value[part];
    }

    return value;
  }

  private async analyzeClusters(event: ErrorEvent): Promise<ClusterAnalysis[]> {
    const relevantClusters: ClusterAnalysis[] = [];

    for (const [clusterId, cluster] of this.clusters.entries()) {
      if (this.belongsToCluster(event, cluster)) {
        // Update cluster
        cluster.errors.push(event);
        cluster.frequency++;
        cluster.lastOccurrence = event.timestamp;

        // Recalculate pattern
        cluster.pattern = await this.calculatePattern(cluster.errors);

        // Update impact
        cluster.impact = await this.calculateClusterImpact(cluster.errors);

        relevantClusters.push(cluster);
      } else {
        // Check if this should create a new cluster
        const similarErrors = await this.findSimilarErrors(event);
        if (similarErrors.length >= 3) {
          // Create new cluster
          const newCluster = await this.createCluster([event, ...similarErrors]);
          this.clusters.set(newCluster.clusterId, newCluster);
          relevantClusters.push(newCluster);
        }
      }
    }

    return relevantClusters;
  }

  private belongsToCluster(event: ErrorEvent, cluster: ClusterAnalysis): boolean {
    // Check if event belongs to existing cluster based on similarity
    return cluster.errors.some(existingEvent => 
      this.calculateSimilarity(event, existingEvent) > 0.7
    );
  }

  private async findSimilarErrors(event: ErrorEvent): Promise<ErrorEvent[]> {
    const similar: ErrorEvent[] = [];
    const timeWindow = 3600000; // 1 hour

    for (const [eventId, otherEvent] of this.events.entries()) {
      if (eventId === event.id) continue;

      const timeDiff = Math.abs(event.timestamp.getTime() - otherEvent.timestamp.getTime());
      if (timeDiff > timeWindow) continue;

      const similarity = this.calculateSimilarity(event, otherEvent);
      if (similarity > 0.7) {
        similar.push(otherEvent);
      }
    }

    return similar;
  }

  private calculateSimilarity(event1: ErrorEvent, event2: ErrorEvent): number {
    let similarity = 0;
    let factors = 0;

    // Category similarity
    if (event1.error.category === event2.error.category) {
      similarity += 0.3;
    }
    factors += 0.3;

    // Severity similarity
    if (event1.error.severity === event2.error.severity) {
      similarity += 0.2;
    }
    factors += 0.2;

    // Component similarity
    if (event1.error.metadata.component === event2.error.metadata.component) {
      similarity += 0.2;
    }
    factors += 0.2;

    // Source similarity
    if (event1.source === event2.source) {
      similarity += 0.1;
    }
    factors += 0.1;

    // Message similarity (simplified)
    const messageSimilarity = this.calculateStringSimilarity(
      event1.error.message,
      event2.error.message
    );
    similarity += messageSimilarity * 0.2;
    factors += 0.2;

    return similarity / factors;
  }

  private calculateStringSimilarity(str1: string, str2: string): number {
    const longer = str1.length > str2.length ? str1 : str2;
    const shorter = str1.length > str2.length ? str2 : str1;
    
    if (longer.length === 0) return 1.0;
    
    const editDistance = this.levenshteinDistance(longer, shorter);
    return (longer.length - editDistance) / longer.length;
  }

  private levenshteinDistance(str1: string, str2: string): number {
    const matrix = Array(str2.length + 1).fill(null).map(() => Array(str1.length + 1).fill(null));

    for (let i = 0; i <= str1.length; i++) matrix[0][i] = i;
    for (let j = 0; j <= str2.length; j++) matrix[j][0] = j;

    for (let j = 1; j <= str2.length; j++) {
      for (let i = 1; i <= str1.length; i++) {
        const indicator = str1[i - 1] === str2[j - 1] ? 0 : 1;
        matrix[j][i] = Math.min(
          matrix[j][i - 1] + 1,
          matrix[j - 1][i] + 1,
          matrix[j - 1][i - 1] + indicator
        );
      }
    }

    return matrix[str2.length][str1.length];
  }

  private async createCluster(errors: ErrorEvent[]): Promise<ClusterAnalysis> {
    const clusterId = this.generateClusterId();
    const pattern = await this.calculatePattern(errors);
    const impact = await this.calculateClusterImpact(errors);

    return {
      clusterId,
      errors: [...errors],
      pattern,
      frequency: errors.length,
      firstOccurrence: errors[0].timestamp,
      lastOccurrence: errors[errors.length - 1].timestamp,
      averageInterval: this.calculateAverageInterval(errors),
      impact,
      recommendedActions: this.generateRecommendations(pattern, impact)
    };
  }

  private async calculatePattern(errors: ErrorEvent[]): Promise<ErrorPattern> {
    // Analyze error patterns
    const intervals = this.calculateIntervals(errors);
    const frequency = this.calculateFrequency(intervals);
    const consistency = this.calculateConsistency(intervals);

    let type: ErrorPattern['type'] = 'random';
    let predictability = 0;

    if (consistency > 0.8) {
      type = 'recurring';
      predictability = consistency;
    } else if (this.isBurstPattern(intervals)) {
      type = 'burst';
      predictability = 0.6;
    } else if (this.isProgressivePattern(intervals)) {
      type = 'progressive';
      predictability = 0.7;
    } else if (this.isSeasonalPattern(errors)) {
      type = 'seasonal';
      predictability = 0.8;
    }

    return {
      type,
      description: `Pattern: ${type} with ${Math.round(predictability * 100)}% predictability`,
      characteristics: {
        frequency,
        consistency,
        intervals: intervals.slice(0, 10) // Store first 10 intervals
      },
      predictability,
      seasonality: this.calculateSeasonality(errors)
    };
  }

  private async calculateClusterImpact(errors: ErrorEvent[]): Promise<ClusterImpact> {
    const severities = errors.map(e => e.error.severity);
    const avgSeverity = this.calculateAverageSeverity(severities);
    
    const userImpact = this.calculateUserImpact(errors);
    const businessImpact = this.calculateBusinessImpact(errors);
    const systemImpact = this.calculateSystemImpact(errors);

    const timeSpan = errors[errors.length - 1].timestamp.getTime() - errors[0].timestamp.getTime();
    const frequency = errors.length / (timeSpan / (1000 * 60 * 60 * 24)); // errors per day

    return {
      userImpact,
      businessImpact,
      systemImpact,
      frequency,
      duration: this.calculateAverageDuration(errors),
      escalationRate: this.calculateEscalationRate(errors)
    };
  }

  private async detectPatterns(event: ErrorEvent): Promise<ErrorPattern[]> {
    const patterns: ErrorPattern[] = [];

    // Check for recent similar errors
    const recentErrors = this.getRecentErrors(event.timestamp, 3600000); // 1 hour
    const similarErrors = recentErrors.filter(e => 
      this.calculateSimilarity(event, e) > 0.8
    );

    if (similarErrors.length >= 3) {
      const pattern = await this.calculatePattern([event, ...similarErrors]);
      patterns.push(pattern);
    }

    // Check for temporal patterns
    const hourlyPattern = this.detectHourlyPattern(event.timestamp);
    if (hourlyPattern) patterns.push(hourlyPattern);

    return patterns;
  }

  private async detectAnomalies(event: ErrorEvent): Promise<AnomalyAlert[]> {
    const alerts: AnomalyAlert[] = [];

    for (const [metricName, detector] of this.anomalyDetectors.entries()) {
      const currentValue = this.getMetricValue(event, metricName);
      if (currentValue === undefined) continue;

      const baseline = this.baselines.get(metricName);
      if (!baseline) continue;

      const anomalyScore = this.calculateAnomalyScore(currentValue, baseline, detector);
      
      if (anomalyScore > detector.threshold) {
        alerts.push({
          id: this.generateAlertId(),
          timestamp: event.timestamp,
          type: detector.type as any,
          severity: this.mapSeverityFromScore(anomalyScore),
          score: anomalyScore,
          baseline: baseline.mean,
          current: currentValue,
          deviation: ((currentValue - baseline.mean) / baseline.mean) * 100,
          description: `Anomaly detected in ${metricName}: ${anomalyScore.toFixed(2)}`,
          relatedEvents: [event.id]
        });
      }
    }

    return alerts;
  }

  private async performRootCauseAnalysis(event: ErrorEvent): Promise<RootCauseAnalysis> {
    const evidence: AnalysisEvidence[] = [];
    const rootCauses: RootCause[] = [];
    const recommendedFixes: RecommendedFix[] = [];
    const preventedBy: PreventionMeasure[] = [];

    // Analyze based on error characteristics
    if (event.error.category === ErrorCategory.DATABASE) {
      rootCauses.push({
        category: 'Configuration',
        description: 'Database connection pool exhaustion',
        likelihood: 0.8,
        impact: 0.9,
        evidence: ['Connection timeout messages', 'High connection count']
      });

      recommendedFixes.push({
        type: 'configuration',
        description: 'Increase database connection pool size',
        priority: 'high',
        effort: 'low',
        impact: 'high',
        estimatedTime: 1
      });

      preventedBy.push({
        type: 'monitoring',
        description: 'Monitor database connection pool usage',
        implementation: 'Add connection pool metrics to monitoring dashboard',
        effectiveness: 0.9
      });
    }

    if (event.error.category === ErrorCategory.PERFORMANCE) {
      rootCauses.push({
        category: 'Code',
        description: 'Inefficient database queries causing slow response times',
        likelihood: 0.7,
        impact: 0.8,
        evidence: ['Slow query logs', 'High CPU usage patterns']
      });

      recommendedFixes.push({
        type: 'code-change',
        description: 'Optimize slow database queries and add database indexes',
        priority: 'medium',
        effort: 'medium',
        impact: 'high',
        estimatedTime: 8
      });
    }

    // Collect evidence
    evidence.push({
      type: 'log-pattern',
      description: 'Error pattern analysis',
      confidence: 0.8,
      data: {
        errorType: event.error.category,
        frequency: this.getRecentErrorCount(event.error.category),
        pattern: 'recurring'
      }
    });

    return {
      eventId: event.id,
      confidence: 0.7,
      rootCauses,
      evidence,
      recommendedFixes,
      preventedBy
    };
  }

  private isSignificantError(error: ErrorInstance): boolean {
    return error.severity === ErrorSeverity.CRITICAL || 
           error.severity === ErrorSeverity.HIGH ||
           error.category === ErrorCategory.SECURITY;
  }

  // Utility methods
  private generateEventId(error: ErrorInstance): string {
    return `event-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private generateClusterId(): string {
    return `cluster-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private generateAlertId(): string {
    return `alert-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private getRecentErrors(timestamp: Date, timeWindow: number): ErrorEvent[] {
    const cutoff = timestamp.getTime() - timeWindow;
    return Array.from(this.events.values()).filter(event => 
      event.timestamp.getTime() >= cutoff
    );
  }

  private calculateIntervals(errors: ErrorEvent[]): number[] {
    const sorted = errors.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
    const intervals: number[] = [];

    for (let i = 1; i < sorted.length; i++) {
      intervals.push(sorted[i].timestamp.getTime() - sorted[i - 1].timestamp.getTime());
    }

    return intervals;
  }

  private calculateAverageInterval(errors: ErrorEvent[]): number {
    const intervals = this.calculateIntervals(errors);
    return intervals.length > 0 ? intervals.reduce((a, b) => a + b, 0) / intervals.length : 0;
  }

  private calculateFrequency(intervals: number[]): number {
    if (intervals.length === 0) return 0;
    const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
    return 1000 * 60 * 60 / avgInterval; // events per hour
  }

  private calculateConsistency(intervals: number[]): number {
    if (intervals.length < 2) return 0;
    
    const mean = intervals.reduce((a, b) => a + b, 0) / intervals.length;
    const variance = intervals.reduce((sum, interval) => sum + Math.pow(interval - mean, 2), 0) / intervals.length;
    const stdDev = Math.sqrt(variance);
    
    return Math.max(0, 1 - (stdDev / mean));
  }

  private isBurstPattern(intervals: number[]): boolean {
    if (intervals.length < 3) return false;
    
    const shortIntervals = intervals.filter(i => i < 60000).length; // Less than 1 minute
    return shortIntervals / intervals.length > 0.7;
  }

  private isProgressivePattern(intervals: number[]): boolean {
    if (intervals.length < 3) return false;
    
    let increasing = 0;
    let decreasing = 0;
    
    for (let i = 1; i < intervals.length; i++) {
      if (intervals[i] > intervals[i - 1]) increasing++;
      else if (intervals[i] < intervals[i - 1]) decreasing++;
    }
    
    return (increasing / (intervals.length - 1)) > 0.7 || (decreasing / (intervals.length - 1)) > 0.7;
  }

  private isSeasonalPattern(errors: ErrorEvent[]): boolean {
    // Simplified seasonal pattern detection
    const hourlyCounts = new Array(24).fill(0);
    
    errors.forEach(event => {
      const hour = event.timestamp.getHours();
      hourlyCounts[hour]++;
    });
    
    const maxCount = Math.max(...hourlyCounts);
    const avgCount = hourlyCounts.reduce((a, b) => a + b, 0) / hourlyCounts.length;
    
    return maxCount > avgCount * 3;
  }

  private calculateSeasonality(errors: ErrorEvent[]): SeasonalPattern | undefined {
    const hourlyCounts = new Array(24).fill(0);
    
    errors.forEach(event => {
      const hour = event.timestamp.getHours();
      hourlyCounts[hour]++;
    });
    
    const peakHours = hourlyCounts
      .map((count, hour) => ({ hour, count }))
      .filter(item => item.count > 0)
      .sort((a, b) => b.count - a.count)
      .slice(0, 3)
      .map(item => item.hour);
    
    if (peakHours.length === 0) return undefined;
    
    return {
      type: 'hourly',
      peakHours,
      trend: 'stable'
    };
  }

  private detectHourlyPattern(timestamp: Date): ErrorPattern | undefined {
    const hour = timestamp.getHours();
    const recentErrors = this.getRecentErrors(timestamp, 24 * 60 * 60 * 1000); // 24 hours
    
    const sameHourErrors = recentErrors.filter(e => e.timestamp.getHours() === hour);
    
    if (sameHourErrors.length >= 5) {
      return {
        type: 'seasonal',
        description: `Recurring errors at ${hour}:00 hour`,
        characteristics: {
          peakHour: hour,
          frequency: sameHourErrors.length / 24
        },
        predictability: 0.6
      };
    }
    
    return undefined;
  }

  private getMetricValue(event: ErrorEvent, metricName: string): number | undefined {
    // Map event properties to metrics
    switch (metricName) {
      case 'error_rate':
        return 1;
      case 'response_time':
        return event.context.responseTime;
      case 'cpu_usage':
        return event.context.cpuUsage;
      case 'memory_usage':
        return event.context.memoryUsage;
      default:
        return undefined;
    }
  }

  private calculateAnomalyScore(value: number, baseline: AnomalyBaseline, detector: AnomalyDetection): number {
    const zScore = Math.abs(value - baseline.mean) / baseline.stdDev;
    
    // Apply seasonality adjustment if available
    let adjustedZScore = zScore;
    if (baseline.seasonality && detector.parameters.hour !== undefined) {
      const seasonalAdjustment = baseline.seasonality[detector.parameters.hour.toString()] || 1;
      adjustedZScore = zScore / seasonalAdjustment;
    }
    
    return Math.min(1, adjustedZScore / 3); // Normalize to 0-1
  }

  private mapSeverityFromScore(score: number): ErrorSeverity {
    if (score > 0.8) return ErrorSeverity.CRITICAL;
    if (score > 0.6) return ErrorSeverity.HIGH;
    if (score > 0.4) return ErrorSeverity.MEDIUM;
    return ErrorSeverity.LOW;
  }

  private calculateAverageSeverity(severities: ErrorSeverity[]): number {
    const severityValues = {
      [ErrorSeverity.CRITICAL]: 5,
      [ErrorSeverity.HIGH]: 4,
      [ErrorSeverity.MEDIUM]: 3,
      [ErrorSeverity.LOW]: 2,
      [ErrorSeverity.INFO]: 1
    };
    
    const sum = severities.reduce((acc, severity) => acc + severityValues[severity], 0);
    return sum / severities.length;
  }

  private calculateUserImpact(errors: ErrorEvent[]): number {
    const criticalComponents = ['auth', 'payment', 'user-service', 'api-gateway'];
    const relevantErrors = errors.filter(e => 
      criticalComponents.includes(e.error.metadata.component)
    );
    
    return relevantErrors.length / errors.length * 10;
  }

  private calculateBusinessImpact(errors: ErrorEvent[]): number {
    const securityErrors = errors.filter(e => e.error.category === ErrorCategory.SECURITY).length;
    const paymentErrors = errors.filter(e => e.error.metadata.component === 'payment').length;
    
    return (securityErrors + paymentErrors) / errors.length * 10;
  }

  private calculateSystemImpact(errors: ErrorEvent[]): number {
    const infrastructureErrors = errors.filter(e => 
      e.error.category === ErrorCategory.INFRASTRUCTURE
    ).length;
    
    return infrastructureErrors / errors.length * 10;
  }

  private calculateAverageDuration(errors: ErrorEvent[]): number {
    // Simplified duration calculation
    return 5 * 60 * 1000; // 5 minutes average
  }

  private calculateEscalationRate(errors: ErrorEvent[]): number {
    const escalatedErrors = errors.filter(e => e.error.escalationRequired).length;
    return escalatedErrors / errors.length * 100;
  }

  private getRecentErrorCount(category: ErrorCategory): number {
    const oneHourAgo = Date.now() - (60 * 60 * 1000);
    return Array.from(this.events.values()).filter(e => 
      e.error.category === category && 
      e.timestamp.getTime() >= oneHourAgo
    ).length;
  }

  private generateRecommendations(pattern: ErrorPattern, impact: ClusterImpact): string[] {
    const recommendations: string[] = [];
    
    if (pattern.type === 'recurring' && pattern.predictability > 0.7) {
      recommendations.push('Implement proactive monitoring for this recurring pattern');
      recommendations.push('Consider automated remediation for this error type');
    }
    
    if (impact.frequency > 10) {
      recommendations.push('High frequency error - prioritize fixing root cause');
    }
    
    if (impact.escalationRate > 50) {
      recommendations.push('High escalation rate - improve automated recovery procedures');
    }
    
    return recommendations;
  }

  private initializeDefaultRules(): void {
    // Database connection error correlation
    this.correlationRules.set('db-connection-chain', {
      id: 'db-connection-chain',
      name: 'Database Connection Chain',
      description: 'Errors that occur in sequence due to database connection issues',
      conditions: [
        { field: 'error.category', operator: 'equals', value: 'database', weight: 0.5 },
        { field: 'error.message', operator: 'contains', value: 'connection', weight: 0.3 },
        { field: 'metadata.component', operator: 'equals', value: 'database', weight: 0.2 }
      ],
      relationship: 'sequential',
      confidence: 0.8,
      timeWindow: 300000, // 5 minutes
      enabled: true,
      matchCount: 0
    });

    // Infrastructure error correlation
    this.correlationRules.set('infrastructure-cascade', {
      id: 'infrastructure-cascade',
      name: 'Infrastructure Cascade Failure',
      description: 'Infrastructure errors that cause cascading failures',
      conditions: [
        { field: 'error.category', operator: 'equals', value: 'infrastructure', weight: 0.4 },
        { field: 'error.severity', operator: 'in', value: ['critical', 'high'], weight: 0.3 },
        { field: 'metadata.component', operator: 'equals', value: 'load-balancer', weight: 0.3 }
      ],
      relationship: 'causal',
      confidence: 0.9,
      timeWindow: 120000, // 2 minutes
      enabled: true,
      matchCount: 0
    });
  }

  private initializeBaselineMetrics(): void {
    // Initialize baseline metrics for anomaly detection
    this.baselines.set('error_rate', {
      mean: 10,
      stdDev: 3,
      percentiles: {
        p50: 8,
        p90: 14,
        p95: 16,
        p99: 20
      },
      seasonality: {
        '0': 0.5, '1': 0.3, '2': 0.2, '3': 0.2, '4': 0.3, '5': 0.4,
        '6': 0.8, '7': 1.2, '8': 1.5, '9': 1.8, '10': 2.0, '11': 1.9,
        '12': 2.1, '13': 2.0, '14': 1.8, '15': 1.6, '16': 1.4, '17': 1.3,
        '18': 1.1, '19': 0.9, '20': 0.8, '21': 0.7, '22': 0.6, '23': 0.5
      }
    });

    this.baselines.set('response_time', {
      mean: 200,
      stdDev: 50,
      percentiles: {
        p50: 180,
        p90: 250,
        p95: 300,
        p99: 400
      },
      seasonality: {}
    });
  }

  private initializeAnomalyDetectors(): void {
    this.anomalyDetectors.set('error_rate', {
      type: 'statistical',
      algorithm: 'z_score',
      parameters: {},
      baseline: this.baselines.get('error_rate')!,
      threshold: 0.7
    });

    this.anomalyDetectors.set('response_time', {
      type: 'statistical',
      algorithm: 'z_score',
      parameters: {},
      baseline: this.baselines.get('response_time')!,
      threshold: 0.8
    });
  }
}

export const errorCorrelationAnalyzer = new ErrorCorrelationAnalyzer();
