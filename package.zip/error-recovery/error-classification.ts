/**
 * Error Classification and Severity Assessment System
 * 
 * This module provides comprehensive error classification, severity assessment,
 * and routing capabilities for automated and manual recovery workflows.
 */

export enum ErrorSeverity {
  CRITICAL = 'critical',      // Immediate action required, service down
  HIGH = 'high',             // Significant impact, degradation
  MEDIUM = 'medium',         // Moderate impact, workarounds available
  LOW = 'low',               // Minor impact, can be addressed in normal schedule
  INFO = 'info'              // Informational, no immediate action needed
}

export enum ErrorCategory {
  INFRASTRUCTURE = 'infrastructure',     // Network, hardware, cloud services
  APPLICATION = 'application',           // Code bugs, logic errors
  DATABASE = 'database',                 // DB connectivity, query issues
  SECURITY = 'security',                 // Auth failures, permission issues
  PERFORMANCE = 'performance',           // Slow response, resource exhaustion
  DEPENDENCY = 'dependency',             // External service failures
  DATA = 'data',                         // Data corruption, inconsistency
  USER = 'user',                         // User input validation errors
  SYSTEM = 'system'                      // Operating system, system resource issues
}

export enum ErrorStatus {
  DETECTED = 'detected',
  ASSESSING = 'assessing',
  CLASSIFIED = 'classified',
  IN_RECOVERY = 'in_recovery',
  RECOVERED = 'recovered',
  FAILED_RECOVERY = 'failed_recovery',
  ESCALATED = 'escalated',
  RESOLVED = 'resolved'
}

export interface ErrorMetadata {
  timestamp: Date;
  source: string;
  component: string;
  environment: 'development' | 'staging' | 'production';
  userId?: string;
  requestId?: string;
  sessionId?: string;
  correlationId?: string;
  stackTrace?: string;
  context: Record<string, any>;
}

export interface ErrorInstance extends Error {
  name: string;
  message: string;
  severity: ErrorSeverity;
  category: ErrorCategory;
  status: ErrorStatus;
  metadata: ErrorMetadata;
  retryable: boolean;
  autoRecoverable: boolean;
  escalationRequired: boolean;
}

export interface ClassificationRule {
  pattern: RegExp | ((error: Error) => boolean);
  category: ErrorCategory;
  severity: ErrorSeverity;
  retryable: boolean;
  autoRecoverable: boolean;
  escalationRequired: boolean;
}

export class ErrorClassifier {
  private rules: ClassificationRule[] = [];

  constructor() {
    this.initializeDefaultRules();
  }

  addRule(rule: ClassificationRule): void {
    this.rules.push(rule);
  }

  classify(error: Error, metadata: ErrorMetadata): ErrorInstance {
    const classifiedError = error as ErrorInstance;
    
    // Apply classification rules
    for (const rule of this.rules) {
      if (this.matchesRule(error, rule)) {
        classifiedError.category = rule.category;
        classifiedError.severity = rule.severity;
        classifiedError.retryable = rule.retryable;
        classifiedError.autoRecoverable = rule.autoRecoverable;
        classifiedError.escalationRequired = rule.escalationRequired;
        break;
      }
    }

    // Default classification if no rules match
    if (!classifiedError.category) {
      classifiedError.category = this.defaultCategory(error, metadata);
    }
    if (!classifiedError.severity) {
      classifiedError.severity = this.defaultSeverity(error, metadata);
    }

    // Set remaining properties
    classifiedError.status = ErrorStatus.DETECTED;
    classifiedError.metadata = metadata;
    
    if (classifiedError.retryable === undefined) {
      classifiedError.retryable = this.isRetryable(error);
    }
    if (classifiedError.autoRecoverable === undefined) {
      classifiedError.autoRecoverable = this.isAutoRecoverable(error, classifiedError.category);
    }
    if (classifiedError.escalationRequired === undefined) {
      classifiedError.escalationRequired = this.requiresEscalation(classifiedError);
    }

    return classifiedError;
  }

  private matchesRule(error: Error, rule: ClassificationRule): boolean {
    if (rule.pattern instanceof RegExp) {
      return rule.pattern.test(error.message) || rule.pattern.test(error.stack || '');
    }
    return rule.pattern(error);
  }

  private defaultCategory(error: Error, metadata: ErrorMetadata): ErrorCategory {
    const message = error.message.toLowerCase();
    
    if (message.includes('database') || message.includes('connection') || message.includes('sql')) {
      return ErrorCategory.DATABASE;
    }
    if (message.includes('network') || message.includes('timeout') || message.includes('econnrefused')) {
      return ErrorCategory.INFRASTRUCTURE;
    }
    if (message.includes('auth') || message.includes('permission') || message.includes('forbidden')) {
      return ErrorCategory.SECURITY;
    }
    if (message.includes('memory') || message.includes('cpu') || message.includes('performance')) {
      return ErrorCategory.PERFORMANCE;
    }
    if (message.includes('external') || message.includes('service') || message.includes('dependency')) {
      return ErrorCategory.DEPENDENCY;
    }
    
    return ErrorCategory.APPLICATION;
  }

  private defaultSeverity(error: Error, metadata: ErrorMetadata): ErrorSeverity {
    // Determine severity based on error type and context
    const criticalPatterns = [
      /out of memory/i,
      /stack overflow/i,
      /connection refused/i,
      /service unavailable/i,
      /database.*down/i
    ];
    
    const highPatterns = [
      /timeout/i,
      /slow/i,
      /degraded/i,
      /partial.*failure/i
    ];

    const message = error.message.toLowerCase();
    
    if (criticalPatterns.some(pattern => pattern.test(message))) {
      return ErrorSeverity.CRITICAL;
    }
    if (highPatterns.some(pattern => pattern.test(message))) {
      return ErrorSeverity.HIGH;
    }
    if (metadata.component === 'auth' || metadata.component === 'payment') {
      return ErrorSeverity.HIGH; // These components require higher severity
    }
    
    return ErrorSeverity.MEDIUM;
  }

  private isRetryable(error: Error): boolean {
    const nonRetryablePatterns = [
      /validation error/i,
      /permission denied/i,
      /auth.*failed/i,
      /invalid.*input/i
    ];
    
    return !nonRetryablePatterns.some(pattern => 
      pattern.test(error.message) || pattern.test(error.stack || '')
    );
  }

  private isAutoRecoverable(error: Error, category: ErrorCategory): boolean {
    // Infrastructure and dependency errors are often auto-recoverable
    if (category === ErrorCategory.INFRASTRUCTURE || category === ErrorCategory.DEPENDENCY) {
      return true;
    }
    
    // Database connection issues are often auto-recoverable
    if (category === ErrorCategory.DATABASE && error.message.includes('connection')) {
      return true;
    }
    
    return false;
  }

  private requiresEscalation(error: ErrorInstance): boolean {
    return error.severity === ErrorSeverity.CRITICAL || 
           error.severity === ErrorSeverity.HIGH ||
           !error.autoRecoverable;
  }

  private initializeDefaultRules(): void {
    // Database connection errors
    this.addRule({
      pattern: /connection.*refused|econnrefused|etimedout/gi,
      category: ErrorCategory.DATABASE,
      severity: ErrorSeverity.HIGH,
      retryable: true,
      autoRecoverable: true,
      escalationRequired: false
    });

    // Authentication errors
    this.addRule({
      pattern: /unauthorized|forbidden|auth.*failed/i,
      category: ErrorCategory.SECURITY,
      severity: ErrorSeverity.MEDIUM,
      retryable: false,
      autoRecoverable: false,
      escalationRequired: true
    });

    // Infrastructure errors
    this.addRule({
      pattern: /service unavailable|econnreset|enotfound/i,
      category: ErrorCategory.INFRASTRUCTURE,
      severity: ErrorSeverity.HIGH,
      retryable: true,
      autoRecoverable: true,
      escalationRequired: false
    });

    // Performance issues
    this.addRule({
      pattern: /timeout|slow|memory.*exhausted/i,
      category: ErrorCategory.PERFORMANCE,
      severity: ErrorSeverity.MEDIUM,
      retryable: true,
      autoRecoverable: true,
      escalationRequired: false
    });

    // Critical system errors
    this.addRule({
      pattern: /out of memory|stack overflow|cannot read property/i,
      category: ErrorCategory.SYSTEM,
      severity: ErrorSeverity.CRITICAL,
      retryable: false,
      autoRecoverable: false,
      escalationRequired: true
    });
  }

  assessImpact(error: ErrorInstance): {
    userImpact: number; // 0-10 scale
    systemImpact: number; // 0-10 scale
    businessImpact: number; // 0-10 scale
    urgencyScore: number; // 0-10 scale
  } {
    let userImpact = 0;
    let systemImpact = 0;
    let businessImpact = 0;
    let urgencyScore = 0;

    // Base scores from severity
    const severityScores = {
      [ErrorSeverity.CRITICAL]: 9,
      [ErrorSeverity.HIGH]: 7,
      [ErrorSeverity.MEDIUM]: 5,
      [ErrorSeverity.LOW]: 2,
      [ErrorSeverity.INFO]: 1
    };

    const baseScore = severityScores[error.severity];
    urgencyScore = baseScore;

    // Adjust based on category
    switch (error.category) {
      case ErrorCategory.SECURITY:
        businessImpact = Math.max(businessImpact, 8);
        urgencyScore += 2;
        break;
      case ErrorCategory.DATABASE:
        userImpact = Math.max(userImpact, 7);
        systemImpact = Math.max(systemImpact, 8);
        break;
      case ErrorCategory.INFRASTRUCTURE:
        userImpact = Math.max(userImpact, 8);
        systemImpact = Math.max(systemImpact, 9);
        break;
      case ErrorCategory.PERFORMANCE:
        userImpact = Math.max(userImpact, 5);
        systemImpact = Math.max(systemImpact, 4);
        break;
    }

    // Environment adjustment
    if (error.metadata.environment === 'production') {
      userImpact += 2;
      businessImpact += 2;
      urgencyScore += 1;
    }

    // Component-specific adjustments
    const criticalComponents = ['auth', 'payment', 'user-service', 'api-gateway'];
    if (criticalComponents.includes(error.metadata.component)) {
      userImpact += 3;
      businessImpact += 3;
      urgencyScore += 2;
    }

    return {
      userImpact: Math.min(10, userImpact),
      systemImpact: Math.min(10, systemImpact),
      businessImpact: Math.min(10, businessImpact),
      urgencyScore: Math.min(10, urgencyScore)
    };
  }

  getRecoveryStrategy(error: ErrorInstance): {
    strategy: 'auto' | 'manual' | 'escalate';
    priority: number;
    estimatedRecoveryTime: number; // in minutes
    requiredRoles: string[];
  } {
    const impact = this.assessImpact(error);
    
    if (error.escalationRequired || impact.urgencyScore >= 8) {
      return {
        strategy: 'escalate',
        priority: 1,
        estimatedRecoveryTime: 30,
        requiredRoles: ['senior-engineer', 'team-lead']
      };
    }

    if (error.autoRecoverable && impact.urgencyScore < 6) {
      return {
        strategy: 'auto',
        priority: 3,
        estimatedRecoveryTime: 5,
        requiredRoles: []
      };
    }

    return {
      strategy: 'manual',
      priority: 2,
        estimatedRecoveryTime: 15,
        requiredRoles: ['engineer', 'devops']
      };
  }
}

export const errorClassifier = new ErrorClassifier();
