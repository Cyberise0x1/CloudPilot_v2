# Error Recovery System

A comprehensive error recovery system that provides automated and manual intervention workflows, error correlation analysis, tracking, notifications, and testing capabilities for production systems.

## Overview

The Error Recovery System is designed to handle the complete lifecycle of error detection, classification, recovery, and analysis. It includes:

- **Error Classification & Severity Assessment** - Intelligent categorization and priority assignment
- **Automated Recovery Procedures** - Self-healing capabilities for common error types
- **Manual Intervention Workflows** - Human-in-the-loop processes for complex issues
- **Recovery Orchestration** - Coordination between automated and manual processes
- **Error Correlation & Analysis** - Pattern detection and root cause analysis
- **Recovery Tracking** - Success/failure tracking and performance analytics
- **Notification Systems** - Multi-channel alerting for critical errors
- **Recovery Testing & Validation** - Automated testing and disaster recovery drills

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Error Recovery System                     │
├─────────────────────────────────────────────────────────────┤
│  Error Classification  │  Automated Recovery  │  Manual      │
│  & Severity Assessment │  Procedures           │  Intervention│
├─────────────────────────────────────────────────────────────┤
│              Recovery Orchestration Layer                   │
├─────────────────────────────────────────────────────────────┤
│  Error Correlation  │  Recovery Tracking  │  Notification  │
│  & Analysis         │  & Analytics         │  Systems       │
├─────────────────────────────────────────────────────────────┤
│                Recovery Testing & Validation                │
└─────────────────────────────────────────────────────────────┘
```

## Components

### 1. Error Classification & Severity Assessment (`error-classification.ts`)

Intelligent error classification with severity assessment and routing capabilities.

**Features:**
- Pattern-based error classification
- Severity scoring (Critical, High, Medium, Low, Info)
- Automatic routing to appropriate recovery workflows
- Impact assessment (user, system, business impact)
- Retry and escalation logic

**Key Classes:**
- `ErrorClassifier` - Main classification engine
- `ErrorInstance` - Classified error representation
- `ErrorSeverity` - Severity levels
- `ErrorCategory` - Error categories

**Usage:**
```typescript
import { errorClassifier, ErrorSeverity, ErrorCategory } from './error-classification';

// Classify an error
const error = new Error('Database connection timeout');
const metadata = {
  timestamp: new Date(),
  source: 'database-service',
  component: 'user-service',
  environment: 'production'
};

const classifiedError = errorClassifier.classify(error, metadata);

console.log(`Category: ${classifiedError.category}`);
console.log(`Severity: ${classifiedError.severity}`);
console.log(`Auto-recoverable: ${classifiedError.autoRecoverable}`);
```

### 2. Automated Recovery Procedures (`automated-recovery.ts`)

Self-healing capabilities for common error scenarios.

**Features:**
- Predefined recovery procedures for different error types
- Configurable steps with validation and rollback
- Retry logic with exponential backoff
- Health check and validation
- Custom action handlers

**Key Classes:**
- `AutomatedRecovery` - Main recovery engine
- `RecoveryProcedure` - Procedure definition
- `RecoveryStep` - Individual recovery step
- `RecoveryResult` - Execution result

**Usage:**
```typescript
import { automatedRecovery } from './automated-recovery';

// Execute automated recovery
const result = await automatedRecovery.executeRecovery(classifiedError, {
  error: classifiedError,
  metadata: classifiedError.metadata,
  previousStepResults: new Map(),
  environment: 'production'
});

if (result.success) {
  console.log(`Recovery completed in ${result.executionTime}ms`);
} else {
  console.log(`Recovery failed: ${result.error?.message}`);
}
```

### 3. Manual Intervention Workflows (`manual-intervention.ts`)

Human-in-the-loop processes for complex error scenarios.

**Features:**
- Workflow definitions for different error types
- Approval processes with escalation levels
- Skill-based assignment
- Timeout handling
- Audit trails

**Key Classes:**
- `ManualInterventionWorkflow` - Workflow management
- `InterventionRequest` - Manual intervention request
- `ApprovalRecord` - Approval tracking
- `InterventionPriority` - Priority levels

**Usage:**
```typescript
import { manualInterventionWorkflow } from './manual-intervention';

// Create manual intervention request
const request = await manualInterventionWorkflow.createInterventionRequest(
  classifiedError,
  'database-recovery',
  {
    sessionId: 'recovery-123',
    escalationReason: 'Automated recovery failed'
  }
);

console.log(`Request created: ${request.id}`);
console.log(`Assigned to: ${request.assignedTo}`);
```

### 4. Recovery Orchestration (`recovery-orchestration.ts`)

Coordinates between automated and manual recovery processes.

**Features:**
- Multi-mode recovery (auto-only, manual-only, hybrid, escalation)
- Policy-based decision making
- State management and transitions
- Timeout handling
- Metrics collection

**Key Classes:**
- `RecoveryOrchestrator` - Main orchestration engine
- `RecoverySession` - Recovery session tracking
- `RecoveryPolicy` - Policy configuration
- `RecoveryMetrics` - Performance metrics

**Usage:**
```typescript
import { recoveryOrchestrator, RecoveryMode } from './recovery-orchestration';

// Initiate recovery process
const sessionId = await recoveryOrchestrator.initiateRecovery(
  classifiedError,
  RecoveryMode.HYBRID,
  'default'
);

console.log(`Recovery session started: ${sessionId}`);
```

### 5. Error Correlation & Analysis (`error-correlation.ts`)

Advanced error correlation and pattern analysis.

**Features:**
- Pattern detection and clustering
- Anomaly detection
- Root cause analysis
- Trend analysis and forecasting
- Seasonal pattern detection

**Key Classes:**
- `ErrorCorrelationAnalyzer` - Analysis engine
- `CorrelationRule` - Correlation rules
- `ClusterAnalysis` - Error clustering
- `RootCauseAnalysis` - Root cause analysis
- `AnomalyAlert` - Anomaly alerts

**Usage:**
```typescript
import { errorCorrelationAnalyzer } from './error-correlation';

// Analyze error for correlations
const analysis = await errorCorrelationAnalyzer.analyzeError(classifiedError);

console.log(`Found ${analysis.correlations.length} correlations`);
console.log(`Found ${analysis.patterns.length} patterns`);
console.log(`Found ${analysis.anomalies.length} anomalies`);

if (analysis.rootCause) {
  console.log(`Root cause confidence: ${analysis.rootCause.confidence}`);
}
```

### 6. Recovery Tracking (`recovery-tracking.ts`)

Comprehensive tracking of recovery successes and failures.

**Features:**
- Detailed recovery record keeping
- Performance analytics
- Trend analysis
- SLA monitoring
- Compliance reporting

**Key Classes:**
- `RecoveryTracker` - Main tracking system
- `RecoveryTrackingRecord` - Individual record
- `RecoveryAnalytics` - Analytics data
- `RecoveryReport` - Report generation

**Usage:**
```typescript
import { recoveryTracker } from './recovery-tracking';

// Record recovery session
await recoveryTracker.recordRecoverySession(sessionId, {
  errorId: classifiedError.metadata.correlationId,
  error: {
    category: classifiedError.category,
    severity: classifiedError.severity,
    message: classifiedError.message,
    component: classifiedError.metadata.component
  },
  recovery: {
    method: RecoveryMethod.AUTOMATED,
    startTime: new Date(),
    outcome: RecoveryOutcome.SUCCESS,
    steps: []
  },
  metrics: {
    timeToDetection: 5000,
    timeToRecovery: 30000,
    automationSuccessRate: 100
  },
  impact: {
    userImpact: 2,
    businessImpact: 3,
    systemImpact: 4,
    downtime: 10000,
    affectedUsers: 0
  }
});

// Generate analytics
const analytics = await recoveryTracker.generateAnalytics('month');
console.log(`Overall success rate: ${analytics.overall.successRate}%`);
```

### 7. Notification Systems (`notification-system.ts`)

Multi-channel notification capabilities for critical errors.

**Features:**
- Multiple notification channels (Email, Slack, PagerDuty, SMS, etc.)
- Template-based notifications
- Escalation rules
- Retry and delivery tracking
- Working hours and vacation handling

**Key Classes:**
- `NotificationSystem` - Main notification engine
- `NotificationTemplate` - Template definition
- `NotificationRecipient` - Recipient information
- `NotificationRequest` - Notification request

**Usage:**
```typescript
import { notificationSystem, NotificationPriority } from './notification-system';

// Send critical alert
const requestIds = await notificationSystem.sendCriticalAlert(
  classifiedError,
  'outage'
);

console.log(`Sent ${requestIds.length} critical alerts`);

// Send custom notification
const requestId = await notificationSystem.sendNotification(
  classifiedError,
  'error-alert',
  ['engineering-team'],
  NotificationPriority.HIGH,
  { context: 'Production error detected' }
);
```

### 8. Recovery Testing & Validation (`recovery-testing.ts`)

Comprehensive testing capabilities for recovery procedures.

**Features:**
- Unit, integration, E2E, chaos, and drill testing
- Automated test execution
- Test result validation
- Disaster recovery drills
- Compliance testing

**Key Classes:**
- `RecoveryTestingSystem` - Main testing system
- `RecoveryTest` - Test definition
- `TestRun` - Test execution
- `DrillExecution` - Drill execution

**Usage:**
```typescript
import { recoveryTestingSystem } from './recovery-testing';

// Run recovery test
const runId = await recoveryTestingSystem.runTest(
  'db-connection-test',
  {
    name: 'Test Environment',
    type: 'test',
    region: 'us-east-1',
    configuration: {},
    isolation: { network: true, data: true, resources: true }
  },
  'automated-test'
);

// Execute disaster recovery drill
const drillId = await recoveryTestingSystem.scheduleDrill(
  'Database Failover Drill',
  'Simulate database failure and verify recovery',
  [
    {
      id: 'participant-1',
      name: 'John Doe',
      role: 'Database Administrator',
      contact: 'john@company.com',
      responsibilities: ['Database management', 'Recovery coordination']
    }
  ],
  new Date(Date.now() + 24 * 60 * 60 * 1000), // Tomorrow
  60, // 60 minutes
  [
    {
      id: 'obj-1',
      description: 'Complete recovery within 30 minutes',
      type: 'technical',
      measurable: true,
      target: 1800000 // 30 minutes in ms
    }
  ]
);
```

## Main System Integration

The `ErrorRecoverySystem` class provides a unified interface to all components:

```typescript
import { 
  ErrorRecoverySystem, 
  createErrorRecoverySystem,
  defaultRecoveryConfig 
} from './index';

// Create system with default configuration
const recoverySystem = createErrorRecoverySystem();

// Or with custom configuration
const customConfig = {
  ...defaultRecoveryConfig,
  enableTesting: true,
  maxAutomationTime: 600000 // 10 minutes
};
const recoverySystem = new ErrorRecoverySystem(customConfig);

// Initialize the system
await recoverySystem.initialize();

// Process an error
const result = await recoverySystem.processError(
  new Error('Database connection failed'),
  {
    timestamp: new Date(),
    source: 'database-service',
    component: 'user-service',
    environment: 'production',
    context: { requestId: 'req-123' }
  }
);

console.log(`Recovery session: ${result.sessionId}`);
console.log(`Classification:`, result.classification);

// Get system status
const status = recoverySystem.getSystemStatus();
console.log(`System status: ${status.status}`);
console.log(`Availability: ${status.metrics.overall.systemAvailability}%`);

// Run recovery tests
const testResults = await recoverySystem.runRecoveryTests({
  category: 'database',
  severity: 'high'
});
console.log(`Test coverage: ${testResults.summary.coverage}%`);

// Execute disaster recovery drill
const drillResult = await recoverySystem.executeDrill({
  scenario: 'Complete system outage simulation',
  participants: ['oncall-team', 'infrastructure-team'],
  duration: 120, // 2 hours
  objectives: ['Recovery time < 30 minutes', 'Zero data loss']
});
console.log(`Drill ID: ${drillResult.drillId}`);

// Shutdown gracefully
await recoverySystem.shutdown();
```

## Configuration

### Basic Configuration

```typescript
const config: RecoverySystemConfig = {
  enableAutomatedRecovery: true,
  enableManualIntervention: true,
  enableErrorCorrelation: true,
  enableNotifications: true,
  enableTesting: true,
  defaultRecoveryMode: 'hybrid',
  maxAutomationTime: 300000, // 5 minutes
  maxTotalRecoveryTime: 1800000, // 30 minutes
  notificationChannels: ['slack', 'email', 'pagerduty'],
  criticalErrorThresholds: {
    errorRate: 0.01, // 1% error rate
    responseTime: 5000, // 5 seconds
    errorSeverity: ['critical', 'high']
  },
  testingSchedule: {
    frequency: 'weekly',
    time: '02:00',
    timezone: 'UTC'
  }
};
```

### Custom Recovery Procedures

```typescript
import { automatedRecovery } from './automated-recovery';

automatedRecovery.registerProcedure({
  name: 'Custom Database Recovery',
  description: 'Custom recovery for specific database issues',
  category: ErrorCategory.DATABASE,
  severity: [ErrorSeverity.HIGH, ErrorSeverity.CRITICAL],
  prerequisites: ['database-connected'],
  steps: [
    {
      id: 'check-connections',
      name: 'Check Database Connections',
      description: 'Verify connection pool status',
      action: { 
        type: 'custom-action',
        actionName: 'check-db-connections',
        parameters: {} 
      }
    },
    {
      id: 'scale-pool',
      name: 'Scale Connection Pool',
      description: 'Increase connection pool size',
      action: {
        type: 'scale-resources',
        resourceType: 'connections',
        targetValue: 100,
        scaleDirection: 'up'
      }
    }
  ],
  timeout: 180000,
  maxRetries: 2,
  rollbackRequired: true,
  validationRequired: true
});
```

### Custom Notification Templates

```typescript
import { notificationSystem } from './notification-system';

notificationSystem.registerTemplate({
  id: 'custom-payment-error',
  name: 'Payment Error Alert',
  description: 'Alert for payment service errors',
  channel: NotificationChannel.SLACK,
  priority: NotificationPriority.CRITICAL,
  subject: '💳 Payment Error: {{error.component}}',
  body: `💳 PAYMENT ERROR ALERT 💳

Service: {{error.component}}
Environment: {{environment}}
Time: {{timestamp}}

Error Details:
{{error.message}}

🚨 IMMEDIATE ACTION REQUIRED 🚨

Session ID: {{sessionId}}`,
  variables: [],
  conditions: [
    { field: 'error.component', operator: 'equals', value: 'payment-service' }
  ],
  escalationRules: [
    { 
      delay: 3, 
      channel: NotificationChannel.PAGERDUTY, 
      recipients: ['payment-oncall'], 
      priority: NotificationPriority.EMERGENCY 
    }
  ],
  enabled: true
});
```

## Integration Examples

### Express.js Middleware

```typescript
import express from 'express';
import { errorRecoverySystem } from './error-recovery';

const app = express();

// Initialize recovery system
await errorRecoverySystem.initialize();

app.use(async (req, res, next) => {
  try {
    await next();
  } catch (error) {
    // Process error through recovery system
    const result = await errorRecoverySystem.processError(error, {
      timestamp: new Date(),
      source: 'express-middleware',
      component: req.route?.path || 'unknown',
      environment: process.env.NODE_ENV,
      context: {
        method: req.method,
        url: req.url,
        userAgent: req.get('User-Agent'),
        requestId: req.headers['x-request-id']
      }
    });

    // Log recovery session
    console.log(`Error processed: ${result.sessionId}`);

    // Send error response
    res.status(500).json({
      error: 'Internal server error',
      recoverySession: result.sessionId
    });
  }
});

app.listen(3000);
```

### Integration with Monitoring Systems

```typescript
import { errorRecoverySystem } from './error-recovery';

// Listen for monitoring alerts
monitoringSystem.on('alert', async (alert) => {
  if (alert.severity === 'critical') {
    try {
      const result = await errorRecoverySystem.processError(
        new Error(alert.message),
        {
          timestamp: new Date(),
          source: 'monitoring-system',
          component: alert.service,
          environment: 'production',
          context: alert.metadata
        }
      );

      console.log(`Monitoring alert processed: ${result.sessionId}`);
    } catch (error) {
      console.error('Failed to process monitoring alert:', error);
    }
  }
});

// Listen for recovery events
errorRecoverySystem.on('recovery_completed', (data) => {
  monitoringSystem.updateAlert(data.alertId, {
    status: 'resolved',
    resolutionTime: data.duration,
    recoveryMethod: data.method
  });
});
```

### Database Integration

```typescript
import { errorRecoverySystem } from './error-recovery';

// Database error handler
database.on('connection_error', async (error) => {
  await errorRecoverySystem.processError(error, {
    timestamp: new Date(),
    source: 'database',
    component: 'database-connection',
    environment: 'production',
    context: {
      host: error.host,
      port: error.port,
      database: error.database
    }
  });
});

database.on('query_timeout', async (error) => {
  await errorRecoverySystem.processError(error, {
    timestamp: new Date(),
    source: 'database',
    component: 'database-query',
    environment: 'production',
    context: {
      query: error.query,
      timeout: error.timeout
    }
  });
});
```

## Testing

### Unit Testing

```typescript
import { errorClassifier } from './error-classification';
import { automatedRecovery } from './automated-recovery';

describe('Error Classification', () => {
  test('should classify database connection errors correctly', () => {
    const error = new Error('Connection refused');
    const metadata = {
      timestamp: new Date(),
      source: 'database',
      component: 'user-service',
      environment: 'test'
    };

    const classified = errorClassifier.classify(error, metadata);
    
    expect(classified.category).toBe('database');
    expect(classified.severity).toBe('high');
    expect(classified.autoRecoverable).toBe(true);
  });
});

describe('Automated Recovery', () => {
  test('should successfully recover from temporary errors', async () => {
    const error = new Error('Connection timeout');
    const context = {
      error,
      metadata: {},
      previousStepResults: new Map(),
      environment: 'test'
    };

    const result = await automatedRecovery.executeRecovery(error, context);
    
    expect(result.success).toBe(true);
    expect(result.stepsExecuted).toBeGreaterThan(0);
  });
});
```

### Integration Testing

```typescript
import { errorRecoverySystem } from './index';

describe('Error Recovery System Integration', () => {
  test('should handle complete error recovery flow', async () => {
    // Initialize system
    await errorRecoverySystem.initialize();

    // Simulate error
    const error = new Error('Service unavailable');
    const metadata = {
      timestamp: new Date(),
      source: 'api-gateway',
      component: 'user-service',
      environment: 'test'
    };

    // Process error
    const result = await errorRecoverySystem.processError(error, metadata);
    
    expect(result.sessionId).toBeDefined();
    expect(result.classification).toBeDefined();

    // Verify recovery
    await waitForRecovery(result.sessionId);
    
    // Cleanup
    await errorRecoverySystem.shutdown();
  });
});
```

## Monitoring and Observability

### Metrics

The system provides comprehensive metrics:

```typescript
// Get current metrics
const status = errorRecoverySystem.getSystemStatus();
console.log('System Metrics:', {
  totalErrors: status.metrics.overall.totalErrors,
  recoveryRate: `${status.metrics.overall.recoveryRate}%`,
  availability: `${status.metrics.overall.systemAvailability}%`,
  automationCoverage: `${status.metrics.overall.automationCoverage}%`
});

// Get detailed analytics
const analytics = await errorRecoverySystem.getAnalytics('month');
console.log('Trends:', analytics.trends.insights);
console.log('SLA Compliance:', `${analytics.sla.slaCompliance}%`);
```

### Health Checks

```typescript
// System health check
const health = errorRecoverySystem.getSystemStatus();
if (health.status !== 'healthy') {
  console.warn(`System health degraded: ${health.status}`);
  console.warn(`Active recoveries: ${health.activeRecoveries}`);
  console.warn(`Pending notifications: ${health.pendingNotifications}`);
}

// Component-specific health checks
const recoveryHealth = checkRecoveryComponentHealth();
const notificationHealth = checkNotificationComponentHealth();
const testingHealth = checkTestingComponentHealth();
```

## Best Practices

### 1. Error Classification
- Use consistent error categories across your application
- Include relevant metadata in error context
- Set appropriate severity levels based on business impact
- Enable auto-recovery for transient errors

### 2. Recovery Procedures
- Start with simple, safe recovery actions
- Include proper validation after each step
- Implement rollback mechanisms for risky operations
- Set appropriate timeouts and retry limits

### 3. Manual Intervention
- Define clear escalation paths
- Include skill-based assignment
- Document procedures and required approvals
- Track lessons learned from manual interventions

### 4. Notifications
- Use appropriate channels for different severity levels
- Include actionable information in notifications
- Respect working hours and quiet periods
- Track notification delivery and response times

### 5. Testing
- Test recovery procedures regularly
- Include both automated and manual scenarios
- Run disaster recovery drills periodically
- Validate testing results and update procedures

### 6. Monitoring
- Monitor system health and metrics continuously
- Set up alerts for system degradation
- Track recovery performance over time
- Regularly review and update thresholds

## Deployment

### Environment Variables

```bash
# Database
DATABASE_URL=postgresql://user:pass@localhost/recovery_db

# Redis (for session management)
REDIS_URL=redis://localhost:6379

# Notification Services
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/...
PAGERDUTY_API_KEY=your_pagerduty_key
SMTP_HOST=smtp.company.com
SMTP_USER=notifications@company.com
SMTP_PASS=your_smtp_password

# Monitoring
MONITORING_API_KEY=your_monitoring_key

# Testing
TEST_ENVIRONMENT=test
DRILL_PARTICIPANTS=team1,team2
```

### Docker Deployment

```dockerfile
FROM node:18-alpine

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

COPY dist/ ./dist/

EXPOSE 3000
CMD ["node", "dist/index.js"]
```

```yaml
# docker-compose.yml
version: '3.8'
services:
  error-recovery:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=postgresql://postgres:password@postgres:5432/recovery
      - REDIS_URL=redis://redis:6379
    depends_on:
      - postgres
      - redis
    volumes:
      - ./logs:/app/logs

  postgres:
    image: postgres:14
    environment:
      POSTGRES_DB: recovery
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: password
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine
    volumes:
      - redis_data:/data

volumes:
  postgres_data:
  redis_data:
```

### Kubernetes Deployment

```yaml
# k8s-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: error-recovery-system
spec:
  replicas: 3
  selector:
    matchLabels:
      app: error-recovery
  template:
    metadata:
      labels:
        app: error-recovery
    spec:
      containers:
      - name: error-recovery
        image: error-recovery:latest
        ports:
        - containerPort: 3000
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: recovery-secrets
              key: database-url
        - name: REDIS_URL
          valueFrom:
            secretKeyRef:
              name: recovery-secrets
              key: redis-url
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 3000
          initialDelaySeconds: 5
          periodSeconds: 5
```

## Security Considerations

### 1. Access Control
- Implement role-based access control for manual interventions
- Secure API endpoints with authentication
- Limit access to sensitive recovery procedures
- Audit all administrative actions

### 2. Data Protection
- Encrypt sensitive error data and logs
- Implement data retention policies
- Secure notification channels
- Protect secrets and credentials

### 3. Network Security
- Use secure communication protocols
- Implement network segmentation
- Monitor for suspicious activities
- Regular security audits

### 4. Compliance
- Maintain audit trails for all recovery actions
- Implement data privacy controls
- Regular compliance assessments
- Document security procedures

## Troubleshooting

### Common Issues

1. **Recovery System Not Starting**
   - Check configuration settings
   - Verify database connectivity
   - Review error logs

2. **Notifications Not Sending**
   - Verify API keys and credentials
   - Check notification channel configurations
   - Test network connectivity

3. **Recovery Procedures Failing**
   - Review step definitions
   - Check dependencies and prerequisites
   - Validate environment configuration

4. **High False Positive Rate**
   - Tune error classification rules
   - Adjust severity thresholds
   - Update correlation patterns

### Debug Mode

```typescript
// Enable debug logging
process.env.LOG_LEVEL = 'debug';

// Enable detailed error tracking
const recoverySystem = createErrorRecoverySystem({
  // ... configuration
  debug: true
});
```

### Performance Tuning

```typescript
// Optimize for high-throughput environments
const optimizedConfig = {
  maxAutomationTime: 180000, // 3 minutes
  batchSize: 100,
  concurrency: 10,
  cacheSize: 10000
};
```

## Contributing

1. Follow the established code patterns
2. Add comprehensive tests for new features
3. Update documentation for API changes
4. Include performance benchmarks
5. Ensure security reviews for sensitive changes

## License

MIT License - see LICENSE file for details.
