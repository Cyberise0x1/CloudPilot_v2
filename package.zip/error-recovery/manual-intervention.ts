/**
 * Manual Intervention Workflows
 * 
 * This module defines manual intervention workflows, approval processes,
 * and human-in-the-loop recovery procedures.
 */

import { ErrorInstance, ErrorSeverity } from './error-classification';

export enum InterventionPriority {
  URGENT = 'urgent',      // Immediate intervention required
  HIGH = 'high',         // Intervention within 1 hour
  MEDIUM = 'medium',     // Intervention within 4 hours
  LOW = 'low'           // Intervention within 24 hours
}

export enum InterventionStatus {
  PENDING = 'pending',
  ASSIGNED = 'assigned',
  IN_PROGRESS = 'in_progress',
  REVIEW_REQUIRED = 'review_required',
  APPROVED = 'approved',
  REJECTED = 'rejected',
  COMPLETED = 'completed',
  ESCALATED = 'escalated'
}

export enum ApprovalLevel {
  OPERATOR = 'operator',        // Level 1: Junior engineers
  SENIOR_ENGINEER = 'senior',   // Level 2: Senior engineers
  TEAM_LEAD = 'lead',          // Level 3: Team leads
  MANAGER = 'manager',         // Level 4: Engineering managers
  DIRECTOR = 'director',       // Level 5: Directors
  EXECUTIVE = 'executive'      // Level 6: C-level executives
}

export interface ManualInterventionRequest {
  id: string;
  errorId: string;
  title: string;
  description: string;
  category: string;
  priority: InterventionPriority;
  requiredSkills: string[];
  estimatedDuration: number; // in minutes
  environment: 'development' | 'staging' | 'production';
  createdAt: Date;
  createdBy: string;
  assignedTo?: string;
  status: InterventionStatus;
  approvalRequired: ApprovalLevel;
  approvalRequiredCount: number;
  approvals: ApprovalRecord[];
  actions: InterventionAction[];
  rollbackPlan?: string;
  successCriteria: string[];
  validationSteps: string[];
  escalations: EscalationRecord[];
  metadata: Record<string, any>;
}

export interface InterventionAction {
  id: string;
  name: string;
  description: string;
  type: 'manual' | 'script' | 'command' | 'configuration' | 'approval';
  required: boolean;
  executed: boolean;
  executedBy?: string;
  executedAt?: Date;
  result?: 'success' | 'failure' | 'skipped';
  notes?: string;
  timeout?: number; // in minutes
}

export interface ApprovalRecord {
  id: string;
  level: ApprovalLevel;
  approver: string;
  status: 'pending' | 'approved' | 'rejected';
  comments?: string;
  timestamp: Date;
  delegationAllowed: boolean;
}

export interface EscalationRecord {
  id: string;
  fromLevel: ApprovalLevel;
  toLevel: ApprovalLevel;
  reason: string;
  escalatedBy: string;
  escalatedAt: Date;
  status: 'pending' | 'approved' | 'rejected';
}

export interface WorkflowDefinition {
  id: string;
  name: string;
  description: string;
  category: string;
  severityLevels: ErrorSeverity[];
  priority: InterventionPriority;
  approvalLevels: ApprovalLevel[];
  requiredSkills: string[];
  estimatedDuration: number;
  actions: WorkflowActionDefinition[];
  autoEscalationRules: AutoEscalationRule[];
  notificationRules: NotificationRule[];
}

export interface WorkflowActionDefinition {
  name: string;
  description: string;
  type: 'manual' | 'script' | 'command' | 'configuration' | 'approval';
  required: boolean;
  timeout?: number;
  validationRequired?: boolean;
  dependencies?: string[]; // Action IDs this action depends on
}

export interface AutoEscalationRule {
  condition: {
    timeElapsed?: number; // minutes
    attempts?: number;
    noResponse?: boolean;
  };
  escalateTo: ApprovalLevel;
  notifyStakeholders: boolean;
}

export interface NotificationRule {
  trigger: 'creation' | 'assignment' | 'escalation' | 'completion' | 'timeout';
  recipients: string[];
  template: string;
  includeLogs?: boolean;
  includeContext?: boolean;
}

export interface AssignmentRule {
  skills: string[];
  availability: string[];
  timezone?: string;
  maxConcurrent: number;
  priority: 'least-loaded' | 'skill-match' | 'availability';
}

export class ManualInterventionWorkflow {
  private workflows: Map<string, WorkflowDefinition> = new Map();
  private activeRequests: Map<string, ManualInterventionRequest> = new Map();
  private assignmentRules: AssignmentRule[] = [];
  private approvers: Map<ApprovalLevel, string[]> = new Map();

  constructor() {
    this.initializeDefaultWorkflows();
    this.initializeApprovers();
  }

  async createInterventionRequest(
    error: ErrorInstance,
    workflowId: string,
    metadata: Record<string, any>
  ): Promise<ManualInterventionRequest> {
    const workflow = this.workflows.get(workflowId);
    if (!workflow) {
      throw new Error(`Workflow not found: ${workflowId}`);
    }

    const request: ManualInterventionRequest = {
      id: this.generateId('intervention'),
      errorId: this.getErrorId(error),
      title: `Manual intervention required for ${error.category} error`,
      description: `Manual intervention required for error: ${error.message}`,
      category: workflow.category,
      priority: workflow.priority,
      requiredSkills: workflow.requiredSkills,
      estimatedDuration: workflow.estimatedDuration,
      environment: error.metadata.environment,
      createdAt: new Date(),
      createdBy: 'system',
      status: InterventionStatus.PENDING,
      approvalRequired: workflow.approvalLevels[0],
      approvalRequiredCount: workflow.approvalLevels.length,
      approvals: workflow.approvalLevels.map(level => ({
        id: this.generateId('approval'),
        level,
        approver: '',
        status: 'pending',
        timestamp: new Date(),
        delegationAllowed: this.isDelegationAllowed(level)
      })),
      actions: workflow.actions.map(action => ({
        id: this.generateId('action'),
        name: action.name,
        description: action.description,
        type: action.type,
        required: action.required,
        executed: false
      })),
      successCriteria: [],
      validationSteps: workflow.actions
        .filter(a => a.validationRequired)
        .map(a => a.name),
      escalations: [],
      metadata
    };

    this.activeRequests.set(request.id, request);

    // Auto-assign if possible
    await this.autoAssign(request);

    // Send notifications
    await this.sendNotifications(request, 'creation');

    return request;
  }

  async assignRequest(requestId: string, assignee: string): Promise<boolean> {
    const request = this.activeRequests.get(requestId);
    if (!request) {
      throw new Error(`Request not found: ${requestId}`);
    }

    if (request.status !== InterventionStatus.PENDING && 
        request.status !== InterventionStatus.ASSIGNED) {
      throw new Error(`Cannot assign request in status: ${request.status}`);
    }

    request.assignedTo = assignee;
    request.status = InterventionStatus.ASSIGNED;

    await this.sendNotifications(request, 'assignment');
    return true;
  }

  async startExecution(requestId: string, executor: string): Promise<boolean> {
    const request = this.activeRequests.get(requestId);
    if (!request) {
      throw new Error(`Request not found: ${requestId}`);
    }

    if (!request.assignedTo || request.assignedTo !== executor) {
      throw new Error(`Request not assigned to executor: ${executor}`);
    }

    request.status = InterventionStatus.IN_PROGRESS;
    return true;
  }

  async executeAction(
    requestId: string,
    actionId: string,
    executor: string,
    result: 'success' | 'failure' | 'skipped',
    notes?: string
  ): Promise<boolean> {
    const request = this.activeRequests.get(requestId);
    if (!request) {
      throw new Error(`Request not found: ${requestId}`);
    }

    const action = request.actions.find(a => a.id === actionId);
    if (!action) {
      throw new Error(`Action not found: ${actionId}`);
    }

    action.executed = true;
    action.executedBy = executor;
    action.executedAt = new Date();
    action.result = result;
    action.notes = notes;

    // Check if all required actions are completed
    const requiredActions = request.actions.filter(a => a.required);
    const completedRequiredActions = requiredActions.filter(a => a.result === 'success');

    if (completedRequiredActions.length === requiredActions.length) {
      request.status = InterventionStatus.REVIEW_REQUIRED;
    }

    return true;
  }

  async requestApproval(
    requestId: string,
    approver: string,
    level: ApprovalLevel,
    decision: 'approve' | 'reject',
    comments?: string
  ): Promise<boolean> {
    const request = this.activeRequests.get(requestId);
    if (!request) {
      throw new Error(`Request not found: ${requestId}`);
    }

    const approval = request.approvals.find(a => a.level === level);
    if (!approval) {
      throw new Error(`Approval level not required: ${level}`);
    }

    if (approval.status !== 'pending') {
      throw new Error(`Approval already processed: ${approval.status}`);
    }

    approval.approver = approver;
    approval.status = decision;
    approval.comments = comments;
    approval.timestamp = new Date();

    // Check if all approvals are complete
    if (request.approvals.every(a => a.status !== 'pending')) {
      const allApproved = request.approvals.every(a => a.status === 'approved');
      request.status = allApproved ? InterventionStatus.APPROVED : InterventionStatus.REJECTED;
    }

    return true;
  }

  async escalateRequest(
    requestId: string,
    escalator: string,
    fromLevel: ApprovalLevel,
    toLevel: ApprovalLevel,
    reason: string
  ): Promise<boolean> {
    const request = this.activeRequests.get(requestId);
    if (!request) {
      throw new Error(`Request not found: ${requestId}`);
    }

    const escalation: EscalationRecord = {
      id: this.generateId('escalation'),
      fromLevel,
      toLevel,
      reason,
      escalatedBy: escalator,
      escalatedAt: new Date(),
      status: 'pending'
    };

    request.escalations.push(escalation);
    request.approvalRequired = toLevel;

    // Add new approval record
    request.approvals.push({
      id: this.generateId('approval'),
      level: toLevel,
      approver: '',
      status: 'pending',
      timestamp: new Date(),
      delegationAllowed: this.isDelegationAllowed(toLevel)
    });

    await this.sendNotifications(request, 'escalation');
    return true;
  }

  async completeRequest(requestId: string, completionNotes?: string): Promise<boolean> {
    const request = this.activeRequests.get(requestId);
    if (!request) {
      throw new Error(`Request not found: ${requestId}`);
    }

    request.status = InterventionStatus.COMPLETED;
    
    // Archive the request
    this.activeRequests.delete(requestId);

    await this.sendNotifications(request, 'completion');
    return true;
  }

  getRequestStatus(requestId: string): ManualInterventionRequest | null {
    return this.activeRequests.get(requestId) || null;
  }

  getRequestsByStatus(status: InterventionStatus): ManualInterventionRequest[] {
    return Array.from(this.activeRequests.values()).filter(r => r.status === status);
  }

  getRequestsByAssignee(assignee: string): ManualInterventionRequest[] {
    return Array.from(this.activeRequests.values()).filter(r => r.assignedTo === assignee);
  }

  getOverdueRequests(): ManualInterventionRequest[] {
    const now = new Date();
    return Array.from(this.activeRequests.values()).filter(request => {
      if (request.status === InterventionStatus.COMPLETED) {
        return false;
      }

      const deadline = new Date(request.createdAt.getTime() + request.estimatedDuration * 60000);
      return now > deadline;
    });
  }

  registerWorkflow(workflow: WorkflowDefinition): void {
    this.workflows.set(workflow.id, workflow);
  }

  registerAssignmentRule(rule: AssignmentRule): void {
    this.assignmentRules.push(rule);
  }

  addApprover(level: ApprovalLevel, approverId: string): void {
    if (!this.approvers.has(level)) {
      this.approvers.set(level, []);
    }
    this.approvers.get(level)!.push(approverId);
  }

  private async autoAssign(request: ManualInterventionRequest): Promise<void> {
    // Find best match based on skills and availability
    const candidates = this.findSuitableAssignees(request);
    
    if (candidates.length > 0) {
      const bestCandidate = this.selectBestCandidate(candidates, request);
      await this.assignRequest(request.id, bestCandidate);
    }
  }

  private findSuitableAssignees(request: ManualInterventionRequest): Array<{
    assignee: string;
    skills: string[];
    workload: number;
    availability: boolean;
  }> {
    // This is a simplified implementation
    // In a real system, this would query a user management system
    return [
      {
        assignee: 'user1',
        skills: ['database', 'nodejs'],
        workload: 3,
        availability: true
      },
      {
        assignee: 'user2',
        skills: ['devops', 'aws'],
        workload: 1,
        availability: true
      }
    ];
  }

  private selectBestCandidate(
    candidates: Array<{ assignee: string; skills: string[]; workload: number; availability: boolean }>,
    request: ManualInterventionRequest
  ): string {
    // Score candidates based on skill match and workload
    let bestScore = -1;
    let bestCandidate = candidates[0].assignee;

    for (const candidate of candidates) {
      let score = 0;

      // Skill match score
      const skillMatches = request.requiredSkills.filter(skill => 
        candidate.skills.includes(skill)
      ).length;
      score += skillMatches * 10;

      // Workload penalty
      score += Math.max(0, 10 - candidate.workload);

      // Availability bonus
      if (candidate.availability) {
        score += 5;
      }

      if (score > bestScore) {
        bestScore = score;
        bestCandidate = candidate.assignee;
      }
    }

    return bestCandidate;
  }

  private isDelegationAllowed(level: ApprovalLevel): boolean {
    return level !== ApprovalLevel.EXECUTIVE && level !== ApprovalLevel.DIRECTOR;
  }

  private async sendNotifications(
    request: ManualInterventionRequest,
    trigger: 'creation' | 'assignment' | 'escalation' | 'completion' | 'timeout'
  ): Promise<void> {
    const workflow = this.getWorkflowForRequest(request);
    if (!workflow) return;

    const notificationRules = workflow.notificationRules.filter(rule => rule.trigger === trigger);
    
    for (const rule of notificationRules) {
      // Implement notification logic
      console.log(`Sending notification for ${trigger}:`, {
        recipients: rule.recipients,
        template: rule.template,
        requestId: request.id,
        title: request.title
      });
    }
  }

  private getWorkflowForRequest(request: ManualInterventionRequest): WorkflowDefinition | null {
    for (const workflow of this.workflows.values()) {
      if (workflow.category === request.category) {
        return workflow;
      }
    }
    return null;
  }

  private getErrorId(error: ErrorInstance): string {
    return error.metadata.correlationId || `error-${Date.now()}`;
  }

  private generateId(prefix: string): string {
    return `${prefix}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private initializeDefaultWorkflows(): void {
    // Database Recovery Workflow
    this.registerWorkflow({
      id: 'database-recovery',
      name: 'Database Recovery Workflow',
      description: 'Manual intervention for database-related issues',
      category: 'database',
      severityLevels: [ErrorSeverity.HIGH, ErrorSeverity.CRITICAL],
      priority: InterventionPriority.HIGH,
      approvalLevels: [ApprovalLevel.SENIOR_ENGINEER],
      requiredSkills: ['database', 'sql'],
      estimatedDuration: 60,
      actions: [
        {
          name: 'Assess Database Impact',
          description: 'Evaluate the scope and impact of the database issue',
          type: 'manual',
          required: true,
          timeout: 15
        },
        {
          name: 'Check Database Logs',
          description: 'Review database error logs and slow query logs',
          type: 'manual',
          required: true,
          timeout: 10
        },
        {
          name: 'Execute Recovery Script',
          description: 'Run the appropriate database recovery script',
          type: 'script',
          required: true,
          timeout: 30,
          validationRequired: true
        },
        {
          name: 'Validate Data Integrity',
          description: 'Verify data consistency and integrity after recovery',
          type: 'manual',
          required: true,
          timeout: 20
        }
      ],
      autoEscalationRules: [
        {
          condition: { timeElapsed: 60 },
          escalateTo: ApprovalLevel.TEAM_LEAD,
          notifyStakeholders: true
        }
      ],
      notificationRules: [
        {
          trigger: 'creation',
          recipients: ['dba-team@company.com'],
          template: 'database-intervention-required'
        },
        {
          trigger: 'escalation',
          recipients: ['team-lead@company.com', 'engineering-manager@company.com'],
          template: 'intervention-escalated'
        }
      ]
    });

    // Security Incident Workflow
    this.registerWorkflow({
      id: 'security-incident',
      name: 'Security Incident Response',
      description: 'Manual intervention for security-related incidents',
      category: 'security',
      severityLevels: [ErrorSeverity.CRITICAL, ErrorSeverity.HIGH],
      priority: InterventionPriority.URGENT,
      approvalLevels: [ApprovalLevel.TEAM_LEAD, ApprovalLevel.MANAGER],
      requiredSkills: ['security', 'incident-response'],
      estimatedDuration: 120,
      actions: [
        {
          name: 'Isolate Affected Systems',
          description: 'Immediately isolate or disable affected systems',
          type: 'manual',
          required: true,
          timeout: 10
        },
        {
          name: 'Gather Evidence',
          description: 'Collect logs, traces, and evidence of the security incident',
          type: 'manual',
          required: true,
          timeout: 30
        },
        {
          name: 'Assess Scope',
          description: 'Determine the full scope and impact of the security incident',
          type: 'manual',
          required: true,
          timeout: 45
        },
        {
          name: 'Implement Fix',
          description: 'Apply the necessary security fixes and patches',
          type: 'manual',
          required: true,
          timeout: 60,
          validationRequired: true
        },
        {
          name: 'Document Incident',
          description: 'Create detailed incident report and documentation',
          type: 'manual',
          required: true,
          timeout: 30
        }
      ],
      autoEscalationRules: [
        {
          condition: { timeElapsed: 30 },
          escalateTo: ApprovalLevel.MANAGER,
          notifyStakeholders: true
        },
        {
          condition: { timeElapsed: 60 },
          escalateTo: ApprovalLevel.DIRECTOR,
          notifyStakeholders: true
        }
      ],
      notificationRules: [
        {
          trigger: 'creation',
          recipients: ['security-team@company.com', 'on-call-engineer@company.com'],
          template: 'security-incident-critical'
        },
        {
          trigger: 'escalation',
          recipients: ['ciso@company.com', 'cto@company.com'],
          template: 'security-incident-escalated'
        }
      ]
    });

    // Performance Issue Workflow
    this.registerWorkflow({
      id: 'performance-issue',
      name: 'Performance Issue Resolution',
      description: 'Manual intervention for performance-related issues',
      category: 'performance',
      severityLevels: [ErrorSeverity.MEDIUM, ErrorSeverity.HIGH],
      priority: InterventionPriority.MEDIUM,
      approvalLevels: [ApprovalLevel.OPERATOR, ApprovalLevel.SENIOR_ENGINEER],
      requiredSkills: ['performance', 'monitoring'],
      estimatedDuration: 90,
      actions: [
        {
          name: 'Analyze Performance Metrics',
          description: 'Review current performance metrics and trends',
          type: 'manual',
          required: true,
          timeout: 20
        },
        {
          name: 'Identify Bottlenecks',
          description: 'Identify the root cause of performance degradation',
          type: 'manual',
          required: true,
          timeout: 30
        },
        {
          name: 'Implement Optimization',
          description: 'Apply performance optimizations',
          type: 'manual',
          required: true,
          timeout: 45
        },
        {
          name: 'Validate Improvement',
          description: 'Verify that performance has improved',
          type: 'manual',
          required: true,
          timeout: 15
        }
      ],
      autoEscalationRules: [
        {
          condition: { timeElapsed: 90 },
          escalateTo: ApprovalLevel.SENIOR_ENGINEER,
          notifyStakeholders: false
        }
      ],
      notificationRules: [
        {
          trigger: 'creation',
          recipients: ['performance-team@company.com'],
          template: 'performance-issue-detected'
        }
      ]
    });
  }

  private initializeApprovers(): void {
    this.addApprover(ApprovalLevel.OPERATOR, 'operator1');
    this.addApprover(ApprovalLevel.OPERATOR, 'operator2');
    
    this.addApprover(ApprovalLevel.SENIOR_ENGINEER, 'senior1');
    this.addApprover(ApprovalLevel.SENIOR_ENGINEER, 'senior2');
    
    this.addApprover(ApprovalLevel.TEAM_LEAD, 'lead1');
    this.addApprover(ApprovalLevel.TEAM_LEAD, 'lead2');
    
    this.addApprover(ApprovalLevel.MANAGER, 'manager1');
    
    this.addApprover(ApprovalLevel.DIRECTOR, 'director1');
    
    this.addApprover(ApprovalLevel.EXECUTIVE, 'cto');
  }
}

export const manualInterventionWorkflow = new ManualInterventionWorkflow();
