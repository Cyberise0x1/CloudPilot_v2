/**
 * Recovery Orchestration System
 * 
 * This module orchestrates the entire recovery process, coordinating between
 * automated and manual recovery workflows, managing state transitions, and
 * providing a unified interface for error recovery.
 */

import { ErrorInstance, ErrorStatus, ErrorSeverity } from './error-classification';
import { automatedRecovery, RecoveryResult } from './automated-recovery';
import { 
  manualInterventionWorkflow, 
  ManualInterventionRequest,
  InterventionStatus,
  ApprovalLevel 
} from './manual-intervention';

export enum RecoveryMode {
  AUTO_ONLY = 'auto_only',           // Automated recovery only
  MANUAL_ONLY = 'manual_only',       // Manual recovery only
  HYBRID = 'hybrid',                 // Automated first, then manual
  ESCALATION = 'escalation'         // Immediate escalation to manual
}

export enum OrchestrationStatus {
  IDLE = 'idle',
  ANALYZING = 'analyzing',
  AUTOMATED_RECOVERY = 'automated_recovery',
  MANUAL_INTERVENTION = 'manual_intervention',
  WAITING_APPROVAL = 'waiting_approval',
  RECOVERING = 'recovering',
  COMPLETED = 'completed',
  FAILED = 'failed',
  ESCALATED = 'escalated'
}

export interface RecoverySession {
  id: string;
  error: ErrorInstance;
  status: OrchestrationStatus;
  mode: RecoveryMode;
  startTime: Date;
  endTime?: Date;
  automatedRecovery?: RecoveryResult;
  manualIntervention?: ManualInterventionRequest;
  recoverySteps: RecoveryStep[];
  currentStepIndex: number;
  state: Record<string, any>;
  metrics: RecoveryMetrics;
  escalationHistory: EscalationRecord[];
  notifications: NotificationRecord[];
}

export interface RecoveryStep {
  id: string;
  name: string;
  description: string;
  type: 'automated' | 'manual' | 'approval' | 'validation' | 'escalation';
  status: 'pending' | 'in_progress' | 'completed' | 'failed' | 'skipped';
  startTime?: Date;
  endTime?: Date;
  result?: any;
  error?: Error;
  dependencies: string[]; // Step IDs this step depends on
  timeout?: number; // in minutes
}

export interface RecoveryMetrics {
  timeToDetect: number; // milliseconds
  timeToStartRecovery: number; // milliseconds
  timeToRecovery: number; // milliseconds
  automationSuccessRate: number; // percentage
  manualInterventionRate: number; // percentage
  escalationRate: number; // percentage
  customerImpact: number; // 0-10 scale
  systemAvailability: number; // percentage
}

export interface EscalationRecord {
  timestamp: Date;
  fromLevel: string;
  toLevel: string;
  reason: string;
  triggeredBy: 'automated' | 'manual' | 'timeout' | 'failure';
}

export interface NotificationRecord {
  timestamp: Date;
  type: string;
  recipients: string[];
  subject: string;
  content: string;
  status: 'sent' | 'failed' | 'pending';
}

export interface RecoveryPolicy {
  name: string;
  description: string;
  mode: RecoveryMode;
  maxAutomationTime: number; // milliseconds
  maxTotalTime: number; // milliseconds
  autoEscalationRules: PolicyEscalationRule[];
  notificationRules: PolicyNotificationRule[];
  retryPolicy: RetryPolicy;
}

export interface PolicyEscalationRule {
  condition: {
    timeElapsed?: number;
    failureCount?: number;
    severity?: ErrorSeverity;
    errorCategory?: string;
  };
  action: 'escalate' | 'failover' | 'notify' | 'restart';
  target: string;
}

export interface PolicyNotificationRule {
  trigger: 'start' | 'progress' | 'escalation' | 'completion' | 'failure';
  recipients: string[];
  template: string;
  includeContext: boolean;
}

export interface RetryPolicy {
  maxAttempts: number;
  backoffStrategy: 'linear' | 'exponential' | 'fixed';
  baseDelay: number; // milliseconds
  maxDelay: number; // milliseconds
  jitter: boolean;
}

export class RecoveryOrchestrator {
  private sessions: Map<string, RecoverySession> = new Map();
  private policies: Map<string, RecoveryPolicy> = new Map();
  private activeTimeoutTimers: Map<string, NodeJS.Timeout> = new Map();

  constructor() {
    this.initializeDefaultPolicies();
  }

  async initiateRecovery(
    error: ErrorInstance,
    mode: RecoveryMode = RecoveryMode.HYBRID,
    policyId?: string
  ): Promise<string> {
    const sessionId = this.generateSessionId();
    
    const session: RecoverySession = {
      id: sessionId,
      error: error,
      status: OrchestrationStatus.ANALYZING,
      mode: mode,
      startTime: new Date(),
      recoverySteps: [],
      currentStepIndex: 0,
      state: {},
      metrics: {
        timeToDetect: Date.now() - error.metadata.timestamp.getTime(),
        timeToStartRecovery: 0,
        timeToRecovery: 0,
        automationSuccessRate: 0,
        manualInterventionRate: 0,
        escalationRate: 0,
        customerImpact: 0,
        systemAvailability: 100
      },
      escalationHistory: [],
      notifications: []
    };

    this.sessions.set(sessionId, session);

    try {
      // Update error status
      error.status = ErrorStatus.IN_RECOVERY;

      // Select or create policy
      const policy = policyId ? this.policies.get(policyId) : this.selectPolicy(error);
      
      if (!policy) {
        throw new Error('No suitable recovery policy found');
      }

      // Create recovery steps based on policy and mode
      session.recoverySteps = this.createRecoverySteps(error, mode, policy);
      
      // Set up timeouts
      this.setupTimeouts(session, policy);

      // Send start notification
      await this.sendNotification(session, 'start', policy);

      // Start recovery process
      await this.executeRecoverySession(sessionId);

      return sessionId;

    } catch (err) {
      session.status = OrchestrationStatus.FAILED;
      session.error = err as Error;
      await this.handleRecoveryFailure(sessionId, err as Error);
      throw err;
    }
  }

  async executeRecoverySession(sessionId: string): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (!session) {
      throw new Error(`Recovery session not found: ${sessionId}`);
    }

    session.metrics.timeToStartRecovery = Date.now() - session.startTime.getTime();

    try {
      switch (session.mode) {
        case RecoveryMode.AUTO_ONLY:
          await this.executeAutomatedOnly(sessionId);
          break;
        case RecoveryMode.MANUAL_ONLY:
          await this.executeManualOnly(sessionId);
          break;
        case RecoveryMode.HYBRID:
          await this.executeHybrid(sessionId);
          break;
        case RecoveryMode.ESCALATION:
          await this.executeEscalation(sessionId);
          break;
      }
    } catch (error) {
      await this.handleRecoveryFailure(sessionId, error as Error);
    }
  }

  private async executeAutomatedOnly(sessionId: string): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (!session) return;

    session.status = OrchestrationStatus.AUTOMATED_RECOVERY;

    try {
      const result = await automatedRecovery.executeRecovery(session.error, {
        error: session.error,
        metadata: session.error.metadata,
        previousStepResults: new Map(),
        environment: session.error.metadata.environment
      });

      session.automatedRecovery = result;

      if (result.success) {
        session.status = OrchestrationStatus.COMPLETED;
        session.metrics.timeToRecovery = Date.now() - session.startTime.getTime();
        await this.completeRecovery(sessionId);
      } else {
        // Automated recovery failed, escalate
        await this.escalateToManual(sessionId, 'Automated recovery failed');
      }
    } catch (error) {
      await this.escalateToManual(sessionId, `Automated recovery error: ${error.message}`);
    }
  }

  private async executeManualOnly(sessionId: string): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (!session) return;

    await this.escalateToManual(sessionId, 'Manual intervention required');
  }

  private async executeHybrid(sessionId: string): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (!session) return;

    try {
      // Try automated recovery first
      session.status = OrchestrationStatus.AUTOMATED_RECOVERY;

      const result = await automatedRecovery.executeRecovery(session.error, {
        error: session.error,
        metadata: session.error.metadata,
        previousStepResults: new Map(),
        environment: session.error.metadata.environment
      });

      session.automatedRecovery = result;

      if (result.success) {
        session.status = OrchestrationStatus.COMPLETED;
        session.metrics.timeToRecovery = Date.now() - session.startTime.getTime();
        session.metrics.automationSuccessRate = 100;
        await this.completeRecovery(sessionId);
      } else {
        // Automated recovery failed, escalate to manual
        await this.escalateToManual(sessionId, 'Automated recovery failed');
      }
    } catch (error) {
      await this.escalateToManual(sessionId, `Automated recovery error: ${error.message}`);
    }
  }

  private async executeEscalation(sessionId: string): Promise<void> {
    await this.escalateToManual(sessionId, 'Immediate escalation required');
  }

  private async escalateToManual(sessionId: string, reason: string): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (!session) return;

    session.status = OrchestrationStatus.MANUAL_INTERVENTION;

    // Determine appropriate workflow based on error
    const workflowId = this.selectWorkflowForError(session.error);
    
    try {
      session.manualIntervention = await manualInterventionWorkflow.createInterventionRequest(
        session.error,
        workflowId,
        {
          sessionId: sessionId,
          escalationReason: reason,
          automatedRecoveryAttempted: !!session.automatedRecovery,
          automatedRecoveryResult: session.automatedRecovery
        }
      );

      // Update metrics
      session.metrics.manualInterventionRate = 100;
      if (session.automatedRecovery) {
        session.metrics.automationSuccessRate = session.automatedRecovery.success ? 50 : 0;
      }

      // Set up manual intervention monitoring
      await this.monitorManualIntervention(sessionId);

    } catch (error) {
      session.status = OrchestrationStatus.FAILED;
      session.error = error as Error;
      await this.handleRecoveryFailure(sessionId, error as Error);
    }
  }

  private async monitorManualIntervention(sessionId: string): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (!session || !session.manualIntervention) return;

    // Poll for completion or update status
    const checkInterval = setInterval(async () => {
      const request = manualInterventionWorkflow.getRequestStatus(session.manualIntervention!.id);
      
      if (request) {
        session.manualIntervention = request;

        switch (request.status) {
          case InterventionStatus.APPROVED:
          case InterventionStatus.COMPLETED:
            session.status = OrchestrationStatus.COMPLETED;
            session.metrics.timeToRecovery = Date.now() - session.startTime.getTime();
            clearInterval(checkInterval);
            await this.completeRecovery(sessionId);
            break;

          case InterventionStatus.ESCALATED:
            session.metrics.escalationRate = 100;
            await this.handleEscalation(sessionId);
            break;

          case InterventionStatus.REJECTED:
            session.status = OrchestrationStatus.FAILED;
            clearInterval(checkInterval);
            await this.handleRecoveryFailure(sessionId, new Error('Manual intervention rejected'));
            break;
        }
      } else {
        // Manual intervention request not found, consider failed
        session.status = OrchestrationStatus.FAILED;
        clearInterval(checkInterval);
        await this.handleRecoveryFailure(sessionId, new Error('Manual intervention request lost'));
      }
    }, 5000); // Check every 5 seconds

    // Store timeout to clean up
    this.activeTimeoutTimers.set(`${sessionId}-manual-monitor`, checkInterval);
  }

  private async completeRecovery(sessionId: string): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (!session) return;

    session.status = OrchestrationStatus.COMPLETED;
    session.endTime = new Date();

    // Validate recovery
    const validationResult = await this.validateRecovery(session);
    if (!validationResult.success) {
      session.status = OrchestrationStatus.FAILED;
      await this.handleRecoveryFailure(sessionId, new Error('Recovery validation failed'));
      return;
    }

    // Update error status
    session.error.status = ErrorStatus.RECOVERED;

    // Send completion notification
    await this.sendNotification(session, 'completion', this.getPolicyForSession(session));

    // Clean up
    this.cleanupSession(sessionId);
  }

  private async handleRecoveryFailure(sessionId: string, error: Error): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (!session) return;

    session.status = OrchestrationStatus.FAILED;
    session.error = error;
    session.endTime = new Date();

    // Update error status
    session.error.status = ErrorStatus.FAILED_RECOVERY;

    // Send failure notification
    await this.sendNotification(session, 'failure', this.getPolicyForSession(session));

    // Attempt final escalation
    await this.handleFinalEscalation(sessionId);

    // Clean up after delay
    setTimeout(() => this.cleanupSession(sessionId), 60000); // Clean up after 1 minute
  }

  private async handleEscalation(sessionId: string): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (!session) return;

    session.status = OrchestrationStatus.ESCALATED;

    const escalation: EscalationRecord = {
      timestamp: new Date(),
      fromLevel: 'current',
      toLevel: 'higher',
      reason: 'Manual intervention escalation',
      triggeredBy: 'manual'
    };

    session.escalationHistory.push(escalation);
    session.metrics.escalationRate = 100;

    await this.sendNotification(session, 'escalation', this.getPolicyForSession(session));
  }

  private async handleFinalEscalation(sessionId: string): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (!session) return;

    // This would typically trigger an emergency notification to on-call engineers
    // or escalate to management
    console.log(`Final escalation for session ${sessionId}`);
  }

  private async validateRecovery(session: RecoverySession): Promise<{ success: boolean; details: string[] }> {
    const details: string[] = [];

    try {
      // Basic validation checks
      details.push('Checking error condition resolution...');
      
      // Check if the original error still exists
      // This would be implemented with actual monitoring/health checks
      const isErrorResolved = await this.checkErrorResolution(session.error);
      if (isErrorResolved) {
        details.push('✓ Error condition resolved');
      } else {
        details.push('✗ Error condition persists');
        return { success: false, details };
      }

      // Validate system health
      details.push('Validating system health...');
      const healthCheck = await this.performSystemHealthCheck();
      if (healthCheck.healthy) {
        details.push('✓ System health verified');
      } else {
        details.push('✗ System health degraded');
        details.push(...healthCheck.issues);
        return { success: false, details };
      }

      return { success: true, details };

    } catch (error) {
      details.push(`Validation error: ${error.message}`);
      return { success: false, details };
    }
  }

  private selectPolicy(error: ErrorInstance): RecoveryPolicy {
    // Select policy based on error characteristics
    for (const policy of this.policies.values()) {
      if (this.matchesPolicy(error, policy)) {
        return policy;
      }
    }

    // Return default policy if no match found
    return this.policies.get('default')!;
  }

  private matchesPolicy(error: ErrorInstance, policy: RecoveryPolicy): boolean {
    // Policy matching logic based on error properties
    if (policy.name === 'default') return true;
    
    // Add specific matching logic here based on error category, severity, etc.
    return false;
  }

  private selectWorkflowForError(error: ErrorInstance): string {
    // Map error types to manual intervention workflows
    const categoryWorkflowMap: Record<string, string> = {
      'database': 'database-recovery',
      'security': 'security-incident',
      'performance': 'performance-issue',
      'infrastructure': 'infrastructure-recovery'
    };

    return categoryWorkflowMap[error.category] || 'general-recovery';
  }

  private createRecoverySteps(error: ErrorInstance, mode: RecoveryMode, policy: RecoveryPolicy): RecoveryStep[] {
    const steps: RecoveryStep[] = [];

    // Analysis step
    steps.push({
      id: 'analyze',
      name: 'Analyze Error',
      description: 'Analyze the error and determine recovery strategy',
      type: 'automated',
      status: 'completed',
      dependencies: []
    });

    switch (mode) {
      case RecoveryMode.AUTO_ONLY:
        steps.push({
          id: 'automated-recovery',
          name: 'Automated Recovery',
          description: 'Execute automated recovery procedures',
          type: 'automated',
          status: 'pending',
          dependencies: ['analyze']
        });
        break;

      case RecoveryMode.MANUAL_ONLY:
        steps.push({
          id: 'manual-intervention',
          name: 'Manual Intervention',
          description: 'Escalate to manual intervention',
          type: 'manual',
          status: 'pending',
          dependencies: ['analyze']
        });
        break;

      case RecoveryMode.HYBRID:
        steps.push(
          {
            id: 'automated-recovery',
            name: 'Automated Recovery Attempt',
            description: 'Try automated recovery first',
            type: 'automated',
            status: 'pending',
            dependencies: ['analyze']
          },
          {
            id: 'manual-intervention',
            name: 'Manual Intervention',
            description: 'Escalate to manual intervention if automated fails',
            type: 'manual',
            status: 'pending',
            dependencies: ['automated-recovery']
          }
        );
        break;

      case RecoveryMode.ESCALATION:
        steps.push({
          id: 'escalation',
          name: 'Immediate Escalation',
          description: 'Immediate escalation to manual intervention',
          type: 'escalation',
          status: 'pending',
          dependencies: ['analyze']
        });
        break;
    }

    // Validation step
    steps.push({
      id: 'validate',
      name: 'Validate Recovery',
      description: 'Validate that recovery was successful',
      type: 'validation',
      status: 'pending',
      dependencies: steps.filter(s => s.type === 'automated' || s.type === 'manual' || s.type === 'escalation').map(s => s.id)
    });

    return steps;
  }

  private setupTimeouts(session: RecoverySession, policy: RecoveryPolicy): void {
    // Set up overall timeout
    const overallTimeout = setTimeout(() => {
      this.handleTimeout(session.id, 'Overall recovery timeout');
    }, policy.maxTotalTime);

    this.activeTimeoutTimers.set(`${session.id}-overall`, overallTimeout);

    // Set up automation timeout
    if (session.mode === RecoveryMode.AUTO_ONLY || session.mode === RecoveryMode.HYBRID) {
      const automationTimeout = setTimeout(() => {
        this.handleTimeout(session.id, 'Automation timeout');
      }, policy.maxAutomationTime);

      this.activeTimeoutTimers.set(`${session.id}-automation`, automationTimeout);
    }
  }

  private async handleTimeout(sessionId: string, reason: string): Promise<void> {
    const session = this.sessions.get(sessionId);
    if (!session) return;

    console.log(`Timeout handling for session ${sessionId}: ${reason}`);

    if (session.status === OrchestrationStatus.AUTOMATED_RECOVERY) {
      // Automation timed out, escalate to manual
      await this.escalateToManual(sessionId, reason);
    } else {
      // Overall timeout, mark as failed
      await this.handleRecoveryFailure(sessionId, new Error(reason));
    }
  }

  private getPolicyForSession(session: RecoverySession): RecoveryPolicy | null {
    // Find the policy used for this session
    for (const policy of this.policies.values()) {
      if (this.matchesPolicy(session.error, policy)) {
        return policy;
      }
    }
    return null;
  }

  private async sendNotification(
    session: RecoverySession,
    trigger: string,
    policy: RecoveryPolicy | null
  ): Promise<void> {
    if (!policy) return;

    const notificationRules = policy.notificationRules.filter(rule => rule.trigger === trigger);
    
    for (const rule of notificationRules) {
      const notification: NotificationRecord = {
        timestamp: new Date(),
        type: trigger,
        recipients: rule.recipients,
        subject: `${trigger.toUpperCase()}: Error Recovery - ${session.error.category}`,
        content: `Recovery ${trigger} for error: ${session.error.message}`,
        status: 'pending'
      };

      session.notifications.push(notification);

      try {
        // Implement actual notification sending logic
        console.log('Sending notification:', notification);
        notification.status = 'sent';
      } catch (error) {
        notification.status = 'failed';
        console.error('Notification failed:', error);
      }
    }
  }

  // Health check and validation methods
  private async checkErrorResolution(error: ErrorInstance): Promise<boolean> {
    // Check if the original error condition is resolved
    // This would integrate with your monitoring system
    return true;
  }

  private async performSystemHealthCheck(): Promise<{ healthy: boolean; issues: string[] }> {
    // Perform comprehensive system health check
    // This would integrate with your monitoring/health check systems
    return {
      healthy: true,
      issues: []
    };
  }

  private cleanupSession(sessionId: string): void {
    // Clean up timers
    const timerKeys = Array.from(this.activeTimeoutTimers.keys()).filter(key => key.startsWith(sessionId));
    timerKeys.forEach(key => {
      clearTimeout(this.activeTimeoutTimers.get(key));
      this.activeTimeoutTimers.delete(key);
    });

    // Archive session data if needed
    // In a real system, you might want to store completed sessions for analytics
    
    // Remove from active sessions
    setTimeout(() => {
      this.sessions.delete(sessionId);
    }, 300000); // Keep for 5 minutes before final cleanup
  }

  // Public methods for session management
  getSession(sessionId: string): RecoverySession | null {
    return this.sessions.get(sessionId) || null;
  }

  getActiveSessions(): RecoverySession[] {
    return Array.from(this.sessions.values()).filter(session => 
      session.status !== OrchestrationStatus.COMPLETED && 
      session.status !== OrchestrationStatus.FAILED
    );
  }

  cancelSession(sessionId: string): boolean {
    const session = this.sessions.get(sessionId);
    if (!session || session.status === OrchestrationStatus.COMPLETED) {
      return false;
    }

    session.status = OrchestrationStatus.FAILED;
    this.cleanupSession(sessionId);
    return true;
  }

  private generateSessionId(): string {
    return `recovery-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private initializeDefaultPolicies(): void {
    // Default recovery policy
    this.policies.set('default', {
      name: 'Default Recovery Policy',
      description: 'Standard recovery policy for general errors',
      mode: RecoveryMode.HYBRID,
      maxAutomationTime: 300000, // 5 minutes
      maxTotalTime: 1800000, // 30 minutes
      autoEscalationRules: [
        {
          condition: { timeElapsed: 300000 }, // 5 minutes
          action: 'escalate',
          target: 'manual-intervention'
        }
      ],
      notificationRules: [
        {
          trigger: 'start',
          recipients: ['operations@company.com'],
          template: 'recovery-started',
          includeContext: true
        },
        {
          trigger: 'completion',
          recipients: ['operations@company.com'],
          template: 'recovery-completed',
          includeContext: true
        },
        {
          trigger: 'failure',
          recipients: ['operations@company.com', 'management@company.com'],
          template: 'recovery-failed',
          includeContext: true
        }
      ],
      retryPolicy: {
        maxAttempts: 3,
        backoffStrategy: 'exponential',
        baseDelay: 1000,
        maxDelay: 30000,
        jitter: true
      }
    });

    // Critical error policy
    this.policies.set('critical', {
      name: 'Critical Error Policy',
      description: 'Recovery policy for critical errors',
      mode: RecoveryMode.ESCALATION,
      maxAutomationTime: 60000, // 1 minute
      maxTotalTime: 900000, // 15 minutes
      autoEscalationRules: [
        {
          condition: { timeElapsed: 60000 }, // 1 minute
          action: 'escalate',
          target: 'emergency-response'
        }
      ],
      notificationRules: [
        {
          trigger: 'start',
          recipients: ['on-call@company.com', 'management@company.com'],
          template: 'critical-error',
          includeContext: true
        },
        {
          trigger: 'escalation',
          recipients: ['cto@company.com', 'emergency-response@company.com'],
          template: 'critical-escalation',
          includeContext: true
        }
      ],
      retryPolicy: {
        maxAttempts: 1,
        backoffStrategy: 'fixed',
        baseDelay: 1000,
        maxDelay: 5000,
        jitter: false
      }
    });
  }
}

export const recoveryOrchestrator = new RecoveryOrchestrator();
